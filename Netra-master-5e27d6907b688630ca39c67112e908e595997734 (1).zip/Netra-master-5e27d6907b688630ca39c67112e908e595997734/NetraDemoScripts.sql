-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.5.35-1ubuntu1


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema netra_437
--

CREATE DATABASE IF NOT EXISTS netra_437;
USE netra_437;

--
-- Definition of table `activities_exec_order`
--

DROP TABLE IF EXISTS `activities_exec_order`;
CREATE TABLE `activities_exec_order` (
  `Activities_Execution_Id` int(11) NOT NULL AUTO_INCREMENT,
  `activity_software_Map_Id` int(10) unsigned NOT NULL,
  `Linked_Activity_Id` int(10) unsigned NOT NULL,
  `Execution_Order` int(11) NOT NULL,
  PRIMARY KEY (`Activities_Execution_Id`),
  KEY `FK_actvts_exc_ordr_actvty_sftwr_mp_id_1` (`activity_software_Map_Id`),
  KEY `FK_actvts_exc_ordr_actvty_sftwr_mp_id_2` (`Linked_Activity_Id`),
  CONSTRAINT `FK_actvts_exc_ordr_actvty_sftwr_mp_id_1` FOREIGN KEY (`activity_software_Map_Id`) REFERENCES `activity_software_mapping` (`activity_software_map_id`),
  CONSTRAINT `FK_actvts_exc_ordr_actvty_sftwr_mp_id_2` FOREIGN KEY (`Linked_Activity_Id`) REFERENCES `activity_software_mapping` (`activity_software_map_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `activities_exec_order`
--

/*!40000 ALTER TABLE `activities_exec_order` DISABLE KEYS */;
INSERT INTO `activities_exec_order` (`Activities_Execution_Id`,`activity_software_Map_Id`,`Linked_Activity_Id`,`Execution_Order`) VALUES 
 (1,1,1,0),
 (2,2,2,0),
 (3,3,3,0),
 (4,4,4,0),
 (5,5,5,0),
 (6,6,6,0),
 (7,7,7,0),
 (8,8,8,0);
/*!40000 ALTER TABLE `activities_exec_order` ENABLE KEYS */;


--
-- Definition of table `activity_software_mapping`
--

DROP TABLE IF EXISTS `activity_software_mapping`;
CREATE TABLE `activity_software_mapping` (
  `activity_software_map_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `software_config_Id` int(10) unsigned NOT NULL,
  `activity_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`activity_software_map_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `activity_software_mapping`
--

/*!40000 ALTER TABLE `activity_software_mapping` DISABLE KEYS */;
INSERT INTO `activity_software_mapping` (`activity_software_map_id`,`software_config_Id`,`activity_id`) VALUES 
 (1,1,1),
 (2,1,2),
 (3,1,7),
 (4,2,1),
 (5,2,3),
 (6,2,5),
 (7,2,6),
 (8,2,7);
/*!40000 ALTER TABLE `activity_software_mapping` ENABLE KEYS */;


--
-- Definition of table `allocation_master`
--

DROP TABLE IF EXISTS `allocation_master`;
CREATE TABLE `allocation_master` (
  `id` char(1) NOT NULL,
  `Name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `allocation_master`
--

/*!40000 ALTER TABLE `allocation_master` DISABLE KEYS */;
INSERT INTO `allocation_master` (`id`,`Name`) VALUES 
 ('A','Normal'),
 ('D','Disruptive'),
 ('L','Locked'),
 ('S','Shared');
/*!40000 ALTER TABLE `allocation_master` ENABLE KEYS */;


--
-- Definition of table `app_prf_conf_param_tmplt_map`
--

DROP TABLE IF EXISTS `app_prf_conf_param_tmplt_map`;
CREATE TABLE `app_prf_conf_param_tmplt_map` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `app_prf_config_id` int(11) NOT NULL,
  `app_prf_config_params_id` int(11) NOT NULL,
  `environment_id` int(10) unsigned DEFAULT NULL,
  `param_value` varchar(30) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_app_prf_conf_param_tmplt_mapping_1` (`app_prf_config_id`),
  KEY `FK_app_prf_conf_param_tmplt_mapping_2` (`app_prf_config_params_id`),
  KEY `FK_app_prf_conf_param_tmplt_mapping_3` (`environment_id`),
  CONSTRAINT `FK_app_prf_conf_param_tmplt_mapping_1` FOREIGN KEY (`app_prf_config_id`) REFERENCES `app_prf_config` (`id`),
  CONSTRAINT `FK_app_prf_conf_param_tmplt_mapping_2` FOREIGN KEY (`app_prf_config_params_id`) REFERENCES `app_prf_config_params` (`id`),
  CONSTRAINT `FK_app_prf_conf_param_tmplt_mapping_3` FOREIGN KEY (`environment_id`) REFERENCES `environments` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `app_prf_conf_param_tmplt_map`
--

/*!40000 ALTER TABLE `app_prf_conf_param_tmplt_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_prf_conf_param_tmplt_map` ENABLE KEYS */;


--
-- Definition of table `app_prf_config`
--

DROP TABLE IF EXISTS `app_prf_config`;
CREATE TABLE `app_prf_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_prf_id` int(10) unsigned DEFAULT NULL,
  `app_prf_det_id` int(10) unsigned DEFAULT NULL,
  `software_config_id` int(11) DEFAULT NULL,
  `application_id` int(10) unsigned DEFAULT NULL,
  `file_name` varchar(45) NOT NULL,
  `file_target_path` varchar(600) NOT NULL,
  `config_file` longblob NOT NULL,
  `template_file` longblob,
  `param_String` varchar(4000) DEFAULT NULL,
  `original_Line_String` varchar(4000) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_app_prf_config_1` (`software_config_id`),
  KEY `FK_app_prf_config_2` (`application_id`),
  CONSTRAINT `FK_app_prf_config_1` FOREIGN KEY (`software_config_id`) REFERENCES `softwareconfig` (`id`),
  CONSTRAINT `FK_app_prf_config_2` FOREIGN KEY (`application_id`) REFERENCES `applications` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `app_prf_config`
--

/*!40000 ALTER TABLE `app_prf_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_prf_config` ENABLE KEYS */;


--
-- Definition of table `app_prf_config_params`
--

DROP TABLE IF EXISTS `app_prf_config_params`;
CREATE TABLE `app_prf_config_params` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_prf_config_id` int(11) DEFAULT NULL,
  `param_name` varchar(300) NOT NULL,
  `default_value` varchar(30) NOT NULL,
  `param_hint_line` longtext NOT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_by` int(10) unsigned DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_app_prf_config_params_1` (`app_prf_config_id`),
  CONSTRAINT `FK_app_prf_config_params_1` FOREIGN KEY (`app_prf_config_id`) REFERENCES `app_prf_config` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `app_prf_config_params`
--

/*!40000 ALTER TABLE `app_prf_config_params` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_prf_config_params` ENABLE KEYS */;


--
-- Definition of table `app_rel_build_mapping`
--

DROP TABLE IF EXISTS `app_rel_build_mapping`;
CREATE TABLE `app_rel_build_mapping` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `app_release_id` int(10) unsigned NOT NULL,
  `build_tool_definition_id` int(10) unsigned NOT NULL,
  `request_id` int(10) unsigned DEFAULT NULL,
  `testing_phase_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `app_rel_build_mapping`
--

/*!40000 ALTER TABLE `app_rel_build_mapping` DISABLE KEYS */;
INSERT INTO `app_rel_build_mapping` (`id`,`app_release_id`,`build_tool_definition_id`,`request_id`,`testing_phase_id`) VALUES 
 (1,1,1,NULL,0),
 (2,2,2,NULL,0);
/*!40000 ALTER TABLE `app_rel_build_mapping` ENABLE KEYS */;


--
-- Definition of table `app_rel_sharedresource_details`
--

DROP TABLE IF EXISTS `app_rel_sharedresource_details`;
CREATE TABLE `app_rel_sharedresource_details` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `application_release_id` int(10) unsigned NOT NULL,
  `resourceType` varchar(45) NOT NULL,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `sharedIP` varchar(45) NOT NULL,
  `sharedHostName` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `app_rel_sharedresource_details`
--

/*!40000 ALTER TABLE `app_rel_sharedresource_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_rel_sharedresource_details` ENABLE KEYS */;


--
-- Definition of table `app_release_shared_dtls`
--

DROP TABLE IF EXISTS `app_release_shared_dtls`;
CREATE TABLE `app_release_shared_dtls` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `shared_ip` varchar(45) NOT NULL,
  `hostname` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `app_release_shared_dtls`
--

/*!40000 ALTER TABLE `app_release_shared_dtls` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_release_shared_dtls` ENABLE KEYS */;


--
-- Definition of table `app_release_shared_map`
--

DROP TABLE IF EXISTS `app_release_shared_map`;
CREATE TABLE `app_release_shared_map` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `repository_master_id` int(11) NOT NULL,
  `shared_resource_id` int(11) DEFAULT NULL,
  `nexus_resource_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `app_release_shared_map`
--

/*!40000 ALTER TABLE `app_release_shared_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_release_shared_map` ENABLE KEYS */;


--
-- Definition of table `app_release_source_code`
--

DROP TABLE IF EXISTS `app_release_source_code`;
CREATE TABLE `app_release_source_code` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `source_code_path` text,
  `ear_path` text,
  `application_release_id` int(10) unsigned DEFAULT NULL,
  `REQUEST_ID` int(11) DEFAULT NULL,
  `SOFTWARECONFIG_ID` int(10) unsigned DEFAULT NULL,
  `SERVERGROUP_NUMBER` int(10) unsigned DEFAULT NULL,
  `APPLICATION_PROFILE_DETAILS_ID` int(10) unsigned DEFAULT NULL,
  `context_name` text,
  `monitoring_flag` varchar(4) DEFAULT NULL,
  `netra_nexus_path` text,
  `overwrite_flag` varchar(4) DEFAULT NULL,
  `script_path` text,
  `temp_artifact_path` varchar(500) DEFAULT NULL,
  `testing_phase_id` int(10) unsigned NOT NULL,
  `repository_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=352 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `app_release_source_code`
--

/*!40000 ALTER TABLE `app_release_source_code` DISABLE KEYS */;
INSERT INTO `app_release_source_code` (`id`,`source_code_path`,`ear_path`,`application_release_id`,`REQUEST_ID`,`SOFTWARECONFIG_ID`,`SERVERGROUP_NUMBER`,`APPLICATION_PROFILE_DETAILS_ID`,`context_name`,`monitoring_flag`,`netra_nexus_path`,`overwrite_flag`,`script_path`,`temp_artifact_path`,`testing_phase_id`,`repository_id`) VALUES 
 (350,'branches/Release2.0Nex/TEMS/','',1,NULL,2,0,1,'tems','N','http://10.130.25.93:8080/nexus/content/repositories/netra/com.temsinfra/App_J/AppJ_Prof1/App_J-AppJ_Prof1.war','N','',NULL,0,1),
 (351,'branches/Release2.0Nex/TEMS/','',2,NULL,2,0,9,'tems','N','http://10.130.25.93:8080/nexus/content/repositories/netra/com.temsinfra/App_J/Rel_prof1.2/App_J-Rel_prof1.2.war','N','',NULL,0,1);
/*!40000 ALTER TABLE `app_release_source_code` ENABLE KEYS */;


--
-- Definition of table `appl_prf_detls_aws`
--

DROP TABLE IF EXISTS `appl_prf_detls_aws`;
CREATE TABLE `appl_prf_detls_aws` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `profile_id` int(10) unsigned NOT NULL,
  `server_group` int(10) unsigned NOT NULL,
  `key_pair` varchar(80) NOT NULL,
  `availability_zone` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_application_profile_id` (`profile_id`),
  CONSTRAINT `FK_application_profile_id` FOREIGN KEY (`profile_id`) REFERENCES `application_profile` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appl_prf_detls_aws`
--

/*!40000 ALTER TABLE `appl_prf_detls_aws` DISABLE KEYS */;
/*!40000 ALTER TABLE `appl_prf_detls_aws` ENABLE KEYS */;


--
-- Definition of table `applctn_rls_phs`
--

DROP TABLE IF EXISTS `applctn_rls_phs`;
CREATE TABLE `applctn_rls_phs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `applctn_id` int(10) unsigned NOT NULL,
  `release_plan_id` int(10) unsigned DEFAULT NULL,
  `phs_id` int(10) unsigned NOT NULL,
  `ord` int(10) unsigned NOT NULL,
  `status` varchar(2) NOT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `modified_by` int(10) unsigned NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_phs_id` (`phs_id`),
  KEY `FK_applctn_rls_id` (`applctn_id`),
  KEY `FK_release_plan_id` (`release_plan_id`),
  CONSTRAINT `FK_applctn_id` FOREIGN KEY (`applctn_id`) REFERENCES `applications` (`ID`),
  CONSTRAINT `FK_phs_id` FOREIGN KEY (`phs_id`) REFERENCES `testing_phase` (`id`),
  CONSTRAINT `FK_release_plan_id` FOREIGN KEY (`release_plan_id`) REFERENCES `release_planning` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `applctn_rls_phs`
--

/*!40000 ALTER TABLE `applctn_rls_phs` DISABLE KEYS */;
/*!40000 ALTER TABLE `applctn_rls_phs` ENABLE KEYS */;


--
-- Definition of table `application_category`
--

DROP TABLE IF EXISTS `application_category`;
CREATE TABLE `application_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category` varchar(45) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `categoryType` varchar(45) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `application_category`
--

/*!40000 ALTER TABLE `application_category` DISABLE KEYS */;
INSERT INTO `application_category` (`id`,`category`,`categoryType`) VALUES 
 (1,'Other',''),
 (2,'Database','S'),
 (3,'Middleware','S'),
 (4,'User Interface','S'),
 (5,'Web Application','A'),
 (6,'Desktop Application','A'),
 (7,'ERP','A'),
 (9,'Mobile Application','A');
/*!40000 ALTER TABLE `application_category` ENABLE KEYS */;


--
-- Definition of table `application_mobile_testing`
--

DROP TABLE IF EXISTS `application_mobile_testing`;
CREATE TABLE `application_mobile_testing` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `requestId` int(11) NOT NULL,
  `applicationId` int(11) NOT NULL,
  `mobile_test_toolId` varchar(45) NOT NULL,
  `deviceIds` varchar(1000) DEFAULT NULL,
  `scripts` varchar(500) DEFAULT NULL,
  `script_parameters` varchar(500) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `script_report` varchar(500) DEFAULT NULL,
  `base_url` varchar(500) DEFAULT NULL,
  `user_name` varchar(500) DEFAULT NULL,
  `password` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `application_mobile_testing`
--

/*!40000 ALTER TABLE `application_mobile_testing` DISABLE KEYS */;
/*!40000 ALTER TABLE `application_mobile_testing` ENABLE KEYS */;


--
-- Definition of table `application_profile`
--

DROP TABLE IF EXISTS `application_profile`;
CREATE TABLE `application_profile` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `PROFILE_NAME` varchar(45) NOT NULL,
  `PROFILE_STATUS` int(10) unsigned NOT NULL,
  `APPLICATION_ID` int(10) unsigned DEFAULT NULL,
  `MONTRG_REQ` varchar(5) DEFAULT NULL,
  `CREATED_BY` int(10) unsigned NOT NULL,
  `CREATED_DATE` datetime NOT NULL,
  `MODIFIED_BY` int(10) unsigned DEFAULT NULL,
  `MODIFIED_DATE` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_application_profile_1` (`APPLICATION_ID`),
  CONSTRAINT `FK_application_profile_applications` FOREIGN KEY (`APPLICATION_ID`) REFERENCES `applications` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `application_profile`
--

/*!40000 ALTER TABLE `application_profile` DISABLE KEYS */;
INSERT INTO `application_profile` (`ID`,`PROFILE_NAME`,`PROFILE_STATUS`,`APPLICATION_ID`,`MONTRG_REQ`,`CREATED_BY`,`CREATED_DATE`,`MODIFIED_BY`,`MODIFIED_DATE`) VALUES 
 (1,'AppJ_Prof1',101,NULL,'N',3,'2016-07-04 15:42:00',3,'2016-07-04 15:42:00'),
 (2,'Phy_Prof',101,NULL,'N',3,'2016-07-04 17:20:37',3,'2016-07-04 17:20:37'),
 (3,'Prof_phy2',101,NULL,'Y',3,'2016-07-05 14:22:31',3,'2016-07-05 14:22:31'),
 (4,'Phy_Prof226',101,NULL,'N',3,'2016-07-11 15:08:20',3,'2016-07-11 15:08:20'),
 (5,'App_prof2',101,NULL,'N',3,'2016-07-11 16:31:02',3,'2016-07-11 16:31:02');
/*!40000 ALTER TABLE `application_profile` ENABLE KEYS */;


--
-- Definition of table `application_profile_details`
--

DROP TABLE IF EXISTS `application_profile_details`;
CREATE TABLE `application_profile_details` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `PROFILE_ID` int(10) unsigned NOT NULL,
  `SOFTWARE_TMPLT_ID` int(11) DEFAULT NULL,
  `SERVER_GROUP` int(10) unsigned DEFAULT NULL,
  `existing_machine_tmplt_id` int(10) unsigned DEFAULT NULL,
  `existing_platform_tmplt_id` int(10) unsigned DEFAULT NULL,
  `pltfrm_tmplt_id` int(10) unsigned DEFAULT NULL,
  `machine_tmplt_id` int(10) unsigned DEFAULT NULL,
  `existing_machine_flag` varchar(5) DEFAULT NULL,
  `install_req` varchar(5) DEFAULT NULL,
  `server_name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_application_profile_details_1` (`PROFILE_ID`),
  KEY `Index_5` (`SOFTWARE_TMPLT_ID`),
  KEY `FK_application_profile_details_6` (`existing_platform_tmplt_id`),
  KEY `FK_application_profile_details_7` (`pltfrm_tmplt_id`),
  KEY `FK_application_profile_details_8` (`machine_tmplt_id`),
  KEY `FK_application_profile_details_existing_machine` (`existing_machine_tmplt_id`),
  CONSTRAINT `FK_application_profile_details_1` FOREIGN KEY (`PROFILE_ID`) REFERENCES `application_profile` (`ID`),
  CONSTRAINT `FK_application_profile_details_4` FOREIGN KEY (`SOFTWARE_TMPLT_ID`) REFERENCES `softwareconfig` (`id`),
  CONSTRAINT `FK_application_profile_details_6` FOREIGN KEY (`existing_platform_tmplt_id`) REFERENCES `provisioned_platform` (`id`),
  CONSTRAINT `FK_application_profile_details_7` FOREIGN KEY (`pltfrm_tmplt_id`) REFERENCES `platform_template` (`id`),
  CONSTRAINT `FK_application_profile_details_8` FOREIGN KEY (`machine_tmplt_id`) REFERENCES `machine_template` (`id`),
  CONSTRAINT `FK_application_profile_details_existing_machine` FOREIGN KEY (`existing_machine_tmplt_id`) REFERENCES `provisioned_machine` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `application_profile_details`
--

/*!40000 ALTER TABLE `application_profile_details` DISABLE KEYS */;
INSERT INTO `application_profile_details` (`ID`,`PROFILE_ID`,`SOFTWARE_TMPLT_ID`,`SERVER_GROUP`,`existing_machine_tmplt_id`,`existing_platform_tmplt_id`,`pltfrm_tmplt_id`,`machine_tmplt_id`,`existing_machine_flag`,`install_req`,`server_name`) VALUES 
 (1,1,2,0,NULL,NULL,1,1,'N','Y','Server1'),
 (2,1,1,0,NULL,NULL,1,1,'N','Y','Server1'),
 (3,2,1,0,NULL,NULL,NULL,NULL,'Y','Y','Physical'),
 (4,2,2,0,NULL,NULL,NULL,NULL,'Y','Y','Physical'),
 (5,3,2,0,NULL,NULL,NULL,NULL,'Y','Y','Serv'),
 (6,3,1,0,NULL,NULL,NULL,NULL,'Y','Y','Serv'),
 (7,4,2,0,NULL,NULL,NULL,NULL,'Y','Y','Serv226'),
 (8,4,1,0,NULL,NULL,NULL,NULL,'Y','Y','Serv226'),
 (9,5,2,0,NULL,NULL,2,2,'N','Y','Serv2'),
 (10,5,1,0,NULL,NULL,2,2,'N','Y','Serv2');
/*!40000 ALTER TABLE `application_profile_details` ENABLE KEYS */;


--
-- Definition of table `application_profile_docker`
--

DROP TABLE IF EXISTS `application_profile_docker`;
CREATE TABLE `application_profile_docker` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `REPOSITORY` varchar(45) DEFAULT NULL,
  `TAGS` varchar(45) DEFAULT NULL,
  `PROFILE_ID` int(10) unsigned NOT NULL,
  `IMAGE_ID` varchar(200) DEFAULT NULL,
  `VIRTUAL_SIZE` int(10) NOT NULL,
  `SERVER_IP` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_app_profile_docker_1` (`PROFILE_ID`),
  CONSTRAINT `FK_app_profile_docker_1` FOREIGN KEY (`PROFILE_ID`) REFERENCES `application_profile` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `application_profile_docker`
--

/*!40000 ALTER TABLE `application_profile_docker` DISABLE KEYS */;
/*!40000 ALTER TABLE `application_profile_docker` ENABLE KEYS */;


--
-- Definition of table `application_profile_mapping`
--

DROP TABLE IF EXISTS `application_profile_mapping`;
CREATE TABLE `application_profile_mapping` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `application_id` int(10) unsigned NOT NULL,
  `profile_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_application_profile_mapping_1` (`application_id`),
  KEY `FK_application_profile_mapping_application_profile` (`profile_id`),
  CONSTRAINT `FK_application_profile_mapping_applications` FOREIGN KEY (`application_id`) REFERENCES `applications` (`ID`),
  CONSTRAINT `FK_application_profile_mapping_application_profile` FOREIGN KEY (`profile_id`) REFERENCES `application_profile` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `application_profile_mapping`
--

/*!40000 ALTER TABLE `application_profile_mapping` DISABLE KEYS */;
INSERT INTO `application_profile_mapping` (`id`,`application_id`,`profile_id`) VALUES 
 (1,1,1),
 (2,1,2),
 (3,1,3),
 (4,1,4),
 (5,1,5);
/*!40000 ALTER TABLE `application_profile_mapping` ENABLE KEYS */;


--
-- Definition of table `application_release`
--

DROP TABLE IF EXISTS `application_release`;
CREATE TABLE `application_release` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `APPLICATION_PROFILE_ID` int(10) unsigned NOT NULL,
  `RELEASE_NAME` varchar(45) NOT NULL,
  `APPLICATION_ID` int(10) unsigned NOT NULL,
  `RELEASE_STATUS` int(10) unsigned DEFAULT NULL,
  `DESCRIPTION` varchar(245) DEFAULT NULL,
  `PARENT_RELEASE` int(10) unsigned DEFAULT NULL,
  `RELEASE_TYPE` varchar(45) NOT NULL,
  `REQUEST_ID` int(10) unsigned DEFAULT NULL,
  `releaseTime` datetime DEFAULT NULL,
  `initiatedBy` varchar(45) DEFAULT NULL,
  `Deploy_From_Nexus` varchar(45) DEFAULT NULL,
  `release_plan_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_application_release_1` (`APPLICATION_PROFILE_ID`),
  KEY `FK_application_release_2` (`APPLICATION_ID`),
  KEY `FK_application_release_status` (`RELEASE_STATUS`),
  KEY `FK_application_release_service_request` (`REQUEST_ID`),
  KEY `FK_application_release_plan` (`release_plan_id`),
  CONSTRAINT `FK_application_release_applications` FOREIGN KEY (`APPLICATION_ID`) REFERENCES `applications` (`ID`),
  CONSTRAINT `FK_application_release_application_profile` FOREIGN KEY (`APPLICATION_PROFILE_ID`) REFERENCES `application_profile` (`ID`),
  CONSTRAINT `FK_application_release_plan` FOREIGN KEY (`release_plan_id`) REFERENCES `release_planning` (`id`),
  CONSTRAINT `FK_application_release_service_request` FOREIGN KEY (`REQUEST_ID`) REFERENCES `service_request` (`Request_id`),
  CONSTRAINT `FK_application_release_status` FOREIGN KEY (`RELEASE_STATUS`) REFERENCES `status` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `application_release`
--

/*!40000 ALTER TABLE `application_release` DISABLE KEYS */;
INSERT INTO `application_release` (`ID`,`APPLICATION_PROFILE_ID`,`RELEASE_NAME`,`APPLICATION_ID`,`RELEASE_STATUS`,`DESCRIPTION`,`PARENT_RELEASE`,`RELEASE_TYPE`,`REQUEST_ID`,`releaseTime`,`initiatedBy`,`Deploy_From_Nexus`,`release_plan_id`) VALUES 
 (1,1,'AppJ_Prof1',1,121,'',NULL,'P',NULL,'2016-07-04 16:31:11','alex','Y',1),
 (2,5,'Rel_prof1.2',1,121,'',NULL,'P',NULL,'2016-07-11 17:47:05','alex','Y',1);
/*!40000 ALTER TABLE `application_release` ENABLE KEYS */;


--
-- Definition of table `application_release_build`
--

DROP TABLE IF EXISTS `application_release_build`;
CREATE TABLE `application_release_build` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `application_release_id` int(10) unsigned NOT NULL,
  `build_tool` varchar(45) DEFAULT NULL,
  `job_name` text,
  `REQUEST_ID` int(11) DEFAULT NULL,
  `build_tool_id` int(11) DEFAULT NULL,
  `job_token` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_application_release_build_1` (`application_release_id`),
  CONSTRAINT `FK_application_release_build_application_release` FOREIGN KEY (`application_release_id`) REFERENCES `application_release` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `application_release_build`
--

/*!40000 ALTER TABLE `application_release_build` DISABLE KEYS */;
/*!40000 ALTER TABLE `application_release_build` ENABLE KEYS */;


--
-- Definition of table `application_release_db`
--

DROP TABLE IF EXISTS `application_release_db`;
CREATE TABLE `application_release_db` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `application_release_id` int(10) unsigned DEFAULT NULL,
  `software_config_id` int(11) DEFAULT NULL,
  `database_scripts_path` text,
  `database_scripts` text,
  `ctime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `schema_name` varchar(45) DEFAULT NULL,
  `rollback_script_path` text,
  `rollback_order` varchar(45) DEFAULT NULL,
  `phase_id` int(10) unsigned DEFAULT NULL,
  `REQUEST_ID` int(11) DEFAULT NULL,
  `SERVERGROUP_NUMBER` int(10) unsigned DEFAULT NULL,
  `APPLICATION_PROFILE_DETAILS_ID` int(10) unsigned DEFAULT NULL,
  `data_masking_flag` varchar(10) DEFAULT NULL,
  `masking_tool_id` int(10) unsigned DEFAULT NULL,
  `optim_extract_filename` varchar(45) DEFAULT NULL,
  `optim_insert_request_name` varchar(45) DEFAULT NULL,
  `optim_extract_request_name` varchar(45) DEFAULT NULL,
  `dbusername` varchar(45) DEFAULT NULL,
  `dbpassword` varchar(45) DEFAULT NULL,
  `repository_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_application_release_db_1` (`application_release_id`),
  KEY `FK_application_release_db_2` (`software_config_id`),
  CONSTRAINT `FK_application_release_db_1` FOREIGN KEY (`application_release_id`) REFERENCES `application_release` (`ID`),
  CONSTRAINT `FK_application_release_db_2` FOREIGN KEY (`software_config_id`) REFERENCES `softwareconfig` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `application_release_db`
--

/*!40000 ALTER TABLE `application_release_db` DISABLE KEYS */;
INSERT INTO `application_release_db` (`id`,`application_release_id`,`software_config_id`,`database_scripts_path`,`database_scripts`,`ctime`,`schema_name`,`rollback_script_path`,`rollback_order`,`phase_id`,`REQUEST_ID`,`SERVERGROUP_NUMBER`,`APPLICATION_PROFILE_DETAILS_ID`,`data_masking_flag`,`masking_tool_id`,`optim_extract_filename`,`optim_insert_request_name`,`optim_extract_request_name`,`dbusername`,`dbpassword`,`repository_id`) VALUES 
 (1,1,1,'http://10.130.25.91/svn/my_repo/branches/Release2.0Nex/DBScripts/','TEMS_ORACLE_DB_new.sql','2016-07-04 11:01:12','tems','','',0,NULL,0,2,'N',NULL,NULL,NULL,NULL,'tems','tems',1),
 (2,2,1,'http://10.130.25.91/svn/my_repo/branches/Release2.0Nex/DBScripts/','TEMS_ORACLE_DB_new.sql','2016-07-11 12:17:05','tems','','',0,NULL,0,10,'N',NULL,NULL,NULL,NULL,'tems','tems',1);
/*!40000 ALTER TABLE `application_release_db` ENABLE KEYS */;


--
-- Definition of table `application_release_test`
--

DROP TABLE IF EXISTS `application_release_test`;
CREATE TABLE `application_release_test` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `application_release_id` int(10) unsigned DEFAULT NULL,
  `test_tool` varchar(45) DEFAULT NULL,
  `test_script_path` text,
  `REQUEST_ID` int(11) DEFAULT NULL,
  `test_tool_id` int(10) unsigned DEFAULT NULL,
  `Server_Group` int(11) DEFAULT NULL,
  `Work_space` varchar(45) DEFAULT NULL,
  `Release_plan` varchar(45) DEFAULT NULL,
  `Phase` varchar(45) DEFAULT NULL,
  `Test_cycle` varchar(45) DEFAULT NULL,
  `Test_suite` varchar(45) DEFAULT NULL,
  `junit_jenkins_job` varchar(100) DEFAULT NULL,
  `maven_flag` varchar(1) DEFAULT NULL,
  `testing_phase_id` int(10) unsigned DEFAULT NULL,
  `automation_type` varchar(45) DEFAULT NULL,
  `configuration_id` varchar(45) DEFAULT NULL,
  `configuration_name` varchar(45) DEFAULT NULL,
  `configuration_version` varchar(45) DEFAULT NULL,
  `jmeter_rampup` mediumtext,
  `jmeter_users` mediumtext,
  `jmeter_duration` mediumtext,
  `selenium_url` varchar(100) DEFAULT NULL,
  `repository_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_application_release_test_1` (`application_release_id`),
  KEY `FK_application_release_test_2` (`test_tool_id`),
  CONSTRAINT `FK_application_release_test_1` FOREIGN KEY (`application_release_id`) REFERENCES `application_release` (`ID`),
  CONSTRAINT `FK_application_release_test_2` FOREIGN KEY (`test_tool_id`) REFERENCES `testing_tool` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `application_release_test`
--

/*!40000 ALTER TABLE `application_release_test` DISABLE KEYS */;
INSERT INTO `application_release_test` (`id`,`application_release_id`,`test_tool`,`test_script_path`,`REQUEST_ID`,`test_tool_id`,`Server_Group`,`Work_space`,`Release_plan`,`Phase`,`Test_cycle`,`Test_suite`,`junit_jenkins_job`,`maven_flag`,`testing_phase_id`,`automation_type`,`configuration_id`,`configuration_name`,`configuration_version`,`jmeter_rampup`,`jmeter_users`,`jmeter_duration`,`selenium_url`,`repository_id`) VALUES 
 (1,1,'SELENIUM','http://10.130.25.91/svn/my_repo/branches/Release1.2/Test/Selenium6/',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,'','N',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'http://myip:8080/',1),
 (2,1,'JUNIT',NULL,NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,'JUnit_Test_Job','N',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1),
 (3,2,'JUNIT',NULL,NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,'JUnit_Test_Job','N',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1),
 (4,2,'SELENIUM','http://10.130.25.91/svn/my_repo/branches/Release1.2/Test/Selenium6/',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,'','N',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'http://myip:8080/',1);
/*!40000 ALTER TABLE `application_release_test` ENABLE KEYS */;


--
-- Definition of table `application_system`
--

DROP TABLE IF EXISTS `application_system`;
CREATE TABLE `application_system` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `applicationId` int(10) unsigned DEFAULT NULL,
  `systemId` int(10) unsigned DEFAULT NULL,
  `dependentType` varchar(45) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `FK_application_system_1` (`applicationId`),
  KEY `FK_application_system_2` (`systemId`),
  CONSTRAINT `FK_application_system_1` FOREIGN KEY (`applicationId`) REFERENCES `applications` (`ID`),
  CONSTRAINT `FK_application_system_2` FOREIGN KEY (`systemId`) REFERENCES `applications` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `application_system`
--

/*!40000 ALTER TABLE `application_system` DISABLE KEYS */;
/*!40000 ALTER TABLE `application_system` ENABLE KEYS */;


--
-- Definition of table `applications`
--

DROP TABLE IF EXISTS `applications`;
CREATE TABLE `applications` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `APPLICATION_NAME` varchar(45) NOT NULL,
  `STATUS` int(10) unsigned NOT NULL,
  `CLIENT_ID` int(10) unsigned NOT NULL,
  `APPLICATION_DESC` varchar(1024) DEFAULT NULL,
  `PROJECT_ID` int(10) unsigned NOT NULL,
  `OWNER_ID` int(10) unsigned DEFAULT NULL,
  `User_grp_id` int(10) unsigned DEFAULT NULL,
  `CREATED_BY` int(10) unsigned NOT NULL,
  `MODIFIED_BY` int(10) unsigned DEFAULT NULL,
  `CREATED_DATE` datetime NOT NULL,
  `MODIFIED_DATE` datetime DEFAULT NULL,
  `TYPE` varchar(45) NOT NULL DEFAULT '',
  `CATEGORY` varchar(45) DEFAULT NULL,
  `Manufacturer` varchar(45) NOT NULL DEFAULT '',
  `Vendor` varchar(45) DEFAULT NULL,
  `MOBILE_APP_TYPE` varchar(45) DEFAULT NULL,
  `NATIVE_APP_TYPE` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_applications_client_id` (`CLIENT_ID`),
  KEY `FK_applications_project_id` (`PROJECT_ID`),
  KEY `FK_applications_status` (`STATUS`),
  KEY `FK_usr_grp_id` (`User_grp_id`),
  CONSTRAINT `FK_applications_client` FOREIGN KEY (`CLIENT_ID`) REFERENCES `client` (`CLIENT_ID`),
  CONSTRAINT `FK_applications_projects` FOREIGN KEY (`PROJECT_ID`) REFERENCES `projects` (`ID`),
  CONSTRAINT `FK_applications_status` FOREIGN KEY (`STATUS`) REFERENCES `status` (`ID`),
  CONSTRAINT `FK_usr_grp_id` FOREIGN KEY (`User_grp_id`) REFERENCES `user_groups` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `applications`
--

/*!40000 ALTER TABLE `applications` DISABLE KEYS */;
INSERT INTO `applications` (`ID`,`APPLICATION_NAME`,`STATUS`,`CLIENT_ID`,`APPLICATION_DESC`,`PROJECT_ID`,`OWNER_ID`,`User_grp_id`,`CREATED_BY`,`MODIFIED_BY`,`CREATED_DATE`,`MODIFIED_DATE`,`TYPE`,`CATEGORY`,`Manufacturer`,`Vendor`,`MOBILE_APP_TYPE`,`NATIVE_APP_TYPE`) VALUES 
 (1,'App_J',51,2,'',1,3,1,3,3,'2016-07-04 00:00:00','2016-07-04 00:00:00','Application','Web Application','In-House','',NULL,NULL);
/*!40000 ALTER TABLE `applications` ENABLE KEYS */;


--
-- Definition of table `automation_tool`
--

DROP TABLE IF EXISTS `automation_tool`;
CREATE TABLE `automation_tool` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `automation_tool`
--

/*!40000 ALTER TABLE `automation_tool` DISABLE KEYS */;
INSERT INTO `automation_tool` (`id`,`name`) VALUES 
 (1,'CARA'),
 (2,'UDeploy'),
 (3,'Puppet'),
 (4,'Scripts');
/*!40000 ALTER TABLE `automation_tool` ENABLE KEYS */;


--
-- Definition of table `aws_account`
--

DROP TABLE IF EXISTS `aws_account`;
CREATE TABLE `aws_account` (
  `aws_account_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `aws_account_name` varchar(100) NOT NULL,
  `aws_account_access_key` varchar(100) NOT NULL,
  `aws_account_secret_key` varchar(100) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`aws_account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aws_account`
--

/*!40000 ALTER TABLE `aws_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `aws_account` ENABLE KEYS */;


--
-- Definition of table `base64_data`
--

DROP TABLE IF EXISTS `base64_data`;
CREATE TABLE `base64_data` (
  `c` char(1) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `val` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `base64_data`
--

/*!40000 ALTER TABLE `base64_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `base64_data` ENABLE KEYS */;


--
-- Definition of table `batch`
--

DROP TABLE IF EXISTS `batch`;
CREATE TABLE `batch` (
  `batch_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `batch_name` varchar(45) NOT NULL,
  `batch_running_status` int(10) unsigned NOT NULL,
  `remarks` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`batch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `batch`
--

/*!40000 ALTER TABLE `batch` DISABLE KEYS */;
/*!40000 ALTER TABLE `batch` ENABLE KEYS */;


--
-- Definition of table `build_tool`
--

DROP TABLE IF EXISTS `build_tool`;
CREATE TABLE `build_tool` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `build_tool`
--

/*!40000 ALTER TABLE `build_tool` DISABLE KEYS */;
INSERT INTO `build_tool` (`id`,`name`) VALUES 
 (1,'Jenkins'),
 (2,'TFS'),
 (3,'TeamCity');
/*!40000 ALTER TABLE `build_tool` ENABLE KEYS */;


--
-- Definition of table `build_tool_definition`
--

DROP TABLE IF EXISTS `build_tool_definition`;
CREATE TABLE `build_tool_definition` (
  `definition_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `build_tool_id` int(10) unsigned NOT NULL,
  `build_name` varchar(45) NOT NULL,
  `collection` varchar(45) DEFAULT NULL,
  `project` varchar(45) DEFAULT NULL,
  `jenkins_job_token` varchar(45) DEFAULT NULL,
  `Parameterized_Build` varchar(20) DEFAULT NULL,
  `build_location` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`definition_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `build_tool_definition`
--

/*!40000 ALTER TABLE `build_tool_definition` DISABLE KEYS */;
INSERT INTO `build_tool_definition` (`definition_id`,`build_tool_id`,`build_name`,`collection`,`project`,`jenkins_job_token`,`Parameterized_Build`,`build_location`) VALUES 
 (1,1,'TEMS_Build_Parameterized',NULL,NULL,'','Y',NULL),
 (2,1,'TEMS_Build_Parameterized',NULL,NULL,'','Y',NULL);
/*!40000 ALTER TABLE `build_tool_definition` ENABLE KEYS */;


--
-- Definition of table `ca_activity_process_order`
--

DROP TABLE IF EXISTS `ca_activity_process_order`;
CREATE TABLE `ca_activity_process_order` (
  `Activity_Process_Id` int(11) NOT NULL AUTO_INCREMENT,
  `Nolio_Soft_Process_Map_Id` int(11) NOT NULL,
  `Process_Order` int(11) NOT NULL,
  `Activity_Sftwr_Map_Id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`Activity_Process_Id`),
  KEY `FK_CA_Activity_Process_Order_2` (`Nolio_Soft_Process_Map_Id`),
  CONSTRAINT `FK_CA_Activity_Process_Order_2` FOREIGN KEY (`Nolio_Soft_Process_Map_Id`) REFERENCES `nolio_software_process_mapping` (`Software_process_map_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ca_activity_process_order`
--

/*!40000 ALTER TABLE `ca_activity_process_order` DISABLE KEYS */;
INSERT INTO `ca_activity_process_order` (`Activity_Process_Id`,`Nolio_Soft_Process_Map_Id`,`Process_Order`,`Activity_Sftwr_Map_Id`) VALUES 
 (1,2,0,1),
 (2,3,0,2),
 (3,1,0,3),
 (4,6,0,4),
 (5,8,0,5),
 (6,5,1,5),
 (7,5,0,6),
 (8,7,0,7),
 (9,5,1,7),
 (10,4,0,8);
/*!40000 ALTER TABLE `ca_activity_process_order` ENABLE KEYS */;


--
-- Definition of table `ca_release_activity`
--

DROP TABLE IF EXISTS `ca_release_activity`;
CREATE TABLE `ca_release_activity` (
  `Activity_Id` int(11) NOT NULL AUTO_INCREMENT,
  `Activity_Name` varchar(45) NOT NULL,
  `Application_specific` char(1) DEFAULT NULL,
  PRIMARY KEY (`Activity_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ca_release_activity`
--

/*!40000 ALTER TABLE `ca_release_activity` DISABLE KEYS */;
INSERT INTO `ca_release_activity` (`Activity_Id`,`Activity_Name`,`Application_specific`) VALUES 
 (1,'Installation','N'),
 (2,'Execute Database Scripts','N'),
 (3,'Application Deployment','Y'),
 (4,'JNDI Name','Y'),
 (5,'Server Restart','Y'),
 (6,'Application Undeployment','Y'),
 (7,'Monitoring','N');
/*!40000 ALTER TABLE `ca_release_activity` ENABLE KEYS */;


--
-- Definition of table `ca_release_config`
--

DROP TABLE IF EXISTS `ca_release_config`;
CREATE TABLE `ca_release_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `server_name` varchar(45) NOT NULL,
  `service_endpoint` varchar(245) NOT NULL,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ca_release_config`
--

/*!40000 ALTER TABLE `ca_release_config` DISABLE KEYS */;
INSERT INTO `ca_release_config` (`id`,`server_name`,`service_endpoint`,`username`,`password`) VALUES 
 (1,'10.130.25.137','http://10.130.25.137:8080/datamanagement/ws/OpenAPIService?wsdl','superuser','vrAwF2U3frRYz9WqoSSnUw==');
/*!40000 ALTER TABLE `ca_release_config` ENABLE KEYS */;


--
-- Definition of table `client`
--

DROP TABLE IF EXISTS `client`;
CREATE TABLE `client` (
  `CLIENT_ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `CLIENT_NAME` varchar(45) NOT NULL,
  `STATUS` int(10) unsigned NOT NULL,
  `REMARK` varchar(200) DEFAULT NULL,
  `CREATED_BY` int(10) unsigned DEFAULT NULL,
  `CREATED_DATE` datetime DEFAULT NULL,
  `MODIFIED_BY` int(10) unsigned DEFAULT NULL,
  `MODIFIED_DATE` datetime DEFAULT NULL,
  PRIMARY KEY (`CLIENT_ID`),
  KEY `FK_client_status` (`STATUS`),
  CONSTRAINT `FK_client_status` FOREIGN KEY (`STATUS`) REFERENCES `status` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `client`
--

/*!40000 ALTER TABLE `client` DISABLE KEYS */;
INSERT INTO `client` (`CLIENT_ID`,`CLIENT_NAME`,`STATUS`,`REMARK`,`CREATED_BY`,`CREATED_DATE`,`MODIFIED_BY`,`MODIFIED_DATE`) VALUES 
 (0,'Operations_Group',41,'operation group',1,'2014-08-20 00:00:00',213,'2015-02-01 00:00:00'),
 (2,'Application_Development',41,'',2,'2016-07-04 13:40:13',2,'2016-07-04 00:00:00');
/*!40000 ALTER TABLE `client` ENABLE KEYS */;


--
-- Definition of table `data_masking_tool_config`
--

DROP TABLE IF EXISTS `data_masking_tool_config`;
CREATE TABLE `data_masking_tool_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bu_id` int(10) unsigned NOT NULL,
  `project_id` int(10) unsigned NOT NULL,
  `application_id` int(10) unsigned NOT NULL,
  `data_masking_tool` varchar(45) NOT NULL,
  `optim_machine_ip` varchar(45) DEFAULT NULL,
  `optim_install_location` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data_masking_tool_config`
--

/*!40000 ALTER TABLE `data_masking_tool_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `data_masking_tool_config` ENABLE KEYS */;


--
-- Definition of table `data_masking_tools`
--

DROP TABLE IF EXISTS `data_masking_tools`;
CREATE TABLE `data_masking_tools` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tool_name` varchar(45) NOT NULL,
  `description` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data_masking_tools`
--

/*!40000 ALTER TABLE `data_masking_tools` DISABLE KEYS */;
INSERT INTO `data_masking_tools` (`id`,`tool_name`,`description`) VALUES 
 (1,'Mastercraft TDEM/TEM',NULL),
 (2,'IBM Optim',NULL);
/*!40000 ALTER TABLE `data_masking_tools` ENABLE KEYS */;


--
-- Definition of table `datastore_details`
--

DROP TABLE IF EXISTS `datastore_details`;
CREATE TABLE `datastore_details` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DataStoreName` varchar(45) NOT NULL,
  `DataCentreId` int(10) unsigned NOT NULL,
  `TotalCapacity` varchar(45) DEFAULT NULL,
  `UsedSpace` varchar(45) DEFAULT NULL,
  `FreeSpace` varchar(45) DEFAULT NULL,
  `Status` varchar(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_datastore_details_1` (`DataCentreId`),
  CONSTRAINT `FK_datastore_details_1` FOREIGN KEY (`DataCentreId`) REFERENCES `vsphere_details` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `datastore_details`
--

/*!40000 ALTER TABLE `datastore_details` DISABLE KEYS */;
INSERT INTO `datastore_details` (`id`,`DataStoreName`,`DataCentreId`,`TotalCapacity`,`UsedSpace`,`FreeSpace`,`Status`) VALUES 
 (1,'ASU NICHE Server',1,NULL,NULL,NULL,'ACT'),
 (2,'ASU NICHE',1,NULL,NULL,NULL,'ACT'),
 (3,'AT-DWH-BO DS',1,NULL,NULL,NULL,'ACT'),
 (4,'AUTOMATION DS',1,NULL,NULL,NULL,'ACT'),
 (5,'CLOUDERA DS',1,NULL,NULL,NULL,'ACT'),
 (6,'FC DATASTORE 2',1,NULL,NULL,NULL,'ACT'),
 (7,'FC DATASTORE 3',1,NULL,NULL,NULL,'ACT'),
 (8,'FC DATASTORE1',1,NULL,NULL,NULL,'ACT'),
 (9,'NICHE DS',1,NULL,NULL,NULL,'ACT'),
 (10,'NOLIO DS',1,NULL,NULL,NULL,'ACT'),
 (11,'OPENSTACK DS',1,NULL,NULL,NULL,'ACT'),
 (12,'PERFORMANCE DS',1,NULL,NULL,NULL,'ACT'),
 (13,'RELEASEMGMT DS',1,NULL,NULL,NULL,'ACT'),
 (14,'SAP BACKUP DS',1,NULL,NULL,NULL,'ACT'),
 (15,'SAP DS',1,NULL,NULL,NULL,'ACT'),
 (16,'SAPIDES DS',1,NULL,NULL,NULL,'ACT'),
 (17,'TDM DS',1,NULL,NULL,NULL,'ACT'),
 (18,'TDMASU DS',1,NULL,NULL,NULL,'ACT'),
 (19,'TEMS DS',1,NULL,NULL,NULL,'ACT'),
 (20,'TEMS-2 DS',1,NULL,NULL,NULL,'ACT'),
 (21,'TEMS-3 DS',1,NULL,NULL,NULL,'ACT'),
 (22,'TEMS-4 DS',1,NULL,NULL,NULL,'ACT');
INSERT INTO `datastore_details` (`id`,`DataStoreName`,`DataCentreId`,`TotalCapacity`,`UsedSpace`,`FreeSpace`,`Status`) VALUES 
 (23,'TMTP DS',1,NULL,NULL,NULL,'ACT'),
 (24,'UDEPLOY DS',1,NULL,NULL,NULL,'ACT'),
 (25,'datastore1 (1)',1,NULL,NULL,NULL,'ACT'),
 (26,'datastore1 (2)',1,NULL,NULL,NULL,'ACT'),
 (27,'datastore1 (3)',1,NULL,NULL,NULL,'ACT'),
 (28,'datastore1',1,NULL,NULL,NULL,'ACT');
/*!40000 ALTER TABLE `datastore_details` ENABLE KEYS */;


--
-- Definition of table `delegate_access`
--

DROP TABLE IF EXISTS `delegate_access`;
CREATE TABLE `delegate_access` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(10) NOT NULL,
  `delegatedUserId` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `delegate_access`
--

/*!40000 ALTER TABLE `delegate_access` DISABLE KEYS */;
/*!40000 ALTER TABLE `delegate_access` ENABLE KEYS */;


--
-- Definition of table `dns_server_details`
--

DROP TABLE IF EXISTS `dns_server_details`;
CREATE TABLE `dns_server_details` (
  `Id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `server` varchar(45) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dns_server_details`
--

/*!40000 ALTER TABLE `dns_server_details` DISABLE KEYS */;
INSERT INTO `dns_server_details` (`Id`,`server`) VALUES 
 (1,'138.120.73.66');
/*!40000 ALTER TABLE `dns_server_details` ENABLE KEYS */;


--
-- Definition of table `docker_server_config`
--

DROP TABLE IF EXISTS `docker_server_config`;
CREATE TABLE `docker_server_config` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `server_ip` varchar(45) NOT NULL,
  `port` int(10) NOT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `docker_server_config`
--

/*!40000 ALTER TABLE `docker_server_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `docker_server_config` ENABLE KEYS */;


--
-- Definition of table `docker_template`
--

DROP TABLE IF EXISTS `docker_template`;
CREATE TABLE `docker_template` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `template_name` varchar(45) NOT NULL,
  `template_data` longblob NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `docker_template`
--

/*!40000 ALTER TABLE `docker_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `docker_template` ENABLE KEYS */;


--
-- Definition of table `entity`
--

DROP TABLE IF EXISTS `entity`;
CREATE TABLE `entity` (
  `ENTITY_ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `NAME` varchar(250) NOT NULL,
  PRIMARY KEY (`ENTITY_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `entity`
--

/*!40000 ALTER TABLE `entity` DISABLE KEYS */;
INSERT INTO `entity` (`ENTITY_ID`,`NAME`) VALUES 
 (1,'User'),
 (2,'Environment'),
 (3,'Project'),
 (4,'Business Unit'),
 (5,'Application'),
 (6,'Software'),
 (7,'Hardware'),
 (8,'Reservation'),
 (9,'Platform'),
 (10,'ApplicationProfile'),
 (11,'FreeSpace'),
 (12,'ApplicationRelease'),
 (13,'Services'),
 (14,'Service Request'),
 (15,'MultiplePofile'),
 (16,'Template'),
 (17,'Share'),
 (18,'ReleaseType'),
 (19,'Role'),
 (20,'Platform Template'),
 (21,'Machine Template'),
 (22,'Provisioned Machine'),
 (23,'Docker');
/*!40000 ALTER TABLE `entity` ENABLE KEYS */;


--
-- Definition of table `env_sftwr_attributes`
--

DROP TABLE IF EXISTS `env_sftwr_attributes`;
CREATE TABLE `env_sftwr_attributes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `envId` int(10) unsigned NOT NULL,
  `softwareConfigId` int(10) unsigned NOT NULL,
  `attributeName` varchar(45) NOT NULL,
  `attributeValue` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `env_sftwr_attributes`
--

/*!40000 ALTER TABLE `env_sftwr_attributes` DISABLE KEYS */;
/*!40000 ALTER TABLE `env_sftwr_attributes` ENABLE KEYS */;


--
-- Definition of table `env_sub_mapping`
--

DROP TABLE IF EXISTS `env_sub_mapping`;
CREATE TABLE `env_sub_mapping` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `environmentId` int(10) unsigned DEFAULT NULL,
  `subEnvironmentId` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_env_sub_mapping_1` (`environmentId`),
  KEY `FK_env_sub_mapping_2` (`subEnvironmentId`),
  CONSTRAINT `FK_env_sub_mapping_1` FOREIGN KEY (`environmentId`) REFERENCES `environments` (`ID`),
  CONSTRAINT `FK_env_sub_mapping_2` FOREIGN KEY (`subEnvironmentId`) REFERENCES `environments` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `env_sub_mapping`
--

/*!40000 ALTER TABLE `env_sub_mapping` DISABLE KEYS */;
/*!40000 ALTER TABLE `env_sub_mapping` ENABLE KEYS */;


--
-- Definition of table `env_type`
--

DROP TABLE IF EXISTS `env_type`;
CREATE TABLE `env_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_value` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `env_type`
--

/*!40000 ALTER TABLE `env_type` DISABLE KEYS */;
INSERT INTO `env_type` (`id`,`type_value`) VALUES 
 (1,'Development'),
 (2,'Testing'),
 (3,'Staging'),
 (4,'Production');
/*!40000 ALTER TABLE `env_type` ENABLE KEYS */;


--
-- Definition of table `environment_application`
--

DROP TABLE IF EXISTS `environment_application`;
CREATE TABLE `environment_application` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `environment_id` int(10) unsigned NOT NULL,
  `application_id` int(10) unsigned NOT NULL,
  `application_release_id` int(10) unsigned DEFAULT NULL,
  `buildTime` varchar(45) DEFAULT NULL,
  `testing_phase_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_environment_application_1` (`application_release_id`),
  KEY `FK_environment_application_2` (`environment_id`),
  KEY `FK_environment_application_3` (`testing_phase_id`),
  CONSTRAINT `FK_environment_application_1` FOREIGN KEY (`application_release_id`) REFERENCES `application_release` (`ID`),
  CONSTRAINT `FK_environment_application_2` FOREIGN KEY (`environment_id`) REFERENCES `environments` (`ID`),
  CONSTRAINT `FK_environment_application_3` FOREIGN KEY (`testing_phase_id`) REFERENCES `testing_phase` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `environment_application`
--

/*!40000 ALTER TABLE `environment_application` DISABLE KEYS */;
INSERT INTO `environment_application` (`id`,`environment_id`,`application_id`,`application_release_id`,`buildTime`,`testing_phase_id`) VALUES 
 (1,1,1,NULL,NULL,NULL),
 (2,2,1,NULL,NULL,NULL),
 (3,3,1,NULL,NULL,NULL),
 (4,4,1,NULL,NULL,1),
 (5,5,1,NULL,NULL,1),
 (6,6,1,NULL,NULL,NULL),
 (7,7,1,NULL,NULL,3),
 (8,8,1,1,NULL,1),
 (9,9,1,NULL,NULL,NULL),
 (10,10,1,NULL,NULL,NULL),
 (11,11,1,NULL,NULL,3),
 (12,12,1,NULL,NULL,NULL),
 (13,13,1,NULL,NULL,3),
 (14,14,1,NULL,NULL,3);
/*!40000 ALTER TABLE `environment_application` ENABLE KEYS */;


--
-- Definition of table `environment_details`
--

DROP TABLE IF EXISTS `environment_details`;
CREATE TABLE `environment_details` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `SOFTWARE_ID` int(11) DEFAULT NULL,
  `CREATED_BY` int(10) unsigned DEFAULT NULL,
  `CREATED_DATE` datetime DEFAULT NULL,
  `MODIFIED_BY` int(10) unsigned DEFAULT NULL,
  `MODIFIED_DATE` datetime DEFAULT NULL,
  `ENVIRONMENT_ID` int(10) unsigned DEFAULT NULL,
  `SERVER_GROUP` int(10) unsigned DEFAULT NULL,
  `provisioned_machine_tmplt_id` int(10) unsigned DEFAULT NULL,
  `provisioned_platform_tmplt_id` int(10) unsigned DEFAULT NULL,
  `install_req` varchar(45) DEFAULT NULL,
  `install_status` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `Index_3` (`SOFTWARE_ID`),
  KEY `FK_environment_details_environments` (`ENVIRONMENT_ID`),
  KEY `FK_environment_details_6` (`provisioned_machine_tmplt_id`),
  KEY `FK_environment_details_7` (`provisioned_platform_tmplt_id`),
  CONSTRAINT `FK_environment_details_1` FOREIGN KEY (`ENVIRONMENT_ID`) REFERENCES `environments` (`ID`),
  CONSTRAINT `FK_environment_details_4` FOREIGN KEY (`SOFTWARE_ID`) REFERENCES `softwareconfig` (`id`),
  CONSTRAINT `FK_environment_details_6` FOREIGN KEY (`provisioned_machine_tmplt_id`) REFERENCES `provisioned_machine` (`id`),
  CONSTRAINT `FK_environment_details_7` FOREIGN KEY (`provisioned_platform_tmplt_id`) REFERENCES `provisioned_platform` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1 ROW_FORMAT=FIXED;

--
-- Dumping data for table `environment_details`
--

/*!40000 ALTER TABLE `environment_details` DISABLE KEYS */;
INSERT INTO `environment_details` (`ID`,`SOFTWARE_ID`,`CREATED_BY`,`CREATED_DATE`,`MODIFIED_BY`,`MODIFIED_DATE`,`ENVIRONMENT_ID`,`SERVER_GROUP`,`provisioned_machine_tmplt_id`,`provisioned_platform_tmplt_id`,`install_req`,`install_status`) VALUES 
 (1,1,NULL,NULL,NULL,NULL,1,0,1,1,'Y','N'),
 (2,2,NULL,NULL,NULL,NULL,1,0,1,1,'Y','N'),
 (3,1,NULL,NULL,NULL,NULL,2,0,2,2,'Y','N'),
 (4,2,NULL,NULL,NULL,NULL,2,0,2,2,'Y','N'),
 (5,2,NULL,NULL,NULL,NULL,3,0,3,3,'Y','N'),
 (6,1,NULL,NULL,NULL,NULL,3,0,3,3,'Y','N'),
 (7,1,NULL,NULL,NULL,NULL,4,0,4,4,'Y','N'),
 (8,2,NULL,NULL,NULL,NULL,4,0,4,4,'Y','N'),
 (9,1,NULL,NULL,NULL,NULL,5,0,5,5,'Y','N'),
 (10,2,NULL,NULL,NULL,NULL,5,0,5,5,'Y','N'),
 (11,1,NULL,NULL,NULL,NULL,6,0,6,6,'Y','N'),
 (12,2,NULL,NULL,NULL,NULL,6,0,6,6,'Y','N'),
 (13,1,NULL,NULL,NULL,NULL,7,0,7,7,'Y','N'),
 (14,2,NULL,NULL,NULL,NULL,7,0,7,7,'Y','N'),
 (15,1,NULL,NULL,NULL,NULL,8,0,8,8,'Y','Y'),
 (16,2,NULL,NULL,NULL,NULL,8,0,8,8,'Y','Y'),
 (17,2,NULL,NULL,NULL,NULL,9,0,9,9,'Y','Y'),
 (18,1,NULL,NULL,NULL,NULL,9,0,9,9,'Y','N');
INSERT INTO `environment_details` (`ID`,`SOFTWARE_ID`,`CREATED_BY`,`CREATED_DATE`,`MODIFIED_BY`,`MODIFIED_DATE`,`ENVIRONMENT_ID`,`SERVER_GROUP`,`provisioned_machine_tmplt_id`,`provisioned_platform_tmplt_id`,`install_req`,`install_status`) VALUES 
 (19,1,NULL,NULL,NULL,NULL,10,0,9,9,'Y','N'),
 (20,2,NULL,NULL,NULL,NULL,10,0,9,9,'N','N'),
 (21,1,NULL,NULL,NULL,NULL,11,0,10,10,'Y','N'),
 (22,2,NULL,NULL,NULL,NULL,11,0,10,10,'Y','N'),
 (23,2,NULL,NULL,NULL,NULL,12,0,9,9,'N','N'),
 (24,1,NULL,NULL,NULL,NULL,12,0,9,9,'N','N'),
 (25,2,NULL,NULL,NULL,NULL,13,0,11,11,'Y','N'),
 (26,1,NULL,NULL,NULL,NULL,13,0,11,11,'Y','N'),
 (27,2,NULL,NULL,NULL,NULL,14,0,12,12,'Y','Y'),
 (28,1,NULL,NULL,NULL,NULL,14,0,12,12,'Y','Y');
/*!40000 ALTER TABLE `environment_details` ENABLE KEYS */;


--
-- Definition of table `environment_details_rejected`
--

DROP TABLE IF EXISTS `environment_details_rejected`;
CREATE TABLE `environment_details_rejected` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `HARDWARE_ID` int(10) unsigned NOT NULL,
  `SOFTWARE_ID` int(11) NOT NULL,
  `CREATED_BY` int(10) unsigned DEFAULT NULL,
  `CREATED_DATE` datetime DEFAULT NULL,
  `MODIFIED_BY` int(10) unsigned DEFAULT NULL,
  `MODIFIED_DATE` datetime DEFAULT NULL,
  `ENVIRONMENT_ID` int(10) unsigned NOT NULL,
  `PLATFORM_ID` int(10) unsigned NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_ENVIRONMENT_DETAILS_2` (`HARDWARE_ID`),
  KEY `Index_3` (`SOFTWARE_ID`),
  KEY `FK_environment_details_environments` (`ENVIRONMENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `environment_details_rejected`
--

/*!40000 ALTER TABLE `environment_details_rejected` DISABLE KEYS */;
/*!40000 ALTER TABLE `environment_details_rejected` ENABLE KEYS */;


--
-- Definition of table `environment_docker_details`
--

DROP TABLE IF EXISTS `environment_docker_details`;
CREATE TABLE `environment_docker_details` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `ENVIRONMENT_ID` int(10) unsigned NOT NULL,
  `PROFILE_ID` int(10) unsigned NOT NULL,
  `CONTAINER_IP` varchar(45) DEFAULT NULL,
  `CONTAINER_ID` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_environment_docker_dtls_1` (`ENVIRONMENT_ID`),
  KEY `FK_environment_docker_dtls_2` (`PROFILE_ID`),
  CONSTRAINT `FK_environment_docker_dtls_1` FOREIGN KEY (`ENVIRONMENT_ID`) REFERENCES `environments` (`ID`),
  CONSTRAINT `FK_environment_docker_dtls_2` FOREIGN KEY (`PROFILE_ID`) REFERENCES `application_profile` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `environment_docker_details`
--

/*!40000 ALTER TABLE `environment_docker_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `environment_docker_details` ENABLE KEYS */;


--
-- Definition of table `environments`
--

DROP TABLE IF EXISTS `environments`;
CREATE TABLE `environments` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `CREATED_BY` int(10) unsigned NOT NULL,
  `CREATED_DATE` datetime NOT NULL,
  `MODIFIED_BY` int(10) unsigned DEFAULT NULL,
  `MODIFIED_DATE` datetime DEFAULT NULL,
  `ENVIRONMENT_NAME` varchar(45) NOT NULL,
  `STATUS` int(10) unsigned DEFAULT NULL,
  `PHASE` int(10) unsigned DEFAULT NULL,
  `PROFILE_ID` int(10) unsigned DEFAULT NULL,
  `ENV_TYPE` varchar(45) DEFAULT NULL,
  `PARENT_ENV` int(10) unsigned DEFAULT NULL,
  `MONTRG_REQ` varchar(5) DEFAULT NULL,
  `reservation_check` varchar(5) DEFAULT NULL,
  `TAGGED_PROJECTS` varchar(45) DEFAULT NULL,
  `env_type_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `Index_2` (`ENVIRONMENT_NAME`),
  KEY `FK_environments_testing_phase` (`PHASE`),
  KEY `FK_environments_2` (`PROFILE_ID`),
  KEY `FK_environments_env_type_idx` (`env_type_id`),
  CONSTRAINT `FK_environments_2` FOREIGN KEY (`PROFILE_ID`) REFERENCES `application_profile` (`ID`),
  CONSTRAINT `FK_environments_env_type` FOREIGN KEY (`env_type_id`) REFERENCES `env_type` (`id`),
  CONSTRAINT `FK_environments_testing_phase` FOREIGN KEY (`PHASE`) REFERENCES `testing_phase` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `environments`
--

/*!40000 ALTER TABLE `environments` DISABLE KEYS */;
INSERT INTO `environments` (`ID`,`CREATED_BY`,`CREATED_DATE`,`MODIFIED_BY`,`MODIFIED_DATE`,`ENVIRONMENT_NAME`,`STATUS`,`PHASE`,`PROFILE_ID`,`ENV_TYPE`,`PARENT_ENV`,`MONTRG_REQ`,`reservation_check`,`TAGGED_PROJECTS`,`env_type_id`) VALUES 
 (1,3,'2016-07-04 00:00:00',3,'2016-07-04 00:00:00','Unit_Env1',23,NULL,1,NULL,NULL,'N','N',NULL,2),
 (2,3,'2016-07-04 00:00:00',NULL,NULL,'Unit_Env2',21,NULL,1,NULL,NULL,'N','N',NULL,2),
 (3,3,'2016-07-04 00:00:00',NULL,NULL,'ST_Env1',23,NULL,2,NULL,NULL,'N','N',NULL,2),
 (4,3,'2016-07-04 00:00:00',3,'2016-07-07 00:00:00','ST_Env2',21,NULL,1,NULL,NULL,'N','N',NULL,1),
 (5,3,'2016-07-05 00:00:00',NULL,NULL,'SIT_Env1',21,NULL,1,NULL,NULL,'Y','N',NULL,1),
 (6,3,'2016-07-05 00:00:00',NULL,NULL,'SIT_Env2',21,NULL,3,NULL,NULL,'Y','N',NULL,2),
 (7,3,'2016-07-07 00:00:00',NULL,NULL,'UAT_Env1',21,NULL,1,NULL,NULL,'N','N',NULL,2),
 (8,3,'2016-07-07 00:00:00',3,'2016-07-07 00:00:00','UAT_Env2',21,NULL,1,NULL,NULL,'Y','N',NULL,2),
 (9,3,'2016-07-11 00:00:00',3,'2016-07-11 00:00:00','Testing1',23,NULL,4,NULL,NULL,'Y','N',NULL,3),
 (10,3,'2016-07-11 00:00:00',3,'2016-07-11 00:00:00','Testing2',21,NULL,4,NULL,NULL,'N','N',NULL,3);
INSERT INTO `environments` (`ID`,`CREATED_BY`,`CREATED_DATE`,`MODIFIED_BY`,`MODIFIED_DATE`,`ENVIRONMENT_NAME`,`STATUS`,`PHASE`,`PROFILE_ID`,`ENV_TYPE`,`PARENT_ENV`,`MONTRG_REQ`,`reservation_check`,`TAGGED_PROJECTS`,`env_type_id`) VALUES 
 (11,3,'2016-07-11 00:00:00',NULL,NULL,'TestEnvironment',22,NULL,5,NULL,NULL,'N','N',NULL,2),
 (12,3,'2016-07-12 00:00:00',NULL,NULL,'asdfghjkl',22,NULL,4,NULL,NULL,'N','N',NULL,3),
 (13,3,'2016-07-13 00:00:00',NULL,NULL,'Environment12',22,NULL,5,NULL,NULL,'N','N',NULL,2),
 (14,3,'2016-07-13 00:00:00',3,'2016-07-16 00:00:00','Environment13',21,NULL,5,NULL,NULL,'I','N',NULL,2);
/*!40000 ALTER TABLE `environments` ENABLE KEYS */;


--
-- Definition of table `global_parameters`
--

DROP TABLE IF EXISTS `global_parameters`;
CREATE TABLE `global_parameters` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `PARAM_NAME` varchar(45) NOT NULL,
  `PARAM_VALUE` varchar(100) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `global_parameters`
--

/*!40000 ALTER TABLE `global_parameters` DISABLE KEYS */;
INSERT INTO `global_parameters` (`ID`,`PARAM_NAME`,`PARAM_VALUE`) VALUES 
 (1,'DB_REQUEST_FILE_UPLOAD','Y'),
 (2,'RELEASE_NOTE_FILE_UPLOAD_LOCATION','C:\\Netra_Temp'),
 (3,'JMETER_SCRIPTS_CHECKOUT_LOCATION','C:\\Netra_Temp\\JMeter'),
 (4,'JMETER_RESULT_LOCATION','C:\\Netra_Temp\\JMeter'),
 (5,'JENKINS_LOG_LOCATION','C:\\Netra\\JenkinsLog'),
 (6,'SHARED_RESERVATION_COUNT','2'),
 (7,'SELENIUM_SCRIPTS_CHECKOUT_LOCATION','C:\\Netra_Temp\\Selenium'),
 (8,'Bulk_Upload_Software','C:\\Software.csv'),
 (9,'Bulk_Upload_Hardware','C:\\Hardware.csv'),
 (10,'CONFIG_FILE_LOCATION','C:\\Config_Files'),
 (11,'SELENIUM_HOME','C:/selenium-server-standalone-2.41.0.jar'),
 (12,'JMETER_HOME','C:\\apacheJmeter'),
 (13,'SELENIUM_PORT_NO','4444'),
 (14,'SONAR_CODECHECKOUT_LOCATION','C:'),
 (15,'SONAR_PDFGENERATION_LOCATION','C:\\folder'),
 (16,'NOLIO_NETRA_SERVER_IP','10.130.25.137'),
 (17,'SONAR_URL','http://10.130.25.225:8082'),
 (18,'SONAR_USERNAME','admin'),
 (19,'SONAR_PASSWORD','admin'),
 (20,'OPERATING_SYSTEM','Windows'),
 (21,'TECHNOLOGY_STACK','Java');
INSERT INTO `global_parameters` (`ID`,`PARAM_NAME`,`PARAM_VALUE`) VALUES 
 (22,'QTP_SCRIPTS_CHECKOUT_LOCATION','C:\\Netra_Temp\\QTP'),
 (23,'FILE_SOURCE_LOCATION','SVN,Local Drive'),
 (24,'VBS_TEMPLATE_LOCATION','C:\\VBS_template'),
 (25,'SVN_CHECKOUT_LOCATION','C:\\\\Config_Files\\\\Desktop\\\\ConfigurationFiles'),
 (26,'HARDWARE_TEMPLATE','C:\\HardwareTemplate.txt'),
 (27,'START_SONAR_LOCATION','C:/Sonar/sonarqube-5.4/bin/windows-x86-64/StartSonar.bat'),
 (28,'START_SONAR_RUNNER_LOCATION','C:/Sonar/sonar-scanner-2.6/bin/sonar-runner.bat'),
 (29,'PSTOOLS_LOCATION','C:\\PsTools\\PsExec.exe'),
 (30,'NETRA_SERVER_USERNAME','administrator'),
 (31,'NETRA_SERVER_PASSWORD','tcs#1234'),
 (32,'TFS_NATIVE_FILE_PATH','C:\\TFS\\native'),
 (33,'VMWARE_BAREMETAL_CREATION_COUNTER','5'),
 (34,'VMWARE_BAREMETAL_CREATION_WAIT_MILLISECONDS','500000'),
 (35,'VMWARE_BAREMETAL_FILE_LOCATION','/home/netra/BareMetal'),
 (36,'VMWARE_BAREMETAL_FILENAME','changeHostname.sh'),
 (37,'VMWARE_BAREMETAL_SH_FILENAME_VM_CREATION','createVm.sh'),
 (38,'VMWARE_BAREMETAL_KICKSTART_FOLDER_NAME','Custom-Kickstart');
INSERT INTO `global_parameters` (`ID`,`PARAM_NAME`,`PARAM_VALUE`) VALUES 
 (39,'SERVICE_LOG_LOCATION','C:\\Netra_Temp1'),
 (40,'Sonar_Agent_URL','10.130.25.225'),
 (41,'USERGUIDE_PATH','C:\\NETRA_USERGUIDE\\User Manual for NETRA'),
 (42,'Docker_Remote_TARFileLocation','/root/tarFiles'),
 (43,'Docker_Local_TARFileLocation','D:\\TarDockerFiles\\'),
 (44,'DOCKER_TEMPLATE_FILE_LOCATION','C:/TemplateDocker'),
 (45,'Docker_Container_Subnet','/24@10.130.25.1'),
 (46,'JASPER_LOCATION','C:\\Netra_Jasper'),
 (47,'PUPPET_AUTOMATE_SCRIPT','C:\\\\puppetlinuxautomation\\\\automatebackup.sh'),
 (48,'PUPPET_REPO_SCRIPT','C:\\\\puppetlinuxautomation\\\\repopup.repo'),
 (49,'CHECK_PUPPET_AGENT_INSTALLATION_FOLDER','C:\\\\puppetlinuxautomation\\\\'),
 (50,'CHECK_PUPPET_AGENT_INSTALLATION_FILE','checkPuppetInstallation.sh'),
 (51,'PUPPET_MANIFEST_LOCATION','/etc/puppet/manifests/testnode/'),
 (52,'PUPPET_TARGET_LOCATION_TO_MOVE','/etc/puppet/manifests/env_completed/'),
 (53,'VMWARE_KICKSTART_CONFIGURATION_FILE_NAME','ks.cfg'),
 (54,'VMWARE_KICKSTART_CONFIGURATION_FILE_OUT_LOC','/var/www/html/centos6.4/isolinux/');
INSERT INTO `global_parameters` (`ID`,`PARAM_NAME`,`PARAM_VALUE`) VALUES 
 (55,'VMWARE_BAREMETAL_EDIT_SH_COMMAND','awk \'{ sub(\\\"r$\", \"\"); print }'),
 (56,'VMWARE_BAREMETAL_SH_FILENAME_VM_DELETION','Delete.sh'),
 (57,'VMWARE_BAREMETAL_KICKSTART_SH_FILENAME','Kickstarter.sh'),
 (58,'SELENIUM_POI_JAR_LOCATION','C:/poi-3.13-20150929.jar'),
 (59,'SELENIUM_COMPILE_BATCH','C:/compileJava.bat'),
 (60,'SELENIUM_RUN_BATCH','C:/runClass.bat'),
 (61,'Puppet_Manifest_Log_location','/home/netra/PuppetLog/'),
 (62,'DAYS_TO_MAIL_BEFORE_ENV_EXPIRATION','2'),
 (63,'Jenkins_Docker_Container','eb92a587ab8b'),
 (64,'PERFECTO_SCRIPT_PATH','C:');
/*!40000 ALTER TABLE `global_parameters` ENABLE KEYS */;


--
-- Definition of table `hardwares`
--

DROP TABLE IF EXISTS `hardwares`;
CREATE TABLE `hardwares` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `NAME` varchar(45) NOT NULL,
  `MACHINE_ID` int(10) unsigned DEFAULT NULL,
  `LOCATION` varchar(45) DEFAULT NULL,
  `PROCESSOR` varchar(45) DEFAULT NULL,
  `STORAGE` varchar(45) DEFAULT NULL,
  `IP` varchar(45) DEFAULT NULL,
  `SYSTEM_TYPE` varchar(45) DEFAULT NULL,
  `CREATED_BY` int(10) unsigned DEFAULT NULL,
  `CREATED_DATE` datetime DEFAULT NULL,
  `MODIFIED_BY` int(10) unsigned DEFAULT NULL,
  `MODIFIED_DATE` datetime DEFAULT NULL,
  `STATUS` varchar(2) DEFAULT NULL,
  `COST` double DEFAULT '0',
  `REMARKS` varchar(300) DEFAULT NULL,
  `CPU_SPEED` varchar(45) DEFAULT NULL,
  `SWAP_MEMORY` varchar(45) DEFAULT NULL,
  `STORAGE_TIER` varchar(45) DEFAULT NULL,
  `MEMORY` varchar(45) DEFAULT NULL,
  `IMAGE_PATH` varchar(3000) DEFAULT NULL,
  `PLATFORM_NAME` varchar(45) DEFAULT NULL,
  `TEMPLATE_FLAG` int(10) unsigned DEFAULT NULL,
  `shared` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `Index_2` (`NAME`),
  KEY `FK_hardwares_machine` (`MACHINE_ID`),
  CONSTRAINT `FK_hardwares_machine` FOREIGN KEY (`MACHINE_ID`) REFERENCES `hardwares` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hardwares`
--

/*!40000 ALTER TABLE `hardwares` DISABLE KEYS */;
/*!40000 ALTER TABLE `hardwares` ENABLE KEYS */;


--
-- Definition of table `jira_config`
--

DROP TABLE IF EXISTS `jira_config`;
CREATE TABLE `jira_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tool_name` varchar(45) NOT NULL,
  `tool_url` varchar(245) NOT NULL,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `bu_id` int(10) unsigned NOT NULL,
  `project_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jira_config`
--

/*!40000 ALTER TABLE `jira_config` DISABLE KEYS */;
INSERT INTO `jira_config` (`id`,`tool_name`,`tool_url`,`username`,`password`,`bu_id`,`project_id`) VALUES 
 (1,'Jira','http://10.130.25.39:8080','durgag','SO/W5S/1+R6hnIhdyhMbiA==',2,1);
/*!40000 ALTER TABLE `jira_config` ENABLE KEYS */;


--
-- Definition of table `jira_mapping`
--

DROP TABLE IF EXISTS `jira_mapping`;
CREATE TABLE `jira_mapping` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bu` int(11) NOT NULL,
  `project_id` int(11) DEFAULT NULL,
  `tracking_tool_id` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `tool_unique_combo` (`bu`,`project_id`),
  KEY `FK_jira_mapping_tool` (`tracking_tool_id`),
  CONSTRAINT `FK_jira_mapping_tool` FOREIGN KEY (`tracking_tool_id`) REFERENCES `jira_config` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jira_mapping`
--

/*!40000 ALTER TABLE `jira_mapping` DISABLE KEYS */;
/*!40000 ALTER TABLE `jira_mapping` ENABLE KEYS */;


--
-- Definition of table `ldap_config`
--

DROP TABLE IF EXISTS `ldap_config`;
CREATE TABLE `ldap_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `server_name` varchar(45) NOT NULL,
  `server_ip` varchar(50) NOT NULL,
  `server_port` varchar(10) NOT NULL,
  `domain` varchar(45) NOT NULL,
  `base` varchar(245) NOT NULL,
  `username` varchar(245) NOT NULL,
  `password` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ldap_config`
--

/*!40000 ALTER TABLE `ldap_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `ldap_config` ENABLE KEYS */;


--
-- Definition of table `lfcycl_srvc_mgmt`
--

DROP TABLE IF EXISTS `lfcycl_srvc_mgmt`;
CREATE TABLE `lfcycl_srvc_mgmt` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rls_phs_id` int(10) unsigned NOT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_by` int(10) unsigned DEFAULT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `FK_rls_phs_id` (`rls_phs_id`),
  CONSTRAINT `FK_rls_phs_id` FOREIGN KEY (`rls_phs_id`) REFERENCES `applctn_rls_phs` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lfcycl_srvc_mgmt`
--

/*!40000 ALTER TABLE `lfcycl_srvc_mgmt` DISABLE KEYS */;
/*!40000 ALTER TABLE `lfcycl_srvc_mgmt` ENABLE KEYS */;


--
-- Definition of table `lfcycl_srvc_mgmt_env`
--

DROP TABLE IF EXISTS `lfcycl_srvc_mgmt_env`;
CREATE TABLE `lfcycl_srvc_mgmt_env` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lfcycl_srvc_mgmt_id` int(10) unsigned NOT NULL,
  `env_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_srvc_mgmt_id_1` (`lfcycl_srvc_mgmt_id`),
  KEY `FK_env_id` (`env_id`),
  CONSTRAINT `FK_env_id` FOREIGN KEY (`env_id`) REFERENCES `environments` (`ID`),
  CONSTRAINT `FK_srvc_mgmt_id_1` FOREIGN KEY (`lfcycl_srvc_mgmt_id`) REFERENCES `lfcycl_srvc_mgmt` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lfcycl_srvc_mgmt_env`
--

/*!40000 ALTER TABLE `lfcycl_srvc_mgmt_env` DISABLE KEYS */;
/*!40000 ALTER TABLE `lfcycl_srvc_mgmt_env` ENABLE KEYS */;


--
-- Definition of table `lfcycl_srvc_mgmt_srvc`
--

DROP TABLE IF EXISTS `lfcycl_srvc_mgmt_srvc`;
CREATE TABLE `lfcycl_srvc_mgmt_srvc` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lfcycl_srvc_mgmt_id` int(10) unsigned NOT NULL,
  `srvc_id` int(10) unsigned NOT NULL,
  `srvc_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_srvc_id` (`srvc_id`),
  KEY `FK_srvc_mgmt_id` (`lfcycl_srvc_mgmt_id`),
  CONSTRAINT `FK_srvc_id` FOREIGN KEY (`srvc_id`) REFERENCES `services` (`SERVICE_ID`),
  CONSTRAINT `FK_srvc_mgmt_id` FOREIGN KEY (`lfcycl_srvc_mgmt_id`) REFERENCES `lfcycl_srvc_mgmt` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lfcycl_srvc_mgmt_srvc`
--

/*!40000 ALTER TABLE `lfcycl_srvc_mgmt_srvc` DISABLE KEYS */;
/*!40000 ALTER TABLE `lfcycl_srvc_mgmt_srvc` ENABLE KEYS */;


--
-- Definition of table `machine_template`
--

DROP TABLE IF EXISTS `machine_template`;
CREATE TABLE `machine_template` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `platform_template_id` int(10) unsigned DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `cpu` varchar(45) DEFAULT NULL,
  `ram` varchar(45) DEFAULT NULL,
  `architecture` varchar(45) DEFAULT NULL,
  `status` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `machine_platform_template` (`platform_template_id`),
  CONSTRAINT `machine_platform_template` FOREIGN KEY (`platform_template_id`) REFERENCES `platform_template` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `machine_template`
--

/*!40000 ALTER TABLE `machine_template` DISABLE KEYS */;
INSERT INTO `machine_template` (`id`,`platform_template_id`,`type`,`cpu`,`ram`,`architecture`,`status`) VALUES 
 (1,1,'VMWARE','1','2048','64-bit',179),
 (2,2,'VMWARE','2','4096','64-bit',179);
/*!40000 ALTER TABLE `machine_template` ENABLE KEYS */;


--
-- Definition of table `machine_template_aws`
--

DROP TABLE IF EXISTS `machine_template_aws`;
CREATE TABLE `machine_template_aws` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `aws_account_id` int(11) NOT NULL,
  `instance_type` varchar(15) NOT NULL,
  `template_id` int(10) unsigned DEFAULT NULL,
  `machine_template_id` int(10) unsigned DEFAULT NULL,
  `sdk` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_machine_aws_2` (`template_id`),
  KEY `machine_template_aws_1` (`machine_template_id`),
  CONSTRAINT `machine_template_aws_1` FOREIGN KEY (`machine_template_id`) REFERENCES `machine_template` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `machine_template_aws`
--

/*!40000 ALTER TABLE `machine_template_aws` DISABLE KEYS */;
/*!40000 ALTER TABLE `machine_template_aws` ENABLE KEYS */;


--
-- Definition of table `machine_template_azure`
--

DROP TABLE IF EXISTS `machine_template_azure`;
CREATE TABLE `machine_template_azure` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `machine_template_id` int(10) unsigned DEFAULT NULL,
  `username` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `machine_template_azure_1` (`machine_template_id`),
  CONSTRAINT `machine_template_azure_1` FOREIGN KEY (`machine_template_id`) REFERENCES `machine_template` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `machine_template_azure`
--

/*!40000 ALTER TABLE `machine_template_azure` DISABLE KEYS */;
/*!40000 ALTER TABLE `machine_template_azure` ENABLE KEYS */;


--
-- Definition of table `machine_template_os`
--

DROP TABLE IF EXISTS `machine_template_os`;
CREATE TABLE `machine_template_os` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `flavor_type` varchar(45) NOT NULL,
  `flavor_id` varchar(45) NOT NULL,
  `machine_template_id` int(10) unsigned DEFAULT NULL,
  `disk` varchar(45) DEFAULT NULL,
  `username` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_machine_template_os_1` (`machine_template_id`),
  CONSTRAINT `FK_machine_template_os_1` FOREIGN KEY (`machine_template_id`) REFERENCES `machine_template` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `machine_template_os`
--

/*!40000 ALTER TABLE `machine_template_os` DISABLE KEYS */;
/*!40000 ALTER TABLE `machine_template_os` ENABLE KEYS */;


--
-- Definition of table `machine_template_vmware`
--

DROP TABLE IF EXISTS `machine_template_vmware`;
CREATE TABLE `machine_template_vmware` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `machine_template_id` int(10) unsigned NOT NULL,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `machine_template_vmware_1` (`machine_template_id`),
  CONSTRAINT `machine_template_vmware_1` FOREIGN KEY (`machine_template_id`) REFERENCES `machine_template` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `machine_template_vmware`
--

/*!40000 ALTER TABLE `machine_template_vmware` DISABLE KEYS */;
INSERT INTO `machine_template_vmware` (`id`,`machine_template_id`,`username`,`password`) VALUES 
 (1,1,'root','vQidDWWy+dDuLEdVh18bX3cYCOMkeMNM'),
 (2,2,'root','8+zePfBRfjqqQnNqaAItDdDh1vE7YS/+');
/*!40000 ALTER TABLE `machine_template_vmware` ENABLE KEYS */;


--
-- Definition of table `machine_tmplt_vmware_barmtl`
--

DROP TABLE IF EXISTS `machine_tmplt_vmware_barmtl`;
CREATE TABLE `machine_tmplt_vmware_barmtl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Hard_Disk_Size` int(11) NOT NULL,
  `Disk_Mode` varchar(45) NOT NULL,
  `machine_template_id` int(11) NOT NULL,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `machine_tmplt_vmware_barmtl`
--

/*!40000 ALTER TABLE `machine_tmplt_vmware_barmtl` DISABLE KEYS */;
/*!40000 ALTER TABLE `machine_tmplt_vmware_barmtl` ENABLE KEYS */;


--
-- Definition of table `machine_type`
--

DROP TABLE IF EXISTS `machine_type`;
CREATE TABLE `machine_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(45) NOT NULL,
  `type_abbr` varchar(20) NOT NULL,
  `description` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `machine_type`
--

/*!40000 ALTER TABLE `machine_type` DISABLE KEYS */;
INSERT INTO `machine_type` (`id`,`type`,`type_abbr`,`description`) VALUES 
 (1,'Physical','PHYSICAL','Physical Machine'),
 (2,'Virtual - Amazon EC2','EC2','Instances provided by Amazon EC2 services'),
 (3,'Virtual - VMware','VMWARE','Virtual Machines created in VMware'),
 (4,'Virtual - Azure','AZURE','Virtual machines provided by Azure'),
 (5,'Virtual - VMware Bare Metal','VMWARE_BARE','Virtual machines created in VMware as Bare Metal'),
 (6,'Virtual-Openstack','OPENSTACK','Instances provided by OS services'),
 (7,'Virtual-Docker','DOCKER','Virtual Containers created by Docker');
/*!40000 ALTER TABLE `machine_type` ENABLE KEYS */;


--
-- Definition of table `mail_setup`
--

DROP TABLE IF EXISTS `mail_setup`;
CREATE TABLE `mail_setup` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `service_id` int(10) unsigned NOT NULL,
  `receiver_to` varchar(500) DEFAULT NULL,
  `receiver_cc` varchar(500) DEFAULT NULL,
  `msg` varchar(160) DEFAULT NULL,
  `action` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_mail_setup_1` (`service_id`),
  CONSTRAINT `FK_mail_setup_1` FOREIGN KEY (`service_id`) REFERENCES `services` (`SERVICE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mail_setup`
--

/*!40000 ALTER TABLE `mail_setup` DISABLE KEYS */;
/*!40000 ALTER TABLE `mail_setup` ENABLE KEYS */;


--
-- Definition of table `mail_setup_mapping`
--

DROP TABLE IF EXISTS `mail_setup_mapping`;
CREATE TABLE `mail_setup_mapping` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bu_id` int(11) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `mail_setup_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_mail_setup_id1_idx` (`mail_setup_id`),
  CONSTRAINT `FK_mail_setup_id1` FOREIGN KEY (`mail_setup_id`) REFERENCES `mail_setup` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mail_setup_mapping`
--

/*!40000 ALTER TABLE `mail_setup_mapping` DISABLE KEYS */;
/*!40000 ALTER TABLE `mail_setup_mapping` ENABLE KEYS */;


--
-- Definition of table `mail_setup_role_mapping`
--

DROP TABLE IF EXISTS `mail_setup_role_mapping`;
CREATE TABLE `mail_setup_role_mapping` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mail_setup_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_mail_setup_role_mapping_1` (`mail_setup_id`),
  CONSTRAINT `FK_mail_setup_role_mapping_1` FOREIGN KEY (`mail_setup_id`) REFERENCES `mail_setup` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mail_setup_role_mapping`
--

/*!40000 ALTER TABLE `mail_setup_role_mapping` DISABLE KEYS */;
/*!40000 ALTER TABLE `mail_setup_role_mapping` ENABLE KEYS */;


--
-- Definition of table `monitoring_master`
--

DROP TABLE IF EXISTS `monitoring_master`;
CREATE TABLE `monitoring_master` (
  `PROXY_PORT` varchar(10) DEFAULT '0',
  `PROXY_URL` varchar(100) DEFAULT NULL,
  `USER_NAME` varchar(45) DEFAULT NULL,
  `PASSWORD` varchar(45) DEFAULT NULL,
  `MACHINE` varchar(45) DEFAULT NULL,
  `DOMAIN` varchar(45) DEFAULT NULL,
  `ACTIVE` varchar(2) DEFAULT NULL,
  `P_Id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`P_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `monitoring_master`
--

/*!40000 ALTER TABLE `monitoring_master` DISABLE KEYS */;
/*!40000 ALTER TABLE `monitoring_master` ENABLE KEYS */;


--
-- Definition of table `msg_history`
--

DROP TABLE IF EXISTS `msg_history`;
CREATE TABLE `msg_history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `receiver_to` varchar(500) DEFAULT NULL,
  `receiver_cc` varchar(500) DEFAULT NULL,
  `msg` varchar(160) DEFAULT NULL,
  `senttime` datetime DEFAULT NULL,
  `receivedtime` datetime DEFAULT NULL,
  `status` varchar(30) DEFAULT NULL,
  `errormsg` varchar(250) DEFAULT NULL,
  `entity` int(10) unsigned DEFAULT NULL,
  `sub_entity` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `msg_history`
--

/*!40000 ALTER TABLE `msg_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `msg_history` ENABLE KEYS */;


--
-- Definition of table `multiple_profile_details`
--

DROP TABLE IF EXISTS `multiple_profile_details`;
CREATE TABLE `multiple_profile_details` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `MULTIPLE_PROFILE_ID` int(10) unsigned NOT NULL,
  `PROFILE_ID` int(10) unsigned DEFAULT NULL,
  `APPLICATION_ID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `fk_1_idx` (`MULTIPLE_PROFILE_ID`),
  KEY `FK_multiple_profile_details_2` (`APPLICATION_ID`),
  CONSTRAINT `fk_1` FOREIGN KEY (`MULTIPLE_PROFILE_ID`) REFERENCES `multiple_profiles` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_multiple_profile_details_2` FOREIGN KEY (`APPLICATION_ID`) REFERENCES `applications` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `multiple_profile_details`
--

/*!40000 ALTER TABLE `multiple_profile_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `multiple_profile_details` ENABLE KEYS */;


--
-- Definition of table `multiple_profiles`
--

DROP TABLE IF EXISTS `multiple_profiles`;
CREATE TABLE `multiple_profiles` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `NAME` varchar(45) NOT NULL,
  `STATUS` int(10) unsigned DEFAULT NULL,
  `CREATED_BY` int(10) unsigned DEFAULT NULL,
  `CREATED_DATE` datetime DEFAULT NULL,
  `MODIFIED_BY` int(10) unsigned DEFAULT NULL,
  `MODIFIED_DATE` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `multiple_profiles`
--

/*!40000 ALTER TABLE `multiple_profiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `multiple_profiles` ENABLE KEYS */;


--
-- Definition of table `neta_nexus_details`
--

DROP TABLE IF EXISTS `neta_nexus_details`;
CREATE TABLE `neta_nexus_details` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nexus_repo_id` varchar(45) NOT NULL,
  `nexus_group_id` varchar(45) NOT NULL,
  `nexus_username` varchar(45) NOT NULL,
  `nexus_password` varchar(45) NOT NULL,
  `nexus_url` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `neta_nexus_details`
--

/*!40000 ALTER TABLE `neta_nexus_details` DISABLE KEYS */;
INSERT INTO `neta_nexus_details` (`id`,`nexus_repo_id`,`nexus_group_id`,`nexus_username`,`nexus_password`,`nexus_url`) VALUES 
 (1,'netra','com.temsinfra','admin','admin123','http://10.130.25.93:8080/nexus');
/*!40000 ALTER TABLE `neta_nexus_details` ENABLE KEYS */;


--
-- Definition of table `netra_parameters`
--

DROP TABLE IF EXISTS `netra_parameters`;
CREATE TABLE `netra_parameters` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `label` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `netra_parameters`
--

/*!40000 ALTER TABLE `netra_parameters` DISABLE KEYS */;
INSERT INTO `netra_parameters` (`id`,`label`) VALUES 
 (1,'Schema Name'),
 (2,'Database Scripts'),
 (3,'Database Scripts Path'),
 (4,'Repository URL'),
 (5,'Repository Username'),
 (6,'Repository Password'),
 (7,'Repository Type'),
 (8,'Move Netra Files/SourcePathAddress'),
 (9,'Move Netra Files/DestinationPathAddress'),
 (10,'Move Netra Files/SourceIPAddress'),
 (11,'QTP/QTP Parameters/Qtp script directory'),
 (12,'QTP/QTP Parameters/Filename'),
 (13,'MC TAM/TAM_Adapter_Name'),
 (14,'TAM/TAM_Adapter_Installation_Directory'),
 (15,'MC TAM/TAM_Adapter_Installation_Directory'),
 (16,'MC TAM/TAM_Adapter_Location_String'),
 (17,'MC TAM/TAM_Server_Url'),
 (18,'MC TAM/Testing_Tool'),
 (19,'MC TAM/UserName'),
 (20,'MC TAM/Password'),
 (21,'TAM/TAM_Adapter_Start_File_Name'),
 (22,'TAM/Server_Ip'),
 (23,'TAM/Server_Port'),
 (24,'TAM/Testing_Tool'),
 (25,'Shared-Nexus Flag'),
 (26,'Shared Location IP'),
 (27,'Shared Location Path'),
 (28,'NETRA Temporary Destination'),
 (29,'Nexus WAR Name'),
 (30,'Nexus Username'),
 (31,'Nexus Password');
INSERT INTO `netra_parameters` (`id`,`label`) VALUES 
 (32,'Nexus Source URL'),
 (33,'Nexus Repo-ID'),
 (34,'Nexus Group-ID'),
 (35,'Nexus Artifact-ID'),
 (36,'Nexus_URL'),
 (37,'Nexus Version-ID'),
 (38,'CA_server'),
 (39,'Oracle_Connection_DBUrl'),
 (40,'MySQL_Connection_DBUrl'),
 (41,'Deployment Artifact Type'),
 (42,'Application_Release'),
 (43,'Application_Nexus_Name'),
 (44,'Windows/Original_Hostname'),
 (45,'Windows/Agent_Hostname'),
 (46,'Windows/Domain_Name'),
 (47,'Deployed Artifact'),
 (48,'Installer Location Linux'),
 (49,'Installer Location Windows'),
 (50,'Target Location Linux'),
 (51,'Target Location Windows'),
 (52,'Deployment Script Name'),
 (53,'Artifact Target Directory'),
 (54,'EAR/Script Selector'),
 (55,'Agent IP'),
 (56,'Target Location'),
 (57,'Protocol'),
 (58,'Script Checkout Directory'),
 (59,'TFS Agent'),
 (60,'Build Location'),
 (61,'Shared Location Name'),
 (62,'Config File Name'),
 (63,'MSSQL_Connection_DBUrl'),
 (64,'TFS Agent'),
 (65,'Build Location'),
 (66,'Current Release');
INSERT INTO `netra_parameters` (`id`,`label`) VALUES 
 (67,'Rollback Flag');
/*!40000 ALTER TABLE `netra_parameters` ENABLE KEYS */;


--
-- Definition of table `netra_parameters_mapping`
--

DROP TABLE IF EXISTS `netra_parameters_mapping`;
CREATE TABLE `netra_parameters_mapping` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nolio_process_id` int(10) unsigned NOT NULL,
  `nolio_parameter_id` int(10) unsigned NOT NULL,
  `netra_parameter_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `netra_parameters_mapping`
--

/*!40000 ALTER TABLE `netra_parameters_mapping` DISABLE KEYS */;
/*!40000 ALTER TABLE `netra_parameters_mapping` ENABLE KEYS */;


--
-- Definition of table `netra_ud_parameters_mapping`
--

DROP TABLE IF EXISTS `netra_ud_parameters_mapping`;
CREATE TABLE `netra_ud_parameters_mapping` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `udeploy_process_Id` int(10) unsigned NOT NULL,
  `udeploy_parameter_id` int(10) unsigned NOT NULL,
  `netra_ud_parameter_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `netra_ud_parameters_mapping`
--

/*!40000 ALTER TABLE `netra_ud_parameters_mapping` DISABLE KEYS */;
/*!40000 ALTER TABLE `netra_ud_parameters_mapping` ENABLE KEYS */;


--
-- Definition of table `nolio_process`
--

DROP TABLE IF EXISTS `nolio_process`;
CREATE TABLE `nolio_process` (
  `Process_Id` int(11) NOT NULL AUTO_INCREMENT,
  `Application_Name` varchar(100) NOT NULL,
  `Environment_Name` varchar(100) NOT NULL,
  `Server_Type` varchar(100) NOT NULL,
  `Process_Full_Path` varchar(200) NOT NULL,
  `Process_Tag` varchar(100) DEFAULT NULL,
  `status` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`Process_Id`),
  UNIQUE KEY `Unique_Index` (`Application_Name`,`Environment_Name`,`Server_Type`,`Process_Full_Path`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nolio_process`
--

/*!40000 ALTER TABLE `nolio_process` DISABLE KEYS */;
INSERT INTO `nolio_process` (`Process_Id`,`Application_Name`,`Environment_Name`,`Server_Type`,`Process_Full_Path`,`Process_Tag`,`status`) VALUES 
 (1,'Test Application','Environment for Single Server Architecture','JPetStore Server','Processes/Simple Process (One Server)',NULL,'ACT'),
 (2,'Test Application','Environment for Two Servers Architecture','App Server','Processes/Simple Process (Two Servers)',NULL,'ACT'),
 (3,'Test Application','Environment for Two Servers Architecture','DB Server','Processes/Simple Process (Two Servers)',NULL,'ACT'),
 (4,'TEMS','Environment for Default Architecture','Server Type 1','Windows Process/GetNolioAgentDirectory',NULL,'ACT'),
 (5,'TEMS','Environment for Default Architecture','Zabbix_Server','FolderMovement/FolderMovement',NULL,'ACT'),
 (6,'TEMS','Environment for Default Architecture','POC','QTP/QTP script Execution',NULL,'ACT'),
 (7,'TEMS','Environment for Default Architecture','Zabbix','Zabbix/Zabbix_Jboss_Template',NULL,'ACT'),
 (8,'TEMS','Environment for Default Architecture','Server Type 1','Windows Process/FileTransfer',NULL,'ACT'),
 (9,'TEMS','Environment for Default Architecture','Zabbix_Server','Zabbix/Zabbix_Orcale_Template',NULL,'ACT');
INSERT INTO `nolio_process` (`Process_Id`,`Application_Name`,`Environment_Name`,`Server_Type`,`Process_Full_Path`,`Process_Tag`,`status`) VALUES 
 (10,'TEMS','Environment for Default Architecture','Oracle Server Type','Windows Process/Conditional Checks',NULL,'ACT'),
 (11,'TEMS','Environment for Default Architecture','Zabbix_win','Zabbix/ZabbixWindowsLinux',NULL,'ACT'),
 (14,'TEMS','Environment for Default Architecture','Websphere','IBM-WAS/IBM-WAS installation and configure',NULL,'ACT'),
 (15,'TEMS','Environment for Default Architecture','Oracle Linux Server Type','Oracle/Install Oracle Linux',NULL,'ACT'),
 (16,'TEMS','Environment for Default Architecture','Server Type 1','Windows Process/Windows_Agent_Deployer',NULL,'ACT'),
 (17,'TEMS','Environment for Default Architecture','TAM','MC TAM/Create_URL_Parameterization_file',NULL,'ACT'),
 (18,'TEMS','Environment for Default Architecture','TAM','MC TAM/MC_TAM_Adapter_Installation',NULL,'ACT'),
 (19,'TEMS','Environment for Default Architecture','Oracle Server Type','Oracle/windows/InstallOracleWin',NULL,'ACT'),
 (20,'TEMS','Environment for Default Architecture','POC','nexus/NexusUplaod',NULL,'ACT');
INSERT INTO `nolio_process` (`Process_Id`,`Application_Name`,`Environment_Name`,`Server_Type`,`Process_Full_Path`,`Process_Tag`,`status`) VALUES 
 (21,'TEMS','Environment for Default Architecture','Server Type 1','nexus/NexusUpload2',NULL,'ACT'),
 (22,'TEMS','Environment for Default Architecture','Oracle Linux Server Type','Oracle/Install Oracle Linux_32',NULL,'ACT'),
 (23,'TEMS','Environment for Default Architecture','Oracle Server Type','Oracle/Import SQL File',NULL,'ACT'),
 (24,'TEMS','Environment for Default Architecture','websphere1','WAS/WAS1',NULL,'ACT'),
 (25,'TEMS','Environment for Default Architecture','WAS','WAS/INSTALL WAS',NULL,'ACT'),
 (26,'TEMS','Environment for Default Architecture','TAM','MC TAM/Start Adapter',NULL,'ACT'),
 (27,'TEMS','Environment for Default Architecture','mysql_linux','MYSQL/MySql_Installation_Linux',NULL,'ACT'),
 (28,'TEMS','Environment for Default Architecture','mysql_linux','MYSQL/mysql_install',NULL,'ACT'),
 (29,'TEMS','Environment for Default Architecture','mysql_linux','MYSQL/mysql',NULL,'ACT'),
 (30,'TEMS','Environment for Default Architecture','SQL_SERVER_WIN','MS_SQL_SERVER/MSSQLDBSCRIPT',NULL,'ACT');
INSERT INTO `nolio_process` (`Process_Id`,`Application_Name`,`Environment_Name`,`Server_Type`,`Process_Full_Path`,`Process_Tag`,`status`) VALUES 
 (31,'TEMS','Environment for Default Architecture','SQL_SERVER_WIN','MS_SQL_SERVER/SQL_SERVER',NULL,'ACT'),
 (32,'TEMS','Environment for Default Architecture','Check_OS','Zabbix/Check_OS_Zabbix',NULL,'ACT'),
 (33,'TEMS','Environment for Default Architecture','Zabbix_win','Zabbix/Win',NULL,'ACT'),
 (34,'TEMS','Environment for Default Architecture','Zabbix','Zabbix/Zabbix_Linux',NULL,'ACT'),
 (35,'TEMS','Environment for TEMS_Architecture','JBoss Server_1','JBoss/Restart_JBoss_Linux',NULL,'ACT'),
 (36,'TEMS','Environment for TEMS_Architecture','JBoss Server_1','JBoss/Install JBoss Linux-cpy',NULL,'ACT'),
 (37,'TEMS','Environment for TEMS_Architecture','JBoss Server_1','JBoss/jboss_undeploy_ear_linux',NULL,'ACT'),
 (38,'TEMS','Environment for TEMS_Architecture','JBoss Server_1','JBoss/Windows_NolioAgentDeployer',NULL,'ACT'),
 (39,'TEMS','Environment for TEMS_Architecture','Oracle Server Type','oracle/Perforce_DBScripts',NULL,'ACT'),
 (40,'TEMS','Environment for TEMS_Architecture','Jboss_Test_Server','JBoss/Deploy_Ear_Nexus_Final',NULL,'ACT');
INSERT INTO `nolio_process` (`Process_Id`,`Application_Name`,`Environment_Name`,`Server_Type`,`Process_Full_Path`,`Process_Tag`,`status`) VALUES 
 (41,'TEMS','Environment for TEMS_Architecture','JBoss Server_1','Processes/Deploy_EAR_Linux',NULL,'ACT'),
 (42,'TEMS','Environment for TEMS_Architecture','JBoss Server_1','JBoss/Deploy_EAR_Linux_Nexus',NULL,'ACT'),
 (43,'TEMS','Environment for TEMS_Architecture','test1','Processes/DBScripts',NULL,'ACT'),
 (44,'TEMS','Environment for TEMS_Architecture','Oracle Server Type','Processes/MYSQLDBScripts',NULL,'ACT'),
 (45,'TEMS','Environment for TEMS_Architecture','jboss','JBoss/Windows/InstallJBossWin',NULL,'ACT'),
 (46,'TEMS','Environment for TEMS_Architecture','Oracle Server Type','Processes/mysql_dbscripts_test',NULL,'ACT'),
 (47,'TEMS','Environment for TEMS_Architecture','JBoss Server_1','JBoss/Windows/Restart jboss processWin',NULL,'ACT'),
 (48,'TEMS','Environment for TEMS_Architecture','jboss','Processes/sonar_1',NULL,'ACT'),
 (49,'TEMS','Environment for TEMS_Architecture','test1','Processes/DB_Scripts_Oracle_Git',NULL,'ACT'),
 (50,'TEMS','Environment for TEMS_Architecture','JBoss Server_1','JBoss/Windows/undeploy jboss win',NULL,'ACT');
INSERT INTO `nolio_process` (`Process_Id`,`Application_Name`,`Environment_Name`,`Server_Type`,`Process_Full_Path`,`Process_Tag`,`status`) VALUES 
 (51,'TEMS','Environment for TEMS_Architecture','Jboss_Test_Server','Processes/Install Oracle Windows',NULL,'ACT'),
 (52,'TEMS','Environment for TEMS_Architecture','Server Type 1','REPO/RepoProcess',NULL,'ACT'),
 (53,'TEMS','Environment for TEMS_Architecture','test1','Processes/DBScripts_DataMasking',NULL,'ACT'),
 (54,'TEMS','Environment for TFS','IIS_SERVER','TFS Processes/Configure_IIS',NULL,'ACT'),
 (55,'TEMS','Environment for TFS','IIS_SERVER','TFS Processes/Deploy_IIS',NULL,'ACT'),
 (56,'demo_rahul','Environment for Default Architecture','Server Type 1','Processes/UnDeploy_Web',NULL,'ACT'),
 (57,'demo_rahul','Environment for Default Architecture','Server Type 1','Processes/Deploy_Web_Rollback',NULL,'ACT'),
 (58,'demo_rahul','Environment for Default Architecture','Server Type 1','Processes/Deploy_Web',NULL,'ACT'),
 (59,'demo_rahul','Environment for Default Architecture','Server Type 1','Processes/Process_Deploy_Webs',NULL,'ACT'),
 (60,'demo_rahul','Environment for Default Architecture','Server Type 1','Processes/dbscript',NULL,'ACT');
INSERT INTO `nolio_process` (`Process_Id`,`Application_Name`,`Environment_Name`,`Server_Type`,`Process_Full_Path`,`Process_Tag`,`status`) VALUES 
 (61,'demo_rahul','Environment for Default Architecture','Server Type 2','Processes/dbscript',NULL,'ACT'),
 (62,'Weblogic','Weblogic','JBoss Server_1','Processes/weblogicDeploy',NULL,'ACT'),
 (63,'Demo123','New Env','Server Type 1','Processes/Folder',NULL,'ACT'),
 (64,'anil','Environment for Default Architecture','Server Type 2','Processes/Process 1',NULL,'ACT'),
 (65,'TibcoApp','Environment for Default Architecture','checkoutandExport','Processes/CheckoutAndExport',NULL,'ACT'),
 (66,'TibcoApp','Environment for Default Architecture','server3','Processes/TibcoDeploymentMultiple',NULL,'ACT'),
 (67,'TibcoApp','Environment for Default Architecture','checkoutandExport','Processes/TibcoDeployment',NULL,'ACT'),
 (68,'test','Environment for Default Architecture','Server Type 1','Processes/Process 1',NULL,'ACT'),
 (69,'prats','Environment for Default Architecture','demo','Processes/abc',NULL,'ACT'),
 (70,'Demo1','Demo1Env','Server Type 1','Processes/Demo1Process',NULL,'ACT');
INSERT INTO `nolio_process` (`Process_Id`,`Application_Name`,`Environment_Name`,`Server_Type`,`Process_Full_Path`,`Process_Tag`,`status`) VALUES 
 (71,'Test_TFS','Environment for Architect_TFS','Server Type 1','Processes/Test_TFS',NULL,'ACT'),
 (72,'Test_TFS','Environment for Architect_TFS','Server Type 1','Processes/MSBUILD_TFS',NULL,'ACT'),
 (74,'Application_TFS','Environment for Default Architecture','Server Type 1','Processes/Process_TFS',NULL,'ACT'),
 (75,'Application_TFS','Environment for Default Architecture','Server Type 2','Processes/Process_TFS',NULL,'ACT');
/*!40000 ALTER TABLE `nolio_process` ENABLE KEYS */;


--
-- Definition of table `nolio_process_parameters`
--

DROP TABLE IF EXISTS `nolio_process_parameters`;
CREATE TABLE `nolio_process_parameters` (
  `parameter_Id` int(11) NOT NULL AUTO_INCREMENT,
  `process_Id` int(11) NOT NULL,
  `parameter_path_name` varchar(200) NOT NULL,
  `parameter_value` varchar(200) DEFAULT NULL,
  `status` varchar(3) DEFAULT NULL,
  `netra_parameter_name` varchar(100) DEFAULT NULL,
  `netra_parameter_mapping` varchar(2) DEFAULT 'N',
  `parameter_scope` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`parameter_Id`),
  UNIQUE KEY `FK_nolio_process_parameters_1` (`process_Id`,`parameter_path_name`),
  CONSTRAINT `FK_nolio_process_parameters_1` FOREIGN KEY (`process_Id`) REFERENCES `nolio_process` (`Process_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=233 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nolio_process_parameters`
--

/*!40000 ALTER TABLE `nolio_process_parameters` DISABLE KEYS */;
INSERT INTO `nolio_process_parameters` (`parameter_Id`,`process_Id`,`parameter_path_name`,`parameter_value`,`status`,`netra_parameter_name`,`netra_parameter_mapping`,`parameter_scope`) VALUES 
 (1,4,'GetNolioAgentDirectory/env_variable',NULL,'ACT',NULL,'N',NULL),
 (2,5,'Move Netra Files/SourceIPAddress',NULL,'ACT',NULL,'N',NULL),
 (3,5,'Move Netra Files/SourcePathAddress',NULL,'ACT',NULL,'N',NULL),
 (4,5,'Move Netra Files/DestinationPathAddress',NULL,'ACT',NULL,'N',NULL),
 (5,6,'QTP/QTP Parameters/Filename',NULL,'ACT',NULL,'N',NULL),
 (6,6,'QTP/QTP Parameters/Qtp script directory',NULL,'ACT',NULL,'N',NULL),
 (7,7,'Zabbix_Templates/JBoss Directory Name',NULL,'ACT',NULL,'N',NULL),
 (8,7,'Zabbix_Templates/Install Directory',NULL,'ACT',NULL,'N',NULL),
 (9,11,'Zabbix_Agent_Linux/OS_Zabbix',NULL,'ACT',NULL,'N',NULL),
 (10,16,'Windows/Agent_Hostname',NULL,'ACT',NULL,'N',NULL),
 (11,16,'Windows/Domain_Name',NULL,'ACT',NULL,'N',NULL),
 (12,16,'Windows/Original_Hostname',NULL,'ACT',NULL,'N',NULL),
 (13,17,'MC TAM/TAM_Adapter_Installation_Directory',NULL,'ACT',NULL,'N',NULL);
INSERT INTO `nolio_process_parameters` (`parameter_Id`,`process_Id`,`parameter_path_name`,`parameter_value`,`status`,`netra_parameter_name`,`netra_parameter_mapping`,`parameter_scope`) VALUES 
 (14,17,'MC TAM/Server_Port',NULL,'ACT',NULL,'N',NULL),
 (15,17,'MC TAM/Server_Ip',NULL,'ACT',NULL,'N',NULL),
 (16,18,'MC TAM/TAM_Adapter_Installation_Directory',NULL,'ACT',NULL,'N',NULL),
 (17,18,'MC TAM/TAM_Adapter_Location_String',NULL,'ACT',NULL,'N',NULL),
 (18,18,'MC TAM/TAM_Adapter_Name',NULL,'ACT',NULL,'N',NULL),
 (19,18,'MC TAM/UserName',NULL,'ACT',NULL,'N',NULL),
 (20,18,'MC TAM/TAM_Server_Url',NULL,'ACT',NULL,'N',NULL),
 (21,18,'MC TAM/Password',NULL,'ACT',NULL,'N',NULL),
 (22,19,'Oracle-import-2015-12-29 19:16:51.135/TargetLoc',NULL,'ACT','Target Location Windows','Y',NULL),
 (23,20,'Nexus Download/Nexus-Pwd',NULL,'ACT',NULL,'N',NULL),
 (24,20,'Nexus Download/RemoteSourcePath',NULL,'ACT',NULL,'N',NULL),
 (25,20,'Nexus Download/Group-Id',NULL,'ACT',NULL,'N',NULL),
 (26,20,'Nexus Download/Nexus_URL',NULL,'ACT',NULL,'N',NULL),
 (27,20,'Nexus Download/Artifact-Id',NULL,'ACT',NULL,'N',NULL);
INSERT INTO `nolio_process_parameters` (`parameter_Id`,`process_Id`,`parameter_path_name`,`parameter_value`,`status`,`netra_parameter_name`,`netra_parameter_mapping`,`parameter_scope`) VALUES 
 (28,20,'Nexus Download/VARIBLE',NULL,'ACT',NULL,'N',NULL),
 (29,20,'Nexus Download/Remote IP',NULL,'ACT',NULL,'N',NULL),
 (30,20,'Nexus Download/warname',NULL,'ACT',NULL,'N',NULL),
 (31,20,'Nexus Download/NexusUrl-Source',NULL,'ACT',NULL,'N',NULL),
 (32,20,'Nexus Download/Nexus-UserName',NULL,'ACT',NULL,'N',NULL),
 (33,20,'Nexus Download/TMP-Destination',NULL,'ACT',NULL,'N',NULL),
 (34,20,'Nexus Download/Version-Id',NULL,'ACT',NULL,'N',NULL),
 (35,20,'Nexus Download/Repo-Id',NULL,'ACT',NULL,'N',NULL),
 (36,21,'Nexus Download/Nexus-Pwd',NULL,'ACT',NULL,'N',NULL),
 (37,21,'Nexus Download/Nexus-UserName',NULL,'ACT',NULL,'N',NULL),
 (38,21,'Nexus Download/Deployment Artifact Type',NULL,'ACT',NULL,'N',NULL),
 (39,21,'Nexus Download/EAR',NULL,'ACT',NULL,'N',NULL),
 (40,21,'Nexus Download/REPO PASSWORD',NULL,'ACT',NULL,'N',NULL),
 (41,21,'Nexus Download/REPO TYPE',NULL,'ACT',NULL,'N',NULL);
INSERT INTO `nolio_process_parameters` (`parameter_Id`,`process_Id`,`parameter_path_name`,`parameter_value`,`status`,`netra_parameter_name`,`netra_parameter_mapping`,`parameter_scope`) VALUES 
 (42,21,'Nexus Download/REPO USER',NULL,'ACT',NULL,'N',NULL),
 (43,21,'Nexus Download/script name',NULL,'ACT',NULL,'N',NULL),
 (44,21,'Nexus Download/Repo-Id',NULL,'ACT',NULL,'N',NULL),
 (45,21,'Nexus Download/RemoteSourcePath',NULL,'ACT',NULL,'N',NULL),
 (46,21,'Nexus Download/NexusUrl-Source',NULL,'ACT',NULL,'N',NULL),
 (47,21,'Nexus Download/Version-Id',NULL,'ACT',NULL,'N',NULL),
 (48,21,'Nexus Download/TARGET DIRECTORY',NULL,'ACT',NULL,'N',NULL),
 (49,21,'Nexus Download/Remote IP',NULL,'ACT',NULL,'N',NULL),
 (50,21,'Nexus Download/TMP-Destination',NULL,'ACT',NULL,'N',NULL),
 (51,21,'Nexus Download/Nexus_URL',NULL,'ACT',NULL,'N',NULL),
 (52,21,'Nexus Download/warname',NULL,'ACT',NULL,'N',NULL),
 (53,21,'Nexus Download/Artifact-Id',NULL,'ACT',NULL,'N',NULL),
 (54,21,'Nexus Download/Group-Id',NULL,'ACT',NULL,'N',NULL),
 (55,21,'Nexus Download/REPO URL',NULL,'ACT',NULL,'N',NULL);
INSERT INTO `nolio_process_parameters` (`parameter_Id`,`process_Id`,`parameter_path_name`,`parameter_value`,`status`,`netra_parameter_name`,`netra_parameter_mapping`,`parameter_scope`) VALUES 
 (56,23,'Oracle/Oracle_Agent_IP',NULL,'ACT',NULL,'N',NULL),
 (57,24,'WAS/Response_file',NULL,'ACT',NULL,'N',NULL),
 (58,24,'WAS/server_bin',NULL,'ACT',NULL,'N',NULL),
 (59,24,'WAS/Linux/path',NULL,'ACT',NULL,'N',NULL),
 (60,24,'WAS/target',NULL,'ACT',NULL,'N',NULL),
 (61,24,'WAS/Install_Path',NULL,'ACT',NULL,'N',NULL),
 (62,24,'WAS/Linux/Installer_Target_Path',NULL,'ACT',NULL,'N',NULL),
 (63,25,'WAS/server_bin',NULL,'ACT',NULL,'N',NULL),
 (64,25,'WAS/Install_Path',NULL,'ACT',NULL,'N',NULL),
 (65,25,'WAS/Response_file',NULL,'ACT',NULL,'N',NULL),
 (66,25,'WAS/Linux/Installer_Target_Path',NULL,'ACT',NULL,'N',NULL),
 (67,25,'WAS/target',NULL,'ACT',NULL,'N',NULL),
 (68,25,'WAS/Linux/path',NULL,'ACT',NULL,'N',NULL),
 (69,26,'MC TAM/TAM_Adapter_Installation_Directory',NULL,'ACT',NULL,'N',NULL),
 (70,26,'MC TAM/TAM_Adapter_Start_File_Name',NULL,'ACT',NULL,'N',NULL),
 (71,28,'My SQL/New_password',NULL,'ACT',NULL,'N',NULL);
INSERT INTO `nolio_process_parameters` (`parameter_Id`,`process_Id`,`parameter_path_name`,`parameter_value`,`status`,`netra_parameter_name`,`netra_parameter_mapping`,`parameter_scope`) VALUES 
 (72,29,'My SQL/New_password',NULL,'ACT',NULL,'N',NULL),
 (73,29,'My SQL/New_user',NULL,'ACT',NULL,'N',NULL),
 (74,30,'MSSQLDbScript/script_path',NULL,'ACT',NULL,'N',NULL),
 (75,30,'Protocol',NULL,'ACT',NULL,'N',NULL),
 (76,30,'MSSQLDbScript/svn_password',NULL,'ACT',NULL,'N',NULL),
 (77,30,'MSSQLDbScript/scriptArr',NULL,'ACT',NULL,'N',NULL),
 (78,30,'MSSQLDbScript/svn_user_name',NULL,'ACT',NULL,'N',NULL),
 (79,30,'MSSQLDbScript/ReleaseName',NULL,'ACT',NULL,'N',NULL),
 (80,32,'Zabbix_Win/OS_Zabbix',NULL,'ACT',NULL,'N',NULL),
 (81,34,'Zabbix_Agent_Linux/OS_Zabbix',NULL,'ACT',NULL,'N',NULL),
 (82,37,'JBoss/ear_file_name',NULL,'ACT','Deployed Artifact','Y',NULL),
 (83,39,'Oracle-import-2016-04-13 03:41:16.232/DBScripts/SVN_Export_Directory',NULL,'ACT',NULL,'N',NULL),
 (84,39,'Oracle-import-2016-04-13 03:41:16.232/DBScripts/scripts_name',NULL,'ACT',NULL,'N',NULL),
 (85,39,'Oracle-import-2016-04-13 03:41:16.232/DBScripts/current_script',NULL,'ACT',NULL,'N',NULL);
INSERT INTO `nolio_process_parameters` (`parameter_Id`,`process_Id`,`parameter_path_name`,`parameter_value`,`status`,`netra_parameter_name`,`netra_parameter_mapping`,`parameter_scope`) VALUES 
 (86,40,'JBoss-import-2015-02-09 17:34:55.61/Linux/Oracle_DBurl',NULL,'ACT',NULL,'N',NULL),
 (87,40,'JBoss-import-2015-02-09 17:34:55.61/version',NULL,'ACT',NULL,'N',NULL),
 (88,40,'JBoss-import-2015-02-09 17:34:55.61/ArtifactId',NULL,'ACT',NULL,'N',NULL),
 (89,40,'JBoss-import-2015-02-09 17:34:55.61/Agent Type',NULL,'ACT',NULL,'N',NULL),
 (90,40,'JBoss-import-2015-02-09 17:34:55.61/Linux/DBurl',NULL,'ACT',NULL,'N',NULL),
 (91,41,'JBoss/Linux/DBurl',NULL,'ACT',NULL,'N',NULL),
 (92,41,'JBoss/Linux/Oracle_DBurl',NULL,'ACT',NULL,'N',NULL),
 (93,41,'JBoss/Linux/remote_source_path',NULL,'ACT',NULL,'N',NULL),
 (94,41,'JBoss/Linux/Nolio_Server',NULL,'ACT',NULL,'N',NULL),
 (95,42,'JBoss/ArtifactId','','ACT','Nexus Artifact-ID','Y',''),
 (96,42,'JBoss/Linux/DBurl','','ACT','MySQL_Connection_DBUrl','Y',''),
 (97,42,'JBoss/Linux/Oracle_DBurl','','ACT','Oracle_Connection_DBUrl','Y','');
INSERT INTO `nolio_process_parameters` (`parameter_Id`,`process_Id`,`parameter_path_name`,`parameter_value`,`status`,`netra_parameter_name`,`netra_parameter_mapping`,`parameter_scope`) VALUES 
 (98,42,'JBoss/version','','ACT','Nexus Version-ID','Y',''),
 (99,43,'Oracle/DBScripts/repository_username',NULL,'ACT',NULL,'N',NULL),
 (100,43,'Oracle/DBScripts/scripts_name',NULL,'ACT',NULL,'N',NULL),
 (101,43,'Oracle/DBScripts/scripts_path',NULL,'ACT',NULL,'N',NULL),
 (102,43,'Oracle/DBScripts/repository_password',NULL,'ACT',NULL,'N',NULL),
 (103,44,'Protocol',NULL,'ACT',NULL,'N',NULL),
 (104,44,'Oracle/DBScripts/scripts_name',NULL,'ACT',NULL,'N',NULL),
 (105,44,'Oracle/DBScripts/repository_password',NULL,'ACT',NULL,'N',NULL),
 (106,44,'Oracle/DBScripts/schema_name',NULL,'ACT',NULL,'N',NULL),
 (107,44,'Oracle/DBScripts/repository_username',NULL,'ACT',NULL,'N',NULL),
 (108,44,'Oracle/DBScripts/scripts_path',NULL,'ACT',NULL,'N',NULL),
 (109,45,'JBoss-import-2015-12-29 19:16:41.225/jBossRootDir',NULL,'ACT','Target Location Windows','Y',NULL),
 (110,46,'Oracle/DBScripts/repository_url',NULL,'ACT',NULL,'N',NULL);
INSERT INTO `nolio_process_parameters` (`parameter_Id`,`process_Id`,`parameter_path_name`,`parameter_value`,`status`,`netra_parameter_name`,`netra_parameter_mapping`,`parameter_scope`) VALUES 
 (111,46,'Oracle/DBScripts/scripts_name',NULL,'ACT',NULL,'N',NULL),
 (112,46,'Oracle/DBScripts/repository_password',NULL,'ACT',NULL,'N',NULL),
 (113,46,'Oracle/DBScripts/repository_username',NULL,'ACT',NULL,'N',NULL),
 (114,46,'Oracle/DBScripts/scripts_path',NULL,'ACT',NULL,'N',NULL),
 (115,47,'JBoss-import-2016-02-10 22:11:31.451/JBossRootDirWindows',NULL,'ACT',NULL,'N',NULL),
 (116,48,'Sonar_3 nov/Exported Global parameters/Sonar Runner path',NULL,'ACT',NULL,'N',NULL),
 (117,48,'Sonar_3 nov/Exported Global parameters/svn_user',NULL,'ACT',NULL,'N',NULL),
 (118,48,'Sonar_3 nov/Exported Global parameters/Sonar  path',NULL,'ACT',NULL,'N',NULL),
 (119,48,'Sonar_3 nov/Exported Global parameters/Project_Folder',NULL,'ACT',NULL,'N',NULL),
 (120,48,'Sonar_3 nov/Exported Global parameters/svn_password',NULL,'ACT',NULL,'N',NULL),
 (121,48,'Sonar_3 nov/Exported Global parameters/SVN_UserInput_CSV',NULL,'ACT',NULL,'N',NULL);
INSERT INTO `nolio_process_parameters` (`parameter_Id`,`process_Id`,`parameter_path_name`,`parameter_value`,`status`,`netra_parameter_name`,`netra_parameter_mapping`,`parameter_scope`) VALUES 
 (122,48,'Sonar_3 nov/Exported Global parameters/sonar-project.propeties',NULL,'ACT',NULL,'N',NULL),
 (123,49,'Oracle-import-2015-01-21 20:01:49.538/DBScripts/Repo_Type','','ACT','Repository Type','Y',''),
 (124,49,'Oracle-import-2015-01-21 20:01:49.538/DBScripts/scripts_path','','ACT','Database Scripts Path','Y',''),
 (125,49,'Protocol','','ACT','Protocol','Y',''),
 (126,49,'Oracle-import-2015-01-21 20:01:49.538/DBScripts/repository_username','','ACT','Repository Username','Y',''),
 (127,49,'Oracle-import-2015-01-21 20:01:49.538/DBScripts/repository_password','','ACT','Repository Password','Y',''),
 (128,49,'Oracle-import-2015-01-21 20:01:49.538/DBScripts/scripts_name','','ACT','Database Scripts','Y',''),
 (129,50,'JBoss-import-2016-02-10 22:11:31.451/deploydwar',NULL,'ACT',NULL,'N',NULL),
 (130,50,'JBoss-import-2016-02-10 22:11:31.451/JBossRootDirWindows',NULL,'ACT',NULL,'N',NULL),
 (131,52,'Upload_EAR/Agent_IP','','ACT','Agent IP','Y','');
INSERT INTO `nolio_process_parameters` (`parameter_Id`,`process_Id`,`parameter_path_name`,`parameter_value`,`status`,`netra_parameter_name`,`netra_parameter_mapping`,`parameter_scope`) VALUES 
 (132,52,'Upload_EAR/warname','','ACT','Deployed Artifact','Y',''),
 (133,52,'Upload_EAR/Deployment Artifact Type','','ACT','Deployment Artifact Type','Y',''),
 (134,52,'Upload_EAR/NexusUrl-Source','','ACT','Nexus Source URL','Y',''),
 (135,52,'Upload_EAR/Repo-Id','','ACT','Nexus Repo-ID','Y',''),
 (136,52,'Upload_EAR/Remote IP','','ACT','Shared Location IP','Y',''),
 (137,52,'Upload_EAR/GitRepository','','ACT','Repository URL','Y',''),
 (138,52,'Upload_EAR/Nexus-Pwd','','ACT','Nexus Password','Y',''),
 (139,52,'Upload_EAR/TARGET DIRECTORY','','ACT','Artifact Target Directory','Y',''),
 (140,52,'Upload_EAR/SVN','','ACT','Repository Type','Y',''),
 (141,52,'Upload_EAR/TMP-Destination','','ACT','NETRA Temporary Destination','Y',''),
 (142,52,'Upload_EAR/REPO URL','','ACT','Repository URL','Y',''),
 (143,52,'Upload_EAR/Version-Id','','ACT','Nexus Version-ID','Y','');
INSERT INTO `nolio_process_parameters` (`parameter_Id`,`process_Id`,`parameter_path_name`,`parameter_value`,`status`,`netra_parameter_name`,`netra_parameter_mapping`,`parameter_scope`) VALUES 
 (144,52,'Upload_EAR/RemoteSourcePath','','ACT','Shared Location Path','Y',''),
 (145,52,'Upload_EAR/EAR','','ACT','EAR/Script Selector','Y',''),
 (146,52,'Upload_EAR/Nexus_URL','','ACT','Nexus_URL','Y',''),
 (147,52,'Upload_EAR/Repository Username','','ACT','Repository Username','Y',''),
 (148,52,'Upload_EAR/REPO PASSWORD','','ACT','Repository Password','Y',''),
 (149,52,'Upload_EAR/Destination_Path','','ACT','Target Location Linux','Y',''),
 (150,52,'Upload_EAR/script name','','ACT','Deployment Script Name','Y',''),
 (151,52,'Upload_EAR/Artifact-Id','','ACT','Nexus Artifact-ID','Y',''),
 (152,52,'Upload_EAR/Group-Id','','ACT','Nexus Group-ID','Y',''),
 (153,52,'Upload_EAR/Nexus-UserName','','ACT','Nexus Username','Y',''),
 (154,52,'Upload_EAR/REPO USER','','ACT','Repository Username','Y',''),
 (155,53,'Oracle-import-2015-02-23 13:38:20.179/DBScripts/scripts_name',NULL,'ACT',NULL,'N',NULL),
 (156,53,'Oracle-import-2015-02-23 13:38:20.179/DBScripts/repository_password',NULL,'ACT',NULL,'N',NULL);
INSERT INTO `nolio_process_parameters` (`parameter_Id`,`process_Id`,`parameter_path_name`,`parameter_value`,`status`,`netra_parameter_name`,`netra_parameter_mapping`,`parameter_scope`) VALUES 
 (157,53,'Oracle-import-2015-02-23 13:38:20.179/DBScripts/repository_username',NULL,'ACT',NULL,'N',NULL),
 (158,53,'Oracle-import-2015-02-23 13:38:20.179/DBScripts/schema_name',NULL,'ACT',NULL,'N',NULL),
 (159,53,'Oracle-import-2015-02-23 13:38:20.179/DBScripts/scripts_path',NULL,'ACT',NULL,'N',NULL),
 (160,53,'Oracle-import-2015-02-23 13:38:20.179/DBScripts/repository_url',NULL,'ACT',NULL,'N',NULL),
 (161,55,'Target_TFS_location',NULL,'ACT',NULL,'N',NULL),
 (162,55,'Build Path',NULL,'ACT',NULL,'N',NULL),
 (163,56,'Default Component/WebsiteName',NULL,'ACT',NULL,'N',NULL),
 (164,56,'Default Component/ApplicationName',NULL,'ACT',NULL,'N',NULL),
 (165,57,'Default Component/RollbackWeb',NULL,'ACT',NULL,'N',NULL),
 (166,57,'Default Component/WebsiteName',NULL,'ACT',NULL,'N',NULL),
 (167,57,'Default Component/ConStringData',NULL,'ACT',NULL,'N',NULL),
 (168,57,'Default Component/BuildPath',NULL,'ACT',NULL,'N',NULL);
INSERT INTO `nolio_process_parameters` (`parameter_Id`,`process_Id`,`parameter_path_name`,`parameter_value`,`status`,`netra_parameter_name`,`netra_parameter_mapping`,`parameter_scope`) VALUES 
 (169,57,'Default Component/Rollback_String',NULL,'ACT',NULL,'N',NULL),
 (170,57,'Default Component/RemoteAgent',NULL,'ACT',NULL,'N',NULL),
 (171,57,'Default Component/ApplicationName',NULL,'ACT',NULL,'N',NULL),
 (172,57,'Default Component/ConStringName',NULL,'ACT',NULL,'N',NULL),
 (173,58,'Default Component/WebsiteName',NULL,'ACT',NULL,'N',NULL),
 (174,58,'Default Component/Destination',NULL,'ACT',NULL,'N',NULL),
 (175,58,'Default Component/RemoteAgent',NULL,'ACT',NULL,'N',NULL),
 (176,58,'Default Component/ApplicationName',NULL,'ACT',NULL,'N',NULL),
 (177,58,'Default Component/ConStringName',NULL,'ACT',NULL,'N',NULL),
 (178,58,'MSSQL_Connection_DBUrl',NULL,'ACT',NULL,'N',NULL),
 (179,58,'Default Component/build path',NULL,'ACT',NULL,'N',NULL),
 (180,59,'Default Component/RollbackWeb',NULL,'ACT',NULL,'N',NULL),
 (181,59,'Default Component/WebsiteName',NULL,'ACT',NULL,'N',NULL);
INSERT INTO `nolio_process_parameters` (`parameter_Id`,`process_Id`,`parameter_path_name`,`parameter_value`,`status`,`netra_parameter_name`,`netra_parameter_mapping`,`parameter_scope`) VALUES 
 (182,59,'Default Component/ConStringData',NULL,'ACT',NULL,'N',NULL),
 (183,59,'Default Component/Rollback_String',NULL,'ACT',NULL,'N',NULL),
 (184,59,'Default Component/BuildPathTFS',NULL,'ACT',NULL,'N',NULL),
 (185,59,'Default Component/RemoteAgent',NULL,'ACT',NULL,'N',NULL),
 (186,59,'Default Component/ApplicationName',NULL,'ACT',NULL,'N',NULL),
 (187,59,'Default Component/ConStringName',NULL,'ACT',NULL,'N',NULL),
 (188,64,'Default Component/anil_env',NULL,'ACT',NULL,'N',NULL),
 (189,65,'Default Component/TibcoParams/GitServerIp',NULL,'ACT',NULL,'N',NULL),
 (190,65,'Default Component/TibcoParams/TibcoCheckoutFromGit',NULL,'ACT',NULL,'N',NULL),
 (191,65,'Default Component/TibcoParams/TibcoEarFile',NULL,'ACT',NULL,'N',NULL),
 (192,65,'Default Component/TibcoParams/TibcoXmlFile',NULL,'ACT',NULL,'N',NULL),
 (193,65,'Default Component/TibcoParams/TibcoGitRepoName',NULL,'ACT',NULL,'N',NULL);
INSERT INTO `nolio_process_parameters` (`parameter_Id`,`process_Id`,`parameter_path_name`,`parameter_value`,`status`,`netra_parameter_name`,`netra_parameter_mapping`,`parameter_scope`) VALUES 
 (194,65,'Default Component/TibcoParams/NetraServerIp',NULL,'ACT',NULL,'N',NULL),
 (195,66,'Default Component/TibcoParams/TibcoUserName',NULL,'ACT',NULL,'N',NULL),
 (196,66,'Default Component/TibcoParams/TibcoCheckoutFromGit',NULL,'ACT',NULL,'N',NULL),
 (197,66,'Default Component/TibcoParams/TibcoInstallLocation',NULL,'ACT',NULL,'N',NULL),
 (198,66,'Default Component/TibcoParams/TibcoDomainName',NULL,'ACT',NULL,'N',NULL),
 (199,66,'Default Component/TibcoParams/TibcoXmlFile',NULL,'ACT',NULL,'N',NULL),
 (200,66,'Default Component/TibcoParams/TibcoPwd',NULL,'ACT',NULL,'N',NULL),
 (201,66,'Default Component/TibcoParams/ApplicationForTibco',NULL,'ACT',NULL,'N',NULL),
 (202,66,'Default Component/TibcoParams/TibcoGitRepoName',NULL,'ACT',NULL,'N',NULL),
 (203,66,'Default Component/TibcoParams/TibcoEarFile',NULL,'ACT',NULL,'N',NULL),
 (204,67,'Default Component/TibcoParams/TibcoPwd',NULL,'ACT',NULL,'N',NULL);
INSERT INTO `nolio_process_parameters` (`parameter_Id`,`process_Id`,`parameter_path_name`,`parameter_value`,`status`,`netra_parameter_name`,`netra_parameter_mapping`,`parameter_scope`) VALUES 
 (205,67,'Default Component/TibcoParams/TibcoDomainName',NULL,'ACT',NULL,'N',NULL),
 (206,67,'Default Component/TibcoParams/TibcoUserName',NULL,'ACT',NULL,'N',NULL),
 (207,67,'Default Component/TibcoParams/ApplicationForTibco',NULL,'ACT',NULL,'N',NULL),
 (208,67,'Default Component/TibcoParams/TibcoEarFile',NULL,'ACT',NULL,'N',NULL),
 (209,67,'Default Component/TibcoParams/TibcoInstallLocation',NULL,'ACT',NULL,'N',NULL),
 (210,67,'Default Component/TibcoParams/TibcoXmlFile',NULL,'ACT',NULL,'N',NULL),
 (211,68,'Default Component/WebsiteName',NULL,'ACT',NULL,'N',NULL),
 (212,68,'Default Component/ConPath',NULL,'ACT',NULL,'N',NULL),
 (213,68,'Default Component/ConStringName',NULL,'ACT',NULL,'N',NULL),
 (214,68,'Default Component/ApplicationName',NULL,'ACT',NULL,'N',NULL),
 (215,69,'prats_param',NULL,'ACT',NULL,'N',NULL),
 (216,70,'demo1FilePath',NULL,'ACT',NULL,'N',NULL);
INSERT INTO `nolio_process_parameters` (`parameter_Id`,`process_Id`,`parameter_path_name`,`parameter_value`,`status`,`netra_parameter_name`,`netra_parameter_mapping`,`parameter_scope`) VALUES 
 (217,72,'Test_TFS/UserName',NULL,'ACT',NULL,'N',NULL),
 (218,72,'Test_TFS/UserFolder',NULL,'ACT',NULL,'N',NULL),
 (219,72,'Test_TFS/TFS URL',NULL,'ACT',NULL,'N',NULL),
 (220,72,'Test_TFS/Password',NULL,'ACT',NULL,'N',NULL),
 (221,72,'Test_TFS/Server Project Path',NULL,'ACT',NULL,'N',NULL),
 (222,72,'Test_TFS/ApplicationName',NULL,'ACT',NULL,'N',NULL),
 (223,74,'Default Component/BuildPath',NULL,'ACT',NULL,'N',NULL),
 (224,74,'Default Component/FolderName',NULL,'ACT',NULL,'N',NULL),
 (225,74,'Default Component/ApplicationName',NULL,'ACT',NULL,'N',NULL),
 (226,74,'Default Component/TFSAgent',NULL,'ACT',NULL,'N',NULL),
 (227,74,'Default Component/BuildCodePath',NULL,'ACT',NULL,'N',NULL),
 (228,75,'Default Component/BuildPath',NULL,'ACT',NULL,'N',NULL),
 (229,75,'Default Component/FolderName',NULL,'ACT',NULL,'N',NULL),
 (230,75,'Default Component/ApplicationName',NULL,'ACT',NULL,'N',NULL);
INSERT INTO `nolio_process_parameters` (`parameter_Id`,`process_Id`,`parameter_path_name`,`parameter_value`,`status`,`netra_parameter_name`,`netra_parameter_mapping`,`parameter_scope`) VALUES 
 (231,75,'Default Component/TFSAgent',NULL,'ACT',NULL,'N',NULL),
 (232,75,'Default Component/BuildCodePath',NULL,'ACT',NULL,'N',NULL);
/*!40000 ALTER TABLE `nolio_process_parameters` ENABLE KEYS */;


--
-- Definition of table `nolio_software_process_mapping`
--

DROP TABLE IF EXISTS `nolio_software_process_mapping`;
CREATE TABLE `nolio_software_process_mapping` (
  `Software_process_map_Id` int(11) NOT NULL AUTO_INCREMENT,
  `software_config_Id` int(11) NOT NULL,
  `nolio_process_Id` int(11) NOT NULL,
  PRIMARY KEY (`Software_process_map_Id`),
  KEY `FK_Nolio_Software_Process_Mapping_1` (`software_config_Id`),
  KEY `FK_Nolio_Software_Process_Mapping_2` (`nolio_process_Id`),
  CONSTRAINT `FK_Nolio_Software_Process_Mapping_1` FOREIGN KEY (`software_config_Id`) REFERENCES `softwareconfig` (`id`),
  CONSTRAINT `FK_Nolio_Software_Process_Mapping_2` FOREIGN KEY (`nolio_process_Id`) REFERENCES `nolio_process` (`Process_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nolio_software_process_mapping`
--

/*!40000 ALTER TABLE `nolio_software_process_mapping` DISABLE KEYS */;
INSERT INTO `nolio_software_process_mapping` (`Software_process_map_Id`,`software_config_Id`,`nolio_process_Id`) VALUES 
 (1,1,9),
 (2,1,15),
 (3,1,49),
 (4,2,7),
 (5,2,35),
 (6,2,36),
 (7,2,37),
 (8,2,42);
/*!40000 ALTER TABLE `nolio_software_process_mapping` ENABLE KEYS */;


--
-- Definition of table `nolio_task_mapping`
--

DROP TABLE IF EXISTS `nolio_task_mapping`;
CREATE TABLE `nolio_task_mapping` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `taskId` int(11) unsigned NOT NULL,
  `Process_Order` int(11) NOT NULL,
  `Nolio_process_Id` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Nolio_process_mapping` (`Nolio_process_Id`),
  KEY `FK_Nolio_task_mapping` (`taskId`),
  CONSTRAINT `FK_Nolio_process_mapping` FOREIGN KEY (`Nolio_process_Id`) REFERENCES `nolio_process` (`Process_Id`),
  CONSTRAINT `FK_Nolio_task_mapping` FOREIGN KEY (`taskId`) REFERENCES `tasks` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nolio_task_mapping`
--

/*!40000 ALTER TABLE `nolio_task_mapping` DISABLE KEYS */;
/*!40000 ALTER TABLE `nolio_task_mapping` ENABLE KEYS */;


--
-- Definition of table `parameter`
--

DROP TABLE IF EXISTS `parameter`;
CREATE TABLE `parameter` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL DEFAULT '',
  `type` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `parameter`
--

/*!40000 ALTER TABLE `parameter` DISABLE KEYS */;
/*!40000 ALTER TABLE `parameter` ENABLE KEYS */;


--
-- Definition of table `pipeline_request_details`
--

DROP TABLE IF EXISTS `pipeline_request_details`;
CREATE TABLE `pipeline_request_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `request_id` int(10) unsigned NOT NULL,
  `phase_id` int(10) unsigned NOT NULL,
  `environment_id` int(10) unsigned NOT NULL,
  `status_id` int(10) unsigned NOT NULL,
  `phase_execution_order` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_pipeline_request_details_1` (`request_id`),
  KEY `FK_pipeline_request_details_2` (`phase_id`),
  KEY `FK_pipeline_request_details_3` (`environment_id`),
  KEY `FK_pipeline_request_details_4` (`status_id`),
  CONSTRAINT `FK_pipeline_request_details_1` FOREIGN KEY (`request_id`) REFERENCES `service_request` (`Request_id`),
  CONSTRAINT `FK_pipeline_request_details_2` FOREIGN KEY (`phase_id`) REFERENCES `testing_phase` (`id`),
  CONSTRAINT `FK_pipeline_request_details_3` FOREIGN KEY (`environment_id`) REFERENCES `environments` (`ID`),
  CONSTRAINT `FK_pipeline_request_details_4` FOREIGN KEY (`status_id`) REFERENCES `status` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pipeline_request_details`
--

/*!40000 ALTER TABLE `pipeline_request_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `pipeline_request_details` ENABLE KEYS */;


--
-- Definition of table `platform_template`
--

DROP TABLE IF EXISTS `platform_template`;
CREATE TABLE `platform_template` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `type` varchar(45) NOT NULL,
  `family` varchar(45) NOT NULL,
  `distribution` varchar(45) DEFAULT NULL,
  `version` varchar(45) DEFAULT NULL,
  `pack` varchar(45) DEFAULT NULL,
  `architecture` varchar(45) DEFAULT NULL,
  `status` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `platform_template`
--

/*!40000 ALTER TABLE `platform_template` DISABLE KEYS */;
INSERT INTO `platform_template` (`id`,`name`,`type`,`family`,`distribution`,`version`,`pack`,`architecture`,`status`) VALUES 
 (1,'Temp1','VMWARE','FT2_Linux','FT2_D1_RHEL','FT2_D1_V1_6','FT2_D2_V1_P1_1.0','FT2_D1_V1_A1_x64',177),
 (2,'Temp2','VMWARE','FT2_Linux','FT2_D1_RHEL','FT2_D1_V1_6','FT2_D2_V1_P1_1.0','FT2_D1_V1_A1_x64',177);
/*!40000 ALTER TABLE `platform_template` ENABLE KEYS */;


--
-- Definition of table `platform_template_aws`
--

DROP TABLE IF EXISTS `platform_template_aws`;
CREATE TABLE `platform_template_aws` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `aws_account_id` int(11) NOT NULL,
  `image_id` varchar(80) NOT NULL,
  `platform_template_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `platform_template_id2` (`platform_template_id`),
  CONSTRAINT `platform_template_id2` FOREIGN KEY (`platform_template_id`) REFERENCES `platform_template` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `platform_template_aws`
--

/*!40000 ALTER TABLE `platform_template_aws` DISABLE KEYS */;
/*!40000 ALTER TABLE `platform_template_aws` ENABLE KEYS */;


--
-- Definition of table `platform_template_azure`
--

DROP TABLE IF EXISTS `platform_template_azure`;
CREATE TABLE `platform_template_azure` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `platform_template_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `platform_template_id_3` (`platform_template_id`),
  CONSTRAINT `platform_template_id_3` FOREIGN KEY (`platform_template_id`) REFERENCES `platform_template` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `platform_template_azure`
--

/*!40000 ALTER TABLE `platform_template_azure` DISABLE KEYS */;
/*!40000 ALTER TABLE `platform_template_azure` ENABLE KEYS */;


--
-- Definition of table `platform_template_os`
--

DROP TABLE IF EXISTS `platform_template_os`;
CREATE TABLE `platform_template_os` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `image_id` varchar(45) NOT NULL,
  `platform_template_id` int(10) unsigned NOT NULL,
  `image_name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_platform_template_os_1` (`platform_template_id`),
  CONSTRAINT `FK_platform_template_os_1` FOREIGN KEY (`platform_template_id`) REFERENCES `platform_template` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `platform_template_os`
--

/*!40000 ALTER TABLE `platform_template_os` DISABLE KEYS */;
/*!40000 ALTER TABLE `platform_template_os` ENABLE KEYS */;


--
-- Definition of table `platform_template_vmware`
--

DROP TABLE IF EXISTS `platform_template_vmware`;
CREATE TABLE `platform_template_vmware` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `platform_template_id` int(10) unsigned DEFAULT NULL,
  `vm_template_name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `platform_template_id` (`platform_template_id`),
  CONSTRAINT `platform_template_id` FOREIGN KEY (`platform_template_id`) REFERENCES `platform_template` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `platform_template_vmware`
--

/*!40000 ALTER TABLE `platform_template_vmware` DISABLE KEYS */;
INSERT INTO `platform_template_vmware` (`id`,`platform_template_id`,`vm_template_name`) VALUES 
 (1,1,'RHEL Test'),
 (2,2,'NETRAV3_LinuxTemplate');
/*!40000 ALTER TABLE `platform_template_vmware` ENABLE KEYS */;


--
-- Definition of table `platform_tmplt_vmware_barmtl`
--

DROP TABLE IF EXISTS `platform_tmplt_vmware_barmtl`;
CREATE TABLE `platform_tmplt_vmware_barmtl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `platform_template_id` int(10) unsigned NOT NULL,
  `iso_file_path` varchar(5000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `platform_tmplt_vmware_barmtl`
--

/*!40000 ALTER TABLE `platform_tmplt_vmware_barmtl` DISABLE KEYS */;
/*!40000 ALTER TABLE `platform_tmplt_vmware_barmtl` ENABLE KEYS */;


--
-- Definition of table `platform_type`
--

DROP TABLE IF EXISTS `platform_type`;
CREATE TABLE `platform_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(45) NOT NULL,
  `label` varchar(45) NOT NULL,
  `value` varchar(45) NOT NULL,
  `vmware_guest_id` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `platform_type`
--

/*!40000 ALTER TABLE `platform_type` DISABLE KEYS */;
INSERT INTO `platform_type` (`id`,`type`,`label`,`value`,`vmware_guest_id`) VALUES 
 (1,'Family','Windows','FT1_Windows',NULL),
 (2,'Distribution','Server','FT1_D1_Server',NULL),
 (3,'Family','Linux','FT2_Linux',NULL),
 (4,'Distribution','RHEL','FT2_D1_RHEL',NULL),
 (5,'Distribution','UBUNTU','FT2_D2_UBUNTU',NULL),
 (6,'Version','6','FT2_D1_V1_6',NULL),
 (7,'Architecture','x64','FT2_D1_V1_A1_x64','other26xlinux-64'),
 (8,'Version','1','FT2_D2_V1_1',NULL),
 (9,'Architecture','x64','FT2_D2_V1_A1_x64',NULL),
 (10,'Version','2008','FT1_D1_V1_2008',NULL),
 (11,'Pack','R2','FT1_D1_V1_P1_R2',NULL),
 (12,'Architecture','x64','FT1_D1_V1_P1_A1_x64',NULL),
 (13,'Architecture','x86','FT2_D1_V1_A2_x86',NULL),
 (14,'Pack','1.0','FT2_D2_V1_P1_1.0',NULL),
 (15,'Pack','1.1','FT2_D1_V1_P1_1.1',NULL);
/*!40000 ALTER TABLE `platform_type` ENABLE KEYS */;


--
-- Definition of table `policy_details`
--

DROP TABLE IF EXISTS `policy_details`;
CREATE TABLE `policy_details` (
  `Id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `POLICY_NAME` varchar(45) NOT NULL,
  `POLICY_DESCRIPTION` varchar(450) DEFAULT NULL,
  `CLOUD_TYPE` varchar(45) NOT NULL,
  `VM_NAME_TEMPLATE` varchar(45) NOT NULL,
  `HOST_NAME` varchar(45) NOT NULL,
  `DHCP_FLAG` varchar(1) NOT NULL,
  `SUBNET_MASK` varchar(45) NOT NULL,
  `DOMAIN` varchar(45) NOT NULL,
  `GATEWAY` varchar(45) NOT NULL,
  `TIMEZONE` varchar(45) NOT NULL,
  `DNS_SERVER` varchar(45) NOT NULL,
  `STATUS` varchar(45) NOT NULL,
  `DATA_CENTER` int(10) unsigned DEFAULT NULL,
  `DATA_STORE` varchar(45) DEFAULT NULL,
  `KICKSTART_IP` varchar(45) DEFAULT NULL,
  `KICKSTART_USERNAME` varchar(45) DEFAULT NULL,
  `KICKSTART_PASSWORD` varchar(45) DEFAULT NULL,
  `KICKSTART_CONFIG_FILENAME` varchar(45) DEFAULT NULL,
  `STATIC_IP` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `policy_details`
--

/*!40000 ALTER TABLE `policy_details` DISABLE KEYS */;
INSERT INTO `policy_details` (`Id`,`POLICY_NAME`,`POLICY_DESCRIPTION`,`CLOUD_TYPE`,`VM_NAME_TEMPLATE`,`HOST_NAME`,`DHCP_FLAG`,`SUBNET_MASK`,`DOMAIN`,`GATEWAY`,`TIMEZONE`,`DNS_SERVER`,`STATUS`,`DATA_CENTER`,`DATA_STORE`,`KICKSTART_IP`,`KICKSTART_USERNAME`,`KICKSTART_PASSWORD`,`KICKSTART_CONFIG_FILENAME`,`STATIC_IP`) VALUES 
 (1,'AD_Policy','AD_Policy','DATA CENTRE','VM{NUMBER}_{REQUESTID}_EV_{ENVIRONMENTID}','VM{NUMBER}_{REQUESTID}_EV_{ENVIRONMENTID}','Y','255.255.255.0','asulabsir.com','138.120.70.1','Asia/Kolkata','138.120.73.66','ACT',1,'TEMS-3 DS',NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `policy_details` ENABLE KEYS */;


--
-- Definition of table `policy_mapping`
--

DROP TABLE IF EXISTS `policy_mapping`;
CREATE TABLE `policy_mapping` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bu` int(11) NOT NULL,
  `project_id` int(11) DEFAULT NULL,
  `application_id` int(11) DEFAULT NULL,
  `policy_detail_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `policy_mapping`
--

/*!40000 ALTER TABLE `policy_mapping` DISABLE KEYS */;
INSERT INTO `policy_mapping` (`id`,`bu`,`project_id`,`application_id`,`policy_detail_id`) VALUES 
 (1,2,NULL,NULL,1);
/*!40000 ALTER TABLE `policy_mapping` ENABLE KEYS */;


--
-- Definition of table `pp_act_exec_order`
--

DROP TABLE IF EXISTS `pp_act_exec_order`;
CREATE TABLE `pp_act_exec_order` (
  `Act_Exec_Id` int(11) NOT NULL AUTO_INCREMENT,
  `act_soft_map_id` int(10) unsigned NOT NULL,
  `Link_Act_Id` int(10) unsigned NOT NULL,
  `Execution_Order` int(11) NOT NULL,
  PRIMARY KEY (`Act_Exec_Id`),
  KEY `pp_act_soft_map_id1` (`act_soft_map_id`),
  KEY `pp_act_soft_map_id2` (`Link_Act_Id`),
  CONSTRAINT `pp_act_soft_map_id1` FOREIGN KEY (`act_soft_map_id`) REFERENCES `pp_act_soft_mapping` (`act_soft_map_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `pp_act_soft_map_id2` FOREIGN KEY (`Link_Act_Id`) REFERENCES `pp_act_soft_mapping` (`act_soft_map_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pp_act_exec_order`
--

/*!40000 ALTER TABLE `pp_act_exec_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `pp_act_exec_order` ENABLE KEYS */;


--
-- Definition of table `pp_act_proc_order`
--

DROP TABLE IF EXISTS `pp_act_proc_order`;
CREATE TABLE `pp_act_proc_order` (
  `Act_Proc_Id` int(11) NOT NULL AUTO_INCREMENT,
  `pp_soft_proc_map_id` int(11) NOT NULL,
  `Process_Order` int(11) NOT NULL,
  `Act_Sftwr_Map_Id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`Act_Proc_Id`),
  KEY `pp_act_rel_Order1` (`pp_soft_proc_map_id`),
  CONSTRAINT `pp_act_rel_Order1` FOREIGN KEY (`pp_soft_proc_map_id`) REFERENCES `pp_soft_proc_mapping` (`Soft_proc_map_Id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pp_act_proc_order`
--

/*!40000 ALTER TABLE `pp_act_proc_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `pp_act_proc_order` ENABLE KEYS */;


--
-- Definition of table `pp_act_soft_mapping`
--

DROP TABLE IF EXISTS `pp_act_soft_mapping`;
CREATE TABLE `pp_act_soft_mapping` (
  `act_soft_map_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `soft_config_Id` int(10) unsigned NOT NULL,
  `activity_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`act_soft_map_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pp_act_soft_mapping`
--

/*!40000 ALTER TABLE `pp_act_soft_mapping` DISABLE KEYS */;
/*!40000 ALTER TABLE `pp_act_soft_mapping` ENABLE KEYS */;


--
-- Definition of table `pp_master_details`
--

DROP TABLE IF EXISTS `pp_master_details`;
CREATE TABLE `pp_master_details` (
  `pp_master_id` int(11) NOT NULL AUTO_INCREMENT,
  `pp_master_USERNAME` varchar(110) NOT NULL,
  `pp_master_PASSWORD` varchar(110) NOT NULL,
  `pp_master_IPADDR` varchar(111) NOT NULL,
  `pp_master_HOSTNAME` varchar(111) NOT NULL,
  `pp_master_DOMAINNAME` varchar(250) DEFAULT NULL,
  `pp_master_STATUS` varchar(250) DEFAULT NULL,
  `pp_master_Process_Path` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`pp_master_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pp_master_details`
--

/*!40000 ALTER TABLE `pp_master_details` DISABLE KEYS */;
INSERT INTO `pp_master_details` (`pp_master_id`,`pp_master_USERNAME`,`pp_master_PASSWORD`,`pp_master_IPADDR`,`pp_master_HOSTNAME`,`pp_master_DOMAINNAME`,`pp_master_STATUS`,`pp_master_Process_Path`) VALUES 
 (1,'root','tcs#1234','10.130.25.79','INCHNSIRASUVM79','asulabsir.com','ACT','/root/SoftwareProcess');
/*!40000 ALTER TABLE `pp_master_details` ENABLE KEYS */;


--
-- Definition of table `pp_proc_param`
--

DROP TABLE IF EXISTS `pp_proc_param`;
CREATE TABLE `pp_proc_param` (
  `parameter_Id` int(11) NOT NULL AUTO_INCREMENT,
  `process_Id` int(11) NOT NULL,
  `param_path_name` varchar(200) NOT NULL,
  `para_value` varchar(200) DEFAULT NULL,
  `status` varchar(3) DEFAULT NULL,
  PRIMARY KEY (`parameter_Id`),
  KEY `FK_pp_proc_param_1` (`process_Id`),
  KEY `pp_param_unique_Index1` (`process_Id`,`param_path_name`),
  CONSTRAINT `FK_pp_proc_param_1` FOREIGN KEY (`process_Id`) REFERENCES `pp_process` (`Process_Id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pp_proc_param`
--

/*!40000 ALTER TABLE `pp_proc_param` DISABLE KEYS */;
/*!40000 ALTER TABLE `pp_proc_param` ENABLE KEYS */;


--
-- Definition of table `pp_process`
--

DROP TABLE IF EXISTS `pp_process`;
CREATE TABLE `pp_process` (
  `Process_Id` int(11) NOT NULL AUTO_INCREMENT,
  `Proc_Full_Path` varchar(200) NOT NULL DEFAULT '',
  `Status` varchar(3) NOT NULL,
  PRIMARY KEY (`Process_Id`),
  UNIQUE KEY `Index_2` (`Proc_Full_Path`),
  KEY `Unique_Index` (`Proc_Full_Path`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pp_process`
--

/*!40000 ALTER TABLE `pp_process` DISABLE KEYS */;
/*!40000 ALTER TABLE `pp_process` ENABLE KEYS */;


--
-- Definition of table `pp_rel_activity`
--

DROP TABLE IF EXISTS `pp_rel_activity`;
CREATE TABLE `pp_rel_activity` (
  `Activity_Id` int(11) NOT NULL AUTO_INCREMENT,
  `Activity_Name` varchar(45) NOT NULL,
  `Application_specific` char(1) NOT NULL,
  PRIMARY KEY (`Activity_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pp_rel_activity`
--

/*!40000 ALTER TABLE `pp_rel_activity` DISABLE KEYS */;
INSERT INTO `pp_rel_activity` (`Activity_Id`,`Activity_Name`,`Application_specific`) VALUES 
 (1,'Installation','N'),
 (2,'Execute Database Scripts','N'),
 (3,'Application Deployment','Y'),
 (4,'JNDI Name','Y'),
 (5,'Server Restart','Y'),
 (6,'Application Undeployment','Y');
/*!40000 ALTER TABLE `pp_rel_activity` ENABLE KEYS */;


--
-- Definition of table `pp_soft_proc_mapping`
--

DROP TABLE IF EXISTS `pp_soft_proc_mapping`;
CREATE TABLE `pp_soft_proc_mapping` (
  `Soft_proc_map_Id` int(11) NOT NULL AUTO_INCREMENT,
  `soft_config_Id` int(11) NOT NULL,
  `pp_process_Id` int(11) NOT NULL,
  PRIMARY KEY (`Soft_proc_map_Id`),
  KEY `pp_soft_proc_map_id1` (`soft_config_Id`),
  KEY `pp_soft_proc_map_id2` (`pp_process_Id`),
  CONSTRAINT `pp_soft_proc_map_id1` FOREIGN KEY (`soft_config_Id`) REFERENCES `softwareconfig` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `pp_soft_proc_map_id2` FOREIGN KEY (`pp_process_Id`) REFERENCES `pp_process` (`Process_Id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pp_soft_proc_mapping`
--

/*!40000 ALTER TABLE `pp_soft_proc_mapping` DISABLE KEYS */;
/*!40000 ALTER TABLE `pp_soft_proc_mapping` ENABLE KEYS */;


--
-- Definition of table `pricing_model`
--

DROP TABLE IF EXISTS `pricing_model`;
CREATE TABLE `pricing_model` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `model_name` varchar(30) NOT NULL,
  `description` varchar(100) DEFAULT NULL,
  `enroll_cost` varchar(20) NOT NULL,
  `billing_frequrency` varchar(100) DEFAULT NULL,
  `active_cost` int(10) NOT NULL,
  `inactive_cost` int(10) NOT NULL,
  `charges_per_CPU` varchar(20) NOT NULL,
  `charges_per_memory` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pricing_model`
--

/*!40000 ALTER TABLE `pricing_model` DISABLE KEYS */;
/*!40000 ALTER TABLE `pricing_model` ENABLE KEYS */;


--
-- Definition of table `pricing_model_project_mapping`
--

DROP TABLE IF EXISTS `pricing_model_project_mapping`;
CREATE TABLE `pricing_model_project_mapping` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `model` int(10) unsigned NOT NULL,
  `projectId` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_model_id` (`model`),
  KEY `FK_client_clientId` (`projectId`),
  CONSTRAINT `FK_client_clientId` FOREIGN KEY (`projectId`) REFERENCES `projects` (`ID`),
  CONSTRAINT `FK_model_id` FOREIGN KEY (`model`) REFERENCES `pricing_model` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pricing_model_project_mapping`
--

/*!40000 ALTER TABLE `pricing_model_project_mapping` DISABLE KEYS */;
/*!40000 ALTER TABLE `pricing_model_project_mapping` ENABLE KEYS */;


--
-- Definition of table `projects`
--

DROP TABLE IF EXISTS `projects`;
CREATE TABLE `projects` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `NAME` varchar(45) NOT NULL,
  `CLIENT_ID` int(10) unsigned NOT NULL,
  `STATUS` int(10) unsigned NOT NULL,
  `REMARK` varchar(200) DEFAULT NULL,
  `PROJECT_OWNER_ID` int(11) DEFAULT NULL,
  `PROJECT_TYPE` varchar(200) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_projects_client_id` (`CLIENT_ID`),
  KEY `FK_projects_status` (`STATUS`),
  CONSTRAINT `FK_projects_client` FOREIGN KEY (`CLIENT_ID`) REFERENCES `client` (`CLIENT_ID`),
  CONSTRAINT `FK_projects_status` FOREIGN KEY (`STATUS`) REFERENCES `status` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `projects`
--

/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
INSERT INTO `projects` (`ID`,`NAME`,`CLIENT_ID`,`STATUS`,`REMARK`,`PROJECT_OWNER_ID`,`PROJECT_TYPE`) VALUES 
 (1,'Project',2,31,'',3,'Agile');
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;


--
-- Definition of table `provisioned_machine`
--

DROP TABLE IF EXISTS `provisioned_machine`;
CREATE TABLE `provisioned_machine` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `CREATED_BY` int(10) unsigned DEFAULT NULL,
  `CREATED_DATE` datetime DEFAULT NULL,
  `MODIFIED_BY` int(10) unsigned DEFAULT NULL,
  `MODIFIED_DATE` datetime DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `hostname` varchar(45) DEFAULT NULL,
  `cpu` int(10) DEFAULT NULL,
  `ram` int(10) DEFAULT NULL,
  `architecture` varchar(45) DEFAULT NULL,
  `provisioned_machine_type` varchar(45) DEFAULT NULL,
  `virtual_machine_type` varchar(45) DEFAULT NULL,
  `perishable_flag` varchar(45) DEFAULT NULL,
  `provisioned_pltfrm_tmplt_id` int(10) unsigned NOT NULL,
  `provisioned_status` varchar(45) DEFAULT NULL,
  `mac_address` varchar(45) DEFAULT NULL,
  `remarks` varchar(45) DEFAULT NULL,
  `status` varchar(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_provisioned_machine_template_3` (`provisioned_pltfrm_tmplt_id`),
  CONSTRAINT `FK_provisioned_machine_template_3` FOREIGN KEY (`provisioned_pltfrm_tmplt_id`) REFERENCES `provisioned_platform` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `provisioned_machine`
--

/*!40000 ALTER TABLE `provisioned_machine` DISABLE KEYS */;
INSERT INTO `provisioned_machine` (`id`,`name`,`CREATED_BY`,`CREATED_DATE`,`MODIFIED_BY`,`MODIFIED_DATE`,`ip`,`hostname`,`cpu`,`ram`,`architecture`,`provisioned_machine_type`,`virtual_machine_type`,`perishable_flag`,`provisioned_pltfrm_tmplt_id`,`provisioned_status`,`mac_address`,`remarks`,`status`) VALUES 
 (1,'VM1_1_EV_1',NULL,NULL,NULL,'2016-07-04 16:56:25',NULL,NULL,1,2048,'64-bit','VIRTUAL','VMWARE',NULL,1,NULL,NULL,NULL,NULL),
 (2,'VM1_2_EV_2',NULL,'2016-07-04 17:07:43',NULL,'2016-07-04 16:59:39','10.130.25.174','TEMSVMI221',1,2048,'64-bit','VIRTUAL','VMWARE',NULL,2,'AVAILABLE',NULL,NULL,'ACT'),
 (3,'Linux436',0,NULL,3,'2016-07-05 00:00:00','10.130.25.231','TEMSVMI1271',2,2048,'FT2_D1_V1_A1_x64','PHYSICAL',NULL,'N',3,'AVAILABLE','00:50:56:89:58:93','','ACT'),
 (4,'VM1_4_EV_4',NULL,NULL,NULL,'2016-07-04 18:01:23',NULL,NULL,1,2048,'64-bit','VIRTUAL','VMWARE',NULL,4,NULL,NULL,NULL,NULL),
 (5,'VM1_7_EV_5',NULL,'2016-07-05 13:31:02',NULL,'2016-07-05 13:22:55','10.130.25.197','TEMSVMI751',1,2048,'64-bit','VIRTUAL','VMWARE',NULL,5,'AVAILABLE',NULL,NULL,'ACT'),
 (6,'Linux197',3,'2016-07-05 00:00:00',0,NULL,'10.130.25.197','TEMSVMI751',2,2048,'FT2_D1_V1_A1_x64','PHYSICAL',NULL,'N',6,'AVAILABLE','00:50:56:89:19:32','','ACT');
INSERT INTO `provisioned_machine` (`id`,`name`,`CREATED_BY`,`CREATED_DATE`,`MODIFIED_BY`,`MODIFIED_DATE`,`ip`,`hostname`,`cpu`,`ram`,`architecture`,`provisioned_machine_type`,`virtual_machine_type`,`perishable_flag`,`provisioned_pltfrm_tmplt_id`,`provisioned_status`,`mac_address`,`remarks`,`status`) VALUES 
 (7,'VM1_9_EV_7',NULL,'2016-07-07 16:52:23',NULL,'2016-07-07 16:43:39','10.130.25.181','TEMSVMI971',1,2048,'64-bit','VIRTUAL','VMWARE',NULL,7,'AVAILABLE',NULL,NULL,'ACT'),
 (8,'VM1_10_EV_8',NULL,'2016-07-07 17:49:30',NULL,'2016-07-07 17:41:18','10.130.25.220','TEMSVMI1081',1,2048,'64-bit','VIRTUAL','VMWARE',NULL,8,'AVAILABLE',NULL,NULL,'ACT'),
 (9,'Server2',0,NULL,3,'2016-07-12 00:00:00','10.130.25.220','TEMSVMI190741',2,2048,'FT2_D1_V1_A1_x64','PHYSICAL',NULL,'N',9,'AVAILABLE','00:50:56:89:4D:8C','','ACT'),
 (10,'VM1_27_EV_11',NULL,'2016-07-11 18:09:45',NULL,'2016-07-11 17:58:36','10.130.25.220','TEMSVMI27111',2,4096,'64-bit','VIRTUAL','VMWARE',NULL,10,'AVAILABLE',NULL,NULL,'ACT'),
 (11,'VM1_31_EV_13',NULL,'2016-07-13 17:33:00',NULL,'2016-07-13 17:22:08','10.130.25.250','TEMSVMI31131',2,4096,'64-bit','VIRTUAL','VMWARE',NULL,11,'AVAILABLE',NULL,NULL,'ACT');
INSERT INTO `provisioned_machine` (`id`,`name`,`CREATED_BY`,`CREATED_DATE`,`MODIFIED_BY`,`MODIFIED_DATE`,`ip`,`hostname`,`cpu`,`ram`,`architecture`,`provisioned_machine_type`,`virtual_machine_type`,`perishable_flag`,`provisioned_pltfrm_tmplt_id`,`provisioned_status`,`mac_address`,`remarks`,`status`) VALUES 
 (12,'VM1_32_EV_14',NULL,'2016-07-13 18:10:30',NULL,'2016-07-13 17:59:46','10.130.25.77','TEMSVMI32141',2,4096,'64-bit','VIRTUAL','VMWARE',NULL,12,'AVAILABLE',NULL,NULL,'ACT');
/*!40000 ALTER TABLE `provisioned_machine` ENABLE KEYS */;


--
-- Definition of table `provisioned_machine_aws`
--

DROP TABLE IF EXISTS `provisioned_machine_aws`;
CREATE TABLE `provisioned_machine_aws` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `aws_account_id` int(11) DEFAULT NULL,
  `provisioned_machine_id` int(10) unsigned DEFAULT NULL,
  `instance_type` varchar(15) DEFAULT NULL,
  `key_pair` varchar(100) DEFAULT NULL,
  `availability_zone` varchar(100) DEFAULT NULL,
  `security_groups` text,
  `provisioned_template_id` int(10) unsigned DEFAULT NULL,
  `prvsnd_machine_tmplt_id` int(10) unsigned DEFAULT NULL,
  `server_group` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_provisioned_machine_aws_1` (`provisioned_machine_id`),
  KEY `FK_provisioned_machine_template_aws_2` (`prvsnd_machine_tmplt_id`) USING BTREE,
  CONSTRAINT `FK_provisioned_machine_template_aws_2` FOREIGN KEY (`prvsnd_machine_tmplt_id`) REFERENCES `provisioned_machine` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `provisioned_machine_aws`
--

/*!40000 ALTER TABLE `provisioned_machine_aws` DISABLE KEYS */;
/*!40000 ALTER TABLE `provisioned_machine_aws` ENABLE KEYS */;


--
-- Definition of table `provisioned_machine_azure`
--

DROP TABLE IF EXISTS `provisioned_machine_azure`;
CREATE TABLE `provisioned_machine_azure` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `prvsnd_machine_tmplt_id` int(10) unsigned DEFAULT NULL,
  `username` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_provisioned_machine_template_azure_1` (`prvsnd_machine_tmplt_id`) USING BTREE,
  CONSTRAINT `FK_provisioned_machine_template_azure_1` FOREIGN KEY (`prvsnd_machine_tmplt_id`) REFERENCES `provisioned_machine` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `provisioned_machine_azure`
--

/*!40000 ALTER TABLE `provisioned_machine_azure` DISABLE KEYS */;
/*!40000 ALTER TABLE `provisioned_machine_azure` ENABLE KEYS */;


--
-- Definition of table `provisioned_machine_os`
--

DROP TABLE IF EXISTS `provisioned_machine_os`;
CREATE TABLE `provisioned_machine_os` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `flavor_type` varchar(45) NOT NULL,
  `flavor_id` varchar(45) NOT NULL,
  `provisioned_machine_id` int(10) unsigned NOT NULL,
  `server_id` varchar(150) DEFAULT NULL,
  `disk` varchar(45) DEFAULT NULL,
  `username` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_provisioned_machine_os_1` (`provisioned_machine_id`),
  CONSTRAINT `FK_provisioned_machine_os_1` FOREIGN KEY (`provisioned_machine_id`) REFERENCES `provisioned_machine` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `provisioned_machine_os`
--

/*!40000 ALTER TABLE `provisioned_machine_os` DISABLE KEYS */;
/*!40000 ALTER TABLE `provisioned_machine_os` ENABLE KEYS */;


--
-- Definition of table `provisioned_machine_physical`
--

DROP TABLE IF EXISTS `provisioned_machine_physical`;
CREATE TABLE `provisioned_machine_physical` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `provisioned_machine_id` int(10) unsigned NOT NULL,
  `username` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_provisioned_machine_physical_1` (`provisioned_machine_id`),
  CONSTRAINT `FK_provisioned_machine_physical_1` FOREIGN KEY (`provisioned_machine_id`) REFERENCES `provisioned_machine` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `provisioned_machine_physical`
--

/*!40000 ALTER TABLE `provisioned_machine_physical` DISABLE KEYS */;
INSERT INTO `provisioned_machine_physical` (`id`,`provisioned_machine_id`,`username`,`password`) VALUES 
 (1,3,'root','UFIi4dTHno5cYF0QRoGyF3Ylms3fCND8'),
 (2,6,'root','8bLmN5ZL8/qHWVvE/cvdheUQmpMT9uxA'),
 (3,9,'root','oJW6VPqNpPtadmFq6dk7RmZ0CchDf4Om');
/*!40000 ALTER TABLE `provisioned_machine_physical` ENABLE KEYS */;


--
-- Definition of table `provisioned_machine_vmware`
--

DROP TABLE IF EXISTS `provisioned_machine_vmware`;
CREATE TABLE `provisioned_machine_vmware` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `prvsnd_machine_tmplt_id` int(10) unsigned DEFAULT NULL,
  `username` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_provisioned_machine_template_vmware_2` (`prvsnd_machine_tmplt_id`),
  CONSTRAINT `FK_provisioned_machine_template_vmware_2` FOREIGN KEY (`prvsnd_machine_tmplt_id`) REFERENCES `provisioned_machine` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `provisioned_machine_vmware`
--

/*!40000 ALTER TABLE `provisioned_machine_vmware` DISABLE KEYS */;
INSERT INTO `provisioned_machine_vmware` (`id`,`prvsnd_machine_tmplt_id`,`username`,`password`) VALUES 
 (1,1,'root','vQidDWWy+dDuLEdVh18bX3cYCOMkeMNM'),
 (2,2,'root','vQidDWWy+dDuLEdVh18bX3cYCOMkeMNM'),
 (3,4,'root','vQidDWWy+dDuLEdVh18bX3cYCOMkeMNM'),
 (4,5,'root','vQidDWWy+dDuLEdVh18bX3cYCOMkeMNM'),
 (5,7,'root','vQidDWWy+dDuLEdVh18bX3cYCOMkeMNM'),
 (6,8,'root','vQidDWWy+dDuLEdVh18bX3cYCOMkeMNM'),
 (7,10,'root','8+zePfBRfjqqQnNqaAItDdDh1vE7YS/+'),
 (8,11,'root','8+zePfBRfjqqQnNqaAItDdDh1vE7YS/+'),
 (9,12,'root','8+zePfBRfjqqQnNqaAItDdDh1vE7YS/+');
/*!40000 ALTER TABLE `provisioned_machine_vmware` ENABLE KEYS */;


--
-- Definition of table `provisioned_platform`
--

DROP TABLE IF EXISTS `provisioned_platform`;
CREATE TABLE `provisioned_platform` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `family` varchar(45) DEFAULT NULL,
  `distribution` varchar(45) DEFAULT NULL,
  `version` varchar(45) DEFAULT NULL,
  `pack` varchar(45) DEFAULT NULL,
  `architecture` varchar(45) DEFAULT NULL,
  `pltfrm_tmplt_status` int(10) unsigned DEFAULT '177',
  `platform_template_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_provisioned_platform_template_1` (`platform_template_id`),
  CONSTRAINT `FK_provisioned_platform_template_1` FOREIGN KEY (`platform_template_id`) REFERENCES `platform_template` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `provisioned_platform`
--

/*!40000 ALTER TABLE `provisioned_platform` DISABLE KEYS */;
INSERT INTO `provisioned_platform` (`id`,`name`,`type`,`family`,`distribution`,`version`,`pack`,`architecture`,`pltfrm_tmplt_status`,`platform_template_id`) VALUES 
 (1,'Temp1','VMWARE','FT2_Linux','FT2_D1_RHEL','FT2_D1_V1_6','FT2_D2_V1_P1_1.0','FT2_D1_V1_A1_x64',177,1),
 (2,'Temp1','VMWARE','FT2_Linux','FT2_D1_RHEL','FT2_D1_V1_6','FT2_D2_V1_P1_1.0','FT2_D1_V1_A1_x64',177,1),
 (3,'Linux436','PHYSICAL','FT2_Linux','FT2_D1_RHEL','FT2_D1_V1_6','FT2_D2_V1_P1_1.0','FT2_D1_V1_A1_x64',177,NULL),
 (4,'Temp1','VMWARE','FT2_Linux','FT2_D1_RHEL','FT2_D1_V1_6','FT2_D2_V1_P1_1.0','FT2_D1_V1_A1_x64',177,1),
 (5,'Temp1','VMWARE','FT2_Linux','FT2_D1_RHEL','FT2_D1_V1_6','FT2_D2_V1_P1_1.0','FT2_D1_V1_A1_x64',177,1),
 (6,'Linux197','PHYSICAL','FT2_Linux','FT2_D1_RHEL','FT2_D1_V1_6','FT2_D2_V1_P1_1.0','FT2_D1_V1_A1_x64',177,NULL),
 (7,'Temp1','VMWARE','FT2_Linux','FT2_D1_RHEL','FT2_D1_V1_6','FT2_D2_V1_P1_1.0','FT2_D1_V1_A1_x64',177,1),
 (8,'Temp1','VMWARE','FT2_Linux','FT2_D1_RHEL','FT2_D1_V1_6','FT2_D2_V1_P1_1.0','FT2_D1_V1_A1_x64',177,1),
 (9,'Server2','PHYSICAL','FT2_Linux','FT2_D1_RHEL','FT2_D1_V1_6','FT2_D2_V1_P1_1.0','FT2_D1_V1_A1_x64',177,NULL);
INSERT INTO `provisioned_platform` (`id`,`name`,`type`,`family`,`distribution`,`version`,`pack`,`architecture`,`pltfrm_tmplt_status`,`platform_template_id`) VALUES 
 (10,'Temp2','VMWARE','FT2_Linux','FT2_D1_RHEL','FT2_D1_V1_6','FT2_D2_V1_P1_1.0','FT2_D1_V1_A1_x64',177,2),
 (11,'Temp2','VMWARE','FT2_Linux','FT2_D1_RHEL','FT2_D1_V1_6','FT2_D2_V1_P1_1.0','FT2_D1_V1_A1_x64',177,2),
 (12,'Temp2','VMWARE','FT2_Linux','FT2_D1_RHEL','FT2_D1_V1_6','FT2_D2_V1_P1_1.0','FT2_D1_V1_A1_x64',177,2);
/*!40000 ALTER TABLE `provisioned_platform` ENABLE KEYS */;


--
-- Definition of table `provisioned_platform_aws`
--

DROP TABLE IF EXISTS `provisioned_platform_aws`;
CREATE TABLE `provisioned_platform_aws` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `aws_account_id` int(11) DEFAULT NULL,
  `provisioned_template_id` int(10) unsigned DEFAULT NULL,
  `image_id` varchar(80) DEFAULT NULL,
  `provisioned_pltfrm_tmplt_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_provisioned_templates_aws_1` (`provisioned_template_id`),
  KEY `FK_provisioned_platform_template_aws_2` (`provisioned_pltfrm_tmplt_id`),
  CONSTRAINT `FK_provisioned_platform_template_aws_2` FOREIGN KEY (`provisioned_pltfrm_tmplt_id`) REFERENCES `provisioned_platform` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `provisioned_platform_aws`
--

/*!40000 ALTER TABLE `provisioned_platform_aws` DISABLE KEYS */;
/*!40000 ALTER TABLE `provisioned_platform_aws` ENABLE KEYS */;


--
-- Definition of table `provisioned_platform_azure`
--

DROP TABLE IF EXISTS `provisioned_platform_azure`;
CREATE TABLE `provisioned_platform_azure` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `provisioned_pltfrm_tmplt_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_provisioned_platform_template_azure_1` (`provisioned_pltfrm_tmplt_id`),
  CONSTRAINT `FK_provisioned_platform_template_azure_1` FOREIGN KEY (`provisioned_pltfrm_tmplt_id`) REFERENCES `provisioned_platform` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `provisioned_platform_azure`
--

/*!40000 ALTER TABLE `provisioned_platform_azure` DISABLE KEYS */;
/*!40000 ALTER TABLE `provisioned_platform_azure` ENABLE KEYS */;


--
-- Definition of table `provisioned_platform_os`
--

DROP TABLE IF EXISTS `provisioned_platform_os`;
CREATE TABLE `provisioned_platform_os` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `image_id` varchar(45) NOT NULL,
  `provisioned_platform_id` int(10) unsigned NOT NULL,
  `image_name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_provisioned_platform_os_1` (`provisioned_platform_id`),
  CONSTRAINT `FK_provisioned_platform_os_1` FOREIGN KEY (`provisioned_platform_id`) REFERENCES `provisioned_platform` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `provisioned_platform_os`
--

/*!40000 ALTER TABLE `provisioned_platform_os` DISABLE KEYS */;
/*!40000 ALTER TABLE `provisioned_platform_os` ENABLE KEYS */;


--
-- Definition of table `provisioned_platform_vmware`
--

DROP TABLE IF EXISTS `provisioned_platform_vmware`;
CREATE TABLE `provisioned_platform_vmware` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `provisioned_template_id` int(10) unsigned DEFAULT NULL,
  `provisioned_pltfrm_tmplt_id` int(10) unsigned DEFAULT NULL,
  `vm_template_name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_provisioned_templates_vmware_1` (`provisioned_template_id`),
  KEY `FK_provisioned_platform_template_vmware_2` (`provisioned_pltfrm_tmplt_id`),
  CONSTRAINT `FK_provisioned_platform_template_vmware_2` FOREIGN KEY (`provisioned_pltfrm_tmplt_id`) REFERENCES `provisioned_platform` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `provisioned_platform_vmware`
--

/*!40000 ALTER TABLE `provisioned_platform_vmware` DISABLE KEYS */;
INSERT INTO `provisioned_platform_vmware` (`id`,`provisioned_template_id`,`provisioned_pltfrm_tmplt_id`,`vm_template_name`) VALUES 
 (1,NULL,1,'RHEL Test'),
 (2,NULL,2,'RHEL Test'),
 (3,NULL,4,'RHEL Test'),
 (4,NULL,5,'RHEL Test'),
 (5,NULL,7,'RHEL Test'),
 (6,NULL,8,'RHEL Test'),
 (7,NULL,10,'NETRAV3_LinuxTemplate'),
 (8,NULL,11,'NETRAV3_LinuxTemplate'),
 (9,NULL,12,'NETRAV3_LinuxTemplate');
/*!40000 ALTER TABLE `provisioned_platform_vmware` ENABLE KEYS */;


--
-- Definition of table `provsnd_machine_vmware_barmtl`
--

DROP TABLE IF EXISTS `provsnd_machine_vmware_barmtl`;
CREATE TABLE `provsnd_machine_vmware_barmtl` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `prvsnd_machine_tmplt_id` int(10) unsigned DEFAULT NULL,
  `username` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `Disk_Mode` varchar(45) DEFAULT NULL,
  `Hard_Disk_Size` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_provisioned_machine_vmware_baremetal_1` (`prvsnd_machine_tmplt_id`) USING BTREE,
  CONSTRAINT `FK_provisioned_machine_vmware_baremetal_1` FOREIGN KEY (`prvsnd_machine_tmplt_id`) REFERENCES `provisioned_machine` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `provsnd_machine_vmware_barmtl`
--

/*!40000 ALTER TABLE `provsnd_machine_vmware_barmtl` DISABLE KEYS */;
/*!40000 ALTER TABLE `provsnd_machine_vmware_barmtl` ENABLE KEYS */;


--
-- Definition of table `provsnd_pltfrm_vmware_barmtl`
--

DROP TABLE IF EXISTS `provsnd_pltfrm_vmware_barmtl`;
CREATE TABLE `provsnd_pltfrm_vmware_barmtl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `provisioned_pltfrm_tmplt_id` int(10) unsigned NOT NULL,
  `iso_File_Path` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_provisioned_platform_vmware_baremetal_1` (`provisioned_pltfrm_tmplt_id`),
  CONSTRAINT `FK_provisioned_platform_vmware_baremetal_1` FOREIGN KEY (`provisioned_pltfrm_tmplt_id`) REFERENCES `provisioned_platform` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `provsnd_pltfrm_vmware_barmtl`
--

/*!40000 ALTER TABLE `provsnd_pltfrm_vmware_barmtl` DISABLE KEYS */;
/*!40000 ALTER TABLE `provsnd_pltfrm_vmware_barmtl` ENABLE KEYS */;


--
-- Definition of table `puppet_task_mapping`
--

DROP TABLE IF EXISTS `puppet_task_mapping`;
CREATE TABLE `puppet_task_mapping` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `taskId` int(11) unsigned NOT NULL,
  `Process_Order` int(11) NOT NULL,
  `Puppet_process_Id` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Puppet_process_mapping` (`Puppet_process_Id`),
  KEY `FK_Puppet_task_mapping` (`taskId`),
  CONSTRAINT `FK_Puppet_process_mapping` FOREIGN KEY (`Puppet_process_Id`) REFERENCES `pp_process` (`Process_Id`),
  CONSTRAINT `FK_Puppet_task_mapping` FOREIGN KEY (`taskId`) REFERENCES `tasks` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `puppet_task_mapping`
--

/*!40000 ALTER TABLE `puppet_task_mapping` DISABLE KEYS */;
/*!40000 ALTER TABLE `puppet_task_mapping` ENABLE KEYS */;


--
-- Definition of table `qrtz_blob_triggers`
--

DROP TABLE IF EXISTS `qrtz_blob_triggers`;
CREATE TABLE `qrtz_blob_triggers` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `BLOB_DATA` blob,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`),
  CONSTRAINT `qrtz_blob_triggers_ibfk_1` FOREIGN KEY (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`) REFERENCES `qrtz_triggers` (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `qrtz_blob_triggers`
--

/*!40000 ALTER TABLE `qrtz_blob_triggers` DISABLE KEYS */;
/*!40000 ALTER TABLE `qrtz_blob_triggers` ENABLE KEYS */;


--
-- Definition of table `qrtz_calendars`
--

DROP TABLE IF EXISTS `qrtz_calendars`;
CREATE TABLE `qrtz_calendars` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `CALENDAR_NAME` varchar(200) NOT NULL,
  `CALENDAR` blob NOT NULL,
  PRIMARY KEY (`SCHED_NAME`,`CALENDAR_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `qrtz_calendars`
--

/*!40000 ALTER TABLE `qrtz_calendars` DISABLE KEYS */;
/*!40000 ALTER TABLE `qrtz_calendars` ENABLE KEYS */;


--
-- Definition of table `qrtz_cron_triggers`
--

DROP TABLE IF EXISTS `qrtz_cron_triggers`;
CREATE TABLE `qrtz_cron_triggers` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `CRON_EXPRESSION` varchar(200) NOT NULL,
  `TIME_ZONE_ID` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`),
  CONSTRAINT `qrtz_cron_triggers_ibfk_1` FOREIGN KEY (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`) REFERENCES `qrtz_triggers` (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `qrtz_cron_triggers`
--

/*!40000 ALTER TABLE `qrtz_cron_triggers` DISABLE KEYS */;
INSERT INTO `qrtz_cron_triggers` (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`,`CRON_EXPRESSION`,`TIME_ZONE_ID`) VALUES 
 ('NETRA_SCHEDULER','Trigger Key DeploymentPipeline','System Triggers','0 0/10 * 1/1 * ? *','Etc/UTC'),
 ('NETRA_SCHEDULER','Trigger Key EnvironmentDeletion','System Triggers','0 0 21 1/1 * ? *','Etc/UTC'),
 ('NETRA_SCHEDULER','Trigger Key JiraDeploymentPipeline','System Triggers','0 0/10 * 1/1 * ? *','Etc/UTC'),
 ('NETRA_SCHEDULER','Trigger Key ReservationExpiration Mail','System Triggers','0 23 15 1/1 * ? *','Etc/UTC');
/*!40000 ALTER TABLE `qrtz_cron_triggers` ENABLE KEYS */;


--
-- Definition of table `qrtz_fired_triggers`
--

DROP TABLE IF EXISTS `qrtz_fired_triggers`;
CREATE TABLE `qrtz_fired_triggers` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `ENTRY_ID` varchar(95) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `INSTANCE_NAME` varchar(200) NOT NULL,
  `FIRED_TIME` bigint(13) NOT NULL,
  `SCHED_TIME` bigint(13) NOT NULL,
  `PRIORITY` int(11) NOT NULL,
  `STATE` varchar(16) NOT NULL,
  `JOB_NAME` varchar(200) DEFAULT NULL,
  `JOB_GROUP` varchar(200) DEFAULT NULL,
  `IS_NONCONCURRENT` varchar(1) DEFAULT NULL,
  `REQUESTS_RECOVERY` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`SCHED_NAME`,`ENTRY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `qrtz_fired_triggers`
--

/*!40000 ALTER TABLE `qrtz_fired_triggers` DISABLE KEYS */;
/*!40000 ALTER TABLE `qrtz_fired_triggers` ENABLE KEYS */;


--
-- Definition of table `qrtz_job_details`
--

DROP TABLE IF EXISTS `qrtz_job_details`;
CREATE TABLE `qrtz_job_details` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `JOB_NAME` varchar(200) NOT NULL,
  `JOB_GROUP` varchar(200) NOT NULL,
  `DESCRIPTION` varchar(250) DEFAULT NULL,
  `JOB_CLASS_NAME` varchar(250) NOT NULL,
  `IS_DURABLE` varchar(1) NOT NULL,
  `IS_NONCONCURRENT` varchar(1) NOT NULL,
  `IS_UPDATE_DATA` varchar(1) NOT NULL,
  `REQUESTS_RECOVERY` varchar(1) NOT NULL,
  `JOB_DATA` blob,
  PRIMARY KEY (`SCHED_NAME`,`JOB_NAME`,`JOB_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `qrtz_job_details`
--

/*!40000 ALTER TABLE `qrtz_job_details` DISABLE KEYS */;
INSERT INTO `qrtz_job_details` (`SCHED_NAME`,`JOB_NAME`,`JOB_GROUP`,`DESCRIPTION`,`JOB_CLASS_NAME`,`IS_DURABLE`,`IS_NONCONCURRENT`,`IS_UPDATE_DATA`,`REQUESTS_RECOVERY`,`JOB_DATA`) VALUES 
 ('NETRA_SCHEDULER','Job Key DeploymentPipeline','System Jobs',NULL,'com.netra.batch.job.DeploymentPipelineJob','0','0','0','0',0xACED0005737200156F72672E71756172747A2E4A6F62446174614D61709FB083E8BFA9B0CB020000787200266F72672E71756172747A2E7574696C732E537472696E674B65794469727479466C61674D61708208E8C3FBC55D280200015A0013616C6C6F77735472616E7369656E74446174617872001D6F72672E71756172747A2E7574696C732E4469727479466C61674D617013E62EAD28760ACE0200025A000564697274794C00036D617074000F4C6A6176612F7574696C2F4D61703B787000737200116A6176612E7574696C2E486173684D61700507DAC1C31660D103000246000A6C6F6164466163746F724900097468726573686F6C6478703F4000000000000F770800000010000000007800),
 ('NETRA_SCHEDULER','Job Key EnvironmentDeletion','System Jobs',NULL,'com.netra.batch.job.EnvironmentDeletionAndExpirationMailJob','0','0','0','0',0xACED0005737200156F72672E71756172747A2E4A6F62446174614D61709FB083E8BFA9B0CB020000787200266F72672E71756172747A2E7574696C732E537472696E674B65794469727479466C61674D61708208E8C3FBC55D280200015A0013616C6C6F77735472616E7369656E74446174617872001D6F72672E71756172747A2E7574696C732E4469727479466C61674D617013E62EAD28760ACE0200025A000564697274794C00036D617074000F4C6A6176612F7574696C2F4D61703B787000737200116A6176612E7574696C2E486173684D61700507DAC1C31660D103000246000A6C6F6164466163746F724900097468726573686F6C6478703F4000000000000F770800000010000000007800),
 ('NETRA_SCHEDULER','Job Key JiraDeploymentPipeline','System Jobs',NULL,'com.netra.batch.job.DeploymentPipelineUsingJira','0','0','0','0',0xACED0005737200156F72672E71756172747A2E4A6F62446174614D61709FB083E8BFA9B0CB020000787200266F72672E71756172747A2E7574696C732E537472696E674B65794469727479466C61674D61708208E8C3FBC55D280200015A0013616C6C6F77735472616E7369656E74446174617872001D6F72672E71756172747A2E7574696C732E4469727479466C61674D617013E62EAD28760ACE0200025A000564697274794C00036D617074000F4C6A6176612F7574696C2F4D61703B787000737200116A6176612E7574696C2E486173684D61700507DAC1C31660D103000246000A6C6F6164466163746F724900097468726573686F6C6478703F4000000000000F770800000010000000007800);
INSERT INTO `qrtz_job_details` (`SCHED_NAME`,`JOB_NAME`,`JOB_GROUP`,`DESCRIPTION`,`JOB_CLASS_NAME`,`IS_DURABLE`,`IS_NONCONCURRENT`,`IS_UPDATE_DATA`,`REQUESTS_RECOVERY`,`JOB_DATA`) VALUES 
 ('NETRA_SCHEDULER','Job Key Reservation Expiration Mail','System Jobs',NULL,'com.netra.batch.job.ReservationExpirationMailJob','0','0','0','0',0xACED0005737200156F72672E71756172747A2E4A6F62446174614D61709FB083E8BFA9B0CB020000787200266F72672E71756172747A2E7574696C732E537472696E674B65794469727479466C61674D61708208E8C3FBC55D280200015A0013616C6C6F77735472616E7369656E74446174617872001D6F72672E71756172747A2E7574696C732E4469727479466C61674D617013E62EAD28760ACE0200025A000564697274794C00036D617074000F4C6A6176612F7574696C2F4D61703B787000737200116A6176612E7574696C2E486173684D61700507DAC1C31660D103000246000A6C6F6164466163746F724900097468726573686F6C6478703F4000000000000F770800000010000000007800);
/*!40000 ALTER TABLE `qrtz_job_details` ENABLE KEYS */;


--
-- Definition of table `qrtz_locks`
--

DROP TABLE IF EXISTS `qrtz_locks`;
CREATE TABLE `qrtz_locks` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `LOCK_NAME` varchar(40) NOT NULL,
  PRIMARY KEY (`SCHED_NAME`,`LOCK_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `qrtz_locks`
--

/*!40000 ALTER TABLE `qrtz_locks` DISABLE KEYS */;
INSERT INTO `qrtz_locks` (`SCHED_NAME`,`LOCK_NAME`) VALUES 
 ('NETRA_SCHEDULER','TRIGGER_ACCESS');
/*!40000 ALTER TABLE `qrtz_locks` ENABLE KEYS */;


--
-- Definition of table `qrtz_paused_trigger_grps`
--

DROP TABLE IF EXISTS `qrtz_paused_trigger_grps`;
CREATE TABLE `qrtz_paused_trigger_grps` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `qrtz_paused_trigger_grps`
--

/*!40000 ALTER TABLE `qrtz_paused_trigger_grps` DISABLE KEYS */;
/*!40000 ALTER TABLE `qrtz_paused_trigger_grps` ENABLE KEYS */;


--
-- Definition of table `qrtz_scheduler_state`
--

DROP TABLE IF EXISTS `qrtz_scheduler_state`;
CREATE TABLE `qrtz_scheduler_state` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `INSTANCE_NAME` varchar(200) NOT NULL,
  `LAST_CHECKIN_TIME` bigint(13) NOT NULL,
  `CHECKIN_INTERVAL` bigint(13) NOT NULL,
  PRIMARY KEY (`SCHED_NAME`,`INSTANCE_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `qrtz_scheduler_state`
--

/*!40000 ALTER TABLE `qrtz_scheduler_state` DISABLE KEYS */;
/*!40000 ALTER TABLE `qrtz_scheduler_state` ENABLE KEYS */;


--
-- Definition of table `qrtz_simple_triggers`
--

DROP TABLE IF EXISTS `qrtz_simple_triggers`;
CREATE TABLE `qrtz_simple_triggers` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `REPEAT_COUNT` bigint(7) NOT NULL,
  `REPEAT_INTERVAL` bigint(12) NOT NULL,
  `TIMES_TRIGGERED` bigint(10) NOT NULL,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`),
  CONSTRAINT `qrtz_simple_triggers_ibfk_1` FOREIGN KEY (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`) REFERENCES `qrtz_triggers` (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `qrtz_simple_triggers`
--

/*!40000 ALTER TABLE `qrtz_simple_triggers` DISABLE KEYS */;
/*!40000 ALTER TABLE `qrtz_simple_triggers` ENABLE KEYS */;


--
-- Definition of table `qrtz_simprop_triggers`
--

DROP TABLE IF EXISTS `qrtz_simprop_triggers`;
CREATE TABLE `qrtz_simprop_triggers` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `STR_PROP_1` varchar(512) DEFAULT NULL,
  `STR_PROP_2` varchar(512) DEFAULT NULL,
  `STR_PROP_3` varchar(512) DEFAULT NULL,
  `INT_PROP_1` int(11) DEFAULT NULL,
  `INT_PROP_2` int(11) DEFAULT NULL,
  `LONG_PROP_1` bigint(20) DEFAULT NULL,
  `LONG_PROP_2` bigint(20) DEFAULT NULL,
  `DEC_PROP_1` decimal(13,4) DEFAULT NULL,
  `DEC_PROP_2` decimal(13,4) DEFAULT NULL,
  `BOOL_PROP_1` varchar(1) DEFAULT NULL,
  `BOOL_PROP_2` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`),
  CONSTRAINT `qrtz_simprop_triggers_ibfk_1` FOREIGN KEY (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`) REFERENCES `qrtz_triggers` (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `qrtz_simprop_triggers`
--

/*!40000 ALTER TABLE `qrtz_simprop_triggers` DISABLE KEYS */;
/*!40000 ALTER TABLE `qrtz_simprop_triggers` ENABLE KEYS */;


--
-- Definition of table `qrtz_triggers`
--

DROP TABLE IF EXISTS `qrtz_triggers`;
CREATE TABLE `qrtz_triggers` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `JOB_NAME` varchar(200) NOT NULL,
  `JOB_GROUP` varchar(200) NOT NULL,
  `DESCRIPTION` varchar(250) DEFAULT NULL,
  `NEXT_FIRE_TIME` bigint(13) DEFAULT NULL,
  `PREV_FIRE_TIME` bigint(13) DEFAULT NULL,
  `PRIORITY` int(11) DEFAULT NULL,
  `TRIGGER_STATE` varchar(16) NOT NULL,
  `TRIGGER_TYPE` varchar(8) NOT NULL,
  `START_TIME` bigint(13) NOT NULL,
  `END_TIME` bigint(13) DEFAULT NULL,
  `CALENDAR_NAME` varchar(200) DEFAULT NULL,
  `MISFIRE_INSTR` smallint(2) DEFAULT NULL,
  `JOB_DATA` blob,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`),
  KEY `SCHED_NAME` (`SCHED_NAME`,`JOB_NAME`,`JOB_GROUP`),
  CONSTRAINT `qrtz_triggers_ibfk_1` FOREIGN KEY (`SCHED_NAME`, `JOB_NAME`, `JOB_GROUP`) REFERENCES `qrtz_job_details` (`SCHED_NAME`, `JOB_NAME`, `JOB_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `qrtz_triggers`
--

/*!40000 ALTER TABLE `qrtz_triggers` DISABLE KEYS */;
INSERT INTO `qrtz_triggers` (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`,`JOB_NAME`,`JOB_GROUP`,`DESCRIPTION`,`NEXT_FIRE_TIME`,`PREV_FIRE_TIME`,`PRIORITY`,`TRIGGER_STATE`,`TRIGGER_TYPE`,`START_TIME`,`END_TIME`,`CALENDAR_NAME`,`MISFIRE_INSTR`,`JOB_DATA`) VALUES 
 ('NETRA_SCHEDULER','Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs',NULL,1469017200000,1469016600000,5,'WAITING','CRON',1469016532000,0,NULL,0,''),
 ('NETRA_SCHEDULER','Trigger Key EnvironmentDeletion','System Triggers','Job Key EnvironmentDeletion','System Jobs',NULL,1469048400000,-1,5,'WAITING','CRON',1469016532000,0,NULL,0,''),
 ('NETRA_SCHEDULER','Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs',NULL,1469017200000,1469016600000,5,'WAITING','CRON',1469016532000,0,NULL,0,''),
 ('NETRA_SCHEDULER','Trigger Key ReservationExpiration Mail','System Triggers','Job Key Reservation Expiration Mail','System Jobs',NULL,1469028180000,-1,5,'WAITING','CRON',1469016532000,0,NULL,0,'');
/*!40000 ALTER TABLE `qrtz_triggers` ENABLE KEYS */;


--
-- Definition of table `quartz_history`
--

DROP TABLE IF EXISTS `quartz_history`;
CREATE TABLE `quartz_history` (
  `trigger_name` varchar(200) NOT NULL,
  `trigger_group` varchar(200) NOT NULL,
  `job_name` varchar(200) NOT NULL,
  `job_group` varchar(200) NOT NULL,
  `trigger_status` varchar(60) NOT NULL,
  `status` varchar(60) NOT NULL,
  `created_by` varchar(20) NOT NULL,
  `fired_time` datetime NOT NULL,
  `misfired_time` datetime DEFAULT NULL,
  `completed_time` datetime DEFAULT NULL,
  `request_id` int(10) unsigned DEFAULT NULL,
  `unique_id` varchar(200) NOT NULL,
  PRIMARY KEY (`unique_id`),
  KEY `Index_request_id` (`request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `quartz_history`
--

/*!40000 ALTER TABLE `quartz_history` DISABLE KEYS */;
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 12:36:26',NULL,'2016-07-04 12:36:26',NULL,'NON_CLUSTERED1467615947432'),
 ('Trigger Key ReservationExpiration Mail','System Triggers','Job Key Reservation Expiration Mail','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 12:36:26',NULL,'2016-07-04 12:36:26',NULL,'NON_CLUSTERED1467615947433'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 12:40:00',NULL,'2016-07-04 12:40:00',NULL,'NON_CLUSTERED1467615947434'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 12:40:00',NULL,'2016-07-04 12:40:00',NULL,'NON_CLUSTERED1467615947435'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 12:50:00',NULL,'2016-07-04 12:50:00',NULL,'NON_CLUSTERED1467615947436');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 12:50:00',NULL,'2016-07-04 12:50:00',NULL,'NON_CLUSTERED1467615947437'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 13:00:00',NULL,'2016-07-04 13:00:00',NULL,'NON_CLUSTERED1467615947438'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 13:00:01',NULL,'2016-07-04 13:00:01',NULL,'NON_CLUSTERED1467615947439'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 13:10:00',NULL,'2016-07-04 13:10:00',NULL,'NON_CLUSTERED1467615947440'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 13:10:00',NULL,'2016-07-04 13:10:00',NULL,'NON_CLUSTERED1467615947441');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 13:20:00',NULL,'2016-07-04 13:20:00',NULL,'NON_CLUSTERED1467615947442'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 13:20:00',NULL,'2016-07-04 13:20:00',NULL,'NON_CLUSTERED1467615947443'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 13:30:00',NULL,'2016-07-04 13:30:00',NULL,'NON_CLUSTERED1467615947444'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 13:30:00',NULL,'2016-07-04 13:30:00',NULL,'NON_CLUSTERED1467615947445'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 13:40:00',NULL,'2016-07-04 13:40:00',NULL,'NON_CLUSTERED1467615947446');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 13:40:00',NULL,'2016-07-04 13:40:00',NULL,'NON_CLUSTERED1467615947447'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 13:50:00',NULL,'2016-07-04 13:50:00',NULL,'NON_CLUSTERED1467615947448'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 13:50:00',NULL,'2016-07-04 13:50:00',NULL,'NON_CLUSTERED1467615947449'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 14:00:00',NULL,'2016-07-04 14:00:00',NULL,'NON_CLUSTERED1467615947450'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 14:00:00',NULL,'2016-07-04 14:00:00',NULL,'NON_CLUSTERED1467615947451');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 14:10:00',NULL,'2016-07-04 14:10:00',NULL,'NON_CLUSTERED1467615947452'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 14:10:00',NULL,'2016-07-04 14:10:00',NULL,'NON_CLUSTERED1467615947453'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 14:20:00',NULL,'2016-07-04 14:20:00',NULL,'NON_CLUSTERED1467615947454'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 14:20:00',NULL,'2016-07-04 14:20:00',NULL,'NON_CLUSTERED1467615947455'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 14:30:00',NULL,'2016-07-04 14:30:00',NULL,'NON_CLUSTERED1467615947456');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 14:30:00',NULL,'2016-07-04 14:30:00',NULL,'NON_CLUSTERED1467615947457'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 14:40:00',NULL,'2016-07-04 14:40:00',NULL,'NON_CLUSTERED1467615947458'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 14:40:00',NULL,'2016-07-04 14:40:00',NULL,'NON_CLUSTERED1467615947459'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 14:50:00',NULL,'2016-07-04 14:50:00',NULL,'NON_CLUSTERED1467615947460'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 14:50:00',NULL,'2016-07-04 14:50:00',NULL,'NON_CLUSTERED1467615947461');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 15:00:00',NULL,'2016-07-04 15:00:00',NULL,'NON_CLUSTERED1467615947462'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 15:00:00',NULL,'2016-07-04 15:00:00',NULL,'NON_CLUSTERED1467615947463'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 15:10:00',NULL,'2016-07-04 15:10:00',NULL,'NON_CLUSTERED1467615947464'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 15:10:00',NULL,'2016-07-04 15:10:00',NULL,'NON_CLUSTERED1467615947465'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 15:20:00',NULL,'2016-07-04 15:20:00',NULL,'NON_CLUSTERED1467615947466');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 15:20:00',NULL,'2016-07-04 15:20:00',NULL,'NON_CLUSTERED1467615947467'),
 ('Trigger Key ReservationExpiration Mail','System Triggers','Job Key Reservation Expiration Mail','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 15:23:00',NULL,'2016-07-04 15:23:00',NULL,'NON_CLUSTERED1467615947468'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 15:30:00',NULL,'2016-07-04 15:30:00',NULL,'NON_CLUSTERED1467615947469'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 15:30:00',NULL,'2016-07-04 15:30:00',NULL,'NON_CLUSTERED1467615947470'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 15:40:00',NULL,'2016-07-04 15:40:00',NULL,'NON_CLUSTERED1467615947471');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 15:40:00',NULL,'2016-07-04 15:40:00',NULL,'NON_CLUSTERED1467615947472'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 15:50:00',NULL,'2016-07-04 15:50:00',NULL,'NON_CLUSTERED1467615947473'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 15:50:00',NULL,'2016-07-04 15:50:00',NULL,'NON_CLUSTERED1467615947474'),
 ('triggerkey_1','triggerkeyGroup_1','jobkey_1','jobkeyGroup_1','DELETE TRIGGER','COMPLETED','SYSTEM','2016-07-04 16:56:27',NULL,'2016-07-04 16:56:42',1,'NON_CLUSTERED1467628830100'),
 ('triggerkey_2','triggerkeyGroup_2','jobkey_2','jobkeyGroup_2','DELETE TRIGGER','COMPLETED','SYSTEM','2016-07-04 16:59:40',NULL,'2016-07-04 17:07:56',2,'NON_CLUSTERED1467628830102');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 17:00:00',NULL,'2016-07-04 17:00:00',NULL,'NON_CLUSTERED1467628830103'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 17:00:00',NULL,'2016-07-04 17:00:00',NULL,'NON_CLUSTERED1467628830104'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 17:10:00',NULL,'2016-07-04 17:10:00',NULL,'NON_CLUSTERED1467628830105'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 17:10:00',NULL,'2016-07-04 17:10:00',NULL,'NON_CLUSTERED1467628830106'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 17:20:00',NULL,'2016-07-04 17:20:00',NULL,'NON_CLUSTERED1467628830107');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 17:20:00',NULL,'2016-07-04 17:20:00',NULL,'NON_CLUSTERED1467628830108'),
 ('triggerkey_3','triggerkeyGroup_3','jobkey_3','jobkeyGroup_3','DELETE TRIGGER','COMPLETED','SYSTEM','2016-07-04 17:21:15',NULL,'2016-07-04 17:21:29',3,'NON_CLUSTERED1467628830109'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 17:30:00',NULL,'2016-07-04 17:30:00',NULL,'NON_CLUSTERED1467628830110'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 17:30:00',NULL,'2016-07-04 17:30:00',NULL,'NON_CLUSTERED1467628830111'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 17:40:00',NULL,'2016-07-04 17:40:00',NULL,'NON_CLUSTERED1467628830112');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 17:40:00',NULL,'2016-07-04 17:40:00',NULL,'NON_CLUSTERED1467628830113'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 17:50:00',NULL,'2016-07-04 17:50:00',NULL,'NON_CLUSTERED1467628830114'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 17:50:00',NULL,'2016-07-04 17:50:00',NULL,'NON_CLUSTERED1467628830115'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 18:00:00',NULL,'2016-07-04 18:00:00',NULL,'NON_CLUSTERED1467628830116'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 18:00:00',NULL,'2016-07-04 18:00:00',NULL,'NON_CLUSTERED1467628830117');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('triggerkey_4','triggerkeyGroup_4','jobkey_4','jobkeyGroup_4','DELETE TRIGGER','COMPLETED','SYSTEM','2016-07-04 18:01:24',NULL,'2016-07-04 18:01:34',4,'NON_CLUSTERED1467628830118'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 18:10:00',NULL,'2016-07-04 18:10:00',NULL,'NON_CLUSTERED1467628830119'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 18:10:00',NULL,'2016-07-04 18:10:00',NULL,'NON_CLUSTERED1467628830120'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 18:20:00',NULL,'2016-07-04 18:20:00',NULL,'NON_CLUSTERED1467628830121'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 18:20:00',NULL,'2016-07-04 18:20:00',NULL,'NON_CLUSTERED1467628830122');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 18:30:00',NULL,'2016-07-04 18:30:00',NULL,'NON_CLUSTERED1467628830123'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 18:30:00',NULL,'2016-07-04 18:30:00',NULL,'NON_CLUSTERED1467628830124'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 18:40:00',NULL,'2016-07-04 18:40:00',NULL,'NON_CLUSTERED1467628830125'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 18:40:00',NULL,'2016-07-04 18:40:00',NULL,'NON_CLUSTERED1467628830126'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 18:50:00',NULL,'2016-07-04 18:50:00',NULL,'NON_CLUSTERED1467628830127');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 18:50:00',NULL,'2016-07-04 18:50:00',NULL,'NON_CLUSTERED1467628830128'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 19:00:00',NULL,'2016-07-04 19:00:00',NULL,'NON_CLUSTERED1467628830129'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 19:00:00',NULL,'2016-07-04 19:00:00',NULL,'NON_CLUSTERED1467628830130'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 19:10:00',NULL,'2016-07-04 19:10:00',NULL,'NON_CLUSTERED1467628830131'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 19:10:00',NULL,'2016-07-04 19:10:00',NULL,'NON_CLUSTERED1467628830132');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 19:20:00',NULL,'2016-07-04 19:20:00',NULL,'NON_CLUSTERED1467628830133'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 19:20:00',NULL,'2016-07-04 19:20:00',NULL,'NON_CLUSTERED1467628830134'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 19:30:00',NULL,'2016-07-04 19:30:00',NULL,'NON_CLUSTERED1467628830135'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 19:30:00',NULL,'2016-07-04 19:30:00',NULL,'NON_CLUSTERED1467628830136'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 19:40:00',NULL,'2016-07-04 19:40:00',NULL,'NON_CLUSTERED1467628830137');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 19:40:00',NULL,'2016-07-04 19:40:00',NULL,'NON_CLUSTERED1467628830138'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 19:50:00',NULL,'2016-07-04 19:50:00',NULL,'NON_CLUSTERED1467628830139'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 19:50:00',NULL,'2016-07-04 19:50:00',NULL,'NON_CLUSTERED1467628830140'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 20:00:00',NULL,'2016-07-04 20:00:00',NULL,'NON_CLUSTERED1467628830141'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 20:00:00',NULL,'2016-07-04 20:00:00',NULL,'NON_CLUSTERED1467628830142');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 20:10:00',NULL,'2016-07-04 20:10:00',NULL,'NON_CLUSTERED1467628830143'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 20:10:00',NULL,'2016-07-04 20:10:00',NULL,'NON_CLUSTERED1467628830144'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 20:20:00',NULL,'2016-07-04 20:20:00',NULL,'NON_CLUSTERED1467628830145'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 20:20:00',NULL,'2016-07-04 20:20:00',NULL,'NON_CLUSTERED1467628830146'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 20:30:00',NULL,'2016-07-04 20:30:00',NULL,'NON_CLUSTERED1467628830147');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 20:30:00',NULL,'2016-07-04 20:30:00',NULL,'NON_CLUSTERED1467628830148'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 20:40:00',NULL,'2016-07-04 20:40:00',NULL,'NON_CLUSTERED1467628830149'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 20:40:00',NULL,'2016-07-04 20:40:00',NULL,'NON_CLUSTERED1467628830150'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 20:50:00',NULL,'2016-07-04 20:50:00',NULL,'NON_CLUSTERED1467628830151'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 20:50:00',NULL,'2016-07-04 20:50:00',NULL,'NON_CLUSTERED1467628830152');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 21:00:00',NULL,'2016-07-04 21:00:00',NULL,'NON_CLUSTERED1467628830153'),
 ('Trigger Key EnvironmentDeletion','System Triggers','Job Key EnvironmentDeletion','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 21:00:00',NULL,'2016-07-04 21:00:00',NULL,'NON_CLUSTERED1467628830154'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 21:00:00',NULL,'2016-07-04 21:00:00',NULL,'NON_CLUSTERED1467628830155'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 21:10:00',NULL,'2016-07-04 21:10:00',NULL,'NON_CLUSTERED1467628830156'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 21:10:00',NULL,'2016-07-04 21:10:00',NULL,'NON_CLUSTERED1467628830157');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 21:20:00',NULL,'2016-07-04 21:20:00',NULL,'NON_CLUSTERED1467628830158'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 21:20:00',NULL,'2016-07-04 21:20:00',NULL,'NON_CLUSTERED1467628830159'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 21:30:00',NULL,'2016-07-04 21:30:00',NULL,'NON_CLUSTERED1467628830160'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 21:30:00',NULL,'2016-07-04 21:30:00',NULL,'NON_CLUSTERED1467628830161'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 21:40:00',NULL,'2016-07-04 21:40:00',NULL,'NON_CLUSTERED1467628830162');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 21:40:00',NULL,'2016-07-04 21:40:00',NULL,'NON_CLUSTERED1467628830163'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 21:50:00',NULL,'2016-07-04 21:50:00',NULL,'NON_CLUSTERED1467628830164'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 21:50:00',NULL,'2016-07-04 21:50:00',NULL,'NON_CLUSTERED1467628830165'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 22:00:00',NULL,'2016-07-04 22:00:00',NULL,'NON_CLUSTERED1467628830166'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 22:00:00',NULL,'2016-07-04 22:00:00',NULL,'NON_CLUSTERED1467628830167');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 22:10:00',NULL,'2016-07-04 22:10:00',NULL,'NON_CLUSTERED1467628830168'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 22:10:00',NULL,'2016-07-04 22:10:00',NULL,'NON_CLUSTERED1467628830169'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 22:20:00',NULL,'2016-07-04 22:20:00',NULL,'NON_CLUSTERED1467628830170'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 22:20:00',NULL,'2016-07-04 22:20:00',NULL,'NON_CLUSTERED1467628830171'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 22:30:00',NULL,'2016-07-04 22:30:00',NULL,'NON_CLUSTERED1467628830172');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 22:30:00',NULL,'2016-07-04 22:30:00',NULL,'NON_CLUSTERED1467628830173'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 22:40:00',NULL,'2016-07-04 22:40:00',NULL,'NON_CLUSTERED1467628830174'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 22:40:00',NULL,'2016-07-04 22:40:00',NULL,'NON_CLUSTERED1467628830175'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 22:50:00',NULL,'2016-07-04 22:50:00',NULL,'NON_CLUSTERED1467628830176'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 22:50:00',NULL,'2016-07-04 22:50:00',NULL,'NON_CLUSTERED1467628830177');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 23:00:00',NULL,'2016-07-04 23:00:00',NULL,'NON_CLUSTERED1467628830178'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 23:00:00',NULL,'2016-07-04 23:00:00',NULL,'NON_CLUSTERED1467628830179'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 23:10:00',NULL,'2016-07-04 23:10:00',NULL,'NON_CLUSTERED1467628830180'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 23:10:00',NULL,'2016-07-04 23:10:00',NULL,'NON_CLUSTERED1467628830181'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 23:20:00',NULL,'2016-07-04 23:20:00',NULL,'NON_CLUSTERED1467628830182');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 23:20:00',NULL,'2016-07-04 23:20:00',NULL,'NON_CLUSTERED1467628830183'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 23:30:00',NULL,'2016-07-04 23:30:00',NULL,'NON_CLUSTERED1467628830184'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 23:30:00',NULL,'2016-07-04 23:30:00',NULL,'NON_CLUSTERED1467628830185'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 23:40:00',NULL,'2016-07-04 23:40:00',NULL,'NON_CLUSTERED1467628830186'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 23:40:00',NULL,'2016-07-04 23:40:00',NULL,'NON_CLUSTERED1467628830187');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 23:50:00',NULL,'2016-07-04 23:50:00',NULL,'NON_CLUSTERED1467628830188'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-04 23:50:00',NULL,'2016-07-04 23:50:00',NULL,'NON_CLUSTERED1467628830189'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 00:00:00',NULL,'2016-07-05 00:00:00',NULL,'NON_CLUSTERED1467628830190'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 00:00:00',NULL,'2016-07-05 00:00:00',NULL,'NON_CLUSTERED1467628830191'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 00:10:00',NULL,'2016-07-05 00:10:00',NULL,'NON_CLUSTERED1467628830192');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 00:10:00',NULL,'2016-07-05 00:10:00',NULL,'NON_CLUSTERED1467628830193'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 00:20:00',NULL,'2016-07-05 00:20:00',NULL,'NON_CLUSTERED1467628830194'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 00:20:00',NULL,'2016-07-05 00:20:00',NULL,'NON_CLUSTERED1467628830195'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 00:30:00',NULL,'2016-07-05 00:30:00',NULL,'NON_CLUSTERED1467628830196'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 00:30:00',NULL,'2016-07-05 00:30:00',NULL,'NON_CLUSTERED1467628830197');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 00:40:00',NULL,'2016-07-05 00:40:00',NULL,'NON_CLUSTERED1467628830198'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 00:40:00',NULL,'2016-07-05 00:40:00',NULL,'NON_CLUSTERED1467628830199'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 00:50:00',NULL,'2016-07-05 00:50:00',NULL,'NON_CLUSTERED1467628830200'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 00:50:00',NULL,'2016-07-05 00:50:00',NULL,'NON_CLUSTERED1467628830201'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 01:00:00',NULL,'2016-07-05 01:00:00',NULL,'NON_CLUSTERED1467628830202');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 01:00:00',NULL,'2016-07-05 01:00:00',NULL,'NON_CLUSTERED1467628830203'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 01:10:00',NULL,'2016-07-05 01:10:00',NULL,'NON_CLUSTERED1467628830204'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 01:10:00',NULL,'2016-07-05 01:10:00',NULL,'NON_CLUSTERED1467628830205'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 01:20:00',NULL,'2016-07-05 01:20:00',NULL,'NON_CLUSTERED1467628830206'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 01:20:00',NULL,'2016-07-05 01:20:00',NULL,'NON_CLUSTERED1467628830207');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 01:30:00',NULL,'2016-07-05 01:30:00',NULL,'NON_CLUSTERED1467628830208'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 01:30:00',NULL,'2016-07-05 01:30:00',NULL,'NON_CLUSTERED1467628830209'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 01:40:00',NULL,'2016-07-05 01:40:00',NULL,'NON_CLUSTERED1467628830210'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 01:40:00',NULL,'2016-07-05 01:40:00',NULL,'NON_CLUSTERED1467628830211'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 01:50:00',NULL,'2016-07-05 01:50:00',NULL,'NON_CLUSTERED1467628830212');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 01:50:00',NULL,'2016-07-05 01:50:00',NULL,'NON_CLUSTERED1467628830213'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 02:00:00',NULL,'2016-07-05 02:00:00',NULL,'NON_CLUSTERED1467628830214'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 02:00:00',NULL,'2016-07-05 02:00:00',NULL,'NON_CLUSTERED1467628830215'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 02:10:00',NULL,'2016-07-05 02:10:00',NULL,'NON_CLUSTERED1467628830216'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 02:10:00',NULL,'2016-07-05 02:10:00',NULL,'NON_CLUSTERED1467628830217');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 02:20:00',NULL,'2016-07-05 02:20:00',NULL,'NON_CLUSTERED1467628830218'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 02:20:00',NULL,'2016-07-05 02:20:00',NULL,'NON_CLUSTERED1467628830219'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 02:30:00',NULL,'2016-07-05 02:30:00',NULL,'NON_CLUSTERED1467628830220'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 02:30:00',NULL,'2016-07-05 02:30:00',NULL,'NON_CLUSTERED1467628830221'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 02:40:00',NULL,'2016-07-05 02:40:00',NULL,'NON_CLUSTERED1467628830222');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 02:40:00',NULL,'2016-07-05 02:40:00',NULL,'NON_CLUSTERED1467628830223'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 02:50:00',NULL,'2016-07-05 02:50:00',NULL,'NON_CLUSTERED1467628830224'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 02:50:00',NULL,'2016-07-05 02:50:00',NULL,'NON_CLUSTERED1467628830225'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 03:00:00',NULL,'2016-07-05 03:00:00',NULL,'NON_CLUSTERED1467628830226'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 03:00:00',NULL,'2016-07-05 03:00:00',NULL,'NON_CLUSTERED1467628830227');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 03:10:00',NULL,'2016-07-05 03:10:00',NULL,'NON_CLUSTERED1467628830228'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 03:10:00',NULL,'2016-07-05 03:10:00',NULL,'NON_CLUSTERED1467628830229'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 03:20:00',NULL,'2016-07-05 03:20:00',NULL,'NON_CLUSTERED1467628830230'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 03:20:00',NULL,'2016-07-05 03:20:00',NULL,'NON_CLUSTERED1467628830231'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 03:30:00',NULL,'2016-07-05 03:30:00',NULL,'NON_CLUSTERED1467628830232');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 03:30:00',NULL,'2016-07-05 03:30:00',NULL,'NON_CLUSTERED1467628830233'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 03:40:00',NULL,'2016-07-05 03:40:00',NULL,'NON_CLUSTERED1467628830234'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 03:40:00',NULL,'2016-07-05 03:40:00',NULL,'NON_CLUSTERED1467628830235'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 03:50:00',NULL,'2016-07-05 03:50:00',NULL,'NON_CLUSTERED1467628830236'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 03:50:00',NULL,'2016-07-05 03:50:00',NULL,'NON_CLUSTERED1467628830237');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 04:00:00',NULL,'2016-07-05 04:00:00',NULL,'NON_CLUSTERED1467628830238'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 04:00:00',NULL,'2016-07-05 04:00:00',NULL,'NON_CLUSTERED1467628830239'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 04:10:00',NULL,'2016-07-05 04:10:00',NULL,'NON_CLUSTERED1467628830240'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 04:10:00',NULL,'2016-07-05 04:10:00',NULL,'NON_CLUSTERED1467628830241'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 04:20:00',NULL,'2016-07-05 04:20:00',NULL,'NON_CLUSTERED1467628830242');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 04:20:00',NULL,'2016-07-05 04:20:00',NULL,'NON_CLUSTERED1467628830243'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 04:30:00',NULL,'2016-07-05 04:30:00',NULL,'NON_CLUSTERED1467628830244'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 04:30:00',NULL,'2016-07-05 04:30:00',NULL,'NON_CLUSTERED1467628830245'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 04:40:00',NULL,'2016-07-05 04:40:00',NULL,'NON_CLUSTERED1467628830246'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 04:40:00',NULL,'2016-07-05 04:40:00',NULL,'NON_CLUSTERED1467628830247');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 04:50:00',NULL,'2016-07-05 04:50:00',NULL,'NON_CLUSTERED1467628830248'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 04:50:00',NULL,'2016-07-05 04:50:00',NULL,'NON_CLUSTERED1467628830249'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 05:00:00',NULL,'2016-07-05 05:00:00',NULL,'NON_CLUSTERED1467628830250'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 05:00:00',NULL,'2016-07-05 05:00:00',NULL,'NON_CLUSTERED1467628830251'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 05:10:00',NULL,'2016-07-05 05:10:00',NULL,'NON_CLUSTERED1467628830252');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 05:10:00',NULL,'2016-07-05 05:10:00',NULL,'NON_CLUSTERED1467628830253'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 05:20:00',NULL,'2016-07-05 05:20:00',NULL,'NON_CLUSTERED1467628830254'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 05:20:00',NULL,'2016-07-05 05:20:00',NULL,'NON_CLUSTERED1467628830255'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 05:30:00',NULL,'2016-07-05 05:30:00',NULL,'NON_CLUSTERED1467628830256'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 05:30:00',NULL,'2016-07-05 05:30:00',NULL,'NON_CLUSTERED1467628830257');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 05:40:00',NULL,'2016-07-05 05:40:00',NULL,'NON_CLUSTERED1467628830258'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 05:40:00',NULL,'2016-07-05 05:40:00',NULL,'NON_CLUSTERED1467628830259'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 05:50:00',NULL,'2016-07-05 05:50:00',NULL,'NON_CLUSTERED1467628830260'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 05:50:00',NULL,'2016-07-05 05:50:00',NULL,'NON_CLUSTERED1467628830261'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 06:00:00',NULL,'2016-07-05 06:00:00',NULL,'NON_CLUSTERED1467628830262');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 06:00:00',NULL,'2016-07-05 06:00:00',NULL,'NON_CLUSTERED1467628830263'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 06:10:00',NULL,'2016-07-05 06:10:00',NULL,'NON_CLUSTERED1467628830264'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 06:10:00',NULL,'2016-07-05 06:10:00',NULL,'NON_CLUSTERED1467628830265'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 06:20:00',NULL,'2016-07-05 06:20:00',NULL,'NON_CLUSTERED1467628830266'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 06:20:00',NULL,'2016-07-05 06:20:00',NULL,'NON_CLUSTERED1467628830267');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 06:30:00',NULL,'2016-07-05 06:30:00',NULL,'NON_CLUSTERED1467628830268'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 06:30:00',NULL,'2016-07-05 06:30:00',NULL,'NON_CLUSTERED1467628830269'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 06:40:00',NULL,'2016-07-05 06:40:00',NULL,'NON_CLUSTERED1467628830270'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 06:40:00',NULL,'2016-07-05 06:40:00',NULL,'NON_CLUSTERED1467628830271'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 06:50:00',NULL,'2016-07-05 06:50:00',NULL,'NON_CLUSTERED1467628830272');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 06:50:00',NULL,'2016-07-05 06:50:00',NULL,'NON_CLUSTERED1467628830273'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 07:00:00',NULL,'2016-07-05 07:00:00',NULL,'NON_CLUSTERED1467628830274'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 07:00:00',NULL,'2016-07-05 07:00:00',NULL,'NON_CLUSTERED1467628830275'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 07:10:00',NULL,'2016-07-05 07:10:00',NULL,'NON_CLUSTERED1467628830276'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 07:10:00',NULL,'2016-07-05 07:10:00',NULL,'NON_CLUSTERED1467628830277');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 07:20:00',NULL,'2016-07-05 07:20:00',NULL,'NON_CLUSTERED1467628830278'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 07:20:00',NULL,'2016-07-05 07:20:00',NULL,'NON_CLUSTERED1467628830279'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 07:30:00',NULL,'2016-07-05 07:30:00',NULL,'NON_CLUSTERED1467628830280'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 07:30:00',NULL,'2016-07-05 07:30:00',NULL,'NON_CLUSTERED1467628830281'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 07:40:00',NULL,'2016-07-05 07:40:00',NULL,'NON_CLUSTERED1467628830282');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 07:40:00',NULL,'2016-07-05 07:40:00',NULL,'NON_CLUSTERED1467628830283'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 07:50:00',NULL,'2016-07-05 07:50:00',NULL,'NON_CLUSTERED1467628830284'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 07:50:00',NULL,'2016-07-05 07:50:00',NULL,'NON_CLUSTERED1467628830285'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 08:00:00',NULL,'2016-07-05 08:00:00',NULL,'NON_CLUSTERED1467628830286'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 08:00:00',NULL,'2016-07-05 08:00:00',NULL,'NON_CLUSTERED1467628830287');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 08:10:00',NULL,'2016-07-05 08:10:00',NULL,'NON_CLUSTERED1467628830288'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 08:10:00',NULL,'2016-07-05 08:10:00',NULL,'NON_CLUSTERED1467628830289'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 08:20:00',NULL,'2016-07-05 08:20:00',NULL,'NON_CLUSTERED1467628830290'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 08:20:00',NULL,'2016-07-05 08:20:00',NULL,'NON_CLUSTERED1467628830291'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 08:30:00',NULL,'2016-07-05 08:30:00',NULL,'NON_CLUSTERED1467628830292');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 08:30:00',NULL,'2016-07-05 08:30:00',NULL,'NON_CLUSTERED1467628830293'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 08:40:00',NULL,'2016-07-05 08:40:00',NULL,'NON_CLUSTERED1467628830294'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 08:40:00',NULL,'2016-07-05 08:40:00',NULL,'NON_CLUSTERED1467628830295'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 08:50:00',NULL,'2016-07-05 08:50:00',NULL,'NON_CLUSTERED1467628830296'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 08:50:00',NULL,'2016-07-05 08:50:00',NULL,'NON_CLUSTERED1467628830297');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 09:00:00',NULL,'2016-07-05 09:00:00',NULL,'NON_CLUSTERED1467628830298'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 09:00:00',NULL,'2016-07-05 09:00:00',NULL,'NON_CLUSTERED1467628830299'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 09:10:00',NULL,'2016-07-05 09:10:00',NULL,'NON_CLUSTERED1467628830300'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 09:10:00',NULL,'2016-07-05 09:10:00',NULL,'NON_CLUSTERED1467628830301'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 09:20:00',NULL,'2016-07-05 09:20:00',NULL,'NON_CLUSTERED1467628830302');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 09:20:00',NULL,'2016-07-05 09:20:00',NULL,'NON_CLUSTERED1467628830303'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 09:30:00',NULL,'2016-07-05 09:30:00',NULL,'NON_CLUSTERED1467628830304'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 09:30:00',NULL,'2016-07-05 09:30:00',NULL,'NON_CLUSTERED1467628830305'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 09:40:00',NULL,'2016-07-05 09:40:00',NULL,'NON_CLUSTERED1467628830306'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 09:40:00',NULL,'2016-07-05 09:40:00',NULL,'NON_CLUSTERED1467628830307');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 09:50:00',NULL,'2016-07-05 09:50:00',NULL,'NON_CLUSTERED1467628830308'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 09:50:00',NULL,'2016-07-05 09:50:00',NULL,'NON_CLUSTERED1467628830309'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 10:00:00',NULL,'2016-07-05 10:00:00',NULL,'NON_CLUSTERED1467628830310'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 10:00:00',NULL,'2016-07-05 10:00:00',NULL,'NON_CLUSTERED1467628830311'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 10:10:00',NULL,'2016-07-05 10:10:00',NULL,'NON_CLUSTERED1467628830312');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 10:10:00',NULL,'2016-07-05 10:10:00',NULL,'NON_CLUSTERED1467628830313'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 10:20:00',NULL,'2016-07-05 10:20:00',NULL,'NON_CLUSTERED1467628830314'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 10:20:00',NULL,'2016-07-05 10:20:00',NULL,'NON_CLUSTERED1467628830315'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 10:30:00',NULL,'2016-07-05 10:30:00',NULL,'NON_CLUSTERED1467628830316'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 10:30:00',NULL,'2016-07-05 10:30:00',NULL,'NON_CLUSTERED1467628830317');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 10:40:00',NULL,'2016-07-05 10:40:00',NULL,'NON_CLUSTERED1467628830318'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 10:40:00',NULL,'2016-07-05 10:40:00',NULL,'NON_CLUSTERED1467628830319'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 10:50:00',NULL,'2016-07-05 10:50:00',NULL,'NON_CLUSTERED1467628830320'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 10:50:00',NULL,'2016-07-05 10:50:00',NULL,'NON_CLUSTERED1467628830321'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 11:00:00',NULL,'2016-07-05 11:00:00',NULL,'NON_CLUSTERED1467628830322');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 11:00:00',NULL,'2016-07-05 11:00:00',NULL,'NON_CLUSTERED1467628830323'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 11:10:00',NULL,'2016-07-05 11:10:00',NULL,'NON_CLUSTERED1467628830324'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 11:10:00',NULL,'2016-07-05 11:10:00',NULL,'NON_CLUSTERED1467628830325'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 11:20:00',NULL,'2016-07-05 11:20:00',NULL,'NON_CLUSTERED1467628830326'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 11:20:00',NULL,'2016-07-05 11:20:00',NULL,'NON_CLUSTERED1467628830327');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 11:30:00',NULL,'2016-07-05 11:30:00',NULL,'NON_CLUSTERED1467628830328'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 11:30:00',NULL,'2016-07-05 11:30:00',NULL,'NON_CLUSTERED1467628830329'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 11:40:00',NULL,'2016-07-05 11:40:00',NULL,'NON_CLUSTERED1467628830330'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 11:40:00',NULL,'2016-07-05 11:40:00',NULL,'NON_CLUSTERED1467628830331'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 11:50:00',NULL,'2016-07-05 11:50:00',NULL,'NON_CLUSTERED1467628830332');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 11:50:00',NULL,'2016-07-05 11:50:00',NULL,'NON_CLUSTERED1467628830333'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 12:00:00',NULL,'2016-07-05 12:00:00',NULL,'NON_CLUSTERED1467628830334'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 12:00:00',NULL,'2016-07-05 12:00:00',NULL,'NON_CLUSTERED1467628830335'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 12:10:00',NULL,'2016-07-05 12:10:00',NULL,'NON_CLUSTERED1467628830336'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 12:10:00',NULL,'2016-07-05 12:10:00',NULL,'NON_CLUSTERED1467628830337');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('triggerkey_5','triggerkeyGroup_5','jobkey_5','jobkeyGroup_5','DELETE TRIGGER','COMPLETED','SYSTEM','2016-07-05 12:17:20',NULL,'2016-07-05 12:19:09',5,'NON_CLUSTERED1467628830338'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 12:20:00',NULL,'2016-07-05 12:20:00',NULL,'NON_CLUSTERED1467628830339'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 12:20:00',NULL,'2016-07-05 12:20:00',NULL,'NON_CLUSTERED1467628830340'),
 ('triggerkey_6','triggerkeyGroup_6','jobkey_6','jobkeyGroup_6','DELETE TRIGGER','COMPLETED','SYSTEM','2016-07-05 12:21:51',NULL,'2016-07-05 12:24:59',6,'NON_CLUSTERED1467628830341'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 12:30:00',NULL,'2016-07-05 12:30:00',NULL,'NON_CLUSTERED1467628830342');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 12:30:00',NULL,'2016-07-05 12:30:00',NULL,'NON_CLUSTERED1467628830343'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 12:40:00',NULL,'2016-07-05 12:40:00',NULL,'NON_CLUSTERED1467628830344'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 12:40:00',NULL,'2016-07-05 12:40:00',NULL,'NON_CLUSTERED1467628830345'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 12:50:00',NULL,'2016-07-05 12:50:00',NULL,'NON_CLUSTERED1467628830346'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 12:50:00',NULL,'2016-07-05 12:50:00',NULL,'NON_CLUSTERED1467628830347');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 13:00:00',NULL,'2016-07-05 13:00:00',NULL,'NON_CLUSTERED1467628830348'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 13:00:00',NULL,'2016-07-05 13:00:00',NULL,'NON_CLUSTERED1467628830349'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 13:10:00',NULL,'2016-07-05 13:10:00',NULL,'NON_CLUSTERED1467628830350'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 13:10:00',NULL,'2016-07-05 13:10:00',NULL,'NON_CLUSTERED1467628830351'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 13:20:00',NULL,'2016-07-05 13:20:00',NULL,'NON_CLUSTERED1467628830352');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 13:20:00',NULL,'2016-07-05 13:20:00',NULL,'NON_CLUSTERED1467628830353'),
 ('triggerkey_7','triggerkeyGroup_7','jobkey_7','jobkeyGroup_7','DELETE TRIGGER','COMPLETED','SYSTEM','2016-07-05 13:22:55',NULL,'2016-07-05 13:31:14',7,'NON_CLUSTERED1467628830354'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 13:30:00',NULL,'2016-07-05 13:30:00',NULL,'NON_CLUSTERED1467628830355'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 13:30:00',NULL,'2016-07-05 13:30:00',NULL,'NON_CLUSTERED1467628830356'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 13:40:00',NULL,'2016-07-05 13:40:00',NULL,'NON_CLUSTERED1467628830357');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 13:40:00',NULL,'2016-07-05 13:40:00',NULL,'NON_CLUSTERED1467628830358'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 13:50:00',NULL,'2016-07-05 13:50:00',NULL,'NON_CLUSTERED1467628830359'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 13:50:00',NULL,'2016-07-05 13:50:00',NULL,'NON_CLUSTERED1467628830360'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 14:00:00',NULL,'2016-07-05 14:00:00',NULL,'NON_CLUSTERED1467628830361'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 14:00:00',NULL,'2016-07-05 14:00:00',NULL,'NON_CLUSTERED1467628830362');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 14:10:00',NULL,'2016-07-05 14:10:00',NULL,'NON_CLUSTERED1467628830363'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 14:10:00',NULL,'2016-07-05 14:10:00',NULL,'NON_CLUSTERED1467628830364'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 14:20:00',NULL,'2016-07-05 14:20:00',NULL,'NON_CLUSTERED1467628830365'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 14:20:00',NULL,'2016-07-05 14:20:00',NULL,'NON_CLUSTERED1467628830366'),
 ('triggerkey_8','triggerkeyGroup_8','jobkey_8','jobkeyGroup_8','DELETE TRIGGER','COMPLETED','SYSTEM','2016-07-05 14:23:20',NULL,'2016-07-05 14:23:34',8,'NON_CLUSTERED1467628830367');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 14:30:00',NULL,'2016-07-05 14:30:00',NULL,'NON_CLUSTERED1467628830368'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 14:30:00',NULL,'2016-07-05 14:30:00',NULL,'NON_CLUSTERED1467628830369'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 14:40:00',NULL,'2016-07-05 14:40:00',NULL,'NON_CLUSTERED1467628830370'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 14:40:00',NULL,'2016-07-05 14:40:00',NULL,'NON_CLUSTERED1467628830371'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 14:50:00',NULL,'2016-07-05 14:50:00',NULL,'NON_CLUSTERED1467628830372');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 14:50:00',NULL,'2016-07-05 14:50:00',NULL,'NON_CLUSTERED1467628830373'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 15:00:00',NULL,'2016-07-05 15:00:00',NULL,'NON_CLUSTERED1467628830374'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 15:00:00',NULL,'2016-07-05 15:00:00',NULL,'NON_CLUSTERED1467628830375'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 15:10:00',NULL,'2016-07-05 15:10:00',NULL,'NON_CLUSTERED1467628830376'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 15:10:00',NULL,'2016-07-05 15:10:00',NULL,'NON_CLUSTERED1467628830377');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 15:20:00',NULL,'2016-07-05 15:20:00',NULL,'NON_CLUSTERED1467628830378'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 15:20:00',NULL,'2016-07-05 15:20:00',NULL,'NON_CLUSTERED1467628830379'),
 ('Trigger Key ReservationExpiration Mail','System Triggers','Job Key Reservation Expiration Mail','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 15:23:00',NULL,'2016-07-05 15:23:00',NULL,'NON_CLUSTERED1467628830380'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 15:30:00',NULL,'2016-07-05 15:30:00',NULL,'NON_CLUSTERED1467628830381'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 15:30:00',NULL,'2016-07-05 15:30:00',NULL,'NON_CLUSTERED1467628830382');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 15:40:00',NULL,'2016-07-05 15:40:00',NULL,'NON_CLUSTERED1467628830383'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 15:40:00',NULL,'2016-07-05 15:40:00',NULL,'NON_CLUSTERED1467628830384'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 15:50:00',NULL,'2016-07-05 15:50:00',NULL,'NON_CLUSTERED1467628830385'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 15:50:00',NULL,'2016-07-05 15:50:00',NULL,'NON_CLUSTERED1467628830386'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 16:00:00',NULL,'2016-07-05 16:00:00',NULL,'NON_CLUSTERED1467628830387');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 16:00:00',NULL,'2016-07-05 16:00:00',NULL,'NON_CLUSTERED1467628830388'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 16:10:00',NULL,'2016-07-05 16:10:00',NULL,'NON_CLUSTERED1467628830389'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 16:10:00',NULL,'2016-07-05 16:10:00',NULL,'NON_CLUSTERED1467628830390'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 16:20:00',NULL,'2016-07-05 16:20:00',NULL,'NON_CLUSTERED1467628830391'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 16:20:00',NULL,'2016-07-05 16:20:00',NULL,'NON_CLUSTERED1467628830392');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 16:30:00',NULL,'2016-07-05 16:30:00',NULL,'NON_CLUSTERED1467628830393'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 16:30:00',NULL,'2016-07-05 16:30:00',NULL,'NON_CLUSTERED1467628830394'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 16:40:00',NULL,'2016-07-05 16:40:00',NULL,'NON_CLUSTERED1467628830395'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 16:40:00',NULL,'2016-07-05 16:40:00',NULL,'NON_CLUSTERED1467628830396'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 16:50:00',NULL,'2016-07-05 16:50:00',NULL,'NON_CLUSTERED1467628830397');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 16:50:00',NULL,'2016-07-05 16:50:00',NULL,'NON_CLUSTERED1467628830398'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 17:00:00',NULL,'2016-07-05 17:00:00',NULL,'NON_CLUSTERED1467628830399'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 17:00:00',NULL,'2016-07-05 17:00:00',NULL,'NON_CLUSTERED1467628830400'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 17:10:00',NULL,'2016-07-05 17:10:00',NULL,'NON_CLUSTERED1467628830401'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 17:10:00',NULL,'2016-07-05 17:10:00',NULL,'NON_CLUSTERED1467628830402');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 17:20:00',NULL,'2016-07-05 17:20:00',NULL,'NON_CLUSTERED1467628830403'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 17:20:00',NULL,'2016-07-05 17:20:00',NULL,'NON_CLUSTERED1467628830404'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 17:30:00',NULL,'2016-07-05 17:30:00',NULL,'NON_CLUSTERED1467628830405'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 17:30:00',NULL,'2016-07-05 17:30:00',NULL,'NON_CLUSTERED1467628830406'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 17:40:00',NULL,'2016-07-05 17:40:00',NULL,'NON_CLUSTERED1467628830407');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 17:40:00',NULL,'2016-07-05 17:40:00',NULL,'NON_CLUSTERED1467628830408'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 17:50:00',NULL,'2016-07-05 17:50:00',NULL,'NON_CLUSTERED1467628830409'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 17:50:00',NULL,'2016-07-05 17:50:00',NULL,'NON_CLUSTERED1467628830410'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 18:00:00',NULL,'2016-07-05 18:00:00',NULL,'NON_CLUSTERED1467628830411'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 18:00:00',NULL,'2016-07-05 18:00:00',NULL,'NON_CLUSTERED1467628830412');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 18:10:00',NULL,'2016-07-05 18:10:00',NULL,'NON_CLUSTERED1467628830413'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 18:10:00',NULL,'2016-07-05 18:10:00',NULL,'NON_CLUSTERED1467628830414'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 18:20:00',NULL,'2016-07-05 18:20:00',NULL,'NON_CLUSTERED1467628830415'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 18:20:00',NULL,'2016-07-05 18:20:00',NULL,'NON_CLUSTERED1467628830416'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 18:30:00',NULL,'2016-07-05 18:30:00',NULL,'NON_CLUSTERED1467628830417');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 18:30:00',NULL,'2016-07-05 18:30:00',NULL,'NON_CLUSTERED1467628830418'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 18:40:00',NULL,'2016-07-05 18:40:00',NULL,'NON_CLUSTERED1467628830419'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 18:40:00',NULL,'2016-07-05 18:40:00',NULL,'NON_CLUSTERED1467628830420'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 18:50:00',NULL,'2016-07-05 18:50:00',NULL,'NON_CLUSTERED1467628830421'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 18:50:00',NULL,'2016-07-05 18:50:00',NULL,'NON_CLUSTERED1467628830422');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 19:00:00',NULL,'2016-07-05 19:00:00',NULL,'NON_CLUSTERED1467628830423'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 19:00:00',NULL,'2016-07-05 19:00:00',NULL,'NON_CLUSTERED1467628830424'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 19:10:00',NULL,'2016-07-05 19:10:00',NULL,'NON_CLUSTERED1467628830425'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 19:10:00',NULL,'2016-07-05 19:10:00',NULL,'NON_CLUSTERED1467628830426'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 19:20:00',NULL,'2016-07-05 19:20:00',NULL,'NON_CLUSTERED1467628830427');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 19:20:00',NULL,'2016-07-05 19:20:00',NULL,'NON_CLUSTERED1467628830428'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 19:30:00',NULL,'2016-07-05 19:30:00',NULL,'NON_CLUSTERED1467628830429'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 19:30:00',NULL,'2016-07-05 19:30:00',NULL,'NON_CLUSTERED1467628830430'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 19:40:00',NULL,'2016-07-05 19:40:00',NULL,'NON_CLUSTERED1467628830431'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 19:40:00',NULL,'2016-07-05 19:40:00',NULL,'NON_CLUSTERED1467628830432');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 19:50:00',NULL,'2016-07-05 19:50:00',NULL,'NON_CLUSTERED1467628830433'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 19:50:00',NULL,'2016-07-05 19:50:00',NULL,'NON_CLUSTERED1467628830434'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 20:00:00',NULL,'2016-07-05 20:00:00',NULL,'NON_CLUSTERED1467628830435'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 20:00:00',NULL,'2016-07-05 20:00:00',NULL,'NON_CLUSTERED1467628830436'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 20:10:00',NULL,'2016-07-05 20:10:00',NULL,'NON_CLUSTERED1467628830437');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 20:10:00',NULL,'2016-07-05 20:10:00',NULL,'NON_CLUSTERED1467628830438'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 20:20:00',NULL,'2016-07-05 20:20:00',NULL,'NON_CLUSTERED1467628830439'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 20:20:00',NULL,'2016-07-05 20:20:00',NULL,'NON_CLUSTERED1467628830440'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 20:30:00',NULL,'2016-07-05 20:30:00',NULL,'NON_CLUSTERED1467628830441'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 20:30:00',NULL,'2016-07-05 20:30:00',NULL,'NON_CLUSTERED1467628830442');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 20:40:00',NULL,'2016-07-05 20:40:00',NULL,'NON_CLUSTERED1467628830443'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 20:40:00',NULL,'2016-07-05 20:40:00',NULL,'NON_CLUSTERED1467628830444'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 20:50:00',NULL,'2016-07-05 20:50:00',NULL,'NON_CLUSTERED1467628830445'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 20:50:00',NULL,'2016-07-05 20:50:00',NULL,'NON_CLUSTERED1467628830446'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 21:00:00',NULL,'2016-07-05 21:00:00',NULL,'NON_CLUSTERED1467628830447');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key EnvironmentDeletion','System Triggers','Job Key EnvironmentDeletion','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 21:00:00',NULL,'2016-07-05 21:00:00',NULL,'NON_CLUSTERED1467628830448'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 21:00:00',NULL,'2016-07-05 21:00:00',NULL,'NON_CLUSTERED1467628830449'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 21:10:00',NULL,'2016-07-05 21:10:00',NULL,'NON_CLUSTERED1467628830450'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 21:10:00',NULL,'2016-07-05 21:10:00',NULL,'NON_CLUSTERED1467628830451'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 21:20:00',NULL,'2016-07-05 21:20:00',NULL,'NON_CLUSTERED1467628830452');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 21:20:00',NULL,'2016-07-05 21:20:00',NULL,'NON_CLUSTERED1467628830453'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 21:30:00',NULL,'2016-07-05 21:30:00',NULL,'NON_CLUSTERED1467628830454'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 21:30:00',NULL,'2016-07-05 21:30:00',NULL,'NON_CLUSTERED1467628830455'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 21:40:00',NULL,'2016-07-05 21:40:00',NULL,'NON_CLUSTERED1467628830456'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 21:40:00',NULL,'2016-07-05 21:40:00',NULL,'NON_CLUSTERED1467628830457');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 21:50:00',NULL,'2016-07-05 21:50:00',NULL,'NON_CLUSTERED1467628830458'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 21:50:00',NULL,'2016-07-05 21:50:00',NULL,'NON_CLUSTERED1467628830459'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 22:00:00',NULL,'2016-07-05 22:00:00',NULL,'NON_CLUSTERED1467628830460'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 22:00:00',NULL,'2016-07-05 22:00:00',NULL,'NON_CLUSTERED1467628830461'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 22:10:00',NULL,'2016-07-05 22:10:00',NULL,'NON_CLUSTERED1467628830462');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 22:10:00',NULL,'2016-07-05 22:10:00',NULL,'NON_CLUSTERED1467628830463'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 22:20:00',NULL,'2016-07-05 22:20:00',NULL,'NON_CLUSTERED1467628830464'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 22:20:00',NULL,'2016-07-05 22:20:00',NULL,'NON_CLUSTERED1467628830465'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 22:30:00',NULL,'2016-07-05 22:30:00',NULL,'NON_CLUSTERED1467628830466'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 22:30:00',NULL,'2016-07-05 22:30:00',NULL,'NON_CLUSTERED1467628830467');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 22:40:00',NULL,'2016-07-05 22:40:00',NULL,'NON_CLUSTERED1467628830468'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 22:40:00',NULL,'2016-07-05 22:40:00',NULL,'NON_CLUSTERED1467628830469'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 22:50:00',NULL,'2016-07-05 22:50:00',NULL,'NON_CLUSTERED1467628830470'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 22:50:00',NULL,'2016-07-05 22:50:00',NULL,'NON_CLUSTERED1467628830471'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 23:00:00',NULL,'2016-07-05 23:00:00',NULL,'NON_CLUSTERED1467628830472');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 23:00:00',NULL,'2016-07-05 23:00:00',NULL,'NON_CLUSTERED1467628830473'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 23:10:00',NULL,'2016-07-05 23:10:00',NULL,'NON_CLUSTERED1467628830474'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 23:10:00',NULL,'2016-07-05 23:10:00',NULL,'NON_CLUSTERED1467628830475'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 23:20:00',NULL,'2016-07-05 23:20:00',NULL,'NON_CLUSTERED1467628830476'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 23:20:00',NULL,'2016-07-05 23:20:00',NULL,'NON_CLUSTERED1467628830477');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 23:30:00',NULL,'2016-07-05 23:30:00',NULL,'NON_CLUSTERED1467628830478'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 23:30:00',NULL,'2016-07-05 23:30:00',NULL,'NON_CLUSTERED1467628830479'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 23:40:00',NULL,'2016-07-05 23:40:00',NULL,'NON_CLUSTERED1467628830480'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 23:40:00',NULL,'2016-07-05 23:40:00',NULL,'NON_CLUSTERED1467628830481'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 23:50:00',NULL,'2016-07-05 23:50:00',NULL,'NON_CLUSTERED1467628830482');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-05 23:50:00',NULL,'2016-07-05 23:50:00',NULL,'NON_CLUSTERED1467628830483'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 00:00:00',NULL,'2016-07-06 00:00:00',NULL,'NON_CLUSTERED1467628830484'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 00:00:00',NULL,'2016-07-06 00:00:00',NULL,'NON_CLUSTERED1467628830485'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 00:10:00',NULL,'2016-07-06 00:10:00',NULL,'NON_CLUSTERED1467628830486'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 00:10:00',NULL,'2016-07-06 00:10:00',NULL,'NON_CLUSTERED1467628830487');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 00:20:00',NULL,'2016-07-06 00:20:00',NULL,'NON_CLUSTERED1467628830488'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 00:20:00',NULL,'2016-07-06 00:20:00',NULL,'NON_CLUSTERED1467628830489'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 00:30:00',NULL,'2016-07-06 00:30:00',NULL,'NON_CLUSTERED1467628830490'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 00:30:00',NULL,'2016-07-06 00:30:00',NULL,'NON_CLUSTERED1467628830491'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 00:40:00',NULL,'2016-07-06 00:40:00',NULL,'NON_CLUSTERED1467628830492');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 00:40:00',NULL,'2016-07-06 00:40:00',NULL,'NON_CLUSTERED1467628830493'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 00:50:00',NULL,'2016-07-06 00:50:00',NULL,'NON_CLUSTERED1467628830494'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 00:50:00',NULL,'2016-07-06 00:50:00',NULL,'NON_CLUSTERED1467628830495'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 01:00:00',NULL,'2016-07-06 01:00:00',NULL,'NON_CLUSTERED1467628830496'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 01:00:00',NULL,'2016-07-06 01:00:00',NULL,'NON_CLUSTERED1467628830497');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 01:10:00',NULL,'2016-07-06 01:10:00',NULL,'NON_CLUSTERED1467628830498'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 01:10:00',NULL,'2016-07-06 01:10:00',NULL,'NON_CLUSTERED1467628830499'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 01:20:00',NULL,'2016-07-06 01:20:00',NULL,'NON_CLUSTERED1467628830500'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 01:20:00',NULL,'2016-07-06 01:20:00',NULL,'NON_CLUSTERED1467628830501'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 01:30:00',NULL,'2016-07-06 01:30:00',NULL,'NON_CLUSTERED1467628830502');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 01:30:00',NULL,'2016-07-06 01:30:00',NULL,'NON_CLUSTERED1467628830503'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 01:40:00',NULL,'2016-07-06 01:40:00',NULL,'NON_CLUSTERED1467628830504'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 01:40:00',NULL,'2016-07-06 01:40:00',NULL,'NON_CLUSTERED1467628830505'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 01:50:00',NULL,'2016-07-06 01:50:00',NULL,'NON_CLUSTERED1467628830506'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 01:50:00',NULL,'2016-07-06 01:50:00',NULL,'NON_CLUSTERED1467628830507');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 02:00:00',NULL,'2016-07-06 02:00:00',NULL,'NON_CLUSTERED1467628830508'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 02:00:00',NULL,'2016-07-06 02:00:00',NULL,'NON_CLUSTERED1467628830509'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 02:10:00',NULL,'2016-07-06 02:10:00',NULL,'NON_CLUSTERED1467628830510'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 02:10:00',NULL,'2016-07-06 02:10:00',NULL,'NON_CLUSTERED1467628830511'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 02:20:00',NULL,'2016-07-06 02:20:00',NULL,'NON_CLUSTERED1467628830512');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 02:20:00',NULL,'2016-07-06 02:20:00',NULL,'NON_CLUSTERED1467628830513'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 02:30:00',NULL,'2016-07-06 02:30:00',NULL,'NON_CLUSTERED1467628830514'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 02:30:00',NULL,'2016-07-06 02:30:00',NULL,'NON_CLUSTERED1467628830515'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 02:40:00',NULL,'2016-07-06 02:40:00',NULL,'NON_CLUSTERED1467628830516'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 02:40:00',NULL,'2016-07-06 02:40:00',NULL,'NON_CLUSTERED1467628830517');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 02:50:00',NULL,'2016-07-06 02:50:00',NULL,'NON_CLUSTERED1467628830518'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 02:50:00',NULL,'2016-07-06 02:50:00',NULL,'NON_CLUSTERED1467628830519'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 03:00:00',NULL,'2016-07-06 03:00:00',NULL,'NON_CLUSTERED1467628830520'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 03:00:00',NULL,'2016-07-06 03:00:00',NULL,'NON_CLUSTERED1467628830521'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 03:10:00',NULL,'2016-07-06 03:10:00',NULL,'NON_CLUSTERED1467628830522');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 03:10:00',NULL,'2016-07-06 03:10:00',NULL,'NON_CLUSTERED1467628830523'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 03:20:00',NULL,'2016-07-06 03:20:00',NULL,'NON_CLUSTERED1467628830524'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 03:20:00',NULL,'2016-07-06 03:20:00',NULL,'NON_CLUSTERED1467628830525'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 03:30:00',NULL,'2016-07-06 03:30:00',NULL,'NON_CLUSTERED1467628830526'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 03:30:00',NULL,'2016-07-06 03:30:00',NULL,'NON_CLUSTERED1467628830527');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 03:40:00',NULL,'2016-07-06 03:40:00',NULL,'NON_CLUSTERED1467628830528'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 03:40:00',NULL,'2016-07-06 03:40:00',NULL,'NON_CLUSTERED1467628830529'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 03:50:00',NULL,'2016-07-06 03:50:00',NULL,'NON_CLUSTERED1467628830530'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 03:50:00',NULL,'2016-07-06 03:50:00',NULL,'NON_CLUSTERED1467628830531'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 04:00:00',NULL,'2016-07-06 04:00:00',NULL,'NON_CLUSTERED1467628830532');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 04:00:00',NULL,'2016-07-06 04:00:00',NULL,'NON_CLUSTERED1467628830533'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 04:10:00',NULL,'2016-07-06 04:10:00',NULL,'NON_CLUSTERED1467628830534'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 04:10:00',NULL,'2016-07-06 04:10:00',NULL,'NON_CLUSTERED1467628830535'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 04:20:00',NULL,'2016-07-06 04:20:00',NULL,'NON_CLUSTERED1467628830536'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 04:20:00',NULL,'2016-07-06 04:20:00',NULL,'NON_CLUSTERED1467628830537');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 04:30:00',NULL,'2016-07-06 04:30:00',NULL,'NON_CLUSTERED1467628830538'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 04:30:00',NULL,'2016-07-06 04:30:00',NULL,'NON_CLUSTERED1467628830539'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 04:40:00',NULL,'2016-07-06 04:40:00',NULL,'NON_CLUSTERED1467628830540'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 04:40:00',NULL,'2016-07-06 04:40:00',NULL,'NON_CLUSTERED1467628830541'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 04:50:00',NULL,'2016-07-06 04:50:00',NULL,'NON_CLUSTERED1467628830542');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 04:50:00',NULL,'2016-07-06 04:50:00',NULL,'NON_CLUSTERED1467628830543'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 05:00:00',NULL,'2016-07-06 05:00:00',NULL,'NON_CLUSTERED1467628830544'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 05:00:00',NULL,'2016-07-06 05:00:00',NULL,'NON_CLUSTERED1467628830545'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 05:10:00',NULL,'2016-07-06 05:10:00',NULL,'NON_CLUSTERED1467628830546'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 05:10:00',NULL,'2016-07-06 05:10:00',NULL,'NON_CLUSTERED1467628830547');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 05:20:00',NULL,'2016-07-06 05:20:00',NULL,'NON_CLUSTERED1467628830548'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 05:20:00',NULL,'2016-07-06 05:20:00',NULL,'NON_CLUSTERED1467628830549'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 05:30:00',NULL,'2016-07-06 05:30:00',NULL,'NON_CLUSTERED1467628830550'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 05:30:00',NULL,'2016-07-06 05:30:00',NULL,'NON_CLUSTERED1467628830551'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 05:40:00',NULL,'2016-07-06 05:40:00',NULL,'NON_CLUSTERED1467628830552');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 05:40:00',NULL,'2016-07-06 05:40:00',NULL,'NON_CLUSTERED1467628830553'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 05:50:00',NULL,'2016-07-06 05:50:00',NULL,'NON_CLUSTERED1467628830554'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 05:50:00',NULL,'2016-07-06 05:50:00',NULL,'NON_CLUSTERED1467628830555'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 06:00:00',NULL,'2016-07-06 06:00:00',NULL,'NON_CLUSTERED1467628830556'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 06:00:00',NULL,'2016-07-06 06:00:00',NULL,'NON_CLUSTERED1467628830557');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 06:10:00',NULL,'2016-07-06 06:10:00',NULL,'NON_CLUSTERED1467628830558'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 06:10:00',NULL,'2016-07-06 06:10:00',NULL,'NON_CLUSTERED1467628830559'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 06:20:00',NULL,'2016-07-06 06:20:00',NULL,'NON_CLUSTERED1467628830560'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 06:20:00',NULL,'2016-07-06 06:20:00',NULL,'NON_CLUSTERED1467628830561'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 06:30:00',NULL,'2016-07-06 06:30:00',NULL,'NON_CLUSTERED1467628830562');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 06:30:00',NULL,'2016-07-06 06:30:00',NULL,'NON_CLUSTERED1467628830563'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 06:40:00',NULL,'2016-07-06 06:40:00',NULL,'NON_CLUSTERED1467628830564'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 06:40:00',NULL,'2016-07-06 06:40:00',NULL,'NON_CLUSTERED1467628830565'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 06:50:00',NULL,'2016-07-06 06:50:00',NULL,'NON_CLUSTERED1467628830566'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 06:50:00',NULL,'2016-07-06 06:50:00',NULL,'NON_CLUSTERED1467628830567');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 07:00:00',NULL,'2016-07-06 07:00:00',NULL,'NON_CLUSTERED1467628830568'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 07:00:00',NULL,'2016-07-06 07:00:00',NULL,'NON_CLUSTERED1467628830569'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 07:10:00',NULL,'2016-07-06 07:10:00',NULL,'NON_CLUSTERED1467628830570'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 07:10:00',NULL,'2016-07-06 07:10:00',NULL,'NON_CLUSTERED1467628830571'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 07:20:00',NULL,'2016-07-06 07:20:00',NULL,'NON_CLUSTERED1467628830572');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 07:20:00',NULL,'2016-07-06 07:20:00',NULL,'NON_CLUSTERED1467628830573'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 07:30:00',NULL,'2016-07-06 07:30:00',NULL,'NON_CLUSTERED1467628830574'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 07:30:00',NULL,'2016-07-06 07:30:00',NULL,'NON_CLUSTERED1467628830575'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 07:40:00',NULL,'2016-07-06 07:40:00',NULL,'NON_CLUSTERED1467628830576'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 07:40:00',NULL,'2016-07-06 07:40:00',NULL,'NON_CLUSTERED1467628830577');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 07:50:00',NULL,'2016-07-06 07:50:00',NULL,'NON_CLUSTERED1467628830578'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 07:50:00',NULL,'2016-07-06 07:50:00',NULL,'NON_CLUSTERED1467628830579'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 08:00:00',NULL,'2016-07-06 08:00:00',NULL,'NON_CLUSTERED1467628830580'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 08:00:00',NULL,'2016-07-06 08:00:00',NULL,'NON_CLUSTERED1467628830581'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 08:10:00',NULL,'2016-07-06 08:10:00',NULL,'NON_CLUSTERED1467628830582');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 08:10:00',NULL,'2016-07-06 08:10:00',NULL,'NON_CLUSTERED1467628830583'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 08:20:00',NULL,'2016-07-06 08:20:00',NULL,'NON_CLUSTERED1467628830584'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 08:20:00',NULL,'2016-07-06 08:20:00',NULL,'NON_CLUSTERED1467628830585'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 08:30:00',NULL,'2016-07-06 08:30:00',NULL,'NON_CLUSTERED1467628830586'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 08:30:00',NULL,'2016-07-06 08:30:00',NULL,'NON_CLUSTERED1467628830587');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 08:40:00',NULL,'2016-07-06 08:40:00',NULL,'NON_CLUSTERED1467628830588'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 08:40:00',NULL,'2016-07-06 08:40:00',NULL,'NON_CLUSTERED1467628830589'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 08:50:00',NULL,'2016-07-06 08:50:00',NULL,'NON_CLUSTERED1467628830590'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 08:50:00',NULL,'2016-07-06 08:50:00',NULL,'NON_CLUSTERED1467628830591'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 09:00:00',NULL,'2016-07-06 09:00:00',NULL,'NON_CLUSTERED1467628830592');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 09:00:00',NULL,'2016-07-06 09:00:00',NULL,'NON_CLUSTERED1467628830593'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 09:10:00',NULL,'2016-07-06 09:10:00',NULL,'NON_CLUSTERED1467628830594'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 09:10:00',NULL,'2016-07-06 09:10:00',NULL,'NON_CLUSTERED1467628830595'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 09:20:00',NULL,'2016-07-06 09:20:00',NULL,'NON_CLUSTERED1467628830596'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 09:20:00',NULL,'2016-07-06 09:20:00',NULL,'NON_CLUSTERED1467628830597');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 09:30:00',NULL,'2016-07-06 09:30:00',NULL,'NON_CLUSTERED1467628830598'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 09:30:00',NULL,'2016-07-06 09:30:00',NULL,'NON_CLUSTERED1467628830599'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 09:40:00',NULL,'2016-07-06 09:40:00',NULL,'NON_CLUSTERED1467628830600'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 09:40:00',NULL,'2016-07-06 09:40:00',NULL,'NON_CLUSTERED1467628830601'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 09:50:00',NULL,'2016-07-06 09:50:00',NULL,'NON_CLUSTERED1467628830602');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 09:50:00',NULL,'2016-07-06 09:50:00',NULL,'NON_CLUSTERED1467628830603'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 10:00:00',NULL,'2016-07-06 10:00:00',NULL,'NON_CLUSTERED1467628830604'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 10:00:00',NULL,'2016-07-06 10:00:00',NULL,'NON_CLUSTERED1467628830605'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 10:10:00',NULL,'2016-07-06 10:10:00',NULL,'NON_CLUSTERED1467628830606'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 10:10:00',NULL,'2016-07-06 10:10:00',NULL,'NON_CLUSTERED1467628830607');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 10:20:00',NULL,'2016-07-06 10:20:00',NULL,'NON_CLUSTERED1467628830608'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 10:20:00',NULL,'2016-07-06 10:20:00',NULL,'NON_CLUSTERED1467628830609'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 10:30:00',NULL,'2016-07-06 10:30:00',NULL,'NON_CLUSTERED1467628830610'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 10:30:00',NULL,'2016-07-06 10:30:00',NULL,'NON_CLUSTERED1467628830611'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 10:40:00',NULL,'2016-07-06 10:40:00',NULL,'NON_CLUSTERED1467628830612');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 10:40:00',NULL,'2016-07-06 10:40:00',NULL,'NON_CLUSTERED1467628830613'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 10:50:00',NULL,'2016-07-06 10:50:00',NULL,'NON_CLUSTERED1467628830614'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 10:50:00',NULL,'2016-07-06 10:50:00',NULL,'NON_CLUSTERED1467628830615'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 11:00:00',NULL,'2016-07-06 11:00:00',NULL,'NON_CLUSTERED1467628830616'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 11:00:00',NULL,'2016-07-06 11:00:00',NULL,'NON_CLUSTERED1467628830617');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 11:10:00',NULL,'2016-07-06 11:10:00',NULL,'NON_CLUSTERED1467628830618'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 11:10:00',NULL,'2016-07-06 11:10:00',NULL,'NON_CLUSTERED1467628830619'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 11:20:00',NULL,'2016-07-06 11:20:00',NULL,'NON_CLUSTERED1467628830620'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 11:20:00',NULL,'2016-07-06 11:20:00',NULL,'NON_CLUSTERED1467628830621'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 11:30:00',NULL,'2016-07-06 11:30:00',NULL,'NON_CLUSTERED1467628830622');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 11:30:00',NULL,'2016-07-06 11:30:00',NULL,'NON_CLUSTERED1467628830623'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 11:40:00',NULL,'2016-07-06 11:40:00',NULL,'NON_CLUSTERED1467628830624'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 11:40:00',NULL,'2016-07-06 11:40:00',NULL,'NON_CLUSTERED1467628830625'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 11:50:00',NULL,'2016-07-06 11:50:00',NULL,'NON_CLUSTERED1467628830626'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 11:50:00',NULL,'2016-07-06 11:50:00',NULL,'NON_CLUSTERED1467628830627');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 12:00:00',NULL,'2016-07-06 12:00:00',NULL,'NON_CLUSTERED1467628830628'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 12:00:00',NULL,'2016-07-06 12:00:00',NULL,'NON_CLUSTERED1467628830629'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 12:10:00',NULL,'2016-07-06 12:10:00',NULL,'NON_CLUSTERED1467628830630'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 12:10:00',NULL,'2016-07-06 12:10:00',NULL,'NON_CLUSTERED1467628830631'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 12:20:00',NULL,'2016-07-06 12:20:00',NULL,'NON_CLUSTERED1467628830632');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 12:20:00',NULL,'2016-07-06 12:20:00',NULL,'NON_CLUSTERED1467628830633'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 12:30:00',NULL,'2016-07-06 12:30:00',NULL,'NON_CLUSTERED1467628830634'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 12:30:00',NULL,'2016-07-06 12:30:00',NULL,'NON_CLUSTERED1467628830635'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 12:40:00',NULL,'2016-07-06 12:40:00',NULL,'NON_CLUSTERED1467628830636'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 12:40:00',NULL,'2016-07-06 12:40:00',NULL,'NON_CLUSTERED1467628830637');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 12:50:00',NULL,'2016-07-06 12:50:00',NULL,'NON_CLUSTERED1467628830638'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 12:50:00',NULL,'2016-07-06 12:50:00',NULL,'NON_CLUSTERED1467628830639'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 13:00:00',NULL,'2016-07-06 13:00:00',NULL,'NON_CLUSTERED1467628830640'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 13:00:00',NULL,'2016-07-06 13:00:00',NULL,'NON_CLUSTERED1467628830641'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 13:10:00',NULL,'2016-07-06 13:10:00',NULL,'NON_CLUSTERED1467628830642');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 13:10:00',NULL,'2016-07-06 13:10:00',NULL,'NON_CLUSTERED1467628830643'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 13:20:00',NULL,'2016-07-06 13:20:00',NULL,'NON_CLUSTERED1467628830644'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 13:20:00',NULL,'2016-07-06 13:20:00',NULL,'NON_CLUSTERED1467628830645'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 13:30:00',NULL,'2016-07-06 13:30:00',NULL,'NON_CLUSTERED1467628830646'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 13:30:00',NULL,'2016-07-06 13:30:00',NULL,'NON_CLUSTERED1467628830647');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 13:40:00',NULL,'2016-07-06 13:40:00',NULL,'NON_CLUSTERED1467628830648'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 13:40:00',NULL,'2016-07-06 13:40:00',NULL,'NON_CLUSTERED1467628830649'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 13:50:00',NULL,'2016-07-06 13:50:00',NULL,'NON_CLUSTERED1467628830650'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 13:50:00',NULL,'2016-07-06 13:50:00',NULL,'NON_CLUSTERED1467628830651'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 14:00:00',NULL,'2016-07-06 14:00:00',NULL,'NON_CLUSTERED1467628830652');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 14:00:00',NULL,'2016-07-06 14:00:00',NULL,'NON_CLUSTERED1467628830653'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 14:10:00',NULL,'2016-07-06 14:10:00',NULL,'NON_CLUSTERED1467628830654'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 14:10:00',NULL,'2016-07-06 14:10:00',NULL,'NON_CLUSTERED1467628830655'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 14:20:00',NULL,'2016-07-06 14:20:00',NULL,'NON_CLUSTERED1467628830656'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 14:20:00',NULL,'2016-07-06 14:20:00',NULL,'NON_CLUSTERED1467628830657');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 14:30:00',NULL,'2016-07-06 14:30:00',NULL,'NON_CLUSTERED1467628830658'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 14:30:00',NULL,'2016-07-06 14:30:00',NULL,'NON_CLUSTERED1467628830659'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 14:40:00',NULL,'2016-07-06 14:40:00',NULL,'NON_CLUSTERED1467628830660'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 14:40:00',NULL,'2016-07-06 14:40:00',NULL,'NON_CLUSTERED1467628830661'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 14:50:00',NULL,'2016-07-06 14:50:00',NULL,'NON_CLUSTERED1467628830662');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 14:50:00',NULL,'2016-07-06 14:50:00',NULL,'NON_CLUSTERED1467628830663'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 15:00:00',NULL,'2016-07-06 15:00:00',NULL,'NON_CLUSTERED1467628830664'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 15:00:00',NULL,'2016-07-06 15:00:00',NULL,'NON_CLUSTERED1467628830665'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 15:10:00',NULL,'2016-07-06 15:10:00',NULL,'NON_CLUSTERED1467628830666'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 15:10:00',NULL,'2016-07-06 15:10:00',NULL,'NON_CLUSTERED1467628830667');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 15:20:00',NULL,'2016-07-06 15:20:00',NULL,'NON_CLUSTERED1467628830668'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 15:20:00',NULL,'2016-07-06 15:20:00',NULL,'NON_CLUSTERED1467628830669'),
 ('Trigger Key ReservationExpiration Mail','System Triggers','Job Key Reservation Expiration Mail','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 15:23:00',NULL,'2016-07-06 15:23:00',NULL,'NON_CLUSTERED1467628830670'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 15:30:00',NULL,'2016-07-06 15:30:00',NULL,'NON_CLUSTERED1467628830671'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 15:30:00',NULL,'2016-07-06 15:30:00',NULL,'NON_CLUSTERED1467628830672');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 15:40:00',NULL,'2016-07-06 15:40:00',NULL,'NON_CLUSTERED1467628830673'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 15:40:00',NULL,'2016-07-06 15:40:00',NULL,'NON_CLUSTERED1467628830674'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 15:50:00',NULL,'2016-07-06 15:50:00',NULL,'NON_CLUSTERED1467628830675'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 15:50:00',NULL,'2016-07-06 15:50:00',NULL,'NON_CLUSTERED1467628830676'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 16:00:00',NULL,'2016-07-06 16:00:00',NULL,'NON_CLUSTERED1467628830677');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 16:00:00',NULL,'2016-07-06 16:00:00',NULL,'NON_CLUSTERED1467628830678'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 16:10:00',NULL,'2016-07-06 16:10:00',NULL,'NON_CLUSTERED1467628830679'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 16:10:00',NULL,'2016-07-06 16:10:00',NULL,'NON_CLUSTERED1467628830680'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 16:20:00',NULL,'2016-07-06 16:20:00',NULL,'NON_CLUSTERED1467628830681'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 16:20:00',NULL,'2016-07-06 16:20:00',NULL,'NON_CLUSTERED1467628830682');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 16:30:00',NULL,'2016-07-06 16:30:00',NULL,'NON_CLUSTERED1467628830683'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 16:30:00',NULL,'2016-07-06 16:30:00',NULL,'NON_CLUSTERED1467628830684'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 16:40:00',NULL,'2016-07-06 16:40:00',NULL,'NON_CLUSTERED1467628830685'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 16:40:00',NULL,'2016-07-06 16:40:00',NULL,'NON_CLUSTERED1467628830686'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 16:50:00',NULL,'2016-07-06 16:50:00',NULL,'NON_CLUSTERED1467628830687');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 16:50:00',NULL,'2016-07-06 16:50:00',NULL,'NON_CLUSTERED1467628830688'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 17:00:00',NULL,'2016-07-06 17:00:00',NULL,'NON_CLUSTERED1467628830689'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 17:00:00',NULL,'2016-07-06 17:00:00',NULL,'NON_CLUSTERED1467628830690'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 17:10:00',NULL,'2016-07-06 17:10:00',NULL,'NON_CLUSTERED1467628830691'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 17:10:00',NULL,'2016-07-06 17:10:00',NULL,'NON_CLUSTERED1467628830692');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 17:20:00',NULL,'2016-07-06 17:20:00',NULL,'NON_CLUSTERED1467628830693'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 17:20:00',NULL,'2016-07-06 17:20:00',NULL,'NON_CLUSTERED1467628830694'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 17:30:00',NULL,'2016-07-06 17:30:00',NULL,'NON_CLUSTERED1467628830695'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 17:30:00',NULL,'2016-07-06 17:30:00',NULL,'NON_CLUSTERED1467628830696'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 17:40:00',NULL,'2016-07-06 17:40:00',NULL,'NON_CLUSTERED1467628830697');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 17:40:00',NULL,'2016-07-06 17:40:00',NULL,'NON_CLUSTERED1467628830698'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 17:50:00',NULL,'2016-07-06 17:50:00',NULL,'NON_CLUSTERED1467628830699'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 17:50:00',NULL,'2016-07-06 17:50:00',NULL,'NON_CLUSTERED1467628830700'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 18:00:00',NULL,'2016-07-06 18:00:00',NULL,'NON_CLUSTERED1467628830701'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 18:00:00',NULL,'2016-07-06 18:00:00',NULL,'NON_CLUSTERED1467628830702');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 18:10:00',NULL,'2016-07-06 18:10:00',NULL,'NON_CLUSTERED1467628830703'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 18:10:00',NULL,'2016-07-06 18:10:00',NULL,'NON_CLUSTERED1467628830704'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 18:20:00',NULL,'2016-07-06 18:20:00',NULL,'NON_CLUSTERED1467628830705'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 18:20:00',NULL,'2016-07-06 18:20:00',NULL,'NON_CLUSTERED1467628830706'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 18:30:00',NULL,'2016-07-06 18:30:00',NULL,'NON_CLUSTERED1467628830707');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 18:30:00',NULL,'2016-07-06 18:30:00',NULL,'NON_CLUSTERED1467628830708'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 18:40:00',NULL,'2016-07-06 18:40:00',NULL,'NON_CLUSTERED1467628830709'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 18:40:00',NULL,'2016-07-06 18:40:00',NULL,'NON_CLUSTERED1467628830710'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 18:50:00',NULL,'2016-07-06 18:50:00',NULL,'NON_CLUSTERED1467628830711'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 18:50:00',NULL,'2016-07-06 18:50:00',NULL,'NON_CLUSTERED1467628830712');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 19:00:00',NULL,'2016-07-06 19:00:00',NULL,'NON_CLUSTERED1467628830713'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 19:00:00',NULL,'2016-07-06 19:00:00',NULL,'NON_CLUSTERED1467628830714'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 19:10:00',NULL,'2016-07-06 19:10:00',NULL,'NON_CLUSTERED1467628830715'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 19:10:00',NULL,'2016-07-06 19:10:00',NULL,'NON_CLUSTERED1467628830716'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 19:20:00',NULL,'2016-07-06 19:20:00',NULL,'NON_CLUSTERED1467628830717');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 19:20:00',NULL,'2016-07-06 19:20:00',NULL,'NON_CLUSTERED1467628830718'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 19:30:00',NULL,'2016-07-06 19:30:00',NULL,'NON_CLUSTERED1467628830719'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 19:30:00',NULL,'2016-07-06 19:30:00',NULL,'NON_CLUSTERED1467628830720'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 19:40:00',NULL,'2016-07-06 19:40:00',NULL,'NON_CLUSTERED1467628830721'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 19:40:00',NULL,'2016-07-06 19:40:00',NULL,'NON_CLUSTERED1467628830722');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 19:50:00',NULL,'2016-07-06 19:50:00',NULL,'NON_CLUSTERED1467628830723'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 19:50:00',NULL,'2016-07-06 19:50:00',NULL,'NON_CLUSTERED1467628830724'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 20:00:00',NULL,'2016-07-06 20:00:00',NULL,'NON_CLUSTERED1467628830725'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 20:00:00',NULL,'2016-07-06 20:00:00',NULL,'NON_CLUSTERED1467628830726'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 20:10:00',NULL,'2016-07-06 20:10:00',NULL,'NON_CLUSTERED1467628830727');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 20:10:00',NULL,'2016-07-06 20:10:00',NULL,'NON_CLUSTERED1467628830728'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 20:20:00',NULL,'2016-07-06 20:20:00',NULL,'NON_CLUSTERED1467628830729'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 20:20:00',NULL,'2016-07-06 20:20:00',NULL,'NON_CLUSTERED1467628830730'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 20:30:00',NULL,'2016-07-06 20:30:00',NULL,'NON_CLUSTERED1467628830731'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 20:30:00',NULL,'2016-07-06 20:30:00',NULL,'NON_CLUSTERED1467628830732');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 20:40:00',NULL,'2016-07-06 20:40:00',NULL,'NON_CLUSTERED1467628830733'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 20:40:00',NULL,'2016-07-06 20:40:00',NULL,'NON_CLUSTERED1467628830734'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 20:50:00',NULL,'2016-07-06 20:50:00',NULL,'NON_CLUSTERED1467628830735'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 20:50:00',NULL,'2016-07-06 20:50:00',NULL,'NON_CLUSTERED1467628830736'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 21:00:00',NULL,'2016-07-06 21:00:00',NULL,'NON_CLUSTERED1467628830737');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key EnvironmentDeletion','System Triggers','Job Key EnvironmentDeletion','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 21:00:00',NULL,'2016-07-06 21:00:00',NULL,'NON_CLUSTERED1467628830738'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 21:00:00',NULL,'2016-07-06 21:00:00',NULL,'NON_CLUSTERED1467628830739'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 21:10:00',NULL,'2016-07-06 21:10:00',NULL,'NON_CLUSTERED1467628830740'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 21:10:00',NULL,'2016-07-06 21:10:01',NULL,'NON_CLUSTERED1467628830741'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 21:20:00',NULL,'2016-07-06 21:20:00',NULL,'NON_CLUSTERED1467628830742');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 21:20:00',NULL,'2016-07-06 21:20:00',NULL,'NON_CLUSTERED1467628830743'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 21:30:00',NULL,'2016-07-06 21:30:00',NULL,'NON_CLUSTERED1467628830744'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 21:30:00',NULL,'2016-07-06 21:30:00',NULL,'NON_CLUSTERED1467628830745'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 21:40:00',NULL,'2016-07-06 21:40:00',NULL,'NON_CLUSTERED1467628830746'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 21:40:00',NULL,'2016-07-06 21:40:00',NULL,'NON_CLUSTERED1467628830747');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 21:50:00',NULL,'2016-07-06 21:50:00',NULL,'NON_CLUSTERED1467628830748'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 21:50:00',NULL,'2016-07-06 21:50:00',NULL,'NON_CLUSTERED1467628830749'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 22:00:00',NULL,'2016-07-06 22:00:00',NULL,'NON_CLUSTERED1467628830750'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 22:00:00',NULL,'2016-07-06 22:00:00',NULL,'NON_CLUSTERED1467628830751'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 22:10:00',NULL,'2016-07-06 22:10:00',NULL,'NON_CLUSTERED1467628830752');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 22:10:00',NULL,'2016-07-06 22:10:00',NULL,'NON_CLUSTERED1467628830753'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 22:20:00',NULL,'2016-07-06 22:20:00',NULL,'NON_CLUSTERED1467628830754'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 22:20:00',NULL,'2016-07-06 22:20:00',NULL,'NON_CLUSTERED1467628830755'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 22:30:00',NULL,'2016-07-06 22:30:00',NULL,'NON_CLUSTERED1467628830756'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 22:30:00',NULL,'2016-07-06 22:30:00',NULL,'NON_CLUSTERED1467628830757');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 22:40:00',NULL,'2016-07-06 22:40:00',NULL,'NON_CLUSTERED1467628830758'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 22:40:00',NULL,'2016-07-06 22:40:00',NULL,'NON_CLUSTERED1467628830759'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 22:50:00',NULL,'2016-07-06 22:50:00',NULL,'NON_CLUSTERED1467628830760'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 22:50:00',NULL,'2016-07-06 22:50:00',NULL,'NON_CLUSTERED1467628830761'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 23:00:00',NULL,'2016-07-06 23:00:00',NULL,'NON_CLUSTERED1467628830762');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 23:00:00',NULL,'2016-07-06 23:00:00',NULL,'NON_CLUSTERED1467628830763'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 23:10:00',NULL,'2016-07-06 23:10:00',NULL,'NON_CLUSTERED1467628830764'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 23:10:00',NULL,'2016-07-06 23:10:00',NULL,'NON_CLUSTERED1467628830765'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 23:20:00',NULL,'2016-07-06 23:20:00',NULL,'NON_CLUSTERED1467628830766'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 23:20:00',NULL,'2016-07-06 23:20:00',NULL,'NON_CLUSTERED1467628830767');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 23:30:00',NULL,'2016-07-06 23:30:00',NULL,'NON_CLUSTERED1467628830768'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 23:30:00',NULL,'2016-07-06 23:30:00',NULL,'NON_CLUSTERED1467628830769'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 23:40:00',NULL,'2016-07-06 23:40:00',NULL,'NON_CLUSTERED1467628830770'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 23:40:00',NULL,'2016-07-06 23:40:00',NULL,'NON_CLUSTERED1467628830771'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 23:50:00',NULL,'2016-07-06 23:50:00',NULL,'NON_CLUSTERED1467628830772');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-06 23:50:00',NULL,'2016-07-06 23:50:00',NULL,'NON_CLUSTERED1467628830773'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 00:00:00',NULL,'2016-07-07 00:00:00',NULL,'NON_CLUSTERED1467628830774'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 00:00:00',NULL,'2016-07-07 00:00:00',NULL,'NON_CLUSTERED1467628830775'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 00:10:00',NULL,'2016-07-07 00:10:00',NULL,'NON_CLUSTERED1467628830776'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 00:10:00',NULL,'2016-07-07 00:10:00',NULL,'NON_CLUSTERED1467628830777');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 00:20:00',NULL,'2016-07-07 00:20:00',NULL,'NON_CLUSTERED1467628830778'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 00:20:00',NULL,'2016-07-07 00:20:00',NULL,'NON_CLUSTERED1467628830779'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 00:30:00',NULL,'2016-07-07 00:30:00',NULL,'NON_CLUSTERED1467628830780'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 00:30:00',NULL,'2016-07-07 00:30:00',NULL,'NON_CLUSTERED1467628830781'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 00:40:00',NULL,'2016-07-07 00:40:00',NULL,'NON_CLUSTERED1467628830782');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 00:40:00',NULL,'2016-07-07 00:40:00',NULL,'NON_CLUSTERED1467628830783'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 00:50:00',NULL,'2016-07-07 00:50:00',NULL,'NON_CLUSTERED1467628830784'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 00:50:00',NULL,'2016-07-07 00:50:00',NULL,'NON_CLUSTERED1467628830785'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 01:00:00',NULL,'2016-07-07 01:00:00',NULL,'NON_CLUSTERED1467628830786'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 01:00:00',NULL,'2016-07-07 01:00:00',NULL,'NON_CLUSTERED1467628830787');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 01:10:00',NULL,'2016-07-07 01:10:00',NULL,'NON_CLUSTERED1467628830788'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 01:10:00',NULL,'2016-07-07 01:10:00',NULL,'NON_CLUSTERED1467628830789'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 01:20:00',NULL,'2016-07-07 01:20:00',NULL,'NON_CLUSTERED1467628830790'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 01:20:00',NULL,'2016-07-07 01:20:00',NULL,'NON_CLUSTERED1467628830791'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 01:30:00',NULL,'2016-07-07 01:30:00',NULL,'NON_CLUSTERED1467628830792');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 01:30:00',NULL,'2016-07-07 01:30:00',NULL,'NON_CLUSTERED1467628830793'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 01:40:00',NULL,'2016-07-07 01:40:00',NULL,'NON_CLUSTERED1467628830794'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 01:40:00',NULL,'2016-07-07 01:40:00',NULL,'NON_CLUSTERED1467628830795'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 01:50:00',NULL,'2016-07-07 01:50:00',NULL,'NON_CLUSTERED1467628830796'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 01:50:00',NULL,'2016-07-07 01:50:00',NULL,'NON_CLUSTERED1467628830797');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 02:00:00',NULL,'2016-07-07 02:00:00',NULL,'NON_CLUSTERED1467628830798'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 02:00:00',NULL,'2016-07-07 02:00:00',NULL,'NON_CLUSTERED1467628830799'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 02:10:00',NULL,'2016-07-07 02:10:00',NULL,'NON_CLUSTERED1467628830800'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 02:10:00',NULL,'2016-07-07 02:10:00',NULL,'NON_CLUSTERED1467628830801'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 02:20:00',NULL,'2016-07-07 02:20:00',NULL,'NON_CLUSTERED1467628830802');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 02:20:00',NULL,'2016-07-07 02:20:00',NULL,'NON_CLUSTERED1467628830803'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 02:30:00',NULL,'2016-07-07 02:30:00',NULL,'NON_CLUSTERED1467628830804'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 02:30:00',NULL,'2016-07-07 02:30:00',NULL,'NON_CLUSTERED1467628830805'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 02:40:00',NULL,'2016-07-07 02:40:00',NULL,'NON_CLUSTERED1467628830806'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 02:40:00',NULL,'2016-07-07 02:40:00',NULL,'NON_CLUSTERED1467628830807');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 02:50:00',NULL,'2016-07-07 02:50:00',NULL,'NON_CLUSTERED1467628830808'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 02:50:00',NULL,'2016-07-07 02:50:00',NULL,'NON_CLUSTERED1467628830809'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 03:00:00',NULL,'2016-07-07 03:00:00',NULL,'NON_CLUSTERED1467628830810'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 03:00:00',NULL,'2016-07-07 03:00:00',NULL,'NON_CLUSTERED1467628830811'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 03:10:00',NULL,'2016-07-07 03:10:00',NULL,'NON_CLUSTERED1467628830812');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 03:10:00',NULL,'2016-07-07 03:10:00',NULL,'NON_CLUSTERED1467628830813'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 03:20:00',NULL,'2016-07-07 03:20:00',NULL,'NON_CLUSTERED1467628830814'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 03:20:00',NULL,'2016-07-07 03:20:00',NULL,'NON_CLUSTERED1467628830815'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 03:30:00',NULL,'2016-07-07 03:30:00',NULL,'NON_CLUSTERED1467628830816'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 03:30:00',NULL,'2016-07-07 03:30:00',NULL,'NON_CLUSTERED1467628830817');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 03:40:00',NULL,'2016-07-07 03:40:00',NULL,'NON_CLUSTERED1467628830818'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 03:40:00',NULL,'2016-07-07 03:40:00',NULL,'NON_CLUSTERED1467628830819'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 03:50:00',NULL,'2016-07-07 03:50:00',NULL,'NON_CLUSTERED1467628830820'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 03:50:00',NULL,'2016-07-07 03:50:00',NULL,'NON_CLUSTERED1467628830821'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 04:00:00',NULL,'2016-07-07 04:00:00',NULL,'NON_CLUSTERED1467628830822');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 04:00:00',NULL,'2016-07-07 04:00:00',NULL,'NON_CLUSTERED1467628830823'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 04:10:00',NULL,'2016-07-07 04:10:00',NULL,'NON_CLUSTERED1467628830824'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 04:10:00',NULL,'2016-07-07 04:10:00',NULL,'NON_CLUSTERED1467628830825'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 04:20:00',NULL,'2016-07-07 04:20:00',NULL,'NON_CLUSTERED1467628830826'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 04:20:00',NULL,'2016-07-07 04:20:00',NULL,'NON_CLUSTERED1467628830827');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 04:30:00',NULL,'2016-07-07 04:30:00',NULL,'NON_CLUSTERED1467628830828'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 04:30:00',NULL,'2016-07-07 04:30:00',NULL,'NON_CLUSTERED1467628830829'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 04:40:00',NULL,'2016-07-07 04:40:00',NULL,'NON_CLUSTERED1467628830830'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 04:40:00',NULL,'2016-07-07 04:40:00',NULL,'NON_CLUSTERED1467628830831'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 04:50:00',NULL,'2016-07-07 04:50:00',NULL,'NON_CLUSTERED1467628830832');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 04:50:00',NULL,'2016-07-07 04:50:00',NULL,'NON_CLUSTERED1467628830833'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 05:00:00',NULL,'2016-07-07 05:00:00',NULL,'NON_CLUSTERED1467628830834'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 05:00:00',NULL,'2016-07-07 05:00:00',NULL,'NON_CLUSTERED1467628830835'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 05:10:00',NULL,'2016-07-07 05:10:00',NULL,'NON_CLUSTERED1467628830836'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 05:10:00',NULL,'2016-07-07 05:10:00',NULL,'NON_CLUSTERED1467628830837');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 05:20:00',NULL,'2016-07-07 05:20:00',NULL,'NON_CLUSTERED1467628830838'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 05:20:00',NULL,'2016-07-07 05:20:00',NULL,'NON_CLUSTERED1467628830839'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 05:30:00',NULL,'2016-07-07 05:30:00',NULL,'NON_CLUSTERED1467628830840'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 05:30:00',NULL,'2016-07-07 05:30:00',NULL,'NON_CLUSTERED1467628830841'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 05:40:00',NULL,'2016-07-07 05:40:00',NULL,'NON_CLUSTERED1467628830842');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 05:40:00',NULL,'2016-07-07 05:40:00',NULL,'NON_CLUSTERED1467628830843'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 05:50:00',NULL,'2016-07-07 05:50:00',NULL,'NON_CLUSTERED1467628830844'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 05:50:00',NULL,'2016-07-07 05:50:00',NULL,'NON_CLUSTERED1467628830845'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 06:00:00',NULL,'2016-07-07 06:00:00',NULL,'NON_CLUSTERED1467628830846'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 06:00:00',NULL,'2016-07-07 06:00:00',NULL,'NON_CLUSTERED1467628830847');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 06:10:00',NULL,'2016-07-07 06:10:00',NULL,'NON_CLUSTERED1467628830848'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 06:10:00',NULL,'2016-07-07 06:10:00',NULL,'NON_CLUSTERED1467628830849'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 06:20:00',NULL,'2016-07-07 06:20:00',NULL,'NON_CLUSTERED1467628830850'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 06:20:00',NULL,'2016-07-07 06:20:00',NULL,'NON_CLUSTERED1467628830851'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 06:30:00',NULL,'2016-07-07 06:30:00',NULL,'NON_CLUSTERED1467628830852');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 06:30:00',NULL,'2016-07-07 06:30:00',NULL,'NON_CLUSTERED1467628830853'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 06:40:00',NULL,'2016-07-07 06:40:00',NULL,'NON_CLUSTERED1467628830854'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 06:40:00',NULL,'2016-07-07 06:40:00',NULL,'NON_CLUSTERED1467628830855'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 06:50:00',NULL,'2016-07-07 06:50:00',NULL,'NON_CLUSTERED1467628830856'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 06:50:00',NULL,'2016-07-07 06:50:00',NULL,'NON_CLUSTERED1467628830857');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 07:00:00',NULL,'2016-07-07 07:00:00',NULL,'NON_CLUSTERED1467628830858'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 07:00:00',NULL,'2016-07-07 07:00:00',NULL,'NON_CLUSTERED1467628830859'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 07:10:00',NULL,'2016-07-07 07:10:00',NULL,'NON_CLUSTERED1467628830860'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 07:10:00',NULL,'2016-07-07 07:10:00',NULL,'NON_CLUSTERED1467628830861'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 07:20:00',NULL,'2016-07-07 07:20:00',NULL,'NON_CLUSTERED1467628830862');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 07:20:00',NULL,'2016-07-07 07:20:00',NULL,'NON_CLUSTERED1467628830863'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 07:30:00',NULL,'2016-07-07 07:30:00',NULL,'NON_CLUSTERED1467628830864'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 07:30:00',NULL,'2016-07-07 07:30:00',NULL,'NON_CLUSTERED1467628830865'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 07:40:00',NULL,'2016-07-07 07:40:00',NULL,'NON_CLUSTERED1467628830866'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 07:40:00',NULL,'2016-07-07 07:40:00',NULL,'NON_CLUSTERED1467628830867');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 07:50:00',NULL,'2016-07-07 07:50:00',NULL,'NON_CLUSTERED1467628830868'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 07:50:00',NULL,'2016-07-07 07:50:00',NULL,'NON_CLUSTERED1467628830869'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 08:00:00',NULL,'2016-07-07 08:00:00',NULL,'NON_CLUSTERED1467628830870'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 08:00:00',NULL,'2016-07-07 08:00:00',NULL,'NON_CLUSTERED1467628830871'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 08:10:00',NULL,'2016-07-07 08:10:00',NULL,'NON_CLUSTERED1467628830872');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 08:10:00',NULL,'2016-07-07 08:10:00',NULL,'NON_CLUSTERED1467628830873'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 08:20:00',NULL,'2016-07-07 08:20:00',NULL,'NON_CLUSTERED1467628830874'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 08:20:00',NULL,'2016-07-07 08:20:00',NULL,'NON_CLUSTERED1467628830875'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 08:30:00',NULL,'2016-07-07 08:30:00',NULL,'NON_CLUSTERED1467628830876'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 08:30:00',NULL,'2016-07-07 08:30:00',NULL,'NON_CLUSTERED1467628830877');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 08:40:00',NULL,'2016-07-07 08:40:00',NULL,'NON_CLUSTERED1467628830878'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 08:40:00',NULL,'2016-07-07 08:40:00',NULL,'NON_CLUSTERED1467628830879'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 08:50:00',NULL,'2016-07-07 08:50:00',NULL,'NON_CLUSTERED1467628830880'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 08:50:00',NULL,'2016-07-07 08:50:00',NULL,'NON_CLUSTERED1467628830881'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 09:00:00',NULL,'2016-07-07 09:00:00',NULL,'NON_CLUSTERED1467628830882');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 09:00:00',NULL,'2016-07-07 09:00:00',NULL,'NON_CLUSTERED1467628830883'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 09:10:00',NULL,'2016-07-07 09:10:00',NULL,'NON_CLUSTERED1467628830884'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 09:10:00',NULL,'2016-07-07 09:10:00',NULL,'NON_CLUSTERED1467628830885'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 09:20:00',NULL,'2016-07-07 09:20:00',NULL,'NON_CLUSTERED1467628830886'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 09:20:00',NULL,'2016-07-07 09:20:00',NULL,'NON_CLUSTERED1467628830887');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 09:30:00',NULL,'2016-07-07 09:30:00',NULL,'NON_CLUSTERED1467628830888'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 09:30:00',NULL,'2016-07-07 09:30:00',NULL,'NON_CLUSTERED1467628830889'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 09:40:00',NULL,'2016-07-07 09:40:00',NULL,'NON_CLUSTERED1467628830890'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 09:40:00',NULL,'2016-07-07 09:40:00',NULL,'NON_CLUSTERED1467628830891'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 09:50:00',NULL,'2016-07-07 09:50:00',NULL,'NON_CLUSTERED1467628830892');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 09:50:00',NULL,'2016-07-07 09:50:00',NULL,'NON_CLUSTERED1467628830893'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 10:00:00',NULL,'2016-07-07 10:00:00',NULL,'NON_CLUSTERED1467628830894'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 10:00:00',NULL,'2016-07-07 10:00:00',NULL,'NON_CLUSTERED1467628830895'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 10:10:00',NULL,'2016-07-07 10:10:00',NULL,'NON_CLUSTERED1467628830896'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 10:10:00',NULL,'2016-07-07 10:10:00',NULL,'NON_CLUSTERED1467628830897');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 10:20:00',NULL,'2016-07-07 10:20:00',NULL,'NON_CLUSTERED1467628830898'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 10:20:00',NULL,'2016-07-07 10:20:00',NULL,'NON_CLUSTERED1467628830899'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 10:30:00',NULL,'2016-07-07 10:30:00',NULL,'NON_CLUSTERED1467628830900'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 10:30:00',NULL,'2016-07-07 10:30:00',NULL,'NON_CLUSTERED1467628830901'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 10:40:00',NULL,'2016-07-07 10:40:00',NULL,'NON_CLUSTERED1467628830902');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 10:40:00',NULL,'2016-07-07 10:40:00',NULL,'NON_CLUSTERED1467628830903'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 10:50:00',NULL,'2016-07-07 10:50:00',NULL,'NON_CLUSTERED1467628830904'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 10:50:00',NULL,'2016-07-07 10:50:00',NULL,'NON_CLUSTERED1467628830905'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 11:00:00',NULL,'2016-07-07 11:00:00',NULL,'NON_CLUSTERED1467628830906'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 11:00:00',NULL,'2016-07-07 11:00:00',NULL,'NON_CLUSTERED1467628830907');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 11:10:00',NULL,'2016-07-07 11:10:00',NULL,'NON_CLUSTERED1467628830908'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 11:10:00',NULL,'2016-07-07 11:10:00',NULL,'NON_CLUSTERED1467628830909'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 11:20:00',NULL,'2016-07-07 11:20:00',NULL,'NON_CLUSTERED1467628830910'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 11:20:00',NULL,'2016-07-07 11:20:00',NULL,'NON_CLUSTERED1467628830911'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 11:30:00',NULL,'2016-07-07 11:30:00',NULL,'NON_CLUSTERED1467628830912');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 11:30:00',NULL,'2016-07-07 11:30:00',NULL,'NON_CLUSTERED1467628830913'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 11:40:00',NULL,'2016-07-07 11:40:00',NULL,'NON_CLUSTERED1467628830914'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 11:40:00',NULL,'2016-07-07 11:40:00',NULL,'NON_CLUSTERED1467628830915'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 11:50:00',NULL,'2016-07-07 11:50:00',NULL,'NON_CLUSTERED1467628830916'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 11:50:00',NULL,'2016-07-07 11:50:00',NULL,'NON_CLUSTERED1467628830917');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 12:00:00',NULL,'2016-07-07 12:00:00',NULL,'NON_CLUSTERED1467628830918'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 12:00:00',NULL,'2016-07-07 12:00:00',NULL,'NON_CLUSTERED1467628830919'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 12:10:00',NULL,'2016-07-07 12:10:00',NULL,'NON_CLUSTERED1467628830920'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 12:10:00',NULL,'2016-07-07 12:10:00',NULL,'NON_CLUSTERED1467628830921'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 12:20:00',NULL,'2016-07-07 12:20:00',NULL,'NON_CLUSTERED1467628830922');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 12:20:00',NULL,'2016-07-07 12:20:00',NULL,'NON_CLUSTERED1467628830923'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 12:30:00',NULL,'2016-07-07 12:30:00',NULL,'NON_CLUSTERED1467628830924'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 12:30:00',NULL,'2016-07-07 12:30:00',NULL,'NON_CLUSTERED1467628830925'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 12:40:00',NULL,'2016-07-07 12:40:00',NULL,'NON_CLUSTERED1467628830926'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 12:40:00',NULL,'2016-07-07 12:40:00',NULL,'NON_CLUSTERED1467628830927');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 12:50:00',NULL,'2016-07-07 12:50:00',NULL,'NON_CLUSTERED1467628830928'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 12:50:00',NULL,'2016-07-07 12:50:00',NULL,'NON_CLUSTERED1467628830929'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 13:00:00',NULL,'2016-07-07 13:00:00',NULL,'NON_CLUSTERED1467628830930'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 13:00:00',NULL,'2016-07-07 13:00:00',NULL,'NON_CLUSTERED1467628830931'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 13:10:00',NULL,'2016-07-07 13:10:00',NULL,'NON_CLUSTERED1467628830932');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 13:10:00',NULL,'2016-07-07 13:10:00',NULL,'NON_CLUSTERED1467628830933'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 13:20:00',NULL,'2016-07-07 13:20:00',NULL,'NON_CLUSTERED1467628830934'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 13:20:00',NULL,'2016-07-07 13:20:00',NULL,'NON_CLUSTERED1467628830935'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 13:30:00',NULL,'2016-07-07 13:30:00',NULL,'NON_CLUSTERED1467628830936'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 13:30:00',NULL,'2016-07-07 13:30:00',NULL,'NON_CLUSTERED1467628830937');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 13:40:00',NULL,'2016-07-07 13:40:00',NULL,'NON_CLUSTERED1467628830938'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 13:40:00',NULL,'2016-07-07 13:40:00',NULL,'NON_CLUSTERED1467628830939'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 13:50:00',NULL,'2016-07-07 13:50:00',NULL,'NON_CLUSTERED1467628830940'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 13:50:00',NULL,'2016-07-07 13:50:00',NULL,'NON_CLUSTERED1467628830941'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 14:00:00',NULL,'2016-07-07 14:00:00',NULL,'NON_CLUSTERED1467628830942');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 14:00:00',NULL,'2016-07-07 14:00:00',NULL,'NON_CLUSTERED1467628830943'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 14:10:00',NULL,'2016-07-07 14:10:00',NULL,'NON_CLUSTERED1467628830944'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 14:10:00',NULL,'2016-07-07 14:10:00',NULL,'NON_CLUSTERED1467628830945'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 14:20:00',NULL,'2016-07-07 14:20:00',NULL,'NON_CLUSTERED1467628830946'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 14:20:00',NULL,'2016-07-07 14:20:00',NULL,'NON_CLUSTERED1467628830947');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 14:30:00',NULL,'2016-07-07 14:30:00',NULL,'NON_CLUSTERED1467628830948'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 14:30:00',NULL,'2016-07-07 14:30:00',NULL,'NON_CLUSTERED1467628830949'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 14:40:00',NULL,'2016-07-07 14:40:00',NULL,'NON_CLUSTERED1467628830950'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 14:40:00',NULL,'2016-07-07 14:40:00',NULL,'NON_CLUSTERED1467628830951'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 14:50:00',NULL,'2016-07-07 14:50:00',NULL,'NON_CLUSTERED1467628830952');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 14:50:00',NULL,'2016-07-07 14:50:00',NULL,'NON_CLUSTERED1467628830953'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 15:00:00',NULL,'2016-07-07 15:00:00',NULL,'NON_CLUSTERED1467628830954'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 15:00:00',NULL,'2016-07-07 15:00:00',NULL,'NON_CLUSTERED1467628830955'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 15:10:00',NULL,'2016-07-07 15:10:00',NULL,'NON_CLUSTERED1467628830956'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 15:10:00',NULL,'2016-07-07 15:10:00',NULL,'NON_CLUSTERED1467628830957');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 15:20:00',NULL,'2016-07-07 15:20:00',NULL,'NON_CLUSTERED1467628830958'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 15:20:00',NULL,'2016-07-07 15:20:00',NULL,'NON_CLUSTERED1467628830959'),
 ('Trigger Key ReservationExpiration Mail','System Triggers','Job Key Reservation Expiration Mail','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 15:23:00',NULL,'2016-07-07 15:23:12',NULL,'NON_CLUSTERED1467628830960'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 15:30:00',NULL,'2016-07-07 15:30:00',NULL,'NON_CLUSTERED1467628830961'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 15:30:00',NULL,'2016-07-07 15:30:00',NULL,'NON_CLUSTERED1467628830962');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 15:40:00',NULL,'2016-07-07 15:40:00',NULL,'NON_CLUSTERED1467628830963'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 15:40:00',NULL,'2016-07-07 15:40:00',NULL,'NON_CLUSTERED1467628830964'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 15:50:00',NULL,'2016-07-07 15:50:00',NULL,'NON_CLUSTERED1467628830965'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 15:50:00',NULL,'2016-07-07 15:50:00',NULL,'NON_CLUSTERED1467628830966'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 16:00:00',NULL,'2016-07-07 16:00:00',NULL,'NON_CLUSTERED1467628830967');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 16:00:00',NULL,'2016-07-07 16:00:00',NULL,'NON_CLUSTERED1467628830968'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 16:10:00',NULL,'2016-07-07 16:10:00',NULL,'NON_CLUSTERED1467628830969'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 16:10:00',NULL,'2016-07-07 16:10:00',NULL,'NON_CLUSTERED1467628830970'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 16:20:00',NULL,'2016-07-07 16:20:00',NULL,'NON_CLUSTERED1467628830971'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 16:20:00',NULL,'2016-07-07 16:20:00',NULL,'NON_CLUSTERED1467628830972');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 16:30:00',NULL,'2016-07-07 16:30:00',NULL,'NON_CLUSTERED1467628830973'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 16:30:00',NULL,'2016-07-07 16:30:00',NULL,'NON_CLUSTERED1467628830974'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 16:40:00',NULL,'2016-07-07 16:40:00',NULL,'NON_CLUSTERED1467628830975'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 16:40:00',NULL,'2016-07-07 16:40:00',NULL,'NON_CLUSTERED1467628830976'),
 ('triggerkey_9','triggerkeyGroup_9','jobkey_9','jobkeyGroup_9','DELETE TRIGGER','COMPLETED','SYSTEM','2016-07-07 16:43:41',NULL,'2016-07-07 16:52:35',9,'NON_CLUSTERED1467628830977');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 16:50:00',NULL,'2016-07-07 16:50:00',NULL,'NON_CLUSTERED1467628830978'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 16:50:00',NULL,'2016-07-07 16:50:00',NULL,'NON_CLUSTERED1467628830979'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 17:00:00',NULL,'2016-07-07 17:00:00',NULL,'NON_CLUSTERED1467628830980'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 17:00:00',NULL,'2016-07-07 17:00:00',NULL,'NON_CLUSTERED1467628830981'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 17:10:00',NULL,'2016-07-07 17:10:00',NULL,'NON_CLUSTERED1467628830982');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 17:10:00',NULL,'2016-07-07 17:10:00',NULL,'NON_CLUSTERED1467628830983'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 17:20:00',NULL,'2016-07-07 17:20:00',NULL,'NON_CLUSTERED1467628830984'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 17:20:00',NULL,'2016-07-07 17:20:00',NULL,'NON_CLUSTERED1467628830985'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 17:30:00',NULL,'2016-07-07 17:30:00',NULL,'NON_CLUSTERED1467628830986'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 17:30:00',NULL,'2016-07-07 17:30:00',NULL,'NON_CLUSTERED1467628830987');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 17:40:00',NULL,'2016-07-07 17:40:00',NULL,'NON_CLUSTERED1467628830988'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 17:40:00',NULL,'2016-07-07 17:40:00',NULL,'NON_CLUSTERED1467628830989'),
 ('triggerkey_10','triggerkeyGroup_10','jobkey_10','jobkeyGroup_10','DELETE TRIGGER','COMPLETED','SYSTEM','2016-07-07 17:41:19',NULL,'2016-07-07 17:49:43',10,'NON_CLUSTERED1467628830990'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 17:50:00',NULL,'2016-07-07 17:50:00',NULL,'NON_CLUSTERED1467628830991'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 17:50:00',NULL,'2016-07-07 17:50:00',NULL,'NON_CLUSTERED1467628830992');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 18:00:00',NULL,'2016-07-07 18:00:00',NULL,'NON_CLUSTERED1467628830993'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 18:00:00',NULL,'2016-07-07 18:00:00',NULL,'NON_CLUSTERED1467628830994'),
 ('triggerkey_11','triggerkeyGroup_11','jobkey_11','jobkeyGroup_11','DELETE TRIGGER','COMPLETED','SYSTEM','2016-07-07 18:06:20',NULL,'2016-07-07 18:11:17',11,'NON_CLUSTERED1467628830995'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 18:10:00',NULL,'2016-07-07 18:10:00',NULL,'NON_CLUSTERED1467628830996'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 18:10:00',NULL,'2016-07-07 18:10:00',NULL,'NON_CLUSTERED1467628830997');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('triggerkey_12','triggerkeyGroup_12','jobkey_12','jobkeyGroup_12','DELETE TRIGGER','COMPLETED','SYSTEM','2016-07-07 18:14:52',NULL,'2016-07-07 18:16:16',12,'NON_CLUSTERED1467628830998'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 18:20:00',NULL,'2016-07-07 18:20:00',NULL,'NON_CLUSTERED1467628830999'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 18:20:00',NULL,'2016-07-07 18:20:00',NULL,'NON_CLUSTERED1467628831000'),
 ('triggerkey_13','triggerkeyGroup_13','jobkey_13','jobkeyGroup_13','DELETE TRIGGER','COMPLETED','SYSTEM','2016-07-07 18:25:27',NULL,'2016-07-07 18:31:31',13,'NON_CLUSTERED1467628831001'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 18:30:00',NULL,'2016-07-07 18:30:00',NULL,'NON_CLUSTERED1467628831002');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 18:30:00',NULL,'2016-07-07 18:30:00',NULL,'NON_CLUSTERED1467628831003'),
 ('triggerkey_14','triggerkeyGroup_14','jobkey_14','jobkeyGroup_14','DELETE TRIGGER','COMPLETED','SYSTEM','2016-07-07 18:33:17',NULL,'2016-07-07 18:38:22',14,'NON_CLUSTERED1467628831004'),
 ('triggerkey_15','triggerkeyGroup_15','jobkey_15','jobkeyGroup_15','DELETE TRIGGER','COMPLETED','SYSTEM','2016-07-07 18:39:15',NULL,'2016-07-07 18:41:21',15,'NON_CLUSTERED1467628831005'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 18:40:00',NULL,'2016-07-07 18:40:00',NULL,'NON_CLUSTERED1467628831006'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 18:40:00',NULL,'2016-07-07 18:40:00',NULL,'NON_CLUSTERED1467628831007');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 18:50:00',NULL,'2016-07-07 18:50:00',NULL,'NON_CLUSTERED1467628831008'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 18:50:00',NULL,'2016-07-07 18:50:00',NULL,'NON_CLUSTERED1467628831009'),
 ('triggerkey_16','triggerkeyGroup_16','jobkey_16','jobkeyGroup_16','DELETE TRIGGER','COMPLETED','SYSTEM','2016-07-07 18:51:20',NULL,'2016-07-07 19:12:27',16,'NON_CLUSTERED1467628831010'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 19:00:00',NULL,'2016-07-07 19:00:00',NULL,'NON_CLUSTERED1467628831011'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 19:00:00',NULL,'2016-07-07 19:00:00',NULL,'NON_CLUSTERED1467628831012');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 19:10:00',NULL,'2016-07-07 19:10:00',NULL,'NON_CLUSTERED1467628831013'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 19:10:00',NULL,'2016-07-07 19:10:00',NULL,'NON_CLUSTERED1467628831014'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 19:20:00',NULL,'2016-07-07 19:20:00',NULL,'NON_CLUSTERED1467628831015'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 19:20:00',NULL,'2016-07-07 19:20:00',NULL,'NON_CLUSTERED1467628831016'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 19:30:00',NULL,'2016-07-07 19:30:00',NULL,'NON_CLUSTERED1467628831017');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 19:30:00',NULL,'2016-07-07 19:30:00',NULL,'NON_CLUSTERED1467628831018'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 19:40:00',NULL,'2016-07-07 19:40:00',NULL,'NON_CLUSTERED1467628831019'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 19:40:00',NULL,'2016-07-07 19:40:00',NULL,'NON_CLUSTERED1467628831020'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 19:50:00',NULL,'2016-07-07 19:50:00',NULL,'NON_CLUSTERED1467628831021'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 19:50:00',NULL,'2016-07-07 19:50:00',NULL,'NON_CLUSTERED1467628831022');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('triggerkey_17','triggerkeyGroup_17','jobkey_17','jobkeyGroup_17','DELETE TRIGGER','COMPLETED','SYSTEM','2016-07-07 19:52:18',NULL,'2016-07-07 19:52:21',17,'NON_CLUSTERED1467628831023'),
 ('triggerkey_18','triggerkeyGroup_18','jobkey_18','jobkeyGroup_18','DELETE TRIGGER','COMPLETED','SYSTEM','2016-07-07 19:57:00',NULL,'2016-07-07 20:03:09',18,'NON_CLUSTERED1467628831024'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 20:00:00',NULL,'2016-07-07 20:00:00',NULL,'NON_CLUSTERED1467628831025'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 20:00:00',NULL,'2016-07-07 20:00:00',NULL,'NON_CLUSTERED1467628831026'),
 ('triggerkey_19','triggerkeyGroup_19','jobkey_19','jobkeyGroup_19','DELETE TRIGGER','COMPLETED','SYSTEM','2016-07-07 20:08:26',NULL,'2016-07-07 20:09:30',19,'NON_CLUSTERED1467628831027');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 20:10:00',NULL,'2016-07-07 20:10:00',NULL,'NON_CLUSTERED1467628831028'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 20:10:00',NULL,'2016-07-07 20:10:00',NULL,'NON_CLUSTERED1467628831029'),
 ('triggerkey_20','triggerkeyGroup_20','jobkey_20','jobkeyGroup_20','DELETE TRIGGER','COMPLETED','SYSTEM','2016-07-07 20:15:40',NULL,'2016-07-07 20:15:42',20,'NON_CLUSTERED1467628831030'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 20:20:00',NULL,'2016-07-07 20:20:00',NULL,'NON_CLUSTERED1467628831031'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 20:20:00',NULL,'2016-07-07 20:20:00',NULL,'NON_CLUSTERED1467628831032');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 20:30:00',NULL,'2016-07-07 20:30:00',NULL,'NON_CLUSTERED1467628831033'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 20:30:00',NULL,'2016-07-07 20:30:00',NULL,'NON_CLUSTERED1467628831034'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 20:40:00',NULL,'2016-07-07 20:40:00',NULL,'NON_CLUSTERED1467628831035'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 20:40:00',NULL,'2016-07-07 20:40:00',NULL,'NON_CLUSTERED1467628831036'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 20:50:00',NULL,'2016-07-07 20:50:00',NULL,'NON_CLUSTERED1467628831037');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 20:50:00',NULL,'2016-07-07 20:50:00',NULL,'NON_CLUSTERED1467628831038'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 21:00:00',NULL,'2016-07-07 21:00:00',NULL,'NON_CLUSTERED1467628831039'),
 ('Trigger Key EnvironmentDeletion','System Triggers','Job Key EnvironmentDeletion','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 21:00:00',NULL,'2016-07-07 21:00:00',NULL,'NON_CLUSTERED1467628831040'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 21:00:00',NULL,'2016-07-07 21:00:00',NULL,'NON_CLUSTERED1467628831041'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 21:10:00',NULL,'2016-07-07 21:10:00',NULL,'NON_CLUSTERED1467628831042');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 21:10:00',NULL,'2016-07-07 21:10:00',NULL,'NON_CLUSTERED1467628831043'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 21:20:00',NULL,'2016-07-07 21:20:00',NULL,'NON_CLUSTERED1467628831044'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 21:20:00',NULL,'2016-07-07 21:20:00',NULL,'NON_CLUSTERED1467628831045'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 21:30:00',NULL,'2016-07-07 21:30:00',NULL,'NON_CLUSTERED1467628831046'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 21:30:00',NULL,'2016-07-07 21:30:00',NULL,'NON_CLUSTERED1467628831047');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 21:40:00',NULL,'2016-07-07 21:40:00',NULL,'NON_CLUSTERED1467628831048'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 21:40:00',NULL,'2016-07-07 21:40:00',NULL,'NON_CLUSTERED1467628831049'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 21:50:00',NULL,'2016-07-07 21:50:00',NULL,'NON_CLUSTERED1467628831050'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 21:50:00',NULL,'2016-07-07 21:50:00',NULL,'NON_CLUSTERED1467628831051'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 22:00:00',NULL,'2016-07-07 22:00:00',NULL,'NON_CLUSTERED1467628831052');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 22:00:00',NULL,'2016-07-07 22:00:00',NULL,'NON_CLUSTERED1467628831053'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 22:10:00',NULL,'2016-07-07 22:10:00',NULL,'NON_CLUSTERED1467628831054'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 22:10:00',NULL,'2016-07-07 22:10:00',NULL,'NON_CLUSTERED1467628831055'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 22:20:00',NULL,'2016-07-07 22:20:00',NULL,'NON_CLUSTERED1467628831056'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 22:20:00',NULL,'2016-07-07 22:20:00',NULL,'NON_CLUSTERED1467628831057');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 22:30:00',NULL,'2016-07-07 22:30:00',NULL,'NON_CLUSTERED1467628831058'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 22:30:00',NULL,'2016-07-07 22:30:00',NULL,'NON_CLUSTERED1467628831059'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 22:40:00',NULL,'2016-07-07 22:40:00',NULL,'NON_CLUSTERED1467628831060'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 22:40:00',NULL,'2016-07-07 22:40:00',NULL,'NON_CLUSTERED1467628831061'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 22:50:00',NULL,'2016-07-07 22:50:00',NULL,'NON_CLUSTERED1467628831062');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 22:50:00',NULL,'2016-07-07 22:50:00',NULL,'NON_CLUSTERED1467628831063'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 23:00:00',NULL,'2016-07-07 23:00:00',NULL,'NON_CLUSTERED1467628831064'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 23:00:00',NULL,'2016-07-07 23:00:00',NULL,'NON_CLUSTERED1467628831065'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 23:10:00',NULL,'2016-07-07 23:10:00',NULL,'NON_CLUSTERED1467628831066'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 23:10:00',NULL,'2016-07-07 23:10:00',NULL,'NON_CLUSTERED1467628831067');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 23:20:00',NULL,'2016-07-07 23:20:00',NULL,'NON_CLUSTERED1467628831068'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 23:20:00',NULL,'2016-07-07 23:20:00',NULL,'NON_CLUSTERED1467628831069'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 23:30:00',NULL,'2016-07-07 23:30:00',NULL,'NON_CLUSTERED1467628831070'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 23:30:00',NULL,'2016-07-07 23:30:00',NULL,'NON_CLUSTERED1467628831071'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 23:40:00',NULL,'2016-07-07 23:40:00',NULL,'NON_CLUSTERED1467628831072');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 23:40:00',NULL,'2016-07-07 23:40:00',NULL,'NON_CLUSTERED1467628831073'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 23:50:00',NULL,'2016-07-07 23:50:00',NULL,'NON_CLUSTERED1467628831074'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-07 23:50:00',NULL,'2016-07-07 23:50:00',NULL,'NON_CLUSTERED1467628831075'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 00:00:00',NULL,'2016-07-08 00:00:00',NULL,'NON_CLUSTERED1467628831076'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 00:00:00',NULL,'2016-07-08 00:00:00',NULL,'NON_CLUSTERED1467628831077');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 00:10:00',NULL,'2016-07-08 00:10:00',NULL,'NON_CLUSTERED1467628831078'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 00:10:00',NULL,'2016-07-08 00:10:00',NULL,'NON_CLUSTERED1467628831079'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 00:20:00',NULL,'2016-07-08 00:20:00',NULL,'NON_CLUSTERED1467628831080'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 00:20:00',NULL,'2016-07-08 00:20:00',NULL,'NON_CLUSTERED1467628831081'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 00:30:00',NULL,'2016-07-08 00:30:00',NULL,'NON_CLUSTERED1467628831082');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 00:30:00',NULL,'2016-07-08 00:30:00',NULL,'NON_CLUSTERED1467628831083'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 00:40:00',NULL,'2016-07-08 00:40:00',NULL,'NON_CLUSTERED1467628831084'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 00:40:00',NULL,'2016-07-08 00:40:00',NULL,'NON_CLUSTERED1467628831085'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 00:50:00',NULL,'2016-07-08 00:50:00',NULL,'NON_CLUSTERED1467628831086'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 00:50:00',NULL,'2016-07-08 00:50:00',NULL,'NON_CLUSTERED1467628831087');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 01:00:00',NULL,'2016-07-08 01:00:00',NULL,'NON_CLUSTERED1467628831088'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 01:00:00',NULL,'2016-07-08 01:00:00',NULL,'NON_CLUSTERED1467628831089'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 01:10:00',NULL,'2016-07-08 01:10:00',NULL,'NON_CLUSTERED1467628831090'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 01:10:00',NULL,'2016-07-08 01:10:00',NULL,'NON_CLUSTERED1467628831091'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 01:20:00',NULL,'2016-07-08 01:20:00',NULL,'NON_CLUSTERED1467628831092');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 01:20:00',NULL,'2016-07-08 01:20:00',NULL,'NON_CLUSTERED1467628831093'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 01:30:00',NULL,'2016-07-08 01:30:00',NULL,'NON_CLUSTERED1467628831094'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 01:30:00',NULL,'2016-07-08 01:30:00',NULL,'NON_CLUSTERED1467628831095'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 01:40:00',NULL,'2016-07-08 01:40:00',NULL,'NON_CLUSTERED1467628831096'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 01:40:00',NULL,'2016-07-08 01:40:00',NULL,'NON_CLUSTERED1467628831097');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 01:50:00',NULL,'2016-07-08 01:50:00',NULL,'NON_CLUSTERED1467628831098'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 01:50:00',NULL,'2016-07-08 01:50:00',NULL,'NON_CLUSTERED1467628831099'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 02:00:00',NULL,'2016-07-08 02:00:00',NULL,'NON_CLUSTERED1467628831100'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 02:00:00',NULL,'2016-07-08 02:00:00',NULL,'NON_CLUSTERED1467628831101'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 02:10:00',NULL,'2016-07-08 02:10:00',NULL,'NON_CLUSTERED1467628831102');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 02:10:00',NULL,'2016-07-08 02:10:00',NULL,'NON_CLUSTERED1467628831103'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 02:20:00',NULL,'2016-07-08 02:20:00',NULL,'NON_CLUSTERED1467628831104'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 02:20:00',NULL,'2016-07-08 02:20:00',NULL,'NON_CLUSTERED1467628831105'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 02:30:00',NULL,'2016-07-08 02:30:00',NULL,'NON_CLUSTERED1467628831106'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 02:30:00',NULL,'2016-07-08 02:30:00',NULL,'NON_CLUSTERED1467628831107');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 02:40:00',NULL,'2016-07-08 02:40:00',NULL,'NON_CLUSTERED1467628831108'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 02:40:00',NULL,'2016-07-08 02:40:00',NULL,'NON_CLUSTERED1467628831109'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 02:50:00',NULL,'2016-07-08 02:50:00',NULL,'NON_CLUSTERED1467628831110'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 02:50:00',NULL,'2016-07-08 02:50:00',NULL,'NON_CLUSTERED1467628831111'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 03:00:00',NULL,'2016-07-08 03:00:00',NULL,'NON_CLUSTERED1467628831112');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 03:00:00',NULL,'2016-07-08 03:00:00',NULL,'NON_CLUSTERED1467628831113'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 03:10:00',NULL,'2016-07-08 03:10:00',NULL,'NON_CLUSTERED1467628831114'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 03:10:00',NULL,'2016-07-08 03:10:00',NULL,'NON_CLUSTERED1467628831115'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 03:20:00',NULL,'2016-07-08 03:20:00',NULL,'NON_CLUSTERED1467628831116'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 03:20:00',NULL,'2016-07-08 03:20:00',NULL,'NON_CLUSTERED1467628831117');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 03:30:00',NULL,'2016-07-08 03:30:00',NULL,'NON_CLUSTERED1467628831118'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 03:30:00',NULL,'2016-07-08 03:30:00',NULL,'NON_CLUSTERED1467628831119'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 03:40:00',NULL,'2016-07-08 03:40:00',NULL,'NON_CLUSTERED1467628831120'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 03:40:00',NULL,'2016-07-08 03:40:00',NULL,'NON_CLUSTERED1467628831121'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 03:50:00',NULL,'2016-07-08 03:50:00',NULL,'NON_CLUSTERED1467628831122');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 03:50:00',NULL,'2016-07-08 03:50:00',NULL,'NON_CLUSTERED1467628831123'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 04:00:00',NULL,'2016-07-08 04:00:00',NULL,'NON_CLUSTERED1467628831124'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 04:00:00',NULL,'2016-07-08 04:00:00',NULL,'NON_CLUSTERED1467628831125'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 04:10:00',NULL,'2016-07-08 04:10:00',NULL,'NON_CLUSTERED1467628831126'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 04:10:00',NULL,'2016-07-08 04:10:00',NULL,'NON_CLUSTERED1467628831127');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 04:20:00',NULL,'2016-07-08 04:20:00',NULL,'NON_CLUSTERED1467628831128'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 04:20:00',NULL,'2016-07-08 04:20:00',NULL,'NON_CLUSTERED1467628831129'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 04:30:00',NULL,'2016-07-08 04:30:00',NULL,'NON_CLUSTERED1467628831130'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 04:30:00',NULL,'2016-07-08 04:30:00',NULL,'NON_CLUSTERED1467628831131'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 04:40:00',NULL,'2016-07-08 04:40:00',NULL,'NON_CLUSTERED1467628831132');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 04:40:00',NULL,'2016-07-08 04:40:00',NULL,'NON_CLUSTERED1467628831133'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 04:50:00',NULL,'2016-07-08 04:50:00',NULL,'NON_CLUSTERED1467628831134'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 04:50:00',NULL,'2016-07-08 04:50:00',NULL,'NON_CLUSTERED1467628831135'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 05:00:00',NULL,'2016-07-08 05:00:00',NULL,'NON_CLUSTERED1467628831136'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 05:00:00',NULL,'2016-07-08 05:00:00',NULL,'NON_CLUSTERED1467628831137');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 05:10:00',NULL,'2016-07-08 05:10:00',NULL,'NON_CLUSTERED1467628831138'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 05:10:00',NULL,'2016-07-08 05:10:00',NULL,'NON_CLUSTERED1467628831139'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 05:20:00',NULL,'2016-07-08 05:20:00',NULL,'NON_CLUSTERED1467628831140'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 05:20:00',NULL,'2016-07-08 05:20:00',NULL,'NON_CLUSTERED1467628831141'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 05:30:00',NULL,'2016-07-08 05:30:00',NULL,'NON_CLUSTERED1467628831142');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 05:30:00',NULL,'2016-07-08 05:30:00',NULL,'NON_CLUSTERED1467628831143'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 05:40:00',NULL,'2016-07-08 05:40:00',NULL,'NON_CLUSTERED1467628831144'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 05:40:00',NULL,'2016-07-08 05:40:00',NULL,'NON_CLUSTERED1467628831145'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 05:50:00',NULL,'2016-07-08 05:50:00',NULL,'NON_CLUSTERED1467628831146'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 05:50:00',NULL,'2016-07-08 05:50:00',NULL,'NON_CLUSTERED1467628831147');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 06:00:00',NULL,'2016-07-08 06:00:00',NULL,'NON_CLUSTERED1467628831148'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 06:00:00',NULL,'2016-07-08 06:00:00',NULL,'NON_CLUSTERED1467628831149'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 06:10:00',NULL,'2016-07-08 06:10:00',NULL,'NON_CLUSTERED1467628831150'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 06:10:00',NULL,'2016-07-08 06:10:00',NULL,'NON_CLUSTERED1467628831151'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 06:20:00',NULL,'2016-07-08 06:20:00',NULL,'NON_CLUSTERED1467628831152');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 06:20:00',NULL,'2016-07-08 06:20:00',NULL,'NON_CLUSTERED1467628831153'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 06:30:00',NULL,'2016-07-08 06:30:00',NULL,'NON_CLUSTERED1467628831154'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 06:30:00',NULL,'2016-07-08 06:30:00',NULL,'NON_CLUSTERED1467628831155'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 06:40:00',NULL,'2016-07-08 06:40:00',NULL,'NON_CLUSTERED1467628831156'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 06:40:00',NULL,'2016-07-08 06:40:00',NULL,'NON_CLUSTERED1467628831157');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 06:50:00',NULL,'2016-07-08 06:50:00',NULL,'NON_CLUSTERED1467628831158'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 06:50:00',NULL,'2016-07-08 06:50:00',NULL,'NON_CLUSTERED1467628831159'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 07:00:00',NULL,'2016-07-08 07:00:00',NULL,'NON_CLUSTERED1467628831160'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 07:00:00',NULL,'2016-07-08 07:00:00',NULL,'NON_CLUSTERED1467628831161'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 07:10:00',NULL,'2016-07-08 07:10:00',NULL,'NON_CLUSTERED1467628831162');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 07:10:00',NULL,'2016-07-08 07:10:00',NULL,'NON_CLUSTERED1467628831163'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 07:20:00',NULL,'2016-07-08 07:20:00',NULL,'NON_CLUSTERED1467628831164'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 07:20:00',NULL,'2016-07-08 07:20:00',NULL,'NON_CLUSTERED1467628831165'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 07:30:00',NULL,'2016-07-08 07:30:00',NULL,'NON_CLUSTERED1467628831166'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 07:30:00',NULL,'2016-07-08 07:30:00',NULL,'NON_CLUSTERED1467628831167');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 07:40:00',NULL,'2016-07-08 07:40:00',NULL,'NON_CLUSTERED1467628831168'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 07:40:00',NULL,'2016-07-08 07:40:00',NULL,'NON_CLUSTERED1467628831169'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 07:50:00',NULL,'2016-07-08 07:50:00',NULL,'NON_CLUSTERED1467628831170'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 07:50:00',NULL,'2016-07-08 07:50:00',NULL,'NON_CLUSTERED1467628831171'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 08:00:00',NULL,'2016-07-08 08:00:00',NULL,'NON_CLUSTERED1467628831172');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 08:00:00',NULL,'2016-07-08 08:00:00',NULL,'NON_CLUSTERED1467628831173'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 08:10:00',NULL,'2016-07-08 08:10:00',NULL,'NON_CLUSTERED1467628831174'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 08:10:00',NULL,'2016-07-08 08:10:00',NULL,'NON_CLUSTERED1467628831175'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 08:20:00',NULL,'2016-07-08 08:20:00',NULL,'NON_CLUSTERED1467628831176'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 08:20:00',NULL,'2016-07-08 08:20:00',NULL,'NON_CLUSTERED1467628831177');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 08:30:00',NULL,'2016-07-08 08:30:00',NULL,'NON_CLUSTERED1467628831178'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 08:30:00',NULL,'2016-07-08 08:30:00',NULL,'NON_CLUSTERED1467628831179'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 08:40:00',NULL,'2016-07-08 08:40:00',NULL,'NON_CLUSTERED1467628831180'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 08:40:00',NULL,'2016-07-08 08:40:00',NULL,'NON_CLUSTERED1467628831181'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 08:50:00',NULL,'2016-07-08 08:50:01',NULL,'NON_CLUSTERED1467628831182');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 08:50:02',NULL,'2016-07-08 08:50:02',NULL,'NON_CLUSTERED1467628831183'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 09:00:00',NULL,'2016-07-08 09:00:00',NULL,'NON_CLUSTERED1467628831184'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 09:00:00',NULL,'2016-07-08 09:00:00',NULL,'NON_CLUSTERED1467628831185'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 09:10:00',NULL,'2016-07-08 09:10:00',NULL,'NON_CLUSTERED1467628831186'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 09:10:00',NULL,'2016-07-08 09:10:00',NULL,'NON_CLUSTERED1467628831187');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 09:20:00',NULL,'2016-07-08 09:20:00',NULL,'NON_CLUSTERED1467628831188'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 09:20:00',NULL,'2016-07-08 09:20:00',NULL,'NON_CLUSTERED1467628831189'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 09:30:00',NULL,'2016-07-08 09:30:00',NULL,'NON_CLUSTERED1467628831190'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 09:30:00',NULL,'2016-07-08 09:30:00',NULL,'NON_CLUSTERED1467628831191'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 09:40:00',NULL,'2016-07-08 09:40:00',NULL,'NON_CLUSTERED1467628831192');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 09:40:00',NULL,'2016-07-08 09:40:00',NULL,'NON_CLUSTERED1467628831193'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 09:50:00',NULL,'2016-07-08 09:50:00',NULL,'NON_CLUSTERED1467628831194'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 09:50:00',NULL,'2016-07-08 09:50:00',NULL,'NON_CLUSTERED1467628831195'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 10:00:00',NULL,'2016-07-08 10:00:00',NULL,'NON_CLUSTERED1467628831196'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 10:00:00',NULL,'2016-07-08 10:00:00',NULL,'NON_CLUSTERED1467628831197');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 10:10:00',NULL,'2016-07-08 10:10:00',NULL,'NON_CLUSTERED1467628831198'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 10:10:00',NULL,'2016-07-08 10:10:00',NULL,'NON_CLUSTERED1467628831199'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 10:20:00',NULL,'2016-07-08 10:20:00',NULL,'NON_CLUSTERED1467628831200'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 10:20:00',NULL,'2016-07-08 10:20:00',NULL,'NON_CLUSTERED1467628831201'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 10:30:00',NULL,'2016-07-08 10:30:00',NULL,'NON_CLUSTERED1467628831202');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 10:30:00',NULL,'2016-07-08 10:30:00',NULL,'NON_CLUSTERED1467628831203'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 10:40:00',NULL,'2016-07-08 10:40:00',NULL,'NON_CLUSTERED1467628831204'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 10:40:00',NULL,'2016-07-08 10:40:00',NULL,'NON_CLUSTERED1467628831205'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 10:50:00',NULL,'2016-07-08 10:50:00',NULL,'NON_CLUSTERED1467628831206'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 10:50:00',NULL,'2016-07-08 10:50:00',NULL,'NON_CLUSTERED1467628831207');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 11:00:00',NULL,'2016-07-08 11:00:00',NULL,'NON_CLUSTERED1467628831208'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 11:00:00',NULL,'2016-07-08 11:00:00',NULL,'NON_CLUSTERED1467628831209'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 11:10:00',NULL,'2016-07-08 11:10:00',NULL,'NON_CLUSTERED1467628831210'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 11:10:00',NULL,'2016-07-08 11:10:00',NULL,'NON_CLUSTERED1467628831211'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 11:20:00',NULL,'2016-07-08 11:20:00',NULL,'NON_CLUSTERED1467628831212');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 11:20:00',NULL,'2016-07-08 11:20:00',NULL,'NON_CLUSTERED1467628831213'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 11:30:00',NULL,'2016-07-08 11:30:00',NULL,'NON_CLUSTERED1467628831214'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 11:30:00',NULL,'2016-07-08 11:30:00',NULL,'NON_CLUSTERED1467628831215'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 11:40:00',NULL,'2016-07-08 11:40:00',NULL,'NON_CLUSTERED1467628831216'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 11:40:00',NULL,'2016-07-08 11:40:00',NULL,'NON_CLUSTERED1467628831217');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 11:50:00',NULL,'2016-07-08 11:50:00',NULL,'NON_CLUSTERED1467628831218'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-08 11:50:00',NULL,'2016-07-08 11:50:00',NULL,'NON_CLUSTERED1467628831219'),
 ('triggerkey_21','triggerkeyGroup_21','jobkey_21','jobkeyGroup_21','DELETE TRIGGER','COMPLETED','SYSTEM','2016-07-11 15:11:43',NULL,'2016-07-11 15:16:15',21,'NON_CLUSTERED1468229188142'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 15:20:00',NULL,'2016-07-11 15:20:00',NULL,'NON_CLUSTERED1468229188143'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 15:20:00',NULL,'2016-07-11 15:20:00',NULL,'NON_CLUSTERED1468229188144');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('triggerkey_22','triggerkeyGroup_22','jobkey_22','jobkeyGroup_22','DELETE TRIGGER','COMPLETED','SYSTEM','2016-07-11 15:21:32',NULL,'2016-07-11 15:25:03',22,'NON_CLUSTERED1468229188145'),
 ('Trigger Key ReservationExpiration Mail','System Triggers','Job Key Reservation Expiration Mail','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 15:23:00',NULL,'2016-07-11 15:23:00',NULL,'NON_CLUSTERED1468229188146'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 15:30:00',NULL,'2016-07-11 15:30:00',NULL,'NON_CLUSTERED1468229188147'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 15:30:00',NULL,'2016-07-11 15:30:00',NULL,'NON_CLUSTERED1468229188148'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 15:40:00',NULL,'2016-07-11 15:40:00',NULL,'NON_CLUSTERED1468229188149');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 15:40:00',NULL,'2016-07-11 15:40:00',NULL,'NON_CLUSTERED1468229188150'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 15:50:00',NULL,'2016-07-11 15:50:00',NULL,'NON_CLUSTERED1468229188151'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 15:50:00',NULL,'2016-07-11 15:50:00',NULL,'NON_CLUSTERED1468229188152'),
 ('triggerkey_23','triggerkeyGroup_23','jobkey_23','jobkeyGroup_23','DELETE TRIGGER','COMPLETED','SYSTEM','2016-07-11 15:52:50',NULL,'2016-07-11 16:00:56',23,'NON_CLUSTERED1468229188153'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 16:00:00',NULL,'2016-07-11 16:00:00',NULL,'NON_CLUSTERED1468229188154');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 16:00:00',NULL,'2016-07-11 16:00:00',NULL,'NON_CLUSTERED1468229188155'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 16:10:00',NULL,'2016-07-11 16:10:00',NULL,'NON_CLUSTERED1468229188156'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 16:10:00',NULL,'2016-07-11 16:10:00',NULL,'NON_CLUSTERED1468229188157'),
 ('triggerkey_24','triggerkeyGroup_24','jobkey_24','jobkeyGroup_24','DELETE TRIGGER','COMPLETED','SYSTEM','2016-07-11 16:16:27',NULL,'2016-07-11 16:19:31',24,'NON_CLUSTERED1468229188158'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 16:20:00',NULL,'2016-07-11 16:20:00',NULL,'NON_CLUSTERED1468229188159');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 16:20:00',NULL,'2016-07-11 16:20:00',NULL,'NON_CLUSTERED1468229188160'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 16:30:00',NULL,'2016-07-11 16:30:00',NULL,'NON_CLUSTERED1468229188161'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 16:30:00',NULL,'2016-07-11 16:30:00',NULL,'NON_CLUSTERED1468229188162'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 16:40:00',NULL,'2016-07-11 16:40:00',NULL,'NON_CLUSTERED1468229188163'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 16:40:00',NULL,'2016-07-11 16:40:00',NULL,'NON_CLUSTERED1468229188164');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 16:50:00',NULL,'2016-07-11 16:50:00',NULL,'NON_CLUSTERED1468229188165'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 16:50:00',NULL,'2016-07-11 16:50:00',NULL,'NON_CLUSTERED1468229188166'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 17:00:00',NULL,'2016-07-11 17:00:00',NULL,'NON_CLUSTERED1468229188167'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 17:00:00',NULL,'2016-07-11 17:00:00',NULL,'NON_CLUSTERED1468229188168'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 17:10:00',NULL,'2016-07-11 17:10:00',NULL,'NON_CLUSTERED1468229188169');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 17:10:00',NULL,'2016-07-11 17:10:00',NULL,'NON_CLUSTERED1468229188170'),
 ('triggerkey_25','triggerkeyGroup_25','jobkey_25','jobkeyGroup_25','DELETE TRIGGER','COMPLETED','SYSTEM','2016-07-11 17:10:05',NULL,'2016-07-11 17:11:08',25,'NON_CLUSTERED1468229188171'),
 ('triggerkey_26','triggerkeyGroup_26','jobkey_26','jobkeyGroup_26','DELETE TRIGGER','COMPLETED','SYSTEM','2016-07-11 17:14:25',NULL,'2016-07-11 17:19:28',26,'NON_CLUSTERED1468229188172'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 17:20:00',NULL,'2016-07-11 17:20:00',NULL,'NON_CLUSTERED1468229188173'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 17:20:00',NULL,'2016-07-11 17:20:00',NULL,'NON_CLUSTERED1468229188174');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 17:30:00',NULL,'2016-07-11 17:30:00',NULL,'NON_CLUSTERED1468229188175'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 17:30:00',NULL,'2016-07-11 17:30:00',NULL,'NON_CLUSTERED1468229188176'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 17:40:00',NULL,'2016-07-11 17:40:00',NULL,'NON_CLUSTERED1468229188177'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 17:40:00',NULL,'2016-07-11 17:40:00',NULL,'NON_CLUSTERED1468229188178'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 17:50:00',NULL,'2016-07-11 17:50:00',NULL,'NON_CLUSTERED1468229188179');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 17:50:00',NULL,'2016-07-11 17:50:00',NULL,'NON_CLUSTERED1468229188180'),
 ('triggerkey_27','triggerkeyGroup_27','jobkey_27','jobkeyGroup_27','DELETE TRIGGER','COMPLETED','SYSTEM','2016-07-11 17:58:36',NULL,'2016-07-11 18:10:09',27,'NON_CLUSTERED1468229188181'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 18:00:00',NULL,'2016-07-11 18:00:00',NULL,'NON_CLUSTERED1468229188182'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 18:00:00',NULL,'2016-07-11 18:00:00',NULL,'NON_CLUSTERED1468229188183'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 18:10:00',NULL,'2016-07-11 18:10:00',NULL,'NON_CLUSTERED1468229188184');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 18:10:00',NULL,'2016-07-11 18:10:00',NULL,'NON_CLUSTERED1468229188185'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 18:20:00',NULL,'2016-07-11 18:20:00',NULL,'NON_CLUSTERED1468229188186'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 18:20:00',NULL,'2016-07-11 18:20:00',NULL,'NON_CLUSTERED1468229188187'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 18:30:00',NULL,'2016-07-11 18:30:00',NULL,'NON_CLUSTERED1468229188188'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 18:30:00',NULL,'2016-07-11 18:30:00',NULL,'NON_CLUSTERED1468229188189');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 18:40:00',NULL,'2016-07-11 18:40:00',NULL,'NON_CLUSTERED1468229188190'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 18:40:00',NULL,'2016-07-11 18:40:00',NULL,'NON_CLUSTERED1468229188191'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 18:50:00',NULL,'2016-07-11 18:50:00',NULL,'NON_CLUSTERED1468229188192'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 18:50:00',NULL,'2016-07-11 18:50:00',NULL,'NON_CLUSTERED1468229188193'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 19:00:00',NULL,'2016-07-11 19:00:00',NULL,'NON_CLUSTERED1468229188194');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-11 19:00:00',NULL,'2016-07-11 19:00:00',NULL,'NON_CLUSTERED1468229188195'),
 ('triggerkey_28','triggerkeyGroup_28','jobkey_28','jobkeyGroup_28','DELETE TRIGGER','COMPLETED','SYSTEM','2016-07-12 11:46:56',NULL,'2016-07-12 11:53:04',28,'NON_CLUSTERED1468303562100'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 11:50:00',NULL,'2016-07-12 11:50:00',NULL,'NON_CLUSTERED1468303562101'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 11:50:00',NULL,'2016-07-12 11:50:00',NULL,'NON_CLUSTERED1468303562102'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 12:00:00',NULL,'2016-07-12 12:00:00',NULL,'NON_CLUSTERED1468303562103');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 12:00:00',NULL,'2016-07-12 12:00:00',NULL,'NON_CLUSTERED1468303562104'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 12:10:00',NULL,'2016-07-12 12:10:00',NULL,'NON_CLUSTERED1468303562105'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 12:10:00',NULL,'2016-07-12 12:10:00',NULL,'NON_CLUSTERED1468303562106'),
 ('triggerkey_29','triggerkeyGroup_29','jobkey_29','jobkeyGroup_29','DELETE TRIGGER','COMPLETED','SYSTEM','2016-07-12 12:16:15',NULL,'2016-07-12 12:17:24',29,'NON_CLUSTERED1468303562107'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 12:20:00',NULL,'2016-07-12 12:20:00',NULL,'NON_CLUSTERED1468303562108');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 12:20:00',NULL,'2016-07-12 12:20:00',NULL,'NON_CLUSTERED1468303562109'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 12:30:00',NULL,'2016-07-12 12:30:00',NULL,'NON_CLUSTERED1468303562110'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 12:30:00',NULL,'2016-07-12 12:30:00',NULL,'NON_CLUSTERED1468303562111'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 12:40:00',NULL,'2016-07-12 12:40:00',NULL,'NON_CLUSTERED1468303562112'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 12:40:00',NULL,'2016-07-12 12:40:00',NULL,'NON_CLUSTERED1468303562113');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 12:50:00',NULL,'2016-07-12 12:50:00',NULL,'NON_CLUSTERED1468303562114'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 12:50:00',NULL,'2016-07-12 12:50:00',NULL,'NON_CLUSTERED1468303562115'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 13:00:00',NULL,'2016-07-12 13:00:00',NULL,'NON_CLUSTERED1468303562116'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 13:00:00',NULL,'2016-07-12 13:00:00',NULL,'NON_CLUSTERED1468303562117'),
 ('triggerkey_30','triggerkeyGroup_30','jobkey_30','jobkeyGroup_30','DELETE TRIGGER','COMPLETED','SYSTEM','2016-07-12 13:06:37',NULL,'2016-07-12 13:07:04',30,'NON_CLUSTERED1468303562118');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 13:10:00',NULL,'2016-07-12 13:10:00',NULL,'NON_CLUSTERED1468303562119'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 13:10:00',NULL,'2016-07-12 13:10:00',NULL,'NON_CLUSTERED1468303562120'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 13:20:00',NULL,'2016-07-12 13:20:00',NULL,'NON_CLUSTERED1468303562121'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 13:20:00',NULL,'2016-07-12 13:20:00',NULL,'NON_CLUSTERED1468303562122'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 13:30:00',NULL,'2016-07-12 13:30:00',NULL,'NON_CLUSTERED1468303562123');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 13:30:00',NULL,'2016-07-12 13:30:00',NULL,'NON_CLUSTERED1468303562124'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 13:40:00',NULL,'2016-07-12 13:40:00',NULL,'NON_CLUSTERED1468303562125'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 13:40:00',NULL,'2016-07-12 13:40:00',NULL,'NON_CLUSTERED1468303562126'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 13:50:00',NULL,'2016-07-12 13:50:00',NULL,'NON_CLUSTERED1468303562127'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 13:50:00',NULL,'2016-07-12 13:50:00',NULL,'NON_CLUSTERED1468303562128');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 14:00:00',NULL,'2016-07-12 14:00:00',NULL,'NON_CLUSTERED1468303562129'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 14:00:00',NULL,'2016-07-12 14:00:00',NULL,'NON_CLUSTERED1468303562130'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 14:10:00',NULL,'2016-07-12 14:10:00',NULL,'NON_CLUSTERED1468303562131'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 14:10:00',NULL,'2016-07-12 14:10:00',NULL,'NON_CLUSTERED1468303562132'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 14:20:00',NULL,'2016-07-12 14:20:00',NULL,'NON_CLUSTERED1468303562133');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 14:20:00',NULL,'2016-07-12 14:20:00',NULL,'NON_CLUSTERED1468303562134'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 14:30:00',NULL,'2016-07-12 14:30:00',NULL,'NON_CLUSTERED1468303562135'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 14:30:00',NULL,'2016-07-12 14:30:00',NULL,'NON_CLUSTERED1468303562136'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 14:40:00',NULL,'2016-07-12 14:40:00',NULL,'NON_CLUSTERED1468303562137'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 14:40:01',NULL,'2016-07-12 14:40:01',NULL,'NON_CLUSTERED1468303562138');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 14:50:00',NULL,'2016-07-12 14:50:00',NULL,'NON_CLUSTERED1468303562139'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 14:50:00',NULL,'2016-07-12 14:50:00',NULL,'NON_CLUSTERED1468303562140'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 15:00:00',NULL,'2016-07-12 15:00:00',NULL,'NON_CLUSTERED1468303562141'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 15:00:00',NULL,'2016-07-12 15:00:00',NULL,'NON_CLUSTERED1468303562142'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 15:10:00',NULL,'2016-07-12 15:10:00',NULL,'NON_CLUSTERED1468303562143');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 15:10:00',NULL,'2016-07-12 15:10:00',NULL,'NON_CLUSTERED1468303562144'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 15:20:00',NULL,'2016-07-12 15:20:00',NULL,'NON_CLUSTERED1468303562145'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 15:20:00',NULL,'2016-07-12 15:20:00',NULL,'NON_CLUSTERED1468303562146'),
 ('Trigger Key ReservationExpiration Mail','System Triggers','Job Key Reservation Expiration Mail','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 15:23:00',NULL,'2016-07-12 15:23:00',NULL,'NON_CLUSTERED1468303562147'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 15:30:00',NULL,'2016-07-12 15:30:00',NULL,'NON_CLUSTERED1468303562148');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 15:30:00',NULL,'2016-07-12 15:30:00',NULL,'NON_CLUSTERED1468303562149'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 15:40:00',NULL,'2016-07-12 15:40:00',NULL,'NON_CLUSTERED1468303562150'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 15:40:00',NULL,'2016-07-12 15:40:00',NULL,'NON_CLUSTERED1468303562151'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 15:50:00',NULL,'2016-07-12 15:50:00',NULL,'NON_CLUSTERED1468303562152'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 15:50:00',NULL,'2016-07-12 15:50:00',NULL,'NON_CLUSTERED1468303562153');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 16:00:00',NULL,'2016-07-12 16:00:00',NULL,'NON_CLUSTERED1468303562154'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 16:00:00',NULL,'2016-07-12 16:00:00',NULL,'NON_CLUSTERED1468303562155'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 16:10:00',NULL,'2016-07-12 16:10:00',NULL,'NON_CLUSTERED1468303562156'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 16:10:00',NULL,'2016-07-12 16:10:00',NULL,'NON_CLUSTERED1468303562157'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 16:20:00',NULL,'2016-07-12 16:20:00',NULL,'NON_CLUSTERED1468303562158');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 16:20:00',NULL,'2016-07-12 16:20:00',NULL,'NON_CLUSTERED1468303562159'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 16:30:00',NULL,'2016-07-12 16:30:00',NULL,'NON_CLUSTERED1468303562160'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 16:30:00',NULL,'2016-07-12 16:30:00',NULL,'NON_CLUSTERED1468303562161'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 16:40:00',NULL,'2016-07-12 16:40:00',NULL,'NON_CLUSTERED1468303562162'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 16:40:00',NULL,'2016-07-12 16:40:00',NULL,'NON_CLUSTERED1468303562163');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 16:50:00',NULL,'2016-07-12 16:50:00',NULL,'NON_CLUSTERED1468303562164'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 16:50:00',NULL,'2016-07-12 16:50:00',NULL,'NON_CLUSTERED1468303562165'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 17:00:00',NULL,'2016-07-12 17:00:00',NULL,'NON_CLUSTERED1468303562166'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 17:00:00',NULL,'2016-07-12 17:00:00',NULL,'NON_CLUSTERED1468303562167'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 17:10:00',NULL,'2016-07-12 17:10:00',NULL,'NON_CLUSTERED1468303562168');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 17:10:00',NULL,'2016-07-12 17:10:00',NULL,'NON_CLUSTERED1468303562169'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 17:20:00',NULL,'2016-07-12 17:20:00',NULL,'NON_CLUSTERED1468303562170'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 17:20:00',NULL,'2016-07-12 17:20:00',NULL,'NON_CLUSTERED1468303562171'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 17:30:00',NULL,'2016-07-12 17:30:00',NULL,'NON_CLUSTERED1468303562172'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 17:30:00',NULL,'2016-07-12 17:30:00',NULL,'NON_CLUSTERED1468303562173');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 17:40:00',NULL,'2016-07-12 17:40:00',NULL,'NON_CLUSTERED1468303562174'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 17:40:00',NULL,'2016-07-12 17:40:00',NULL,'NON_CLUSTERED1468303562175'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 17:50:00',NULL,'2016-07-12 17:50:00',NULL,'NON_CLUSTERED1468303562176'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 17:50:00',NULL,'2016-07-12 17:50:00',NULL,'NON_CLUSTERED1468303562177'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 18:00:00',NULL,'2016-07-12 18:00:00',NULL,'NON_CLUSTERED1468303562178');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 18:00:00',NULL,'2016-07-12 18:00:00',NULL,'NON_CLUSTERED1468303562179'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 18:10:00',NULL,'2016-07-12 18:10:00',NULL,'NON_CLUSTERED1468303562180'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-12 18:10:00',NULL,'2016-07-12 18:10:00',NULL,'NON_CLUSTERED1468303562181'),
 ('triggerkey_31','triggerkeyGroup_31','jobkey_31','jobkeyGroup_31','DELETE TRIGGER','COMPLETED','SYSTEM','2016-07-13 17:22:10',NULL,'2016-07-13 17:33:25',31,'NON_CLUSTERED1468330467371'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 17:30:00',NULL,'2016-07-13 17:30:00',NULL,'NON_CLUSTERED1468330467372');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 17:30:00',NULL,'2016-07-13 17:30:00',NULL,'NON_CLUSTERED1468330467373'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 17:40:00',NULL,'2016-07-13 17:40:00',NULL,'NON_CLUSTERED1468330467374'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 17:40:00',NULL,'2016-07-13 17:40:00',NULL,'NON_CLUSTERED1468330467375'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 17:50:00',NULL,'2016-07-13 17:50:00',NULL,'NON_CLUSTERED1468330467376'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 17:50:00',NULL,'2016-07-13 17:50:00',NULL,'NON_CLUSTERED1468330467377');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('triggerkey_32','triggerkeyGroup_32','jobkey_32','jobkeyGroup_32','DELETE TRIGGER','COMPLETED','SYSTEM','2016-07-13 17:59:47',NULL,'2016-07-13 18:48:07',32,'NON_CLUSTERED1468330467379'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 18:00:00',NULL,'2016-07-13 18:00:00',NULL,'NON_CLUSTERED1468330467380'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 18:00:00',NULL,'2016-07-13 18:00:00',NULL,'NON_CLUSTERED1468330467381'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 18:10:00',NULL,'2016-07-13 18:10:00',NULL,'NON_CLUSTERED1468330467382'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 18:10:00',NULL,'2016-07-13 18:10:00',NULL,'NON_CLUSTERED1468330467383');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 18:20:00',NULL,'2016-07-13 18:20:00',NULL,'NON_CLUSTERED1468330467384'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 18:20:00',NULL,'2016-07-13 18:20:00',NULL,'NON_CLUSTERED1468330467385'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 18:30:00',NULL,'2016-07-13 18:30:00',NULL,'NON_CLUSTERED1468330467386'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 18:30:00',NULL,'2016-07-13 18:30:00',NULL,'NON_CLUSTERED1468330467387'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 18:40:00',NULL,'2016-07-13 18:40:00',NULL,'NON_CLUSTERED1468330467388');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 18:40:00',NULL,'2016-07-13 18:40:00',NULL,'NON_CLUSTERED1468330467389'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 18:50:00',NULL,'2016-07-13 18:50:00',NULL,'NON_CLUSTERED1468330467390'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 18:50:00',NULL,'2016-07-13 18:50:00',NULL,'NON_CLUSTERED1468330467391'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 19:00:00',NULL,'2016-07-13 19:00:00',NULL,'NON_CLUSTERED1468330467392'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 19:00:00',NULL,'2016-07-13 19:00:00',NULL,'NON_CLUSTERED1468330467393');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 19:10:00',NULL,'2016-07-13 19:10:00',NULL,'NON_CLUSTERED1468330467394'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 19:10:00',NULL,'2016-07-13 19:10:00',NULL,'NON_CLUSTERED1468330467395'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 19:20:00',NULL,'2016-07-13 19:20:00',NULL,'NON_CLUSTERED1468330467396'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 19:20:00',NULL,'2016-07-13 19:20:00',NULL,'NON_CLUSTERED1468330467397'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 19:30:00',NULL,'2016-07-13 19:30:00',NULL,'NON_CLUSTERED1468330467398');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 19:30:00',NULL,'2016-07-13 19:30:00',NULL,'NON_CLUSTERED1468330467399'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 19:40:00',NULL,'2016-07-13 19:40:00',NULL,'NON_CLUSTERED1468330467400'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 19:40:00',NULL,'2016-07-13 19:40:00',NULL,'NON_CLUSTERED1468330467401'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 19:50:00',NULL,'2016-07-13 19:50:00',NULL,'NON_CLUSTERED1468330467402'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 19:50:00',NULL,'2016-07-13 19:50:00',NULL,'NON_CLUSTERED1468330467403');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 20:00:00',NULL,'2016-07-13 20:00:00',NULL,'NON_CLUSTERED1468330467404'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 20:00:00',NULL,'2016-07-13 20:00:00',NULL,'NON_CLUSTERED1468330467405'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 20:10:00',NULL,'2016-07-13 20:10:00',NULL,'NON_CLUSTERED1468330467406'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 20:10:00',NULL,'2016-07-13 20:10:00',NULL,'NON_CLUSTERED1468330467407'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 20:20:00',NULL,'2016-07-13 20:20:00',NULL,'NON_CLUSTERED1468330467408');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 20:20:00',NULL,'2016-07-13 20:20:00',NULL,'NON_CLUSTERED1468330467409'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 20:30:00',NULL,'2016-07-13 20:30:00',NULL,'NON_CLUSTERED1468330467410'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 20:30:00',NULL,'2016-07-13 20:30:00',NULL,'NON_CLUSTERED1468330467411'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 20:40:00',NULL,'2016-07-13 20:40:00',NULL,'NON_CLUSTERED1468330467412'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 20:40:00',NULL,'2016-07-13 20:40:00',NULL,'NON_CLUSTERED1468330467413');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 20:50:00',NULL,'2016-07-13 20:50:00',NULL,'NON_CLUSTERED1468330467414'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 20:50:00',NULL,'2016-07-13 20:50:00',NULL,'NON_CLUSTERED1468330467415'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 21:00:00',NULL,'2016-07-13 21:00:00',NULL,'NON_CLUSTERED1468330467416'),
 ('Trigger Key EnvironmentDeletion','System Triggers','Job Key EnvironmentDeletion','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 21:00:00',NULL,'2016-07-13 21:00:00',NULL,'NON_CLUSTERED1468330467417'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 21:00:00',NULL,'2016-07-13 21:00:00',NULL,'NON_CLUSTERED1468330467418');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 21:10:00',NULL,'2016-07-13 21:10:00',NULL,'NON_CLUSTERED1468330467419'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 21:10:00',NULL,'2016-07-13 21:10:00',NULL,'NON_CLUSTERED1468330467420'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 21:20:00',NULL,'2016-07-13 21:20:00',NULL,'NON_CLUSTERED1468330467421'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 21:20:00',NULL,'2016-07-13 21:20:00',NULL,'NON_CLUSTERED1468330467422'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 21:30:00',NULL,'2016-07-13 21:30:00',NULL,'NON_CLUSTERED1468330467423');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 21:30:00',NULL,'2016-07-13 21:30:00',NULL,'NON_CLUSTERED1468330467424'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 21:40:00',NULL,'2016-07-13 21:40:00',NULL,'NON_CLUSTERED1468330467425'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 21:40:00',NULL,'2016-07-13 21:40:00',NULL,'NON_CLUSTERED1468330467426'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 21:50:00',NULL,'2016-07-13 21:50:00',NULL,'NON_CLUSTERED1468330467427'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 21:50:00',NULL,'2016-07-13 21:50:00',NULL,'NON_CLUSTERED1468330467428');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 22:00:00',NULL,'2016-07-13 22:00:00',NULL,'NON_CLUSTERED1468330467429'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 22:00:00',NULL,'2016-07-13 22:00:00',NULL,'NON_CLUSTERED1468330467430'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 22:10:00',NULL,'2016-07-13 22:10:00',NULL,'NON_CLUSTERED1468330467431'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 22:10:00',NULL,'2016-07-13 22:10:00',NULL,'NON_CLUSTERED1468330467432'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 22:20:00',NULL,'2016-07-13 22:20:00',NULL,'NON_CLUSTERED1468330467433');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 22:20:00',NULL,'2016-07-13 22:20:00',NULL,'NON_CLUSTERED1468330467434'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 22:30:00',NULL,'2016-07-13 22:30:00',NULL,'NON_CLUSTERED1468330467435'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 22:30:00',NULL,'2016-07-13 22:30:00',NULL,'NON_CLUSTERED1468330467436'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 22:40:00',NULL,'2016-07-13 22:40:00',NULL,'NON_CLUSTERED1468330467437'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 22:40:00',NULL,'2016-07-13 22:40:00',NULL,'NON_CLUSTERED1468330467438');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 22:50:00',NULL,'2016-07-13 22:50:00',NULL,'NON_CLUSTERED1468330467439'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 22:50:00',NULL,'2016-07-13 22:50:00',NULL,'NON_CLUSTERED1468330467440'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 23:00:00',NULL,'2016-07-13 23:00:00',NULL,'NON_CLUSTERED1468330467441'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 23:00:00',NULL,'2016-07-13 23:00:00',NULL,'NON_CLUSTERED1468330467442'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 23:10:00',NULL,'2016-07-13 23:10:00',NULL,'NON_CLUSTERED1468330467443');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 23:10:00',NULL,'2016-07-13 23:10:00',NULL,'NON_CLUSTERED1468330467444'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 23:20:00',NULL,'2016-07-13 23:20:00',NULL,'NON_CLUSTERED1468330467445'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 23:20:00',NULL,'2016-07-13 23:20:00',NULL,'NON_CLUSTERED1468330467446'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 23:30:00',NULL,'2016-07-13 23:30:00',NULL,'NON_CLUSTERED1468330467447'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 23:30:00',NULL,'2016-07-13 23:30:00',NULL,'NON_CLUSTERED1468330467448');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 23:40:00',NULL,'2016-07-13 23:40:00',NULL,'NON_CLUSTERED1468330467449'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 23:40:00',NULL,'2016-07-13 23:40:00',NULL,'NON_CLUSTERED1468330467450'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 23:50:00',NULL,'2016-07-13 23:50:00',NULL,'NON_CLUSTERED1468330467451'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-13 23:50:00',NULL,'2016-07-13 23:50:00',NULL,'NON_CLUSTERED1468330467452'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 00:00:00',NULL,'2016-07-14 00:00:00',NULL,'NON_CLUSTERED1468330467453');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 00:00:00',NULL,'2016-07-14 00:00:00',NULL,'NON_CLUSTERED1468330467454'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 00:10:00',NULL,'2016-07-14 00:10:00',NULL,'NON_CLUSTERED1468330467455'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 00:10:00',NULL,'2016-07-14 00:10:00',NULL,'NON_CLUSTERED1468330467456'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 00:20:00',NULL,'2016-07-14 00:20:00',NULL,'NON_CLUSTERED1468330467457'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 00:20:00',NULL,'2016-07-14 00:20:00',NULL,'NON_CLUSTERED1468330467458');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 00:30:00',NULL,'2016-07-14 00:30:00',NULL,'NON_CLUSTERED1468330467459'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 00:30:00',NULL,'2016-07-14 00:30:00',NULL,'NON_CLUSTERED1468330467460'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 00:40:00',NULL,'2016-07-14 00:40:00',NULL,'NON_CLUSTERED1468330467461'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 00:40:00',NULL,'2016-07-14 00:40:00',NULL,'NON_CLUSTERED1468330467462'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 00:50:00',NULL,'2016-07-14 00:50:00',NULL,'NON_CLUSTERED1468330467463');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 00:50:00',NULL,'2016-07-14 00:50:00',NULL,'NON_CLUSTERED1468330467464'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 01:00:00',NULL,'2016-07-14 01:00:00',NULL,'NON_CLUSTERED1468330467465'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 01:00:00',NULL,'2016-07-14 01:00:00',NULL,'NON_CLUSTERED1468330467466'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 01:10:00',NULL,'2016-07-14 01:10:00',NULL,'NON_CLUSTERED1468330467467'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 01:10:00',NULL,'2016-07-14 01:10:00',NULL,'NON_CLUSTERED1468330467468');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 01:20:00',NULL,'2016-07-14 01:20:00',NULL,'NON_CLUSTERED1468330467469'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 01:20:00',NULL,'2016-07-14 01:20:00',NULL,'NON_CLUSTERED1468330467470'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 01:30:00',NULL,'2016-07-14 01:30:00',NULL,'NON_CLUSTERED1468330467471'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 01:30:00',NULL,'2016-07-14 01:30:00',NULL,'NON_CLUSTERED1468330467472'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 01:40:00',NULL,'2016-07-14 01:40:00',NULL,'NON_CLUSTERED1468330467473');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 01:40:00',NULL,'2016-07-14 01:40:00',NULL,'NON_CLUSTERED1468330467474'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 01:50:00',NULL,'2016-07-14 01:50:00',NULL,'NON_CLUSTERED1468330467475'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 01:50:00',NULL,'2016-07-14 01:50:00',NULL,'NON_CLUSTERED1468330467476'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 02:00:00',NULL,'2016-07-14 02:00:00',NULL,'NON_CLUSTERED1468330467477'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 02:00:00',NULL,'2016-07-14 02:00:00',NULL,'NON_CLUSTERED1468330467478');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 02:10:00',NULL,'2016-07-14 02:10:00',NULL,'NON_CLUSTERED1468330467479'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 02:10:00',NULL,'2016-07-14 02:10:00',NULL,'NON_CLUSTERED1468330467480'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 02:20:00',NULL,'2016-07-14 02:20:00',NULL,'NON_CLUSTERED1468330467481'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 02:20:00',NULL,'2016-07-14 02:20:00',NULL,'NON_CLUSTERED1468330467482'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 02:30:00',NULL,'2016-07-14 02:30:00',NULL,'NON_CLUSTERED1468330467483');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 02:30:00',NULL,'2016-07-14 02:30:00',NULL,'NON_CLUSTERED1468330467484'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 02:40:00',NULL,'2016-07-14 02:40:00',NULL,'NON_CLUSTERED1468330467485'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 02:40:00',NULL,'2016-07-14 02:40:00',NULL,'NON_CLUSTERED1468330467486'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 02:50:00',NULL,'2016-07-14 02:50:00',NULL,'NON_CLUSTERED1468330467487'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 02:50:00',NULL,'2016-07-14 02:50:00',NULL,'NON_CLUSTERED1468330467488');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 03:00:00',NULL,'2016-07-14 03:00:00',NULL,'NON_CLUSTERED1468330467489'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 03:00:00',NULL,'2016-07-14 03:00:00',NULL,'NON_CLUSTERED1468330467490'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 03:10:00',NULL,'2016-07-14 03:10:00',NULL,'NON_CLUSTERED1468330467491'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 03:10:00',NULL,'2016-07-14 03:10:00',NULL,'NON_CLUSTERED1468330467492'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 03:20:00',NULL,'2016-07-14 03:20:00',NULL,'NON_CLUSTERED1468330467493');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 03:20:00',NULL,'2016-07-14 03:20:00',NULL,'NON_CLUSTERED1468330467494'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 03:30:00',NULL,'2016-07-14 03:30:00',NULL,'NON_CLUSTERED1468330467495'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 03:30:00',NULL,'2016-07-14 03:30:00',NULL,'NON_CLUSTERED1468330467496'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 03:40:00',NULL,'2016-07-14 03:40:00',NULL,'NON_CLUSTERED1468330467497'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 03:40:00',NULL,'2016-07-14 03:40:00',NULL,'NON_CLUSTERED1468330467498');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 03:50:00',NULL,'2016-07-14 03:50:00',NULL,'NON_CLUSTERED1468330467499'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 03:50:00',NULL,'2016-07-14 03:50:00',NULL,'NON_CLUSTERED1468330467500'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 04:00:00',NULL,'2016-07-14 04:00:00',NULL,'NON_CLUSTERED1468330467501'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 04:00:00',NULL,'2016-07-14 04:00:00',NULL,'NON_CLUSTERED1468330467502'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 04:10:00',NULL,'2016-07-14 04:10:00',NULL,'NON_CLUSTERED1468330467503');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 04:10:00',NULL,'2016-07-14 04:10:00',NULL,'NON_CLUSTERED1468330467504'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 04:20:00',NULL,'2016-07-14 04:20:00',NULL,'NON_CLUSTERED1468330467505'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 04:20:00',NULL,'2016-07-14 04:20:00',NULL,'NON_CLUSTERED1468330467506'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 04:30:00',NULL,'2016-07-14 04:30:00',NULL,'NON_CLUSTERED1468330467507'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 04:30:00',NULL,'2016-07-14 04:30:00',NULL,'NON_CLUSTERED1468330467508');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 04:40:00',NULL,'2016-07-14 04:40:00',NULL,'NON_CLUSTERED1468330467509'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 04:40:00',NULL,'2016-07-14 04:40:00',NULL,'NON_CLUSTERED1468330467510'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 04:50:00',NULL,'2016-07-14 04:50:00',NULL,'NON_CLUSTERED1468330467511'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 04:50:00',NULL,'2016-07-14 04:50:00',NULL,'NON_CLUSTERED1468330467512'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 05:00:00',NULL,'2016-07-14 05:00:00',NULL,'NON_CLUSTERED1468330467513');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 05:00:00',NULL,'2016-07-14 05:00:00',NULL,'NON_CLUSTERED1468330467514'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 05:10:00',NULL,'2016-07-14 05:10:00',NULL,'NON_CLUSTERED1468330467515'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 05:10:00',NULL,'2016-07-14 05:10:00',NULL,'NON_CLUSTERED1468330467516'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 05:20:00',NULL,'2016-07-14 05:20:00',NULL,'NON_CLUSTERED1468330467517'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 05:20:00',NULL,'2016-07-14 05:20:00',NULL,'NON_CLUSTERED1468330467518');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 05:30:00',NULL,'2016-07-14 05:30:00',NULL,'NON_CLUSTERED1468330467519'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 05:30:00',NULL,'2016-07-14 05:30:00',NULL,'NON_CLUSTERED1468330467520'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 05:40:00',NULL,'2016-07-14 05:40:00',NULL,'NON_CLUSTERED1468330467521'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 05:40:00',NULL,'2016-07-14 05:40:00',NULL,'NON_CLUSTERED1468330467522'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 05:50:00',NULL,'2016-07-14 05:50:00',NULL,'NON_CLUSTERED1468330467523');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 05:50:00',NULL,'2016-07-14 05:50:00',NULL,'NON_CLUSTERED1468330467524'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 06:00:00',NULL,'2016-07-14 06:00:00',NULL,'NON_CLUSTERED1468330467525'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 06:00:00',NULL,'2016-07-14 06:00:00',NULL,'NON_CLUSTERED1468330467526'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 06:10:00',NULL,'2016-07-14 06:10:00',NULL,'NON_CLUSTERED1468330467527'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 06:10:00',NULL,'2016-07-14 06:10:00',NULL,'NON_CLUSTERED1468330467528');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 06:20:00',NULL,'2016-07-14 06:20:00',NULL,'NON_CLUSTERED1468330467529'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 06:20:00',NULL,'2016-07-14 06:20:00',NULL,'NON_CLUSTERED1468330467530'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 06:30:00',NULL,'2016-07-14 06:30:00',NULL,'NON_CLUSTERED1468330467531'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 06:30:00',NULL,'2016-07-14 06:30:00',NULL,'NON_CLUSTERED1468330467532'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 06:40:00',NULL,'2016-07-14 06:40:00',NULL,'NON_CLUSTERED1468330467533');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 06:40:00',NULL,'2016-07-14 06:40:00',NULL,'NON_CLUSTERED1468330467534'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 06:50:00',NULL,'2016-07-14 06:50:00',NULL,'NON_CLUSTERED1468330467535'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 06:50:00',NULL,'2016-07-14 06:50:00',NULL,'NON_CLUSTERED1468330467536'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 07:00:00',NULL,'2016-07-14 07:00:00',NULL,'NON_CLUSTERED1468330467537'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 07:00:00',NULL,'2016-07-14 07:00:00',NULL,'NON_CLUSTERED1468330467538');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 07:10:00',NULL,'2016-07-14 07:10:00',NULL,'NON_CLUSTERED1468330467539'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 07:10:00',NULL,'2016-07-14 07:10:00',NULL,'NON_CLUSTERED1468330467540'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 07:20:00',NULL,'2016-07-14 07:20:00',NULL,'NON_CLUSTERED1468330467541'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 07:20:00',NULL,'2016-07-14 07:20:00',NULL,'NON_CLUSTERED1468330467542'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 07:30:00',NULL,'2016-07-14 07:30:00',NULL,'NON_CLUSTERED1468330467543');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 07:30:00',NULL,'2016-07-14 07:30:00',NULL,'NON_CLUSTERED1468330467544'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 07:40:00',NULL,'2016-07-14 07:40:00',NULL,'NON_CLUSTERED1468330467545'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 07:40:00',NULL,'2016-07-14 07:40:00',NULL,'NON_CLUSTERED1468330467546'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 07:50:00',NULL,'2016-07-14 07:50:00',NULL,'NON_CLUSTERED1468330467547'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 07:50:00',NULL,'2016-07-14 07:50:00',NULL,'NON_CLUSTERED1468330467548');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 08:00:00',NULL,'2016-07-14 08:00:00',NULL,'NON_CLUSTERED1468330467549'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 08:00:00',NULL,'2016-07-14 08:00:00',NULL,'NON_CLUSTERED1468330467550'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 08:10:00',NULL,'2016-07-14 08:10:00',NULL,'NON_CLUSTERED1468330467551'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 08:10:00',NULL,'2016-07-14 08:10:00',NULL,'NON_CLUSTERED1468330467552'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 08:20:00',NULL,'2016-07-14 08:20:00',NULL,'NON_CLUSTERED1468330467553');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 08:20:00',NULL,'2016-07-14 08:20:00',NULL,'NON_CLUSTERED1468330467554'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 08:30:00',NULL,'2016-07-14 08:30:00',NULL,'NON_CLUSTERED1468330467555'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 08:30:00',NULL,'2016-07-14 08:30:00',NULL,'NON_CLUSTERED1468330467556'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 08:40:00',NULL,'2016-07-14 08:40:00',NULL,'NON_CLUSTERED1468330467557'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 08:40:00',NULL,'2016-07-14 08:40:00',NULL,'NON_CLUSTERED1468330467558');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 08:50:00',NULL,'2016-07-14 08:50:00',NULL,'NON_CLUSTERED1468330467559'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 08:50:00',NULL,'2016-07-14 08:50:00',NULL,'NON_CLUSTERED1468330467560'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 09:00:00',NULL,'2016-07-14 09:00:00',NULL,'NON_CLUSTERED1468330467561'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 09:00:00',NULL,'2016-07-14 09:00:00',NULL,'NON_CLUSTERED1468330467562'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 09:10:00',NULL,'2016-07-14 09:10:00',NULL,'NON_CLUSTERED1468330467563');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 09:10:00',NULL,'2016-07-14 09:10:00',NULL,'NON_CLUSTERED1468330467564'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 09:20:00',NULL,'2016-07-14 09:20:00',NULL,'NON_CLUSTERED1468330467565'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 09:20:00',NULL,'2016-07-14 09:20:00',NULL,'NON_CLUSTERED1468330467566'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 09:30:00',NULL,'2016-07-14 09:30:00',NULL,'NON_CLUSTERED1468330467567'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 09:30:00',NULL,'2016-07-14 09:30:00',NULL,'NON_CLUSTERED1468330467568');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 09:40:00',NULL,'2016-07-14 09:40:00',NULL,'NON_CLUSTERED1468330467569'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 09:40:00',NULL,'2016-07-14 09:40:00',NULL,'NON_CLUSTERED1468330467570'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 09:50:00',NULL,'2016-07-14 09:50:00',NULL,'NON_CLUSTERED1468330467571'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 09:50:00',NULL,'2016-07-14 09:50:00',NULL,'NON_CLUSTERED1468330467572'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 10:00:00',NULL,'2016-07-14 10:00:00',NULL,'NON_CLUSTERED1468330467573');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 10:00:00',NULL,'2016-07-14 10:00:00',NULL,'NON_CLUSTERED1468330467574'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 10:10:00',NULL,'2016-07-14 10:10:00',NULL,'NON_CLUSTERED1468330467575'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 10:10:00',NULL,'2016-07-14 10:10:00',NULL,'NON_CLUSTERED1468330467576'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 10:20:00',NULL,'2016-07-14 10:20:00',NULL,'NON_CLUSTERED1468330467577'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 10:20:00',NULL,'2016-07-14 10:20:00',NULL,'NON_CLUSTERED1468330467578');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 10:30:00',NULL,'2016-07-14 10:30:00',NULL,'NON_CLUSTERED1468330467579'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 10:30:00',NULL,'2016-07-14 10:30:00',NULL,'NON_CLUSTERED1468330467580'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 10:40:00',NULL,'2016-07-14 10:40:00',NULL,'NON_CLUSTERED1468330467581'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 10:40:00',NULL,'2016-07-14 10:40:00',NULL,'NON_CLUSTERED1468330467582'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 10:50:00',NULL,'2016-07-14 10:50:00',NULL,'NON_CLUSTERED1468330467583');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 10:50:00',NULL,'2016-07-14 10:50:00',NULL,'NON_CLUSTERED1468330467584'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 11:00:00',NULL,'2016-07-14 11:00:00',NULL,'NON_CLUSTERED1468330467585'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 11:00:00',NULL,'2016-07-14 11:00:00',NULL,'NON_CLUSTERED1468330467586'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 11:10:00',NULL,'2016-07-14 11:10:00',NULL,'NON_CLUSTERED1468330467587'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 11:10:00',NULL,'2016-07-14 11:10:00',NULL,'NON_CLUSTERED1468330467588');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 11:20:00',NULL,'2016-07-14 11:20:00',NULL,'NON_CLUSTERED1468330467589'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 11:20:00',NULL,'2016-07-14 11:20:00',NULL,'NON_CLUSTERED1468330467590'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 11:30:00',NULL,'2016-07-14 11:30:00',NULL,'NON_CLUSTERED1468330467591'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 11:30:01',NULL,'2016-07-14 11:30:01',NULL,'NON_CLUSTERED1468330467592'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 11:40:00',NULL,'2016-07-14 11:40:00',NULL,'NON_CLUSTERED1468330467593');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 11:40:00',NULL,'2016-07-14 11:40:00',NULL,'NON_CLUSTERED1468330467594'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 11:50:00',NULL,'2016-07-14 11:50:00',NULL,'NON_CLUSTERED1468330467595'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 11:50:00',NULL,'2016-07-14 11:50:00',NULL,'NON_CLUSTERED1468330467596'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 12:00:00',NULL,'2016-07-14 12:00:00',NULL,'NON_CLUSTERED1468330467597'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 12:00:00',NULL,'2016-07-14 12:00:00',NULL,'NON_CLUSTERED1468330467598');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 12:10:00',NULL,'2016-07-14 12:10:00',NULL,'NON_CLUSTERED1468330467599'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 12:10:00',NULL,'2016-07-14 12:10:00',NULL,'NON_CLUSTERED1468330467600'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 12:20:00',NULL,'2016-07-14 12:20:00',NULL,'NON_CLUSTERED1468330467601'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 12:20:00',NULL,'2016-07-14 12:20:00',NULL,'NON_CLUSTERED1468330467602'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 12:30:00',NULL,'2016-07-14 12:30:00',NULL,'NON_CLUSTERED1468330467603');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 12:30:00',NULL,'2016-07-14 12:30:00',NULL,'NON_CLUSTERED1468330467604'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 12:40:00',NULL,'2016-07-14 12:40:00',NULL,'NON_CLUSTERED1468330467605'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 12:40:00',NULL,'2016-07-14 12:40:00',NULL,'NON_CLUSTERED1468330467606'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 12:50:00',NULL,'2016-07-14 12:50:00',NULL,'NON_CLUSTERED1468330467607'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 12:50:00',NULL,'2016-07-14 12:50:00',NULL,'NON_CLUSTERED1468330467608');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 13:00:00',NULL,'2016-07-14 13:00:00',NULL,'NON_CLUSTERED1468330467609'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 13:00:00',NULL,'2016-07-14 13:00:00',NULL,'NON_CLUSTERED1468330467610'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 13:10:00',NULL,'2016-07-14 13:10:00',NULL,'NON_CLUSTERED1468330467611'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 13:10:00',NULL,'2016-07-14 13:10:00',NULL,'NON_CLUSTERED1468330467612'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 13:20:00',NULL,'2016-07-14 13:20:00',NULL,'NON_CLUSTERED1468330467613');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 13:20:00',NULL,'2016-07-14 13:20:00',NULL,'NON_CLUSTERED1468330467614'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 13:30:00',NULL,'2016-07-14 13:30:00',NULL,'NON_CLUSTERED1468330467615'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 13:30:00',NULL,'2016-07-14 13:30:00',NULL,'NON_CLUSTERED1468330467616'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 13:40:00',NULL,'2016-07-14 13:40:00',NULL,'NON_CLUSTERED1468330467617'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 13:40:00',NULL,'2016-07-14 13:40:00',NULL,'NON_CLUSTERED1468330467618');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 13:50:00',NULL,'2016-07-14 13:50:00',NULL,'NON_CLUSTERED1468330467619'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 13:50:00',NULL,'2016-07-14 13:50:00',NULL,'NON_CLUSTERED1468330467620'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 14:00:00',NULL,'2016-07-14 14:00:00',NULL,'NON_CLUSTERED1468330467621'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 14:00:00',NULL,'2016-07-14 14:00:00',NULL,'NON_CLUSTERED1468330467622'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 14:10:00',NULL,'2016-07-14 14:10:00',NULL,'NON_CLUSTERED1468330467623');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 14:10:00',NULL,'2016-07-14 14:10:00',NULL,'NON_CLUSTERED1468330467624'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 14:20:00',NULL,'2016-07-14 14:20:00',NULL,'NON_CLUSTERED1468330467625'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 14:20:00',NULL,'2016-07-14 14:20:00',NULL,'NON_CLUSTERED1468330467626'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 14:30:00',NULL,'2016-07-14 14:30:00',NULL,'NON_CLUSTERED1468330467627'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 14:30:00',NULL,'2016-07-14 14:30:00',NULL,'NON_CLUSTERED1468330467628');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 14:40:00',NULL,'2016-07-14 14:40:00',NULL,'NON_CLUSTERED1468330467629'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 14:40:00',NULL,'2016-07-14 14:40:00',NULL,'NON_CLUSTERED1468330467630'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 14:50:00',NULL,'2016-07-14 14:50:00',NULL,'NON_CLUSTERED1468330467631'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 14:50:00',NULL,'2016-07-14 14:50:00',NULL,'NON_CLUSTERED1468330467632'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 15:00:00',NULL,'2016-07-14 15:00:00',NULL,'NON_CLUSTERED1468330467633');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 15:00:00',NULL,'2016-07-14 15:00:00',NULL,'NON_CLUSTERED1468330467634'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 15:10:00',NULL,'2016-07-14 15:10:00',NULL,'NON_CLUSTERED1468330467635'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 15:10:00',NULL,'2016-07-14 15:10:00',NULL,'NON_CLUSTERED1468330467636'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 15:20:00',NULL,'2016-07-14 15:20:00',NULL,'NON_CLUSTERED1468330467637'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 15:20:00',NULL,'2016-07-14 15:20:00',NULL,'NON_CLUSTERED1468330467638');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key ReservationExpiration Mail','System Triggers','Job Key Reservation Expiration Mail','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 15:23:00',NULL,'2016-07-14 15:23:00',NULL,'NON_CLUSTERED1468330467639'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 15:30:00',NULL,'2016-07-14 15:30:00',NULL,'NON_CLUSTERED1468330467640'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 15:30:00',NULL,'2016-07-14 15:30:00',NULL,'NON_CLUSTERED1468330467641'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 15:40:00',NULL,'2016-07-14 15:40:00',NULL,'NON_CLUSTERED1468330467642'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 15:40:00',NULL,'2016-07-14 15:40:00',NULL,'NON_CLUSTERED1468330467643');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 15:50:00',NULL,'2016-07-14 15:50:00',NULL,'NON_CLUSTERED1468330467644'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 15:50:00',NULL,'2016-07-14 15:50:00',NULL,'NON_CLUSTERED1468330467645'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 16:00:00',NULL,'2016-07-14 16:00:00',NULL,'NON_CLUSTERED1468330467646'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 16:00:00',NULL,'2016-07-14 16:00:00',NULL,'NON_CLUSTERED1468330467647'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 16:10:00',NULL,'2016-07-14 16:10:00',NULL,'NON_CLUSTERED1468330467648');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 16:10:00',NULL,'2016-07-14 16:10:00',NULL,'NON_CLUSTERED1468330467649'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 16:20:00',NULL,'2016-07-14 16:20:00',NULL,'NON_CLUSTERED1468330467650'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 16:20:00',NULL,'2016-07-14 16:20:00',NULL,'NON_CLUSTERED1468330467651'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 16:30:00',NULL,'2016-07-14 16:30:00',NULL,'NON_CLUSTERED1468330467652'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 16:30:00',NULL,'2016-07-14 16:30:00',NULL,'NON_CLUSTERED1468330467653');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 16:40:00',NULL,'2016-07-14 16:40:00',NULL,'NON_CLUSTERED1468330467654'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 16:40:00',NULL,'2016-07-14 16:40:00',NULL,'NON_CLUSTERED1468330467655'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 16:50:00',NULL,'2016-07-14 16:50:00',NULL,'NON_CLUSTERED1468330467656'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 16:50:00',NULL,'2016-07-14 16:50:00',NULL,'NON_CLUSTERED1468330467657'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 17:00:00',NULL,'2016-07-14 17:00:00',NULL,'NON_CLUSTERED1468330467658');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 17:00:00',NULL,'2016-07-14 17:00:00',NULL,'NON_CLUSTERED1468330467659'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 17:10:00',NULL,'2016-07-14 17:10:00',NULL,'NON_CLUSTERED1468330467660'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 17:10:00',NULL,'2016-07-14 17:10:00',NULL,'NON_CLUSTERED1468330467661'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 17:20:00',NULL,'2016-07-14 17:20:00',NULL,'NON_CLUSTERED1468330467662'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 17:20:00',NULL,'2016-07-14 17:20:00',NULL,'NON_CLUSTERED1468330467663');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 17:30:00',NULL,'2016-07-14 17:30:00',NULL,'NON_CLUSTERED1468330467664'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 17:30:00',NULL,'2016-07-14 17:30:00',NULL,'NON_CLUSTERED1468330467665'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 17:40:00',NULL,'2016-07-14 17:40:00',NULL,'NON_CLUSTERED1468330467666'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 17:40:00',NULL,'2016-07-14 17:40:00',NULL,'NON_CLUSTERED1468330467667'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 17:50:00',NULL,'2016-07-14 17:50:00',NULL,'NON_CLUSTERED1468330467668');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 17:50:00',NULL,'2016-07-14 17:50:00',NULL,'NON_CLUSTERED1468330467669'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 18:00:00',NULL,'2016-07-14 18:00:00',NULL,'NON_CLUSTERED1468330467670'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 18:00:00',NULL,'2016-07-14 18:00:00',NULL,'NON_CLUSTERED1468330467671'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 18:10:00',NULL,'2016-07-14 18:10:00',NULL,'NON_CLUSTERED1468330467672'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 18:10:00',NULL,'2016-07-14 18:10:00',NULL,'NON_CLUSTERED1468330467673');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 18:20:00',NULL,'2016-07-14 18:20:00',NULL,'NON_CLUSTERED1468330467674'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 18:20:00',NULL,'2016-07-14 18:20:00',NULL,'NON_CLUSTERED1468330467675'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 18:30:00',NULL,'2016-07-14 18:30:00',NULL,'NON_CLUSTERED1468330467676'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 18:30:00',NULL,'2016-07-14 18:30:00',NULL,'NON_CLUSTERED1468330467677'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 18:40:00',NULL,'2016-07-14 18:40:00',NULL,'NON_CLUSTERED1468330467678');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 18:40:00',NULL,'2016-07-14 18:40:00',NULL,'NON_CLUSTERED1468330467679'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 18:50:00',NULL,'2016-07-14 18:50:00',NULL,'NON_CLUSTERED1468330467680'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 18:50:00',NULL,'2016-07-14 18:50:00',NULL,'NON_CLUSTERED1468330467681'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 19:00:00',NULL,'2016-07-14 19:00:00',NULL,'NON_CLUSTERED1468330467682'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 19:00:00',NULL,'2016-07-14 19:00:00',NULL,'NON_CLUSTERED1468330467683');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 19:10:00',NULL,'2016-07-14 19:10:00',NULL,'NON_CLUSTERED1468330467684'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 19:10:00',NULL,'2016-07-14 19:10:00',NULL,'NON_CLUSTERED1468330467685'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 19:20:00',NULL,'2016-07-14 19:20:00',NULL,'NON_CLUSTERED1468330467686'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 19:20:00',NULL,'2016-07-14 19:20:00',NULL,'NON_CLUSTERED1468330467687'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 19:30:00',NULL,'2016-07-14 19:30:00',NULL,'NON_CLUSTERED1468330467688');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 19:30:00',NULL,'2016-07-14 19:30:00',NULL,'NON_CLUSTERED1468330467689'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 19:40:00',NULL,'2016-07-14 19:40:00',NULL,'NON_CLUSTERED1468330467690'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 19:40:00',NULL,'2016-07-14 19:40:00',NULL,'NON_CLUSTERED1468330467691'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 19:50:00',NULL,'2016-07-14 19:50:00',NULL,'NON_CLUSTERED1468330467692'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 19:50:00',NULL,'2016-07-14 19:50:00',NULL,'NON_CLUSTERED1468330467693');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 20:00:00',NULL,'2016-07-14 20:00:00',NULL,'NON_CLUSTERED1468330467694'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 20:00:00',NULL,'2016-07-14 20:00:00',NULL,'NON_CLUSTERED1468330467695'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 20:10:00',NULL,'2016-07-14 20:10:00',NULL,'NON_CLUSTERED1468330467696'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 20:10:00',NULL,'2016-07-14 20:10:00',NULL,'NON_CLUSTERED1468330467697'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 20:20:00',NULL,'2016-07-14 20:20:00',NULL,'NON_CLUSTERED1468330467698');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 20:20:00',NULL,'2016-07-14 20:20:00',NULL,'NON_CLUSTERED1468330467699'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 20:30:00',NULL,'2016-07-14 20:30:00',NULL,'NON_CLUSTERED1468330467700'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 20:30:00',NULL,'2016-07-14 20:30:00',NULL,'NON_CLUSTERED1468330467701'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 20:40:00',NULL,'2016-07-14 20:40:00',NULL,'NON_CLUSTERED1468330467702'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 20:40:00',NULL,'2016-07-14 20:40:00',NULL,'NON_CLUSTERED1468330467703');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 20:50:00',NULL,'2016-07-14 20:50:00',NULL,'NON_CLUSTERED1468330467704'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 20:50:00',NULL,'2016-07-14 20:50:00',NULL,'NON_CLUSTERED1468330467705'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 21:00:00',NULL,'2016-07-14 21:00:00',NULL,'NON_CLUSTERED1468330467706'),
 ('Trigger Key EnvironmentDeletion','System Triggers','Job Key EnvironmentDeletion','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 21:00:00',NULL,'2016-07-14 21:00:00',NULL,'NON_CLUSTERED1468330467707'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 21:00:00',NULL,'2016-07-14 21:00:00',NULL,'NON_CLUSTERED1468330467708');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 21:10:00',NULL,'2016-07-14 21:10:00',NULL,'NON_CLUSTERED1468330467709'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 21:10:00',NULL,'2016-07-14 21:10:00',NULL,'NON_CLUSTERED1468330467710'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 21:20:00',NULL,'2016-07-14 21:20:00',NULL,'NON_CLUSTERED1468330467711'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 21:20:00',NULL,'2016-07-14 21:20:00',NULL,'NON_CLUSTERED1468330467712'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 21:30:00',NULL,'2016-07-14 21:30:00',NULL,'NON_CLUSTERED1468330467713');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 21:30:00',NULL,'2016-07-14 21:30:00',NULL,'NON_CLUSTERED1468330467714'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 21:40:00',NULL,'2016-07-14 21:40:00',NULL,'NON_CLUSTERED1468330467715'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 21:40:00',NULL,'2016-07-14 21:40:00',NULL,'NON_CLUSTERED1468330467716'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 21:50:00',NULL,'2016-07-14 21:50:00',NULL,'NON_CLUSTERED1468330467717'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 21:50:00',NULL,'2016-07-14 21:50:00',NULL,'NON_CLUSTERED1468330467718');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 22:00:00',NULL,'2016-07-14 22:00:00',NULL,'NON_CLUSTERED1468330467719'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 22:00:00',NULL,'2016-07-14 22:00:00',NULL,'NON_CLUSTERED1468330467720'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 22:10:00',NULL,'2016-07-14 22:10:00',NULL,'NON_CLUSTERED1468330467721'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 22:10:00',NULL,'2016-07-14 22:10:00',NULL,'NON_CLUSTERED1468330467722'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 22:20:00',NULL,'2016-07-14 22:20:00',NULL,'NON_CLUSTERED1468330467723');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 22:20:00',NULL,'2016-07-14 22:20:00',NULL,'NON_CLUSTERED1468330467724'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 22:30:00',NULL,'2016-07-14 22:30:00',NULL,'NON_CLUSTERED1468330467725'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 22:30:00',NULL,'2016-07-14 22:30:00',NULL,'NON_CLUSTERED1468330467726'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 22:40:00',NULL,'2016-07-14 22:40:00',NULL,'NON_CLUSTERED1468330467727'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 22:40:00',NULL,'2016-07-14 22:40:00',NULL,'NON_CLUSTERED1468330467728');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 22:50:00',NULL,'2016-07-14 22:50:00',NULL,'NON_CLUSTERED1468330467729'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 22:50:00',NULL,'2016-07-14 22:50:00',NULL,'NON_CLUSTERED1468330467730'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 23:00:00',NULL,'2016-07-14 23:00:00',NULL,'NON_CLUSTERED1468330467731'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 23:00:00',NULL,'2016-07-14 23:00:00',NULL,'NON_CLUSTERED1468330467732'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 23:10:00',NULL,'2016-07-14 23:10:00',NULL,'NON_CLUSTERED1468330467733');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 23:10:00',NULL,'2016-07-14 23:10:00',NULL,'NON_CLUSTERED1468330467734'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 23:20:00',NULL,'2016-07-14 23:20:00',NULL,'NON_CLUSTERED1468330467735'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 23:20:00',NULL,'2016-07-14 23:20:00',NULL,'NON_CLUSTERED1468330467736'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 23:30:00',NULL,'2016-07-14 23:30:00',NULL,'NON_CLUSTERED1468330467737'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 23:30:00',NULL,'2016-07-14 23:30:00',NULL,'NON_CLUSTERED1468330467738');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 23:40:00',NULL,'2016-07-14 23:40:00',NULL,'NON_CLUSTERED1468330467739'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 23:40:00',NULL,'2016-07-14 23:40:00',NULL,'NON_CLUSTERED1468330467740'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 23:50:00',NULL,'2016-07-14 23:50:00',NULL,'NON_CLUSTERED1468330467741'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-14 23:50:00',NULL,'2016-07-14 23:50:00',NULL,'NON_CLUSTERED1468330467742'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 00:00:00',NULL,'2016-07-15 00:00:00',NULL,'NON_CLUSTERED1468330467743');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 00:00:00',NULL,'2016-07-15 00:00:00',NULL,'NON_CLUSTERED1468330467744'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 00:10:00',NULL,'2016-07-15 00:10:00',NULL,'NON_CLUSTERED1468330467745'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 00:10:00',NULL,'2016-07-15 00:10:00',NULL,'NON_CLUSTERED1468330467746'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 00:20:00',NULL,'2016-07-15 00:20:00',NULL,'NON_CLUSTERED1468330467747'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 00:20:00',NULL,'2016-07-15 00:20:00',NULL,'NON_CLUSTERED1468330467748');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 00:30:00',NULL,'2016-07-15 00:30:00',NULL,'NON_CLUSTERED1468330467749'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 00:30:00',NULL,'2016-07-15 00:30:00',NULL,'NON_CLUSTERED1468330467750'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 00:40:00',NULL,'2016-07-15 00:40:00',NULL,'NON_CLUSTERED1468330467751'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 00:40:00',NULL,'2016-07-15 00:40:00',NULL,'NON_CLUSTERED1468330467752'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 00:50:00',NULL,'2016-07-15 00:50:00',NULL,'NON_CLUSTERED1468330467753');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 00:50:00',NULL,'2016-07-15 00:50:00',NULL,'NON_CLUSTERED1468330467754'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 01:00:00',NULL,'2016-07-15 01:00:00',NULL,'NON_CLUSTERED1468330467755'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 01:00:00',NULL,'2016-07-15 01:00:00',NULL,'NON_CLUSTERED1468330467756'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 01:10:00',NULL,'2016-07-15 01:10:00',NULL,'NON_CLUSTERED1468330467757'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 01:10:00',NULL,'2016-07-15 01:10:00',NULL,'NON_CLUSTERED1468330467758');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 01:20:00',NULL,'2016-07-15 01:20:00',NULL,'NON_CLUSTERED1468330467759'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 01:20:00',NULL,'2016-07-15 01:20:00',NULL,'NON_CLUSTERED1468330467760'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 01:30:00',NULL,'2016-07-15 01:30:00',NULL,'NON_CLUSTERED1468330467761'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 01:30:00',NULL,'2016-07-15 01:30:00',NULL,'NON_CLUSTERED1468330467762'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 01:40:00',NULL,'2016-07-15 01:40:00',NULL,'NON_CLUSTERED1468330467763');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 01:40:00',NULL,'2016-07-15 01:40:00',NULL,'NON_CLUSTERED1468330467764'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 01:50:00',NULL,'2016-07-15 01:50:00',NULL,'NON_CLUSTERED1468330467765'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 01:50:00',NULL,'2016-07-15 01:50:00',NULL,'NON_CLUSTERED1468330467766'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 02:00:00',NULL,'2016-07-15 02:00:00',NULL,'NON_CLUSTERED1468330467767'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 02:00:00',NULL,'2016-07-15 02:00:00',NULL,'NON_CLUSTERED1468330467768');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 02:10:00',NULL,'2016-07-15 02:10:00',NULL,'NON_CLUSTERED1468330467769'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 02:10:00',NULL,'2016-07-15 02:10:00',NULL,'NON_CLUSTERED1468330467770'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 02:20:00',NULL,'2016-07-15 02:20:00',NULL,'NON_CLUSTERED1468330467771'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 02:20:00',NULL,'2016-07-15 02:20:00',NULL,'NON_CLUSTERED1468330467772'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 02:30:00',NULL,'2016-07-15 02:30:00',NULL,'NON_CLUSTERED1468330467773');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 02:30:00',NULL,'2016-07-15 02:30:00',NULL,'NON_CLUSTERED1468330467774'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 02:40:00',NULL,'2016-07-15 02:40:00',NULL,'NON_CLUSTERED1468330467775'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 02:40:00',NULL,'2016-07-15 02:40:00',NULL,'NON_CLUSTERED1468330467776'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 02:50:00',NULL,'2016-07-15 02:50:00',NULL,'NON_CLUSTERED1468330467777'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 02:50:00',NULL,'2016-07-15 02:50:00',NULL,'NON_CLUSTERED1468330467778');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 03:00:00',NULL,'2016-07-15 03:00:00',NULL,'NON_CLUSTERED1468330467779'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 03:00:00',NULL,'2016-07-15 03:00:00',NULL,'NON_CLUSTERED1468330467780'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 03:10:00',NULL,'2016-07-15 03:10:00',NULL,'NON_CLUSTERED1468330467781'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 03:10:00',NULL,'2016-07-15 03:10:00',NULL,'NON_CLUSTERED1468330467782'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 03:20:00',NULL,'2016-07-15 03:20:00',NULL,'NON_CLUSTERED1468330467783');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 03:20:00',NULL,'2016-07-15 03:20:00',NULL,'NON_CLUSTERED1468330467784'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 03:30:00',NULL,'2016-07-15 03:30:00',NULL,'NON_CLUSTERED1468330467785'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 03:30:00',NULL,'2016-07-15 03:30:00',NULL,'NON_CLUSTERED1468330467786'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 03:40:00',NULL,'2016-07-15 03:40:00',NULL,'NON_CLUSTERED1468330467787'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 03:40:00',NULL,'2016-07-15 03:40:00',NULL,'NON_CLUSTERED1468330467788');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 03:50:00',NULL,'2016-07-15 03:50:00',NULL,'NON_CLUSTERED1468330467789'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 03:50:00',NULL,'2016-07-15 03:50:00',NULL,'NON_CLUSTERED1468330467790'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 04:00:00',NULL,'2016-07-15 04:00:00',NULL,'NON_CLUSTERED1468330467791'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 04:00:00',NULL,'2016-07-15 04:00:00',NULL,'NON_CLUSTERED1468330467792'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 04:10:00',NULL,'2016-07-15 04:10:00',NULL,'NON_CLUSTERED1468330467793');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 04:10:00',NULL,'2016-07-15 04:10:00',NULL,'NON_CLUSTERED1468330467794'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 04:20:00',NULL,'2016-07-15 04:20:00',NULL,'NON_CLUSTERED1468330467795'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 04:20:00',NULL,'2016-07-15 04:20:00',NULL,'NON_CLUSTERED1468330467796'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 04:30:00',NULL,'2016-07-15 04:30:00',NULL,'NON_CLUSTERED1468330467797'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 04:30:00',NULL,'2016-07-15 04:30:00',NULL,'NON_CLUSTERED1468330467798');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 04:40:00',NULL,'2016-07-15 04:40:00',NULL,'NON_CLUSTERED1468330467799'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 04:40:00',NULL,'2016-07-15 04:40:00',NULL,'NON_CLUSTERED1468330467800'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 04:50:00',NULL,'2016-07-15 04:50:00',NULL,'NON_CLUSTERED1468330467801'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 04:50:00',NULL,'2016-07-15 04:50:00',NULL,'NON_CLUSTERED1468330467802'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 05:00:00',NULL,'2016-07-15 05:00:00',NULL,'NON_CLUSTERED1468330467803');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 05:00:00',NULL,'2016-07-15 05:00:00',NULL,'NON_CLUSTERED1468330467804'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 05:10:00',NULL,'2016-07-15 05:10:00',NULL,'NON_CLUSTERED1468330467805'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 05:10:00',NULL,'2016-07-15 05:10:00',NULL,'NON_CLUSTERED1468330467806'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 05:20:00',NULL,'2016-07-15 05:20:00',NULL,'NON_CLUSTERED1468330467807'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 05:20:00',NULL,'2016-07-15 05:20:00',NULL,'NON_CLUSTERED1468330467808');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 05:30:00',NULL,'2016-07-15 05:30:00',NULL,'NON_CLUSTERED1468330467809'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 05:30:00',NULL,'2016-07-15 05:30:00',NULL,'NON_CLUSTERED1468330467810'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 05:40:00',NULL,'2016-07-15 05:40:00',NULL,'NON_CLUSTERED1468330467811'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 05:40:00',NULL,'2016-07-15 05:40:00',NULL,'NON_CLUSTERED1468330467812'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 05:50:00',NULL,'2016-07-15 05:50:00',NULL,'NON_CLUSTERED1468330467813');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 05:50:00',NULL,'2016-07-15 05:50:00',NULL,'NON_CLUSTERED1468330467814'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 06:00:00',NULL,'2016-07-15 06:00:00',NULL,'NON_CLUSTERED1468330467815'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 06:00:00',NULL,'2016-07-15 06:00:00',NULL,'NON_CLUSTERED1468330467816'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 06:10:00',NULL,'2016-07-15 06:10:00',NULL,'NON_CLUSTERED1468330467817'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 06:10:00',NULL,'2016-07-15 06:10:00',NULL,'NON_CLUSTERED1468330467818');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 06:20:00',NULL,'2016-07-15 06:20:00',NULL,'NON_CLUSTERED1468330467819'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 06:20:00',NULL,'2016-07-15 06:20:00',NULL,'NON_CLUSTERED1468330467820'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 06:30:00',NULL,'2016-07-15 06:30:00',NULL,'NON_CLUSTERED1468330467821'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 06:30:00',NULL,'2016-07-15 06:30:00',NULL,'NON_CLUSTERED1468330467822'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 06:40:00',NULL,'2016-07-15 06:40:00',NULL,'NON_CLUSTERED1468330467823');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 06:40:00',NULL,'2016-07-15 06:40:00',NULL,'NON_CLUSTERED1468330467824'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 06:50:00',NULL,'2016-07-15 06:50:00',NULL,'NON_CLUSTERED1468330467825'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 06:50:00',NULL,'2016-07-15 06:50:00',NULL,'NON_CLUSTERED1468330467826'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 07:00:00',NULL,'2016-07-15 07:00:00',NULL,'NON_CLUSTERED1468330467827'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 07:00:00',NULL,'2016-07-15 07:00:00',NULL,'NON_CLUSTERED1468330467828');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 07:10:00',NULL,'2016-07-15 07:10:00',NULL,'NON_CLUSTERED1468330467829'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 07:10:00',NULL,'2016-07-15 07:10:00',NULL,'NON_CLUSTERED1468330467830'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 07:20:00',NULL,'2016-07-15 07:20:00',NULL,'NON_CLUSTERED1468330467831'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 07:20:00',NULL,'2016-07-15 07:20:00',NULL,'NON_CLUSTERED1468330467832'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 07:30:00',NULL,'2016-07-15 07:30:00',NULL,'NON_CLUSTERED1468330467833');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 07:30:00',NULL,'2016-07-15 07:30:00',NULL,'NON_CLUSTERED1468330467834'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 07:40:00',NULL,'2016-07-15 07:40:00',NULL,'NON_CLUSTERED1468330467835'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 07:40:00',NULL,'2016-07-15 07:40:00',NULL,'NON_CLUSTERED1468330467836'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 07:50:00',NULL,'2016-07-15 07:50:00',NULL,'NON_CLUSTERED1468330467837'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 07:50:00',NULL,'2016-07-15 07:50:00',NULL,'NON_CLUSTERED1468330467838');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 08:00:00',NULL,'2016-07-15 08:00:00',NULL,'NON_CLUSTERED1468330467839'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 08:00:00',NULL,'2016-07-15 08:00:00',NULL,'NON_CLUSTERED1468330467840'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 08:10:00',NULL,'2016-07-15 08:10:00',NULL,'NON_CLUSTERED1468330467841'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 08:10:00',NULL,'2016-07-15 08:10:00',NULL,'NON_CLUSTERED1468330467842'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 08:20:00',NULL,'2016-07-15 08:20:00',NULL,'NON_CLUSTERED1468330467843');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 08:20:00',NULL,'2016-07-15 08:20:00',NULL,'NON_CLUSTERED1468330467844'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 08:30:00',NULL,'2016-07-15 08:30:00',NULL,'NON_CLUSTERED1468330467845'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 08:30:00',NULL,'2016-07-15 08:30:00',NULL,'NON_CLUSTERED1468330467846'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 08:40:00',NULL,'2016-07-15 08:40:00',NULL,'NON_CLUSTERED1468330467847'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 08:40:00',NULL,'2016-07-15 08:40:00',NULL,'NON_CLUSTERED1468330467848');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 08:50:00',NULL,'2016-07-15 08:50:00',NULL,'NON_CLUSTERED1468330467849'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 08:50:00',NULL,'2016-07-15 08:50:00',NULL,'NON_CLUSTERED1468330467850'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 09:00:00',NULL,'2016-07-15 09:00:00',NULL,'NON_CLUSTERED1468330467851'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 09:00:00',NULL,'2016-07-15 09:00:00',NULL,'NON_CLUSTERED1468330467852'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 09:10:00',NULL,'2016-07-15 09:10:00',NULL,'NON_CLUSTERED1468330467853');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 09:10:00',NULL,'2016-07-15 09:10:00',NULL,'NON_CLUSTERED1468330467854'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 09:20:00',NULL,'2016-07-15 09:20:00',NULL,'NON_CLUSTERED1468330467855'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 09:20:00',NULL,'2016-07-15 09:20:00',NULL,'NON_CLUSTERED1468330467856'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 09:30:00',NULL,'2016-07-15 09:30:00',NULL,'NON_CLUSTERED1468330467857'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 09:30:00',NULL,'2016-07-15 09:30:00',NULL,'NON_CLUSTERED1468330467858');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 09:40:00',NULL,'2016-07-15 09:40:00',NULL,'NON_CLUSTERED1468330467859'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 09:40:00',NULL,'2016-07-15 09:40:00',NULL,'NON_CLUSTERED1468330467860'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 09:50:00',NULL,'2016-07-15 09:50:00',NULL,'NON_CLUSTERED1468330467861'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 09:50:00',NULL,'2016-07-15 09:50:00',NULL,'NON_CLUSTERED1468330467862'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 10:00:00',NULL,'2016-07-15 10:00:00',NULL,'NON_CLUSTERED1468330467863');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 10:00:00',NULL,'2016-07-15 10:00:00',NULL,'NON_CLUSTERED1468330467864'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 10:10:00',NULL,'2016-07-15 10:10:00',NULL,'NON_CLUSTERED1468330467865'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 10:10:00',NULL,'2016-07-15 10:10:00',NULL,'NON_CLUSTERED1468330467866'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 10:20:00',NULL,'2016-07-15 10:20:00',NULL,'NON_CLUSTERED1468330467867'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 10:20:00',NULL,'2016-07-15 10:20:00',NULL,'NON_CLUSTERED1468330467868');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 10:30:00',NULL,'2016-07-15 10:30:00',NULL,'NON_CLUSTERED1468330467869'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 10:30:00',NULL,'2016-07-15 10:30:00',NULL,'NON_CLUSTERED1468330467870'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 10:40:00',NULL,'2016-07-15 10:40:00',NULL,'NON_CLUSTERED1468330467871'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 10:40:00',NULL,'2016-07-15 10:40:00',NULL,'NON_CLUSTERED1468330467872'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 10:50:00',NULL,'2016-07-15 10:50:00',NULL,'NON_CLUSTERED1468330467873');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 10:50:00',NULL,'2016-07-15 10:50:00',NULL,'NON_CLUSTERED1468330467874'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 11:00:00',NULL,'2016-07-15 11:00:00',NULL,'NON_CLUSTERED1468330467875'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 11:00:00',NULL,'2016-07-15 11:00:00',NULL,'NON_CLUSTERED1468330467876'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 11:10:00',NULL,'2016-07-15 11:10:00',NULL,'NON_CLUSTERED1468330467877'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 11:10:00',NULL,'2016-07-15 11:10:00',NULL,'NON_CLUSTERED1468330467878');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 11:20:00',NULL,'2016-07-15 11:20:00',NULL,'NON_CLUSTERED1468330467879'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 11:20:00',NULL,'2016-07-15 11:20:00',NULL,'NON_CLUSTERED1468330467880'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 11:30:00',NULL,'2016-07-15 11:30:00',NULL,'NON_CLUSTERED1468330467881'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 11:30:00',NULL,'2016-07-15 11:30:00',NULL,'NON_CLUSTERED1468330467882'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 11:40:00',NULL,'2016-07-15 11:40:00',NULL,'NON_CLUSTERED1468330467883');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 11:40:00',NULL,'2016-07-15 11:40:00',NULL,'NON_CLUSTERED1468330467884'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 11:50:00',NULL,'2016-07-15 11:50:00',NULL,'NON_CLUSTERED1468330467885'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 11:50:00',NULL,'2016-07-15 11:50:00',NULL,'NON_CLUSTERED1468330467886'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 12:00:00',NULL,'2016-07-15 12:00:00',NULL,'NON_CLUSTERED1468330467887'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 12:00:00',NULL,'2016-07-15 12:00:00',NULL,'NON_CLUSTERED1468330467888');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 12:10:00',NULL,'2016-07-15 12:10:00',NULL,'NON_CLUSTERED1468330467889'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 12:10:00',NULL,'2016-07-15 12:10:00',NULL,'NON_CLUSTERED1468330467890'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 12:20:00',NULL,'2016-07-15 12:20:00',NULL,'NON_CLUSTERED1468330467891'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 12:20:00',NULL,'2016-07-15 12:20:00',NULL,'NON_CLUSTERED1468330467892'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 12:30:00',NULL,'2016-07-15 12:30:00',NULL,'NON_CLUSTERED1468330467893');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 12:30:00',NULL,'2016-07-15 12:30:00',NULL,'NON_CLUSTERED1468330467894'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 12:40:00',NULL,'2016-07-15 12:40:00',NULL,'NON_CLUSTERED1468330467895'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 12:40:00',NULL,'2016-07-15 12:40:00',NULL,'NON_CLUSTERED1468330467896'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 12:50:00',NULL,'2016-07-15 12:50:00',NULL,'NON_CLUSTERED1468330467897'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 12:50:00',NULL,'2016-07-15 12:50:00',NULL,'NON_CLUSTERED1468330467898');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 13:00:00',NULL,'2016-07-15 13:00:00',NULL,'NON_CLUSTERED1468330467899'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 13:00:00',NULL,'2016-07-15 13:00:00',NULL,'NON_CLUSTERED1468330467900'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 13:10:00',NULL,'2016-07-15 13:10:00',NULL,'NON_CLUSTERED1468330467901'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 13:10:00',NULL,'2016-07-15 13:10:00',NULL,'NON_CLUSTERED1468330467902'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 13:20:00',NULL,'2016-07-15 13:20:00',NULL,'NON_CLUSTERED1468330467903');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 13:20:00',NULL,'2016-07-15 13:20:00',NULL,'NON_CLUSTERED1468330467904'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 13:30:00',NULL,'2016-07-15 13:30:00',NULL,'NON_CLUSTERED1468330467905'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 13:30:00',NULL,'2016-07-15 13:30:00',NULL,'NON_CLUSTERED1468330467906'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 13:40:00',NULL,'2016-07-15 13:40:00',NULL,'NON_CLUSTERED1468330467907'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 13:40:00',NULL,'2016-07-15 13:40:00',NULL,'NON_CLUSTERED1468330467908');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 13:50:00',NULL,'2016-07-15 13:50:00',NULL,'NON_CLUSTERED1468330467909'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 13:50:00',NULL,'2016-07-15 13:50:00',NULL,'NON_CLUSTERED1468330467910'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 14:00:00',NULL,'2016-07-15 14:00:00',NULL,'NON_CLUSTERED1468330467911'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 14:00:00',NULL,'2016-07-15 14:00:00',NULL,'NON_CLUSTERED1468330467912'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 14:10:00',NULL,'2016-07-15 14:10:00',NULL,'NON_CLUSTERED1468330467913');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 14:10:00',NULL,'2016-07-15 14:10:00',NULL,'NON_CLUSTERED1468330467914'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 14:20:00',NULL,'2016-07-15 14:20:00',NULL,'NON_CLUSTERED1468330467915'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 14:20:00',NULL,'2016-07-15 14:20:00',NULL,'NON_CLUSTERED1468330467916'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 14:30:00',NULL,'2016-07-15 14:30:00',NULL,'NON_CLUSTERED1468330467917'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 14:30:00',NULL,'2016-07-15 14:30:00',NULL,'NON_CLUSTERED1468330467918');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 14:40:00',NULL,'2016-07-15 14:40:00',NULL,'NON_CLUSTERED1468330467919'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 14:40:00',NULL,'2016-07-15 14:40:00',NULL,'NON_CLUSTERED1468330467920'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 14:50:00',NULL,'2016-07-15 14:50:00',NULL,'NON_CLUSTERED1468330467921'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 14:50:00',NULL,'2016-07-15 14:50:00',NULL,'NON_CLUSTERED1468330467922'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 15:00:00',NULL,'2016-07-15 15:00:00',NULL,'NON_CLUSTERED1468330467923');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 15:00:00',NULL,'2016-07-15 15:00:00',NULL,'NON_CLUSTERED1468330467924'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 15:10:00',NULL,'2016-07-15 15:10:00',NULL,'NON_CLUSTERED1468330467925'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 15:10:00',NULL,'2016-07-15 15:10:00',NULL,'NON_CLUSTERED1468330467926'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 15:20:00',NULL,'2016-07-15 15:20:00',NULL,'NON_CLUSTERED1468330467927'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 15:20:00',NULL,'2016-07-15 15:20:00',NULL,'NON_CLUSTERED1468330467928');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key ReservationExpiration Mail','System Triggers','Job Key Reservation Expiration Mail','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 15:23:00',NULL,'2016-07-15 15:23:00',NULL,'NON_CLUSTERED1468330467929'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 15:30:00',NULL,'2016-07-15 15:30:00',NULL,'NON_CLUSTERED1468330467930'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 15:30:00',NULL,'2016-07-15 15:30:00',NULL,'NON_CLUSTERED1468330467931'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 15:40:00',NULL,'2016-07-15 15:40:00',NULL,'NON_CLUSTERED1468330467932'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 15:40:00',NULL,'2016-07-15 15:40:00',NULL,'NON_CLUSTERED1468330467933');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 15:50:00',NULL,'2016-07-15 15:50:00',NULL,'NON_CLUSTERED1468330467934'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 15:50:00',NULL,'2016-07-15 15:50:00',NULL,'NON_CLUSTERED1468330467935'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 16:00:00',NULL,'2016-07-15 16:00:00',NULL,'NON_CLUSTERED1468330467936'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 16:00:00',NULL,'2016-07-15 16:00:00',NULL,'NON_CLUSTERED1468330467937'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 16:10:00',NULL,'2016-07-15 16:10:00',NULL,'NON_CLUSTERED1468330467938');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 16:10:00',NULL,'2016-07-15 16:10:00',NULL,'NON_CLUSTERED1468330467939'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 16:20:00',NULL,'2016-07-15 16:20:00',NULL,'NON_CLUSTERED1468330467940'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 16:20:00',NULL,'2016-07-15 16:20:00',NULL,'NON_CLUSTERED1468330467941'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 16:30:00',NULL,'2016-07-15 16:30:00',NULL,'NON_CLUSTERED1468330467942'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 16:30:00',NULL,'2016-07-15 16:30:00',NULL,'NON_CLUSTERED1468330467943');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 16:40:00',NULL,'2016-07-15 16:40:00',NULL,'NON_CLUSTERED1468330467944'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 16:40:00',NULL,'2016-07-15 16:40:00',NULL,'NON_CLUSTERED1468330467945'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 16:50:00',NULL,'2016-07-15 16:50:00',NULL,'NON_CLUSTERED1468330467946'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 16:50:00',NULL,'2016-07-15 16:50:00',NULL,'NON_CLUSTERED1468330467947'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 17:00:00',NULL,'2016-07-15 17:00:00',NULL,'NON_CLUSTERED1468330467948');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 17:00:00',NULL,'2016-07-15 17:00:00',NULL,'NON_CLUSTERED1468330467949'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 17:10:00',NULL,'2016-07-15 17:10:00',NULL,'NON_CLUSTERED1468330467950'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 17:10:00',NULL,'2016-07-15 17:10:00',NULL,'NON_CLUSTERED1468330467951'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 17:20:00',NULL,'2016-07-15 17:20:00',NULL,'NON_CLUSTERED1468330467952'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 17:20:00',NULL,'2016-07-15 17:20:00',NULL,'NON_CLUSTERED1468330467953');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 17:30:00',NULL,'2016-07-15 17:30:00',NULL,'NON_CLUSTERED1468330467954'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 17:30:00',NULL,'2016-07-15 17:30:00',NULL,'NON_CLUSTERED1468330467955'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 17:40:00',NULL,'2016-07-15 17:40:00',NULL,'NON_CLUSTERED1468330467956'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 17:40:00',NULL,'2016-07-15 17:40:00',NULL,'NON_CLUSTERED1468330467957'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 17:50:00',NULL,'2016-07-15 17:50:00',NULL,'NON_CLUSTERED1468330467958');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 17:50:00',NULL,'2016-07-15 17:50:00',NULL,'NON_CLUSTERED1468330467959'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 18:00:00',NULL,'2016-07-15 18:00:00',NULL,'NON_CLUSTERED1468330467960'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 18:00:00',NULL,'2016-07-15 18:00:00',NULL,'NON_CLUSTERED1468330467961'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 18:10:00',NULL,'2016-07-15 18:10:00',NULL,'NON_CLUSTERED1468330467962'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 18:10:00',NULL,'2016-07-15 18:10:00',NULL,'NON_CLUSTERED1468330467963');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 18:20:00',NULL,'2016-07-15 18:20:00',NULL,'NON_CLUSTERED1468330467964'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 18:20:00',NULL,'2016-07-15 18:20:00',NULL,'NON_CLUSTERED1468330467965'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 18:30:00',NULL,'2016-07-15 18:30:00',NULL,'NON_CLUSTERED1468330467966'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 18:30:00',NULL,'2016-07-15 18:30:00',NULL,'NON_CLUSTERED1468330467967'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 18:40:00',NULL,'2016-07-15 18:40:00',NULL,'NON_CLUSTERED1468330467968');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 18:40:00',NULL,'2016-07-15 18:40:00',NULL,'NON_CLUSTERED1468330467969'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 18:50:00',NULL,'2016-07-15 18:50:00',NULL,'NON_CLUSTERED1468330467970'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 18:50:00',NULL,'2016-07-15 18:50:00',NULL,'NON_CLUSTERED1468330467971'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 19:00:00',NULL,'2016-07-15 19:00:00',NULL,'NON_CLUSTERED1468330467972'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 19:00:00',NULL,'2016-07-15 19:00:00',NULL,'NON_CLUSTERED1468330467973');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 19:10:00',NULL,'2016-07-15 19:10:00',NULL,'NON_CLUSTERED1468330467974'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 19:10:00',NULL,'2016-07-15 19:10:00',NULL,'NON_CLUSTERED1468330467975'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 19:20:00',NULL,'2016-07-15 19:20:00',NULL,'NON_CLUSTERED1468330467976'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 19:20:00',NULL,'2016-07-15 19:20:00',NULL,'NON_CLUSTERED1468330467977'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 19:30:00',NULL,'2016-07-15 19:30:00',NULL,'NON_CLUSTERED1468330467978');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 19:30:00',NULL,'2016-07-15 19:30:00',NULL,'NON_CLUSTERED1468330467979'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 19:40:00',NULL,'2016-07-15 19:40:00',NULL,'NON_CLUSTERED1468330467980'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 19:40:00',NULL,'2016-07-15 19:40:00',NULL,'NON_CLUSTERED1468330467981'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 19:50:00',NULL,'2016-07-15 19:50:00',NULL,'NON_CLUSTERED1468330467982'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 19:50:00',NULL,'2016-07-15 19:50:00',NULL,'NON_CLUSTERED1468330467983');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 20:00:00',NULL,'2016-07-15 20:00:00',NULL,'NON_CLUSTERED1468330467984'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 20:00:00',NULL,'2016-07-15 20:00:00',NULL,'NON_CLUSTERED1468330467985'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 20:10:00',NULL,'2016-07-15 20:10:00',NULL,'NON_CLUSTERED1468330467986'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 20:10:00',NULL,'2016-07-15 20:10:00',NULL,'NON_CLUSTERED1468330467987'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 20:20:00',NULL,'2016-07-15 20:20:00',NULL,'NON_CLUSTERED1468330467988');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 20:20:00',NULL,'2016-07-15 20:20:00',NULL,'NON_CLUSTERED1468330467989'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 20:30:00',NULL,'2016-07-15 20:30:00',NULL,'NON_CLUSTERED1468330467990'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 20:30:00',NULL,'2016-07-15 20:30:00',NULL,'NON_CLUSTERED1468330467991'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 20:40:00',NULL,'2016-07-15 20:40:00',NULL,'NON_CLUSTERED1468330467992'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 20:40:00',NULL,'2016-07-15 20:40:00',NULL,'NON_CLUSTERED1468330467993');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 20:50:00',NULL,'2016-07-15 20:50:00',NULL,'NON_CLUSTERED1468330467994'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 20:50:00',NULL,'2016-07-15 20:50:00',NULL,'NON_CLUSTERED1468330467995'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 21:00:00',NULL,'2016-07-15 21:00:00',NULL,'NON_CLUSTERED1468330467996'),
 ('Trigger Key EnvironmentDeletion','System Triggers','Job Key EnvironmentDeletion','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 21:00:00',NULL,'2016-07-15 21:00:00',NULL,'NON_CLUSTERED1468330467997'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 21:00:00',NULL,'2016-07-15 21:00:00',NULL,'NON_CLUSTERED1468330467998');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 21:10:00',NULL,'2016-07-15 21:10:00',NULL,'NON_CLUSTERED1468330467999'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 21:10:00',NULL,'2016-07-15 21:10:00',NULL,'NON_CLUSTERED1468330468000'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 21:20:00',NULL,'2016-07-15 21:20:00',NULL,'NON_CLUSTERED1468330468001'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 21:20:00',NULL,'2016-07-15 21:20:00',NULL,'NON_CLUSTERED1468330468002'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 21:30:00',NULL,'2016-07-15 21:30:00',NULL,'NON_CLUSTERED1468330468003');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 21:30:00',NULL,'2016-07-15 21:30:00',NULL,'NON_CLUSTERED1468330468004'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 21:40:00',NULL,'2016-07-15 21:40:00',NULL,'NON_CLUSTERED1468330468005'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 21:40:00',NULL,'2016-07-15 21:40:00',NULL,'NON_CLUSTERED1468330468006'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 21:50:00',NULL,'2016-07-15 21:50:00',NULL,'NON_CLUSTERED1468330468007'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 21:50:00',NULL,'2016-07-15 21:50:00',NULL,'NON_CLUSTERED1468330468008');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 22:00:00',NULL,'2016-07-15 22:00:00',NULL,'NON_CLUSTERED1468330468009'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 22:00:00',NULL,'2016-07-15 22:00:00',NULL,'NON_CLUSTERED1468330468010'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 22:10:00',NULL,'2016-07-15 22:10:00',NULL,'NON_CLUSTERED1468330468011'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 22:10:00',NULL,'2016-07-15 22:10:00',NULL,'NON_CLUSTERED1468330468012'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 22:20:00',NULL,'2016-07-15 22:20:00',NULL,'NON_CLUSTERED1468330468013');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 22:20:00',NULL,'2016-07-15 22:20:00',NULL,'NON_CLUSTERED1468330468014'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 22:30:00',NULL,'2016-07-15 22:30:00',NULL,'NON_CLUSTERED1468330468015'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 22:30:00',NULL,'2016-07-15 22:30:00',NULL,'NON_CLUSTERED1468330468016'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 22:40:00',NULL,'2016-07-15 22:40:00',NULL,'NON_CLUSTERED1468330468017'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 22:40:00',NULL,'2016-07-15 22:40:00',NULL,'NON_CLUSTERED1468330468018');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 22:50:00',NULL,'2016-07-15 22:50:00',NULL,'NON_CLUSTERED1468330468019'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 22:50:00',NULL,'2016-07-15 22:50:00',NULL,'NON_CLUSTERED1468330468020'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 23:00:00',NULL,'2016-07-15 23:00:00',NULL,'NON_CLUSTERED1468330468021'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 23:00:00',NULL,'2016-07-15 23:00:00',NULL,'NON_CLUSTERED1468330468022'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 23:10:00',NULL,'2016-07-15 23:10:00',NULL,'NON_CLUSTERED1468330468023');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 23:10:00',NULL,'2016-07-15 23:10:00',NULL,'NON_CLUSTERED1468330468024'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 23:20:00',NULL,'2016-07-15 23:20:00',NULL,'NON_CLUSTERED1468330468025'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 23:20:00',NULL,'2016-07-15 23:20:00',NULL,'NON_CLUSTERED1468330468026'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 23:30:00',NULL,'2016-07-15 23:30:00',NULL,'NON_CLUSTERED1468330468027'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 23:30:00',NULL,'2016-07-15 23:30:00',NULL,'NON_CLUSTERED1468330468028');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 23:40:00',NULL,'2016-07-15 23:40:00',NULL,'NON_CLUSTERED1468330468029'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 23:40:00',NULL,'2016-07-15 23:40:00',NULL,'NON_CLUSTERED1468330468030'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 23:50:00',NULL,'2016-07-15 23:50:00',NULL,'NON_CLUSTERED1468330468031'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-15 23:50:00',NULL,'2016-07-15 23:50:00',NULL,'NON_CLUSTERED1468330468032'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 00:00:00',NULL,'2016-07-16 00:00:00',NULL,'NON_CLUSTERED1468330468033');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 00:00:00',NULL,'2016-07-16 00:00:00',NULL,'NON_CLUSTERED1468330468034'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 00:10:00',NULL,'2016-07-16 00:10:00',NULL,'NON_CLUSTERED1468330468035'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 00:10:00',NULL,'2016-07-16 00:10:00',NULL,'NON_CLUSTERED1468330468036'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 00:20:00',NULL,'2016-07-16 00:20:00',NULL,'NON_CLUSTERED1468330468037'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 00:20:00',NULL,'2016-07-16 00:20:00',NULL,'NON_CLUSTERED1468330468038');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 00:30:00',NULL,'2016-07-16 00:30:00',NULL,'NON_CLUSTERED1468330468039'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 00:30:00',NULL,'2016-07-16 00:30:00',NULL,'NON_CLUSTERED1468330468040'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 00:40:00',NULL,'2016-07-16 00:40:00',NULL,'NON_CLUSTERED1468330468041'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 00:40:00',NULL,'2016-07-16 00:40:00',NULL,'NON_CLUSTERED1468330468042'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 00:50:00',NULL,'2016-07-16 00:50:00',NULL,'NON_CLUSTERED1468330468043');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 00:50:00',NULL,'2016-07-16 00:50:00',NULL,'NON_CLUSTERED1468330468044'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 01:00:00',NULL,'2016-07-16 01:00:00',NULL,'NON_CLUSTERED1468330468045'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 01:00:00',NULL,'2016-07-16 01:00:00',NULL,'NON_CLUSTERED1468330468046'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 01:10:00',NULL,'2016-07-16 01:10:00',NULL,'NON_CLUSTERED1468330468047'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 01:10:00',NULL,'2016-07-16 01:10:00',NULL,'NON_CLUSTERED1468330468048');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 01:20:00',NULL,'2016-07-16 01:20:00',NULL,'NON_CLUSTERED1468330468049'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 01:20:00',NULL,'2016-07-16 01:20:00',NULL,'NON_CLUSTERED1468330468050'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 01:30:00',NULL,'2016-07-16 01:30:00',NULL,'NON_CLUSTERED1468330468051'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 01:30:00',NULL,'2016-07-16 01:30:00',NULL,'NON_CLUSTERED1468330468052'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 01:40:00',NULL,'2016-07-16 01:40:00',NULL,'NON_CLUSTERED1468330468053');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 01:40:00',NULL,'2016-07-16 01:40:00',NULL,'NON_CLUSTERED1468330468054'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 01:50:00',NULL,'2016-07-16 01:50:00',NULL,'NON_CLUSTERED1468330468055'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 01:50:00',NULL,'2016-07-16 01:50:00',NULL,'NON_CLUSTERED1468330468056'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 02:00:00',NULL,'2016-07-16 02:00:00',NULL,'NON_CLUSTERED1468330468057'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 02:00:00',NULL,'2016-07-16 02:00:00',NULL,'NON_CLUSTERED1468330468058');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 02:10:00',NULL,'2016-07-16 02:10:00',NULL,'NON_CLUSTERED1468330468059'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 02:10:00',NULL,'2016-07-16 02:10:00',NULL,'NON_CLUSTERED1468330468060'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 02:20:00',NULL,'2016-07-16 02:20:00',NULL,'NON_CLUSTERED1468330468061'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 02:20:00',NULL,'2016-07-16 02:20:00',NULL,'NON_CLUSTERED1468330468062'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 02:30:00',NULL,'2016-07-16 02:30:00',NULL,'NON_CLUSTERED1468330468063');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 02:30:00',NULL,'2016-07-16 02:30:00',NULL,'NON_CLUSTERED1468330468064'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 02:40:00',NULL,'2016-07-16 02:40:00',NULL,'NON_CLUSTERED1468330468065'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 02:40:00',NULL,'2016-07-16 02:40:00',NULL,'NON_CLUSTERED1468330468066'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 02:50:00',NULL,'2016-07-16 02:50:00',NULL,'NON_CLUSTERED1468330468067'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 02:50:00',NULL,'2016-07-16 02:50:00',NULL,'NON_CLUSTERED1468330468068');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 03:00:00',NULL,'2016-07-16 03:00:00',NULL,'NON_CLUSTERED1468330468069'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 03:00:00',NULL,'2016-07-16 03:00:00',NULL,'NON_CLUSTERED1468330468070'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 03:10:00',NULL,'2016-07-16 03:10:00',NULL,'NON_CLUSTERED1468330468071'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 03:10:00',NULL,'2016-07-16 03:10:00',NULL,'NON_CLUSTERED1468330468072'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 03:20:00',NULL,'2016-07-16 03:20:00',NULL,'NON_CLUSTERED1468330468073');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 03:20:00',NULL,'2016-07-16 03:20:00',NULL,'NON_CLUSTERED1468330468074'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 03:30:00',NULL,'2016-07-16 03:30:00',NULL,'NON_CLUSTERED1468330468075'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 03:30:00',NULL,'2016-07-16 03:30:00',NULL,'NON_CLUSTERED1468330468076'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 03:40:00',NULL,'2016-07-16 03:40:00',NULL,'NON_CLUSTERED1468330468077'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 03:40:00',NULL,'2016-07-16 03:40:00',NULL,'NON_CLUSTERED1468330468078');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 03:50:00',NULL,'2016-07-16 03:50:00',NULL,'NON_CLUSTERED1468330468079'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 03:50:00',NULL,'2016-07-16 03:50:00',NULL,'NON_CLUSTERED1468330468080'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 04:00:00',NULL,'2016-07-16 04:00:00',NULL,'NON_CLUSTERED1468330468081'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 04:00:00',NULL,'2016-07-16 04:00:00',NULL,'NON_CLUSTERED1468330468082'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 04:10:00',NULL,'2016-07-16 04:10:00',NULL,'NON_CLUSTERED1468330468083');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 04:10:00',NULL,'2016-07-16 04:10:00',NULL,'NON_CLUSTERED1468330468084'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 04:20:00',NULL,'2016-07-16 04:20:00',NULL,'NON_CLUSTERED1468330468085'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 04:20:00',NULL,'2016-07-16 04:20:00',NULL,'NON_CLUSTERED1468330468086'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 04:30:00',NULL,'2016-07-16 04:30:00',NULL,'NON_CLUSTERED1468330468087'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 04:30:00',NULL,'2016-07-16 04:30:00',NULL,'NON_CLUSTERED1468330468088');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 04:40:00',NULL,'2016-07-16 04:40:00',NULL,'NON_CLUSTERED1468330468089'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 04:40:00',NULL,'2016-07-16 04:40:00',NULL,'NON_CLUSTERED1468330468090'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 04:50:00',NULL,'2016-07-16 04:50:00',NULL,'NON_CLUSTERED1468330468091'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 04:50:00',NULL,'2016-07-16 04:50:00',NULL,'NON_CLUSTERED1468330468092'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 05:00:00',NULL,'2016-07-16 05:00:00',NULL,'NON_CLUSTERED1468330468093');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 05:00:00',NULL,'2016-07-16 05:00:00',NULL,'NON_CLUSTERED1468330468094'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 05:10:00',NULL,'2016-07-16 05:10:00',NULL,'NON_CLUSTERED1468330468095'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 05:10:00',NULL,'2016-07-16 05:10:00',NULL,'NON_CLUSTERED1468330468096'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 05:20:00',NULL,'2016-07-16 05:20:00',NULL,'NON_CLUSTERED1468330468097'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 05:20:00',NULL,'2016-07-16 05:20:00',NULL,'NON_CLUSTERED1468330468098');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 05:30:00',NULL,'2016-07-16 05:30:00',NULL,'NON_CLUSTERED1468330468099'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 05:30:00',NULL,'2016-07-16 05:30:00',NULL,'NON_CLUSTERED1468330468100'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 05:40:00',NULL,'2016-07-16 05:40:00',NULL,'NON_CLUSTERED1468330468101'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 05:40:00',NULL,'2016-07-16 05:40:00',NULL,'NON_CLUSTERED1468330468102'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 05:50:00',NULL,'2016-07-16 05:50:00',NULL,'NON_CLUSTERED1468330468103');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 05:50:00',NULL,'2016-07-16 05:50:00',NULL,'NON_CLUSTERED1468330468104'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 06:00:00',NULL,'2016-07-16 06:00:00',NULL,'NON_CLUSTERED1468330468105'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 06:00:00',NULL,'2016-07-16 06:00:00',NULL,'NON_CLUSTERED1468330468106'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 06:10:00',NULL,'2016-07-16 06:10:00',NULL,'NON_CLUSTERED1468330468107'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 06:10:00',NULL,'2016-07-16 06:10:00',NULL,'NON_CLUSTERED1468330468108');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 06:20:00',NULL,'2016-07-16 06:20:00',NULL,'NON_CLUSTERED1468330468109'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 06:20:00',NULL,'2016-07-16 06:20:00',NULL,'NON_CLUSTERED1468330468110'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 06:30:00',NULL,'2016-07-16 06:30:00',NULL,'NON_CLUSTERED1468330468111'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 06:30:00',NULL,'2016-07-16 06:30:00',NULL,'NON_CLUSTERED1468330468112'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 06:40:00',NULL,'2016-07-16 06:40:00',NULL,'NON_CLUSTERED1468330468113');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 06:40:00',NULL,'2016-07-16 06:40:00',NULL,'NON_CLUSTERED1468330468114'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 06:50:00',NULL,'2016-07-16 06:50:00',NULL,'NON_CLUSTERED1468330468115'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 06:50:00',NULL,'2016-07-16 06:50:00',NULL,'NON_CLUSTERED1468330468116'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 07:00:00',NULL,'2016-07-16 07:00:00',NULL,'NON_CLUSTERED1468330468117'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 07:00:00',NULL,'2016-07-16 07:00:00',NULL,'NON_CLUSTERED1468330468118');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 07:10:00',NULL,'2016-07-16 07:10:00',NULL,'NON_CLUSTERED1468330468119'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 07:10:00',NULL,'2016-07-16 07:10:00',NULL,'NON_CLUSTERED1468330468120'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 07:20:00',NULL,'2016-07-16 07:20:00',NULL,'NON_CLUSTERED1468330468121'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 07:20:00',NULL,'2016-07-16 07:20:00',NULL,'NON_CLUSTERED1468330468122'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 07:30:00',NULL,'2016-07-16 07:30:00',NULL,'NON_CLUSTERED1468330468123');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 07:30:00',NULL,'2016-07-16 07:30:00',NULL,'NON_CLUSTERED1468330468124'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 07:40:00',NULL,'2016-07-16 07:40:00',NULL,'NON_CLUSTERED1468330468125'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 07:40:00',NULL,'2016-07-16 07:40:00',NULL,'NON_CLUSTERED1468330468126'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 07:50:00',NULL,'2016-07-16 07:50:00',NULL,'NON_CLUSTERED1468330468127'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 07:50:00',NULL,'2016-07-16 07:50:00',NULL,'NON_CLUSTERED1468330468128');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 08:00:00',NULL,'2016-07-16 08:00:00',NULL,'NON_CLUSTERED1468330468129'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 08:00:00',NULL,'2016-07-16 08:00:00',NULL,'NON_CLUSTERED1468330468130'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 08:10:00',NULL,'2016-07-16 08:10:00',NULL,'NON_CLUSTERED1468330468131'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 08:10:00',NULL,'2016-07-16 08:10:00',NULL,'NON_CLUSTERED1468330468132'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 08:20:00',NULL,'2016-07-16 08:20:00',NULL,'NON_CLUSTERED1468330468133');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 08:20:00',NULL,'2016-07-16 08:20:00',NULL,'NON_CLUSTERED1468330468134'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 08:30:00',NULL,'2016-07-16 08:30:00',NULL,'NON_CLUSTERED1468330468135'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 08:30:00',NULL,'2016-07-16 08:30:00',NULL,'NON_CLUSTERED1468330468136'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 08:40:00',NULL,'2016-07-16 08:40:00',NULL,'NON_CLUSTERED1468330468137'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 08:40:00',NULL,'2016-07-16 08:40:00',NULL,'NON_CLUSTERED1468330468138');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 08:50:00',NULL,'2016-07-16 08:50:00',NULL,'NON_CLUSTERED1468330468139'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 08:50:00',NULL,'2016-07-16 08:50:00',NULL,'NON_CLUSTERED1468330468140'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 09:00:00',NULL,'2016-07-16 09:00:00',NULL,'NON_CLUSTERED1468330468141'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 09:00:00',NULL,'2016-07-16 09:00:00',NULL,'NON_CLUSTERED1468330468142'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 09:10:00',NULL,'2016-07-16 09:10:00',NULL,'NON_CLUSTERED1468330468143');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 09:10:00',NULL,'2016-07-16 09:10:00',NULL,'NON_CLUSTERED1468330468144'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 09:20:00',NULL,'2016-07-16 09:20:00',NULL,'NON_CLUSTERED1468330468145'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 09:20:00',NULL,'2016-07-16 09:20:00',NULL,'NON_CLUSTERED1468330468146'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 09:30:00',NULL,'2016-07-16 09:30:00',NULL,'NON_CLUSTERED1468330468147'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 09:30:00',NULL,'2016-07-16 09:30:00',NULL,'NON_CLUSTERED1468330468148');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 09:40:00',NULL,'2016-07-16 09:40:00',NULL,'NON_CLUSTERED1468330468149'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 09:40:00',NULL,'2016-07-16 09:40:00',NULL,'NON_CLUSTERED1468330468150'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 09:50:00',NULL,'2016-07-16 09:50:00',NULL,'NON_CLUSTERED1468330468151'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 09:50:00',NULL,'2016-07-16 09:50:00',NULL,'NON_CLUSTERED1468330468152'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 10:00:00',NULL,'2016-07-16 10:00:00',NULL,'NON_CLUSTERED1468330468153');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 10:00:00',NULL,'2016-07-16 10:00:00',NULL,'NON_CLUSTERED1468330468154'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 10:10:00',NULL,'2016-07-16 10:10:00',NULL,'NON_CLUSTERED1468330468155'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 10:10:00',NULL,'2016-07-16 10:10:00',NULL,'NON_CLUSTERED1468330468156'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 10:20:00',NULL,'2016-07-16 10:20:00',NULL,'NON_CLUSTERED1468330468157'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 10:20:00',NULL,'2016-07-16 10:20:00',NULL,'NON_CLUSTERED1468330468158');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 10:30:00',NULL,'2016-07-16 10:30:00',NULL,'NON_CLUSTERED1468330468159'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 10:30:00',NULL,'2016-07-16 10:30:00',NULL,'NON_CLUSTERED1468330468160'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 10:40:00',NULL,'2016-07-16 10:40:00',NULL,'NON_CLUSTERED1468330468161'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 10:40:00',NULL,'2016-07-16 10:40:00',NULL,'NON_CLUSTERED1468330468162'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 10:50:00',NULL,'2016-07-16 10:50:00',NULL,'NON_CLUSTERED1468330468163');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 10:50:00',NULL,'2016-07-16 10:50:00',NULL,'NON_CLUSTERED1468330468164'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 11:00:00',NULL,'2016-07-16 11:00:00',NULL,'NON_CLUSTERED1468330468165'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 11:00:00',NULL,'2016-07-16 11:00:00',NULL,'NON_CLUSTERED1468330468166'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 11:10:00',NULL,'2016-07-16 11:10:00',NULL,'NON_CLUSTERED1468330468167'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 11:10:00',NULL,'2016-07-16 11:10:00',NULL,'NON_CLUSTERED1468330468168');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 11:20:00',NULL,'2016-07-16 11:20:00',NULL,'NON_CLUSTERED1468330468169'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 11:20:00',NULL,'2016-07-16 11:20:00',NULL,'NON_CLUSTERED1468330468170'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 11:30:00',NULL,'2016-07-16 11:30:00',NULL,'NON_CLUSTERED1468330468171'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 11:30:00',NULL,'2016-07-16 11:30:00',NULL,'NON_CLUSTERED1468330468172'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 11:40:00',NULL,'2016-07-16 11:40:00',NULL,'NON_CLUSTERED1468330468173');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 11:40:00',NULL,'2016-07-16 11:40:00',NULL,'NON_CLUSTERED1468330468174'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 11:50:00',NULL,'2016-07-16 11:50:00',NULL,'NON_CLUSTERED1468330468175'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 11:50:00',NULL,'2016-07-16 11:50:00',NULL,'NON_CLUSTERED1468330468176'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 12:00:00',NULL,'2016-07-16 12:00:00',NULL,'NON_CLUSTERED1468330468177'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 12:00:00',NULL,'2016-07-16 12:00:00',NULL,'NON_CLUSTERED1468330468178');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 12:10:00',NULL,'2016-07-16 12:10:00',NULL,'NON_CLUSTERED1468330468179'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 12:10:00',NULL,'2016-07-16 12:10:00',NULL,'NON_CLUSTERED1468330468180'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 12:20:00',NULL,'2016-07-16 12:20:00',NULL,'NON_CLUSTERED1468330468181'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 12:20:00',NULL,'2016-07-16 12:20:00',NULL,'NON_CLUSTERED1468330468182'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 12:30:00',NULL,'2016-07-16 12:30:00',NULL,'NON_CLUSTERED1468330468183');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 12:30:00',NULL,'2016-07-16 12:30:00',NULL,'NON_CLUSTERED1468330468184'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 12:40:00',NULL,'2016-07-16 12:40:00',NULL,'NON_CLUSTERED1468330468185'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 12:40:00',NULL,'2016-07-16 12:40:00',NULL,'NON_CLUSTERED1468330468186'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 12:50:00',NULL,'2016-07-16 12:50:00',NULL,'NON_CLUSTERED1468330468187'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 12:50:00',NULL,'2016-07-16 12:50:00',NULL,'NON_CLUSTERED1468330468188');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 13:00:00',NULL,'2016-07-16 13:00:00',NULL,'NON_CLUSTERED1468330468189'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 13:00:00',NULL,'2016-07-16 13:00:00',NULL,'NON_CLUSTERED1468330468190'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 13:10:00',NULL,'2016-07-16 13:10:00',NULL,'NON_CLUSTERED1468330468191'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 13:10:00',NULL,'2016-07-16 13:10:00',NULL,'NON_CLUSTERED1468330468192'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 13:20:00',NULL,'2016-07-16 13:20:00',NULL,'NON_CLUSTERED1468330468193');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 13:20:00',NULL,'2016-07-16 13:20:00',NULL,'NON_CLUSTERED1468330468194'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 13:30:00',NULL,'2016-07-16 13:30:00',NULL,'NON_CLUSTERED1468330468195'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 13:30:00',NULL,'2016-07-16 13:30:00',NULL,'NON_CLUSTERED1468330468196'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 13:40:00',NULL,'2016-07-16 13:40:00',NULL,'NON_CLUSTERED1468330468197'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 13:40:00',NULL,'2016-07-16 13:40:00',NULL,'NON_CLUSTERED1468330468198');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 13:50:00',NULL,'2016-07-16 13:50:00',NULL,'NON_CLUSTERED1468330468199'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 13:50:00',NULL,'2016-07-16 13:50:00',NULL,'NON_CLUSTERED1468330468200'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 14:00:00',NULL,'2016-07-16 14:00:00',NULL,'NON_CLUSTERED1468330468201'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 14:00:00',NULL,'2016-07-16 14:00:00',NULL,'NON_CLUSTERED1468330468202'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 14:10:00',NULL,'2016-07-16 14:10:00',NULL,'NON_CLUSTERED1468330468203');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 14:10:00',NULL,'2016-07-16 14:10:00',NULL,'NON_CLUSTERED1468330468204'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 14:20:00',NULL,'2016-07-16 14:20:00',NULL,'NON_CLUSTERED1468330468205'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 14:20:00',NULL,'2016-07-16 14:20:00',NULL,'NON_CLUSTERED1468330468206'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 14:30:00',NULL,'2016-07-16 14:30:00',NULL,'NON_CLUSTERED1468330468207'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 14:30:00',NULL,'2016-07-16 14:30:00',NULL,'NON_CLUSTERED1468330468208');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 14:40:00',NULL,'2016-07-16 14:40:00',NULL,'NON_CLUSTERED1468330468209'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 14:40:00',NULL,'2016-07-16 14:40:00',NULL,'NON_CLUSTERED1468330468210'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 14:50:00',NULL,'2016-07-16 14:50:00',NULL,'NON_CLUSTERED1468330468211'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 14:50:00',NULL,'2016-07-16 14:50:00',NULL,'NON_CLUSTERED1468330468212'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 15:00:00',NULL,'2016-07-16 15:00:00',NULL,'NON_CLUSTERED1468330468213');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 15:00:00',NULL,'2016-07-16 15:00:00',NULL,'NON_CLUSTERED1468330468214'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 15:10:00',NULL,'2016-07-16 15:10:00',NULL,'NON_CLUSTERED1468330468215'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 15:10:00',NULL,'2016-07-16 15:10:00',NULL,'NON_CLUSTERED1468330468216'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 15:20:00',NULL,'2016-07-16 15:20:00',NULL,'NON_CLUSTERED1468330468217'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 15:20:00',NULL,'2016-07-16 15:20:00',NULL,'NON_CLUSTERED1468330468218');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key ReservationExpiration Mail','System Triggers','Job Key Reservation Expiration Mail','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 15:23:00',NULL,'2016-07-16 15:23:00',NULL,'NON_CLUSTERED1468330468219'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 15:30:00',NULL,'2016-07-16 15:30:00',NULL,'NON_CLUSTERED1468330468220'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 15:30:00',NULL,'2016-07-16 15:30:00',NULL,'NON_CLUSTERED1468330468221'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 15:40:00',NULL,'2016-07-16 15:40:00',NULL,'NON_CLUSTERED1468330468222'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 15:40:00',NULL,'2016-07-16 15:40:00',NULL,'NON_CLUSTERED1468330468223');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 15:50:00',NULL,'2016-07-16 15:50:00',NULL,'NON_CLUSTERED1468330468224'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 15:50:00',NULL,'2016-07-16 15:50:00',NULL,'NON_CLUSTERED1468330468225'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 16:00:00',NULL,'2016-07-16 16:00:00',NULL,'NON_CLUSTERED1468330468226'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 16:00:00',NULL,'2016-07-16 16:00:00',NULL,'NON_CLUSTERED1468330468227'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 16:10:00',NULL,'2016-07-16 16:10:00',NULL,'NON_CLUSTERED1468330468228');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 16:10:00',NULL,'2016-07-16 16:10:00',NULL,'NON_CLUSTERED1468330468229'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 16:20:00',NULL,'2016-07-16 16:20:00',NULL,'NON_CLUSTERED1468330468230'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 16:20:00',NULL,'2016-07-16 16:20:00',NULL,'NON_CLUSTERED1468330468231'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 16:30:00',NULL,'2016-07-16 16:30:00',NULL,'NON_CLUSTERED1468330468232'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 16:30:00',NULL,'2016-07-16 16:30:00',NULL,'NON_CLUSTERED1468330468233');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 16:40:00',NULL,'2016-07-16 16:40:00',NULL,'NON_CLUSTERED1468330468234'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 16:40:00',NULL,'2016-07-16 16:40:00',NULL,'NON_CLUSTERED1468330468235'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 16:50:00',NULL,'2016-07-16 16:50:00',NULL,'NON_CLUSTERED1468330468236'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 16:50:00',NULL,'2016-07-16 16:50:00',NULL,'NON_CLUSTERED1468330468237'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 17:00:00',NULL,'2016-07-16 17:00:00',NULL,'NON_CLUSTERED1468330468238');
INSERT INTO `quartz_history` (`trigger_name`,`trigger_group`,`job_name`,`job_group`,`trigger_status`,`status`,`created_by`,`fired_time`,`misfired_time`,`completed_time`,`request_id`,`unique_id`) VALUES 
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 17:00:00',NULL,'2016-07-16 17:00:00',NULL,'NON_CLUSTERED1468330468239'),
 ('Trigger Key DeploymentPipeline','System Triggers','Job Key DeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 17:10:00',NULL,'2016-07-16 17:10:00',NULL,'NON_CLUSTERED1468330468240'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-16 17:10:00',NULL,'2016-07-16 17:10:00',NULL,'NON_CLUSTERED1468330468241'),
 ('Trigger Key JiraDeploymentPipeline','System Triggers','Job Key JiraDeploymentPipeline','System Jobs','DO NOTHING','COMPLETED','SYSTEM','2016-07-20 12:10:00',NULL,'2016-07-20 12:10:00',NULL,'NON_CLUSTERED1469016529520');
/*!40000 ALTER TABLE `quartz_history` ENABLE KEYS */;


--
-- Definition of table `release_planning`
--

DROP TABLE IF EXISTS `release_planning`;
CREATE TABLE `release_planning` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bu_id` int(10) unsigned DEFAULT NULL,
  `project_id` int(10) unsigned DEFAULT NULL,
  `application_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(45) NOT NULL DEFAULT '',
  `version` varchar(45) NOT NULL DEFAULT '',
  `type` varchar(45) NOT NULL DEFAULT '',
  `start_date` datetime DEFAULT NULL,
  `target_date` datetime DEFAULT NULL,
  `manager_id` int(11) DEFAULT NULL,
  `description` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_release_planning_1` (`bu_id`),
  KEY `FK_release_planning_2` (`project_id`),
  KEY `FK_release_planning_3` (`application_id`),
  KEY `FK_release_planning_4` (`manager_id`),
  CONSTRAINT `FK_release_planning_1` FOREIGN KEY (`bu_id`) REFERENCES `client` (`CLIENT_ID`),
  CONSTRAINT `FK_release_planning_2` FOREIGN KEY (`project_id`) REFERENCES `projects` (`ID`),
  CONSTRAINT `FK_release_planning_3` FOREIGN KEY (`application_id`) REFERENCES `applications` (`ID`),
  CONSTRAINT `FK_release_planning_4` FOREIGN KEY (`manager_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `release_planning`
--

/*!40000 ALTER TABLE `release_planning` DISABLE KEYS */;
INSERT INTO `release_planning` (`id`,`bu_id`,`project_id`,`application_id`,`name`,`version`,`type`,`start_date`,`target_date`,`manager_id`,`description`) VALUES 
 (1,2,1,1,'Rel1','1.1','Major','2016-07-04 00:00:00','2016-07-31 00:00:00',3,'');
/*!40000 ALTER TABLE `release_planning` ENABLE KEYS */;


--
-- Definition of table `release_planning_phases`
--

DROP TABLE IF EXISTS `release_planning_phases`;
CREATE TABLE `release_planning_phases` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `release_planning_id` int(10) unsigned DEFAULT NULL,
  `application_phase_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_release_planning_phases_1` (`release_planning_id`),
  KEY `FK_release_planning_phases_2` (`application_phase_id`),
  CONSTRAINT `FK_release_planning_phases_1` FOREIGN KEY (`release_planning_id`) REFERENCES `release_planning` (`id`),
  CONSTRAINT `FK_release_planning_phases_2` FOREIGN KEY (`application_phase_id`) REFERENCES `testing_phase` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `release_planning_phases`
--

/*!40000 ALTER TABLE `release_planning_phases` DISABLE KEYS */;
INSERT INTO `release_planning_phases` (`id`,`release_planning_id`,`application_phase_id`) VALUES 
 (1,1,1),
 (2,1,2),
 (3,1,3),
 (4,1,4),
 (5,1,5),
 (6,1,6),
 (7,1,7);
/*!40000 ALTER TABLE `release_planning_phases` ENABLE KEYS */;


--
-- Definition of table `repo_config`
--

DROP TABLE IF EXISTS `repo_config`;
CREATE TABLE `repo_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `repo_name` varchar(45) NOT NULL DEFAULT '',
  `repo_type` int(11) NOT NULL,
  `repo_username` varchar(45) NOT NULL DEFAULT '',
  `repo_password` varchar(45) NOT NULL DEFAULT '',
  `description` varchar(45) DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `port` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_repo_config_1` (`repo_type`),
  CONSTRAINT `FK_repo_config_1` FOREIGN KEY (`repo_type`) REFERENCES `repo_list` (`repo_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `repo_config`
--

/*!40000 ALTER TABLE `repo_config` DISABLE KEYS */;
INSERT INTO `repo_config` (`id`,`repo_name`,`repo_type`,`repo_username`,`repo_password`,`description`,`ip`,`port`) VALUES 
 (1,'repo_svn',1,'scmuser','kOpE0IAe0rDmdTkbsKviQfIa9R6A0vBe','','','');
/*!40000 ALTER TABLE `repo_config` ENABLE KEYS */;


--
-- Definition of table `repo_config_details`
--

DROP TABLE IF EXISTS `repo_config_details`;
CREATE TABLE `repo_config_details` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `repo_config_id` int(10) unsigned DEFAULT NULL,
  `bu_id` int(10) unsigned DEFAULT NULL,
  `project_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `repo_config_details`
--

/*!40000 ALTER TABLE `repo_config_details` DISABLE KEYS */;
INSERT INTO `repo_config_details` (`id`,`repo_config_id`,`bu_id`,`project_id`) VALUES 
 (1,1,2,1);
/*!40000 ALTER TABLE `repo_config_details` ENABLE KEYS */;


--
-- Definition of table `repo_list`
--

DROP TABLE IF EXISTS `repo_list`;
CREATE TABLE `repo_list` (
  `repo_id` int(5) NOT NULL AUTO_INCREMENT,
  `repo_name` varchar(30) NOT NULL,
  PRIMARY KEY (`repo_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `repo_list`
--

/*!40000 ALTER TABLE `repo_list` DISABLE KEYS */;
INSERT INTO `repo_list` (`repo_id`,`repo_name`) VALUES 
 (1,'SVN'),
 (2,'GIT'),
 (3,'IBM ClearCase'),
 (4,'Perforce'),
 (5,'TFS'),
 (6,'Shared Location');
/*!40000 ALTER TABLE `repo_list` ENABLE KEYS */;


--
-- Definition of table `repository_master`
--

DROP TABLE IF EXISTS `repository_master`;
CREATE TABLE `repository_master` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Type` int(10) unsigned NOT NULL,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `ReleaseId` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `repository_master`
--

/*!40000 ALTER TABLE `repository_master` DISABLE KEYS */;
/*!40000 ALTER TABLE `repository_master` ENABLE KEYS */;


--
-- Definition of table `reservation`
--

DROP TABLE IF EXISTS `reservation`;
CREATE TABLE `reservation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `startTime` datetime DEFAULT NULL,
  `endTime` datetime DEFAULT NULL,
  `userId` int(11) NOT NULL,
  `disruptive` varchar(16) DEFAULT NULL,
  `actionRemark` varchar(1024) DEFAULT NULL,
  `APPLICATION_ID` int(10) unsigned DEFAULT NULL,
  `ENVIRONMENT_ID` int(10) unsigned DEFAULT NULL,
  `STATUS` varchar(2) DEFAULT NULL,
  `CancelUserId` int(10) unsigned DEFAULT NULL,
  `Comments` varchar(255) DEFAULT NULL,
  `Testing_Type` int(10) unsigned DEFAULT NULL,
  `isConflicting` int(10) unsigned NOT NULL DEFAULT '0',
  `IsRepetitive` int(11) DEFAULT NULL,
  `ParentId` int(11) DEFAULT NULL,
  `release_plan_id` int(11) DEFAULT NULL,
  `phase_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `userId` (`userId`),
  KEY `FK_reservation_1` (`APPLICATION_ID`),
  KEY `FK_reservation_2` (`ENVIRONMENT_ID`),
  CONSTRAINT `FK_reservation_1` FOREIGN KEY (`APPLICATION_ID`) REFERENCES `applications` (`ID`),
  CONSTRAINT `FK_reservation_2` FOREIGN KEY (`ENVIRONMENT_ID`) REFERENCES `environments` (`ID`),
  CONSTRAINT `FK_reservation_3` FOREIGN KEY (`userId`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reservation`
--

/*!40000 ALTER TABLE `reservation` DISABLE KEYS */;
INSERT INTO `reservation` (`id`,`startTime`,`endTime`,`userId`,`disruptive`,`actionRemark`,`APPLICATION_ID`,`ENVIRONMENT_ID`,`STATUS`,`CancelUserId`,`Comments`,`Testing_Type`,`isConflicting`,`IsRepetitive`,`ParentId`,`release_plan_id`,`phase_id`) VALUES 
 (1,'2016-07-05 00:00:00','2016-07-08 00:00:00',3,'S','',1,1,'81',NULL,NULL,1,0,0,NULL,NULL,NULL);
/*!40000 ALTER TABLE `reservation` ENABLE KEYS */;


--
-- Definition of table `reservation_mail_master`
--

DROP TABLE IF EXISTS `reservation_mail_master`;
CREATE TABLE `reservation_mail_master` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `subject` varchar(100) DEFAULT NULL,
  `body` varchar(200) DEFAULT NULL,
  `res_status` int(10) unsigned DEFAULT NULL,
  `Remarks` varchar(45) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reservation_mail_master`
--

/*!40000 ALTER TABLE `reservation_mail_master` DISABLE KEYS */;
INSERT INTO `reservation_mail_master` (`ID`,`subject`,`body`,`res_status`,`Remarks`) VALUES 
 (1,'Reservation Request in Pending Approval','Reservation Request has been submitted successfully and it is pending with value. Following are the details:',84,'Pending Approval'),
 (2,'Reservation Cancelled','Reservation request has been cancelled successfully.Following are the details:',82,'cancelled'),
 (3,'Reservation Request Approved','Reservation request has been approved.Following are the details:',81,'reserved'),
 (4,'Reservation Request made in conflict','Reservation request has been done successfully but is in conflict.Following are the details:',83,'conflicting'),
 (5,'Reservation Request Rejected','Reservation request has been rejected by value.Following are the reservation details:',85,'rejected'),
 (6,'Reservation Updation  made successfully','Reservation updation request has been done successfully .Following are the details:',86,'updated'),
 (7,'Reservation Conflicts Resolved','Following reservations were modified while conflict resolution:',87,'conflict resolution'),
 (8,'Reservation Request  Updated in conflict','Reservation updation request has been done successfully but is in conflict .Following are the details:',88,'update in conflicting mode');
/*!40000 ALTER TABLE `reservation_mail_master` ENABLE KEYS */;


--
-- Definition of table `role_level`
--

DROP TABLE IF EXISTS `role_level`;
CREATE TABLE `role_level` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `role_level_order` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_role_level_2` (`role_id`),
  CONSTRAINT `FK_role_level_2` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `role_level`
--

/*!40000 ALTER TABLE `role_level` DISABLE KEYS */;
INSERT INTO `role_level` (`id`,`role_id`,`role_level_order`) VALUES 
 (1,4,1),
 (2,3,2),
 (3,2,3),
 (4,1,4);
/*!40000 ALTER TABLE `role_level` ENABLE KEYS */;


--
-- Definition of table `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(24) NOT NULL,
  `CREATED_BY` int(10) unsigned DEFAULT NULL,
  `CREATED_DATE` datetime DEFAULT NULL,
  `MODIFIED_BY` int(10) unsigned DEFAULT NULL,
  `MODIFIED_DATE` datetime DEFAULT NULL,
  `REMARKS` varchar(45) DEFAULT NULL,
  `STATUS` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `roles`
--

/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` (`id`,`name`,`CREATED_BY`,`CREATED_DATE`,`MODIFIED_BY`,`MODIFIED_DATE`,`REMARKS`,`STATUS`) VALUES 
 (0,'SuperUser',1,'2014-11-17 00:00:00',1,'2014-11-17 00:00:00','',175),
 (1,'Admin',1,'2014-11-17 00:00:00',1,'2014-11-17 00:00:00',NULL,175),
 (2,'Test Manager',1,'2014-11-17 00:00:00',1,'2014-11-17 00:00:00',NULL,175),
 (3,'Test Lead',1,'2014-11-17 00:00:00',1,'2014-11-17 00:00:00',NULL,175),
 (4,'Normal User',1,'2014-11-17 00:00:00',1,'2014-11-17 00:00:00',NULL,175);
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;


--
-- Definition of table `screen_access`
--

DROP TABLE IF EXISTS `screen_access`;
CREATE TABLE `screen_access` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ROLE_ID` int(10) unsigned NOT NULL,
  `SCREEN_ID` int(10) unsigned NOT NULL,
  `ACCESS_S` char(1) DEFAULT NULL,
  `CREATED_BY` int(10) unsigned NOT NULL,
  `CREATED_DATE` datetime NOT NULL,
  `MODIFIED_BY` int(10) unsigned NOT NULL,
  `MODIFIED_DATE` datetime NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_screens` (`SCREEN_ID`),
  CONSTRAINT `FK_screens` FOREIGN KEY (`SCREEN_ID`) REFERENCES `screens` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3342 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `screen_access`
--

/*!40000 ALTER TABLE `screen_access` DISABLE KEYS */;
INSERT INTO `screen_access` (`ID`,`ROLE_ID`,`SCREEN_ID`,`ACCESS_S`,`CREATED_BY`,`CREATED_DATE`,`MODIFIED_BY`,`MODIFIED_DATE`) VALUES 
 (1,0,1,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (2,0,2,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (3,0,3,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (4,0,4,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (5,0,5,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (6,0,6,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (7,0,7,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (8,0,8,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (9,0,9,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (10,0,10,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (11,0,11,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (12,0,12,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (13,0,13,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (14,0,14,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (15,0,15,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26');
INSERT INTO `screen_access` (`ID`,`ROLE_ID`,`SCREEN_ID`,`ACCESS_S`,`CREATED_BY`,`CREATED_DATE`,`MODIFIED_BY`,`MODIFIED_DATE`) VALUES 
 (16,0,16,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (17,0,17,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (18,0,18,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (19,0,19,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (20,0,20,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (21,0,21,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (22,0,22,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (23,0,23,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (24,0,24,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (25,0,25,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (26,0,26,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (27,0,27,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (28,0,28,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (31,0,31,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (32,0,32,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26');
INSERT INTO `screen_access` (`ID`,`ROLE_ID`,`SCREEN_ID`,`ACCESS_S`,`CREATED_BY`,`CREATED_DATE`,`MODIFIED_BY`,`MODIFIED_DATE`) VALUES 
 (33,0,33,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (34,0,34,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (35,0,35,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (36,0,36,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (37,0,37,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (38,0,38,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (39,0,39,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (40,0,40,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (41,0,41,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (42,0,42,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (43,0,43,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (44,0,44,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (45,0,45,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (46,0,46,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (47,0,47,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26');
INSERT INTO `screen_access` (`ID`,`ROLE_ID`,`SCREEN_ID`,`ACCESS_S`,`CREATED_BY`,`CREATED_DATE`,`MODIFIED_BY`,`MODIFIED_DATE`) VALUES 
 (48,0,48,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (50,0,50,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (52,0,52,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (53,0,53,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (54,0,54,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (55,0,55,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (56,0,56,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (57,0,57,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (58,0,58,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (59,0,59,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (60,0,60,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (61,0,61,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (62,0,62,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (63,0,63,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (64,0,64,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26');
INSERT INTO `screen_access` (`ID`,`ROLE_ID`,`SCREEN_ID`,`ACCESS_S`,`CREATED_BY`,`CREATED_DATE`,`MODIFIED_BY`,`MODIFIED_DATE`) VALUES 
 (65,0,65,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (66,0,66,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (67,0,67,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (68,0,68,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (69,0,69,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (70,0,70,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (71,0,71,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (72,0,72,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (73,0,73,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (74,0,74,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (75,0,75,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (76,0,76,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (77,0,77,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (78,0,78,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (79,0,79,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26');
INSERT INTO `screen_access` (`ID`,`ROLE_ID`,`SCREEN_ID`,`ACCESS_S`,`CREATED_BY`,`CREATED_DATE`,`MODIFIED_BY`,`MODIFIED_DATE`) VALUES 
 (80,0,80,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (81,0,81,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (82,0,82,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (83,0,83,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (84,0,84,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (85,0,85,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (86,0,86,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (87,0,87,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (88,0,88,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (89,0,89,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (90,0,90,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (91,0,91,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (92,0,92,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (93,0,93,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (872,0,105,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26');
INSERT INTO `screen_access` (`ID`,`ROLE_ID`,`SCREEN_ID`,`ACCESS_S`,`CREATED_BY`,`CREATED_DATE`,`MODIFIED_BY`,`MODIFIED_DATE`) VALUES 
 (873,0,106,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (2201,0,101,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (2202,0,102,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (2203,0,103,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (2204,0,111,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (2205,0,112,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (2206,0,113,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (2207,0,114,'1',1,'2016-02-24 00:00:00',1,'2016-02-24 00:00:00'),
 (2444,0,115,'1',1,'2016-02-29 00:00:00',1,'2016-02-29 00:00:00'),
 (2601,0,118,'1',1,'2016-03-03 00:00:00',1,'2016-03-03 00:00:00'),
 (2760,0,117,'1',1,'2016-03-04 19:10:24',1,'2016-03-04 19:10:24'),
 (2761,0,116,'1',1,'2016-03-07 11:38:33',1,'2016-03-07 11:38:33'),
 (3243,0,135,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (3244,0,136,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26');
INSERT INTO `screen_access` (`ID`,`ROLE_ID`,`SCREEN_ID`,`ACCESS_S`,`CREATED_BY`,`CREATED_DATE`,`MODIFIED_BY`,`MODIFIED_DATE`) VALUES 
 (3245,0,137,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (3247,0,138,'1',1,'2016-05-04 00:00:00',1,'2016-05-04 00:00:00'),
 (3249,0,139,'1',1,'2016-05-04 00:00:00',1,'2016-05-04 00:00:00'),
 (3251,0,140,'1',1,'2015-03-13 00:00:00',1,'2015-03-13 00:00:00'),
 (3252,0,146,'1',1,'2016-06-15 11:55:22',1,'2016-06-15 11:55:22'),
 (3253,1,1,'1',1,'2016-07-04 13:39:03',1,'2016-07-04 13:39:03'),
 (3254,1,13,'1',1,'2016-07-04 13:39:03',1,'2016-07-04 13:39:03'),
 (3255,1,114,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3256,1,2,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3257,1,14,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3258,1,15,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3259,1,16,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3260,1,17,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3261,1,18,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3262,1,19,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04');
INSERT INTO `screen_access` (`ID`,`ROLE_ID`,`SCREEN_ID`,`ACCESS_S`,`CREATED_BY`,`CREATED_DATE`,`MODIFIED_BY`,`MODIFIED_DATE`) VALUES 
 (3263,1,20,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3264,1,21,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3265,1,22,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3266,1,23,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3267,1,24,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3268,1,25,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3269,1,26,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3270,1,31,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3271,1,32,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3272,1,33,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3273,1,101,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3274,1,102,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3275,1,103,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3276,1,92,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3277,1,111,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04');
INSERT INTO `screen_access` (`ID`,`ROLE_ID`,`SCREEN_ID`,`ACCESS_S`,`CREATED_BY`,`CREATED_DATE`,`MODIFIED_BY`,`MODIFIED_DATE`) VALUES 
 (3278,1,112,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3279,1,113,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3280,1,115,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3281,1,118,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3282,1,119,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3283,1,138,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3284,1,140,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3285,1,144,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3286,1,145,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3287,1,34,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3288,1,35,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3289,1,36,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3290,1,37,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3291,1,38,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04');
INSERT INTO `screen_access` (`ID`,`ROLE_ID`,`SCREEN_ID`,`ACCESS_S`,`CREATED_BY`,`CREATED_DATE`,`MODIFIED_BY`,`MODIFIED_DATE`) VALUES 
 (3292,1,39,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3293,1,40,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3294,1,41,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3295,1,42,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3296,1,43,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3297,1,44,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3298,1,45,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3299,1,46,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3300,1,47,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3301,1,48,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3302,1,50,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3303,1,105,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3304,1,106,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3305,1,139,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3306,1,52,'0',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04');
INSERT INTO `screen_access` (`ID`,`ROLE_ID`,`SCREEN_ID`,`ACCESS_S`,`CREATED_BY`,`CREATED_DATE`,`MODIFIED_BY`,`MODIFIED_DATE`) VALUES 
 (3307,1,53,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3308,1,54,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3309,1,55,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3310,1,56,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3311,1,57,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3312,1,58,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3313,1,59,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3314,1,60,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3315,1,61,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3316,1,62,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3317,1,65,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3318,1,66,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3319,1,67,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3320,1,69,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3321,1,70,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04');
INSERT INTO `screen_access` (`ID`,`ROLE_ID`,`SCREEN_ID`,`ACCESS_S`,`CREATED_BY`,`CREATED_DATE`,`MODIFIED_BY`,`MODIFIED_DATE`) VALUES 
 (3322,1,72,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3323,1,74,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3324,1,75,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3325,1,77,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3326,1,78,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3327,1,79,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3328,1,80,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3329,1,81,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3330,1,82,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3331,1,135,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3332,1,136,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3333,1,137,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3334,1,83,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3335,1,146,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3336,1,84,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04');
INSERT INTO `screen_access` (`ID`,`ROLE_ID`,`SCREEN_ID`,`ACCESS_S`,`CREATED_BY`,`CREATED_DATE`,`MODIFIED_BY`,`MODIFIED_DATE`) VALUES 
 (3337,1,85,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3338,1,117,'1',1,'2016-07-04 13:39:04',1,'2016-07-04 13:39:04'),
 (3339,0,147,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (3340,0,148,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26'),
 (3341,0,149,'1',1,'2015-03-20 16:08:26',1,'2015-03-20 16:08:26');
/*!40000 ALTER TABLE `screen_access` ENABLE KEYS */;


--
-- Definition of table `screen_tree`
--

DROP TABLE IF EXISTS `screen_tree`;
CREATE TABLE `screen_tree` (
  `PK_SCRN_TREE` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `PRNT_SCRN` int(10) unsigned NOT NULL,
  `CHLD_SCRN` int(10) unsigned NOT NULL,
  PRIMARY KEY (`PK_SCRN_TREE`),
  KEY `FK_screen_tree_1` (`PRNT_SCRN`),
  KEY `FK_screen_tree_2` (`CHLD_SCRN`),
  CONSTRAINT `FK_scrn_tr_chld_scrn` FOREIGN KEY (`CHLD_SCRN`) REFERENCES `screens` (`ID`),
  CONSTRAINT `FK_scrn_tr_prnt_scrn` FOREIGN KEY (`PRNT_SCRN`) REFERENCES `screens` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=113 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `screen_tree`
--

/*!40000 ALTER TABLE `screen_tree` DISABLE KEYS */;
INSERT INTO `screen_tree` (`PK_SCRN_TREE`,`PRNT_SCRN`,`CHLD_SCRN`) VALUES 
 (1,1,1),
 (2,1,13),
 (3,2,2),
 (4,3,14),
 (5,3,15),
 (6,3,16),
 (7,3,17),
 (8,3,18),
 (9,3,19),
 (10,3,20),
 (11,3,21),
 (12,3,22),
 (13,3,23),
 (14,3,24),
 (15,3,25),
 (16,3,26),
 (17,3,27),
 (18,3,28),
 (21,3,31),
 (22,3,32),
 (23,3,33),
 (24,4,34),
 (25,4,35),
 (26,4,36),
 (27,4,37),
 (28,4,38),
 (29,4,39),
 (30,4,40),
 (31,4,41),
 (32,4,42),
 (33,4,43),
 (34,4,44),
 (35,4,45),
 (36,4,46),
 (37,4,47),
 (38,4,48),
 (40,4,50),
 (42,5,52),
 (43,5,53),
 (44,5,54),
 (45,5,55),
 (46,6,56),
 (47,6,57),
 (48,6,58),
 (49,6,59),
 (50,7,60),
 (51,7,61),
 (52,7,62),
 (53,9,65),
 (54,9,66),
 (55,10,67),
 (56,10,68),
 (57,10,69),
 (58,10,70),
 (59,10,71),
 (60,10,72),
 (61,10,73),
 (62,10,74),
 (63,10,75),
 (64,10,76),
 (65,10,77),
 (66,10,78),
 (67,10,79),
 (68,10,80),
 (69,10,81),
 (70,10,82),
 (71,11,83),
 (72,12,84),
 (73,12,85),
 (78,3,101),
 (79,3,102),
 (80,3,103),
 (81,3,92),
 (83,4,105),
 (84,4,106),
 (89,3,111),
 (90,3,112);
INSERT INTO `screen_tree` (`PK_SCRN_TREE`,`PRNT_SCRN`,`CHLD_SCRN`) VALUES 
 (91,3,113),
 (92,1,114),
 (93,3,115),
 (94,116,117),
 (95,3,118),
 (96,3,119),
 (101,10,135),
 (102,10,136),
 (103,10,137),
 (104,3,138),
 (105,4,139),
 (106,3,140),
 (107,3,144),
 (108,3,145),
 (109,11,146),
 (110,3,147),
 (111,3,148),
 (112,3,149);
/*!40000 ALTER TABLE `screen_tree` ENABLE KEYS */;


--
-- Definition of table `screens`
--

DROP TABLE IF EXISTS `screens`;
CREATE TABLE `screens` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `NAME` varchar(45) NOT NULL,
  `ACTION_STR` varchar(45) NOT NULL,
  `ADMIN_ACCESS` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `Index_2` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=150 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `screens`
--

/*!40000 ALTER TABLE `screens` DISABLE KEYS */;
INSERT INTO `screens` (`ID`,`NAME`,`ACTION_STR`,`ADMIN_ACCESS`) VALUES 
 (1,'Home','HomeAction',NULL),
 (2,'Calendar','SummaryViewAction',NULL),
 (3,'Administration','Admin',NULL),
 (4,'Templates','Inventory',NULL),
 (5,'Environment','Environment',NULL),
 (6,'Reservation','Reservation',NULL),
 (7,'Reports','Reports',NULL),
 (8,'Profile','Profile',NULL),
 (9,'Work Flow','WorkFlowAction',NULL),
 (10,'Application','ApplicationAction',NULL),
 (11,'Services','ServiceRequestsAction',NULL),
 (12,'Lifecycle','LifecycleAction',NULL),
 (13,'Monitoring Dashboard','MonitoringDashboard',NULL),
 (14,'Search Roles','Roles',NULL),
 (15,'Access Management','AccessMgmtAction',NULL),
 (16,'Add User','AddUserMgmtAction',NULL),
 (17,'Search User','UserMgmtAction',NULL),
 (18,'System Configuration','NolioProcessAction',NULL),
 (19,'Search Services','ServicesAction',NULL),
 (20,'Search Business Unit','BusinessUnitSearchAction',NULL),
 (21,'Project','ProjectSearchAction',NULL),
 (22,'CA Release Activity','CAReleaseActivity',NULL),
 (23,'Edit User','UserMgmtActionEdit',NULL);
INSERT INTO `screens` (`ID`,`NAME`,`ACTION_STR`,`ADMIN_ACCESS`) VALUES 
 (24,'Monitoring Threshold','MonitoringThreshold',NULL),
 (25,'Add Services','ServicesActionAdd',NULL),
 (26,'Edit Services','ServicesActionEdit',NULL),
 (27,'Add Business Unit','BusinessUnitSearchActionAdd','Y'),
 (28,'Edit Business Unit','BusinessUnitSearchActionEdit','Y'),
 (31,'Add Role','RoleSearchActionAdd',NULL),
 (32,'Search Role','RoleSearchAction',NULL),
 (33,'Edit Role','RoleSearchActionEdit',NULL),
 (34,'User Bulk Upload','UserBulkUploadAction',NULL),
 (35,'VMWare BareMetal Template','VMWareBareMetalActionLand',NULL),
 (36,'AWS','AWSAction',NULL),
 (37,'Add CI Server','CIServer',NULL),
 (38,'Cloud','VMWareAction',NULL),
 (39,'Add Server','AddHardwareAction',NULL),
 (40,'Search Server','HardwareAction',NULL),
 (41,'Add Software','AddSoftwareAction',NULL),
 (42,'Search Software','SoftwareAction',NULL),
 (43,'Device Bulk Upload','DeviceBulkUploadAction',NULL),
 (44,'VMWare BareMetal Template','VMWareBareMetalAction',''),
 (45,'Add VMWare BareMetal Template','VM WareBareMetalActionAdd',NULL);
INSERT INTO `screens` (`ID`,`NAME`,`ACTION_STR`,`ADMIN_ACCESS`) VALUES 
 (46,'Edit VMWare BareMetal Template','VMWareBareMetalActionEdit',NULL),
 (47,'Edit Cloud','VMWareEditAction',NULL),
 (48,'Edit Server','HardwareActionEdit',NULL),
 (50,'Edit Software','SoftwareActionEdit',NULL),
 (52,'Add Environment','AddEnvironmentAction',NULL),
 (53,'Search Environment','EnvironmentAction',NULL),
 (54,'Inventory Management','ServerMaster',NULL),
 (55,'Edit Environment','EnvironmentActionEdit',NULL),
 (56,'Make Reservation','ReservationAction',NULL),
 (57,'Cancel Reservation','CancelReservationAction',NULL),
 (58,'Search Reservation','SearchReservationAction',NULL),
 (59,'Update Reservation','UpdateReservationAction',NULL),
 (60,'User Reports','ReportsViewerAction',NULL),
 (61,'CI Server','CIServerReportsViewerAction',NULL),
 (62,'Testing Reports','TestingReportsAction',NULL),
 (63,'Change Password','PasswordMgmtAction',NULL),
 (64,'Update Profile','UpdateProfileAction',NULL),
 (65,'Define WorkFlow','DefineWorkFlowAction',NULL),
 (66,'Work List','MyWorkFlowRequest',NULL);
INSERT INTO `screens` (`ID`,`NAME`,`ACTION_STR`,`ADMIN_ACCESS`) VALUES 
 (67,'Application Management','AddApplicationManagementAction',NULL),
 (68,'Search Application','ApplicationManagement',NULL),
 (69,'Search Application Profile','ApplicationProfileAction',NULL),
 (70,'Search Application Release','ApplicationReleaseAction',NULL),
 (71,'Multiple Application Profile','SubApplicationMgmntAction',NULL),
 (72,'User Group Management','UserGroupManagementAction',NULL),
 (73,'Application Life Cycle','ApplicationLifeCycleAction',NULL),
 (74,'Application Phases','ApplicationPhaseAction',NULL),
 (75,'Application Parameters','ApplicationParametersActionSearch',NULL),
 (76,'Sonar Review','SonarReviewAction',NULL),
 (77,'Edit Application','ApplicationManagementEdit',NULL),
 (78,'Add Application','AddApplication',NULL),
 (79,'Add Application Release ','ApplicationReleaseActionAdd',NULL),
 (80,'Edit Application Release','ApplicationReleaseActionEdit',NULL),
 (81,'Add Application Profile','ApplicationProfileActionAdd',NULL),
 (82,'Edit Application Profile','ApplicationProfileActionEdit',NULL);
INSERT INTO `screens` (`ID`,`NAME`,`ACTION_STR`,`ADMIN_ACCESS`) VALUES 
 (83,'Service Requests','SearchServiceRequestAction',NULL),
 (84,'Phase Management','PhaseManagementAction',NULL),
 (85,'Service Management','ServiceManagementAction',NULL),
 (86,'Url Monitoring','UrlAction',NULL),
 (87,'Monitoring','MonitoringAction',NULL),
 (88,'Add Environment','EnvironmentAddAction',NULL),
 (89,'AddEnvironment','AddEnvironmentAction',NULL),
 (90,'MakeReservation','ReservationAction',NULL),
 (91,'EditCARelease','CAReleaseEditAction',''),
 (92,'Email Notification','EmailNotificationAction',NULL),
 (93,'Puppet Process Activity','PuppetProcessActivity',''),
 (101,'Add Parameter','ParameterActionAdd',NULL),
 (102,'Edit Parameter','ParameterActionEdit',NULL),
 (103,'Search Parameter','ParameterAction',NULL),
 (105,'Add Software Manifest','AddSoftwareManifestAction',NULL),
 (106,'Search Software Manifest','SoftwareManifestAction',NULL),
 (107,'Udeploy Release Activity','UdeployReleaseActivity',NULL),
 (111,'Add Repository Configuration','RepositoryActionAdd',NULL);
INSERT INTO `screens` (`ID`,`NAME`,`ACTION_STR`,`ADMIN_ACCESS`) VALUES 
 (112,'Edit Repository Configuration','RepositoryActionEdit',NULL),
 (113,'Repository Configuration','RepositoryAction',NULL),
 (114,'Monitoring Docker','MonitoringDocker',NULL),
 (115,'ServiceNow Mapping','ServiceNowMapping',NULL),
 (116,'Issue Tracking','IssueTracking',NULL),
 (117,'JIRA Configuration','JiraConfig',NULL),
 (118,'Udeploy Release Activity','UdeployReleaseActivity',NULL),
 (119,'Puppet Release Activity','PuppetReleaseActivity',NULL),
 (135,'Search Release Planning','ReleasePlanningAction',NULL),
 (136,'Add Release Planning','ReleasePlanningActionAdd',NULL),
 (137,'Edit Release Planning','ReleasePlanningActionEdit',NULL),
 (138,'Service Now Configuration','ServiceNowConfiguration',NULL),
 (139,'ServiceNow Import','ServiceNowImport',NULL),
 (140,'Puppet Release Activity','PuppetReleaseActivity',NULL),
 (144,'Delegate Access','DelegateAccessAction',NULL),
 (145,'Revoke Access','RevokeAccessAction',NULL),
 (146,'Request List','ServicesRequestListAction',NULL);
INSERT INTO `screens` (`ID`,`NAME`,`ACTION_STR`,`ADMIN_ACCESS`) VALUES 
 (147,'Add Task','AddTaskAction',NULL),
 (148,'Edit Task','EditTaskAction',NULL),
 (149,'Search Task','SearchTaskAction',NULL);
/*!40000 ALTER TABLE `screens` ENABLE KEYS */;


--
-- Definition of table `script_parameters_mapping`
--

DROP TABLE IF EXISTS `script_parameters_mapping`;
CREATE TABLE `script_parameters_mapping` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `SCRIPT_ID` int(11) NOT NULL,
  `PARAMETER_NAME` varchar(45) NOT NULL,
  `PARAMETER_VALUE` varchar(45) DEFAULT NULL,
  `netra_parameter_name` varchar(100) DEFAULT NULL,
  `netra_parameter_mapping` varchar(2) DEFAULT 'N',
  `parameter_scope` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_script_parameters_mapping` (`SCRIPT_ID`),
  CONSTRAINT `FK_script_parameters_mapping` FOREIGN KEY (`SCRIPT_ID`) REFERENCES `script_task_mapping` (`Script_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `script_parameters_mapping`
--

/*!40000 ALTER TABLE `script_parameters_mapping` DISABLE KEYS */;
/*!40000 ALTER TABLE `script_parameters_mapping` ENABLE KEYS */;


--
-- Definition of table `script_task_mapping`
--

DROP TABLE IF EXISTS `script_task_mapping`;
CREATE TABLE `script_task_mapping` (
  `Script_Id` int(11) NOT NULL AUTO_INCREMENT,
  `taskId` int(11) unsigned NOT NULL,
  `UploadFlag` varchar(3) DEFAULT NULL,
  `File_Path` varchar(60) NOT NULL,
  `target_location` varchar(45) DEFAULT NULL,
  `files_Name` varchar(100) DEFAULT NULL,
  `upload_source` varchar(45) DEFAULT NULL,
  `repo_id` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`Script_Id`),
  KEY `FK_Script_task_mapping` (`taskId`),
  KEY `FK_Script_task_mapping_repo` (`repo_id`),
  CONSTRAINT `FK_Script_task_mapping` FOREIGN KEY (`taskId`) REFERENCES `tasks` (`ID`),
  CONSTRAINT `FK_Script_task_mapping_repo` FOREIGN KEY (`repo_id`) REFERENCES `repo_config` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `script_task_mapping`
--

/*!40000 ALTER TABLE `script_task_mapping` DISABLE KEYS */;
/*!40000 ALTER TABLE `script_task_mapping` ENABLE KEYS */;


--
-- Definition of table `security_answers`
--

DROP TABLE IF EXISTS `security_answers`;
CREATE TABLE `security_answers` (
  `answers_id` int(11) NOT NULL AUTO_INCREMENT,
  `question_id` int(11) NOT NULL,
  `answer_name` varchar(45) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`answers_id`),
  KEY `FK_security_answers_1` (`question_id`),
  CONSTRAINT `FK_security_answers_1` FOREIGN KEY (`question_id`) REFERENCES `security_questions` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `security_answers`
--

/*!40000 ALTER TABLE `security_answers` DISABLE KEYS */;
INSERT INTO `security_answers` (`answers_id`,`question_id`,`answer_name`,`user_id`) VALUES 
 (1,1,'a',2),
 (2,2,'a',2),
 (3,3,'a',2),
 (4,1,'a',3),
 (5,2,'a',3),
 (6,3,'a',3);
/*!40000 ALTER TABLE `security_answers` ENABLE KEYS */;


--
-- Definition of table `security_questions`
--

DROP TABLE IF EXISTS `security_questions`;
CREATE TABLE `security_questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `security_questions`
--

/*!40000 ALTER TABLE `security_questions` DISABLE KEYS */;
INSERT INTO `security_questions` (`id`,`name`) VALUES 
 (1,'What is your mother\'s maiden name?'),
 (2,'What is your pet\'s name?'),
 (3,'What was the name of your first school?');
/*!40000 ALTER TABLE `security_questions` ENABLE KEYS */;


--
-- Definition of table `server_template_property`
--

DROP TABLE IF EXISTS `server_template_property`;
CREATE TABLE `server_template_property` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `PROVISION_MACHINE_ID` int(10) unsigned NOT NULL,
  `PROPERTY_NAME` varchar(45) NOT NULL,
  `PROPERTY_VALUE` varchar(45) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `server_template_property`
--

/*!40000 ALTER TABLE `server_template_property` DISABLE KEYS */;
/*!40000 ALTER TABLE `server_template_property` ENABLE KEYS */;


--
-- Definition of table `service_jira_mapping`
--

DROP TABLE IF EXISTS `service_jira_mapping`;
CREATE TABLE `service_jira_mapping` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `jira_issue` varchar(45) DEFAULT NULL,
  `service_req_id` int(10) unsigned DEFAULT NULL,
  `deployment_flag` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `req_issue_fk` (`service_req_id`),
  CONSTRAINT `req_issue_fk` FOREIGN KEY (`service_req_id`) REFERENCES `service_request` (`Request_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `service_jira_mapping`
--

/*!40000 ALTER TABLE `service_jira_mapping` DISABLE KEYS */;
INSERT INTO `service_jira_mapping` (`id`,`jira_issue`,`service_req_id`,`deployment_flag`) VALUES 
 (1,'NET-961',28,'N');
/*!40000 ALTER TABLE `service_jira_mapping` ENABLE KEYS */;


--
-- Definition of table `service_mail_master`
--

DROP TABLE IF EXISTS `service_mail_master`;
CREATE TABLE `service_mail_master` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mail_messages` varchar(200) NOT NULL,
  `service_mail_id` int(10) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `service_mail_master`
--

/*!40000 ALTER TABLE `service_mail_master` DISABLE KEYS */;
INSERT INTO `service_mail_master` (`ID`,`mail_messages`,`service_mail_id`) VALUES 
 (1,'Hi,',1),
 (2,'NETRA',2),
 (3,'TCS Lucknow',3),
 (4,'India',4),
 (5,'Please find attached logs of the service.',5),
 (6,'Thanks',6),
 (7,'This is an auto generated mail, please do not reply.',7);
/*!40000 ALTER TABLE `service_mail_master` ENABLE KEYS */;


--
-- Definition of table `service_request`
--

DROP TABLE IF EXISTS `service_request`;
CREATE TABLE `service_request` (
  `Request_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Service_id` int(11) DEFAULT NULL,
  `Status_id` int(11) DEFAULT NULL,
  `Application_id` int(10) unsigned DEFAULT NULL,
  `Action_Flag` char(1) DEFAULT NULL,
  `Environment_id` int(10) unsigned DEFAULT NULL,
  `StartTime` datetime DEFAULT NULL,
  `EndTime` datetime DEFAULT NULL,
  `Application_Release_Id` int(10) unsigned DEFAULT NULL,
  `CREATED_BY` int(10) unsigned DEFAULT NULL,
  `CREATED_DATE` datetime DEFAULT NULL,
  `MODIFIED_BY` int(10) unsigned DEFAULT NULL,
  `MODIFIED_DATE` datetime DEFAULT NULL,
  `PromotedEnv_id` int(10) unsigned DEFAULT NULL,
  `Remarks` text,
  `CRON_EXPRESSION` varchar(45) DEFAULT NULL,
  `PIPELINE_REQ_FLAG` varchar(1) DEFAULT NULL,
  `PARENT_REQ_ID` int(10) unsigned DEFAULT NULL,
  `CHILD_REQ_EXEC_ORDER` int(10) unsigned DEFAULT NULL,
  `CHILD_WORKFLOW_FLAG` varchar(1) DEFAULT NULL,
  `is_Scheduled` char(2) DEFAULT 'N',
  `target_server_id` int(10) unsigned DEFAULT NULL,
  `tool_config_loc` varchar(1000) DEFAULT NULL,
  `testing_phase_id` int(10) unsigned DEFAULT NULL,
  `sel_port` int(10) unsigned DEFAULT NULL,
  `result_Location` varchar(1000) DEFAULT NULL,
  `script_copy_Location` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`Request_id`),
  KEY `applications_fk_idx` (`Application_id`),
  KEY `environment_fk_idx` (`Environment_id`),
  CONSTRAINT `FK_service_request_env` FOREIGN KEY (`Environment_id`) REFERENCES `environments` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `service_request`
--

/*!40000 ALTER TABLE `service_request` DISABLE KEYS */;
INSERT INTO `service_request` (`Request_id`,`Service_id`,`Status_id`,`Application_id`,`Action_Flag`,`Environment_id`,`StartTime`,`EndTime`,`Application_Release_Id`,`CREATED_BY`,`CREATED_DATE`,`MODIFIED_BY`,`MODIFIED_DATE`,`PromotedEnv_id`,`Remarks`,`CRON_EXPRESSION`,`PIPELINE_REQ_FLAG`,`PARENT_REQ_ID`,`CHILD_REQ_EXEC_ORDER`,`CHILD_WORKFLOW_FLAG`,`is_Scheduled`,`target_server_id`,`tool_config_loc`,`testing_phase_id`,`sel_port`,`result_Location`,`script_copy_Location`) VALUES 
 (1,1,143,NULL,'E',1,'2016-07-05 00:00:00','2016-07-31 23:59:59',NULL,3,'2016-07-04 00:00:00',NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'N',NULL,NULL,NULL,NULL,NULL,NULL),
 (2,1,143,NULL,'E',2,'2016-07-05 00:00:00','2016-07-14 23:59:59',NULL,3,'2016-07-04 00:00:00',NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'N',NULL,NULL,NULL,NULL,NULL,NULL),
 (3,1,143,NULL,'E',3,'2016-07-04 00:00:00','2016-07-26 23:59:59',NULL,3,'2016-07-04 00:00:00',NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'N',NULL,NULL,NULL,NULL,NULL,NULL),
 (4,1,143,NULL,'E',4,'2016-07-05 00:00:00','2016-07-20 23:59:59',NULL,3,'2016-07-04 00:00:00',NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'N',NULL,NULL,NULL,NULL,NULL,NULL),
 (5,13,143,1,'C',3,NULL,NULL,NULL,3,'2016-07-05 00:00:00',0,NULL,NULL,NULL,'',NULL,0,0,NULL,'N',0,NULL,0,0,NULL,NULL);
INSERT INTO `service_request` (`Request_id`,`Service_id`,`Status_id`,`Application_id`,`Action_Flag`,`Environment_id`,`StartTime`,`EndTime`,`Application_Release_Id`,`CREATED_BY`,`CREATED_DATE`,`MODIFIED_BY`,`MODIFIED_DATE`,`PromotedEnv_id`,`Remarks`,`CRON_EXPRESSION`,`PIPELINE_REQ_FLAG`,`PARENT_REQ_ID`,`CHILD_REQ_EXEC_ORDER`,`CHILD_WORKFLOW_FLAG`,`is_Scheduled`,`target_server_id`,`tool_config_loc`,`testing_phase_id`,`sel_port`,`result_Location`,`script_copy_Location`) VALUES 
 (6,16,143,1,'E',3,NULL,NULL,NULL,3,'2016-07-05 00:00:00',NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'N',NULL,NULL,NULL,NULL,NULL,NULL),
 (7,1,143,NULL,'E',5,'2016-07-06 00:00:00','2016-07-28 23:59:59',NULL,3,'2016-07-05 00:00:00',NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'N',NULL,NULL,NULL,NULL,NULL,NULL),
 (8,1,143,NULL,'E',6,'2016-07-06 00:00:00','2016-07-19 23:59:59',NULL,3,'2016-07-05 00:00:00',NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'N',NULL,NULL,NULL,NULL,NULL,NULL),
 (9,1,143,NULL,'E',7,'2016-07-08 00:00:00','2016-07-25 23:59:59',NULL,3,'2016-07-07 00:00:00',NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'N',NULL,NULL,NULL,NULL,NULL,NULL),
 (10,1,143,NULL,'E',8,'2016-07-07 00:00:00','2016-07-13 23:59:59',NULL,3,'2016-07-07 00:00:00',NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'N',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `service_request` (`Request_id`,`Service_id`,`Status_id`,`Application_id`,`Action_Flag`,`Environment_id`,`StartTime`,`EndTime`,`Application_Release_Id`,`CREATED_BY`,`CREATED_DATE`,`MODIFIED_BY`,`MODIFIED_DATE`,`PromotedEnv_id`,`Remarks`,`CRON_EXPRESSION`,`PIPELINE_REQ_FLAG`,`PARENT_REQ_ID`,`CHILD_REQ_EXEC_ORDER`,`CHILD_WORKFLOW_FLAG`,`is_Scheduled`,`target_server_id`,`tool_config_loc`,`testing_phase_id`,`sel_port`,`result_Location`,`script_copy_Location`) VALUES 
 (11,13,143,1,'C',8,NULL,NULL,NULL,3,'2016-07-07 00:00:00',0,NULL,NULL,NULL,'',NULL,0,0,NULL,'N',0,NULL,0,0,NULL,NULL),
 (12,13,143,1,'E',8,NULL,NULL,NULL,3,'2016-07-07 00:00:00',0,NULL,NULL,NULL,'',NULL,0,0,NULL,'N',0,NULL,0,0,NULL,NULL),
 (13,16,143,1,'C',8,NULL,NULL,NULL,3,'2016-07-07 00:00:00',NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'N',NULL,NULL,NULL,NULL,NULL,NULL),
 (14,16,143,1,'C',8,NULL,NULL,NULL,3,'2016-07-07 00:00:00',NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'N',NULL,NULL,NULL,NULL,NULL,NULL),
 (15,15,143,1,'E',NULL,NULL,NULL,1,3,'2016-07-07 00:00:00',NULL,NULL,NULL,'','',NULL,0,0,NULL,'N',0,NULL,1,0,NULL,NULL),
 (16,5,143,1,'E',8,NULL,NULL,NULL,3,'2016-07-07 00:00:00',NULL,'2016-07-07 00:00:00',NULL,'','',NULL,NULL,NULL,NULL,'N',NULL,NULL,1,NULL,NULL,NULL);
INSERT INTO `service_request` (`Request_id`,`Service_id`,`Status_id`,`Application_id`,`Action_Flag`,`Environment_id`,`StartTime`,`EndTime`,`Application_Release_Id`,`CREATED_BY`,`CREATED_DATE`,`MODIFIED_BY`,`MODIFIED_DATE`,`PromotedEnv_id`,`Remarks`,`CRON_EXPRESSION`,`PIPELINE_REQ_FLAG`,`PARENT_REQ_ID`,`CHILD_REQ_EXEC_ORDER`,`CHILD_WORKFLOW_FLAG`,`is_Scheduled`,`target_server_id`,`tool_config_loc`,`testing_phase_id`,`sel_port`,`result_Location`,`script_copy_Location`) VALUES 
 (17,20,143,1,'E',2,NULL,NULL,1,3,'2016-07-07 00:00:00',NULL,'2016-07-07 00:00:00',NULL,'qwdfg','',NULL,NULL,NULL,NULL,'N',NULL,NULL,1,NULL,NULL,NULL),
 (18,20,143,1,'C',8,NULL,NULL,1,3,'2016-07-07 00:00:00',NULL,'2016-07-07 00:00:00',NULL,'wqefgb','',NULL,NULL,NULL,NULL,'N',NULL,NULL,1,NULL,NULL,NULL),
 (19,2,143,1,'E',8,NULL,NULL,1,3,'2016-07-07 00:00:00',NULL,'2016-07-07 00:00:00',NULL,'',NULL,NULL,NULL,NULL,NULL,'N',NULL,NULL,2,NULL,NULL,NULL),
 (20,6,143,1,'E',8,NULL,NULL,1,3,'2016-07-07 20:15:40',NULL,'2016-07-07 20:15:40',NULL,'',NULL,NULL,NULL,NULL,NULL,'N',NULL,NULL,1,NULL,NULL,NULL),
 (21,1,143,NULL,'E',9,'2016-07-11 00:00:00','2016-07-31 23:59:59',NULL,3,'2016-07-11 00:00:00',NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'N',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `service_request` (`Request_id`,`Service_id`,`Status_id`,`Application_id`,`Action_Flag`,`Environment_id`,`StartTime`,`EndTime`,`Application_Release_Id`,`CREATED_BY`,`CREATED_DATE`,`MODIFIED_BY`,`MODIFIED_DATE`,`PromotedEnv_id`,`Remarks`,`CRON_EXPRESSION`,`PIPELINE_REQ_FLAG`,`PARENT_REQ_ID`,`CHILD_REQ_EXEC_ORDER`,`CHILD_WORKFLOW_FLAG`,`is_Scheduled`,`target_server_id`,`tool_config_loc`,`testing_phase_id`,`sel_port`,`result_Location`,`script_copy_Location`) VALUES 
 (22,1,143,NULL,'E',10,'2016-07-11 00:00:00','2016-07-20 23:59:59',NULL,3,'2016-07-11 00:00:00',NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'N',NULL,NULL,NULL,NULL,NULL,NULL),
 (23,16,143,1,'E',9,NULL,NULL,NULL,3,'2016-07-11 00:00:00',NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'N',NULL,NULL,NULL,NULL,NULL,NULL),
 (24,16,143,1,'C',10,NULL,NULL,NULL,3,'2016-07-11 00:00:00',NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'N',NULL,NULL,NULL,NULL,NULL,NULL),
 (25,19,143,1,'E',NULL,NULL,NULL,1,3,'2016-07-11 00:00:00',NULL,NULL,NULL,NULL,'',NULL,0,0,NULL,'N',0,NULL,0,0,NULL,NULL),
 (26,15,143,1,'C',NULL,NULL,NULL,1,3,'2016-07-11 00:00:00',NULL,NULL,NULL,'','',NULL,0,0,NULL,'N',0,NULL,3,0,NULL,NULL);
INSERT INTO `service_request` (`Request_id`,`Service_id`,`Status_id`,`Application_id`,`Action_Flag`,`Environment_id`,`StartTime`,`EndTime`,`Application_Release_Id`,`CREATED_BY`,`CREATED_DATE`,`MODIFIED_BY`,`MODIFIED_DATE`,`PromotedEnv_id`,`Remarks`,`CRON_EXPRESSION`,`PIPELINE_REQ_FLAG`,`PARENT_REQ_ID`,`CHILD_REQ_EXEC_ORDER`,`CHILD_WORKFLOW_FLAG`,`is_Scheduled`,`target_server_id`,`tool_config_loc`,`testing_phase_id`,`sel_port`,`result_Location`,`script_copy_Location`) VALUES 
 (27,1,143,NULL,'E',11,'2016-07-11 00:00:00','2016-07-27 23:59:59',NULL,3,'2016-07-11 00:00:00',NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'N',NULL,NULL,NULL,NULL,NULL,NULL),
 (28,15,143,1,'C',NULL,NULL,NULL,1,3,'2016-07-12 00:00:00',NULL,NULL,NULL,'','',NULL,0,0,NULL,'N',0,NULL,3,0,NULL,NULL),
 (29,16,143,1,'E',9,NULL,NULL,NULL,3,'2016-07-12 00:00:00',NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'N',NULL,NULL,NULL,NULL,NULL,NULL),
 (30,1,143,NULL,'E',12,'2016-07-12 00:00:00','2016-07-21 23:59:59',NULL,3,'2016-07-12 00:00:00',NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'N',NULL,NULL,NULL,NULL,NULL,NULL),
 (31,1,143,NULL,'E',13,'2016-07-13 00:00:00','2016-07-27 23:59:59',NULL,3,'2016-07-13 00:00:00',NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'N',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `service_request` (`Request_id`,`Service_id`,`Status_id`,`Application_id`,`Action_Flag`,`Environment_id`,`StartTime`,`EndTime`,`Application_Release_Id`,`CREATED_BY`,`CREATED_DATE`,`MODIFIED_BY`,`MODIFIED_DATE`,`PromotedEnv_id`,`Remarks`,`CRON_EXPRESSION`,`PIPELINE_REQ_FLAG`,`PARENT_REQ_ID`,`CHILD_REQ_EXEC_ORDER`,`CHILD_WORKFLOW_FLAG`,`is_Scheduled`,`target_server_id`,`tool_config_loc`,`testing_phase_id`,`sel_port`,`result_Location`,`script_copy_Location`) VALUES 
 (32,1,143,NULL,'E',14,'2016-07-13 00:00:00','2016-07-21 23:59:59',NULL,3,'2016-07-13 00:00:00',NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'N',NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `service_request` ENABLE KEYS */;


--
-- Definition of table `service_request_details`
--

DROP TABLE IF EXISTS `service_request_details`;
CREATE TABLE `service_request_details` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `PROFILE_ID` int(10) unsigned DEFAULT NULL,
  `ENVIRONMENT_ID` int(10) unsigned DEFAULT NULL,
  `RELEASE_ID` int(10) unsigned DEFAULT NULL,
  `REQUEST_ID` int(10) unsigned DEFAULT NULL,
  `ENVRNMNT_DTLS_ID` int(10) unsigned DEFAULT NULL,
  `AGNT_TYP` varchar(45) DEFAULT NULL,
  `PROVISIONED_MACHINE_ID` int(15) DEFAULT NULL,
  `SOFTWARE_REQUESTED` int(11) DEFAULT NULL,
  `Transform_map_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1 ROW_FORMAT=FIXED;

--
-- Dumping data for table `service_request_details`
--

/*!40000 ALTER TABLE `service_request_details` DISABLE KEYS */;
INSERT INTO `service_request_details` (`ID`,`PROFILE_ID`,`ENVIRONMENT_ID`,`RELEASE_ID`,`REQUEST_ID`,`ENVRNMNT_DTLS_ID`,`AGNT_TYP`,`PROVISIONED_MACHINE_ID`,`SOFTWARE_REQUESTED`,`Transform_map_id`) VALUES 
 (1,NULL,NULL,NULL,5,NULL,'CA',3,NULL,NULL),
 (2,2,3,NULL,6,5,NULL,NULL,2,NULL),
 (3,2,3,NULL,6,6,NULL,NULL,1,NULL),
 (4,NULL,NULL,NULL,11,NULL,'CA',8,NULL,NULL),
 (5,NULL,NULL,NULL,12,NULL,'ZA',8,NULL,NULL),
 (6,1,8,NULL,13,15,NULL,NULL,1,NULL),
 (7,1,8,NULL,13,16,NULL,NULL,2,NULL),
 (8,1,8,NULL,14,15,NULL,NULL,1,NULL),
 (9,1,8,NULL,14,16,NULL,NULL,2,NULL),
 (10,4,9,NULL,23,17,NULL,NULL,2,NULL),
 (11,4,9,NULL,23,18,NULL,NULL,1,NULL),
 (12,4,10,NULL,24,19,NULL,NULL,1,NULL),
 (13,4,10,NULL,24,20,NULL,NULL,2,NULL),
 (14,4,9,NULL,29,17,NULL,NULL,2,NULL),
 (15,4,9,NULL,29,18,NULL,NULL,1,NULL);
/*!40000 ALTER TABLE `service_request_details` ENABLE KEYS */;


--
-- Definition of table `service_request_history`
--

DROP TABLE IF EXISTS `service_request_history`;
CREATE TABLE `service_request_history` (
  `Id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Request_id` int(10) unsigned NOT NULL,
  `Comments` varchar(1000) DEFAULT NULL,
  `Created_Date` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=440 DEFAULT CHARSET=latin1 ROW_FORMAT=FIXED;

--
-- Dumping data for table `service_request_history`
--

/*!40000 ALTER TABLE `service_request_history` DISABLE KEYS */;
INSERT INTO `service_request_history` (`Id`,`Request_id`,`Comments`,`Created_Date`) VALUES 
 (1,1,'Scheduling request.','2016-07-04 16:56:27'),
 (2,1,'Initiating request','2016-07-04 16:56:27'),
 (3,1,'Starting environment creation, this might take some time','2016-07-04 16:56:29'),
 (4,1,'Failure -: Virtual Machine cannot be cloned due to -The name \'VM1_1_EV_1\' already exists.','2016-07-04 16:56:39'),
 (5,1,'Environment creation failed','2016-07-04 16:56:39'),
 (6,2,'Scheduling request.','2016-07-04 16:59:40'),
 (7,2,'Initiating request','2016-07-04 16:59:40'),
 (8,2,'Starting environment creation, this might take some time','2016-07-04 16:59:42'),
 (9,2,'Virtual Machine got cloned successfully. VM details: VirtualMachine IP Address- 10.130.25.174,VirtualMachine Host name-TEMSVMI221','2016-07-04 17:07:43'),
 (10,2,'Machine with IP 10.130.25.174 is not reachable','2016-07-04 17:07:53'),
 (11,2,'Environment creation failed','2016-07-04 17:07:53'),
 (12,3,'Scheduling request.','2016-07-04 17:21:15'),
 (13,3,'Initiating request','2016-07-04 17:21:15');
INSERT INTO `service_request_history` (`Id`,`Request_id`,`Comments`,`Created_Date`) VALUES 
 (14,3,'Starting environment creation, this might take some time','2016-07-04 17:21:17'),
 (15,3,'Machine with IP 10.130.25.174 is not reachable','2016-07-04 17:21:27'),
 (16,3,'Environment creation failed','2016-07-04 17:21:27'),
 (17,4,'Scheduling request.','2016-07-04 18:01:24'),
 (18,4,'Initiating request','2016-07-04 18:01:24'),
 (19,4,'Starting environment creation, this might take some time','2016-07-04 18:01:25'),
 (20,4,'Failure -: Virtual Machine cannot be cloned due to -Insufficient disk space on datastore \'TEMS-3 DS\'.','2016-07-04 18:01:32'),
 (21,4,'Environment creation failed','2016-07-04 18:01:32'),
 (22,5,'Scheduling request.','2016-07-05 12:17:20'),
 (23,5,'Initiating request','2016-07-05 12:17:20'),
 (24,5,'Checking Java version installed on machine','2016-07-05 12:17:22'),
 (25,5,'Java installed on machine','2016-07-05 12:18:46'),
 (26,5,'CA Lisa Agent Installation code started for machine: 10.130.25.231','2016-07-05 12:18:46'),
 (27,5,'CA RELEASE AUTOMATION agent already installed.','2016-07-05 12:19:08');
INSERT INTO `service_request_history` (`Id`,`Request_id`,`Comments`,`Created_Date`) VALUES 
 (28,5,'CA Lisa Agent Installation code completed .... ','2016-07-05 12:19:08'),
 (29,6,'Scheduling request.','2016-07-05 12:21:51'),
 (30,6,'Initiating request','2016-07-05 12:21:51'),
 (31,6,'Software Installation started','2016-07-05 12:21:53'),
 (32,6,'Calling CA RELEASE AUTOMATION web service to run process JBoss/Install JBoss Linux-cpy with processID 36','2016-07-05 12:21:53'),
 (33,6,'successfully mapped the agent:: 10.130.25.231 with server and mappingId is:: 0','2016-07-05 12:21:54'),
 (34,6,'CA RELEASE AUTOMATION JBoss/Install JBoss Linux-cpy Process Started:: Process started with jobId:: 197346','2016-07-05 12:21:56'),
 (35,6,'CA RELEASE AUTOMATION JBoss/Install JBoss Linux-cpy Process State::Current state of the job: 197346 is FLOW_FAILED_PAUSED','2016-07-05 12:22:56'),
 (36,6,'CA RELEASE AUTOMATION JBoss/Install JBoss Linux-cpy Failed Process:: Process FAILED with jobId:: 197346','2016-07-05 12:22:56'),
 (37,6,'CA RELEASE AUTOMATION Error:: Error in jobId:: 197346 is :Server localhost(10.130.25.231) has failed step Create chmod SH.','2016-07-05 12:22:56');
INSERT INTO `service_request_history` (`Id`,`Request_id`,`Comments`,`Created_Date`) VALUES 
 (38,6,'CA RELEASE AUTOMATION JBoss/Install JBoss Linux-cpy Process Force STOP:: Stopping failed Process with jobId:: 197346','2016-07-05 12:22:56'),
 (39,6,'Software Installation failed for Mapped Software:: JBoss','2016-07-05 12:22:56'),
 (40,6,'There are no config files to be moved','2016-07-05 12:22:56'),
 (41,6,'Calling CA RELEASE AUTOMATION web service to run process Oracle/Install Oracle Linux with processID 15','2016-07-05 12:22:56'),
 (42,6,'successfully mapped the agent:: 10.130.25.231 with server and mappingId is:: 0','2016-07-05 12:22:57'),
 (43,6,'CA RELEASE AUTOMATION Oracle/Install Oracle Linux Process Started:: Process started with jobId:: 197347','2016-07-05 12:22:58'),
 (44,6,'CA RELEASE AUTOMATION Oracle/Install Oracle Linux Process State::Current state of the job: 197347 is INIT','2016-07-05 12:23:58'),
 (45,6,'CA RELEASE AUTOMATION Oracle/Install Oracle Linux Process State::Current state of the job: 197347 is FLOW_FAILED_PAUSED','2016-07-05 12:24:58'),
 (46,6,'CA RELEASE AUTOMATION Oracle/Install Oracle Linux Failed Process:: Process FAILED with jobId:: 197347','2016-07-05 12:24:58');
INSERT INTO `service_request_history` (`Id`,`Request_id`,`Comments`,`Created_Date`) VALUES 
 (47,6,'CA RELEASE AUTOMATION Error:: Error in jobId:: 197347 is :Server localhost(10.130.25.231) has failed step Create User.','2016-07-05 12:24:58'),
 (48,6,'CA RELEASE AUTOMATION Oracle/Install Oracle Linux Process Force STOP:: Stopping failed Process with jobId:: 197347','2016-07-05 12:24:58'),
 (49,6,'Software Installation failed for Mapped Software:: Oracle','2016-07-05 12:24:58'),
 (50,6,'There are no config files to be moved','2016-07-05 12:24:58'),
 (51,6,'Software Installation Unsuccessful','2016-07-05 12:24:58'),
 (52,7,'Scheduling request.','2016-07-05 13:22:55'),
 (53,7,'Initiating request','2016-07-05 13:22:55'),
 (54,7,'Starting environment creation, this might take some time','2016-07-05 13:22:56'),
 (55,7,'Virtual Machine got cloned successfully. VM details: VirtualMachine IP Address- 10.130.25.197,VirtualMachine Host name-TEMSVMI751','2016-07-05 13:31:02'),
 (56,7,'Machine with IP 10.130.25.197 is not reachable','2016-07-05 13:31:12'),
 (57,7,'Environment creation failed','2016-07-05 13:31:12');
INSERT INTO `service_request_history` (`Id`,`Request_id`,`Comments`,`Created_Date`) VALUES 
 (58,8,'Scheduling request.','2016-07-05 14:23:20'),
 (59,8,'Initiating request','2016-07-05 14:23:20'),
 (60,8,'Starting environment creation, this might take some time','2016-07-05 14:23:21'),
 (61,8,'Machine with IP 10.130.25.197 is not reachable','2016-07-05 14:23:32'),
 (62,8,'Environment creation failed','2016-07-05 14:23:32'),
 (63,9,'Scheduling request.','2016-07-07 16:43:40'),
 (64,9,'Initiating request','2016-07-07 16:43:41'),
 (65,9,'Starting environment creation, this might take some time','2016-07-07 16:43:42'),
 (66,9,'Virtual Machine got cloned successfully. VM details: VirtualMachine IP Address- 10.130.25.181,VirtualMachine Host name-TEMSVMI971','2016-07-07 16:52:23'),
 (67,9,'Machine with IP 10.130.25.181 is not reachable','2016-07-07 16:52:33'),
 (68,9,'Environment creation failed','2016-07-07 16:52:33'),
 (69,10,'Scheduling request.','2016-07-07 17:41:18'),
 (70,10,'Initiating request','2016-07-07 17:41:19'),
 (71,10,'Starting environment creation, this might take some time','2016-07-07 17:41:20');
INSERT INTO `service_request_history` (`Id`,`Request_id`,`Comments`,`Created_Date`) VALUES 
 (72,10,'Virtual Machine got cloned successfully. VM details: VirtualMachine IP Address- 10.130.25.220,VirtualMachine Host name-TEMSVMI1081','2016-07-07 17:49:30'),
 (73,10,'Machine with IP 10.130.25.220 is not reachable','2016-07-07 17:49:40'),
 (74,10,'Environment creation failed','2016-07-07 17:49:40'),
 (75,11,'Scheduling request.','2016-07-07 18:06:19'),
 (76,11,'Initiating request','2016-07-07 18:06:20'),
 (77,11,'Checking Java version installed on machine','2016-07-07 18:06:22'),
 (78,11,'Java installed on machine','2016-07-07 18:07:48'),
 (79,11,'CA Lisa Agent Installation code started for machine: 10.130.25.220','2016-07-07 18:07:48'),
 (80,11,'CA RELEASE AUTOMATION agent installed successfully.','2016-07-07 18:10:16'),
 (81,11,'CA Lisa Agent Installation code completed .... ','2016-07-07 18:11:16'),
 (82,12,'Scheduling request.','2016-07-07 18:14:52'),
 (83,12,'Initiating request','2016-07-07 18:14:52'),
 (84,12,'Zabbix Agent Installation code started for machine : 10.130.25.220','2016-07-07 18:14:54');
INSERT INTO `service_request_history` (`Id`,`Request_id`,`Comments`,`Created_Date`) VALUES 
 (85,12,'Checking Java version installed on machine','2016-07-07 18:14:54'),
 (86,12,'Java installed on machine','2016-07-07 18:16:15'),
 (87,12,'Monitoring agent installation started','2016-07-07 18:16:15'),
 (88,12,'Copying monitoring agent files','2016-07-07 18:16:15'),
 (89,12,'Deployment failed due to:: null','2016-07-07 18:16:15'),
 (90,13,'Scheduling request.','2016-07-07 18:25:27'),
 (91,13,'Initiating request','2016-07-07 18:25:27'),
 (92,13,'Software Installation started','2016-07-07 18:25:28'),
 (93,13,'Calling CA RELEASE AUTOMATION web service to run process Oracle/Install Oracle Linux with processID 15','2016-07-07 18:25:28'),
 (94,13,'successfully mapped the agent:: 10.130.25.220 with server and mappingId is:: 0','2016-07-07 18:25:29'),
 (95,13,'CA RELEASE AUTOMATION Oracle/Install Oracle Linux Process Started:: Process started with jobId:: 197406','2016-07-07 18:25:30'),
 (96,13,'CA RELEASE AUTOMATION Oracle/Install Oracle Linux Process State::Current state of the job: 197406 is INIT','2016-07-07 18:26:30'),
 (97,13,'CA RELEASE AUTOMATION Oracle/Install Oracle Linux Process State::Current state of the job: 197406 is INIT','2016-07-07 18:27:30');
INSERT INTO `service_request_history` (`Id`,`Request_id`,`Comments`,`Created_Date`) VALUES 
 (98,13,'CA RELEASE AUTOMATION Oracle/Install Oracle Linux Process State::Current state of the job: 197406 is FLOW_IN_PROGRESS','2016-07-07 18:28:30'),
 (99,13,'CA RELEASE AUTOMATION Oracle/Install Oracle Linux Process State::Current state of the job: 197406 is FLOW_IN_PROGRESS','2016-07-07 18:29:30'),
 (100,13,'CA RELEASE AUTOMATION Oracle/Install Oracle Linux Process State::Current state of the job: 197406 is FLOW_IN_PROGRESS','2016-07-07 18:30:30'),
 (101,13,'CA RELEASE AUTOMATION Oracle/Install Oracle Linux Process State::Current state of the job: 197406 is FLOW_FINISHED','2016-07-07 18:31:30'),
 (102,13,'CA RELEASE AUTOMATION Oracle/Install Oracle Linux Process Finished::Job finished with jobId:197406','2016-07-07 18:31:30'),
 (103,13,'Software Installation successful for Mapped Software:: Oracle','2016-07-07 18:31:30'),
 (104,13,'There are no config files to be moved','2016-07-07 18:31:30'),
 (105,13,'Software Installation successful','2016-07-07 18:31:30');
INSERT INTO `service_request_history` (`Id`,`Request_id`,`Comments`,`Created_Date`) VALUES 
 (106,14,'Scheduling request.','2016-07-07 18:33:17'),
 (107,14,'Initiating request','2016-07-07 18:33:17'),
 (108,14,'Software Installation started','2016-07-07 18:33:19'),
 (109,14,'Calling CA RELEASE AUTOMATION web service to run process JBoss/Install JBoss Linux-cpy with processID 36','2016-07-07 18:33:19'),
 (110,14,'successfully mapped the agent:: 10.130.25.220 with server and mappingId is:: 0','2016-07-07 18:33:20'),
 (111,14,'CA RELEASE AUTOMATION JBoss/Install JBoss Linux-cpy Process Started:: Process started with jobId:: 197407','2016-07-07 18:33:21'),
 (112,14,'CA RELEASE AUTOMATION JBoss/Install JBoss Linux-cpy Process State::Current state of the job: 197407 is FLOW_IN_PROGRESS','2016-07-07 18:34:21'),
 (113,14,'CA RELEASE AUTOMATION JBoss/Install JBoss Linux-cpy Process State::Current state of the job: 197407 is FLOW_IN_PROGRESS','2016-07-07 18:35:21'),
 (114,14,'CA RELEASE AUTOMATION JBoss/Install JBoss Linux-cpy Process State::Current state of the job: 197407 is FLOW_IN_PROGRESS','2016-07-07 18:36:21'),
 (115,14,'CA RELEASE AUTOMATION JBoss/Install JBoss Linux-cpy Process State::Current state of the job: 197407 is FLOW_IN_PROGRESS','2016-07-07 18:37:21');
INSERT INTO `service_request_history` (`Id`,`Request_id`,`Comments`,`Created_Date`) VALUES 
 (116,14,'CA RELEASE AUTOMATION JBoss/Install JBoss Linux-cpy Process State::Current state of the job: 197407 is FLOW_FINISHED','2016-07-07 18:38:21'),
 (117,14,'CA RELEASE AUTOMATION JBoss/Install JBoss Linux-cpy Process Finished::Job finished with jobId:197407','2016-07-07 18:38:21'),
 (118,14,'Software Installation successful for Mapped Software:: JBoss','2016-07-07 18:38:21'),
 (119,14,'There are no config files to be moved','2016-07-07 18:38:21'),
 (120,14,'Software Installation successful','2016-07-07 18:38:21'),
 (121,15,'Scheduling request.','2016-07-07 18:39:15'),
 (122,15,'Initiating request','2016-07-07 18:39:15'),
 (123,15,'JobId of next build is:: 29','2016-07-07 18:40:20'),
 (124,15,'No valid build details available. Build service Unsuccessful','2016-07-07 18:41:20'),
 (125,16,'Scheduling request.','2016-07-07 18:51:20'),
 (126,16,'Initiating request','2016-07-07 18:51:20'),
 (127,16,'Build process started for application::App_J','2016-07-07 18:51:22'),
 (128,16,'JobId of next build is:: 30','2016-07-07 18:52:22');
INSERT INTO `service_request_history` (`Id`,`Request_id`,`Comments`,`Created_Date`) VALUES 
 (129,16,'Jenkins build in progress:: 60% build completed.','2016-07-07 18:53:22'),
 (130,16,'Jenkins build in progress:: 92% build completed.','2016-07-07 18:54:22'),
 (131,16,'Jenkins build in progress:: 99% build completed.','2016-07-07 18:55:22'),
 (132,16,'Jenkins build for jobId::30 is SUCCESS','2016-07-07 18:56:22'),
 (133,16,'Build process for application completed ','2016-07-07 18:56:22'),
 (134,16,'Initiating Deployment ','2016-07-07 18:56:22'),
 (135,16,'There are no config files to be moved','2016-07-07 18:56:23'),
 (136,16,'Calling CA RELEASE AUTOMATION web service to run process JBoss/Deploy_EAR_Linux_Nexus with processID 42','2016-07-07 18:56:23'),
 (137,16,'successfully mapped the agent:: 10.130.25.220 with server and mappingId is:: 0','2016-07-07 18:56:23'),
 (138,16,'CA RELEASE AUTOMATION JBoss/Deploy_EAR_Linux_Nexus Process Started:: Process started with jobId:: 197409','2016-07-07 18:56:24'),
 (139,16,'CA RELEASE AUTOMATION JBoss/Deploy_EAR_Linux_Nexus Process State::Current state of the job: 197409 is FLOW_IN_PROGRESS','2016-07-07 18:57:24');
INSERT INTO `service_request_history` (`Id`,`Request_id`,`Comments`,`Created_Date`) VALUES 
 (140,16,'CA RELEASE AUTOMATION JBoss/Deploy_EAR_Linux_Nexus Process State::Current state of the job: 197409 is FLOW_IN_PROGRESS','2016-07-07 18:58:24'),
 (141,16,'CA RELEASE AUTOMATION JBoss/Deploy_EAR_Linux_Nexus Process State::Current state of the job: 197409 is FLOW_IN_PROGRESS','2016-07-07 18:59:24'),
 (142,16,'CA RELEASE AUTOMATION JBoss/Deploy_EAR_Linux_Nexus Process State::Current state of the job: 197409 is FLOW_IN_PROGRESS','2016-07-07 19:00:24'),
 (143,16,'CA RELEASE AUTOMATION JBoss/Deploy_EAR_Linux_Nexus Process State::Current state of the job: 197409 is FLOW_IN_PROGRESS','2016-07-07 19:01:24'),
 (144,16,'CA RELEASE AUTOMATION JBoss/Deploy_EAR_Linux_Nexus Process State::Current state of the job: 197409 is FLOW_IN_PROGRESS','2016-07-07 19:02:24'),
 (145,16,'CA RELEASE AUTOMATION JBoss/Deploy_EAR_Linux_Nexus Process State::Current state of the job: 197409 is FLOW_IN_PROGRESS','2016-07-07 19:03:24'),
 (146,16,'CA RELEASE AUTOMATION JBoss/Deploy_EAR_Linux_Nexus Process State::Current state of the job: 197409 is FLOW_IN_PROGRESS','2016-07-07 19:04:24');
INSERT INTO `service_request_history` (`Id`,`Request_id`,`Comments`,`Created_Date`) VALUES 
 (147,16,'CA RELEASE AUTOMATION JBoss/Deploy_EAR_Linux_Nexus Process State::Current state of the job: 197409 is FLOW_IN_PROGRESS','2016-07-07 19:05:25'),
 (148,16,'CA RELEASE AUTOMATION JBoss/Deploy_EAR_Linux_Nexus Process State::Current state of the job: 197409 is FLOW_IN_PROGRESS','2016-07-07 19:06:25'),
 (149,16,'CA RELEASE AUTOMATION JBoss/Deploy_EAR_Linux_Nexus Process State::Current state of the job: 197409 is FLOW_IN_PROGRESS','2016-07-07 19:07:25'),
 (150,16,'CA RELEASE AUTOMATION JBoss/Deploy_EAR_Linux_Nexus Process State::Current state of the job: 197409 is FLOW_IN_PROGRESS','2016-07-07 19:08:25'),
 (151,16,'CA RELEASE AUTOMATION JBoss/Deploy_EAR_Linux_Nexus Process State::Current state of the job: 197409 is FLOW_IN_PROGRESS','2016-07-07 19:09:25'),
 (152,16,'CA RELEASE AUTOMATION JBoss/Deploy_EAR_Linux_Nexus Process State::Current state of the job: 197409 is FLOW_IN_PROGRESS','2016-07-07 19:10:25'),
 (153,16,'CA RELEASE AUTOMATION JBoss/Deploy_EAR_Linux_Nexus Process State::Current state of the job: 197409 is FLOW_IN_PROGRESS','2016-07-07 19:11:25');
INSERT INTO `service_request_history` (`Id`,`Request_id`,`Comments`,`Created_Date`) VALUES 
 (154,16,'CA RELEASE AUTOMATION JBoss/Deploy_EAR_Linux_Nexus Process State::Current state of the job: 197409 is FLOW_FAILED_PAUSED','2016-07-07 19:12:25'),
 (155,16,'CA RELEASE AUTOMATION JBoss/Deploy_EAR_Linux_Nexus Failed Process:: Process FAILED with jobId:: 197409','2016-07-07 19:12:25'),
 (156,16,'CA RELEASE AUTOMATION Error:: Error in jobId:: 197409 is :Server TEMSVMI1081.asulabsir.com(10.130.25.220) has failed step Nexus - Download Nexus Artifact By GAV.','2016-07-07 19:12:25'),
 (157,16,'CA RELEASE AUTOMATION JBoss/Deploy_EAR_Linux_Nexus Process Force STOP:: Stopping failed Process with jobId:: 197409','2016-07-07 19:12:25'),
 (158,16,'Deployment Unsuccessful','2016-07-07 19:12:25'),
 (159,17,'Scheduling request.','2016-07-07 19:52:18'),
 (160,17,'Initiating request','2016-07-07 19:52:18'),
 (161,17,'DB Refresh started for Release Deployment','2016-07-07 19:52:19'),
 (162,17,'Calling CA RELEASE AUTOMATION web service to run process Processes/DB_Scripts_Oracle_Git with processID 49','2016-07-07 19:52:20'),
 (163,17,'Can Not Map the agent:: 10.130.25.174 with server due to ErrorCode:: -2','2016-07-07 19:52:20');
INSERT INTO `service_request_history` (`Id`,`Request_id`,`Comments`,`Created_Date`) VALUES 
 (164,17,'DB Refresh failed','2016-07-07 19:52:20'),
 (165,17,'Release Deployment Unsuccessful','2016-07-07 19:52:20'),
 (166,18,'Scheduling request.','2016-07-07 19:57:00'),
 (167,18,'Initiating request','2016-07-07 19:57:00'),
 (168,18,'DB Refresh started for Release Deployment','2016-07-07 19:57:01'),
 (169,18,'Calling CA RELEASE AUTOMATION web service to run process Processes/DB_Scripts_Oracle_Git with processID 49','2016-07-07 19:57:01'),
 (170,18,'successfully mapped the agent:: 10.130.25.220 with server and mappingId is:: 0','2016-07-07 19:57:02'),
 (171,18,'Setting CA RELEASE AUTOMATION parameters to run a process Processes/DB_Scripts_Oracle_Git','2016-07-07 19:57:02'),
 (172,18,'CA RELEASE AUTOMATION Processes/DB_Scripts_Oracle_Git Process Started:: Process started with jobId:: 197411','2016-07-07 19:57:03'),
 (173,18,'CA RELEASE AUTOMATION Processes/DB_Scripts_Oracle_Git Process State::Current state of the job: 197411 is FLOW_FINISHED','2016-07-07 19:58:03'),
 (174,18,'CA RELEASE AUTOMATION Processes/DB_Scripts_Oracle_Git Process Finished::Job finished with jobId:197411','2016-07-07 19:58:03');
INSERT INTO `service_request_history` (`Id`,`Request_id`,`Comments`,`Created_Date`) VALUES 
 (175,18,'DB Refresh successful','2016-07-07 19:58:03'),
 (176,18,'There are no config files to be moved','2016-07-07 19:58:04'),
 (177,18,'Calling CA RELEASE AUTOMATION web service to run process JBoss/Deploy_EAR_Linux_Nexus with processID 42','2016-07-07 19:58:04'),
 (178,18,'successfully mapped the agent:: 10.130.25.220 with server and mappingId is:: 0','2016-07-07 19:58:04'),
 (179,18,'Setting CA RELEASE AUTOMATION parameters to run a process JBoss/Deploy_EAR_Linux_Nexus','2016-07-07 19:58:04'),
 (180,18,'CA RELEASE AUTOMATION JBoss/Deploy_EAR_Linux_Nexus Process Started:: Process started with jobId:: 197412','2016-07-07 19:58:05'),
 (181,18,'CA RELEASE AUTOMATION JBoss/Deploy_EAR_Linux_Nexus Process State::Current state of the job: 197412 is FLOW_FINISHED','2016-07-07 19:59:05'),
 (182,18,'CA RELEASE AUTOMATION JBoss/Deploy_EAR_Linux_Nexus Process Finished::Job finished with jobId:197412','2016-07-07 19:59:05'),
 (183,18,'Calling CA RELEASE AUTOMATION web service to run process JBoss/Restart_JBoss_Linux with processID 35','2016-07-07 19:59:05');
INSERT INTO `service_request_history` (`Id`,`Request_id`,`Comments`,`Created_Date`) VALUES 
 (184,18,'successfully mapped the agent:: 10.130.25.220 with server and mappingId is:: 0','2016-07-07 19:59:05'),
 (185,18,'Setting CA RELEASE AUTOMATION parameters to run a process JBoss/Restart_JBoss_Linux','2016-07-07 19:59:05'),
 (186,18,'CA RELEASE AUTOMATION JBoss/Restart_JBoss_Linux Process Started:: Process started with jobId:: 197413','2016-07-07 19:59:06'),
 (187,18,'CA RELEASE AUTOMATION JBoss/Restart_JBoss_Linux Process State::Current state of the job: 197413 is FLOW_IN_PROGRESS','2016-07-07 20:00:06'),
 (188,18,'CA RELEASE AUTOMATION JBoss/Restart_JBoss_Linux Process State::Current state of the job: 197413 is FLOW_IN_PROGRESS','2016-07-07 20:01:06'),
 (189,18,'CA RELEASE AUTOMATION JBoss/Restart_JBoss_Linux Process State::Current state of the job: 197413 is FLOW_IN_PROGRESS','2016-07-07 20:02:06'),
 (190,18,'CA RELEASE AUTOMATION JBoss/Restart_JBoss_Linux Process State::Current state of the job: 197413 is FLOW_FINISHED','2016-07-07 20:03:06'),
 (191,18,'CA RELEASE AUTOMATION JBoss/Restart_JBoss_Linux Process Finished::Job finished with jobId:197413','2016-07-07 20:03:06');
INSERT INTO `service_request_history` (`Id`,`Request_id`,`Comments`,`Created_Date`) VALUES 
 (192,18,'Deployment successful','2016-07-07 20:03:06'),
 (193,19,'Scheduling request.','2016-07-07 20:08:26'),
 (194,19,'Initiating request','2016-07-07 20:08:26'),
 (195,19,'DB Refresh started','2016-07-07 20:08:27'),
 (196,19,'Calling CA RELEASE AUTOMATION web service to run process Processes/DB_Scripts_Oracle_Git with processID 49','2016-07-07 20:08:27'),
 (197,19,'successfully mapped the agent:: 10.130.25.220 with server and mappingId is:: 0','2016-07-07 20:08:28'),
 (198,19,'Setting CA RELEASE AUTOMATION parameters to run a process Processes/DB_Scripts_Oracle_Git','2016-07-07 20:08:28'),
 (199,19,'CA RELEASE AUTOMATION Processes/DB_Scripts_Oracle_Git Process Started:: Process started with jobId:: 197414','2016-07-07 20:08:29'),
 (200,19,'CA RELEASE AUTOMATION Processes/DB_Scripts_Oracle_Git Process State::Current state of the job: 197414 is FLOW_FAILED_PAUSED','2016-07-07 20:09:29'),
 (201,19,'CA RELEASE AUTOMATION Processes/DB_Scripts_Oracle_Git Failed Process:: Process FAILED with jobId:: 197414','2016-07-07 20:09:29'),
 (202,19,'CA RELEASE AUTOMATION Error:: Error in jobId:: 197414 is :Server TEMSVMI1081.asulabsir.com(10.130.25.220) has failed step Run SQL File on Oracle(c) Database Server.','2016-07-07 20:09:29');
INSERT INTO `service_request_history` (`Id`,`Request_id`,`Comments`,`Created_Date`) VALUES 
 (203,19,'CA RELEASE AUTOMATION Processes/DB_Scripts_Oracle_Git Process Force STOP:: Stopping failed Process with jobId:: 197414','2016-07-07 20:09:29'),
 (204,19,'DB Refresh Unsuccessful','2016-07-07 20:09:29'),
 (205,20,'Scheduling request.','2016-07-07 20:15:40'),
 (206,20,'Initiating request','2016-07-07 20:15:40'),
 (207,20,'Test execution started','2016-07-07 20:15:41'),
 (208,20,'JUnit test execution started','2016-07-07 20:15:41'),
 (209,20,'JUnit test execution completed','2016-07-07 20:15:42'),
 (210,20,'Testing Failed !','2016-07-07 20:15:42'),
 (211,20,'Testing failed due to internal error','2016-07-07 20:15:42'),
 (212,21,'Scheduling request.','2016-07-11 15:11:42'),
 (213,21,'Initiating request','2016-07-11 15:11:43'),
 (214,21,'Starting environment creation, this might take some time','2016-07-11 15:11:45'),
 (215,21,'Checking Java version installed on machine','2016-07-11 15:11:47'),
 (216,21,'Java installed on machine','2016-07-11 15:13:09');
INSERT INTO `service_request_history` (`Id`,`Request_id`,`Comments`,`Created_Date`) VALUES 
 (217,21,'CA RELEASE AUTOMATION agent installed successfully.','2016-07-11 15:15:08'),
 (218,21,'Monitoring agent installation started','2016-07-11 15:16:09'),
 (219,21,'Copying monitoring agent files','2016-07-11 15:16:09'),
 (220,21,'Environment Creation Service failed due to:: Error in installation machine/java/agent ','2016-07-11 15:16:09'),
 (221,22,'Scheduling request.','2016-07-11 15:21:32'),
 (222,22,'Initiating request','2016-07-11 15:21:32'),
 (223,22,'Starting environment creation, this might take some time','2016-07-11 15:21:34'),
 (224,22,'Checking Java version installed on machine','2016-07-11 15:21:35'),
 (225,22,'Java installed on machine','2016-07-11 15:22:57'),
 (226,22,'CA RELEASE AUTOMATION agent already installed.','2016-07-11 15:22:57'),
 (227,22,'Calling CA RELEASE AUTOMATION web service to run process Oracle/Install Oracle Linux with processID 15','2016-07-11 15:22:57'),
 (228,22,'successfully mapped the agent:: 10.130.25.226 with server and mappingId is:: 0','2016-07-11 15:22:57');
INSERT INTO `service_request_history` (`Id`,`Request_id`,`Comments`,`Created_Date`) VALUES 
 (229,22,'CA RELEASE AUTOMATION Oracle/Install Oracle Linux Process Started:: Process started with jobId:: 197428','2016-07-11 15:22:58'),
 (230,22,'CA RELEASE AUTOMATION Oracle/Install Oracle Linux Process State::Current state of the job: 197428 is PRE_FAILED','2016-07-11 15:23:58'),
 (231,22,'CA RELEASE AUTOMATION Oracle/Install Oracle Linux Failed Process:: Process FAILED with jobId:: 197428','2016-07-11 15:23:58'),
 (232,22,'CA RELEASE AUTOMATION Error:: Error in jobId:: 197428 is :Connectivity check failed. reason: Could not find accessible execution server for agent [localhost:10.130.25.226]. Agent may be offline.','2016-07-11 15:23:58'),
 (233,22,'CA RELEASE AUTOMATION Oracle/Install Oracle Linux Process Force STOP:: Stopping failed Process with jobId:: 197428','2016-07-11 15:23:58'),
 (234,22,'Software Installation failed for Mapped Software:: Oracle','2016-07-11 15:23:58'),
 (235,22,'There are no config files to be moved','2016-07-11 15:23:59'),
 (236,22,'Calling CA RELEASE AUTOMATION web service to run process JBoss/Install JBoss Linux-cpy with processID 36','2016-07-11 15:23:59');
INSERT INTO `service_request_history` (`Id`,`Request_id`,`Comments`,`Created_Date`) VALUES 
 (237,22,'successfully mapped the agent:: 10.130.25.226 with server and mappingId is:: 0','2016-07-11 15:23:59'),
 (238,22,'CA RELEASE AUTOMATION JBoss/Install JBoss Linux-cpy Process Started:: Process started with jobId:: 197429','2016-07-11 15:24:00'),
 (239,22,'CA RELEASE AUTOMATION JBoss/Install JBoss Linux-cpy Process State::Current state of the job: 197429 is PRE_FAILED','2016-07-11 15:25:00'),
 (240,22,'CA RELEASE AUTOMATION JBoss/Install JBoss Linux-cpy Failed Process:: Process FAILED with jobId:: 197429','2016-07-11 15:25:00'),
 (241,22,'CA RELEASE AUTOMATION Error:: Error in jobId:: 197429 is :Connectivity check failed. reason: Could not find accessible execution server for agent [localhost:10.130.25.226]. Agent may be offline.','2016-07-11 15:25:00'),
 (242,22,'CA RELEASE AUTOMATION JBoss/Install JBoss Linux-cpy Process Force STOP:: Stopping failed Process with jobId:: 197429','2016-07-11 15:25:00'),
 (243,22,'Software Installation failed for Mapped Software:: JBoss','2016-07-11 15:25:00');
INSERT INTO `service_request_history` (`Id`,`Request_id`,`Comments`,`Created_Date`) VALUES 
 (244,22,'There are no config files to be moved','2016-07-11 15:25:00'),
 (245,22,'Environment creation failed','2016-07-11 15:25:00'),
 (246,23,'Scheduling request.','2016-07-11 15:52:50'),
 (247,23,'Initiating request','2016-07-11 15:52:50'),
 (248,23,'Software Installation started','2016-07-11 15:52:51'),
 (249,23,'Calling CA RELEASE AUTOMATION web service to run process JBoss/Install JBoss Linux-cpy with processID 36','2016-07-11 15:52:51'),
 (250,23,'successfully mapped the agent:: 10.130.25.226 with server and mappingId is:: 0','2016-07-11 15:52:51'),
 (251,23,'CA RELEASE AUTOMATION JBoss/Install JBoss Linux-cpy Process Started:: Process started with jobId:: 197432','2016-07-11 15:52:53'),
 (252,23,'CA RELEASE AUTOMATION JBoss/Install JBoss Linux-cpy Process State::Current state of the job: 197432 is INIT','2016-07-11 15:53:53'),
 (253,23,'CA RELEASE AUTOMATION JBoss/Install JBoss Linux-cpy Process State::Current state of the job: 197432 is FLOW_IN_PROGRESS','2016-07-11 15:54:53'),
 (254,23,'CA RELEASE AUTOMATION JBoss/Install JBoss Linux-cpy Process State::Current state of the job: 197432 is FLOW_IN_PROGRESS','2016-07-11 15:55:53');
INSERT INTO `service_request_history` (`Id`,`Request_id`,`Comments`,`Created_Date`) VALUES 
 (255,23,'CA RELEASE AUTOMATION JBoss/Install JBoss Linux-cpy Process State::Current state of the job: 197432 is FLOW_IN_PROGRESS','2016-07-11 15:56:53'),
 (256,23,'CA RELEASE AUTOMATION JBoss/Install JBoss Linux-cpy Process State::Current state of the job: 197432 is FLOW_FINISHED','2016-07-11 15:57:53'),
 (257,23,'CA RELEASE AUTOMATION JBoss/Install JBoss Linux-cpy Process Finished::Job finished with jobId:197432','2016-07-11 15:57:54'),
 (258,23,'Software Installation successful for Mapped Software:: JBoss','2016-07-11 15:57:54'),
 (259,23,'There are no config files to be moved','2016-07-11 15:57:54'),
 (260,23,'Calling CA RELEASE AUTOMATION web service to run process Oracle/Install Oracle Linux with processID 15','2016-07-11 15:57:54'),
 (261,23,'successfully mapped the agent:: 10.130.25.226 with server and mappingId is:: 0','2016-07-11 15:57:54'),
 (262,23,'CA RELEASE AUTOMATION Oracle/Install Oracle Linux Process Started:: Process started with jobId:: 197433','2016-07-11 15:57:55'),
 (263,23,'CA RELEASE AUTOMATION Oracle/Install Oracle Linux Process State::Current state of the job: 197433 is INIT','2016-07-11 15:58:55');
INSERT INTO `service_request_history` (`Id`,`Request_id`,`Comments`,`Created_Date`) VALUES 
 (264,23,'CA RELEASE AUTOMATION Oracle/Install Oracle Linux Process State::Current state of the job: 197433 is INIT','2016-07-11 15:59:55'),
 (265,23,'CA RELEASE AUTOMATION Oracle/Install Oracle Linux Process State::Current state of the job: 197433 is FLOW_FAILED_PAUSED','2016-07-11 16:00:55'),
 (266,23,'CA RELEASE AUTOMATION Oracle/Install Oracle Linux Failed Process:: Process FAILED with jobId:: 197433','2016-07-11 16:00:55'),
 (267,23,'CA RELEASE AUTOMATION Error:: Error in jobId:: 197433 is :Server TEMSVMI190741.asulabsir.com(10.130.25.226) has failed step Create User.','2016-07-11 16:00:55'),
 (268,23,'CA RELEASE AUTOMATION Oracle/Install Oracle Linux Process Force STOP:: Stopping failed Process with jobId:: 197433','2016-07-11 16:00:56'),
 (269,23,'Software Installation failed for Mapped Software:: Oracle','2016-07-11 16:00:56'),
 (270,23,'There are no config files to be moved','2016-07-11 16:00:56'),
 (271,23,'Software Installation Unsuccessful','2016-07-11 16:00:56');
INSERT INTO `service_request_history` (`Id`,`Request_id`,`Comments`,`Created_Date`) VALUES 
 (272,24,'Scheduling request.','2016-07-11 16:16:26'),
 (273,24,'Initiating request','2016-07-11 16:16:27'),
 (274,24,'Software Installation started','2016-07-11 16:16:28'),
 (275,24,'Calling CA RELEASE AUTOMATION web service to run process Oracle/Install Oracle Linux with processID 15','2016-07-11 16:16:28'),
 (276,24,'successfully mapped the agent:: 10.130.25.226 with server and mappingId is:: 0','2016-07-11 16:16:29'),
 (277,24,'CA RELEASE AUTOMATION Oracle/Install Oracle Linux Process Started:: Process started with jobId:: 197434','2016-07-11 16:16:30'),
 (278,24,'CA RELEASE AUTOMATION Oracle/Install Oracle Linux Process State::Current state of the job: 197434 is INIT','2016-07-11 16:17:30'),
 (279,24,'CA RELEASE AUTOMATION Oracle/Install Oracle Linux Process State::Current state of the job: 197434 is INIT','2016-07-11 16:18:30'),
 (280,24,'CA RELEASE AUTOMATION Oracle/Install Oracle Linux Process State::Current state of the job: 197434 is FLOW_FAILED_PAUSED','2016-07-11 16:19:30'),
 (281,24,'CA RELEASE AUTOMATION Oracle/Install Oracle Linux Failed Process:: Process FAILED with jobId:: 197434','2016-07-11 16:19:30');
INSERT INTO `service_request_history` (`Id`,`Request_id`,`Comments`,`Created_Date`) VALUES 
 (282,24,'CA RELEASE AUTOMATION Error:: Error in jobId:: 197434 is :Server TEMSVMI190741.asulabsir.com(10.130.25.226) has failed step Create User.','2016-07-11 16:19:30'),
 (283,24,'CA RELEASE AUTOMATION Oracle/Install Oracle Linux Process Force STOP:: Stopping failed Process with jobId:: 197434','2016-07-11 16:19:30'),
 (284,24,'Software Installation failed for Mapped Software:: Oracle','2016-07-11 16:19:30'),
 (285,24,'There are no config files to be moved','2016-07-11 16:19:30'),
 (286,24,'Software Installation successful','2016-07-11 16:19:30'),
 (287,25,'Scheduling request.','2016-07-11 17:10:05'),
 (288,25,'Initiating request','2016-07-11 17:10:05'),
 (289,25,'Code Analysis started for application::App_J','2016-07-11 17:10:06'),
 (290,25,'Calling CA RELEASE AUTOMATION web service to run process Processes/sonar_1 with processID 48','2016-07-11 17:10:06'),
 (291,25,'successfully mapped the agent:: 10.130.25.225 with server and mappingId is:: 0','2016-07-11 17:10:06'),
 (292,25,'Setting CA RELEASE AUTOMATION parameters to run a process Processes/sonar_1','2016-07-11 17:10:06');
INSERT INTO `service_request_history` (`Id`,`Request_id`,`Comments`,`Created_Date`) VALUES 
 (293,25,'CA RELEASE AUTOMATION Processes/sonar_1 Process Started:: Process started with jobId:: 197435','2016-07-11 17:10:07'),
 (294,25,'CA RELEASE AUTOMATION Processes/sonar_1 Process State::Current state of the job: 197435 is FLOW_FAILED_PAUSED','2016-07-11 17:11:07'),
 (295,25,'CA RELEASE AUTOMATION Processes/sonar_1 Failed Process:: Process FAILED with jobId:: 197435','2016-07-11 17:11:07'),
 (296,25,'CA RELEASE AUTOMATION Error:: Error in jobId:: 197435 is :Server PerforceHost(10.130.25.225) has failed step Strings - Extract Regular Expresssion Check.','2016-07-11 17:11:07'),
 (297,25,'CA RELEASE AUTOMATION Processes/sonar_1 Process Force STOP:: Stopping failed Process with jobId:: 197435','2016-07-11 17:11:07'),
 (298,25,'Code Analysis failed. Please try again later','2016-07-11 17:11:08'),
 (299,26,'Scheduling request.','2016-07-11 17:14:25'),
 (300,26,'Initiating request','2016-07-11 17:14:25'),
 (301,26,'JobId of next build is:: 31','2016-07-11 17:15:27');
INSERT INTO `service_request_history` (`Id`,`Request_id`,`Comments`,`Created_Date`) VALUES 
 (302,26,'Jenkins build in progress:: 52% build completed.','2016-07-11 17:16:27'),
 (303,26,'Jenkins build in progress:: 80% build completed.','2016-07-11 17:17:28'),
 (304,26,'Jenkins build in progress:: 99% build completed.','2016-07-11 17:18:28'),
 (305,26,'Jenkins build for jobId::31 is SUCCESS','2016-07-11 17:19:28'),
 (306,26,'Build service successful','2016-07-11 17:19:28'),
 (307,27,'Scheduling request.','2016-07-11 17:58:36'),
 (308,27,'Initiating request','2016-07-11 17:58:36'),
 (309,27,'Starting environment creation, this might take some time','2016-07-11 17:58:37'),
 (310,27,'Virtual Machine got cloned successfully. VM details: VirtualMachine IP Address- 10.130.25.220,VirtualMachine Host name-TEMSVMI27111','2016-07-11 18:09:44'),
 (311,27,'Checking Java version installed on machine','2016-07-11 18:09:46'),
 (312,27,'Java not found. Installing Java','2016-07-11 18:10:07'),
 (313,27,'Environment Creation Service failed due to:: Error in installation machine/java/agent ','2016-07-11 18:10:07'),
 (314,28,'Scheduling request.','2016-07-12 11:46:55');
INSERT INTO `service_request_history` (`Id`,`Request_id`,`Comments`,`Created_Date`) VALUES 
 (315,28,'Initiating request','2016-07-12 11:46:56'),
 (316,28,'JobId of next build is:: 32','2016-07-12 11:48:01'),
 (317,28,'Jenkins build in progress:: 39% build completed.','2016-07-12 11:49:01'),
 (318,28,'Jenkins build in progress:: 60% build completed.','2016-07-12 11:50:01'),
 (319,28,'Jenkins build in progress:: 81% build completed.','2016-07-12 11:51:01'),
 (320,28,'Jenkins build in progress:: 99% build completed.','2016-07-12 11:52:01'),
 (321,28,'Jenkins build for jobId::32 is SUCCESS','2016-07-12 11:53:01'),
 (322,28,'Build service successful','2016-07-12 11:53:01'),
 (323,29,'Scheduling request.','2016-07-12 12:16:15'),
 (324,29,'Initiating request','2016-07-12 12:16:15'),
 (325,29,'Software Installation started','2016-07-12 12:16:17'),
 (326,29,'Calling CA RELEASE AUTOMATION web service to run process Oracle/Install Oracle Linux with processID 15','2016-07-12 12:16:17'),
 (327,29,'successfully mapped the agent:: 10.130.25.226 with server and mappingId is:: 0','2016-07-12 12:16:21'),
 (328,29,'CA RELEASE AUTOMATION Oracle/Install Oracle Linux Process Started:: Process started with jobId:: 197449','2016-07-12 12:16:22');
INSERT INTO `service_request_history` (`Id`,`Request_id`,`Comments`,`Created_Date`) VALUES 
 (329,29,'CA RELEASE AUTOMATION Oracle/Install Oracle Linux Process State::Current state of the job: 197449 is PRE_FAILED','2016-07-12 12:17:23'),
 (330,29,'CA RELEASE AUTOMATION Oracle/Install Oracle Linux Failed Process:: Process FAILED with jobId:: 197449','2016-07-12 12:17:23'),
 (331,29,'CA RELEASE AUTOMATION Error:: Error in jobId:: 197449 is :Connectivity check failed. reason: Could not find accessible execution server for agent [TEMSVMI190741.asulabsir.com:10.130.25.226]. Agent may be offline.','2016-07-12 12:17:23'),
 (332,29,'CA RELEASE AUTOMATION Oracle/Install Oracle Linux Process Force STOP:: Stopping failed Process with jobId:: 197449','2016-07-12 12:17:23'),
 (333,29,'Software Installation failed for Mapped Software:: Oracle','2016-07-12 12:17:23'),
 (334,29,'There are no config files to be moved','2016-07-12 12:17:24'),
 (335,29,'Software Installation Unsuccessful','2016-07-12 12:17:24'),
 (336,30,'Scheduling request.','2016-07-12 13:06:37');
INSERT INTO `service_request_history` (`Id`,`Request_id`,`Comments`,`Created_Date`) VALUES 
 (337,30,'Initiating request','2016-07-12 13:06:37'),
 (338,30,'Starting environment creation, this might take some time','2016-07-12 13:06:38'),
 (339,30,'Checking Java version installed on machine','2016-07-12 13:06:39'),
 (340,30,'Java not found. Installing Java','2016-07-12 13:07:01'),
 (341,30,'Environment Creation Service failed due to:: Error in installation machine/java/agent ','2016-07-12 13:07:01'),
 (342,31,'Scheduling request.','2016-07-13 17:22:10'),
 (343,31,'Initiating request','2016-07-13 17:22:11'),
 (344,31,'Starting environment creation, this might take some time','2016-07-13 17:22:13'),
 (345,31,'Virtual Machine got cloned successfully. VM details: VirtualMachine IP Address- 10.130.25.250,VirtualMachine Host name-TEMSVMI31131','2016-07-13 17:33:00'),
 (346,31,'Checking Java version installed on machine','2016-07-13 17:33:01'),
 (347,31,'Java not found. Installing Java','2016-07-13 17:33:23'),
 (348,31,'Environment Creation Service failed due to:: Error in installation machine/java/agent ','2016-07-13 17:33:23');
INSERT INTO `service_request_history` (`Id`,`Request_id`,`Comments`,`Created_Date`) VALUES 
 (349,32,'Scheduling request.','2016-07-13 17:59:46'),
 (350,32,'Initiating request','2016-07-13 17:59:47'),
 (351,32,'Starting environment creation, this might take some time','2016-07-13 17:59:48'),
 (352,32,'Virtual Machine got cloned successfully. VM details: VirtualMachine IP Address- 10.130.25.77,VirtualMachine Host name-TEMSVMI32141','2016-07-13 18:10:30'),
 (353,32,'Checking Java version installed on machine','2016-07-13 18:10:31'),
 (354,32,'Java not found. Installing Java','2016-07-13 18:10:52'),
 (355,32,'Java installed on machine','2016-07-13 18:13:29'),
 (356,32,'CA RELEASE AUTOMATION agent installed successfully.','2016-07-13 18:15:39'),
 (357,32,'Monitoring agent installation started','2016-07-13 18:16:39'),
 (358,32,'Copying monitoring agent files','2016-07-13 18:16:39'),
 (359,32,'Installing monitoring agent','2016-07-13 18:18:31'),
 (360,32,'Monitoring agent installation successful','2016-07-13 18:20:26'),
 (361,32,'Calling CA RELEASE AUTOMATION web service to run process JBoss/Install JBoss Linux-cpy with processID 36','2016-07-13 18:20:27');
INSERT INTO `service_request_history` (`Id`,`Request_id`,`Comments`,`Created_Date`) VALUES 
 (362,32,'successfully mapped the agent:: 10.130.25.77 with server and mappingId is:: 0','2016-07-13 18:20:27'),
 (363,32,'CA RELEASE AUTOMATION JBoss/Install JBoss Linux-cpy Process Started:: Process started with jobId:: 197558','2016-07-13 18:20:29'),
 (364,32,'CA RELEASE AUTOMATION JBoss/Install JBoss Linux-cpy Process State::Current state of the job: 197558 is FLOW_IN_PROGRESS','2016-07-13 18:21:29'),
 (365,32,'CA RELEASE AUTOMATION JBoss/Install JBoss Linux-cpy Process State::Current state of the job: 197558 is FLOW_IN_PROGRESS','2016-07-13 18:22:29'),
 (366,32,'CA RELEASE AUTOMATION JBoss/Install JBoss Linux-cpy Process State::Current state of the job: 197558 is FLOW_IN_PROGRESS','2016-07-13 18:23:29'),
 (367,32,'CA RELEASE AUTOMATION JBoss/Install JBoss Linux-cpy Process State::Current state of the job: 197558 is FLOW_FINISHED','2016-07-13 18:24:29'),
 (368,32,'CA RELEASE AUTOMATION JBoss/Install JBoss Linux-cpy Process Finished::Job finished with jobId:197558','2016-07-13 18:24:29'),
 (369,32,'Software Installation successful for Mapped Software:: JBoss','2016-07-13 18:24:29');
INSERT INTO `service_request_history` (`Id`,`Request_id`,`Comments`,`Created_Date`) VALUES 
 (370,32,'There are no config files to be moved','2016-07-13 18:24:30'),
 (371,32,'1 Zabbix templates found for softwareConfigId :: 2','2016-07-13 18:24:30'),
 (372,32,'1 Zabbix templates linked successfully for software id: 2','2016-07-13 18:24:38'),
 (373,32,'Calling CA RELEASE AUTOMATION web service to run process Zabbix/Zabbix_Jboss_Template with processID 7','2016-07-13 18:24:38'),
 (374,32,'successfully mapped the agent:: 10.130.25.77 with server and mappingId is:: 0','2016-07-13 18:24:38'),
 (375,32,'CA RELEASE AUTOMATION Zabbix/Zabbix_Jboss_Template Process Started:: Process started with jobId:: 197559','2016-07-13 18:24:40'),
 (376,32,'CA RELEASE AUTOMATION Zabbix/Zabbix_Jboss_Template Process State::Current state of the job: 197559 is FLOW_IN_PROGRESS','2016-07-13 18:25:40'),
 (377,32,'CA RELEASE AUTOMATION Zabbix/Zabbix_Jboss_Template Process State::Current state of the job: 197559 is FLOW_IN_PROGRESS','2016-07-13 18:26:40'),
 (378,32,'CA RELEASE AUTOMATION Zabbix/Zabbix_Jboss_Template Process State::Current state of the job: 197559 is FLOW_IN_PROGRESS','2016-07-13 18:27:40');
INSERT INTO `service_request_history` (`Id`,`Request_id`,`Comments`,`Created_Date`) VALUES 
 (379,32,'CA RELEASE AUTOMATION Zabbix/Zabbix_Jboss_Template Process State::Current state of the job: 197559 is FLOW_FINISHED','2016-07-13 18:28:40'),
 (380,32,'CA RELEASE AUTOMATION Zabbix/Zabbix_Jboss_Template Process Finished::Job finished with jobId:197559','2016-07-13 18:28:40'),
 (381,32,'Zabbix Template config files moved successfully for software  : 2','2016-07-13 18:28:40'),
 (382,32,'Calling CA RELEASE AUTOMATION web service to run process Oracle/Install Oracle Linux with processID 15','2016-07-13 18:28:40'),
 (383,32,'successfully mapped the agent:: 10.130.25.77 with server and mappingId is:: 0','2016-07-13 18:28:42'),
 (384,32,'CA RELEASE AUTOMATION Oracle/Install Oracle Linux Process Started:: Process started with jobId:: 197560','2016-07-13 18:28:45'),
 (385,32,'CA RELEASE AUTOMATION Oracle/Install Oracle Linux Process State::Current state of the job: 197560 is INIT','2016-07-13 18:29:45'),
 (386,32,'CA RELEASE AUTOMATION Oracle/Install Oracle Linux Process State::Current state of the job: 197560 is FLOW_IN_PROGRESS','2016-07-13 18:30:45');
INSERT INTO `service_request_history` (`Id`,`Request_id`,`Comments`,`Created_Date`) VALUES 
 (387,32,'CA RELEASE AUTOMATION Oracle/Install Oracle Linux Process State::Current state of the job: 197560 is FLOW_IN_PROGRESS','2016-07-13 18:31:45'),
 (388,32,'CA RELEASE AUTOMATION Oracle/Install Oracle Linux Process State::Current state of the job: 197560 is FLOW_IN_PROGRESS','2016-07-13 18:32:45'),
 (389,32,'CA RELEASE AUTOMATION Oracle/Install Oracle Linux Process State::Current state of the job: 197560 is FLOW_FINISHED','2016-07-13 18:33:45'),
 (390,32,'CA RELEASE AUTOMATION Oracle/Install Oracle Linux Process Finished::Job finished with jobId:197560','2016-07-13 18:33:45'),
 (391,32,'Software Installation successful for Mapped Software:: Oracle','2016-07-13 18:33:45'),
 (392,32,'There are no config files to be moved','2016-07-13 18:33:45'),
 (393,32,'1 Zabbix templates found for softwareConfigId :: 1','2016-07-13 18:33:45'),
 (394,32,'1 Zabbix templates linked successfully for software id: 1','2016-07-13 18:33:48'),
 (395,32,'Calling CA RELEASE AUTOMATION web service to run process Zabbix/Zabbix_Orcale_Template with processID 9','2016-07-13 18:33:48');
INSERT INTO `service_request_history` (`Id`,`Request_id`,`Comments`,`Created_Date`) VALUES 
 (396,32,'successfully mapped the agent:: 10.130.25.77 with server and mappingId is:: 0','2016-07-13 18:33:48'),
 (397,32,'CA RELEASE AUTOMATION Zabbix/Zabbix_Orcale_Template Process Started:: Process started with jobId:: 197561','2016-07-13 18:33:49'),
 (398,32,'CA RELEASE AUTOMATION Zabbix/Zabbix_Orcale_Template Process State::Current state of the job: 197561 is FLOW_IN_PROGRESS','2016-07-13 18:34:49'),
 (399,32,'CA RELEASE AUTOMATION Zabbix/Zabbix_Orcale_Template Process State::Current state of the job: 197561 is FLOW_FINISHED','2016-07-13 18:35:49'),
 (400,32,'CA RELEASE AUTOMATION Zabbix/Zabbix_Orcale_Template Process Finished::Job finished with jobId:197561','2016-07-13 18:35:49'),
 (401,32,'Zabbix Template config files moved successfully for software  : 1','2016-07-13 18:35:49'),
 (402,32,'Calling CA RELEASE AUTOMATION web service to run process Processes/DB_Scripts_Oracle_Git with processID 49','2016-07-13 18:35:50'),
 (403,32,'successfully mapped the agent:: 10.130.25.77 with server and mappingId is:: 0','2016-07-13 18:35:51');
INSERT INTO `service_request_history` (`Id`,`Request_id`,`Comments`,`Created_Date`) VALUES 
 (404,32,'Setting CA RELEASE AUTOMATION parameters to run a process Processes/DB_Scripts_Oracle_Git','2016-07-13 18:35:51'),
 (405,32,'CA RELEASE AUTOMATION Processes/DB_Scripts_Oracle_Git Process Started:: Process started with jobId:: 197562','2016-07-13 18:35:52'),
 (406,32,'CA RELEASE AUTOMATION Processes/DB_Scripts_Oracle_Git Process State::Current state of the job: 197562 is FLOW_FINISHED','2016-07-13 18:36:52'),
 (407,32,'CA RELEASE AUTOMATION Processes/DB_Scripts_Oracle_Git Process Finished::Job finished with jobId:197562','2016-07-13 18:36:52'),
 (408,32,'DB Refresh successful..','2016-07-13 18:36:52'),
 (409,32,'Build process started for application::App_J','2016-07-13 18:36:53'),
 (410,32,'JobId of next build is:: 33','2016-07-13 18:37:56'),
 (411,32,'Jenkins build in progress:: 38% build completed.','2016-07-13 18:38:57'),
 (412,32,'Jenkins build in progress:: 58% build completed.','2016-07-13 18:39:57'),
 (413,32,'Jenkins build in progress:: 78% build completed.','2016-07-13 18:40:57');
INSERT INTO `service_request_history` (`Id`,`Request_id`,`Comments`,`Created_Date`) VALUES 
 (414,32,'Jenkins build in progress:: 98% build completed.','2016-07-13 18:41:58'),
 (415,32,'Jenkins build for jobId::33 is SUCCESS','2016-07-13 18:42:58'),
 (416,32,'Build process for application completed ','2016-07-13 18:42:58'),
 (417,32,'Deployment started ....','2016-07-13 18:42:58'),
 (418,32,'There are no config files to be moved','2016-07-13 18:42:58'),
 (419,32,'Calling CA RELEASE AUTOMATION web service to run process JBoss/Deploy_EAR_Linux_Nexus with processID 42','2016-07-13 18:42:58'),
 (420,32,'successfully mapped the agent:: 10.130.25.77 with server and mappingId is:: 0','2016-07-13 18:42:59'),
 (421,32,'Setting CA RELEASE AUTOMATION parameters to run a process JBoss/Deploy_EAR_Linux_Nexus','2016-07-13 18:42:59'),
 (422,32,'CA RELEASE AUTOMATION JBoss/Deploy_EAR_Linux_Nexus Process Started:: Process started with jobId:: 197565','2016-07-13 18:43:00'),
 (423,32,'CA RELEASE AUTOMATION JBoss/Deploy_EAR_Linux_Nexus Process State::Current state of the job: 197565 is FLOW_FINISHED','2016-07-13 18:44:00'),
 (424,32,'CA RELEASE AUTOMATION JBoss/Deploy_EAR_Linux_Nexus Process Finished::Job finished with jobId:197565','2016-07-13 18:44:00');
INSERT INTO `service_request_history` (`Id`,`Request_id`,`Comments`,`Created_Date`) VALUES 
 (425,32,'Calling CA RELEASE AUTOMATION web service to run process JBoss/Restart_JBoss_Linux with processID 35','2016-07-13 18:44:00'),
 (426,32,'successfully mapped the agent:: 10.130.25.77 with server and mappingId is:: 0','2016-07-13 18:44:01'),
 (427,32,'Setting CA RELEASE AUTOMATION parameters to run a process JBoss/Restart_JBoss_Linux','2016-07-13 18:44:01'),
 (428,32,'CA RELEASE AUTOMATION JBoss/Restart_JBoss_Linux Process Started:: Process started with jobId:: 197567','2016-07-13 18:44:03'),
 (429,32,'CA RELEASE AUTOMATION JBoss/Restart_JBoss_Linux Process State::Current state of the job: 197567 is FLOW_IN_PROGRESS','2016-07-13 18:45:04'),
 (430,32,'CA RELEASE AUTOMATION JBoss/Restart_JBoss_Linux Process State::Current state of the job: 197567 is FLOW_IN_PROGRESS','2016-07-13 18:46:04'),
 (431,32,'CA RELEASE AUTOMATION JBoss/Restart_JBoss_Linux Process State::Current state of the job: 197567 is FLOW_IN_PROGRESS','2016-07-13 18:47:04'),
 (432,32,'CA RELEASE AUTOMATION JBoss/Restart_JBoss_Linux Process State::Current state of the job: 197567 is FLOW_FINISHED','2016-07-13 18:48:04');
INSERT INTO `service_request_history` (`Id`,`Request_id`,`Comments`,`Created_Date`) VALUES 
 (433,32,'CA RELEASE AUTOMATION JBoss/Restart_JBoss_Linux Process Finished::Job finished with jobId:197567','2016-07-13 18:48:04'),
 (434,32,'Deployment completed ....','2016-07-13 18:48:04'),
 (435,32,'Selenium test scripts execution started','2016-07-13 18:48:04'),
 (436,32,'Target Server not configured.','2016-07-13 18:48:05'),
 (437,32,'Selenium test execution completed','2016-07-13 18:48:05'),
 (438,32,'Smoke testing failed!','2016-07-13 18:48:05'),
 (439,32,'Environment creation failed','2016-07-13 18:48:05');
/*!40000 ALTER TABLE `service_request_history` ENABLE KEYS */;


--
-- Definition of table `services`
--

DROP TABLE IF EXISTS `services`;
CREATE TABLE `services` (
  `SERVICE_ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `SERVICE_NAME` varchar(45) NOT NULL,
  `STATUS` int(10) unsigned NOT NULL,
  `REMARKS` varchar(200) DEFAULT NULL,
  `LIFECYCLE_FLAG` varchar(2) DEFAULT NULL,
  `SERVICE_FLAG` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`SERVICE_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `services`
--

/*!40000 ALTER TABLE `services` DISABLE KEYS */;
INSERT INTO `services` (`SERVICE_ID`,`SERVICE_NAME`,`STATUS`,`REMARKS`,`LIFECYCLE_FLAG`,`SERVICE_FLAG`) VALUES 
 (1,'Create Environment',123,'Create Environment',NULL,'Y'),
 (2,'Database Refresh',123,'Database Refresh','Y','Y'),
 (3,'VM Reconfiguration ',123,'Virtual machine Re-configuration',NULL,'Y'),
 (4,'Make Reservation',123,'Make Reservation',NULL,'Y'),
 (5,'Application Deployment',123,'Application Deployment','Y','Y'),
 (6,'Test Execution',123,'Test Execution','Y','Y'),
 (7,'ApplicationReleaseRollback',123,'ApplicationReleaseRollback',NULL,'Y'),
 (8,'Promote',123,'Promote',NULL,'Y'),
 (9,'Restart Server',123,'Restart Server',NULL,'Y'),
 (10,'Application Undeployment',123,'Application Undeployment',NULL,'Y'),
 (11,'EC2 configuration',123,'EC2 configuration',NULL,'N'),
 (12,'Create E2E Environment',123,'Create E2E Environment',NULL,'Y'),
 (13,'Agent Deployment',123,'Agent Deployement',NULL,'Y'),
 (14,'VM Configuration',124,'VM Configuration',NULL,NULL),
 (15,'Build',123,'Build','Y','Y'),
 (16,'Software Installation',123,'Software Installation','N','Y');
INSERT INTO `services` (`SERVICE_ID`,`SERVICE_NAME`,`STATUS`,`REMARKS`,`LIFECYCLE_FLAG`,`SERVICE_FLAG`) VALUES 
 (17,'Deployment Pipeline Service',123,'Deployment Pipeline Service',NULL,'Y'),
 (18,'Code Deployment',124,'Code Deployment',NULL,'N'),
 (19,'Code Analysis',123,'Code Analysis','Y','Y'),
 (20,'Release Deployment',123,'Release Deployment','Y','Y'),
 (21,'Unschedule Services',123,'Unschedule Service',NULL,'Y'),
 (24,'ServiceNow Import',123,'ServiceNow Import',NULL,'Y'),
 (25,'Mobility Testing',123,'Mobility Testing',NULL,'Y');
/*!40000 ALTER TABLE `services` ENABLE KEYS */;


--
-- Definition of table `services_client`
--

DROP TABLE IF EXISTS `services_client`;
CREATE TABLE `services_client` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `CLIENT_ID` int(10) unsigned NOT NULL,
  `SERVICE_ID` int(10) unsigned NOT NULL,
  `ROLE_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_services_client_1` (`CLIENT_ID`),
  KEY `FK_services_client_2` (`SERVICE_ID`),
  CONSTRAINT `FK_services_client_1` FOREIGN KEY (`CLIENT_ID`) REFERENCES `client` (`CLIENT_ID`),
  CONSTRAINT `FK_services_client_2` FOREIGN KEY (`SERVICE_ID`) REFERENCES `services` (`SERVICE_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=160 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `services_client`
--

/*!40000 ALTER TABLE `services_client` DISABLE KEYS */;
INSERT INTO `services_client` (`ID`,`CLIENT_ID`,`SERVICE_ID`,`ROLE_ID`) VALUES 
 (14,0,14,1),
 (18,0,18,1),
 (21,0,21,1),
 (22,2,3,1),
 (23,0,3,1),
 (24,0,6,2),
 (25,0,6,1),
 (26,0,6,3),
 (27,0,6,4),
 (28,2,6,1),
 (29,2,6,2),
 (30,2,6,3),
 (31,2,6,4),
 (32,0,16,2),
 (33,0,16,1),
 (34,0,16,3),
 (35,0,16,4),
 (36,2,16,1),
 (37,2,16,2),
 (38,2,16,3),
 (39,2,16,4),
 (40,0,24,1),
 (41,0,24,2),
 (42,0,24,3),
 (43,0,24,4),
 (44,2,24,1),
 (45,2,24,2),
 (46,2,24,3),
 (47,2,24,4),
 (48,2,9,1),
 (49,0,9,1),
 (50,0,20,2),
 (51,0,20,1),
 (52,0,20,3),
 (53,0,20,4),
 (54,2,20,1),
 (55,2,20,2),
 (56,2,20,3),
 (57,2,20,4),
 (58,0,8,2),
 (59,0,8,1),
 (60,0,8,3),
 (61,0,8,4),
 (62,2,8,1),
 (63,2,8,2),
 (64,2,8,3),
 (65,2,8,4),
 (66,2,25,1),
 (67,2,25,2),
 (68,2,25,3),
 (69,2,25,4),
 (70,0,4,2),
 (71,0,4,1),
 (72,0,4,3),
 (73,0,4,4),
 (74,2,4,1),
 (75,2,4,2),
 (76,2,4,3),
 (77,2,4,4),
 (78,0,11,2),
 (79,0,11,1),
 (80,0,11,3),
 (81,0,11,4),
 (82,2,11,1),
 (83,2,11,2),
 (84,2,11,3),
 (85,2,11,4),
 (86,0,17,2),
 (87,0,17,1);
INSERT INTO `services_client` (`ID`,`CLIENT_ID`,`SERVICE_ID`,`ROLE_ID`) VALUES 
 (88,0,17,3),
 (89,0,17,4),
 (90,2,17,1),
 (91,2,17,2),
 (92,2,17,3),
 (93,2,17,4),
 (94,0,2,2),
 (95,0,2,1),
 (96,0,2,3),
 (97,0,2,4),
 (98,2,2,1),
 (99,2,2,2),
 (100,2,2,3),
 (101,2,2,4),
 (102,0,1,2),
 (103,0,1,1),
 (104,0,1,3),
 (105,0,1,4),
 (106,2,1,1),
 (107,2,1,2),
 (108,2,1,3),
 (109,2,1,4),
 (110,0,12,2),
 (111,0,12,1),
 (112,0,12,3),
 (113,0,12,4),
 (114,2,12,1),
 (115,2,12,2),
 (116,2,12,3),
 (117,2,12,4),
 (118,0,19,2),
 (119,0,19,1),
 (120,0,19,3),
 (121,0,19,4),
 (122,2,19,1),
 (123,2,19,2),
 (124,2,19,3),
 (125,2,19,4),
 (126,0,15,2),
 (127,0,15,1),
 (128,0,15,3),
 (129,0,15,4),
 (130,2,15,1),
 (131,2,15,2),
 (132,2,15,3),
 (133,2,15,4),
 (134,0,10,2),
 (135,0,10,1),
 (136,0,10,3),
 (137,0,10,4),
 (138,2,10,1),
 (139,2,10,2),
 (140,2,10,3),
 (141,2,10,4),
 (142,0,7,2),
 (143,0,7,1),
 (144,0,7,3),
 (145,0,7,4),
 (146,2,7,1),
 (147,2,7,2),
 (148,2,7,3),
 (149,2,7,4),
 (150,0,5,2),
 (151,0,5,1),
 (152,0,5,3);
INSERT INTO `services_client` (`ID`,`CLIENT_ID`,`SERVICE_ID`,`ROLE_ID`) VALUES 
 (153,0,5,4),
 (154,2,5,1),
 (155,2,5,2),
 (156,2,5,3),
 (157,2,5,4),
 (158,2,13,1),
 (159,0,13,1);
/*!40000 ALTER TABLE `services_client` ENABLE KEYS */;


--
-- Definition of table `sn_columns`
--

DROP TABLE IF EXISTS `sn_columns`;
CREATE TABLE `sn_columns` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `tablename` varchar(45) DEFAULT NULL,
  `columnname` varchar(45) DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `baseURL` varchar(45) DEFAULT NULL,
  `element` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=819 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sn_columns`
--

/*!40000 ALTER TABLE `sn_columns` DISABLE KEYS */;
INSERT INTO `sn_columns` (`id`,`tablename`,`columnname`,`type`,`baseURL`,`element`) VALUES 
 (670,'cmdb_ci_database','Asset','reference','dev22026.service-now.com','asset'),
 (671,'cmdb_ci_database','Asset tag','string','dev22026.service-now.com','asset_tag'),
 (672,'cmdb_ci_database','Assigned','glide_date_time','dev22026.service-now.com','assigned'),
 (673,'cmdb_ci_database','Assigned to','reference','dev22026.service-now.com','assigned_to'),
 (674,'cmdb_ci_database','Assignment group','reference','dev22026.service-now.com','assignment_group'),
 (675,'cmdb_ci_database','Checked in','glide_date_time','dev22026.service-now.com','checked_in'),
 (676,'cmdb_ci_database','Checked out','glide_date_time','dev22026.service-now.com','checked_out'),
 (677,'cmdb_ci_database','Company','reference','dev22026.service-now.com','company'),
 (678,'cmdb_ci_database','Cost','float','dev22026.service-now.com','cost'),
 (679,'cmdb_ci_database','Cost currency','string','dev22026.service-now.com','cost_cc'),
 (680,'cmdb_ci_database','Cost center','reference','dev22026.service-now.com','cost_center');
INSERT INTO `sn_columns` (`id`,`tablename`,`columnname`,`type`,`baseURL`,`element`) VALUES 
 (681,'cmdb_ci_database','Order received','glide_date_time','dev22026.service-now.com','delivery_date'),
 (682,'cmdb_ci_database','Department','reference','dev22026.service-now.com','department'),
 (683,'cmdb_ci_database','Due','glide_date_time','dev22026.service-now.com','due'),
 (684,'cmdb_ci_database','Due in','string','dev22026.service-now.com','due_in'),
 (685,'cmdb_ci_database','GL account','string','dev22026.service-now.com','gl_account'),
 (686,'cmdb_ci_database','Installed','glide_date_time','dev22026.service-now.com','install_date'),
 (687,'cmdb_ci_database','Status','integer','dev22026.service-now.com','install_status'),
 (688,'cmdb_ci_database','Invoice number','string','dev22026.service-now.com','invoice_number'),
 (689,'cmdb_ci_database','Justification','string','dev22026.service-now.com','justification'),
 (690,'cmdb_ci_database','Lease contract','string','dev22026.service-now.com','lease_id'),
 (691,'cmdb_ci_database','Location','reference','dev22026.service-now.com','location');
INSERT INTO `sn_columns` (`id`,`tablename`,`columnname`,`type`,`baseURL`,`element`) VALUES 
 (692,'cmdb_ci_database','Managed by','reference','dev22026.service-now.com','managed_by'),
 (693,'cmdb_ci_database','Manufacturer','reference','dev22026.service-now.com','manufacturer'),
 (694,'cmdb_ci_database','Model ID','reference','dev22026.service-now.com','model_id'),
 (695,'cmdb_ci_database','Name','string','dev22026.service-now.com','name'),
 (696,'cmdb_ci_database','Ordered','glide_date_time','dev22026.service-now.com','order_date'),
 (697,'cmdb_ci_database','Owned by','reference','dev22026.service-now.com','owned_by'),
 (698,'cmdb_ci_database','PO number','string','dev22026.service-now.com','po_number'),
 (699,'cmdb_ci_database','Purchased','glide_date','dev22026.service-now.com','purchase_date'),
 (700,'cmdb_ci_database','Serial number','string','dev22026.service-now.com','serial_number'),
 (701,'cmdb_ci_database','Skip sync','boolean','dev22026.service-now.com','skip_sync'),
 (702,'cmdb_ci_database','Supported by','reference','dev22026.service-now.com','supported_by'),
 (703,'cmdb_ci_database','Support group','reference','dev22026.service-now.com','support_group');
INSERT INTO `sn_columns` (`id`,`tablename`,`columnname`,`type`,`baseURL`,`element`) VALUES 
 (704,'cmdb_ci_database','Class','sys_class_name','dev22026.service-now.com','sys_class_name'),
 (705,'cmdb_ci_database','Created by','string','dev22026.service-now.com','sys_created_by'),
 (706,'cmdb_ci_database','Created','glide_date_time','dev22026.service-now.com','sys_created_on'),
 (707,'cmdb_ci_database','Domain','domain_id','dev22026.service-now.com','sys_domain'),
 (708,'cmdb_ci_database','Domain Path','domain_path','dev22026.service-now.com','sys_domain_path'),
 (709,'cmdb_ci_database','Updates','integer','dev22026.service-now.com','sys_mod_count'),
 (710,'cmdb_ci_database','Updated by','string','dev22026.service-now.com','sys_updated_by'),
 (711,'cmdb_ci_database','Updated','glide_date_time','dev22026.service-now.com','sys_updated_on'),
 (712,'cmdb_ci_database','Requires verification','boolean','dev22026.service-now.com','unverified'),
 (713,'cmdb_ci_database','Vendor','reference','dev22026.service-now.com','vendor'),
 (714,'cmdb_ci_database','Warranty expiration','glide_date','dev22026.service-now.com','warranty_expiration');
INSERT INTO `sn_columns` (`id`,`tablename`,`columnname`,`type`,`baseURL`,`element`) VALUES 
 (715,'cmdb_ci_database','Attributes','string','dev22026.service-now.com','attributes'),
 (716,'cmdb_ci_database','Can Print','boolean','dev22026.service-now.com','can_print'),
 (717,'cmdb_ci_database','Category','string','dev22026.service-now.com','category'),
 (718,'cmdb_ci_database','Approval group','reference','dev22026.service-now.com','change_control'),
 (719,'cmdb_ci_database','Comments','string','dev22026.service-now.com','comments'),
 (720,'cmdb_ci_database','Correlation ID','string','dev22026.service-now.com','correlation_id'),
 (721,'cmdb_ci_database','Discovery source','string','dev22026.service-now.com','discovery_source'),
 (722,'cmdb_ci_database','DNS Domain','string','dev22026.service-now.com','dns_domain'),
 (723,'cmdb_ci_database','Fault count','integer','dev22026.service-now.com','fault_count'),
 (724,'cmdb_ci_database','First discovered','glide_date_time','dev22026.service-now.com','first_discovered'),
 (725,'cmdb_ci_database','Fully qualified domain name','string','dev22026.service-now.com','fqdn');
INSERT INTO `sn_columns` (`id`,`tablename`,`columnname`,`type`,`baseURL`,`element`) VALUES 
 (726,'cmdb_ci_database','IP Address','string','dev22026.service-now.com','ip_address'),
 (727,'cmdb_ci_database','Most recent discovery','glide_date_time','dev22026.service-now.com','last_discovered'),
 (728,'cmdb_ci_database','MAC Address','string','dev22026.service-now.com','mac_address'),
 (729,'cmdb_ci_database','Maintenance schedule','reference','dev22026.service-now.com','maintenance_schedule'),
 (730,'cmdb_ci_database','Model number','string','dev22026.service-now.com','model_number'),
 (731,'cmdb_ci_database','Monitor','boolean','dev22026.service-now.com','monitor'),
 (732,'cmdb_ci_database','Operational status','integer','dev22026.service-now.com','operational_status'),
 (733,'cmdb_ci_database','Schedule','reference','dev22026.service-now.com','schedule'),
 (734,'cmdb_ci_database','Description','string','dev22026.service-now.com','short_description'),
 (735,'cmdb_ci_database','Start date','glide_date_time','dev22026.service-now.com','start_date'),
 (736,'cmdb_ci_database','Subcategory','string','dev22026.service-now.com','subcategory');
INSERT INTO `sn_columns` (`id`,`tablename`,`columnname`,`type`,`baseURL`,`element`) VALUES 
 (737,'cmdb_ci_database','Database Server','reference','dev22026.service-now.com','db_server'),
 (738,'cmdb_ci_database','Type','string','dev22026.service-now.com','type'),
 (739,'cmdb_ci_database','Version','string','dev22026.service-now.com','version'),
 (740,'cmdb_ci_app_server','Asset','reference','dev22026.service-now.com','asset'),
 (741,'cmdb_ci_app_server','Asset tag','string','dev22026.service-now.com','asset_tag'),
 (742,'cmdb_ci_app_server','Assigned','glide_date_time','dev22026.service-now.com','assigned'),
 (743,'cmdb_ci_app_server','Assigned to','reference','dev22026.service-now.com','assigned_to'),
 (744,'cmdb_ci_app_server','Assignment group','reference','dev22026.service-now.com','assignment_group'),
 (745,'cmdb_ci_app_server','Checked in','glide_date_time','dev22026.service-now.com','checked_in'),
 (746,'cmdb_ci_app_server','Checked out','glide_date_time','dev22026.service-now.com','checked_out'),
 (747,'cmdb_ci_app_server','Company','reference','dev22026.service-now.com','company');
INSERT INTO `sn_columns` (`id`,`tablename`,`columnname`,`type`,`baseURL`,`element`) VALUES 
 (748,'cmdb_ci_app_server','Cost','float','dev22026.service-now.com','cost'),
 (749,'cmdb_ci_app_server','Cost currency','string','dev22026.service-now.com','cost_cc'),
 (750,'cmdb_ci_app_server','Cost center','reference','dev22026.service-now.com','cost_center'),
 (751,'cmdb_ci_app_server','Order received','glide_date_time','dev22026.service-now.com','delivery_date'),
 (752,'cmdb_ci_app_server','Department','reference','dev22026.service-now.com','department'),
 (753,'cmdb_ci_app_server','Due','glide_date_time','dev22026.service-now.com','due'),
 (754,'cmdb_ci_app_server','Due in','string','dev22026.service-now.com','due_in'),
 (755,'cmdb_ci_app_server','GL account','string','dev22026.service-now.com','gl_account'),
 (756,'cmdb_ci_app_server','Installed','glide_date_time','dev22026.service-now.com','install_date'),
 (757,'cmdb_ci_app_server','Status','integer','dev22026.service-now.com','install_status'),
 (758,'cmdb_ci_app_server','Invoice number','string','dev22026.service-now.com','invoice_number');
INSERT INTO `sn_columns` (`id`,`tablename`,`columnname`,`type`,`baseURL`,`element`) VALUES 
 (759,'cmdb_ci_app_server','Justification','string','dev22026.service-now.com','justification'),
 (760,'cmdb_ci_app_server','Lease contract','string','dev22026.service-now.com','lease_id'),
 (761,'cmdb_ci_app_server','Location','reference','dev22026.service-now.com','location'),
 (762,'cmdb_ci_app_server','Managed by','reference','dev22026.service-now.com','managed_by'),
 (763,'cmdb_ci_app_server','Manufacturer','reference','dev22026.service-now.com','manufacturer'),
 (764,'cmdb_ci_app_server','Model ID','reference','dev22026.service-now.com','model_id'),
 (765,'cmdb_ci_app_server','Name','string','dev22026.service-now.com','name'),
 (766,'cmdb_ci_app_server','Ordered','glide_date_time','dev22026.service-now.com','order_date'),
 (767,'cmdb_ci_app_server','Owned by','reference','dev22026.service-now.com','owned_by'),
 (768,'cmdb_ci_app_server','PO number','string','dev22026.service-now.com','po_number'),
 (769,'cmdb_ci_app_server','Purchased','glide_date','dev22026.service-now.com','purchase_date');
INSERT INTO `sn_columns` (`id`,`tablename`,`columnname`,`type`,`baseURL`,`element`) VALUES 
 (770,'cmdb_ci_app_server','Serial number','string','dev22026.service-now.com','serial_number'),
 (771,'cmdb_ci_app_server','Skip sync','boolean','dev22026.service-now.com','skip_sync'),
 (772,'cmdb_ci_app_server','Supported by','reference','dev22026.service-now.com','supported_by'),
 (773,'cmdb_ci_app_server','Support group','reference','dev22026.service-now.com','support_group'),
 (774,'cmdb_ci_app_server','Class','sys_class_name','dev22026.service-now.com','sys_class_name'),
 (775,'cmdb_ci_app_server','Created by','string','dev22026.service-now.com','sys_created_by'),
 (776,'cmdb_ci_app_server','Created','glide_date_time','dev22026.service-now.com','sys_created_on'),
 (777,'cmdb_ci_app_server','Domain','domain_id','dev22026.service-now.com','sys_domain'),
 (778,'cmdb_ci_app_server','Domain Path','domain_path','dev22026.service-now.com','sys_domain_path'),
 (779,'cmdb_ci_app_server','Updates','integer','dev22026.service-now.com','sys_mod_count'),
 (780,'cmdb_ci_app_server','Updated by','string','dev22026.service-now.com','sys_updated_by');
INSERT INTO `sn_columns` (`id`,`tablename`,`columnname`,`type`,`baseURL`,`element`) VALUES 
 (781,'cmdb_ci_app_server','Updated','glide_date_time','dev22026.service-now.com','sys_updated_on'),
 (782,'cmdb_ci_app_server','Requires verification','boolean','dev22026.service-now.com','unverified'),
 (783,'cmdb_ci_app_server','Vendor','reference','dev22026.service-now.com','vendor'),
 (784,'cmdb_ci_app_server','Warranty expiration','glide_date','dev22026.service-now.com','warranty_expiration'),
 (785,'cmdb_ci_app_server','Attributes','string','dev22026.service-now.com','attributes'),
 (786,'cmdb_ci_app_server','Can Print','boolean','dev22026.service-now.com','can_print'),
 (787,'cmdb_ci_app_server','Category','string','dev22026.service-now.com','category'),
 (788,'cmdb_ci_app_server','Approval group','reference','dev22026.service-now.com','change_control'),
 (789,'cmdb_ci_app_server','Comments','string','dev22026.service-now.com','comments'),
 (790,'cmdb_ci_app_server','Correlation ID','string','dev22026.service-now.com','correlation_id'),
 (791,'cmdb_ci_app_server','Discovery source','string','dev22026.service-now.com','discovery_source');
INSERT INTO `sn_columns` (`id`,`tablename`,`columnname`,`type`,`baseURL`,`element`) VALUES 
 (792,'cmdb_ci_app_server','DNS Domain','string','dev22026.service-now.com','dns_domain'),
 (793,'cmdb_ci_app_server','Fault count','integer','dev22026.service-now.com','fault_count'),
 (794,'cmdb_ci_app_server','First discovered','glide_date_time','dev22026.service-now.com','first_discovered'),
 (795,'cmdb_ci_app_server','Fully qualified domain name','string','dev22026.service-now.com','fqdn'),
 (796,'cmdb_ci_app_server','IP Address','string','dev22026.service-now.com','ip_address'),
 (797,'cmdb_ci_app_server','Most recent discovery','glide_date_time','dev22026.service-now.com','last_discovered'),
 (798,'cmdb_ci_app_server','MAC Address','string','dev22026.service-now.com','mac_address'),
 (799,'cmdb_ci_app_server','Maintenance schedule','reference','dev22026.service-now.com','maintenance_schedule'),
 (800,'cmdb_ci_app_server','Model number','string','dev22026.service-now.com','model_number'),
 (801,'cmdb_ci_app_server','Monitor','boolean','dev22026.service-now.com','monitor');
INSERT INTO `sn_columns` (`id`,`tablename`,`columnname`,`type`,`baseURL`,`element`) VALUES 
 (802,'cmdb_ci_app_server','Operational status','integer','dev22026.service-now.com','operational_status'),
 (803,'cmdb_ci_app_server','Schedule','reference','dev22026.service-now.com','schedule'),
 (804,'cmdb_ci_app_server','Description','string','dev22026.service-now.com','short_description'),
 (805,'cmdb_ci_app_server','Start date','glide_date_time','dev22026.service-now.com','start_date'),
 (806,'cmdb_ci_app_server','Subcategory','string','dev22026.service-now.com','subcategory'),
 (807,'cmdb_ci_app_server','Configuration directory','string','dev22026.service-now.com','config_directory'),
 (808,'cmdb_ci_app_server','Configuration file','string','dev22026.service-now.com','config_file'),
 (809,'cmdb_ci_app_server','Edition','string','dev22026.service-now.com','edition'),
 (810,'cmdb_ci_app_server','Installation directory','string','dev22026.service-now.com','install_directory'),
 (811,'cmdb_ci_app_server','Is clustered','boolean','dev22026.service-now.com','is_clustered'),
 (812,'cmdb_ci_app_server','PID','integer','dev22026.service-now.com','pid');
INSERT INTO `sn_columns` (`id`,`tablename`,`columnname`,`type`,`baseURL`,`element`) VALUES 
 (813,'cmdb_ci_app_server','Running process command','string','dev22026.service-now.com','running_process_command'),
 (814,'cmdb_ci_app_server','Running process key parameters','string','dev22026.service-now.com','running_process_key_parameters'),
 (815,'cmdb_ci_app_server','TCP port(s)','string','dev22026.service-now.com','tcp_port'),
 (816,'cmdb_ci_app_server','Used for','string','dev22026.service-now.com','used_for'),
 (817,'cmdb_ci_app_server','Version','string','dev22026.service-now.com','version'),
 (818,'cmdb_ci_app_server','Container','string','dev22026.service-now.com','container');
/*!40000 ALTER TABLE `sn_columns` ENABLE KEYS */;


--
-- Definition of table `sn_server_config`
--

DROP TABLE IF EXISTS `sn_server_config`;
CREATE TABLE `sn_server_config` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `baseURL` varchar(45) NOT NULL,
  `port` int(10) NOT NULL,
  `proxyURL` varchar(45) DEFAULT NULL,
  `proxyPassword` varchar(45) DEFAULT NULL,
  `proxyUsername` varchar(45) DEFAULT NULL,
  `proxyPort` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sn_server_config`
--

/*!40000 ALTER TABLE `sn_server_config` DISABLE KEYS */;
INSERT INTO `sn_server_config` (`id`,`username`,`password`,`baseURL`,`port`,`proxyURL`,`proxyPassword`,`proxyUsername`,`proxyPort`) VALUES 
 (1,'admin','auxGPcveYMTBNUvL48UGwtuCjpjgmKlP','https://dev22026.service-now.com',443,'172.16.181.145','8D8KW8bqGNNjSwKNXtnLpJNx8w8jAwjM','241283',8080);
/*!40000 ALTER TABLE `sn_server_config` ENABLE KEYS */;


--
-- Definition of table `sn_table_names`
--

DROP TABLE IF EXISTS `sn_table_names`;
CREATE TABLE `sn_table_names` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `table_name` varchar(45) NOT NULL,
  `tool` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sn_table_names`
--

/*!40000 ALTER TABLE `sn_table_names` DISABLE KEYS */;
INSERT INTO `sn_table_names` (`id`,`table_name`,`tool`) VALUES 
 (1,'software','Netra'),
 (2,'softwareconfig','Netra'),
 (3,'cmdb_ci_app_server','ServiceNow'),
 (4,'cmdb_ci_database','ServiceNow'),
 (5,'provisioned_platform','Netra'),
 (6,'provisioned_machine','Netra'),
 (7,'provisioned_machine_physical','Netra'),
 (8,'cmdb_ci_server','ServiceNow');
/*!40000 ALTER TABLE `sn_table_names` ENABLE KEYS */;


--
-- Definition of table `software`
--

DROP TABLE IF EXISTS `software`;
CREATE TABLE `software` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `type` varchar(64) NOT NULL,
  `manufacturer` varchar(64) NOT NULL,
  `model` varchar(64) NOT NULL,
  `CREATED_BY` int(10) unsigned DEFAULT NULL,
  `CREATED_DATE` datetime DEFAULT NULL,
  `MODIFIED_BY` int(10) unsigned DEFAULT NULL,
  `MODIFIED_DATE` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `software`
--

/*!40000 ALTER TABLE `software` DISABLE KEYS */;
INSERT INTO `software` (`id`,`name`,`type`,`manufacturer`,`model`,`CREATED_BY`,`CREATED_DATE`,`MODIFIED_BY`,`MODIFIED_DATE`) VALUES 
 (1,'Oracle','Database','Oracle','Oracle',3,'2016-07-04 00:00:00',3,'2016-07-04 00:00:00'),
 (2,'JBoss','Application Server','JBoss','JBoss',3,'2016-07-04 00:00:00',3,'2016-07-04 00:00:00');
/*!40000 ALTER TABLE `software` ENABLE KEYS */;


--
-- Definition of table `software_task_mapping`
--

DROP TABLE IF EXISTS `software_task_mapping`;
CREATE TABLE `software_task_mapping` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `software_config_id` int(10) unsigned NOT NULL,
  `task_order` int(10) unsigned NOT NULL,
  `task_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `software_task_mapping`
--

/*!40000 ALTER TABLE `software_task_mapping` DISABLE KEYS */;
/*!40000 ALTER TABLE `software_task_mapping` ENABLE KEYS */;


--
-- Definition of table `software_template_property`
--

DROP TABLE IF EXISTS `software_template_property`;
CREATE TABLE `software_template_property` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SOFTWARECONFIG_ID` int(11) NOT NULL,
  `attribute_value` varchar(45) NOT NULL,
  `attribute_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_software_template_property_1` (`SOFTWARECONFIG_ID`),
  KEY `FK_software_template_property_2` (`attribute_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `software_template_property`
--

/*!40000 ALTER TABLE `software_template_property` DISABLE KEYS */;
/*!40000 ALTER TABLE `software_template_property` ENABLE KEYS */;


--
-- Definition of table `softwareconfig`
--

DROP TABLE IF EXISTS `softwareconfig`;
CREATE TABLE `softwareconfig` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `deviceId` int(11) NOT NULL,
  `version` varchar(48) NOT NULL,
  `patch` varchar(32) DEFAULT NULL,
  `effectiveDate` datetime DEFAULT NULL,
  `effectiveRelease` varchar(32) DEFAULT NULL,
  `remark` varchar(45) DEFAULT NULL,
  `status` int(10) unsigned DEFAULT '61',
  `CREATED_BY` int(10) unsigned DEFAULT NULL,
  `CREATED_DATE` datetime DEFAULT NULL,
  `MODIFIED_BY` int(10) unsigned DEFAULT NULL,
  `MODIFIED_DATE` datetime DEFAULT NULL,
  `targetLocationWindows` varchar(45) DEFAULT NULL,
  `targetLocationLinux` varchar(45) DEFAULT NULL,
  `targetFlag` varchar(45) DEFAULT NULL,
  `installerLocationLinux` varchar(45) DEFAULT NULL,
  `installerLocationWindows` varchar(45) DEFAULT NULL,
  `parameters` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `deviceId` (`deviceId`),
  CONSTRAINT `FK_softwareconfig_1` FOREIGN KEY (`deviceId`) REFERENCES `software` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `softwareconfig`
--

/*!40000 ALTER TABLE `softwareconfig` DISABLE KEYS */;
INSERT INTO `softwareconfig` (`id`,`deviceId`,`version`,`patch`,`effectiveDate`,`effectiveRelease`,`remark`,`status`,`CREATED_BY`,`CREATED_DATE`,`MODIFIED_BY`,`MODIFIED_DATE`,`targetLocationWindows`,`targetLocationLinux`,`targetFlag`,`installerLocationLinux`,`installerLocationWindows`,`parameters`) VALUES 
 (1,1,'10g','0.00','2016-07-04 00:00:00',NULL,'',61,3,'2016-07-04 00:00:00',NULL,NULL,'','/opt','L','/opt','',NULL),
 (2,2,'5','0.00','2016-07-04 00:00:00',NULL,'',61,3,'2016-07-04 00:00:00',NULL,NULL,'','/opt','L','/opt','',NULL);
/*!40000 ALTER TABLE `softwareconfig` ENABLE KEYS */;


--
-- Definition of table `sonar_detail`
--

DROP TABLE IF EXISTS `sonar_detail`;
CREATE TABLE `sonar_detail` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `application_release_id` int(10) unsigned NOT NULL,
  `checkout_location` varchar(300) DEFAULT NULL,
  `svn_path_location` varchar(500) NOT NULL,
  `testing_phase_id` int(10) unsigned NOT NULL,
  `repository_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sonar_detail`
--

/*!40000 ALTER TABLE `sonar_detail` DISABLE KEYS */;
INSERT INTO `sonar_detail` (`id`,`application_release_id`,`checkout_location`,`svn_path_location`,`testing_phase_id`,`repository_id`) VALUES 
 (1,1,NULL,'http://10.130.25.91/svn/my_repo/branches/Release1.2/TEMS/TEMS-Externa/',0,1),
 (2,2,NULL,'http://10.130.25.91/svn/my_repo/branches/Release1.2/TEMS/TEMS-Externa/',0,1);
/*!40000 ALTER TABLE `sonar_detail` ENABLE KEYS */;


--
-- Definition of table `sonar_reports_detail`
--

DROP TABLE IF EXISTS `sonar_reports_detail`;
CREATE TABLE `sonar_reports_detail` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Application_id` int(10) unsigned NOT NULL,
  `Application_release_id` int(10) unsigned NOT NULL,
  `FolderName` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sonar_reports_detail`
--

/*!40000 ALTER TABLE `sonar_reports_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `sonar_reports_detail` ENABLE KEYS */;


--
-- Definition of table `status`
--

DROP TABLE IF EXISTS `status`;
CREATE TABLE `status` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `STATUS_DESC` varchar(45) NOT NULL,
  `ENTITY_ID` int(10) unsigned NOT NULL,
  `VISSIBLE` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=191 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `status`
--

/*!40000 ALTER TABLE `status` DISABLE KEYS */;
INSERT INTO `status` (`ID`,`STATUS_DESC`,`ENTITY_ID`,`VISSIBLE`) VALUES 
 (11,'Active',1,NULL),
 (12,'Inactive',1,NULL),
 (21,'Available',2,NULL),
 (22,'Unavailable',2,NULL),
 (23,'Under Implementation',2,NULL),
 (25,'Pending Approval',2,NULL),
 (26,'Rejected',2,NULL),
 (31,'Active',3,NULL),
 (32,'Inactive',3,NULL),
 (41,'Active',4,NULL),
 (42,'Inactive',4,NULL),
 (51,'Available',5,NULL),
 (52,'Unavailable',5,NULL),
 (61,'Available',6,NULL),
 (62,'Unavailable',6,NULL),
 (71,'Available',7,NULL),
 (72,'Unavailable',7,NULL),
 (73,'Allocated',7,NULL),
 (81,'Reserved',8,NULL),
 (82,'Cancelled',8,NULL),
 (83,'Conflicting',8,NULL),
 (84,'Pending Approval',8,NULL),
 (85,'Rejected',8,NULL),
 (86,'Auto Rejected',8,NULL),
 (91,'Available',9,NULL),
 (92,'Unavailable',9,NULL),
 (101,'Active',10,NULL),
 (102,'Inactive',10,NULL),
 (121,'Active',12,NULL),
 (122,'Inactive',12,NULL),
 (123,'Active',13,NULL),
 (124,'Inactive',13,NULL),
 (141,'Pending Approval',14,NULL),
 (142,'Under Implementation',14,NULL),
 (143,'Completed',15,NULL);
INSERT INTO `status` (`ID`,`STATUS_DESC`,`ENTITY_ID`,`VISSIBLE`) VALUES 
 (144,'Rejected',15,NULL),
 (145,'Not Started',15,NULL),
 (146,'Skipped',15,NULL),
 (147,'Submission Failed',15,'N'),
 (151,'Active',16,NULL),
 (152,'Inactive',16,NULL),
 (161,'Yes',16,NULL),
 (162,'No',16,NULL),
 (171,'Shared',17,NULL),
 (172,'Not Shared',17,NULL),
 (173,'Major',18,NULL),
 (174,'Minor',18,NULL),
 (175,'Active',19,NULL),
 (176,'Inactive',19,NULL),
 (177,'Available',20,NULL),
 (178,'Unavailable',20,NULL),
 (179,'Available',21,NULL),
 (180,'Unavailable',21,NULL),
 (187,'ACT',22,NULL),
 (188,'ICT',22,NULL),
 (189,'Active',23,NULL),
 (190,'Inactive',23,NULL);
/*!40000 ALTER TABLE `status` ENABLE KEYS */;


--
-- Definition of table `svndetail`
--

DROP TABLE IF EXISTS `svndetail`;
CREATE TABLE `svndetail` (
  `SVNID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `HEADURL` varchar(100) NOT NULL,
  `TAGURL` varchar(100) NOT NULL,
  `USERNAME` varchar(45) NOT NULL,
  `PASSWORD` varchar(45) NOT NULL,
  PRIMARY KEY (`SVNID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `svndetail`
--

/*!40000 ALTER TABLE `svndetail` DISABLE KEYS */;
/*!40000 ALTER TABLE `svndetail` ENABLE KEYS */;


--
-- Definition of table `tasks`
--

DROP TABLE IF EXISTS `tasks`;
CREATE TABLE `tasks` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `TASK_NAME` varchar(45) NOT NULL,
  `ACTIVITY_ID` int(11) NOT NULL,
  `MANIFEST_ID` int(10) unsigned DEFAULT NULL,
  `CREATED_BY` int(10) unsigned NOT NULL,
  `MODIFIED_BY` int(10) unsigned DEFAULT NULL,
  `CREATED_DATE` datetime NOT NULL,
  `MODIFIED_DATE` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_CA_Activity_ID` (`ACTIVITY_ID`),
  KEY `FK_Manifest_ID1` (`MANIFEST_ID`),
  CONSTRAINT `FK_CA_Activity_ID` FOREIGN KEY (`ACTIVITY_ID`) REFERENCES `ca_release_activity` (`Activity_Id`),
  CONSTRAINT `FK_Manifest_ID1` FOREIGN KEY (`MANIFEST_ID`) REFERENCES `automation_tool` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tasks`
--

/*!40000 ALTER TABLE `tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `tasks` ENABLE KEYS */;


--
-- Definition of table `tems_testing_type`
--

DROP TABLE IF EXISTS `tems_testing_type`;
CREATE TABLE `tems_testing_type` (
  `Type_Id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Type_Name` varchar(45) NOT NULL,
  PRIMARY KEY (`Type_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tems_testing_type`
--

/*!40000 ALTER TABLE `tems_testing_type` DISABLE KEYS */;
INSERT INTO `tems_testing_type` (`Type_Id`,`Type_Name`) VALUES 
 (1,'Regression'),
 (2,'Functional'),
 (3,'UAT'),
 (4,'Performance Testing'),
 (5,'Compatibility Testing'),
 (6,'Integration Testing'),
 (7,'End-to-end testing');
/*!40000 ALTER TABLE `tems_testing_type` ENABLE KEYS */;


--
-- Definition of table `test_execution_results`
--

DROP TABLE IF EXISTS `test_execution_results`;
CREATE TABLE `test_execution_results` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `service_request_id` int(10) unsigned NOT NULL,
  `app_rel_id` int(10) unsigned NOT NULL,
  `provider` varchar(16) NOT NULL,
  `status` varchar(8) NOT NULL,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `total_tests` int(10) unsigned DEFAULT NULL,
  `skipped` int(10) unsigned DEFAULT NULL,
  `failed` int(10) unsigned DEFAULT NULL,
  `passed` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_by` int(10) unsigned DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `test_execution_results`
--

/*!40000 ALTER TABLE `test_execution_results` DISABLE KEYS */;
INSERT INTO `test_execution_results` (`id`,`service_request_id`,`app_rel_id`,`provider`,`status`,`start_time`,`end_time`,`total_tests`,`skipped`,`failed`,`passed`,`created_by`,`created_date`,`modified_by`,`modified_date`) VALUES 
 (1,20,1,'JUNIT','FAILED','2016-07-07 20:15:41','2016-07-07 20:15:41',NULL,NULL,NULL,NULL,3,'2016-07-07 20:15:41',3,'2016-07-07 20:15:41');
/*!40000 ALTER TABLE `test_execution_results` ENABLE KEYS */;


--
-- Definition of table `test_execution_results_details`
--

DROP TABLE IF EXISTS `test_execution_results_details`;
CREATE TABLE `test_execution_results_details` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `test_execution_result_id` int(10) unsigned DEFAULT NULL,
  `test_case_name` varchar(100) NOT NULL,
  `status` varchar(8) DEFAULT NULL,
  `total_tests` int(10) unsigned DEFAULT NULL,
  `skipped` int(10) unsigned DEFAULT NULL,
  `failed` int(10) unsigned DEFAULT NULL,
  `passed` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_test_execution_results_details_1` (`test_execution_result_id`),
  CONSTRAINT `FK_test_execution_results_details_1` FOREIGN KEY (`test_execution_result_id`) REFERENCES `test_execution_results` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `test_execution_results_details`
--

/*!40000 ALTER TABLE `test_execution_results_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `test_execution_results_details` ENABLE KEYS */;


--
-- Definition of table `testing_phase`
--

DROP TABLE IF EXISTS `testing_phase`;
CREATE TABLE `testing_phase` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `PhaseName` varchar(45) NOT NULL,
  `colorCode` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `testing_phase`
--

/*!40000 ALTER TABLE `testing_phase` DISABLE KEYS */;
INSERT INTO `testing_phase` (`id`,`PhaseName`,`colorCode`) VALUES 
 (1,'UNIT','#6DFC51'),
 (2,'QA','#E0400A'),
 (3,'ST','#056492'),
 (4,'SIT','#BFBFBF'),
 (5,'UAT','#1A3B69'),
 (6,'PRE PROD','#FFE382'),
 (7,'PROD','#FFE382');
/*!40000 ALTER TABLE `testing_phase` ENABLE KEYS */;


--
-- Definition of table `testing_tool`
--

DROP TABLE IF EXISTS `testing_tool`;
CREATE TABLE `testing_tool` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `description` varchar(100) DEFAULT NULL,
  `TAM_adapter_location` varchar(200) DEFAULT NULL,
  `TAM_adapter_folder_name` varchar(45) DEFAULT NULL,
  `TAM_start_file_name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `testing_tool`
--

/*!40000 ALTER TABLE `testing_tool` DISABLE KEYS */;
INSERT INTO `testing_tool` (`id`,`name`,`description`,`TAM_adapter_location`,`TAM_adapter_folder_name`,`TAM_start_file_name`) VALUES 
 (1,'SELENIUM',NULL,NULL,NULL,NULL),
 (2,'QTP',NULL,NULL,NULL,NULL),
 (3,'APACHE_JMETER',NULL,NULL,NULL,NULL),
 (4,'MasterCraft TAM Server',NULL,NULL,NULL,NULL),
 (5,'JUNIT',NULL,NULL,NULL,NULL),
 (6,'MasterCraft TAM Client(RAFT-Selenium)',NULL,'C:\\tamzipfile\\TCSMasterCraftRAFT-SeleniumAdapter.zip','TCS MasterCraftRAFT-Selenium Adapter','StartAdapter-Selenium.bat'),
 (7,'PERFECTO',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `testing_tool` ENABLE KEYS */;


--
-- Definition of table `testing_tools_configuration`
--

DROP TABLE IF EXISTS `testing_tools_configuration`;
CREATE TABLE `testing_tools_configuration` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bu_id` int(10) unsigned NOT NULL,
  `project_id` int(10) unsigned DEFAULT NULL,
  `application_id` int(10) unsigned DEFAULT NULL,
  `script_copy_location` varchar(45) DEFAULT NULL,
  `username` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `machine_username` varchar(45) DEFAULT NULL,
  `machine_password` varchar(45) DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `parameter_name` varchar(45) DEFAULT NULL,
  `testing_tool_id` int(10) unsigned NOT NULL,
  `Domain` varchar(200) DEFAULT NULL,
  `Server_url` varchar(200) DEFAULT NULL,
  `Tam_adapter_flag` varchar(5) DEFAULT NULL,
  `Tam_adapter_name` varchar(45) DEFAULT NULL,
  `Adapter_copy_location_windows` varchar(45) DEFAULT NULL,
  `Adapter_copy_location_linux` varchar(45) DEFAULT NULL,
  `Execution_server_name` varchar(45) NOT NULL,
  `prov_mach_id` int(10) unsigned DEFAULT NULL,
  `sel_Jar_Location` varchar(1000) DEFAULT NULL,
  `sel_port` int(10) unsigned DEFAULT NULL,
  `result_Location` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_TestingTool_id` (`testing_tool_id`),
  CONSTRAINT `FK_TestingTool_id` FOREIGN KEY (`testing_tool_id`) REFERENCES `testing_tool` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `testing_tools_configuration`
--

/*!40000 ALTER TABLE `testing_tools_configuration` DISABLE KEYS */;
/*!40000 ALTER TABLE `testing_tools_configuration` ENABLE KEYS */;


--
-- Definition of table `tools_configuration`
--

DROP TABLE IF EXISTS `tools_configuration`;
CREATE TABLE `tools_configuration` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `bu_id` int(11) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `application_id` int(11) DEFAULT NULL,
  `type` int(10) unsigned DEFAULT NULL,
  `CI_Server_URL` varchar(45) NOT NULL,
  `server_ip` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Index_2` (`bu_id`,`project_id`,`application_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tools_configuration`
--

/*!40000 ALTER TABLE `tools_configuration` DISABLE KEYS */;
INSERT INTO `tools_configuration` (`id`,`username`,`password`,`bu_id`,`project_id`,`application_id`,`type`,`CI_Server_URL`,`server_ip`) VALUES 
 (1,'builduser','f4C+fC1bU1vp6Z8cl5NEB0QOfVYahmJ4',2,1,1,1,'http://10.130.25.150:8080/jenkins','');
/*!40000 ALTER TABLE `tools_configuration` ENABLE KEYS */;


--
-- Definition of table `transformmap_config`
--

DROP TABLE IF EXISTS `transformmap_config`;
CREATE TABLE `transformmap_config` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `baseURL` varchar(45) NOT NULL,
  `sn_tab_name` varchar(90) NOT NULL,
  `local_tab_name` varchar(124) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transformmap_config`
--

/*!40000 ALTER TABLE `transformmap_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `transformmap_config` ENABLE KEYS */;


--
-- Definition of table `transformmap_mapping`
--

DROP TABLE IF EXISTS `transformmap_mapping`;
CREATE TABLE `transformmap_mapping` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sn_col_name` varchar(45) DEFAULT NULL,
  `local_col_name` varchar(45) DEFAULT NULL,
  `tMapID` int(10) unsigned NOT NULL,
  `netra_table` varchar(45) DEFAULT NULL,
  `sn_table` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_transformMap_mapping_1` (`tMapID`),
  CONSTRAINT `FK_transformMap_mapping_1` FOREIGN KEY (`tMapID`) REFERENCES `transformmap_config` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transformmap_mapping`
--

/*!40000 ALTER TABLE `transformmap_mapping` DISABLE KEYS */;
/*!40000 ALTER TABLE `transformmap_mapping` ENABLE KEYS */;


--
-- Definition of table `ud_act_exec_order`
--

DROP TABLE IF EXISTS `ud_act_exec_order`;
CREATE TABLE `ud_act_exec_order` (
  `Activities_Execution_Id` int(11) NOT NULL AUTO_INCREMENT,
  `activity_software_Map_Id` int(10) unsigned NOT NULL,
  `Linked_Activity_Id` int(10) unsigned NOT NULL,
  `Execution_Order` int(11) NOT NULL,
  PRIMARY KEY (`Activities_Execution_Id`),
  KEY `FK_actvts_exc_ordr_actvty_sftwr_mp_id_3` (`activity_software_Map_Id`),
  KEY `FK_actvts_exc_ordr_actvty_sftwr_mp_id_4` (`Linked_Activity_Id`),
  CONSTRAINT `FK_actvts_exc_ordr_actvty_sftwr_mp_id_3` FOREIGN KEY (`activity_software_Map_Id`) REFERENCES `ud_act_soft_map` (`activity_software_map_id`),
  CONSTRAINT `FK_actvts_exc_ordr_actvty_sftwr_mp_id_4` FOREIGN KEY (`Linked_Activity_Id`) REFERENCES `ud_act_soft_map` (`activity_software_map_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ud_act_exec_order`
--

/*!40000 ALTER TABLE `ud_act_exec_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `ud_act_exec_order` ENABLE KEYS */;


--
-- Definition of table `ud_act_proc_order`
--

DROP TABLE IF EXISTS `ud_act_proc_order`;
CREATE TABLE `ud_act_proc_order` (
  `Activity_Process_Id` int(11) NOT NULL AUTO_INCREMENT,
  `Udeploy_Soft_Proc_Map_Id` int(11) NOT NULL,
  `Process_Order` int(11) NOT NULL,
  `Activity_Sftwr_Map_Id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`Activity_Process_Id`),
  KEY `FK_UDEPLOY_Activity_Process_Order_2` (`Udeploy_Soft_Proc_Map_Id`),
  CONSTRAINT `FK_UDEPLOY_Activity_Process_Order_2` FOREIGN KEY (`Udeploy_Soft_Proc_Map_Id`) REFERENCES `ud_soft_proc_map` (`Software_process_map_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ud_act_proc_order`
--

/*!40000 ALTER TABLE `ud_act_proc_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `ud_act_proc_order` ENABLE KEYS */;


--
-- Definition of table `ud_act_soft_map`
--

DROP TABLE IF EXISTS `ud_act_soft_map`;
CREATE TABLE `ud_act_soft_map` (
  `activity_software_map_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `software_config_Id` int(10) unsigned NOT NULL,
  `activity_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`activity_software_map_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ud_act_soft_map`
--

/*!40000 ALTER TABLE `ud_act_soft_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `ud_act_soft_map` ENABLE KEYS */;


--
-- Definition of table `ud_soft_proc_map`
--

DROP TABLE IF EXISTS `ud_soft_proc_map`;
CREATE TABLE `ud_soft_proc_map` (
  `Software_process_map_Id` int(11) NOT NULL AUTO_INCREMENT,
  `software_config_Id` int(11) NOT NULL,
  `udeploy_process_Id` int(11) NOT NULL,
  PRIMARY KEY (`Software_process_map_Id`),
  KEY `FK_ud_soft_proc_map_1` (`software_config_Id`),
  KEY `FK_ud_soft_proc_map_2` (`udeploy_process_Id`),
  CONSTRAINT `FK_ud_soft_proc_map_1` FOREIGN KEY (`software_config_Id`) REFERENCES `softwareconfig` (`id`),
  CONSTRAINT `FK_ud_soft_proc_map_2` FOREIGN KEY (`udeploy_process_Id`) REFERENCES `udeploy_process` (`Process_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ud_soft_proc_map`
--

/*!40000 ALTER TABLE `ud_soft_proc_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `ud_soft_proc_map` ENABLE KEYS */;


--
-- Definition of table `udeploy_process`
--

DROP TABLE IF EXISTS `udeploy_process`;
CREATE TABLE `udeploy_process` (
  `Process_Id` int(11) NOT NULL AUTO_INCREMENT,
  `Process_Full_Path` varchar(200) NOT NULL DEFAULT '',
  `Status` varchar(5) NOT NULL,
  PRIMARY KEY (`Process_Id`),
  UNIQUE KEY `udeploy_process_Index` (`Process_Full_Path`),
  KEY `Unique_Index_ud` (`Process_Full_Path`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `udeploy_process`
--

/*!40000 ALTER TABLE `udeploy_process` DISABLE KEYS */;
/*!40000 ALTER TABLE `udeploy_process` ENABLE KEYS */;


--
-- Definition of table `udeploy_process_parameters`
--

DROP TABLE IF EXISTS `udeploy_process_parameters`;
CREATE TABLE `udeploy_process_parameters` (
  `parameter_Id` int(11) NOT NULL AUTO_INCREMENT,
  `process_Id` int(11) NOT NULL,
  `parameter_path_name` varchar(200) NOT NULL,
  `parameter_value` varchar(200) DEFAULT NULL,
  `status` varchar(3) DEFAULT NULL,
  `netra_parameter_name` varchar(100) DEFAULT NULL,
  `netra_parameter_mapping` varchar(2) DEFAULT 'N',
  `parameter_scope` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`parameter_Id`),
  UNIQUE KEY `FK_udeploy_process_parameters_1` (`process_Id`,`parameter_path_name`),
  CONSTRAINT `FK_udeploy_process_parameters_1` FOREIGN KEY (`process_Id`) REFERENCES `udeploy_process` (`Process_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `udeploy_process_parameters`
--

/*!40000 ALTER TABLE `udeploy_process_parameters` DISABLE KEYS */;
/*!40000 ALTER TABLE `udeploy_process_parameters` ENABLE KEYS */;


--
-- Definition of table `udeploy_server_details`
--

DROP TABLE IF EXISTS `udeploy_server_details`;
CREATE TABLE `udeploy_server_details` (
  `udeploy_server_id` int(11) NOT NULL AUTO_INCREMENT,
  `udeploy_server_USERNAME` varchar(110) NOT NULL,
  `udeploy_server_PASSWORD` varchar(110) NOT NULL,
  `udeploy_server_IPADDR` varchar(111) NOT NULL,
  `udeploy_server_STATUS` varchar(250) DEFAULT NULL,
  `udeploy_server_URL` varchar(250) DEFAULT NULL,
  `udeploy_server_HOSTNAME` varchar(20) NOT NULL,
  `udeploy_server_SHARENAME` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`udeploy_server_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `udeploy_server_details`
--

/*!40000 ALTER TABLE `udeploy_server_details` DISABLE KEYS */;
INSERT INTO `udeploy_server_details` (`udeploy_server_id`,`udeploy_server_USERNAME`,`udeploy_server_PASSWORD`,`udeploy_server_IPADDR`,`udeploy_server_STATUS`,`udeploy_server_URL`,`udeploy_server_HOSTNAME`,`udeploy_server_SHARENAME`) VALUES 
 (1,'admin','admin','10.130.25.71','ACT','https://10.130.25.71:8080','TESTVM1','CHNSIRASUVM135');
/*!40000 ALTER TABLE `udeploy_server_details` ENABLE KEYS */;


--
-- Definition of table `udeploy_task_mapping`
--

DROP TABLE IF EXISTS `udeploy_task_mapping`;
CREATE TABLE `udeploy_task_mapping` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `taskId` int(11) unsigned NOT NULL,
  `Process_Order` int(11) NOT NULL,
  `Udeploy_process_Id` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Udeploy_process_mapping` (`Udeploy_process_Id`),
  KEY `FK_Udeploy_task_mapping` (`taskId`),
  CONSTRAINT `FK_Udeploy_process_mapping` FOREIGN KEY (`Udeploy_process_Id`) REFERENCES `udeploy_process` (`Process_Id`),
  CONSTRAINT `FK_Udeploy_task_mapping` FOREIGN KEY (`taskId`) REFERENCES `tasks` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `udeploy_task_mapping`
--

/*!40000 ALTER TABLE `udeploy_task_mapping` DISABLE KEYS */;
/*!40000 ALTER TABLE `udeploy_task_mapping` ENABLE KEYS */;


--
-- Definition of table `user_business_unit`
--

DROP TABLE IF EXISTS `user_business_unit`;
CREATE TABLE `user_business_unit` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `client_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_user_business_unit_1` (`user_id`),
  CONSTRAINT `FK_user_business_unit_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_business_unit`
--

/*!40000 ALTER TABLE `user_business_unit` DISABLE KEYS */;
INSERT INTO `user_business_unit` (`id`,`user_id`,`client_id`) VALUES 
 (1,1,0),
 (2,2,0),
 (3,3,2),
 (4,4,2),
 (6,6,2),
 (7,5,2);
/*!40000 ALTER TABLE `user_business_unit` ENABLE KEYS */;


--
-- Definition of table `user_defined_env_params`
--

DROP TABLE IF EXISTS `user_defined_env_params`;
CREATE TABLE `user_defined_env_params` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `env_id` int(10) unsigned NOT NULL,
  `nolio_param_id` int(10) unsigned NOT NULL,
  `nolio_param_value` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_defined_env_params`
--

/*!40000 ALTER TABLE `user_defined_env_params` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_defined_env_params` ENABLE KEYS */;


--
-- Definition of table `user_defined_rel_params`
--

DROP TABLE IF EXISTS `user_defined_rel_params`;
CREATE TABLE `user_defined_rel_params` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rel_id` int(10) unsigned NOT NULL,
  `nolio_param_id` int(10) unsigned DEFAULT NULL,
  `nolio_param_value` varchar(500) CHARACTER SET latin1 DEFAULT NULL,
  `script_param_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_defined_rel_params`
--

/*!40000 ALTER TABLE `user_defined_rel_params` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_defined_rel_params` ENABLE KEYS */;


--
-- Definition of table `user_group_details`
--

DROP TABLE IF EXISTS `user_group_details`;
CREATE TABLE `user_group_details` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `GROUP_ID` int(10) unsigned NOT NULL,
  `USER_ID` int(11) NOT NULL,
  `CREATED_BY` int(10) unsigned DEFAULT NULL,
  `CREATED_DATE` datetime DEFAULT NULL,
  `MODIFIED_BY` int(10) unsigned DEFAULT NULL,
  `MODIFIED_DATE` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `user_id` (`USER_ID`),
  KEY `FK_user_group_details_1` (`GROUP_ID`),
  CONSTRAINT `FK_user_group_details_1` FOREIGN KEY (`GROUP_ID`) REFERENCES `user_groups` (`ID`),
  CONSTRAINT `FK_user_group_details_2` FOREIGN KEY (`USER_ID`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_group_details`
--

/*!40000 ALTER TABLE `user_group_details` DISABLE KEYS */;
INSERT INTO `user_group_details` (`ID`,`GROUP_ID`,`USER_ID`,`CREATED_BY`,`CREATED_DATE`,`MODIFIED_BY`,`MODIFIED_DATE`) VALUES 
 (1,1,3,NULL,NULL,NULL,NULL),
 (2,1,4,NULL,NULL,NULL,NULL),
 (3,1,5,NULL,NULL,NULL,NULL),
 (4,1,6,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `user_group_details` ENABLE KEYS */;


--
-- Definition of table `user_groups`
--

DROP TABLE IF EXISTS `user_groups`;
CREATE TABLE `user_groups` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `NAME` varchar(45) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_groups`
--

/*!40000 ALTER TABLE `user_groups` DISABLE KEYS */;
INSERT INTO `user_groups` (`ID`,`NAME`) VALUES 
 (1,'UG1');
/*!40000 ALTER TABLE `user_groups` ENABLE KEYS */;


--
-- Definition of table `userprivileges`
--

DROP TABLE IF EXISTS `userprivileges`;
CREATE TABLE `userprivileges` (
  `id` int(11) NOT NULL,
  `roleId` int(11) NOT NULL,
  PRIMARY KEY (`id`,`roleId`),
  KEY `roleId` (`roleId`),
  CONSTRAINT `FK_userprivileges_1` FOREIGN KEY (`id`) REFERENCES `users` (`id`),
  CONSTRAINT `FK_userprivileges_2` FOREIGN KEY (`roleId`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userprivileges`
--

/*!40000 ALTER TABLE `userprivileges` DISABLE KEYS */;
INSERT INTO `userprivileges` (`id`,`roleId`) VALUES 
 (1,0),
 (2,1),
 (3,1),
 (4,2),
 (5,3),
 (6,4);
/*!40000 ALTER TABLE `userprivileges` ENABLE KEYS */;


--
-- Definition of table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `passwordenc` varchar(256) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `phone` varchar(16) DEFAULT NULL,
  `fullname` varchar(45) DEFAULT NULL,
  `lastpasswordchanged` datetime DEFAULT NULL,
  `CLIENT_ID` int(10) unsigned DEFAULT NULL,
  `USER_SOURCE` varchar(4) DEFAULT 'TEMS',
  `CREATED_BY` int(10) unsigned DEFAULT NULL,
  `CREATED_DATE` datetime DEFAULT NULL,
  `MODIFIED_BY` int(10) unsigned DEFAULT NULL,
  `MODIFIED_DATE` datetime DEFAULT NULL,
  `STATUS` int(10) unsigned DEFAULT NULL,
  `supervisorid` int(10) unsigned DEFAULT NULL,
  `Address` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`,`name`,`passwordenc`,`email`,`phone`,`fullname`,`lastpasswordchanged`,`CLIENT_ID`,`USER_SOURCE`,`CREATED_BY`,`CREATED_DATE`,`MODIFIED_BY`,`MODIFIED_DATE`,`STATUS`,`supervisorid`,`Address`) VALUES 
 (1,'demo','$2a$04$iOOzYnTd9VQg1F7jzZOjde4tN/CoPXc0UcmF25eeNAWyiKTm.28gu','Receiver.Test@tcsdev.com','123456987','demo','2013-12-23 00:00:00',0,'TEMS',NULL,NULL,1,'2013-12-23 00:00:00',11,NULL,NULL),
 (2,'op_user','$2a$10$qCgxZthpmk9N7D6ySEeQwOI.je/O3ypqQipTUL4NA2g2YJu/QlVKa','op@abc.com','','op user','2016-07-04 00:00:00',0,'TEMS',1,'2016-07-04 13:38:27',2,'2016-07-04 00:00:00',11,NULL,''),
 (3,'alex','$2a$10$NNQupj0ARxShLdW1jp4jT.esYbLIrfxHXMPO0XI8LSyTLbrgo/xmW','alex@abc.com','','alex','2016-07-04 00:00:00',2,'TEMS',2,'2016-07-04 13:40:44',3,'2016-07-04 00:00:00',11,NULL,''),
 (4,'mathew','$2a$10$rvHPP8XBgTwaobMS5FI9AOFUwegJ2LxRptPK3DpsKbfnuJUd9FCYe','mathew@abc.com','','mathew',NULL,2,'TEMS',3,'2016-07-04 14:07:00',0,NULL,11,3,''),
 (5,'lina','$2a$10$vI12JlpMwMyzxdWA1TlHFuNQ3cbHjCrluHfrcSTA3zbEo/U6iSoKa','lina@abc.com','','lina',NULL,2,'TEMS',3,'2016-07-04 14:07:21',5,'2016-07-04 00:00:00',11,4,''),
 (6,'nils','$2a$10$fQOVWEcqjIYAZCIBPesUW.wqu8ig47uk0C7wG4k/e9u.6KQDn1qWG','nils@abc.com','','nils',NULL,2,'TEMS',3,'2016-07-04 14:07:48',0,NULL,11,5,'');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;


--
-- Definition of table `vsphere_details`
--

DROP TABLE IF EXISTS `vsphere_details`;
CREATE TABLE `vsphere_details` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DataCenterName` varchar(45) NOT NULL,
  `URL` varchar(45) NOT NULL,
  `Username` varchar(45) NOT NULL,
  `Password` varchar(45) NOT NULL,
  `Server_Type` varchar(45) NOT NULL,
  `Tenant` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vsphere_details`
--

/*!40000 ALTER TABLE `vsphere_details` DISABLE KEYS */;
INSERT INTO `vsphere_details` (`id`,`DataCenterName`,`URL`,`Username`,`Password`,`Server_Type`,`Tenant`) VALUES 
 (1,'ASU LAB Siruseri','https://10.130.25.14/sdk','test','M+LOgOgTgoVYZLXLPZsXkinHOPvpTkXw','D',NULL);
/*!40000 ALTER TABLE `vsphere_details` ENABLE KEYS */;


--
-- Definition of table `wf_current`
--

DROP TABLE IF EXISTS `wf_current`;
CREATE TABLE `wf_current` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `level_order` int(10) unsigned NOT NULL,
  `wf_status_id` int(10) unsigned NOT NULL,
  `wf_update_date` datetime NOT NULL,
  `createdby` int(10) unsigned NOT NULL,
  `createdate` datetime NOT NULL,
  `lastupdatedby` int(10) unsigned NOT NULL,
  `lastupdatedate` datetime NOT NULL,
  `currentownerid` int(11) NOT NULL,
  `wf_id` int(10) unsigned NOT NULL,
  `client_id` int(10) unsigned NOT NULL,
  `project_id` int(10) unsigned NOT NULL,
  `application_id` int(10) unsigned DEFAULT NULL,
  `environment_id` int(10) unsigned DEFAULT NULL,
  `entity_id` int(11) DEFAULT NULL,
  `request_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`,`createdate`),
  KEY `FK_wf_current_1` (`wf_id`),
  KEY `FK_wf_current_2` (`client_id`),
  KEY `FK_wf_current_4` (`application_id`),
  KEY `FK_wf_current_3` (`project_id`),
  KEY `FK_wf_current_5` (`environment_id`),
  KEY `FK_wf_current_6` (`wf_status_id`),
  KEY `FK_wf_current_7` (`currentownerid`),
  KEY `FK_entityId` (`entity_id`),
  CONSTRAINT `FK_wf_current_1` FOREIGN KEY (`wf_id`) REFERENCES `wrkflw_mstr` (`wf_id`),
  CONSTRAINT `FK_wf_current_2` FOREIGN KEY (`client_id`) REFERENCES `client` (`CLIENT_ID`),
  CONSTRAINT `FK_wf_current_3` FOREIGN KEY (`project_id`) REFERENCES `projects` (`ID`),
  CONSTRAINT `FK_wf_current_4` FOREIGN KEY (`application_id`) REFERENCES `applications` (`ID`),
  CONSTRAINT `FK_wf_current_5` FOREIGN KEY (`environment_id`) REFERENCES `environments` (`ID`),
  CONSTRAINT `FK_wf_current_6` FOREIGN KEY (`wf_status_id`) REFERENCES `wf_status` (`wf_status_id`),
  CONSTRAINT `FK_wf_current_7` FOREIGN KEY (`currentownerid`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wf_current`
--

/*!40000 ALTER TABLE `wf_current` DISABLE KEYS */;
INSERT INTO `wf_current` (`id`,`level_order`,`wf_status_id`,`wf_update_date`,`createdby`,`createdate`,`lastupdatedby`,`lastupdatedate`,`currentownerid`,`wf_id`,`client_id`,`project_id`,`application_id`,`environment_id`,`entity_id`,`request_id`) VALUES 
 (1,0,3,'2016-07-04 00:00:00',3,'2016-07-04 00:00:00',3,'2016-07-04 00:00:00',3,1,2,1,1,1,NULL,1),
 (2,0,3,'2016-07-04 00:00:00',3,'2016-07-04 00:00:00',3,'2016-07-04 00:00:00',3,1,2,1,1,2,NULL,2),
 (3,0,3,'2016-07-04 00:00:00',3,'2016-07-04 00:00:00',3,'2016-07-04 00:00:00',3,1,2,1,1,3,NULL,3),
 (4,1,3,'2016-07-04 00:00:00',3,'2016-07-04 00:00:00',3,'2016-07-04 00:00:00',3,3,2,1,1,1,1,NULL),
 (5,0,3,'2016-07-04 00:00:00',3,'2016-07-04 00:00:00',3,'2016-07-04 00:00:00',3,1,2,1,1,4,NULL,4),
 (6,0,3,'2016-07-05 00:00:00',3,'2016-07-05 00:00:00',3,'2016-07-05 00:00:00',3,16,2,1,1,3,NULL,6),
 (7,0,3,'2016-07-05 00:00:00',3,'2016-07-05 00:00:00',3,'2016-07-05 00:00:00',3,1,2,1,1,5,NULL,7),
 (8,0,3,'2016-07-05 00:00:00',3,'2016-07-05 00:00:00',3,'2016-07-05 00:00:00',3,1,2,1,1,6,NULL,8),
 (9,0,3,'2016-07-07 00:00:00',3,'2016-07-07 00:00:00',3,'2016-07-07 00:00:00',3,1,2,1,1,7,NULL,9);
INSERT INTO `wf_current` (`id`,`level_order`,`wf_status_id`,`wf_update_date`,`createdby`,`createdate`,`lastupdatedby`,`lastupdatedate`,`currentownerid`,`wf_id`,`client_id`,`project_id`,`application_id`,`environment_id`,`entity_id`,`request_id`) VALUES 
 (10,0,3,'2016-07-07 00:00:00',3,'2016-07-07 00:00:00',3,'2016-07-07 00:00:00',3,1,2,1,1,8,NULL,10),
 (11,0,3,'2016-07-07 00:00:00',3,'2016-07-07 00:00:00',3,'2016-07-07 00:00:00',3,16,2,1,1,8,NULL,13),
 (12,0,3,'2016-07-07 00:00:00',3,'2016-07-07 00:00:00',3,'2016-07-07 00:00:00',3,16,2,1,1,8,NULL,14),
 (13,0,3,'2016-07-07 00:00:00',3,'2016-07-07 00:00:00',3,'2016-07-07 00:00:00',3,4,2,1,1,8,NULL,16),
 (14,0,3,'2016-07-07 00:00:00',3,'2016-07-07 00:00:00',3,'2016-07-07 00:00:00',3,15,2,1,1,2,NULL,17),
 (15,0,3,'2016-07-07 00:00:00',3,'2016-07-07 00:00:00',3,'2016-07-07 00:00:00',3,15,2,1,1,8,NULL,18),
 (16,0,3,'2016-07-07 00:00:00',3,'2016-07-07 00:00:00',3,'2016-07-07 00:00:00',3,4,2,1,1,8,NULL,19),
 (17,0,3,'2016-07-07 00:00:00',3,'2016-07-07 00:00:00',3,'2016-07-07 00:00:00',3,12,2,1,1,8,NULL,20),
 (18,0,3,'2016-07-11 00:00:00',3,'2016-07-11 00:00:00',3,'2016-07-11 00:00:00',3,1,2,1,1,9,NULL,21);
INSERT INTO `wf_current` (`id`,`level_order`,`wf_status_id`,`wf_update_date`,`createdby`,`createdate`,`lastupdatedby`,`lastupdatedate`,`currentownerid`,`wf_id`,`client_id`,`project_id`,`application_id`,`environment_id`,`entity_id`,`request_id`) VALUES 
 (19,0,3,'2016-07-11 00:00:00',3,'2016-07-11 00:00:00',3,'2016-07-11 00:00:00',3,1,2,1,1,10,NULL,22),
 (20,0,3,'2016-07-11 00:00:00',3,'2016-07-11 00:00:00',3,'2016-07-11 00:00:00',3,16,2,1,1,9,NULL,23),
 (21,0,3,'2016-07-11 00:00:00',3,'2016-07-11 00:00:00',3,'2016-07-11 00:00:00',3,16,2,1,1,10,NULL,24),
 (22,0,3,'2016-07-11 00:00:00',3,'2016-07-11 00:00:00',3,'2016-07-11 00:00:00',3,1,2,1,1,11,NULL,27),
 (23,0,3,'2016-07-12 00:00:00',3,'2016-07-12 00:00:00',3,'2016-07-12 00:00:00',3,16,2,1,1,9,NULL,29),
 (24,0,3,'2016-07-12 00:00:00',3,'2016-07-12 00:00:00',3,'2016-07-12 00:00:00',3,1,2,1,1,12,NULL,30),
 (25,0,3,'2016-07-13 00:00:00',3,'2016-07-13 00:00:00',3,'2016-07-13 00:00:00',3,1,2,1,1,13,NULL,31),
 (26,0,3,'2016-07-13 00:00:00',3,'2016-07-13 00:00:00',3,'2016-07-13 00:00:00',3,1,2,1,1,14,NULL,32);
/*!40000 ALTER TABLE `wf_current` ENABLE KEYS */;


--
-- Definition of table `wf_history`
--

DROP TABLE IF EXISTS `wf_history`;
CREATE TABLE `wf_history` (
  `wf_history_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `wf_id` int(10) unsigned NOT NULL,
  `client_id` int(10) unsigned NOT NULL,
  `project_id` int(10) unsigned NOT NULL,
  `level_order` int(10) unsigned NOT NULL,
  `status_changed_to` int(10) unsigned DEFAULT NULL,
  `status_changed_by_role` int(10) unsigned DEFAULT NULL,
  `status_changed_by_name` varchar(45) NOT NULL,
  `status_changed_id` int(11) NOT NULL,
  `status_change_date` datetime DEFAULT NULL,
  `comments` varchar(1024) DEFAULT NULL,
  `createdby` int(10) unsigned NOT NULL,
  `createdate` datetime NOT NULL,
  `lastupdatedby` int(10) unsigned DEFAULT NULL,
  `lastupdatedate` datetime DEFAULT NULL,
  `message_to_user` varchar(1024) DEFAULT NULL,
  `application_id` int(10) unsigned DEFAULT NULL,
  `wf_current_id` int(10) unsigned NOT NULL,
  `environment_id` int(10) unsigned DEFAULT NULL,
  `entity_id` int(10) unsigned DEFAULT NULL,
  `action_performed_by` int(10) DEFAULT NULL,
  `action_performed_by_name` varchar(60) DEFAULT NULL,
  `action_performed_by_role` int(10) DEFAULT NULL,
  PRIMARY KEY (`wf_history_id`),
  KEY `FK_wf_history_1` (`wf_id`),
  KEY `FK_wf_history_2` (`client_id`),
  KEY `FK_wf_history_3` (`project_id`),
  KEY `FK_wf_history_4` (`application_id`),
  KEY `FK_wf_history_5` (`environment_id`),
  KEY `FK_wf_history_6` (`wf_current_id`),
  KEY `FK_wf_history_7` (`status_changed_to`),
  KEY `FK_wf_history_8` (`status_changed_id`),
  CONSTRAINT `FK_wf_history_1` FOREIGN KEY (`wf_id`) REFERENCES `wrkflw_mstr` (`wf_id`),
  CONSTRAINT `FK_wf_history_2` FOREIGN KEY (`client_id`) REFERENCES `client` (`CLIENT_ID`),
  CONSTRAINT `FK_wf_history_3` FOREIGN KEY (`project_id`) REFERENCES `projects` (`ID`),
  CONSTRAINT `FK_wf_history_4` FOREIGN KEY (`application_id`) REFERENCES `applications` (`ID`),
  CONSTRAINT `FK_wf_history_5` FOREIGN KEY (`environment_id`) REFERENCES `environments` (`ID`),
  CONSTRAINT `FK_wf_history_6` FOREIGN KEY (`wf_current_id`) REFERENCES `wf_current` (`id`),
  CONSTRAINT `FK_wf_history_7` FOREIGN KEY (`status_changed_to`) REFERENCES `wf_status` (`wf_status_id`),
  CONSTRAINT `FK_wf_history_8` FOREIGN KEY (`status_changed_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wf_history`
--

/*!40000 ALTER TABLE `wf_history` DISABLE KEYS */;
INSERT INTO `wf_history` (`wf_history_id`,`wf_id`,`client_id`,`project_id`,`level_order`,`status_changed_to`,`status_changed_by_role`,`status_changed_by_name`,`status_changed_id`,`status_change_date`,`comments`,`createdby`,`createdate`,`lastupdatedby`,`lastupdatedate`,`message_to_user`,`application_id`,`wf_current_id`,`environment_id`,`entity_id`,`action_performed_by`,`action_performed_by_name`,`action_performed_by_role`) VALUES 
 (1,1,2,1,0,1,1,'alex',3,'2016-07-04 00:00:00',NULL,3,'2016-07-04 00:00:00',NULL,NULL,NULL,1,1,1,NULL,NULL,NULL,NULL),
 (2,1,2,1,0,1,1,'alex',3,'2016-07-04 00:00:00',NULL,3,'2016-07-04 00:00:00',NULL,NULL,NULL,1,2,2,NULL,NULL,NULL,NULL),
 (3,1,2,1,0,1,1,'alex',3,'2016-07-04 00:00:00',NULL,3,'2016-07-04 00:00:00',NULL,NULL,NULL,1,3,3,NULL,NULL,NULL,NULL),
 (4,3,2,1,0,1,1,'alex',3,'2016-07-04 00:00:00',NULL,3,'2016-07-04 00:00:00',NULL,NULL,NULL,1,4,1,1,NULL,NULL,NULL),
 (5,3,2,1,1,4,1,'alex',3,'2016-07-04 00:00:00','ok',3,'2016-07-04 00:00:00',3,'2016-07-04 00:00:00','ok',1,4,1,NULL,3,'alex',1),
 (6,1,2,1,0,1,1,'alex',3,'2016-07-04 00:00:00',NULL,3,'2016-07-04 00:00:00',NULL,NULL,NULL,1,5,4,NULL,NULL,NULL,NULL);
INSERT INTO `wf_history` (`wf_history_id`,`wf_id`,`client_id`,`project_id`,`level_order`,`status_changed_to`,`status_changed_by_role`,`status_changed_by_name`,`status_changed_id`,`status_change_date`,`comments`,`createdby`,`createdate`,`lastupdatedby`,`lastupdatedate`,`message_to_user`,`application_id`,`wf_current_id`,`environment_id`,`entity_id`,`action_performed_by`,`action_performed_by_name`,`action_performed_by_role`) VALUES 
 (7,16,2,1,0,1,1,'alex',3,'2016-07-05 00:00:00',NULL,3,'2016-07-05 00:00:00',NULL,NULL,NULL,1,6,3,NULL,NULL,NULL,NULL),
 (8,1,2,1,0,1,1,'alex',3,'2016-07-05 00:00:00',NULL,3,'2016-07-05 00:00:00',NULL,NULL,NULL,1,7,5,NULL,NULL,NULL,NULL),
 (9,1,2,1,0,1,1,'alex',3,'2016-07-05 00:00:00',NULL,3,'2016-07-05 00:00:00',NULL,NULL,NULL,1,8,6,NULL,NULL,NULL,NULL),
 (10,1,2,1,0,1,1,'alex',3,'2016-07-07 00:00:00',NULL,3,'2016-07-07 00:00:00',NULL,NULL,NULL,1,9,7,NULL,NULL,NULL,NULL),
 (11,1,2,1,0,1,1,'alex',3,'2016-07-07 00:00:00',NULL,3,'2016-07-07 00:00:00',NULL,NULL,NULL,1,10,8,NULL,NULL,NULL,NULL),
 (12,16,2,1,0,1,1,'alex',3,'2016-07-07 00:00:00',NULL,3,'2016-07-07 00:00:00',NULL,NULL,NULL,1,11,8,NULL,NULL,NULL,NULL);
INSERT INTO `wf_history` (`wf_history_id`,`wf_id`,`client_id`,`project_id`,`level_order`,`status_changed_to`,`status_changed_by_role`,`status_changed_by_name`,`status_changed_id`,`status_change_date`,`comments`,`createdby`,`createdate`,`lastupdatedby`,`lastupdatedate`,`message_to_user`,`application_id`,`wf_current_id`,`environment_id`,`entity_id`,`action_performed_by`,`action_performed_by_name`,`action_performed_by_role`) VALUES 
 (13,16,2,1,0,1,1,'alex',3,'2016-07-07 00:00:00',NULL,3,'2016-07-07 00:00:00',NULL,NULL,NULL,1,12,8,NULL,NULL,NULL,NULL),
 (14,4,2,1,0,1,1,'alex',3,'2016-07-07 00:00:00',NULL,3,'2016-07-07 00:00:00',NULL,NULL,NULL,1,13,8,NULL,NULL,NULL,NULL),
 (15,15,2,1,0,1,1,'alex',3,'2016-07-07 00:00:00',NULL,3,'2016-07-07 00:00:00',NULL,NULL,NULL,1,14,2,NULL,NULL,NULL,NULL),
 (16,15,2,1,0,1,1,'alex',3,'2016-07-07 00:00:00',NULL,3,'2016-07-07 00:00:00',NULL,NULL,NULL,1,15,8,NULL,NULL,NULL,NULL),
 (17,4,2,1,0,1,1,'alex',3,'2016-07-07 00:00:00',NULL,3,'2016-07-07 00:00:00',NULL,NULL,NULL,1,16,8,NULL,NULL,NULL,NULL),
 (18,12,2,1,0,1,1,'alex',3,'2016-07-07 00:00:00',NULL,3,'2016-07-07 00:00:00',NULL,NULL,NULL,1,17,8,NULL,NULL,NULL,NULL);
INSERT INTO `wf_history` (`wf_history_id`,`wf_id`,`client_id`,`project_id`,`level_order`,`status_changed_to`,`status_changed_by_role`,`status_changed_by_name`,`status_changed_id`,`status_change_date`,`comments`,`createdby`,`createdate`,`lastupdatedby`,`lastupdatedate`,`message_to_user`,`application_id`,`wf_current_id`,`environment_id`,`entity_id`,`action_performed_by`,`action_performed_by_name`,`action_performed_by_role`) VALUES 
 (19,1,2,1,0,1,1,'alex',3,'2016-07-11 00:00:00',NULL,3,'2016-07-11 00:00:00',NULL,NULL,NULL,1,18,9,NULL,NULL,NULL,NULL),
 (20,1,2,1,0,1,1,'alex',3,'2016-07-11 00:00:00',NULL,3,'2016-07-11 00:00:00',NULL,NULL,NULL,1,19,10,NULL,NULL,NULL,NULL),
 (21,16,2,1,0,1,1,'alex',3,'2016-07-11 00:00:00',NULL,3,'2016-07-11 00:00:00',NULL,NULL,NULL,1,20,9,NULL,NULL,NULL,NULL),
 (22,16,2,1,0,1,1,'alex',3,'2016-07-11 00:00:00',NULL,3,'2016-07-11 00:00:00',NULL,NULL,NULL,1,21,10,NULL,NULL,NULL,NULL),
 (23,1,2,1,0,1,1,'alex',3,'2016-07-11 00:00:00',NULL,3,'2016-07-11 00:00:00',NULL,NULL,NULL,1,22,11,NULL,NULL,NULL,NULL),
 (24,16,2,1,0,1,1,'alex',3,'2016-07-12 00:00:00',NULL,3,'2016-07-12 00:00:00',NULL,NULL,NULL,1,23,9,NULL,NULL,NULL,NULL);
INSERT INTO `wf_history` (`wf_history_id`,`wf_id`,`client_id`,`project_id`,`level_order`,`status_changed_to`,`status_changed_by_role`,`status_changed_by_name`,`status_changed_id`,`status_change_date`,`comments`,`createdby`,`createdate`,`lastupdatedby`,`lastupdatedate`,`message_to_user`,`application_id`,`wf_current_id`,`environment_id`,`entity_id`,`action_performed_by`,`action_performed_by_name`,`action_performed_by_role`) VALUES 
 (25,1,2,1,0,1,1,'alex',3,'2016-07-12 00:00:00',NULL,3,'2016-07-12 00:00:00',NULL,NULL,NULL,1,24,12,NULL,NULL,NULL,NULL),
 (26,1,2,1,0,1,1,'alex',3,'2016-07-13 00:00:00',NULL,3,'2016-07-13 00:00:00',NULL,NULL,NULL,1,25,13,NULL,NULL,NULL,NULL),
 (27,1,2,1,0,1,1,'alex',3,'2016-07-13 00:00:00',NULL,3,'2016-07-13 00:00:00',NULL,NULL,NULL,1,26,14,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `wf_history` ENABLE KEYS */;


--
-- Definition of table `wf_level`
--

DROP TABLE IF EXISTS `wf_level`;
CREATE TABLE `wf_level` (
  `wf_level_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `wf_id` int(10) unsigned NOT NULL,
  `client_id` int(10) unsigned NOT NULL,
  `level_order` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`wf_level_id`),
  KEY `FK_wf_level_1` (`wf_id`),
  KEY `FK_wf_level_2` (`client_id`),
  CONSTRAINT `FK_wf_level_1` FOREIGN KEY (`wf_id`) REFERENCES `wrkflw_mstr` (`wf_id`),
  CONSTRAINT `FK_wf_level_2` FOREIGN KEY (`client_id`) REFERENCES `client` (`CLIENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wf_level`
--

/*!40000 ALTER TABLE `wf_level` DISABLE KEYS */;
/*!40000 ALTER TABLE `wf_level` ENABLE KEYS */;


--
-- Definition of table `wf_status`
--

DROP TABLE IF EXISTS `wf_status`;
CREATE TABLE `wf_status` (
  `wf_status_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status_name` varchar(45) NOT NULL,
  PRIMARY KEY (`wf_status_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wf_status`
--

/*!40000 ALTER TABLE `wf_status` DISABLE KEYS */;
INSERT INTO `wf_status` (`wf_status_id`,`status_name`) VALUES 
 (1,'Requested'),
 (2,'Pending'),
 (3,'Completed'),
 (4,'Approved'),
 (5,'Rejected'),
 (6,'Cancelled'),
 (7,'Auto Rejected');
/*!40000 ALTER TABLE `wf_status` ENABLE KEYS */;


--
-- Definition of table `wrkflw_mstr`
--

DROP TABLE IF EXISTS `wrkflw_mstr`;
CREATE TABLE `wrkflw_mstr` (
  `wf_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `wf_name` varchar(45) NOT NULL,
  `wf_desc` varchar(45) DEFAULT NULL,
  `Linked_Service_Id` int(10) unsigned DEFAULT NULL,
  `wf_req` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`wf_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wrkflw_mstr`
--

/*!40000 ALTER TABLE `wrkflw_mstr` DISABLE KEYS */;
INSERT INTO `wrkflw_mstr` (`wf_id`,`wf_name`,`wf_desc`,`Linked_Service_Id`,`wf_req`) VALUES 
 (1,'Create Environment','Create Environment',NULL,'Y'),
 (2,'Edit Environment','Edit Environment',NULL,'Y'),
 (3,'Make Reservation','Make Reservation',NULL,'Y'),
 (4,'Database Refresh','Database Refresh',2,'Y'),
 (5,'VM Reconfiguration','Virtual Machine Reconfiguration',3,'N'),
 (6,'Application Deployment','Application Deployment',5,'Y'),
 (7,'Application Release Rollback','Application Release Rollback',NULL,'Y'),
 (8,'Promote','Promote',NULL,'Y'),
 (9,'Restart Server','Restart Server',9,'N'),
 (10,'Application Undeployment','Application Undeployment',NULL,'Y'),
 (11,'Create E2E Environment','Create E2E Environment',12,'Y'),
 (12,'Test Execution','Test Execution',6,'Y'),
 (13,'Agent Deployment','Agent Deployment',NULL,'N'),
 (14,'Build','build',15,'Y'),
 (15,'Release Deployment','Release Deployment',20,'Y'),
 (16,'Software Installation','Software Installation',16,'Y'),
 (17,'Deployment Pipeline','Deployment Pipeline',NULL,'Y'),
 (18,'Code Analysis','Code Analysis',19,'N');
INSERT INTO `wrkflw_mstr` (`wf_id`,`wf_name`,`wf_desc`,`Linked_Service_Id`,`wf_req`) VALUES 
 (20,'Mobility Testing','Mobility Testing',25,'Y');
/*!40000 ALTER TABLE `wrkflw_mstr` ENABLE KEYS */;


--
-- Definition of table `zabbix_software_mapping`
--

DROP TABLE IF EXISTS `zabbix_software_mapping`;
CREATE TABLE `zabbix_software_mapping` (
  `template_id` int(11) NOT NULL,
  `template_name` varchar(100) NOT NULL,
  `software_config_id` int(11) NOT NULL,
  PRIMARY KEY (`template_id`,`software_config_id`),
  KEY `FK_zabbix_software_mapping_1` (`software_config_id`),
  CONSTRAINT `FK_zabbix_software_mapping_1` FOREIGN KEY (`software_config_id`) REFERENCES `softwareconfig` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `zabbix_software_mapping`
--

/*!40000 ALTER TABLE `zabbix_software_mapping` DISABLE KEYS */;
INSERT INTO `zabbix_software_mapping` (`template_id`,`template_name`,`software_config_id`) VALUES 
 (10110,'Template App Jboss',2),
 (10111,'Template App Oracle',1);
/*!40000 ALTER TABLE `zabbix_software_mapping` ENABLE KEYS */;


--
-- Definition of table `zabbix_trigger_function`
--

DROP TABLE IF EXISTS `zabbix_trigger_function`;
CREATE TABLE `zabbix_trigger_function` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `function_name` varchar(200) DEFAULT NULL,
  `function_formt` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `zabbix_trigger_function`
--

/*!40000 ALTER TABLE `zabbix_trigger_function` DISABLE KEYS */;
INSERT INTO `zabbix_trigger_function` (`id`,`function_name`,`function_formt`) VALUES 
 (1,'abschange',''),
 (2,'avg','(sec|#num,<time_shift>)'),
 (3,'change',''),
 (4,'band','(sec|#num,mask,<time_shift>)'),
 (5,'count','(sec|#num,<pattern>,<operator>,<time_shift>)'),
 (6,'date',''),
 (7,'date',''),
 (8,'dayofmonth',''),
 (9,'dayofweek',''),
 (10,'delta','(sec|#num,<time_shift>)'),
 (11,'diff',''),
 (12,'fuzzytime','(sec)'),
 (13,'iregexp','(pattern,<sec|#num>)'),
 (14,'last','(sec|#num,<time_shift>)'),
 (15,'logeventid','(pattern)'),
 (16,'logseverity',''),
 (17,'logsource','(pattern)'),
 (18,'max','(sec|#num,<time_shift>)'),
 (19,'min','(sec|#num,<time_shift>)'),
 (20,'nodata','(sec)'),
 (21,'now',''),
 (22,'percentile','(sec|#num,<time_shift>,percentage)'),
 (23,'prev',''),
 (24,'regexp','(pattern,<sec|#num>)'),
 (25,'str','(pattern,<sec|#num>)'),
 (26,'strlen','(sec|#num,<time_shift>)'),
 (27,'sum','(sec|#num,<time_shift>)'),
 (28,'time','');
/*!40000 ALTER TABLE `zabbix_trigger_function` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
