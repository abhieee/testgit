package com.ext.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.hibernate.HibernateException;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.AWSDAO;
import com.framework.exception.CMMException;
import com.framework.to.AWSAccountTO;
import com.framework.to.MachineTemplateAwsTO;
import com.framework.to.MachineTemplateTO;
import com.framework.to.PlatformTemplateAwsTO;
import com.framework.to.PlatformTemplateTO;
import com.framework.to.aws.AWSEC2ImageTO;

/**
 * This is the implementing class of AWSDAO interface. The task of this class is to handle all the database transactions of NETRA. Note : This class is not to
 * be used for calling any service of AWS and only tasked to interact with the local database of the application.
 *
 * @author TCS
 */
public class AWSDAOImpl extends HibernateDaoSupport implements AWSDAO {
	private static final String PBLMENCOUNTEREDGETAWSACCOUNT = "Problem encountered. AWSDAOImpl : getAWSAccount";
	private static final String PBLMENCOUNTEREDADDIMAGES = "Problem encountered. AWSDAOImpl : addImageToTemplates";
	
	/**
	 * Fetches all the aws accounts that have been added to the database.
	 *
	 * @return List of all the accounts in database
	 * @throws CMMException
	 */
	@Override
	public List<AWSAccountTO> getAllAWSAccountsList() throws CMMException {
	
		try {
			return (List<AWSAccountTO>) getHibernateTemplate().find("from AWSAccountTO");
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. AWSDAOImpl : getAllAWSAccountsList", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. AWSDAOImpl : getAllAWSAccountsList", he);
		}
	}
	
	/**
	 * Checks whether a aws account exists with the given name or not.
	 *
	 * @param awsAccountName
	 *                the name of the account which needs to be matched
	 * @return true if account exists, false otherwise
	 * @throws CMMException
	 */
	@Override
	public boolean checkAWSAccountExists(String awsAccountName) throws CMMException {
	
		DetachedCriteria criteria = DetachedCriteria.forClass(AWSAccountTO.class);
		criteria.add(Restrictions.like("awsAccountName", "%" + awsAccountName + "%"));
		try {
			if (getHibernateTemplate().findByCriteria(criteria).isEmpty()) {
				return true;
			}
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. AWSDAOImpl : checkAWSAccountExists", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. AWSDAOImpl : checkAWSAccountExists", he);
		}
		return false;
	}
	
	/**
	 * Add a AWS Account to the database
	 *
	 * @param awsAccount
	 *                object of AWSAccountTO containing the details of aws account which needs to be added
	 * @throws CMMException
	 */
	@Override
	public void addAWSAccount(AWSAccountTO awsAccount) throws CMMException {
	
		try {
			getHibernateTemplate().save(awsAccount);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. AWSDAOImpl : addAWSAccount", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. AWSDAOImpl : addAWSAccount", he);
		}
	}
	
	/**
	 * Fetches a aws account details based on the account id.
	 *
	 * @param awsAccountId
	 *                id of the aws account as in the database
	 * @return object of AWSAccountTO
	 * @throws CMMException
	 */
	@Override
	public AWSAccountTO getAWSAccount(Long awsAccountId) throws CMMException {
	
		try {
			return getHibernateTemplate().get(AWSAccountTO.class, awsAccountId);
		} catch (DataAccessException dae) {
			throw new CMMException(PBLMENCOUNTEREDGETAWSACCOUNT, dae);
		} catch (HibernateException he) {
			throw new CMMException(PBLMENCOUNTEREDGETAWSACCOUNT, he);
		} catch (NullPointerException npe) {
			throw new CMMException(PBLMENCOUNTEREDGETAWSACCOUNT, npe);
		}
	}
	
	/**
	 * Updates the details of an aws account
	 *
	 * @param awsAccount
	 *                object of AWSAccountTO containing the details of the aws account which needs to be updated.
	 * @throws CMMException
	 */
	@Override
	public void updateAWSAccount(AWSAccountTO awsAccount) throws CMMException {
	
		try {
			getHibernateTemplate().update(awsAccount);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. AWSDAOImpl : updateAWSAccount", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. AWSDAOImpl : updateAWSAccount", he);
		}
	}
	
	/**
	 * Removed an aws account details from the database.
	 *
	 * @param awsAccountId
	 *                id of the aws account which has to be removed.
	 * @throws CMMException
	 */
	@Override
	public void deleteAWSAccount(Long awsAccountId) throws CMMException {
	
		try {
			getHibernateTemplate().delete(getAWSAccount(awsAccountId));
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. AWSDAOImpl : deleteAWSAccount", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. AWSDAOImpl : deleteAWSAccount", he);
		}
	}
	
	/**
	 * Creates a map of the aws credentials which would be used for accessing the AWS services. The key of this map is the Access Key and the value is the
	 * Secure secret key.
	 *
	 * @param awsAccountId
	 *                id of the aws account for which the map needs to be created
	 * @return map of the credentials
	 * @throws CMMException
	 */
	@Override
	public Map<String, String> getCredentialMap(Long awsAccountId) throws CMMException {
	
		try {
			Map<String, String> credentialsMap = new HashMap<String, String>();
			AWSAccountTO account = getAWSAccount(awsAccountId);
			credentialsMap.put("accessKey", account.getAwsAccountAccessKey());
			credentialsMap.put("secretKey", account.getAwsAccountSecretKey());
			return credentialsMap;
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. AWSDAOImpl : getCredentialMap", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. AWSDAOImpl : getCredentialMap", he);
		}
	}
	
	/**
	 * Fetches a list of all the aws platform templates which are tagged to the provided account.
	 *
	 * @param awsAccountId
	 *                id of the aws account
	 * @return list of platform templates for aws
	 * @throws CMMException
	 */
	@Override
	public List<PlatformTemplateAwsTO> getAllPlatformTemplateAws(Long awsAccountId) throws CMMException {
	
		try {
			return (List<PlatformTemplateAwsTO>) getHibernateTemplate().find("from PlatformTemplateAwsTO where awsAccountId = " + awsAccountId + "order by platformTemplate.name");
		} catch (DataAccessException dae) {
			throw new CMMException(PBLMENCOUNTEREDADDIMAGES, dae);
		} catch (HibernateException he) {
			throw new CMMException(PBLMENCOUNTEREDADDIMAGES, he);
		}
	}
	
	/**
	 * Add an aws image to the local database for use in profiles. Only those images which have been added would be available to netra user for environment
	 * creation and deployments.
	 *
	 * @param image
	 *                object of AWSEC2ImageTO for image id
	 * @param awsAccountId
	 *                aws account id for which the image is being added
	 * @param platformTemplate
	 *                the platform details which needs to be added
	 * @return string "IMAGE_EXISTS" in case the images being added already exists or "IMAGE_ADDED" once the image is successfully added.
	 * @throws CMMException
	 */
	@Override
	public String addImageToTemplates(AWSEC2ImageTO image, Long awsAccountId, PlatformTemplateTO platformTemplate) throws CMMException {
	
		try {
			int listSize = getHibernateTemplate().find("from PlatformTemplateAwsTO where imageId=?", image.getImageId()).size();
			if (listSize > 0) {
				return "IMAGE_EXISTS";
			}
			MachineTemplateTO machineTemplate = new MachineTemplateTO();
			platformTemplate.setName(image.getName());
			platformTemplate.setArchitecture(image.getArchitecture());
			PlatformTemplateAwsTO platformTemplateAws = new PlatformTemplateAwsTO();
			platformTemplateAws.setAwsAccountId(awsAccountId);
			platformTemplateAws.setImageId(image.getImageId());
			platformTemplate.getPlatformTemplateAws().add(platformTemplateAws);
			platformTemplateAws.setPlatformTemplate(platformTemplate);
			Long plateformTemplateId = (Long) getHibernateTemplate().save(platformTemplate);
			machineTemplate.setPlatformTemplateId(plateformTemplateId);
			machineTemplate.setType(platformTemplate.getType());
			machineTemplate.setCPU(platformTemplate.getCpu());
			machineTemplate.setRAM(platformTemplate.getRam());
			machineTemplate.setArchitecture(platformTemplate.getArchitecture());
			machineTemplate.setStatus(179L);
			MachineTemplateAwsTO machineTemplateAws = new MachineTemplateAwsTO();
			machineTemplateAws.setAwsAccountId(awsAccountId);
			machineTemplateAws.setSdk("1.7.1");
			machineTemplateAws.setInstanceType(platformTemplate.getInstanceType());
			machineTemplate.getMachineTemplateAws().add(machineTemplateAws);
			machineTemplateAws.setMachineTemplate(machineTemplate);
			getHibernateTemplate().save(machineTemplate);
			return "IMAGE_ADDED";
		} catch (DataAccessException dae) {
			throw new CMMException(PBLMENCOUNTEREDADDIMAGES, dae);
		} catch (HibernateException he) {
			throw new CMMException(PBLMENCOUNTEREDADDIMAGES, he);
		}
	}
	
	/**
	 * Fetches machine templates for aws. Note : It fetches only those aws templates which have sdk 1.7.1
	 *
	 * @return list of machine templates of aws
	 * @throws CMMException
	 */
	@Override
	public List<MachineTemplateAwsTO> getAllMachineTemplateAws() throws CMMException {
	
		try {
			return (List<MachineTemplateAwsTO>) getHibernateTemplate().find("from MachineTemplateAwsTO where sdk='1.7.1' group by instanceType order by instanceType ");
		} catch (DataAccessException dae) {
			throw new CMMException(PBLMENCOUNTEREDADDIMAGES, dae);
		} catch (HibernateException he) {
			throw new CMMException(PBLMENCOUNTEREDADDIMAGES, he);
		} catch (Exception e) {
			throw new CMMException(PBLMENCOUNTEREDADDIMAGES, e);
		}
	}
}
