package com.ext.dao.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.util.StringUtils;
import com.ext.dao.BulkUploadDAO;
import com.framework.common.PasswordEncryptorUtil;
import com.framework.exception.CMMException;
import com.framework.to.BUMapConfigTO;
import com.framework.to.BUMappingTO;
import com.framework.to.BulkUploadSoftwareTO;
import com.framework.to.ProvisionedMachinePhysicalTO;
import com.framework.to.ProvisionedMachineTO;
import com.framework.to.SoftwareTO;
import com.framework.to.SoftwareconfigTO;
import com.framework.to.TemplatesTO;
import com.framework.utility.DateUtils;

public class BulkUploadDAOImpl extends HibernateDaoSupport implements BulkUploadDAO {
	
	@Autowired
	private PasswordEncryptorUtil passwordEncryptorUtil;
	private static final Logger LOG = Logger.getLogger(BulkUploadDAOImpl.class);
	Date currentDate = DateUtils.getStartTime(new Date());
	private String dbName;
	
	public String getDbName() {
	
		return dbName;
	}
	
	public void setDbName(String dbName) {
	
		this.dbName = dbName;
	}
	
	@Override
	public List<String> uploadHardware(List<ProvisionedMachineTO> hardwares) throws CMMException {
	
		List<String> comments = new ArrayList<>();
		int flag = 0;
		try {
			int i = 1;
			for (ProvisionedMachineTO machineTemp : hardwares) {
				ProvisionedMachinePhysicalTO proMachPhysical = machineTemp.getProMachPhysical();
				List<TemplatesTO> unit = (List<TemplatesTO>) getHibernateTemplate().find("from ProvisionedMachineTO where name=?", machineTemp.getName());
				if (unit.isEmpty()) {
					machineTemp.getProvisionedPlatform().setProvisionedMachine(new HashSet<ProvisionedMachineTO>());
					Long provisionedPlatformTemplateId = (Long) getHibernateTemplate().save(machineTemp.getProvisionedPlatform());
					machineTemp.setProvisionedPlatformTemplateId(provisionedPlatformTemplateId);
					Long proMachine = (Long) getHibernateTemplate().save(machineTemp);
					proMachPhysical.setProvisionedMachineId(proMachine);
					proMachPhysical.setPassword(passwordEncryptorUtil.encrypt(machineTemp.getProMachPhysical().getPassword()));
					getHibernateTemplate().save(proMachPhysical);
				} else {
					flag++;
					comments.add("Hardware Name already exists for row no. " + i);
				}
				i++;
			}
			if (flag > 0) {
				comments.add(" Rest of the Hardwares(if any) have been added. ");
			}
			return comments;
		} catch (DataAccessException | HibernateException e) {
			LOG.error(e);
			throw new CMMException("Problem encountered.BulkUploadDAOImpl:uploadHardware", e);
		}
	}
	
	@Override
	public List<String> uploadSoftware(List<BulkUploadSoftwareTO> softwares) throws CMMException {
	
		List<String> comments = new ArrayList<>();
		int flag = 0;
		try {
			int i = 1;
			for (BulkUploadSoftwareTO sw : softwares) {
				List<SoftwareTO> unit = (List<SoftwareTO>) getHibernateTemplate().find("from SoftwareTO where name=?", sw.getName());
				SoftwareconfigTO unit1 = new SoftwareconfigTO();
				if (!unit.isEmpty()) {
					unit1 = (SoftwareconfigTO) getHibernateTemplate().find("from SoftwareconfigTO where deviceId=?", unit.get(0).getId()).get(0);
				}
				if (unit.isEmpty()) {
					SoftwareTO swTemp = new SoftwareTO();
					swTemp.setName(sw.getName());
					swTemp.setModel(sw.getModel());
					swTemp.setManufacturer(sw.getManufacturer());
					swTemp.setType(sw.getType());
					swTemp.setCreatedById(sw.getCreatedById());
					swTemp.setCreatedByDate(currentDate);
					SoftwareconfigTO temp = new SoftwareconfigTO();
					temp.setRemark(sw.getRemark());
					temp.setVersion(sw.getVersion());
					temp.setEffectiveDate(DateUtils.getStartTime(new Date()));
					temp.setStatusId(61L);
					temp.setSoftware(swTemp);
					temp.setCreatedById(sw.getCreatedById());
					temp.setCreatedByDate(currentDate);
					swTemp.getSoftwareconfigs().add(temp);
					getHibernateTemplate().save(swTemp);
				} else if (unit1.getVersion().equalsIgnoreCase(sw.getVersion().trim())) {
					SoftwareTO swTemp = unit.get(0);
					swTemp.setModel(sw.getModel());
					swTemp.setManufacturer(sw.getManufacturer());
					swTemp.setType(sw.getType());
					swTemp.setModifiedbyId(sw.getCreatedById());
					swTemp.setModifiedbyDate(currentDate);
					unit1.setRemark(sw.getRemark());
					unit1.setEffectiveDate(DateUtils.getStartTime(new Date()));
					unit1.setStatusId(61L);
					unit1.setSoftware(swTemp);
					unit1.setModifiedbyId(sw.getCreatedById());
					unit1.setModifiedbyDate(currentDate);
					getHibernateTemplate().update(swTemp);
					getHibernateTemplate().update(unit1);
					flag++;
				} else {
					comments.add(" Software Name already exists for row no. " + i + ". ");
				}
				i++;
			}
			if (flag > 0) {
				comments.add(flag + " Softwares were modified. ");
				comments.add("Rest of the Softwares(if any) have been added. ");
				comments.add("comments");
			}
			return comments;
		} catch (DataAccessException | HibernateException e) {
			LOG.error(e);
			throw new CMMException("Problem encountered.BulkUploadDAOImpl:uploadSoftware", e);
		}
	}
	
	@Override
	public boolean saveTMap(BUMapConfigTO buMapConfigTO, BUMappingTO buColumnMapping) throws CMMException {
	
		try {
			getHibernateTemplate().save(buMapConfigTO);
			Long tmapID = buMapConfigTO.getId();
			for (int i = 0; i < buColumnMapping.getNetraColumns().size(); i++) {
				BUMappingTO netrCol = new BUMappingTO();
				netrCol.setbUtMapID(tmapID);
				netrCol.setFileColumn(buColumnMapping.getFileColumns().get(i));
				netrCol.setNetraColumn(buColumnMapping.getNetraColumns().get(i));
				netrCol.setNetraTable(buColumnMapping.getTableNames().get(i));
				getHibernateTemplate().save(netrCol);
			}
			return true;
		} catch (DataAccessException | HibernateException e) {
			logger.error("Problem encountered.BulkUploadDaoImpl:saveTMap", e);
		}
		return false;
	}
	
	@Override
	public boolean checkIfMapNameExists(String mapName) throws CMMException {
	
		List<BUMapConfigTO> mapNames = new ArrayList<>(0);
		try {
			mapNames = (List<BUMapConfigTO>) getHibernateTemplate().find("from BUMapConfigTO");
			for (BUMapConfigTO map : mapNames) {
				if (map.getName().equals(mapName)) {
					return true;
				}
			}
			return false;
		} catch (DataAccessException | HibernateException e) {
			logger.error("Problem encountered.BulkUploadDaoImpl:checkIfMapNameExists", e);
		}
		return true;
	}
	
	@Override
	public List<BUMapConfigTO> searchTmap(String mapName) throws CMMException {
	
		Session session = null;
		List<BUMapConfigTO> buMapConfTOList = new ArrayList<>();
		String query = null;
		try {
			session = getSession();
			query = "select id,name,fileName,net_tab_name" + " from bumap_config";
			if (StringUtils.hasText(mapName)) {
				query = query + " where name  like'" + mapName + "%'";
			}
			Query q = session.createSQLQuery(query);
			List<Object[]> objList = q.list();
			for (Object[] temp : objList) {
				BUMapConfigTO envObj = new BUMapConfigTO();
				envObj.setId(((Integer) temp[0]).longValue());
				envObj.setName((String) temp[1]);
				envObj.setFileName((String) temp[2]);
				envObj.setNetraTableName((String) temp[3]);
				buMapConfTOList.add(envObj);
			}
			return buMapConfTOList;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.BulkUploadDaoImpl:searchTmap.", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.BulkUploadDaoImpl:searchTmap.", he);
		}
	}
	
	@Override
	public BUMapConfigTO fetchTmap(String mapName) throws CMMException {
	
		BUMapConfigTO map = new BUMapConfigTO();
		try {
			map = (BUMapConfigTO) getHibernateTemplate().find("from BUMapConfigTO where name = ?", mapName).get(0);
			return map;
		} catch (DataAccessException | HibernateException e) {
			logger.error("Problem encountered.BulkUploadDaoImpl:fetchTmap", e);
		}
		return map;
	}
	
	@Override
	public List<BUMappingTO> fetchMapping(Long id) throws CMMException {
	
		List<BUMappingTO> maps = new ArrayList<>();
		try {
			maps = (List<BUMappingTO>) getHibernateTemplate().find("from BUMappingTO where bUtMapID = ?", id);
			return maps;
		} catch (DataAccessException | HibernateException e) {
			logger.error("Problem encountered.BulkUploadDaoImpl:fetchMapping", e);
		}
		return maps;
	}
	
	@Override
	public List<Long> saveImportDataParent(String tableName, List<String> fieldNames, List<String[]> data, Long userID) throws CMMException {
	
		Session session = null;
		String query = null;
		String field = "";
		Date date = new Date();
		List<Long> ids = new ArrayList<>();
		Timestamp dt = new Timestamp(date.getTime());
		try {
			for (int j = 0; j < fieldNames.size(); j++) {
				field = field + fieldNames.get(j) + ",";
			}
			Boolean status = checkForColumns(tableName);
			if (status) {
				field = field + "CREATED_BY," + "CREATED_DATE";
			} else {
				field = field.substring(0, field.length() - 1);
			}
			String query1 = "select " + fieldNames.get(0) + " from " + tableName;
			session = getSession();
			Query q = session.createSQLQuery(query1);
			List<String> objList = q.list();
			for (String[] datas : data) {
				Boolean flag = true;
				for (String temp : objList) {
					if (temp.contains(datas[0])) {
						query = "update " + tableName + " set ";
						for (int i = 0; i < fieldNames.size(); i++) {
							query = query + fieldNames.get(i) + "='" + datas[i] + "',";
						}
						if (status) {
							query = query + "MODIFIED_BY='" + userID + "',MODIFIED_DATE='" + dt + "'";
						} else {
							query = query.substring(0, query.length() - 1);
						}
						query = query + " where " + fieldNames.get(0) + "='" + temp + "'";
						Query q2 = session.createSQLQuery(query);
						q2.executeUpdate();
						flag = false;
						break;
					}
				}
				if (flag) {
					query = "insert into " + tableName + " (" + field + ") values ('";
					for (String dat : datas) {
						query = query + dat + "','";
					}
					if (status) {
						query = query + userID + "','" + dt + "')";
					} else {
						query = query.substring(0, query.length() - 2);
						query = query + ")";
					}
					Query q2 = session.createSQLQuery(query);
					q2.executeUpdate();
				}
				query = "select id from " + tableName + " where " + fieldNames.get(0) + "='" + datas[0] + "'";
				q = session.createSQLQuery(query);
				List<Object> objLis = q.list();
				ids.add(((Integer) objLis.get(0)).longValue());
			}
			return ids;
		} catch (DataAccessException | HibernateException e) {
			logger.error("Problem encountered.BulkUploadDAOImpl:saveImportDataParent.", e);
		}
		return ids;
	}
	
	private Boolean checkForColumns(String tableName) throws CMMException {
	
		Boolean status = false;
		Session session = null;
		String query = null;
		try {
			String tableSchema = getDbName();
			query = "Select distinct column_name from INFORMATION_SCHEMA.COLUMNS where table_name='" + tableName + "' and TABLE_SCHEMA='" + tableSchema + "'";
			session = getSession();
			Query q = session.createSQLQuery(query);
			List<String> objList = q.list();
			for (String temp : objList) {
				if ("CREATED_BY".equalsIgnoreCase(temp)) {
					status = true;
				}
			}
		} catch (DataAccessException | HibernateException e) {
			logger.error("Problem encountered.BulkUploadDAOImpl:getColumnNames", e);
		}
		return status;
	}
	
	@Override
	public boolean saveImportDataChild(String tableColName, List<String> fieldNames, List<String[]> data, Long userID, List<Long> ids) throws CMMException {
	
		Session session = null;
		String query = null;
		String field = "";
		Date date = new Date();
		String tableName = tableColName.split("::")[0];
		Timestamp dt = new Timestamp(date.getTime());
		try {
			for (int j = 0; j < fieldNames.size(); j++) {
				field = field + fieldNames.get(j) + ",";
			}
			Boolean status = checkForColumns(tableName);
			field = field + tableColName.split("::")[1];
			if (status) {
				field = field + ",CREATED_BY," + "CREATED_DATE";
			}
			String query1 = "select " + tableColName.split("::")[1] + " from " + tableName;
			session = getSession();
			Query q = session.createSQLQuery(query1);
			List<Object> dbjList = q.list();
			List<Long> dbList = new ArrayList<>();
			for (Object temp : dbjList) {
				dbList.add(((Integer) temp).longValue());
			}
			int z = 0;
			for (Long id : ids) {
				Boolean flag = true;
				for (Long temp : dbList) {
					if (id.equals(temp)) {
						query = "update " + tableName + " set ";
						for (int i = 0; i < fieldNames.size(); i++) {
							query = query + fieldNames.get(i) + "='" + data.get(z)[i] + "',";
						}
						if (status) {
							query = query + "MODIFIED_BY='" + userID + "',MODIFIED_DATE='" + dt + "'";
						} else {
							query = query.substring(0, query.length() - 1);
						}
						query = query + " where " + tableColName.split("::")[1] + "='" + id + "'";
						Query q2 = session.createSQLQuery(query);
						q2.executeUpdate();
						flag = false;
						z++;
						break;
					}
				}
				if (flag) {
					query = "insert into " + tableName + " (" + field + ") values ('";
					for (String dat : data.get(z)) {
						query = query + dat + "','";
					}
					if (status) {
						query = query + id + "','" + userID + "','" + dt + "')";
					} else {
						query = query + id + "')";
					}
					Query q2 = session.createSQLQuery(query);
					q2.executeUpdate();
					z++;
				}
			}
			return true;
		} catch (DataAccessException | HibernateException | IndexOutOfBoundsException e) {
			logger.error("Problem encountered.BulkUploadDAOImpl:saveImportDataChild.", e);
		}
		return false;
	}
}
