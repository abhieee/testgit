package com.ext.dao.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.hibernate.HibernateException;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.ServiceRequestHistoryDAO;
import com.framework.exception.CMMException;
import com.framework.to.BusinessUnitTO;
import com.framework.to.ServiceRequestHistoryTO;
import com.framework.to.ServiceRequestTO;

public class ServiceRequestHistoryDAOImpl extends HibernateDaoSupport implements ServiceRequestHistoryDAO {
	
	@Override
	public boolean updateServiceRequestHistory(Long requestId, String comments) throws CMMException {
	
		try {
			ServiceRequestHistoryTO serviceRequestHistoryTO = new ServiceRequestHistoryTO();
			serviceRequestHistoryTO.setRequestId(requestId);
			serviceRequestHistoryTO.setComments(comments);
			serviceRequestHistoryTO.setCreatedDate(new Date());
			getHibernateTemplate().save(serviceRequestHistoryTO);
			return true;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.ServiceRequestHistoryDAOImpl:updateServiceRequestHistory", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.ServiceRequestHistoryDAOImpl:updateServiceRequestHistory", he);
		}
	}
	
	@Override
	public List<ServiceRequestHistoryTO> getServiceRequestHistoryList(Long requestId) throws CMMException {
	
		try {
			List<ServiceRequestHistoryTO> list = new ArrayList<ServiceRequestHistoryTO>(0);
			list = (List<ServiceRequestHistoryTO>) getHibernateTemplate().find("select name from ServiceRequestHistoryTO where RequestId=?", requestId);
			return list;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.ServiceRequestHistoryDAOImpl:updateServiceRequestHistory", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.ServiceRequestHistoryDAOImpl:updateServiceRequestHistory", he);
		}
	}
	
	@Override
	public ServiceRequestTO fetchPipeLineRequestDetails(Long requestId) throws CMMException {
	
		try {
			List<ServiceRequestTO> list = (List<ServiceRequestTO>) getHibernateTemplate().find("from ServiceRequestTO where id=?", requestId);
			if (!list.isEmpty()) {
				BusinessUnitTO buTo = (BusinessUnitTO) getHibernateTemplate().find("from BusinessUnitTO where id=?", list.get(0).getUserTO().getClientId()).get(0);
				list.get(0).setBusinessUnitTO(buTo);
				return list.get(0);
			} else {
				logger.error("The Request Details cannot be retrieved : Request id " + requestId);
				throw new CMMException("Problem encountered.Please conatct Administrator.The Request Details cannot be retrieved.");
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.Please conatct Administrator.", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.Problem encountered.Please conatct Administrator.", he);
		}
	}
	
	@Override
	public List<ServiceRequestTO> fetchChildPipeLineRequestDetails(Long parentRequestId) throws CMMException {
	
		try {
			return (List<ServiceRequestTO>) getHibernateTemplate().find("from ServiceRequestTO where parentRequestId=?", parentRequestId);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.Please conatct Administrator.", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.Please conatct Administrator.", he);
		}
	}
	
	@Override
	public List<ServiceRequestTO> fetchServicesForSelectedEnvironment(Long selectedEnvironment, Long parentRequestId) throws CMMException {
	
		try {
			return (List<ServiceRequestTO>) getHibernateTemplate().find("from ServiceRequestTO where parentRequestId=? and environmentId=? order by childRequestExecutionOrder asc", parentRequestId, selectedEnvironment);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.Please conatct Administrator.", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.Please conatct Administrator.", he);
		}
	}
}
