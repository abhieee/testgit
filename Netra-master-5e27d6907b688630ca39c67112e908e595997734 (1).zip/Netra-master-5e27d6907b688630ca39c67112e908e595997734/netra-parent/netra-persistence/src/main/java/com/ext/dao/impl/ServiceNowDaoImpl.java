package com.ext.dao.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.util.StringUtils;
import com.ext.dao.ServiceNowDao;
import com.framework.common.CMMConstants;
import com.framework.exception.CMMException;
import com.framework.to.ImportTablesTO;
import com.framework.to.PlatformTypeTO;
import com.framework.to.SNColumnMappingTO;
import com.framework.to.ServiceNowConfigTO;
import com.framework.to.ServiceRequestDetailsTO;
import com.framework.to.ServiceRequestTO;
import com.framework.to.TransformMapConfigTO;
import com.framework.to.TransfromMapTO;
import com.framework.to.UserTO;

public class ServiceNowDaoImpl extends HibernateDaoSupport implements ServiceNowDao {
	
	private String dbName;
	
	public String getDbName() {
	
		return dbName;
	}
	
	public void setDbName(String dbName) {
	
		this.dbName = dbName;
	}
	
	@Override
	public ServiceNowConfigTO fetchSNServer(String baseURL) throws CMMException {
	
		ServiceNowConfigTO serviceNowConfigTO = new ServiceNowConfigTO();
		try {
			serviceNowConfigTO = (ServiceNowConfigTO) getHibernateTemplate().find("from ServiceNowConfigTO where baseURL=?", baseURL).get(0);
			return serviceNowConfigTO;
		} catch (DataAccessException | HibernateException e) {
			logger.error("Problem encountered.ServiceNowDaoImpl:fetchSNServer", e);
		}
		return serviceNowConfigTO;
	}
	
	@Override
	public List<TransfromMapTO> fetchColNames(String netraTable) throws CMMException {
	
		Session session = null;
		List<TransfromMapTO> envList = new ArrayList<>();
		String query = null;
		try {
			String tableSchema = getDbName();
			session = getSession();
			query = "Select distinct data_type,column_name,is_nullable from INFORMATION_SCHEMA.COLUMNS where table_name='" + netraTable + "' and TABLE_SCHEMA='" + tableSchema + "'";
			Query q = session.createSQLQuery(query);
			List<Object[]> objList = q.list();
			Long i = (long) 0;
			for (Object[] temp : objList) {
				TransfromMapTO envObj = new TransfromMapTO();
				envObj.setType((String) temp[0]);
				envObj.setId(i);
				String empty = (String) temp[2];
				if (empty.contains("YES")) {
					envObj.setIsNull(true);
					envObj.setColumnNameNetra(netraTable + "::" + (String) temp[1]);
				} else {
					envObj.setIsNull(false);
					envObj.setColumnNameNetra(netraTable + "::" + (String) temp[1] + "*");
				}
				envList.add(envObj);
				i++;
			}
			return envList;
		} catch (DataAccessException | HibernateException e) {
			logger.error("Problem encountered.ServiceNowDaoImpl:fetchColNames", e);
		}
		return envList;
	}
	
	@Override
	public List<String[]> fetchReferenceColNames(List<String> netraTable) throws CMMException {
	
		Session session = null;
		List<String[]> refTables = new ArrayList<>();
		String query = null;
		try {
			String tableSchema = getDbName();
			session = getSession();
			for (String table : netraTable) {
				query = "SELECT distinct table_name,column_name,REFERENCED_TABLE_NAME,REFERENCED_column_NAME FROM information_schema.KEY_COLUMN_USAGE WHERE TABLE_NAME = '" + table + "'" + " And REFERENCED_TABLE_NAME is not null and TABLE_SCHEMA='" + tableSchema + "'";
				Query q = session.createSQLQuery(query);
				List<Object[]> objList = q.list();
				for (Object[] temp : objList) {
					String[] envObj = new String[4];
					envObj[0] = (String) temp[0];
					envObj[1] = (String) temp[1];
					envObj[2] = (String) temp[2];
					envObj[3] = (String) temp[3];
					refTables.add(envObj);
				}
			}
			return refTables;
		} catch (DataAccessException | HibernateException e) {
			logger.error("Problem encountered.ServiceNowDaoImpl:fetchReferenceColNames", e);
		}
		return refTables;
	}
	
	@Override
	public List<String[]> mandateRefTab(List<String[]> refTables) throws CMMException {
	
		Session session = null;
		String query = null;
		List<String[]> refTable = new ArrayList<>();
		try {
			String tableSchema = getDbName();
			session = getSession();
			for (String[] table : refTables) {
				query = "SELECT distinct IS_NULLABLE FROM information_schema.COLUMNS WHERE TABLE_NAME = '" + table[0] + "' and column_name = '" + table[1] + "' and TABLE_SCHEMA = '" + tableSchema + "'";
				Query q = session.createSQLQuery(query);
				List<String> objList = q.list();
				if ("no".equalsIgnoreCase(objList.get(0))) {
					refTable.add(table);
				}
			}
			return refTable;
		} catch (DataAccessException | HibernateException e) {
			logger.error("Problem encountered.ServiceNowDaoImpl:mandateRefTab", e);
		}
		return refTables;
	}
	
	@Override
	public List<ImportTablesTO> searchSNTableNames() throws CMMException {
	
		List<ImportTablesTO> tableNames = new ArrayList<>(0);
		try {
			tableNames = (List<ImportTablesTO>) getHibernateTemplate().find("from ImportTablesTO where tool=?", CMMConstants.Framework.ServiceNowTables.SERVICE_NOW);
			return tableNames;
		} catch (DataAccessException | HibernateException e) {
			logger.error("Problem encountered.ServiceNowDaoImpl:searchSNTableNames", e);
		}
		return tableNames;
	}
	
	@Override
	public List<ImportTablesTO> searchNetraTableNames() throws CMMException {
	
		List<ImportTablesTO> tableNames = new ArrayList<>(0);
		try {
			tableNames = (List<ImportTablesTO>) getHibernateTemplate().find("from ImportTablesTO where tool=?", CMMConstants.Framework.ServiceNowTables.NETRA);
			return tableNames;
		} catch (DataAccessException | HibernateException e) {
			logger.error("Problem encountered.ServiceNowDaoImpl:searchNetraTableNames", e);
		}
		return tableNames;
	}
	
	@Override
	public boolean saveTMap(TransformMapConfigTO transformMapConfigTO, SNColumnMappingTO snColumnMapping) throws CMMException {
	
		try {
			getHibernateTemplate().save(transformMapConfigTO);
			Long tmapID = transformMapConfigTO.getId();
			for (int i = 0; i < snColumnMapping.getNetraColumns().size(); i++) {
				SNColumnMappingTO netrCol = new SNColumnMappingTO();
				netrCol.settMapID(tmapID);
				netrCol.setSnColumn(snColumnMapping.getSnColumns().get(i));
				netrCol.setNetraColumn(snColumnMapping.getNetraColumns().get(i));
				netrCol.setNetraTable(snColumnMapping.getTableNames().get(i));
				netrCol.setSnTable(snColumnMapping.getTableNamesSN().get(i));
				getHibernateTemplate().save(netrCol);
			}
			return true;
		} catch (DataAccessException | HibernateException e) {
			logger.error("Problem encountered.ServiceNowDaoImpl:saveTMap", e);
		}
		return false;
	}
	
	@Override
	public boolean saveEditTMap(TransformMapConfigTO transformMapConfigTO, SNColumnMappingTO snColumnMapping) throws CMMException {
	
		try {
			getHibernateTemplate().update(transformMapConfigTO);
			Session session = getSession();
			String query = "delete from transformmap_mapping where tMapID=" + transformMapConfigTO.getId();
			Query q = session.createSQLQuery(query);
			q.executeUpdate();
			for (int i = 0; i < snColumnMapping.getNetraColumns().size(); i++) {
				SNColumnMappingTO netrCol = new SNColumnMappingTO();
				netrCol.settMapID(transformMapConfigTO.getId());
				netrCol.setSnColumn(snColumnMapping.getSnColumns().get(i));
				netrCol.setNetraColumn(snColumnMapping.getNetraColumns().get(i));
				netrCol.setNetraTable(snColumnMapping.getTableNames().get(i));
				netrCol.setSnTable(snColumnMapping.getTableNamesSN().get(i));
				getHibernateTemplate().save(netrCol);
			}
			return true;
		} catch (DataAccessException | HibernateException e) {
			logger.error("Problem encountered.ServiceNowDaoImpl:saveTMap", e);
		}
		return false;
	}
	
	@Override
	public boolean checkIfMapNameExists(String mapName) throws CMMException {
	
		List<TransformMapConfigTO> mapNames = new ArrayList<>(0);
		try {
			mapNames = (List<TransformMapConfigTO>) getHibernateTemplate().find("from TransformMapConfigTO");
			for (TransformMapConfigTO map : mapNames) {
				if (map.getName().equals(mapName)) {
					return true;
				}
			}
			return false;
		} catch (DataAccessException | HibernateException e) {
			logger.error("Problem encountered.ServiceNowDaoImpl:checkIfMapNameExists", e);
		}
		return true;
	}
	
	@Override
	public boolean checkIfBaseURLExists(String baseURL) throws CMMException {
	
		List<ServiceNowConfigTO> servers = new ArrayList<>(0);
		try {
			servers = (List<ServiceNowConfigTO>) getHibernateTemplate().find("from ServiceNowConfigTO");
			for (ServiceNowConfigTO map : servers) {
				if (map.getBaseURL().contains(baseURL)) {
					return true;
				}
			}
			return false;
		} catch (DataAccessException | HibernateException e) {
			logger.error("Problem encountered.ServiceNowDaoImpl:checkIfBaseURLExists", e);
		}
		return false;
	}
	
	@Override
	public List<TransformMapConfigTO> searchTMaps(String mapName) throws CMMException {
	
		Session session = null;
		List<TransformMapConfigTO> mapList = new ArrayList<>();
		String query = null;
		try {
			session = getSession();
			query = "select ID,name,baseURL,sn_tab_name,local_tab_name" + " from transformmap_config";
			if (StringUtils.hasText(mapName)) {
				query = query + " where name  like'" + mapName + "%'";
			}
			Query q = session.createSQLQuery(query);
			List<Object[]> objList = q.list();
			for (Object[] temp : objList) {
				TransformMapConfigTO map = new TransformMapConfigTO();
				map.setId(((Integer) temp[0]).longValue());
				map.setName((String) temp[1]);
				map.setBaseURL((String) temp[2]);
				map.setSnTableName((String) temp[3]);
				map.setNetraTableName((String) temp[4]);
				mapList.add(map);
			}
			return mapList;
		} catch (DataAccessException | HibernateException e) {
			logger.error("Problem encountered.ServiceNowDaoImpl:searchTMaps.", e);
		}
		return mapList;
	}
	
	@Override
	public TransformMapConfigTO getTransformConfigData(String mapName) throws CMMException {
	
		TransformMapConfigTO map = new TransformMapConfigTO();
		try {
			map = (TransformMapConfigTO) getHibernateTemplate().find("from TransformMapConfigTO where name=?", mapName).get(0);
			return map;
		} catch (DataAccessException | HibernateException e) {
			logger.error("Problem encountered.ServiceNowDaoImpl:getTransformConfigData", e);
		}
		return map;
	}
	
	@Override
	public List<SNColumnMappingTO> getColumnNames(Long tMapId) throws CMMException {
	
		List<SNColumnMappingTO> columns = new ArrayList<>();
		try {
			columns = (List<SNColumnMappingTO>) getHibernateTemplate().find("from SNColumnMappingTO where tMapID=?", tMapId);
			return columns;
		} catch (DataAccessException | HibernateException e) {
			logger.error("Problem encountered.ServiceNowDaoImpl:getColumnNames", e);
		}
		return columns;
	}
	
	private Boolean checkForColumns(String tableName) throws CMMException {
	
		Boolean status = false;
		Session session = null;
		String query = null;
		try {
			String tableSchema = getDbName();
			query = "Select distinct column_name from INFORMATION_SCHEMA.COLUMNS where table_name='" + tableName + "' and TABLE_SCHEMA='" + tableSchema + "'";
			session = getSession();
			Query q = session.createSQLQuery(query);
			List<String> objList = q.list();
			for (String temp : objList) {
				if ("CREATED_BY".equalsIgnoreCase(temp)) {
					status = true;
				}
			}
		} catch (DataAccessException | HibernateException e) {
			logger.error("Problem encountered.ServiceNowDaoImpl:getColumnNames", e);
		}
		return status;
	}
	
	@Override
	public List<Long> saveImportDataParent(String tableName, List<String> fieldNames, List<String[]> data, UserTO userTo) throws CMMException {
	
		Session session = null;
		String query = null;
		String field = "";
		Date date = new Date();
		List<Long> ids = new ArrayList<>();
		Timestamp dt = new Timestamp(date.getTime());
		try {
			for (int j = 0; j < fieldNames.size(); j++) {
				field = field + fieldNames.get(j) + ",";
			}
			Boolean status = checkForColumns(tableName);
			if (status) {
				field = field + "CREATED_BY," + "CREATED_DATE";
			} else {
				field = field.substring(0, field.length() - 1);
			}
			String query1 = "select " + fieldNames.get(0) + " from " + tableName;
			session = getSession();
			Query q = session.createSQLQuery(query1);
			List<String> objList = q.list();
			for (String[] datas : data) {
				Boolean flag = true;
				for (String temp : objList) {
					if (temp.contains(datas[0])) {
						query = "update " + tableName + " set ";
						for (int i = 0; i < fieldNames.size(); i++) {
							query = query + fieldNames.get(i) + "='" + datas[i] + "',";
						}
						if (status) {
							query = query + "MODIFIED_BY='" + userTo.getId() + "',MODIFIED_DATE='" + dt + "'";
						} else {
							query = query.substring(0, query.length() - 1);
						}
						query = query + " where " + fieldNames.get(0) + "='" + temp + "'";
						Query q2 = session.createSQLQuery(query);
						q2.executeUpdate();
						flag = false;
						break;
					}
				}
				if (flag) {
					query = "insert into " + tableName + " (" + field + ") values ('";
					for (String dat : datas) {
						query = query + dat + "','";
					}
					if (status) {
						query = query + userTo.getId() + "','" + dt + "')";
					} else {
						query = query.substring(0, query.length() - 2);
						query = query + ")";
					}
					Query q2 = session.createSQLQuery(query);
					q2.executeUpdate();
				}
				query = "select id from " + tableName + " where " + fieldNames.get(0) + "='" + datas[0] + "'";
				q = session.createSQLQuery(query);
				List<Object> objLis = q.list();
				ids.add(((Integer) objLis.get(0)).longValue());
			}
			return ids;
		} catch (DataAccessException | HibernateException e) {
			logger.error("Problem encountered.ServiceNowDaoImpl:saveImportDataParent.", e);
		}
		return ids;
	}
	
	@Override
	public boolean saveImportDataChild(String tableColName, List<String> fieldNames, List<String[]> data, UserTO userTo, List<Long> ids) throws CMMException {
	
		Session session = null;
		String query = null;
		String field = "";
		Date date = new Date();
		String tableName = tableColName.split("::")[0];
		Timestamp dt = new Timestamp(date.getTime());
		try {
			for (int j = 0; j < fieldNames.size(); j++) {
				field = field + fieldNames.get(j) + ",";
			}
			Boolean status = checkForColumns(tableName);
			field = field + tableColName.split("::")[1];
			if (status) {
				field = field + ",CREATED_BY," + "CREATED_DATE";
			}
			String query1 = "select " + tableColName.split("::")[1] + " from " + tableName;
			session = getSession();
			Query q = session.createSQLQuery(query1);
			List<Object> dbjList = q.list();
			List<Long> dbList = new ArrayList<>();
			for (Object temp : dbjList) {
				dbList.add(((Integer) temp).longValue());
			}
			int z = 0;
			for (Long id : ids) {
				Boolean flag = true;
				for (Long temp : dbList) {
					if (id.equals(temp)) {
						query = "update " + tableName + " set ";
						for (int i = 0; i < fieldNames.size(); i++) {
							query = query + fieldNames.get(i) + "='" + data.get(z)[i] + "',";
						}
						if (status) {
							query = query + "MODIFIED_BY='" + userTo.getId() + "',MODIFIED_DATE='" + dt + "'";
						} else {
							query = query.substring(0, query.length() - 1);
						}
						query = query + " where " + tableColName.split("::")[1] + "='" + id + "'";
						Query q2 = session.createSQLQuery(query);
						q2.executeUpdate();
						flag = false;
						z++;
						break;
					}
				}
				if (flag) {
					query = "insert into " + tableName + " (" + field + ") values ('";
					for (String dat : data.get(z)) {
						query = query + dat + "','";
					}
					if (status) {
						query = query + id + "','" + userTo.getId() + "','" + dt + "')";
					} else {
						query = query + id + "')";
					}
					Query q2 = session.createSQLQuery(query);
					q2.executeUpdate();
					z++;
				}
			}
			return true;
		} catch (DataAccessException | HibernateException | IndexOutOfBoundsException e) {
			logger.error("Problem encountered.ServiceNowDaoImpl:saveImportDataChild.", e);
		}
		return false;
	}
	
	@Override
	public ServiceRequestTO importDataDB(ServiceRequestTO serviceNowRequestTO, List<Long> tmapID) throws CMMException {
	
		int success = -1;
		try {
			serviceNowRequestTO.setServiceId(CMMConstants.Framework.Service.SERVICE_NOW_IMPORT_ID);
			serviceNowRequestTO.setStatusId(CMMConstants.Framework.Entity.SERVICE_REQUEST_UNDER_IMPLEMENTATION);
			serviceNowRequestTO.setActionFlag(CMMConstants.Framework.ServiceRequestStatus.SERVICE_REQUEST_ACTIVE);
			getHibernateTemplate().save(serviceNowRequestTO);
			Long id = serviceNowRequestTO.getId();
			for (Long tmap : tmapID) {
				ServiceRequestDetailsTO serviceRequestDetailsTO = new ServiceRequestDetailsTO();
				serviceRequestDetailsTO.setRequestId(id);
				serviceRequestDetailsTO.settMapID(tmap);
				getHibernateTemplate().save(serviceRequestDetailsTO);
			}
			serviceNowRequestTO.setSuccess(success);
		} catch (DataAccessException | HibernateException e) {
			logger.error("Problem encountered.ServiceNowDaoImpl:importDataDB.", e);
		}
		return serviceNowRequestTO;
	}
	
	@Override
	public List<ServiceRequestDetailsTO> getServiceRequestDetails(Long requestID) throws CMMException {
	
		List<ServiceRequestDetailsTO> serviceNowRequestTO = new ArrayList<>();
		try {
			serviceNowRequestTO = (List<ServiceRequestDetailsTO>) getHibernateTemplate().find("from ServiceRequestDetailsTO where REQUEST_ID=?", requestID);
		} catch (DataAccessException | HibernateException e) {
			logger.error("Problem encountered.ServiceNowDaoImpl:getServiceRequestDetails", e);
		}
		return serviceNowRequestTO;
	}
	
	@Override
	public ServiceRequestTO getServiceRequest(Long requestID) throws CMMException {
	
		ServiceRequestTO serviceNowRequestTO = new ServiceRequestTO();
		try {
			serviceNowRequestTO = (ServiceRequestTO) getHibernateTemplate().find("from ServiceRequestTO where id=?", requestID).get(0);
		} catch (DataAccessException | HibernateException e) {
			logger.error("Problem encountered.ServiceNowDaoImpl:getServiceRequest", e);
		}
		return serviceNowRequestTO;
	}
	
	@Override
	public TransformMapConfigTO getTransformConfigDataByID(Long tMapId) throws CMMException {
	
		TransformMapConfigTO transMap = new TransformMapConfigTO();
		try {
			transMap = (TransformMapConfigTO) getHibernateTemplate().find("from TransformMapConfigTO where id=?", tMapId).get(0);
		} catch (DataAccessException | HibernateException e) {
			logger.error("Problem encountered.ServiceNowDaoImpl:getTransformConfigDataByID", e);
		}
		return transMap;
	}
	
	@Override
	public void saveSNcols(List<String> snTable, List<TransfromMapTO> tableList) throws CMMException {
	
		List<TransfromMapTO> columns = new ArrayList<>();
		String baseURL = tableList.get(0).getBaseURL();
		for (TransfromMapTO tMap : tableList) {
			TransfromMapTO tMap1 = new TransfromMapTO();
			tMap1.setTableName(tMap.getColumnNameSN().split("::")[0]);
			tMap1.setColumnNameSN(tMap.getColumnNameSN().split("::")[1]);
			tMap1.setType(tMap.getType());
			tMap1.setElement(tMap.getElement().split("::")[1]);
			tMap1.setBaseURL(tMap.getBaseURL());
			columns.add(tMap1);
		}
		try {
			Session session = getSession();
			for (String table : snTable) {
				String query = "delete from sn_columns where tablename = '" + table + "' and baseURL = '" + baseURL + "' ";
				Query q = session.createSQLQuery(query);
				q.executeUpdate();
				for (TransfromMapTO tMap : columns) {
					if (tMap.getTableName().equalsIgnoreCase(table)) {
						getHibernateTemplate().save(tMap);
					}
				}
			}
		} catch (DataAccessException | HibernateException e) {
			logger.error("Problem encountered.ServiceNowDaoImpl:saveSNcols", e);
		}
	}
	
	@Override
	public List<TransfromMapTO> loadSNcols(List<String> snTable, String baseURL) throws CMMException {
	
		List<TransfromMapTO> transMap1 = new ArrayList<>();
		try {
			for (String table : snTable) {
				List<TransfromMapTO> transMap = (List<TransfromMapTO>) getHibernateTemplate().find("from TransfromMapTO where tableName=? AND baseURL=?", table, baseURL);
				for (TransfromMapTO map : transMap) {
					transMap1.add(map);
				}
			}
		} catch (DataAccessException | HibernateException e) {
			logger.error("Problem encountered.ServiceNowDaoImpl:getTransformConfigDataByID", e);
		}
		return transMap1;
	}
	
	@Override
	public boolean snExits(String snTable, String baseURL) throws CMMException {
	
		boolean state = false;
		try {
			List<TransfromMapTO> transMap = (List<TransfromMapTO>) getHibernateTemplate().find("from TransfromMapTO where tableName=? AND baseURL=?", snTable, baseURL);
			if (!transMap.isEmpty()) {
				state = true;
			}
		} catch (DataAccessException | HibernateException e) {
			logger.error("Problem encountered.ServiceNowDaoImpl:snExits", e);
		}
		return state;
	}
	
	@Override
	public List<PlatformTypeTO> getOSDetailsUtility(String value) throws CMMException {
	
		PlatformTypeTO val = new PlatformTypeTO();
		List<PlatformTypeTO> allVals = new ArrayList<>();
		try {
			val = (PlatformTypeTO) getHibernateTemplate().find("from PlatformTypeTO where label=?", value).get(0);
			Session session = getSession();
			String query = "select type,label,value from platform_type where value like'" + val.getValue().split("_")[0] + "%'";
			Query q = session.createSQLQuery(query);
			List<Object[]> objList = q.list();
			for (Object[] temp : objList) {
				PlatformTypeTO map = new PlatformTypeTO();
				map.setType((String) temp[0]);
				map.setLabel((String) temp[1]);
				map.setValue((String) temp[2]);
				allVals.add(map);
			}
			return allVals;
		} catch (DataAccessException | HibernateException e) {
			logger.error("Problem encountered.ServiceNowDaoImpl:getOSDetailsUtility", e);
		}
		return allVals;
	}
}
