package com.ext.dao.impl;

import java.util.ArrayList;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.hibernate.exception.ConstraintViolationException;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.util.StringUtils;
import com.ext.dao.ServiceManagementDAO;
import com.framework.common.CMMConstants;
import com.framework.exception.CMMException;
import com.framework.to.ServiceClientTO;
import com.framework.to.ServiceTO;
import com.framework.to.ServiceTypeTO;
import com.framework.to.StatusTO;

public class ServiceManagementDAOImpl extends HibernateDaoSupport implements ServiceManagementDAO {
	
	@Override
	public List<ServiceTypeTO> getCatalogType() throws CMMException {
	
		try {
			return (List<ServiceTypeTO>) getHibernateTemplate().find("from ServiceTypeTO");
		} catch (DataIntegrityViolationException div) {
			logger.error(div);
			throw new CMMException("Problem encountered.ServiceManagementDAOImpl:getCatalogType", div);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.ServiceManagementDAOImpl:getCatalogType", dae);
		} catch (ConstraintViolationException e) {
			logger.error(e);
			throw new CMMException("Problem encountered.ServiceManagementDAOImpl:getCatalogType", e);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.ServiceManagementDAOImpl:getCatalogType", he);
		}
	}
	
	@Override
	public void getBusinessUnits() {
	
		/* No implementation required at the moment. Method for future use. */
	}
	
	@Override
	public void addService(ServiceTO serviceTO) throws CMMException {
	
		try {
			getHibernateTemplate().saveOrUpdate(serviceTO);
		} catch (DataIntegrityViolationException div) {
			throw new CMMException("Problem encountered.ServiceManagementDAOImpl:addService", div);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered.ServiceManagementDAOImpl:addService", dae);
		} catch (ConstraintViolationException e) {
			throw new CMMException("Problem encountered.ServiceManagementDAOImpl:addService", e);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.ServiceManagementDAOImpl:addService", he);
		}
	}
	
	@Override
	public List<ServiceTO> searchService(ServiceTO serviceTO) throws CMMException {
	
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(ServiceTO.class);
			if (StringUtils.hasText(serviceTO.getName())) {
				criteria.add(Restrictions.ilike("name", "%" + serviceTO.getName() + "%"));
			}
			if ((serviceTO.getSelectedStatus() != null) && (serviceTO.getSelectedStatus() != -1)) {
				criteria.add(Restrictions.eq("statusTO.id", serviceTO.getSelectedStatus()));
			}
			if (serviceTO.getSearchCount() == 0) {
				return (List<ServiceTO>) getHibernateTemplate().findByCriteria(criteria);
			}
			Session session = getSession();
			criteria.getExecutableCriteria(session).setFirstResult(serviceTO.getFirstResult());
			criteria.getExecutableCriteria(session).setMaxResults(serviceTO.getTableSize());
			return (List<ServiceTO>) getHibernateTemplate().findByCriteria(criteria);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.ServiceManagementDAOImpl:searchService", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.ServiceManagementDAOImpl:searchService", he);
		}
	}
	
	@Override
	public ServiceTO getServicesDetails(ServiceTO serviceTO) throws CMMException {
	
		try {
			serviceTO = (ServiceTO) getHibernateTemplate().find("from ServiceTO where id=?", serviceTO.getId()).get(0);
			return serviceTO;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.ServiceManagementDAOImpl:getServicesDetails.", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.ServiceManagementDAOImpl:getServicesDetails", he);
		}
	}
	
	@Override
	public void editService(ServiceTO serviceTOTemp) throws CMMException {
	
		try {
			ServiceTO serviceTO = (ServiceTO) getHibernateTemplate().find("from ServiceTO where id=?", serviceTOTemp.getId()).get(0);
			serviceTO.setName(serviceTOTemp.getName());
			serviceTO.setDescription(serviceTOTemp.getDescription());
			serviceTO.setStatus(serviceTOTemp.getStatus());
			getHibernateTemplate().update(serviceTO);
			serviceTO.getServiceClientTO().clear();
			for (Long client : serviceTOTemp.getSelectedClients()) {
				for (Long role : serviceTOTemp.getSelectedRoles()) {
					ServiceClientTO temp = new ServiceClientTO();
					temp.setClientId(client);
					temp.setRoleId(role);
					temp.setServiceTO(serviceTO);
					serviceTO.getServiceClientTO().add(temp);
					String query = "from ServiceClientTO t where t.clientId=? and t.serviceTO.id=? and t.roleId=?";
					List<ServiceClientTO> ser = (List<ServiceClientTO>) getHibernateTemplate().find(query, client, serviceTOTemp.getId(), role);
					if (ser.isEmpty()) {
						getHibernateTemplate().save(temp);
						getHibernateTemplate().update(serviceTO);
					}
				}
			}
		} catch (DataIntegrityViolationException div) {
			logger.error(div);
			throw new CMMException("Problem Occured in : ServiceManagementDAOImpl : editService : DataIntegrityViolationException", div);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem Occured in : ServiceManagementDAOImpl : editService : DataAccessException", dae);
		} catch (ConstraintViolationException e) {
			logger.error(e);
			throw new CMMException("Problem Occured in : ServiceManagementDAOImpl : editService : ConstraintViolationException", e);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem Occured in : ServiceManagementDAOImpl : editService : HibernateException", he);
		}
	}
	
	@Override
	public List<StatusTO> getStatusList(String entityId) throws CMMException {
	
		try {
			return (List<StatusTO>) getHibernateTemplate().find("from StatusTO where entityId=?", CMMConstants.Framework.Entity.SERVICES);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.ServiceManagementDAOImpl:getStatusList", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.ServiceManagementDAOImpl:getStatusList.", he);
		}
	}
	
	@Override
	public boolean checkExistingService(ServiceTO serviceTO) throws CMMException {
	
		try {
			List<ServiceTO> service = (List<ServiceTO>) getHibernateTemplate().find("from ServiceTO where name=?", serviceTO.getName());
			return !service.isEmpty();
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.ServiceManagementDAOImpl:checkExistingService", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.ServiceManagementDAOImpl:checkExistingService", he);
		}
	}
	
	@Override
	public List<Long> getselectedRoles(List<Long> clients, Long serviceId) throws CMMException {
	
		List<Long> roles = new ArrayList<Long>(0);
		Session session = null;
		try {
			session = getSession();
			session.beginTransaction();
			List<ServiceClientTO> sr = (List<ServiceClientTO>) getHibernateTemplate().find("from ServiceClientTO s where s.serviceTO.id=?", serviceId);
			if (!sr.isEmpty()) {
				String hql = "select role_id from services_client s where client_id in (:clients) and service_id in (:service)";
				Query q = session.createSQLQuery(hql);
				q.setParameterList("clients", clients);
				q.setParameter("service", serviceId);
				roles = q.list();
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.ServiceManagementDAOImpl: getselectedRoles", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.ServiceManagementDAOImpl: getselectedRoles", he);
		}
		return roles;
	}
}
