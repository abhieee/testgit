package com.ext.dao.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.exception.ConstraintViolationException;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.ProjectDao;
import com.framework.common.CMMConstants;
import com.framework.exception.CMMException;
import com.framework.to.BusinessUnitTO;
import com.framework.to.ProjectsTO;
import com.framework.to.StatusTO;
import com.framework.to.UserTO;
import com.framework.utility.DateUtils;

public class ProjectDaoImpl extends HibernateDaoSupport implements ProjectDao {
	
	@Override
	public void addProject(ProjectsTO projectsTO) throws CMMException {
	
		try {
			projectsTO.setCreatedDate(DateUtils.getStartTime(new Date()));
			projectsTO.setClientId(projectsTO.getSelectedClientId());
			getHibernateTemplate().save(projectsTO);
		} catch (DataIntegrityViolationException div) {
			logger.error(div);
			throw new CMMException("Problem encountered.ProjectDaoImpl:addProject", div);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.ProjectDaoImpl:addProject", dae);
		} catch (ConstraintViolationException e) {
			logger.error(e);
			throw new CMMException("Problem encountered.ProjectDaoImpl:addProject", e);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.ProjectDaoImpl:addProject", he);
		}
	}
	
	@Override
	public boolean checkName(ProjectsTO projectsTO) throws CMMException {
	
		boolean flag = false;
		try {
			if (projectsTO.getId() == 0L) {
				List<ProjectsTO> unit = (List<ProjectsTO>) getHibernateTemplate().find("from ProjectsTO where name=?", projectsTO.getName());
				if (!unit.isEmpty()) {
					flag = true;
				} else {
					flag = false;
				}
			} else {
				List<ProjectsTO> unit = (List<ProjectsTO>) getHibernateTemplate().find("from ProjectsTO where name=? and id <> ?", projectsTO.getName(), projectsTO.getId());
				if (!unit.isEmpty()) {
					flag = true;
				} else {
					flag = false;
				}
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.ProjectDaoImpl:checkName.", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.ProjectDaoImpl:checkName.", he);
		}
		return flag;
	}
	
	/**
	 * Search the Business Units for the Logged in User.
	 *
	 * @param clientId
	 *                The Id of the user Logged in.
	 * @return All the Business Units in form of a list.
	 */
	@Override
	public List<BusinessUnitTO> getAllClients(Long clientId) throws CMMException {
	
		try {
			if (clientId == 0) {
				return (List<BusinessUnitTO>) getHibernateTemplate().find("from BusinessUnitTO where clientId<>? and status=? ", clientId, CMMConstants.Framework.Entity.BUSINESS_ACTIVE);
			} else {
				return (List<BusinessUnitTO>) getHibernateTemplate().find("from BusinessUnitTO where clientId=? and status=?", clientId, CMMConstants.Framework.Entity.BUSINESS_ACTIVE);
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.ProjectDaoImpl:getAllClients", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.ProjectDaoImpl:getAllClients", he);
		}
	}
	
	@Override
	public List<StatusTO> getStatusList() throws CMMException {
	
		try {
			return (List<StatusTO>) getHibernateTemplate().find("from StatusTO where entityId=?", CMMConstants.Framework.Entity.PROJECT);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.ProjectDaoImpl:getStatusList", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.ProjectDaoImpl:getStatusList", he);
		}
	}
	
	@Override
	public List<ProjectsTO> searchProject(ProjectsTO projectsTO) throws CMMException {
	
		Session session = null;
		try {
			List<ProjectsTO> projectList = new ArrayList<ProjectsTO>();
			session = getSession();
			if (projectsTO.getClientId() > 0) {
				String Query = "select p,b.name from ProjectsTO p , BusinessUnitTO b where p.clientId = b.clientId and b.clientId in (:clientList)";
				if (!"".equalsIgnoreCase(projectsTO.getName().trim())) {
					String projectname = projectsTO.getName().replace("_", "/_");
					Query = Query + " and (p.name  like '%" + projectname + "%' escape '/' )";
				}
				if (projectsTO.getSelectedClientId() > 0L) {
					Query = Query + " and b.clientId = " + projectsTO.getSelectedClientId();
				}
				if (projectsTO.getSelectedStatus() > 0L) {
					Query = Query + " and p.statusTO.id = " + projectsTO.getSelectedStatus();
				}
				Query q = session.createQuery(Query);
				if (projectsTO.getSearchCount() == 0) {
					q.setParameterList("clientList", projectsTO.getClientIdlist());
					List<Object[]> temp = q.list();
					for (Object[] hd : temp) {
						ProjectsTO project = (ProjectsTO) hd[0];
						project.setBusinessUnitName(hd[1].toString());
						projectList.add(project);
					}
					return projectList;
				}
				q.setFirstResult(projectsTO.getFirstResult());
				q.setMaxResults(projectsTO.getTableSize());
				q.setParameterList("clientList", projectsTO.getClientIdlist());
				List<Object[]> temp = q.list();
				for (Object[] hd : temp) {
					ProjectsTO project = (ProjectsTO) hd[0];
					project.setBusinessUnitName(hd[1].toString());
					projectList.add(project);
				}
			} else {
				String Query = "select p,b.name from ProjectsTO p , BusinessUnitTO b where p.clientId = b.clientId ";
				if (!"".equalsIgnoreCase(projectsTO.getName().trim())) {
					String projectname = projectsTO.getName().replace("_", "/_");
					Query = Query + " and (p.name  like '%" + projectname + "%' escape '/' )";
				}
				if (projectsTO.getSelectedClientId() >= 0L) {
					Query = Query + " and b.clientId = " + projectsTO.getSelectedClientId();
				}
				if (projectsTO.getSelectedStatus() > 0L) {
					Query = Query + " and p.statusTO.id = " + projectsTO.getSelectedStatus();
				}
				Query query = session.createQuery(Query);
				if (projectsTO.getSearchCount() == 0) {
					List<Object[]> temp = query.list();
					for (Object[] hd : temp) {
						ProjectsTO project = (ProjectsTO) hd[0];
						project.setBusinessUnitName(hd[1].toString());
						projectList.add(project);
					}
					return projectList;
				}
				query.setFirstResult(projectsTO.getFirstResult());
				query.setMaxResults(projectsTO.getTableSize());
				List<Object[]> temp = query.list();
				for (Object[] hd : temp) {
					ProjectsTO project = (ProjectsTO) hd[0];
					project.setBusinessUnitName(hd[1].toString());
					projectList.add(project);
				}
			}
			return projectList;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.ProjectDaoImpl:searchProject", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.ProjectDaoImpl:searchProject", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public ProjectsTO getProjectDetails(ProjectsTO projectsTO) throws CMMException {
	
		try {
			ProjectsTO projTO = (ProjectsTO) getHibernateTemplate().find("from ProjectsTO where id=?", projectsTO.getId()).get(0);
			BusinessUnitTO buTO = (BusinessUnitTO) getHibernateTemplate().find("from BusinessUnitTO where id=?", projTO.getClientId()).get(0);
			List<UserTO> userTo = (List<UserTO>) getHibernateTemplate().find("from UserTO");
			projTO.setOwnerList(userTo);
			projTO.setSelectedStatus(projTO.getStatus());
			projTO.setSelectedClientId(projTO.getClientId());
			projTO.setSelectedClientName(buTO.getName());
			projTO.setBusinessUnitName(buTO.getName());
			projTO.setSelectedOwner(projTO.getSelectedOwner());
			return projTO;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.ProjectDaoImpl:getProjectDetails", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.ProjectDaoImpl:getProjectDetails", he);
		}
	}
	
	/**
	 * Updates the details of the selected project.
	 *
	 * @param projectsTO
	 *                Object containing details to be modified.
	 * @return A long value to generate suitable message on the UI.
	 */
	@Override
	public Long editProject(ProjectsTO projectsTO) throws CMMException {
	
		try {
			String Query = "select p.name  from ProjectsTO p , BusinessUnitTO b where p.clientId =b.clientId and b.clientId=?";
			List<String> proj_name = (List<String>) getHibernateTemplate().find(Query, projectsTO.getClientId());
			int count = 0;
			for (String fetch_projName : proj_name) {
				if (fetch_projName.equals(projectsTO.getName())) {
					count++;
				}
				if (count > 1) {
					return -1L;
				}
			}
			projectsTO.setStatus(projectsTO.getSelectedStatus());
			projectsTO.setRemark(projectsTO.getRemark());
			projectsTO.setName(projectsTO.getName());
			getHibernateTemplate().update(projectsTO);
			return 1L;
		} catch (ConstraintViolationException ce) {
			logger.error(ce);
			throw new CMMException("Problem encountered.ProjectDaoImpl:editProject", ce);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.ProjectDaoImpl:editProject", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.ProjectDaoImpl:editProject", he);
		}
	}
	
	@Override
	public List<ProjectsTO> fetchAllProjects() throws CMMException {
	
		try {
			return (List<ProjectsTO>) getHibernateTemplate().find("from ProjectsTO");
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.ProjectDaoImpl : fetchAllProjects", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.ProjectDaoImpl : fetchAllProjects", he);
		}
	}
}
