package com.ext.puppet.dao.Impl;

import java.util.List;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.puppet.dao.PuppetReleaseDao;
import com.framework.exception.CMMException;
import com.framework.puppetMaster.to.PuppetMasterDetailsTO;
import com.framework.puppetMaster.to.PuppetProcess;

public class PuppetReleaseDaoImpl extends HibernateDaoSupport implements PuppetReleaseDao {
	
	private static final Logger LOGGER = Logger.getLogger(PuppetReleaseDaoImpl.class);
	
	@Override
	public List<PuppetMasterDetailsTO> searchPuppetRelease(PuppetMasterDetailsTO puppetMasterDetailsTO) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			Criteria criteria = session.createCriteria(PuppetMasterDetailsTO.class, "puppetMasterDetailsTO");
			if (!"".equalsIgnoreCase(puppetMasterDetailsTO.getIpaddr().trim())) {
				criteria.add(Restrictions.like("ipaddr", "%" + puppetMasterDetailsTO.getIpaddr() + "%"));
			}
			List<PuppetMasterDetailsTO> puppetMasterList = criteria.list();
			if (puppetMasterDetailsTO.getSearchCount() == 0) {
				puppetMasterList = criteria.list();
			} else {
				criteria.setFirstResult(puppetMasterDetailsTO.getFirstResult());
				criteria.setMaxResults(puppetMasterDetailsTO.getTableSize());
				puppetMasterList = criteria.list();
			}
			if (puppetMasterList.isEmpty()) {
				puppetMasterList = null;
				return puppetMasterList;
			} else {
				return puppetMasterList;
			}
		} catch (DataAccessException | HibernateException dae) {
			LOGGER.error("Error in PuppetReleaseDaoImpl:searchPuppetRelease ", dae);
			throw new CMMException("Problem encountered. PuppetReleaseDaoImpl:searchPuppetRelease", dae);
		}
	}
	
	@Override
	public PuppetMasterDetailsTO loadPuppetRelease(PuppetMasterDetailsTO puppeTMasterDetailsTO) throws CMMException {
	
		try {
			return (PuppetMasterDetailsTO) getHibernateTemplate().find("from PuppetMasterDetailsTO where id=?", puppeTMasterDetailsTO.getId()).get(0);
		} catch (DataAccessException | HibernateException dae) {
			LOGGER.error("Error in PuppetReleaseDaoImpl: loadPuppetRelease ", dae);
			throw new CMMException("Problem encountered. PuppetReleaseDaoImpl: loadPuppetRelease", dae);
		}
	}
	
	@Override
	public void editPuppetRelease(PuppetMasterDetailsTO puppeTMasterDetailsTO) throws CMMException {
	
		try {
			getHibernateTemplate().update(puppeTMasterDetailsTO);
		} catch (DataAccessException | HibernateException dae) {
			LOGGER.error("Error in PuppetReleaseDaoImpl: editPuppetRelease ", dae);
			throw new CMMException("Problem encountered. PuppetReleaseDaoImpl: editPuppetRelease", dae);
		}
	}
	
	@Override
	public boolean addPuppetProcessesInDB(List<PuppetProcess> processList) throws CMMException {
	
		boolean flag = false;
		List<PuppetProcess> puppetProcessListDB = (List<PuppetProcess>) getHibernateTemplate().find("from PuppetProcess");
		if (!processList.isEmpty() && !puppetProcessListDB.isEmpty()) {
			LOGGER.debug("puppetProcessListDB size" + puppetProcessListDB.size());
			LOGGER.debug("processList size" + processList.size());
			for (int i = 0; i < puppetProcessListDB.size(); i++) {
				for (int j = 0; j < processList.size(); j++) {
					if (puppetProcessListDB.get(i).getProcessFullPath().equalsIgnoreCase(processList.get(j).getProcessFullPath())) {
						LOGGER.debug(i + "********i-->>>" + puppetProcessListDB.get(i).getProcessFullPath());
						LOGGER.debug(j + "*********j-->>>" + processList.get(j).getProcessFullPath());
						processList.remove(processList.get(j));
					}
				}
			}
			flag = true;
		} else {
			flag = false;
		}
		if (!processList.isEmpty()) {
			for (PuppetProcess process : processList) {
				process.getProcessFullPath();
				process.getStatus();
				LOGGER.debug("process.getProcessFullPath()>>>>" + process.getProcessFullPath());
				getHibernateTemplate().saveOrUpdate(process);
			}
			flag = true;
		}
		return flag;
	}
}
