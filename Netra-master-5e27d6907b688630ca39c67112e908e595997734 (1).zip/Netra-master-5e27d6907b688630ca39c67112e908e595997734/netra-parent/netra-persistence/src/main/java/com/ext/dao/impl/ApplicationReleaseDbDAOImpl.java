/**
 *
 */
package com.ext.dao.impl;

import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.ApplicationReleaseDbDAO;
import com.framework.common.CMMConstants;
import com.framework.exception.CMMException;
import com.framework.to.ApplicationReleaseDbTO;

/**
 * @author 460650
 */
public class ApplicationReleaseDbDAOImpl extends HibernateDaoSupport implements ApplicationReleaseDbDAO {
	
	@Override
	public List<ApplicationReleaseDbTO> fetchAppReleaseDbByRequestId(long requestId, long softwareConfigId, long relTestingPhase) throws CMMException {
	
		Session session = getSession();
		List<ApplicationReleaseDbTO> applicationReleaseDbList;
		try {
			Criteria criteria = session.createCriteria(ApplicationReleaseDbTO.class);
			criteria.add(Restrictions.eq("RequestId", requestId)).add(Restrictions.eq("softwareConfigId", softwareConfigId));
			Criterion allPhaseCriteria = Restrictions.eq("selectedTestingPhase", CMMConstants.Framework.DROPDOWN_SELECTED_VALUE_ALL);
			Criterion selectedPhaseCriteria = Restrictions.eq("selectedTestingPhase", relTestingPhase);
			Disjunction disjunction = Restrictions.disjunction();
			disjunction.add(selectedPhaseCriteria);
			disjunction.add(allPhaseCriteria);
			criteria.add(disjunction).addOrder(Order.asc("id"));
			applicationReleaseDbList = criteria.list();
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.ApplicationReleaseDbDAOImpl:fetchAppReleaseDbByRequestId", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.ApplicationReleaseDbDAOImpl:fetchAppReleaseDbByRequestId", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return applicationReleaseDbList;
	}
	
	@Override
	public List<ApplicationReleaseDbTO> fetchAppReleaseDbByReleaseId(long applicationReleaseId, long softwareConfigId, long relTestingPhase) throws CMMException {
	
		List<ApplicationReleaseDbTO> applicationReleaseDbList;
		Session session = getSession();
		try {
			Criteria criteria = session.createCriteria(ApplicationReleaseDbTO.class);
			criteria.add(Restrictions.eq("applicationRelease.id", applicationReleaseId)).add(Restrictions.eq("softwareConfigId", softwareConfigId));
			Criterion allPhaseCriteria = Restrictions.eq("selectedTestingPhase", CMMConstants.Framework.DROPDOWN_SELECTED_VALUE_ALL);
			Criterion selectedPhaseCriteria = Restrictions.eq("selectedTestingPhase", relTestingPhase);
			Disjunction disjunction = Restrictions.disjunction();
			disjunction.add(selectedPhaseCriteria);
			disjunction.add(allPhaseCriteria);
			criteria.add(disjunction).addOrder(Order.asc("id"));
			applicationReleaseDbList = criteria.list();
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDbDAOImpl : fetchAppReleaseDbByReleaseId ", dae);
		} catch (HibernateException e) {
			logger.error(e);
			throw new CMMException("Problem encountered. ApplicationReleaseDbDAOImpl : fetchAppReleaseDbByReleaseId ", e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return applicationReleaseDbList;
	}
	
	@Override
	public List<ApplicationReleaseDbTO> fetchAppReleaseDbByRequestIdDocker(long requestId, long environmentPhaseId) throws CMMException {
	
		Session session = getSession();
		List<ApplicationReleaseDbTO> applicationReleaseDbList;
		try {
			Criteria criteria = session.createCriteria(ApplicationReleaseDbTO.class);
			criteria.add(Restrictions.eq("RequestId", requestId));
			Criterion allPhaseCriteria = Restrictions.eq("selectedTestingPhase", CMMConstants.Framework.DROPDOWN_SELECTED_VALUE_ALL);
			Criterion selectedPhaseCriteria = Restrictions.eq("selectedTestingPhase", environmentPhaseId);
			Disjunction disjunction = Restrictions.disjunction();
			disjunction.add(selectedPhaseCriteria);
			disjunction.add(allPhaseCriteria);
			criteria.add(disjunction).addOrder(Order.asc("id"));
			applicationReleaseDbList = criteria.list();
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.ApplicationReleaseDbDAOImpl:fetchAppReleaseDbByRequestId", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.ApplicationReleaseDbDAOImpl:fetchAppReleaseDbByRequestId", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return applicationReleaseDbList;
	}
	
	@Override
	public List<ApplicationReleaseDbTO> fetchAppReleaseDbByReleaseIdDocker(long applicationReleaseId, long environmentPhaseId) throws CMMException {
	
		List<ApplicationReleaseDbTO> applicationReleaseDbList;
		Session session = getSession();
		try {
			Criteria criteria = session.createCriteria(ApplicationReleaseDbTO.class);
			criteria.add(Restrictions.eq("applicationRelease.id", applicationReleaseId));
			Criterion allPhaseCriteria = Restrictions.eq("selectedTestingPhase", CMMConstants.Framework.DROPDOWN_SELECTED_VALUE_ALL);
			Criterion selectedPhaseCriteria = Restrictions.eq("selectedTestingPhase", environmentPhaseId);
			Disjunction disjunction = Restrictions.disjunction();
			disjunction.add(selectedPhaseCriteria);
			disjunction.add(allPhaseCriteria);
			criteria.add(disjunction).addOrder(Order.asc("id"));
			applicationReleaseDbList = criteria.list();
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDbDAOImpl : fetchAppReleaseDbByReleaseId ", dae);
		} catch (HibernateException e) {
			logger.error(e);
			throw new CMMException("Problem encountered. ApplicationReleaseDbDAOImpl : fetchAppReleaseDbByReleaseId ", e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return applicationReleaseDbList;
	}
}
