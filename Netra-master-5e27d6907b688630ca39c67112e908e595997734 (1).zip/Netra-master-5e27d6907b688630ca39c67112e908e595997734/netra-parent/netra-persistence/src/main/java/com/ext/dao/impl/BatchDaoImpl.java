package com.ext.dao.impl;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.BatchDAO;
import com.framework.exception.CMMException;

public class BatchDaoImpl extends HibernateDaoSupport implements BatchDAO {
	
	@Override
	public boolean checkBatchRunningStatus(long id) throws CMMException {
	
		return false;
	}
	
	@Override
	public boolean updateBatchRunningStatus(long id, long statusId) throws CMMException {
	
		return true;
	}
}
