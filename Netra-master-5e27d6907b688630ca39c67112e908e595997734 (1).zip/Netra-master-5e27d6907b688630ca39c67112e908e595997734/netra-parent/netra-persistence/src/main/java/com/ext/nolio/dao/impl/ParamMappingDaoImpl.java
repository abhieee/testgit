/**
 *
 */
package com.ext.nolio.dao.impl;

import java.util.List;
import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.nolio.dao.ParamMappingDao;
import com.framework.exception.CMMException;
import com.framework.nolio.to.ParamMappingTO;

/**
 * @author 460650
 */
public class ParamMappingDaoImpl extends HibernateDaoSupport implements ParamMappingDao {
	
	private static final Logger LOGGER = Logger.getLogger(ParamMappingDaoImpl.class);
	
	@Override
	public List<ParamMappingTO> fetchParamMapping(long paramMappingId) throws CMMException {
	
		try {
			List<ParamMappingTO> paramMappingList = (List<ParamMappingTO>) getHibernateTemplate().find("from ParamMappingTO where paramMappingId=?", paramMappingId);
			if ((paramMappingList == null) || paramMappingList.isEmpty()) {
				LOGGER.debug("No param mapping found for paramMappingId :" + paramMappingId);
				throw new CMMException("No param mapping found for paramMappingId :" + paramMappingId);
			}
			return paramMappingList;
		} catch (DataAccessException dae) {
			LOGGER.error(dae);
			throw new CMMException("Problem encountered. ParamMappingDaoImpl: fetchParamMapping", dae);
		} catch (HibernateException e) {
			LOGGER.error(e);
			throw new CMMException("Problem encountered. ParamMappingDaoImpl: fetchParamMapping", e);
		}
	}
}
