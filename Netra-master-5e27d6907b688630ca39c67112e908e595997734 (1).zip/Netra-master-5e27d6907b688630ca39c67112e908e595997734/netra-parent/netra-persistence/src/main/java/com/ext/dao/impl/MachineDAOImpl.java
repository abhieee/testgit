/**
 *
 */
package com.ext.dao.impl;

import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.MachineDAO;
import com.framework.common.CMMConstants;
import com.framework.exception.CMMException;
import com.framework.to.HardwareTO;
import com.framework.to.MachineAwsTO;
import com.framework.to.MachinePhysicalTO;
import com.framework.to.MachineTO;
import com.framework.to.MachineVMWareTO;
import com.framework.to.ProvisionedMachineAwsTO;
import com.framework.to.ProvisionedMachineOSTO;
import com.framework.to.ProvisionedMachineTO;
import com.framework.to.ProvisionedMachineVMWareTO;
import com.framework.to.ProvisionedMachineVmwareBareMetalTO;
import com.framework.to.ProvisionedPlatformOSTO;
import com.framework.to.ProvisionedPlatformTO;
import com.framework.to.ProvisionedPlatformVmwareBareMetalTO;
import com.framework.to.ProvisionedTemplateTO;
import com.framework.to.ProvisionedTemplatesAwsTO;
import com.framework.to.TemplateVMWareTO;

/**
 * @author 460650
 */
public class MachineDAOImpl extends HibernateDaoSupport implements MachineDAO {
	
	@Override
	public List<MachineTO> getAllMachines() throws CMMException {
	
		try {
			List<MachineTO> machineList = (List<MachineTO>) getHibernateTemplate().find("from MachineTO");
			if ((machineList == null) || machineList.isEmpty()) {
				throw new CMMException("No data present in machine table.");
			}
			return machineList;
		} catch (DataAccessException dae) {
			throw new CMMException("Can not fetch machine details:: ", dae);
		} catch (HibernateException he) {
			throw new CMMException("Can not access database:: ", he);
		}
	}
	
	@Override
	public List<ProvisionedMachineTO> getAllProvisionedMachines() throws CMMException {
	
		try {
			List<ProvisionedMachineTO> provisionedMachineList = (List<ProvisionedMachineTO>) getHibernateTemplate().find("from ProvisionedMachineTO");
			if ((provisionedMachineList == null) || provisionedMachineList.isEmpty()) {
				throw new CMMException("No data present in machine table.");
			}
			return provisionedMachineList;
		} catch (DataAccessException dae) {
			throw new CMMException("Can not fetch provisioned machine details:: ", dae);
		} catch (HibernateException he) {
			throw new CMMException("Can not access database:: ", he);
		}
	}
	
	@Override
	public ProvisionedMachineTO getProvisionedMachineDetailsById(long provisionedMachineId) throws CMMException {
	
		Session session = null;
		try {
			ProvisionedMachineTO provisionedMachineTO = (ProvisionedMachineTO) getHibernateTemplate().find("from ProvisionedMachineTO where id = ?", provisionedMachineId).get(0);
			if (provisionedMachineTO == null) {
				throw new CMMException("No provioned machine details found for machineId:: " + provisionedMachineId);
			}
			if (provisionedMachineTO.getProvisionedMachineType().equalsIgnoreCase(CMMConstants.Framework.MachineTypes.MACHINE_TYPE_VIRTUAL)) {
				if (provisionedMachineTO.getVirtualMachineType().equalsIgnoreCase(CMMConstants.Framework.MachineTypes.MACHINE_TYPE_EC2)) {
					session = getSession();
					List<ProvisionedMachineAwsTO> provisionedMachineAwsList = session.createCriteria(ProvisionedMachineAwsTO.class).add(Restrictions.eq("provisionedMachine.id", provisionedMachineId)).list();
					if (provisionedMachineAwsList == null) {
						throw new CMMException("No provisioned machine aws details found for provisionedmachineId:: " + provisionedMachineId);
					}
					provisionedMachineTO.setProvisionedMachineAwsList(provisionedMachineAwsList);
				} else if (provisionedMachineTO.getVirtualMachineType().equalsIgnoreCase(CMMConstants.Framework.MachineTypes.MACHINE_TYPE_OPENSTACK)) {
					session = getSession();
					List<ProvisionedMachineOSTO> provisionedMachineTOList = session.createCriteria(ProvisionedMachineOSTO.class).add(Restrictions.eq("provisionedMachine.id", provisionedMachineId)).list();
					if (provisionedMachineTOList == null) {
						throw new CMMException("No provisioned machine openstack details found for provisionedmachineId:: " + provisionedMachineId);
					}
					provisionedMachineTO.setProvisionedMachineOSTOList(provisionedMachineTOList);
				}
			}
			return provisionedMachineTO;
		} catch (DataAccessException dae) {
			throw new CMMException("Error in fetching Provisioned Machine details for provisionedMachineId:: " + provisionedMachineId, dae);
		} catch (HibernateException he) {
			throw new CMMException("Can not fetch Provisioned Machine data from database for provisionedMachineId:: " + provisionedMachineId, he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public void updateProvisionedMachine(ProvisionedMachineTO provisionedMachineTO) throws CMMException {
	
		try {
			getHibernateTemplate().update(provisionedMachineTO);
		} catch (DataAccessException dae) {
			throw new CMMException("Error in fetching Provisioned template platformId for provisionedtemplateId:: " + provisionedMachineTO.getId(), dae);
		} catch (HibernateException he) {
			throw new CMMException("Error in updating provisioned_machine table for id:: " + provisionedMachineTO.getId(), he);
		}
	}
	
	@Override
	public void updateProvisionedOSMachine(ProvisionedMachineTO provisionedMachineTO, ProvisionedMachineOSTO provisionedMachineOSTO) throws CMMException {
	
		try {
			getHibernateTemplate().update(provisionedMachineTO);
			getHibernateTemplate().update(provisionedMachineOSTO);
		} catch (DataAccessException dae) {
			throw new CMMException("Error in fetching Provisioned template platformId for provisionedtemplateId:: " + provisionedMachineTO.getId(), dae);
		} catch (HibernateException he) {
			throw new CMMException("Error in updating provisioned_machine table for id:: " + provisionedMachineTO.getId(), he);
		}
	}
	
	@Override
	public long getPlatformIdForEC2(long provisionedtemplateId) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			Long osId = (Long) session.createCriteria(ProvisionedTemplateTO.class).add(Restrictions.eq("id", provisionedtemplateId)).setProjection(Projections.property("platform.platformId")).uniqueResult();
			if (osId == null) {
				throw new CMMException("No OS details found for provisionedtemplateId:: " + provisionedtemplateId);
			}
			return osId;
		} catch (DataAccessException dae) {
			throw new CMMException("Error in fetching Provisioned template platformId for provisionedtemplateId:: " + provisionedtemplateId, dae);
		} catch (HibernateException he) {
			throw new CMMException("Can not fetch Provisioned template data from database for provisionedtemplateId:: " + provisionedtemplateId, he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public long fetchProvisionedTemplateIdForAWS(long provisionedMachineId) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			Long provisionedTemplateId = (Long) session.createCriteria(ProvisionedMachineAwsTO.class).add(Restrictions.eq("provisionedMachine.id", provisionedMachineId)).setProjection(Projections.property("provisionedtemplateId")).uniqueResult();
			if (provisionedTemplateId == null) {
				throw new CMMException("No template record found for provisionedMachineId:: " + provisionedMachineId);
			}
			return provisionedTemplateId;
		} catch (DataAccessException dae) {
			throw new CMMException("Error in fetching Provisioned template platformId for provisionedtemplateId:: " + provisionedMachineId, dae);
		} catch (HibernateException he) {
			throw new CMMException("Can not fetch Provisioned template data from database for provisionedtemplateId:: " + provisionedMachineId, he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public long fetchProvisionedTemplateIdForVMware(long provisionedMachineId) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			Long provisionedTemplateId = (Long) session.createCriteria(ProvisionedMachineVMWareTO.class).add(Restrictions.eq("provisionedMachine.id", provisionedMachineId)).setProjection(Projections.property("templateId")).uniqueResult();
			if (provisionedTemplateId == null) {
				throw new CMMException("No provisioned template record found for provisionedMachineId:: " + provisionedMachineId);
			}
			return provisionedTemplateId;
		} catch (DataAccessException dae) {
			throw new CMMException("Error in fetching Provisioned template platformId for provisionedMachineId:: " + provisionedMachineId, dae);
		} catch (HibernateException he) {
			throw new CMMException("Can not fetch Provisioned template for VMware data from database for provisionedMachineId:: " + provisionedMachineId, he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public MachineTO getMachineDetails(MachineTO machineTO) throws CMMException {
	
		try {
			return (MachineTO) getHibernateTemplate().find("from MachineTO where id=?", machineTO.getId()).get(0);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. MachineDAOImpl : getMachineDetails", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. MachineDAOImpl : getMachineDetails", he);
		}
	}
	
	@Override
	public MachineAwsTO getMachineAWSDetails(MachineTO machineTO) throws CMMException {
	
		try {
			return (MachineAwsTO) getHibernateTemplate().find("from MachineAwsTO where machine.id=?", machineTO.getId()).get(0);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. MachineDAOImpl : getMachineAWSDetails", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. MachineDAOImpl : getMachineAWSDetails", he);
		}
	}
	
	@Override
	public HardwareTO getMachinePhysicalDetails(MachineTO machineTO) throws CMMException {
	
		MachinePhysicalTO machinePhysicalTO = (MachinePhysicalTO) getHibernateTemplate().find("from MachinePhysicalTO where machine.id=?", machineTO.getId()).get(0);
		return (HardwareTO) getHibernateTemplate().find("from HardwareTO where id=?", machinePhysicalTO.getHardwareId()).get(0);
	}
	
	@Override
	public ProvisionedPlatformTO getProvisionedPlatformTemplateDetails(long provisionedPlatformTemplateId) throws CMMException {
	
		Session session = null;
		try {
			ProvisionedPlatformTO provisionedPlatformTemplateTO = (ProvisionedPlatformTO) getHibernateTemplate().find("from ProvisionedPlatformTO where id=?", provisionedPlatformTemplateId).get(0);
			if (provisionedPlatformTemplateTO == null) {
				throw new CMMException("No ProvisionedPlatformTemplate records found for id:: " + provisionedPlatformTemplateId);
			}
			if (provisionedPlatformTemplateTO.getType().equalsIgnoreCase(CMMConstants.Framework.MachineTypes.MACHINE_TYPE_VMWARE)) {
				TemplateVMWareTO TemplateVMWare = (TemplateVMWareTO) getHibernateTemplate().find("from TemplateVMWareTO where platformTemplate.id=?", provisionedPlatformTemplateTO.getPlatformTemplateId()).get(0);
				if (TemplateVMWare != null) {
					if (!"".equalsIgnoreCase(TemplateVMWare.getVmTemplateName())) {
						provisionedPlatformTemplateTO.setPlatformTemplateName(TemplateVMWare.getVmTemplateName());
					}
				}
			}
			if (provisionedPlatformTemplateTO.getType().equalsIgnoreCase(CMMConstants.Framework.MachineTypes.MACHINE_TYPE_EC2)) {
				session = getSession();
				List<ProvisionedTemplatesAwsTO> provisionedMachineAwsList = session.createCriteria(ProvisionedTemplatesAwsTO.class).add(Restrictions.eq("provisionedPlatformId", provisionedPlatformTemplateId)).list();
				if (provisionedMachineAwsList == null) {
					throw new CMMException("No ProvisionedPlatformTemplate aws details found for provisionedPlatformId:: " + provisionedPlatformTemplateId);
				}
				provisionedPlatformTemplateTO.setProvisionedMachineAwsList(provisionedMachineAwsList);
			} else if (provisionedPlatformTemplateTO.getType().equalsIgnoreCase(CMMConstants.Framework.MachineTypes.MACHINE_TYPE_OPENSTACK)) {
				session = getSession();
				List<ProvisionedPlatformOSTO> provisionedPlatformOSList = session.createCriteria(ProvisionedPlatformOSTO.class).add(Restrictions.eq("provisionedPlatformId", provisionedPlatformTemplateId)).list();
				if (provisionedPlatformOSList == null) {
					throw new CMMException("No ProvisionedPlatformTemplate openstack details found for provisionedPlatformId:: " + provisionedPlatformTemplateId);
				}
				provisionedPlatformTemplateTO.setProvisionedPlatformOSTOList(provisionedPlatformOSList);
			}
			return provisionedPlatformTemplateTO;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. MachineDAOImpl : getProvisionedPlatformTemplateDetails", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. MachineDAOImpl : getProvisionedPlatformTemplateDetails", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public MachineVMWareTO getMachineVMWareDetails(MachineTO machineTO) throws CMMException {
	
		return null;
	}
	
	@Override
	public void updateProvisionedMachineAws(ProvisionedMachineAwsTO provMachine) throws CMMException {
	
		try {
			ProvisionedMachineAwsTO machine = getHibernateTemplate().get(ProvisionedMachineAwsTO.class, provMachine.getId());
			machine.setAwsAccountId(provMachine.getAwsAccountId());
			machine.setInstanceType(provMachine.getInstanceType());
			machine.setKeyPair(provMachine.getKeyPair());
			machine.setAvailabilityZone(provMachine.getAvailabilityZone());
			machine.setSecurityGroups(provMachine.getSecurityGroups());
			machine.setProvisionedMachineTemplateId(provMachine.getProvisionedMachineTemplateId());
			machine.setProvisionedtemplateId(provMachine.getProvisionedtemplateId());
			machine.setServerGroup(provMachine.getServerGroup());
			getHibernateTemplate().update(machine);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. MachineDAOImpl : updateProvisionedMachineAws", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. MachineDAOImpl : updateProvisionedMachineAws", he);
		}
	}
	
	@Override
	public ProvisionedMachineVmwareBareMetalTO getProMachineVmwareBareMetalDetailsById(Long proMachineId) throws CMMException {
	
		try {
			return (ProvisionedMachineVmwareBareMetalTO) getHibernateTemplate().find("from ProvisionedMachineVmwareBareMetalTO p where p.provisionedMachineTemplateId=?", proMachineId).get(0);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. MachineDAOImpl : getProMachineVmwareBareMetalDetailsById", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. MachineDAOImpl : getProMachineVmwareBareMetalDetailsById", he);
		}
	}
	
	@Override
	public ProvisionedPlatformVmwareBareMetalTO getProPlatformVmwareBareMetalDetailsById(Long proPlatformId) throws CMMException {
	
		try {
			return (ProvisionedPlatformVmwareBareMetalTO) getHibernateTemplate().find("from ProvisionedPlatformVmwareBareMetalTO p where p.provisionedPlatformId=?", proPlatformId).get(0);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. MachineDAOImpl : getProPlatformVmwareBareMetalDetailsById", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. MachineDAOImpl : getProPlatformVmwareBareMetalDetailsById", he);
		}
	}
}
