/**
 *
 */
package com.ext.nolio.dao.impl;

import java.util.ArrayList;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.exception.ConstraintViolationException;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.nolio.dao.CAActivityProcessDao;
import com.framework.exception.CMMException;
import com.framework.nolio.to.CAActivityProcessOrderTO;
import com.framework.nolio.to.CaActivityExecOrderTO;
import com.framework.nolio.to.NolioProcessSoftwareMapping;
import com.framework.to.ActivitySoftwareMappingTO;
import com.framework.to.CAReleaseActivityTO;

/**
 * @author 460650
 */
public class CAActivityProcessDaoImpl extends HibernateDaoSupport implements CAActivityProcessDao {
	
	@Override
	public List<CAActivityProcessOrderTO> fetchNolioSoftProcessMapByActivityID(long mapActivityId) throws CMMException {
	
		List<CAActivityProcessOrderTO> caActivityProcessList = new ArrayList<CAActivityProcessOrderTO>();
		try {
			caActivityProcessList = (List<CAActivityProcessOrderTO>) getHibernateTemplate().findByCriteria(DetachedCriteria.forClass(CAActivityProcessOrderTO.class).add(Restrictions.eq("activitySoftwareMappingTO.activitySoftwareMapId", mapActivityId)).addOrder(Order.asc("processOrder")));
			if (caActivityProcessList == null) {
				logger.debug("No record found for activityId::" + mapActivityId);
				throw new CMMException("No activity mapping found for given activityId::" + mapActivityId);
			}
		} catch (DataAccessException da) {
			logger.error(da);
			throw new CMMException("Problem encountered. CAActivityProcessDaoImpl : fetchNolioSoftProcessMapByActivityID", da);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. CAActivityProcessDaoImpl : fetchNolioSoftProcessMapByActivityID", he);
		}
		return caActivityProcessList;
	}
	
	@Override
	public void saveOrderedNolioProcessForActivity(CAReleaseActivityTO cAReleaseActivityTO) throws CMMException {
	
		try {
			List<Long> orderedProcessList = new ArrayList<Long>();
			List<Long> procList = cAReleaseActivityTO.getNolioProcessSoftwareMapOrderedList();
			for (Long l : procList) {
				NolioProcessSoftwareMapping npSoftMap = getNolioProcessSoftwareMapping(cAReleaseActivityTO, l);
				orderedProcessList.add(npSoftMap.getSoftwareProcessMappingId());
			}
			ActivitySoftwareMappingTO activitySoftwareMappingToP = getActivitySoftwareMapping(cAReleaseActivityTO);
			List<CAActivityProcessOrderTO> CaActivityProcessOrderTOprevious = (List<CAActivityProcessOrderTO>) getHibernateTemplate().find("from CAActivityProcessOrderTO where activitySoftwareMappingTO.activitySoftwareMapId =? ", activitySoftwareMappingToP.getActivitySoftwareMapId());
			if (CaActivityProcessOrderTOprevious != null) {
				for (int i = 0; i < CaActivityProcessOrderTOprevious.size(); i++) {
					CAActivityProcessOrderTO CaActivityProcessOrderTO = CaActivityProcessOrderTOprevious.get(i);
					getHibernateTemplate().delete(CaActivityProcessOrderTO);
				}
			}
			for (int i = 0; i < orderedProcessList.size(); i++) {
				NolioProcessSoftwareMapping nolioProcessSoftwareMapping = new NolioProcessSoftwareMapping();
				nolioProcessSoftwareMapping.setSoftwareProcessMappingId(orderedProcessList.get(i));
				CAActivityProcessOrderTO caActivityProcessOrderTO = new CAActivityProcessOrderTO();
				caActivityProcessOrderTO.setNolioProcessSoftwareMapping(nolioProcessSoftwareMapping);
				caActivityProcessOrderTO.setActivitySoftwareMappingTO(activitySoftwareMappingToP);
				caActivityProcessOrderTO.setProcessOrder(i);
				getHibernateTemplate().saveOrUpdate(caActivityProcessOrderTO);
				logger.debug("Nolio processes saved successfully for ActivityId:: " + cAReleaseActivityTO.getSelectedActivityId());
			}
		} catch (DataIntegrityViolationException div) {
			logger.error(div);
			throw new CMMException("Problem encountered. CAActivityProcessDaoImpl : saveOrderedNolioProcessForActivity", div);
		} catch (ConstraintViolationException e) {
			logger.error(e);
			throw new CMMException("Problem encountered. CAActivityProcessDaoImpl : saveOrderedNolioProcessForActivity", e);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. CAActivityProcessDaoImpl : saveOrderedNolioProcessForActivity", he);
		}
	}
	
	@Override
	public void saveOrderedActivities(CAReleaseActivityTO cAReleaseActivityTO) throws CMMException {
	
		Session session = null;
		try {
			ActivitySoftwareMappingTO activitySoftwareMappingToP = getActivitySoftwareMapping(cAReleaseActivityTO);
			List<CaActivityExecOrderTO> caActivityExecOrderTOprevious = new ArrayList<CaActivityExecOrderTO>();
			caActivityExecOrderTOprevious = (List<CaActivityExecOrderTO>) getHibernateTemplate().find("from CaActivityExecOrderTO where activitySoftwareMappingTOP.activitySoftwareMapId =? ", activitySoftwareMappingToP.getActivitySoftwareMapId());
			if (caActivityExecOrderTOprevious != null) {
				for (int i = 0; i < caActivityExecOrderTOprevious.size(); i++) {
					CaActivityExecOrderTO caActivityExecOrderTO = caActivityExecOrderTOprevious.get(i);
					getHibernateTemplate().delete(caActivityExecOrderTO);
				}
			}
			Transaction tx = null;
			session = getSession();
			tx = session.beginTransaction();
			String hql = "from  ActivitySoftwareMappingTO where softwareconfigTO.id = ? and caReleaseActivityTO.activityId = ? )";
			Query q = session.createQuery(hql);
			q.setParameter(0, cAReleaseActivityTO.getSoftwareId());
			q.setParameter(1, cAReleaseActivityTO.getSelectedActivityId());
			List<Object[]> obj = q.list();
			tx.commit();
			CaActivityExecOrderTO caActivityExecOrderTO = new CaActivityExecOrderTO();
			for (int i = 0; i < obj.size(); i++) {
				Object activitySoftware = obj.get(i);
				caActivityExecOrderTO.setActivitySoftwareMappingTO((ActivitySoftwareMappingTO) activitySoftware);
				caActivityExecOrderTO.setActivitySoftwareMappingTOP(activitySoftwareMappingToP);
				caActivityExecOrderTO.setExeOrder(i);
				getHibernateTemplate().save(caActivityExecOrderTO);
				logger.debug("Activities saved successfully for ActivityId:: " + cAReleaseActivityTO.getSelectedActivityId());
			}
		} catch (DataIntegrityViolationException div) {
			logger.error(div);
			throw new CMMException("Problem encountered. CAActivityProcessDaoImpl : saveOrderedActivities", div);
		} catch (ConstraintViolationException e) {
			logger.error(e);
			throw new CMMException("Problem encountered. CAActivityProcessDaoImpl : saveOrderedActivities", e);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. CAActivityProcessDaoImpl : saveOrderedActivities", he);
		} catch (Exception e) {
			logger.error(e);
			throw new CMMException("Problem encountered. CAActivityProcessDaoImpl : saveOrderedActivities", e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	public ActivitySoftwareMappingTO getActivitySoftwareMapping(CAReleaseActivityTO cAReleaseActivityTO) throws CMMException {
	
		try {
			ActivitySoftwareMappingTO activitySoftwareMappingToP = new ActivitySoftwareMappingTO();
			DetachedCriteria criteria = DetachedCriteria.forClass(ActivitySoftwareMappingTO.class);
			criteria.createAlias("softwareconfigTO", "soft", CriteriaSpecification.LEFT_JOIN);
			criteria.createAlias("caReleaseActivityTO", "acti", CriteriaSpecification.LEFT_JOIN);
			criteria.add(Restrictions.eq("soft.id", cAReleaseActivityTO.getSoftwareId()));
			criteria.add(Restrictions.eq("acti.activityId", cAReleaseActivityTO.getSelectedActivityId()));
			activitySoftwareMappingToP = (ActivitySoftwareMappingTO) getHibernateTemplate().findByCriteria(criteria).get(0);
			return activitySoftwareMappingToP;
		} catch (DataIntegrityViolationException div) {
			logger.error(div);
			throw new CMMException("Problem encountered. CAActivityProcessDaoImpl : getActivitySoftwareMapping", div);
		} catch (ConstraintViolationException e) {
			logger.error(e);
			throw new CMMException("Problem encountered. CAActivityProcessDaoImpl : getActivitySoftwareMapping", e);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. CAActivityProcessDaoImpl : getActivitySoftwareMapping", he);
		}
	}
	
	@Override
	public List<CAActivityProcessOrderTO> fetchNolioProcessOrder(CAReleaseActivityTO cAReleaseActivityTO) throws CMMException {
	
		try {
			List<Long> activitySoftwareMappingTO = (List<Long>) getHibernateTemplate().find("select activitySoftwareMapId from ActivitySoftwareMappingTO where softwareconfigTO.id = ? ", Long.parseLong(cAReleaseActivityTO.getSelectedVersion()));
			List<Long> nolioProcessSoftwareMapping = (List<Long>) getHibernateTemplate().find("select softwareProcessMappingId from NolioProcessSoftwareMapping where softwareConfigTO.id = ? ", Long.parseLong(cAReleaseActivityTO.getSelectedVersion()));
			if (!activitySoftwareMappingTO.isEmpty() && !nolioProcessSoftwareMapping.isEmpty()) {
				String paramNames[] = { "mapIds", "nolioIds" };
				Object[] values = { activitySoftwareMappingTO, nolioProcessSoftwareMapping };
				return (List<CAActivityProcessOrderTO>) getHibernateTemplate().findByNamedParam(" from CAActivityProcessOrderTO where activitySoftwareMappingTO.activitySoftwareMapId in(:mapIds) and nolioProcessSoftwareMapping.softwareProcessMappingId in (:nolioIds) Order by activitySoftwareMappingTO.activitySoftwareMapId,processOrder ", paramNames, values);
			} else {
				return null;
			}
		} catch (ConstraintViolationException ce) {
			logger.error(ce);
			throw new CMMException("Problem encountered. CAActivityProcessDaoImpl : fetchNolioProcessOrder", ce);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. CAActivityProcessDaoImpl : fetchNolioProcessOrder", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. CAActivityProcessDaoImpl : fetchNolioProcessOrder", he);
		} catch (Exception e) {
			logger.error(e);
			throw new CMMException("Problem encountered. CAActivityProcessDaoImpl : fetchNolioProcessOrder", e);
		}
	}
	
	@Override
	public List<CaActivityExecOrderTO> fetchOrderedActivities(CAReleaseActivityTO cAReleaseActivityTO) throws CMMException {
	
		try {
			ActivitySoftwareMappingTO activitySoftwareMappingTO = (ActivitySoftwareMappingTO) getHibernateTemplate().find("from ActivitySoftwareMappingTO where softwareconfigTO.id = ? and caReleaseActivityTO.activityId =?", cAReleaseActivityTO.getSelectedVersion(), cAReleaseActivityTO.getSelectedActivityId()).get(0);
			return (List<CaActivityExecOrderTO>) getHibernateTemplate().find("from  CaActivityExecOrderTO where activitySoftwareMappingTOP.activitySoftwareMapId = ?  order by exeOrder ", activitySoftwareMappingTO.getActivitySoftwareMapId());
		} catch (ConstraintViolationException ce) {
			logger.error(ce);
			throw new CMMException("Problem encountered. CAActivityProcessDaoImpl : fetchOrderedActivities", ce);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. CAActivityProcessDaoImpl : fetchOrderedActivities", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. CAActivityProcessDaoImpl : fetchOrderedActivities", he);
		} catch (Exception e) {
			logger.error(e);
			throw new CMMException("Problem encountered. CAActivityProcessDaoImpl : fetchOrderedActivities", e);
		}
	}
	
	public NolioProcessSoftwareMapping getNolioProcessSoftwareMapping(CAReleaseActivityTO cAReleaseActivityTO, Long processId) throws CMMException {
	
		try {
			NolioProcessSoftwareMapping nolioProcessSoftwareMapping = new NolioProcessSoftwareMapping();
			DetachedCriteria criteria = DetachedCriteria.forClass(NolioProcessSoftwareMapping.class);
			criteria.createAlias("softwareConfigTO", "soft", CriteriaSpecification.LEFT_JOIN);
			criteria.createAlias("nolioProcess", "nol", CriteriaSpecification.LEFT_JOIN);
			criteria.add(Restrictions.eq("soft.id", cAReleaseActivityTO.getSoftwareId()));
			criteria.add(Restrictions.eq("nol.processId", processId));
			nolioProcessSoftwareMapping = (NolioProcessSoftwareMapping) getHibernateTemplate().findByCriteria(criteria).get(0);
			return nolioProcessSoftwareMapping;
		} catch (DataIntegrityViolationException div) {
			logger.error(div);
			throw new CMMException("Problem encountered. CAActivityProcessDaoImpl : getActivitySoftwareMapping", div);
		} catch (ConstraintViolationException e) {
			logger.error(e);
			throw new CMMException("Problem encountered. CAActivityProcessDaoImpl : getActivitySoftwareMapping", e);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. CAActivityProcessDaoImpl : getActivitySoftwareMapping", he);
		}
	}
}
