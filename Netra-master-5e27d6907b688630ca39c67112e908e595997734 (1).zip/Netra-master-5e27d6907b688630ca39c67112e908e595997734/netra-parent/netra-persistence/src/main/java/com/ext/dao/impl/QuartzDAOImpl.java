package com.ext.dao.impl;

import java.util.Date;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.exception.ConstraintViolationException;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.QuartzDAO;
import com.framework.exception.CMMException;
import com.framework.to.QuartzHistoryTO;

/**
 * This class is used make entries in the database corresponding to the scheduled quartz jobs.
 *
 * @author TCS
 */
public class QuartzDAOImpl extends HibernateDaoSupport implements QuartzDAO {
	
	/*
	 */
	@Override
	public boolean insertFiredTimeQuartzhistory(Object[] args) throws CMMException {
	
		try {
			QuartzHistoryTO quartzHistoryTO = new QuartzHistoryTO();
			quartzHistoryTO.setTriggerName((String) args[0]);
			quartzHistoryTO.setTriggerGroup((String) args[1]);
			quartzHistoryTO.setFiredTime((Date) args[4]);
			quartzHistoryTO.setJobName((String) args[5]);
			quartzHistoryTO.setJobGroup((String) args[6]);
			quartzHistoryTO.setTriggerStatus("TRIGGER_FIRED");
			quartzHistoryTO.setStatus("STARTED");
			quartzHistoryTO.setCreatedBy("SYSTEM");
			if ((args[8] != null) && ((Long) args[8] != 0L)) {
				quartzHistoryTO.setRequestId((Long) args[8]);
			}
			quartzHistoryTO.setUniqueId((String) args[9]);
			getHibernateTemplate().saveOrUpdate(quartzHistoryTO);
		} catch (ConstraintViolationException e) {
			logger.error(e);
			throw new CMMException("Problem encountered.", e);
		} catch (DataAccessException e) {
			logger.error(e);
			throw new CMMException("Problem encountered.", e);
		} catch (HibernateException e) {
			logger.error(e);
			throw new CMMException("Problem encountered.", e);
		}
		return true;
	}
	
	@Override
	public boolean updateCompletedTimeQuartzhistory(Object[] args) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			Query q = session.createQuery("update QuartzHistoryTO set completedTime=:completedTime,status=:status,triggerStatus=:triggerStatus where uniqueId=:uniqueId");
			q.setTimestamp("completedTime", (Date) args[4]);
			q.setString("uniqueId", (String) args[9]);
			q.setString("status", "COMPLETED");
			q.setString("triggerStatus", (String) args[11]);
			q.executeUpdate();
		} catch (ConstraintViolationException e) {
			logger.error(e);
			throw new CMMException("Problem encountered.", e);
		} catch (DataAccessException e) {
			logger.error(e);
			throw new CMMException("Problem encountered.", e);
		} catch (HibernateException e) {
			logger.error(e);
			throw new CMMException("Problem encountered.", e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return true;
	}
	
	@Override
	public boolean updateMisfiredTimeQuartzhistory(Object[] args) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			Query q = session.createQuery("update QuartzHistoryTO set completedTime=:completedTime,status=:status,triggerStatus=:triggerStatus where uniqueId=:uniqueId");
			q.setTimestamp("misFiredTime", (Date) args[4]);
			q.setString("uniqueId", (String) args[9]);
			q.setString("status", "MISFIRED");
			q.setString("triggerStatus", (String) args[11]);
			q.executeUpdate();
		} catch (ConstraintViolationException e) {
			logger.error(e);
			throw new CMMException("Problem encountered.", e);
		} catch (DataAccessException e) {
			logger.error(e);
			throw new CMMException("Problem encountered.", e);
		} catch (HibernateException e) {
			logger.error(e);
			throw new CMMException("Problem encountered.", e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return true;
	}
}
