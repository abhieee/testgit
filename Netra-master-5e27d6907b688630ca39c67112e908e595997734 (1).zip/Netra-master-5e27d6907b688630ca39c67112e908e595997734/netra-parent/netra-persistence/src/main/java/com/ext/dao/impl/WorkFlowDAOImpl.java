package com.ext.dao.impl;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.ReservationDAO;
import com.ext.dao.WorkFlowDAO;
import com.framework.common.CMMConstants;
import com.framework.exception.CMMException;
import com.framework.to.ApplicationReleaseTO;
import com.framework.to.ApplicationTO;
import com.framework.to.BusinessUnitTO;
import com.framework.to.EnvironmentTO;
import com.framework.to.PipelineRequestDetailsTO;
import com.framework.to.ProjectsTO;
import com.framework.to.ReleasePlanningTO;
import com.framework.to.ReservationTO;
import com.framework.to.RoleTO;
import com.framework.to.ServiceRequestTO;
import com.framework.to.StatusTO;
import com.framework.to.TestingPhaseTO;
import com.framework.to.WorkFlowLevelTO;
import com.framework.to.WorkFlowRequestTO;
import com.framework.to.WorkFlowTO;
import com.framework.to.WorkflowCurrentTO;
import com.framework.to.WorkflowHistoryTO;
import com.framework.to.WorkflowStatusTO;
import com.framework.utility.DateUtils;

public class WorkFlowDAOImpl extends HibernateDaoSupport implements WorkFlowDAO {
	
	DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
	SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
	ReservationDAO reservationDAO;
	
	public AccessMgmtDAOImpl getAccessMgmtDAOImpl() {
	
		return accessMgmtDAOImpl;
	}
	
	public void setAccessMgmtDAOImpl(AccessMgmtDAOImpl accessMgmtDAOImpl) {
	
		this.accessMgmtDAOImpl = accessMgmtDAOImpl;
	}
	
	AccessMgmtDAOImpl accessMgmtDAOImpl;
	
	public ReservationDAO getReservationDAO() {
	
		return reservationDAO;
	}
	
	public void setReservationDAO(ReservationDAO reservationDAO) {
	
		this.reservationDAO = reservationDAO;
	}
	
	ReservationDAOImpl reservationDAOImpl = new ReservationDAOImpl();
	
	@Override
	public List<WorkFlowTO> getWorkFlowActionList() throws CMMException {
	
		try {
			return (List<WorkFlowTO>) getHibernateTemplate().find("from WorkFlowTO w where w.wfReq='Y' order by name");
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : getWorkFlowActionList ", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : getWorkFlowActionList", he);
		}
	}
	
	@Override
	public void defineWorkflow(WorkFlowLevelTO workFlowLevelTO) throws CMMException {
	
		try {
			DetachedCriteria criteria1 = DetachedCriteria.forClass(WorkFlowLevelTO.class);
			criteria1.add(Restrictions.eq("clientId", workFlowLevelTO.getClientId()));
			criteria1.add(Restrictions.eq("workflowId", workFlowLevelTO.getWorkflowId()));
			List<WorkFlowLevelTO> levelList = (List<WorkFlowLevelTO>) getHibernateTemplate().findByCriteria(criteria1);
			for (WorkFlowLevelTO temp : levelList) {
				getHibernateTemplate().delete(temp);// deleting the previous
			}
			DetachedCriteria criteria = DetachedCriteria.forClass(WorkFlowTO.class, "workflow");
			criteria.add(Restrictions.eq("id", workFlowLevelTO.getWorkflowId()));
			WorkFlowTO workflow = (WorkFlowTO) getHibernateTemplate().findByCriteria(criteria).get(0);
			Long counter = 0L;
			if (workFlowLevelTO.getDefinedRoles() != null) {
				for (Long roleId : workFlowLevelTO.getDefinedRoles()) {
					WorkFlowLevelTO temp = new WorkFlowLevelTO();
					counter++;
					temp.setLevelOrder(counter);// setting the level order of the
					temp.setRoleId(roleId);
					temp.setClientId(workFlowLevelTO.getClientId());
					WorkFlowTO workflowTemp = new WorkFlowTO();
					workflowTemp.getWorkFlowLevel().add(temp);
					workflowTemp.setId(workflow.getId());
					temp.setWorkFlows(workflowTemp);
					getHibernateTemplate().save(temp);
				}
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : defineWorkflow ", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : defineWorkflow", he);
		}
	}
	
	@Override
	public String fetchRemarks(WorkflowCurrentTO wct) throws CMMException {
	
		try {
			String rem = "";
			if (wct.getRequestId() == 1L) {
				rem = (String) getHibernateTemplate().find("select actionRemark from ReservationTO where id=?", wct.getEntity_id()).get(0);
			} else if (wct.getRequestId() == 0L) {
				Long workflowId = (Long) getHibernateTemplate().find("select serviceRequestId from WorkflowCurrentTO where reqId=?", wct.getReqId()).get(0);
				rem = (String) getHibernateTemplate().find("select remark from ServiceRequestTO where id=?", workflowId).get(0);
			}
			return rem;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : getDefinedRoles", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : getDefinedRoles", he);
		}
	}
	
	@Override
	public List<RoleTO> getDefinedRoles(WorkFlowLevelTO workFlowLevelTO) throws CMMException {
	
		List<RoleTO> dbRoles = new ArrayList<RoleTO>();
		StringBuilder query = new StringBuilder("select r.name from RoleTO r where r.id=?");// to
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(WorkFlowLevelTO.class);
			criteria.add(Restrictions.eq("clientId", workFlowLevelTO.getSelectedBusinessUnit()));
			criteria.add(Restrictions.eq("workflowId", workFlowLevelTO.getSelectedWorkFlowAction()));
			List<WorkFlowLevelTO> roles = (List<WorkFlowLevelTO>) getHibernateTemplate().findByCriteria(criteria);
			for (WorkFlowLevelTO obj : roles) {
				RoleTO roleTO = new RoleTO();
				String roleName = (String) getHibernateTemplate().find(query.toString(), obj.getRoleId()).get(0);
				roleTO.setName(roleName);
				roleTO.setId(obj.getRoleId());
				dbRoles.add(roleTO);
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : getDefinedRoles", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : getDefinedRoles", he);
		}
		return dbRoles;
	}
	
	@Override
	public List<WorkflowCurrentTO> searchWorkList(WorkflowCurrentTO workflowCurrentTO) throws CMMException {
	
		DateFormat localFormatter = new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy");
		String dateFromStr = null;
		String dateToStr = null;
		Date dateFrom = null;
		Date dateTo = null;
		Calendar cal = Calendar.getInstance();
		String formatedFromDate = null;
		String formatedToDate = null;
		DateFormat formatter1 = new SimpleDateFormat("yyyy-MM-dd");
		if (workflowCurrentTO.getFromDate() != null) {
			dateFromStr = workflowCurrentTO.getFromDate();
			try {
				dateFrom = localFormatter.parse(dateFromStr);
				cal.setTime(dateFrom);
				formatedFromDate = cal.get(Calendar.YEAR) + "-" + (cal.get(Calendar.MONTH) + 1) + "-" + cal.get(Calendar.DATE);
				dateFrom = formatter1.parse(formatedFromDate);
			} catch (ParseException e) {
				throw new CMMException("Error parsing date ", e);
			}
		}
		if (workflowCurrentTO.getToDate() != null) {
			dateToStr = workflowCurrentTO.getToDate();
			try {
				dateTo = localFormatter.parse(dateToStr);
				cal.setTime(dateTo);
				formatedToDate = cal.get(Calendar.YEAR) + "-" + (cal.get(Calendar.MONTH) + 1) + "-" + cal.get(Calendar.DATE);
				dateTo = formatter1.parse(formatedToDate);
			} catch (ParseException e) {
				throw new CMMException("Error parsing date ", e);
			}
		}
		Session session = null;
		String query = null;
		try {
			Long userId = null;
			List<Long> userIds = new ArrayList<Long>();
			List<Long> userIdList = (List<Long>) getHibernateTemplate().find("select userId from DelegatedUserTO where delegatedUserId=? ", workflowCurrentTO.getLoggedInUser());
			if (!userIdList.isEmpty()) {
				userId = userIdList.get(0);
				userIds.add(userId);
			}
			userIds.add(workflowCurrentTO.getLoggedInUser());
			session = getSession();
			List<WorkflowCurrentTO> dbWorklists = new ArrayList<WorkflowCurrentTO>(0);
			query = " select distinct wcto ,buto.name, appto.appName,pto.name ,whto.createdBy from WorkflowCurrentTO wcto,BusinessUnitTO buto, ApplicationTO appto ,ProjectsTO pto, WorkflowHistoryTO whto  where wcto.clientId =buto.clientId and wcto.id = whto.wf_current_id  and wcto.applicationId =appto.id and wcto.projectId =pto.id  and whto.userTO.id in (:userIDs) and (whto.wfStatusTO.id is null or whto.wfStatusTO.id=1L) and wcto.clientId in (:clientIdlist) ";
			if ((workflowCurrentTO.getRequestId() != null) && (workflowCurrentTO.getRequestId() > 0)) {
				query = query + " and wcto.reqId = " + workflowCurrentTO.getRequestId();
			}
			if ((workflowCurrentTO.getServiceRequestId() != null) && (workflowCurrentTO.getServiceRequestId() > 0)) {
				query = query + " and wcto.serviceRequestId = " + workflowCurrentTO.getServiceRequestId();
			}
			if ((workflowCurrentTO.getEntity_id() != null) && (workflowCurrentTO.getEntity_id() > 0)) {
				query = query + " and wcto.entity_id = " + workflowCurrentTO.getEntity_id();
			}
			if ((workflowCurrentTO.getSelectedApp() != -1) && (workflowCurrentTO.getSelectedApp() != 0)) {
				query = query + " and appto.id = " + workflowCurrentTO.getSelectedApp();
			}
			if ((workflowCurrentTO.getSelectedWorkFlowAction() != -1) && (workflowCurrentTO.getSelectedWorkFlowAction() != 0)) {
				query = query + " and wcto.workFlowTO.id = " + workflowCurrentTO.getSelectedWorkFlowAction();
			}
			if ((workflowCurrentTO.getSelectedStatus() != 4) && (workflowCurrentTO.getSelectedStatus() > 0L)) {
				query = query + " and wcto.wfStatusTO.id = " + workflowCurrentTO.getSelectedStatus();
			}
			if (workflowCurrentTO.getSelectedStatus() == 4) {
				query = query + " and wcto.wfStatusTO.id = " + workflowCurrentTO.getSelectedStatus();
			}
			if ((workflowCurrentTO.getFromDate() != null) && (workflowCurrentTO.getToDate() == null)) {
				query = query + " and wcto.requestDate >=:datefrom";
			}
			if ((workflowCurrentTO.getToDate() != null) && (workflowCurrentTO.getFromDate() == null)) {
				query = query + " and wcto.requestDate <=:dateto ";
			}
			if ((workflowCurrentTO.getToDate() != null) && (workflowCurrentTO.getFromDate() != null)) {
				query = query + " and wcto.requestDate >=:datefrom  and wcto.requestDate <=:dateto ";
			}
			/* Added for bug 3253 */
			query = query + " order by wcto.wfStatusTO.id asc ";
			/* Addition ends for bug 3253 */
			Query query1 = session.createQuery(query);
			query1.setParameterList("clientIdlist", workflowCurrentTO.getClientIdList());
			query1.setParameterList("userIDs", userIds);
			if ((workflowCurrentTO.getFromDate() != null) && (workflowCurrentTO.getToDate() == null)) {
				query1.setDate("datefrom", dateFrom);
			}
			if ((workflowCurrentTO.getToDate() != null) && (workflowCurrentTO.getFromDate() == null)) {
				query1.setDate("dateto", dateTo);
			}
			if ((workflowCurrentTO.getToDate() != null) && (workflowCurrentTO.getFromDate() != null)) {
				query1.setDate("datefrom", dateFrom);
				query1.setDate("dateto", dateTo);
			}
			List<Object[]> temp = query1.list();
			for (Object[] obj : temp) {
				BusinessUnitTO buto = new BusinessUnitTO();
				ProjectsTO pto = new ProjectsTO();
				ApplicationTO ato = new ApplicationTO();
				EnvironmentTO eto = new EnvironmentTO();
				WorkflowCurrentTO workflowCurrentTOnew = (WorkflowCurrentTO) obj[0];
				Long createdby = (Long) obj[4];
				Long currOwnerId = workflowCurrentTOnew.getCurrentOwner();
				StringBuilder userQuery = new StringBuilder("select u.name from UserTO u where u.id=?");
				String userName = (String) getHibernateTemplate().find(userQuery.toString(), currOwnerId).get(0);// to
				String createdByUser = (String) getHibernateTemplate().find(userQuery.toString(), createdby).get(0);
				workflowCurrentTOnew.setCreatedByUser(createdByUser);
				buto.setName(obj[1].toString());
				workflowCurrentTOnew.setBusinessUnitTO(buto);
				ato.setAppName(obj[2].toString());
				workflowCurrentTOnew.setAppTO(ato);
				pto.setName(obj[3].toString());
				workflowCurrentTOnew.setProjectsTO(pto);
				if (workflowCurrentTOnew.getEnvironmentId() != null) {
					StringBuilder query_env = new StringBuilder("select e.environmentName from EnvironmentTO e where e.id=?");
					String env_name = (String) getHibernateTemplate().find(query_env.toString(), workflowCurrentTOnew.getEnvironmentId()).get(0);
					eto.setEnvironmentName(env_name);
					workflowCurrentTOnew.setEnvironmentTO(eto);
				} else {
					eto.setEnvironmentName("NA");
					workflowCurrentTOnew.setEnvironmentTO(eto);
				}
				workflowCurrentTOnew.setCurrentOwnerName(userName);
				workflowCurrentTOnew.setDeploymentPipelineFlag("No");
				dbWorklists.add(workflowCurrentTOnew);
			}
			return dbWorklists;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : searchWorkList", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : searchWorkList", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public WorkFlowRequestTO viewEnvReqWorkflow(Long reqId) throws CMMException {
	
		DateFormat localDf = new SimpleDateFormat("dd/MM/yyyy");
		WorkFlowRequestTO worklist = new WorkFlowRequestTO();// this TO contains
		String query = " select wcto ,buto.name, appto.appName,pto.name from WorkflowCurrentTO wcto,BusinessUnitTO buto, ApplicationTO appto ,ProjectsTO pto  where wcto.clientId =buto.clientId and wcto.applicationId =appto.id  and wcto.projectId =pto.id";
		DetachedCriteria criteria2 = DetachedCriteria.forClass(WorkflowHistoryTO.class);
		Session session = null;
		try {
			if (reqId != null) {
				query = query + "  and wcto.reqId =" + reqId;
			}
			session = getSession();
			Query query3 = session.createQuery(query);// session closed in finally
			Object[] temps = (Object[]) query3.list().get(0);
			BusinessUnitTO buto = new BusinessUnitTO();
			ProjectsTO pto = new ProjectsTO();
			ApplicationTO ato = new ApplicationTO();
			EnvironmentTO eto = new EnvironmentTO();
			WorkflowCurrentTO dbCurrentWorklist = (WorkflowCurrentTO) temps[0];
			buto.setName(temps[1].toString());
			dbCurrentWorklist.setBusinessUnitTO(buto);
			ato.setAppName(temps[2].toString());
			dbCurrentWorklist.setAppTO(ato);
			pto.setName(temps[3].toString());
			dbCurrentWorklist.setProjectsTO(pto);
			if (dbCurrentWorklist.getEnvironmentId() != null) {
				StringBuilder query_env = new StringBuilder("select e.environmentName from EnvironmentTO e where e.id=?");
				String env_name = (String) getHibernateTemplate().find(query_env.toString(), dbCurrentWorklist.getEnvironmentId()).get(0);
				eto.setEnvironmentName(env_name);
				dbCurrentWorklist.setEnvironmentTO(eto);
			} else {
				eto.setEnvironmentName("NA");
				dbCurrentWorklist.setEnvironmentTO(eto);
			}
			if (reqId != null) {
				criteria2.add(Restrictions.like("wf_current_id", reqId));
				criteria2.addOrder(Order.asc("levelOrder"));
			}
			List<WorkflowHistoryTO> dbHistoryWorklist = new LinkedList<WorkflowHistoryTO>();
			dbHistoryWorklist = (List<WorkflowHistoryTO>) getHibernateTemplate().findByCriteria(criteria2);
			StringBuilder query2 = new StringBuilder("select r.name from RoleTO r where r.id=?");
			for (WorkflowHistoryTO obj : dbHistoryWorklist) {
				String roleName = (String) getHibernateTemplate().find(query2.toString(), obj.getStatusChangedByRole()).get(0);
				obj.setStatusChangedByRoleName(roleName);
			}
			for (WorkflowHistoryTO obj : dbHistoryWorklist) {
				if (obj.getAction_performed_by_role() != null) {
					String roleName = (String) getHibernateTemplate().find(query2.toString(), obj.getAction_performed_by_role()).get(0);
					obj.setAction_performed_by_role_name(roleName);
				}
			}
			worklist.setWorkflowHistoryTO(dbHistoryWorklist);
			worklist.setWorkflowCurrentTO(dbCurrentWorklist);
			Long serviceReqId = worklist.getWorkflowCurrentTO().getServiceRequestId();
			if (serviceReqId != null) {
				List<ServiceRequestTO> requestToList = (List<ServiceRequestTO>) getHibernateTemplate().find("from ServiceRequestTO where id= ?", serviceReqId);
				for (ServiceRequestTO serviceRequestTo : requestToList) {
					ServiceRequestTO SrvicerequestToNew = new ServiceRequestTO();
					if (serviceRequestTo.getStartTime() != null) {
						SrvicerequestToNew.setStartTimeStr(localDf.format(serviceRequestTo.getStartTime()));
					}
					if (serviceRequestTo.getEndTime() != null) {
						SrvicerequestToNew.setEndTimeStr(localDf.format(serviceRequestTo.getEndTime()));
					}
					if (!requestToList.isEmpty()) {
						if (requestToList.get(0).getApplicationReleaseId() != null) {
							List<ApplicationReleaseTO> releaseList = (List<ApplicationReleaseTO>) getHibernateTemplate().find("from ApplicationReleaseTO where id= ?", requestToList.get(0).getApplicationReleaseId());
							if (releaseList.size() > 0L) {
								worklist.setReleaseName(releaseList.get(0).getName());
							}
						}
						worklist.setServiceRequest(requestToList.get(0));
					}
					worklist.setServiceRequestTo(SrvicerequestToNew);
				}
			}
			DetachedCriteria criteria = DetachedCriteria.forClass(ReservationTO.class);
			if (dbCurrentWorklist.getEntity_id() != null) {
				criteria.add(Restrictions.like("id", dbCurrentWorklist.getEntity_id()));// in
				ReservationTO dbReservationDtls = (ReservationTO) getHibernateTemplate().findByCriteria(criteria).get(0);
				if (dbReservationDtls.getStartTime() != null) {
					dbCurrentWorklist.setFromDate(localDf.format(dbReservationDtls.getStartTime()));
				}
				if (dbReservationDtls.getEndTime() != null) {
					dbCurrentWorklist.setToDate(localDf.format(dbReservationDtls.getEndTime()));
				}
				if ((dbReservationDtls.getDisruptive() != null) && dbReservationDtls.getDisruptive().equalsIgnoreCase(CMMConstants.Framework.ReservationStatus.RESERVATION_DISRUPTIVE)) {
					dbCurrentWorklist.setDisruptive("Disruptive");
				} else if ((dbReservationDtls.getDisruptive() != null) && dbReservationDtls.getDisruptive().equalsIgnoreCase(CMMConstants.Framework.ReservationStatus.RESERVATION_LOCKED)) {
					dbCurrentWorklist.setDisruptive("Locked");
				} else {
					dbCurrentWorklist.setDisruptive("Shared");
				}
				if (dbReservationDtls.getReleasePlan() != null) {
					List<ReleasePlanningTO> releasePlanName = (List<ReleasePlanningTO>) getHibernateTemplate().find("select r from ReleasePlanningTO r where r.id=?", dbReservationDtls.getReleasePlan());
					if (!releasePlanName.isEmpty()) {
						dbCurrentWorklist.setReleasePlanName(releasePlanName.get(0).getName());
					}
				} else {
					dbCurrentWorklist.setReleasePlanName("NA");
				}
				if (dbReservationDtls.getTestingPhase() != null) {
					List<TestingPhaseTO> testPhase = (List<TestingPhaseTO>) getHibernateTemplate().find("select t from TestingPhaseTO t where t.id=?", dbReservationDtls.getTestingPhase());
					if (!testPhase.isEmpty()) {
						dbCurrentWorklist.setTestingPhaseName(testPhase.get(0).getName());
					}
				} else {
					dbCurrentWorklist.setTestingPhaseName("NA");
				}
				worklist.setWorkflowCurrentTO(dbCurrentWorklist);
				if ((dbCurrentWorklist.getWorkFlowTO().getId() == 3) && (dbReservationDtls.getIsconflicting() == 1)) {
					/* Changing the query for bug 2880 */
					String query1 = "select r.id,r.startTime,r.endTime,r.userId,am.name , s.statusDesc,r.testingType, t.name from ReservationTO r,StatusTO s,AllocationMasterTO am , TestingTypeTO t  where s.id = r.status.id and r.environments.id=?  and ((r.startTime >= ? and r.endTime <= ?) or (r.startTime <= ? and r.endTime >= ?) or (r.startTime <= ? and r.endTime > ?) or (r.startTime < ? and  r.endTime >= ?)) and r.disruptive =am.id and r.status.id=? and r.id !=? and r.disruptive=am.id  and r.testingType = t.id ";
					/* change ends here */
					List<Object[]> conflictidList = (List<Object[]>) getHibernateTemplate().find(query1, dbReservationDtls.getEnvironments().getId(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getEndTime(), CMMConstants.Framework.Entity.RESERVATION_STATUS_APPROVED, dbReservationDtls.getId());
					List<ReservationTO> tempReservation = new ArrayList<ReservationTO>();
					if (!conflictidList.isEmpty()) {
						for (Object[] temp : conflictidList) {
							ReservationTO reservations = new ReservationTO();
							reservations.setId(Long.parseLong(temp[0].toString()));
							reservations.setStartTime((Date) temp[1]);
							reservations.setEndTime((Date) temp[2]);
							reservations.setUserId(Long.parseLong(temp[3].toString()));
							reservations.setDisruptive(temp[4].toString());
							reservations.setStatusDesc(temp[5].toString());
							reservations.setTestingType(Long.parseLong(temp[6].toString()));
							/* Addition for bug 2979 */
							reservations.setTestingTypeDesc(temp[7].toString());
							/* Addition ends here */
							tempReservation.add(reservations);
						}
					}
					worklist.setReservationTO(tempReservation);
				}
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : viewEnvReqWorkflow", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : viewEnvReqWorkflow", he);
		} catch (Exception e) {
			logger.error(e);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : viewEnvReqWorkflow", e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return worklist;
	}
	
	/*
	 * used to check if work flow levels define for the selected client and work flow action
	 * @clientId - client id
	 * @workFlowId - work flow id
	 */
	@Override
	public List<WorkFlowLevelTO> checkWorkFlowDefined(long clientId, long workFlowId) throws CMMException {
	
		try {
			DetachedCriteria criteria1 = DetachedCriteria.forClass(WorkFlowLevelTO.class);
			criteria1.add(Restrictions.eq("clientId", clientId));
			criteria1.add(Restrictions.eq("workflowId", workFlowId));
			return (List<WorkFlowLevelTO>) getHibernateTemplate().findByCriteria(criteria1);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : checkWorkFlowDefined", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : checkWorkFlowDefined", he);
		}
	}
	
	@Override
	public ApplicationTO fetchApplication(Long application_id) throws CMMException {
	
		try {
			ApplicationTO appTo = new ApplicationTO();
			appTo = (ApplicationTO) getHibernateTemplate().find("from ApplicationTO where id=?", application_id).get(0);
			return appTo;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : checkWorkFlowDefined", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : checkWorkFlowDefined", he);
		}
	}
	
	@Override
	public WorkflowCurrentTO approveRequest(WorkFlowRequestTO workFlowRequestTO) throws CMMException {
	
		WorkflowCurrentTO workflowCurrentTO = workFlowRequestTO.getWorkflowCurrentTO();
		List<WorkflowHistoryTO> workflowHistoryTO = workFlowRequestTO.getWorkflowHistoryTO();
		Long historyLevelOrder = null;
		Long currentLevelOrder = null;
		Long currentOwner = null;
		Long envStatus = null;
		Long serviceRequestHistory = null;
		Long statusValue = 85L;
		try {
			for (WorkflowHistoryTO obj : workflowHistoryTO) {
				if (obj.getLevelOrder().equals(workflowCurrentTO.getLevelOrder()) && obj.getWf_current_id().equals(workflowCurrentTO.getReqId())) {
					obj.setStatusChangedById(workFlowRequestTO.getWorkflowCurrentTO().getLoggedInUser());
					WorkflowStatusTO wfStatusTO = (WorkflowStatusTO) getHibernateTemplate().find("from WorkflowStatusTO where id = 4L").get(0);
					WorkflowHistoryTO workflowHistoryTOnew = (WorkflowHistoryTO) getHibernateTemplate().find("from WorkflowHistoryTO where wf_current_id =? and levelOrder=?", obj.getWf_current_id(), obj.getLevelOrder()).get(0);
					workflowHistoryTOnew.setWfStatusTO(wfStatusTO);
					workflowHistoryTOnew.setStatusChangedDate(DateUtils.getStartTime(new Date()));
					workflowHistoryTOnew.setLastUpdateBy(workFlowRequestTO.getWorkflowCurrentTO().getLoggedInUser());
					workflowHistoryTOnew.setComments(obj.getComments());
					workflowHistoryTOnew.setMessageForUser(obj.getMessageForUser());
					workflowHistoryTOnew.setLastUpdateDate(DateUtils.getStartTime(new Date()));
					workflowHistoryTOnew.setAction_performed_by(workFlowRequestTO.getAction_performed_by());
					workflowHistoryTOnew.setAction_performed_by_role(workFlowRequestTO.getAction_performed_by_role());
					workflowHistoryTOnew.setAction_performed_by_name(workFlowRequestTO.getAction_performed_by_name());
					getHibernateTemplate().update(workflowHistoryTOnew);
					historyLevelOrder = obj.getLevelOrder();
					if (historyLevelOrder != (workflowHistoryTO.size() - 1)) {
						currentLevelOrder = historyLevelOrder + 1;
					}
				}
			}
			for (WorkflowHistoryTO obj : workflowHistoryTO) {
				if (obj.getLevelOrder().equals(currentLevelOrder)) {// on
					currentOwner = obj.getUserTO().getId();// set that level
					break;
				} else if (obj.getLevelOrder() == (workflowHistoryTO.size() - 1)) {
					currentOwner = workFlowRequestTO.getWorkflowCurrentTO().getLoggedInUser();// current
					currentLevelOrder = (long) (workflowHistoryTO.size() - 1);// current
					break;
				}
			}
			if (historyLevelOrder <= (workflowHistoryTO.size() - 1)) {
				workflowCurrentTO.setLevelOrder(currentLevelOrder);
				if (historyLevelOrder == (workflowHistoryTO.size() - 1)) {
					workflowCurrentTO.getWfStatusTO().setId(3L);// set status
				} else {
					workflowCurrentTO.getWfStatusTO().setId(2L);// else set
				}
				workflowCurrentTO.setCurrentOwner(currentOwner);
				WorkflowStatusTO wfStatusTO = (WorkflowStatusTO) getHibernateTemplate().find("from WorkflowStatusTO where id = ?", workflowCurrentTO.getWfStatusTO().getId()).get(0);
				WorkflowCurrentTO WorkflowCurrentTOnew = (WorkflowCurrentTO) getHibernateTemplate().find("from WorkflowCurrentTO where id =?", workflowCurrentTO.getReqId()).get(0);
				WorkflowCurrentTOnew.setCurrentOwner(workflowCurrentTO.getCurrentOwner());
				WorkflowCurrentTOnew.setLevelOrder(workflowCurrentTO.getLevelOrder());
				WorkflowCurrentTOnew.setWfStatusTO(wfStatusTO);
				getHibernateTemplate().update(WorkflowCurrentTOnew);
				if (workflowCurrentTO.getWfStatusTO().getId() == 3) {
					envStatus = 23L;// set nv status undr implementation
					serviceRequestHistory = 142L;
				} else {
					envStatus = 25L;// else set env status pending approval
					serviceRequestHistory = 141L;
				}
				if ((workflowCurrentTO.getWorkFlowTO().getId() == 3) && (workflowCurrentTO.getWfStatusTO().getId() == 3)) {
					DetachedCriteria criteria = DetachedCriteria.forClass(ReservationTO.class);
					if (workflowCurrentTO.getEntity_id() != null) {
						criteria.add(Restrictions.like("id", workflowCurrentTO.getEntity_id()));
					}
					ReservationTO dbReservationDtls = (ReservationTO) getHibernateTemplate().findByCriteria(criteria).get(0);
					String allocationMode = dbReservationDtls.getDisruptive();
					if (dbReservationDtls.getIsRepetetive() != 1L) {
						if (allocationMode.equals(CMMConstants.Framework.ReservationStatus.RESERVATION_SHARED)) {
							List<ReservationTO> reservationList1 = new ArrayList<ReservationTO>(0);
							String query2 = "select r from ReservationTO as r where r.environments.id =?  and ((r.startTime <= ? and r.endTime >= ? and r.endTime <= ?) or (r.endTime >= ? and r.startTime >= ? and r.startTime <= ?) or (r.startTime <= ? and r.endTime >= ?) or (r.startTime >= ? and r.startTime <= ? and r.endTime >= ? and r.endTime <= ?)) and (r.startTime != ? and r.endTime != ?) and r.status.id IN (81, 84) and r.id !=?";
							reservationList1 = (List<ReservationTO>) getHibernateTemplate().find(query2, dbReservationDtls.getEnvironments().getId(), dbReservationDtls.getStartTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getId());
							Long countSharedApproved = 0L;
							Long countDisruptiveApproved = 0L;
							Long countDisruptivePending = 0L;
							List<ReservationTO> sharedApprovedList = new ArrayList<ReservationTO>(0);
							List<ReservationTO> disruptiveApprovedList = new ArrayList<ReservationTO>(0);
							List<ReservationTO> sharedPendingList = new ArrayList<ReservationTO>(0);
							List<ReservationTO> disruptivePendingList = new ArrayList<ReservationTO>(0);
							for (ReservationTO reservationToObj : reservationList1) {
								if ("S".equalsIgnoreCase(reservationToObj.getDisruptive()) && (reservationToObj.getStatus().getId() == 81L)) {
									sharedApprovedList.add(reservationToObj);
									countSharedApproved++;
								}
								if ("S".equalsIgnoreCase(reservationToObj.getDisruptive()) && (reservationToObj.getStatus().getId() == 84L)) {
									sharedPendingList.add(reservationToObj);
								}
								if (!"S".equalsIgnoreCase(reservationToObj.getDisruptive()) && (reservationToObj.getStatus().getId() == 81L)) {
									disruptiveApprovedList.add(reservationToObj);
									countDisruptiveApproved++;
								}
								if (!"S".equalsIgnoreCase(reservationToObj.getDisruptive()) && (reservationToObj.getStatus().getId() == 84L)) {
									countDisruptivePending++;
									disruptivePendingList.add(reservationToObj);
								}
							}
							if ((countSharedApproved < 2L) && (countDisruptiveApproved == 0L)) {
								Long conflictingStatus = 0L;
								if (countDisruptivePending == 0L) {
									StatusTO status = new StatusTO();
									status.setId(CMMConstants.Framework.Entity.RESERVATION_STATUS_APPROVED);
									dbReservationDtls.setStatus(status);
									dbReservationDtls.setIsconflicting(conflictingStatus);
									getHibernateTemplate().update(dbReservationDtls);
								} else if (countDisruptivePending > 0) {
									for (ReservationTO resTo : disruptivePendingList) {
										conflictingStatus = 1L;
										resTo.setIsconflicting(conflictingStatus);
										getHibernateTemplate().update(resTo);
									}
									StatusTO status = new StatusTO();
									status.setId(CMMConstants.Framework.Entity.RESERVATION_STATUS_APPROVED);
									dbReservationDtls.setStatus(status);
									conflictingStatus = 1L;
									dbReservationDtls.setIsconflicting(conflictingStatus);
									getHibernateTemplate().update(dbReservationDtls);
								}
							}
							if (countDisruptiveApproved == 1L) {
								Long conflictingStatus = 0L;
								if (countDisruptivePending == 0L) {
									List<Long> selectedReservations = new ArrayList<Long>(0);
									Long reservationId = disruptiveApprovedList.get(0).getId();
									selectedReservations.add(reservationId);
									disruptiveApprovedList.get(0).setSelectedReservations(selectedReservations);
									reservationDAO.deleteReservations(disruptiveApprovedList.get(0), statusValue);
									StatusTO status1 = new StatusTO();
									status1.setId(CMMConstants.Framework.Entity.RESERVATION_STATUS_APPROVED);
									dbReservationDtls.setStatus(status1);
									getHibernateTemplate().update(dbReservationDtls);
								}
								if (countDisruptivePending > 0L) {
									for (ReservationTO resTo : sharedPendingList) {
										conflictingStatus = 1L;
										resTo.setIsconflicting(conflictingStatus);
										getHibernateTemplate().update(resTo);
									}
									for (ReservationTO resTo : disruptivePendingList) {
										conflictingStatus = 1L;
										resTo.setIsconflicting(conflictingStatus);
										getHibernateTemplate().update(resTo);
									}
									StatusTO status = new StatusTO();
									status.setId(CMMConstants.Framework.Entity.RESERVATION_STATUS_APPROVED);
									dbReservationDtls.setStatus(status);
									conflictingStatus = 1L;
									dbReservationDtls.setIsconflicting(conflictingStatus);
									getHibernateTemplate().update(dbReservationDtls);
									List<Long> selectedReservations = new ArrayList<Long>(0);
									Long reservationId = disruptiveApprovedList.get(0).getId();
									selectedReservations.add(reservationId);
									disruptiveApprovedList.get(0).setSelectedReservations(selectedReservations);
									reservationDAO.deleteReservations(disruptiveApprovedList.get(0), statusValue);
								}
							}
						}
						if (allocationMode.equals(CMMConstants.Framework.ReservationStatus.RESERVATION_DISRUPTIVE) || allocationMode.equals(CMMConstants.Framework.ReservationStatus.RESERVATION_LOCKED)) {
							if (dbReservationDtls.getIsconflicting() == 1L) {
								String query3 = "select r from ReservationTO as r where r.environments.id =?  and ((r.startTime <= ? and r.endTime >= ? and r.endTime <= ?) or (r.endTime >= ? and r.startTime >= ? and r.startTime <= ?) or (r.startTime <= ? and r.endTime >= ?) or (r.startTime >= ? and r.startTime <= ? and r.endTime >= ? and r.endTime <= ?)) and (r.startTime != ? and r.endTime != ?) and r.status.id =? and r.id !=?";
								List<ReservationTO> reservation3 = (List<ReservationTO>) getHibernateTemplate().find(query3, dbReservationDtls.getEnvironments().getId(), dbReservationDtls.getStartTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getStartTime(), CMMConstants.Framework.Entity.RESERVATION_STATUS_APPROVED, dbReservationDtls.getId());
								for (ReservationTO res : reservation3) {
									List<Long> selectedReservations = new ArrayList<Long>(0);
									Long reservationId = res.getId();
									selectedReservations.add(reservationId);
									res.setSelectedReservations(selectedReservations);
									reservationDAO.deleteReservations(res, statusValue);
								}
							}
							StatusTO statusTo = new StatusTO();
							statusTo.setId(CMMConstants.Framework.Entity.RESERVATION_STATUS_APPROVED);
							dbReservationDtls.setStatus(statusTo);
							getHibernateTemplate().update(dbReservationDtls);
							/*
							 * Changes by Saumya for pending conflict request with isConflicting flag as 1, start
							 */
							String query4 = "select r from ReservationTO as r where r.environments.id=? and ((r.startTime >= ? and r.endTime <= ?) or (r.startTime <= ? and r.endTime >= ?) or (r.startTime <= ? and r.endTime > ?) or (r.startTime < ? and  r.endTime >= ?)) and r.status.id=? and r.id !=? ";
							List<ReservationTO> reservation4 = (List<ReservationTO>) getHibernateTemplate().find(query4, dbReservationDtls.getEnvironments().getId(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getEndTime(), CMMConstants.Framework.Entity.RESERVATION_STATUS_PENDING, dbReservationDtls.getId());
							Long countSharedPending1 = 0L;
							Long countDisruptivePending1 = 0L;
							Long countLockedPending1 = 0L;
							List<ReservationTO> sharedPendingList1 = new ArrayList<ReservationTO>(0);
							List<ReservationTO> disruptivePendingList1 = new ArrayList<ReservationTO>(0);
							List<ReservationTO> lockedPendingList1 = new ArrayList<ReservationTO>(0);
							for (ReservationTO reservationToObj : reservation4) {
								if ("S".equalsIgnoreCase(reservationToObj.getDisruptive()) && (reservationToObj.getStatus().getId() == 84L)) {
									countSharedPending1++;
									sharedPendingList1.add(reservationToObj);
								}
								if (!"D".equalsIgnoreCase(reservationToObj.getDisruptive()) && (reservationToObj.getStatus().getId() == 84L)) {
									countDisruptivePending1++;
									disruptivePendingList1.add(reservationToObj);
								}
								if (!"L".equalsIgnoreCase(reservationToObj.getDisruptive()) && (reservationToObj.getStatus().getId() == 84L)) {
									countLockedPending1++;
									lockedPendingList1.add(reservationToObj);
								}
							}
							if ((countSharedPending1 > 0) || (countDisruptivePending1 > 0) || (countLockedPending1 > 0)) {
								dbReservationDtls.setIsconflicting(1L);
								getHibernateTemplate().update(dbReservationDtls);
								for (ReservationTO res : sharedPendingList1) {
									res.setIsconflicting(1L);
									getHibernateTemplate().update(res);
								}
								for (ReservationTO res : disruptivePendingList1) {
									res.setIsconflicting(1L);
									getHibernateTemplate().update(res);
								}
								for (ReservationTO res : lockedPendingList1) {
									res.setIsconflicting(1L);
									getHibernateTemplate().update(res);// Saumya
								}
							}
							/*
							 * Changes by Saumya for pending conflict request with isConflicting flag as 1,end
							 */
							else {
								dbReservationDtls.setIsconflicting(0L);
								getHibernateTemplate().update(dbReservationDtls);
							}
						}
					} else {
						checkChild(dbReservationDtls);
					}
				} else {
					if (workflowCurrentTO.getWorkFlowTO().getId() == 1) {
						EnvironmentTO environmentTO = (EnvironmentTO) getHibernateTemplate().find("from EnvironmentTO where id =?", workflowCurrentTO.getEnvironmentId()).get(0);
						environmentTO.setStatus(envStatus);
						getHibernateTemplate().update(environmentTO);
					}
					List<ServiceRequestTO> serviceRequestTOlist = (List<ServiceRequestTO>) getHibernateTemplate().find("from ServiceRequestTO where id =?", workflowCurrentTO.getServiceRequestId());
					if (!serviceRequestTOlist.isEmpty()) {
						ServiceRequestTO serviceRequestTO = serviceRequestTOlist.get(0);
						if ((serviceRequestTO.getParentRequestId() != null) && (serviceRequestTO.getParentRequestId() > 0L)) {
							serviceRequestTO.setStatusId(CMMConstants.Framework.Entity.SERVICE_REQUEST_NOT_STARTED);
						} else {
							serviceRequestTO.setStatusId(serviceRequestHistory);
						}
						getHibernateTemplate().update(serviceRequestTO);
					}
				}
			}
			return workflowCurrentTO;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : approveRequest", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : approveRequest", he);
		} catch (Exception he) {
			logger.error(he);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : approveRequest", he);
		}
	}
	
	@Override
	public List<WorkflowCurrentTO> onLoadWorkList(Long userId) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			List<WorkflowCurrentTO> dbWorklists = new ArrayList<WorkflowCurrentTO>(0);
			String query = " select wcto ,buto.name, appto.appName,pto.name ,eto.environmentName from WorkflowCurrentTO wcto,BusinessUnitTO buto, ApplicationTO appto ,ProjectsTO pto, EnvironmentTO eto  where wcto.clientId =buto.clientId and wcto.applicationId =appto.id and wcto.environmentId =eto.id and wcto.projectId =pto.id  and ( wcto.currentOwner =" + userId + " OR  wcto.userTO.id = " + userId + ")  and wcto.wfStatusTO.id = 2L";
			Query query1 = session.createQuery(query);
			List<Object[]> temp = query1.list();
			for (Object[] obj : temp) {
				BusinessUnitTO buto = new BusinessUnitTO();
				ProjectsTO pto = new ProjectsTO();
				ApplicationTO ato = new ApplicationTO();
				EnvironmentTO eto = new EnvironmentTO();
				WorkflowCurrentTO workflowCurrentTOnew = (WorkflowCurrentTO) obj[0];
				Long currOwnerId = workflowCurrentTOnew.getCurrentOwner();
				StringBuilder userQuery = new StringBuilder("select u.name from UserTO u where u.id=?");
				String userName = (String) getHibernateTemplate().find(userQuery.toString(), currOwnerId).get(0);// to
				workflowCurrentTOnew.setCurrentOwnerName(userName);
				buto.setName(obj[1].toString());
				workflowCurrentTOnew.setBusinessUnitTO(buto);
				ato.setAppName(obj[2].toString());
				workflowCurrentTOnew.setAppTO(ato);
				pto.setName(obj[3].toString());
				workflowCurrentTOnew.setProjectsTO(pto);
				eto.setEnvironmentName(obj[4].toString());
				workflowCurrentTOnew.setEnvironmentTO(eto);
				workflowCurrentTOnew.setDeploymentPipelineFlag("No");
				if (workflowCurrentTOnew.getServiceRequestId() != null) {
					List<ServiceRequestTO> serviceRequestToList = (List<ServiceRequestTO>) getHibernateTemplate().find("from ServiceRequestTO where id =?", workflowCurrentTOnew.getServiceRequestId());
					if (serviceRequestToList.size() > 0L) {
						ServiceRequestTO serviceRequestTO = new ServiceRequestTO();
						serviceRequestTO = serviceRequestToList.get(0);
						if ((serviceRequestTO.getPipelineRequest() != null) && "Y".equalsIgnoreCase(serviceRequestTO.getPipelineRequest())) {
							workflowCurrentTOnew.setDeploymentPipelineFlag("Yes");
						}
					}
				}
				dbWorklists.add(workflowCurrentTOnew);
			}
			return dbWorklists;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : onLoadWorkList", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : onLoadWorkList", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<WorkflowCurrentTO> onLoadWorkList(Long userId, List<Long> clientIdlist) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			List<WorkflowCurrentTO> dbWorklists = new ArrayList<WorkflowCurrentTO>(0);
			String query = " select distinct wcto ,buto.name, appto.appName,pto.name ,eto.environmentName from WorkflowCurrentTO wcto,BusinessUnitTO buto, ApplicationTO appto ,ProjectsTO pto, EnvironmentTO eto , WorkflowHistoryTO whto  where wcto.clientId =buto.clientId and wcto.id = whto.wf_current_id  and wcto.applicationId =appto.id and wcto.environmentId =eto.id and wcto.projectId =pto.id  and whto.userTO.id =" + userId + " and (whto.wfStatusTO.id is null or whto.wfStatusTO.id=1L) ";
			if (!((clientIdlist.size() == 1) && (clientIdlist.get(0) == 0L))) {
				query = query + "and wcto.clientId in (:clientIdlist)";
			}
			query = query + " order by wcto.wfStatusTO.id asc ";
			Query query1 = session.createQuery(query);
			if (!((clientIdlist.size() == 1) && (clientIdlist.get(0) == 0L))) {
				query1.setParameterList("clientIdlist", clientIdlist);
			}
			List<Object[]> temp = query1.list();
			for (Object[] obj : temp) {
				BusinessUnitTO buto = new BusinessUnitTO();
				ProjectsTO pto = new ProjectsTO();
				ApplicationTO ato = new ApplicationTO();
				EnvironmentTO eto = new EnvironmentTO();
				WorkflowCurrentTO workflowCurrentTOnew = (WorkflowCurrentTO) obj[0];
				Long currOwnerId = workflowCurrentTOnew.getCurrentOwner();
				StringBuilder userQuery = new StringBuilder("select u.name from UserTO u where u.id=?");
				String userName = (String) getHibernateTemplate().find(userQuery.toString(), currOwnerId).get(0);// to
				workflowCurrentTOnew.setCurrentOwnerName(userName);
				buto.setName(obj[1].toString());
				workflowCurrentTOnew.setBusinessUnitTO(buto);
				ato.setAppName(obj[2].toString());
				workflowCurrentTOnew.setAppTO(ato);
				pto.setName(obj[3].toString());
				workflowCurrentTOnew.setProjectsTO(pto);
				eto.setEnvironmentName(obj[4].toString());
				workflowCurrentTOnew.setEnvironmentTO(eto);
				workflowCurrentTOnew.setDeploymentPipelineFlag("No");
				if (workflowCurrentTOnew.getServiceRequestId() != null) {
					List<ServiceRequestTO> serviceRequestToList = (List<ServiceRequestTO>) getHibernateTemplate().find("from ServiceRequestTO where id =?", workflowCurrentTOnew.getServiceRequestId());
					if (serviceRequestToList.size() > 0L) {
						ServiceRequestTO serviceRequestTO = new ServiceRequestTO();
						serviceRequestTO = serviceRequestToList.get(0);
						if ((serviceRequestTO.getPipelineRequest() != null) && "Y".equalsIgnoreCase(serviceRequestTO.getPipelineRequest())) {
							workflowCurrentTOnew.setDeploymentPipelineFlag("Yes");
						}
					}
				}
				dbWorklists.add(workflowCurrentTOnew);
			}
			return dbWorklists;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : onLoadWorkList", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : onLoadWorkList", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public void rejectRequest(WorkFlowRequestTO workFlowRequestTO) throws CMMException {
	
		WorkflowCurrentTO workflowCurrentTO = workFlowRequestTO.getWorkflowCurrentTO();
		List<WorkflowHistoryTO> workflowHistoryTO = workFlowRequestTO.getWorkflowHistoryTO();
		Long statusValue = 85L;
		Long isRepetetive;
		List<ReservationTO> childReserv = new ArrayList<ReservationTO>();
		try {
			for (WorkflowHistoryTO obj : workflowHistoryTO) {
				if (obj.getLevelOrder().equals(workflowCurrentTO.getLevelOrder()) && obj.getWf_current_id().equals(workflowCurrentTO.getReqId())) {
					obj.setStatusChangedById(workFlowRequestTO.getWorkflowCurrentTO().getLoggedInUser());
					WorkflowStatusTO wfStatusTO = (WorkflowStatusTO) getHibernateTemplate().find("from WorkflowStatusTO where id = 5L").get(0);
					WorkflowHistoryTO workflowHistoryTOnew = (WorkflowHistoryTO) getHibernateTemplate().find("from WorkflowHistoryTO where wf_current_id =? and levelOrder=?", obj.getWf_current_id(), obj.getLevelOrder()).get(0);
					workflowHistoryTOnew.setWfStatusTO(wfStatusTO);
					workflowHistoryTOnew.setStatusChangedDate(DateUtils.getStartTime(new Date()));
					workflowHistoryTOnew.setLastUpdateBy(workFlowRequestTO.getWorkflowCurrentTO().getLoggedInUser());
					workflowHistoryTOnew.setComments(obj.getComments());
					workflowHistoryTOnew.setMessageForUser(obj.getMessageForUser());
					workflowHistoryTOnew.setLastUpdateDate(DateUtils.getStartTime(new Date()));
					workflowHistoryTOnew.setAction_performed_by(workFlowRequestTO.getAction_performed_by());
					workflowHistoryTOnew.setAction_performed_by_role(workFlowRequestTO.getAction_performed_by_role());
					workflowHistoryTOnew.setAction_performed_by_name(workFlowRequestTO.getAction_performed_by_name());
					getHibernateTemplate().update(workflowHistoryTOnew);
					break;
				}
			}
			WorkflowStatusTO wfStatusTO = (WorkflowStatusTO) getHibernateTemplate().find("from WorkflowStatusTO where id = 5L").get(0);
			WorkflowCurrentTO WorkflowCurrentTOnew = (WorkflowCurrentTO) getHibernateTemplate().find("from WorkflowCurrentTO where id =?", workflowCurrentTO.getReqId()).get(0);
			WorkflowCurrentTOnew.setWfStatusTO(wfStatusTO);
			getHibernateTemplate().update(WorkflowCurrentTOnew);
			if (workflowCurrentTO.getWorkFlowTO().getId() == 3) {
				Long reservationId = workflowCurrentTO.getEntity_id();
				List<Long> selectedReservation = new ArrayList<Long>(0);
				selectedReservation.add(reservationId);
				ReservationTO reservationTO = new ReservationTO();
				reservationTO.setSelectedReservations(selectedReservation);
				reservationDAO.deleteReservations(reservationTO, statusValue);
				isRepetetive = getIsRepetitiveReservation(reservationId);
				if (isRepetetive == 1L) {
					int i;
					childReserv = fetchChildReservations(reservationId);
					for (i = 0; i < childReserv.size(); i++) {
						List<Long> childselectedReservations = new ArrayList<Long>(0);
						Long id = childReserv.get(i).getId();
						childselectedReservations.add(id);
						ReservationTO childreservationTO = new ReservationTO();
						childreservationTO.setSelectedReservations(childselectedReservations);
						reservationDAO.deleteReservations(childreservationTO, statusValue);
					}
				}
			} else {
				if (workflowCurrentTO.getWorkFlowTO().getId() == 1) {
					EnvironmentTO environmentTO = (EnvironmentTO) getHibernateTemplate().find("from EnvironmentTO where id =?", workflowCurrentTO.getEnvironmentId()).get(0);
					environmentTO.setStatus(26L);
					getHibernateTemplate().update(environmentTO);
				}
				List<ServiceRequestTO> serviceRequestTOlist = (List<ServiceRequestTO>) getHibernateTemplate().find("from ServiceRequestTO where id =?", workflowCurrentTO.getServiceRequestId());
				if (!serviceRequestTOlist.isEmpty()) {
					ServiceRequestTO serviceRequestTO = serviceRequestTOlist.get(0);
					serviceRequestTO.setStatusId(144L);
					serviceRequestTO.setActionFlag(CMMConstants.Framework.ServiceRequestStatus.SERVICE_REQUEST_REJECTED);
					getHibernateTemplate().update(serviceRequestTO);
				}
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : rejectRequest", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : rejectRequest", he);
		}
	}
	
	@Override
	public List<WorkflowCurrentTO> searchWorkListForAdim(WorkflowCurrentTO workflowCurrentTO) throws CMMException {
	
		Session session = null;
		try {
			DateFormat localFormatter = new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy");
			String dateFromStr = null;
			String dateToStr = null;
			Date dateFrom = null;
			Date dateTo = null;
			Calendar cal = Calendar.getInstance();
			String formatedFromDate = null;
			String formatedToDate = null;
			DateFormat formatter1 = new SimpleDateFormat("yyyy-MM-dd");
			if (workflowCurrentTO.getFromDate() != null) {
				dateFromStr = workflowCurrentTO.getFromDate();
				try {
					dateFrom = localFormatter.parse(dateFromStr);
					cal.setTime(dateFrom);
					formatedFromDate = cal.get(Calendar.YEAR) + "-" + (cal.get(Calendar.MONTH) + 1) + "-" + cal.get(Calendar.DATE);
					dateFrom = formatter1.parse(formatedFromDate);
				} catch (ParseException e) {
					throw new CMMException("Error parsing date ", e);
				}
			}
			if (workflowCurrentTO.getToDate() != null) {
				dateToStr = workflowCurrentTO.getToDate();
				try {
					dateTo = localFormatter.parse(dateToStr);
					cal.setTime(dateTo);
					formatedToDate = cal.get(Calendar.YEAR) + "-" + (cal.get(Calendar.MONTH) + 1) + "-" + cal.get(Calendar.DATE);
					dateTo = formatter1.parse(formatedToDate);
				} catch (ParseException e) {
					throw new CMMException("Error parsing date ", e);
				}
			}
			List<WorkflowCurrentTO> dbWorklists = new ArrayList<WorkflowCurrentTO>(0);
			String query = null;
			query = " select distinct wcto ,buto.name, appto.appName,pto.name ,whto.createdBy from WorkflowCurrentTO wcto,BusinessUnitTO buto, ApplicationTO appto ,ProjectsTO pto, WorkflowHistoryTO whto  where wcto.clientId =buto.clientId and wcto.applicationId =appto.id and wcto.projectId =pto.id and whto.wf_current_id =wcto.reqId ";
			if ((workflowCurrentTO.getRequestId() != null) && (workflowCurrentTO.getRequestId() > 0)) {
				query = query + " and wcto.reqId = " + workflowCurrentTO.getRequestId();
			}
			if ((workflowCurrentTO.getServiceRequestId() != null) && (workflowCurrentTO.getServiceRequestId() > 0)) {
				query = query + " and wcto.serviceRequestId = " + workflowCurrentTO.getServiceRequestId();
			}
			if ((workflowCurrentTO.getEntity_id() != null) && (workflowCurrentTO.getEntity_id() > 0)) {
				query = query + " and wcto.entity_id = " + workflowCurrentTO.getEntity_id();
			}
			if ((workflowCurrentTO.getSelectedApp() != null) && (workflowCurrentTO.getSelectedApp() > 0)) {
				query = query + " and appto.id = " + workflowCurrentTO.getSelectedApp();
			}
			if ((workflowCurrentTO.getSelectedWorkFlowAction() != null) && (workflowCurrentTO.getSelectedWorkFlowAction() > 0)) {
				query = query + " and wcto.workFlowTO.id = " + workflowCurrentTO.getSelectedWorkFlowAction();
			}
			if ((workflowCurrentTO.getSelectedStatus() != 4) && (workflowCurrentTO.getSelectedStatus() > 0L)) {
				query = query + " and wcto.wfStatusTO.id = " + workflowCurrentTO.getSelectedStatus();
			}
			if (workflowCurrentTO.getSelectedStatus() == 4) {
				query = query + " and whto.wfStatusTO.id = " + workflowCurrentTO.getSelectedStatus();
			}
			if ((workflowCurrentTO.getFromDate() != null) && (workflowCurrentTO.getToDate() == null)) {
				query = query + " and wcto.requestDate >=:datefrom";
			}
			if ((workflowCurrentTO.getToDate() != null) && (workflowCurrentTO.getFromDate() == null)) {
				query = query + " and wcto.requestDate <=:dateto ";
			}
			if ((workflowCurrentTO.getToDate() != null) && (workflowCurrentTO.getFromDate() != null)) {
				query = query + " and wcto.requestDate >=:datefrom  and wcto.requestDate <=:dateto ";
			}
			/* Added for bug 3253 */
			query = query + " order by wcto.wfStatusTO.id asc ";
			/* Addition ends for bug 3253 */
			session = getSession();
			Query query1 = session.createQuery(query);
			if ((workflowCurrentTO.getFromDate() != null) && (workflowCurrentTO.getToDate() == null)) {
				query1.setDate("datefrom", dateFrom);
			}
			if ((workflowCurrentTO.getToDate() != null) && (workflowCurrentTO.getFromDate() == null)) {
				query1.setDate("dateto", dateTo);
			}
			if ((workflowCurrentTO.getToDate() != null) && (workflowCurrentTO.getFromDate() != null)) {
				query1.setDate("datefrom", dateFrom);
				query1.setDate("dateto", dateTo);
			}
			List<Object[]> temp = query1.list();
			if (workflowCurrentTO.getSearchCount() == 0) {
				for (Object[] obj : temp) {
					BusinessUnitTO buto = new BusinessUnitTO();
					ProjectsTO pto = new ProjectsTO();
					ApplicationTO ato = new ApplicationTO();
					EnvironmentTO eto = new EnvironmentTO();
					WorkflowCurrentTO workflowCurrentTOnew = (WorkflowCurrentTO) obj[0];
					Long createdby = (Long) obj[4];
					Long currOwnerId = workflowCurrentTOnew.getCurrentOwner();
					StringBuilder userQuery = new StringBuilder("select u.name from UserTO u where u.id=?");
					String userName = (String) getHibernateTemplate().find(userQuery.toString(), currOwnerId).get(0);// to
					String createdByUser = (String) getHibernateTemplate().find(userQuery.toString(), createdby).get(0);
					buto.setName(obj[1].toString());
					workflowCurrentTOnew.setBusinessUnitTO(buto);
					ato.setAppName(obj[2].toString());
					workflowCurrentTOnew.setAppTO(ato);
					pto.setName(obj[3].toString());
					workflowCurrentTOnew.setProjectsTO(pto);
					if (workflowCurrentTOnew.getEnvironmentId() != null) {
						StringBuilder query_env = new StringBuilder("select e.environmentName from EnvironmentTO e where e.id=?");
						String env_name = (String) getHibernateTemplate().find(query_env.toString(), workflowCurrentTOnew.getEnvironmentId()).get(0);
						eto.setEnvironmentName(env_name);
						workflowCurrentTOnew.setEnvironmentTO(eto);
					} else {
						eto.setEnvironmentName("NA");
						workflowCurrentTOnew.setEnvironmentTO(eto);
					}
					workflowCurrentTOnew.setCurrentOwnerName(userName);
					workflowCurrentTOnew.setDeploymentPipelineFlag("No");
					workflowCurrentTOnew.setCreatedByUser(createdByUser);
					boolean requestSubmittedWithoutErrorFlag = true;
					if (requestSubmittedWithoutErrorFlag) {
						dbWorklists.add(workflowCurrentTOnew);
					}
				}
			} else {
				query1.setFirstResult(workflowCurrentTO.getFirstResult());
				query1.setMaxResults(workflowCurrentTO.getTableSize());
				for (Object[] obj : temp) {
					BusinessUnitTO buto = new BusinessUnitTO();
					ProjectsTO pto = new ProjectsTO();
					ApplicationTO ato = new ApplicationTO();
					EnvironmentTO eto = new EnvironmentTO();
					WorkflowCurrentTO workflowCurrentTOnew = (WorkflowCurrentTO) obj[0];
					Long currOwnerId = workflowCurrentTOnew.getCurrentOwner();
					StringBuilder userQuery = new StringBuilder("select u.name from UserTO u where u.id=?");
					String userName = (String) getHibernateTemplate().find(userQuery.toString(), currOwnerId).get(0);// to
					buto.setName(obj[1].toString());
					workflowCurrentTOnew.setBusinessUnitTO(buto);
					ato.setAppName(obj[2].toString());
					workflowCurrentTOnew.setAppTO(ato);
					pto.setName(obj[3].toString());
					workflowCurrentTOnew.setProjectsTO(pto);
					if (workflowCurrentTOnew.getEnvironmentId() != null) {
						StringBuilder query_env = new StringBuilder("select e.environmentName from EnvironmentTO e where e.id=?");
						String env_name = (String) getHibernateTemplate().find(query_env.toString(), workflowCurrentTOnew.getEnvironmentId()).get(0);
						eto.setEnvironmentName(env_name);
						workflowCurrentTOnew.setEnvironmentTO(eto);
					} else {
						eto.setEnvironmentName("NA");
						workflowCurrentTOnew.setEnvironmentTO(eto);
					}
					workflowCurrentTOnew.setCurrentOwnerName(userName);
					workflowCurrentTOnew.setDeploymentPipelineFlag("No");
					boolean requestSubmittedWithoutErrorFlag = true;
					if (requestSubmittedWithoutErrorFlag) {
						dbWorklists.add(workflowCurrentTOnew);
					}
				}
			}
			return dbWorklists;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : searchWorkListForAdim", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : searchWorkListForAdim", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	public Long isConflicting(ReservationTO reservation) throws CMMException {
	
		Long reservationId = 0L;
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(ReservationTO.class, "reservation");
			criteria.add(Restrictions.eq("reservation.environments.id", reservation.getEnvironments().getId()));
			criteria.add(Restrictions.le("startTime", reservation.getStartTime()));
			criteria.add(Restrictions.ge("endTime", reservation.getEndTime()));
			criteria.add(Restrictions.eq("status.id", CMMConstants.Framework.Entity.RESERVATION_STATUS_APPROVED));
			criteria.add(Restrictions.eq("disruptive", CMMConstants.Framework.ReservationStatus.RESERVATION_DISRUPTIVE));
			List<ReservationTO> reservationTO = (List<ReservationTO>) getHibernateTemplate().findByCriteria(criteria);
			if (!reservationTO.isEmpty()) {
				ReservationTO res = reservationTO.get(0);
				reservationId = res.getId();
			}
			return reservationId;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : isConflicting", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : isConflicting", he);
		}
	}
	
	@Override
	public List<WorkflowStatusTO> getStatusList() throws CMMException {
	
		try {
			return (List<WorkflowStatusTO>) getHibernateTemplate().find("from WorkflowStatusTO");
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : getStatusList", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : getStatusList", he);
		}
	}
	
	@Override
	public WorkflowCurrentTO updateRequest(WorkFlowRequestTO workFlowRequestTO) throws CMMException {
	
		WorkflowCurrentTO workflowCurrentTO = workFlowRequestTO.getWorkflowCurrentTO();
		List<WorkflowHistoryTO> workflowHistoryTO = workFlowRequestTO.getWorkflowHistoryTO();
		Long historyLevelOrder = null;
		Long currentLevelOrder = null;
		Long currentOwner = null;
		Long statusValue = 85L;
		try {
			for (WorkflowHistoryTO obj : workflowHistoryTO) {
				if (obj.getLevelOrder().equals(workflowCurrentTO.getLevelOrder()) && obj.getWf_current_id().equals(workflowCurrentTO.getReqId())) {
					obj.setStatusChangedById(workFlowRequestTO.getWorkflowCurrentTO().getLoggedInUser());
					WorkflowStatusTO wfStatusTO = (WorkflowStatusTO) getHibernateTemplate().find("from WorkflowStatusTO where id = 4L").get(0);
					WorkflowHistoryTO workflowHistoryTOnew = (WorkflowHistoryTO) getHibernateTemplate().find("from WorkflowHistoryTO where wf_current_id =? and levelOrder=?", obj.getWf_current_id(), obj.getLevelOrder()).get(0);
					workflowHistoryTOnew.setWfStatusTO(wfStatusTO);
					workflowHistoryTOnew.setStatusChangedDate(DateUtils.getStartTime(new Date()));
					workflowHistoryTOnew.setLastUpdateBy(workFlowRequestTO.getWorkflowCurrentTO().getLoggedInUser());
					workflowHistoryTOnew.setComments(obj.getComments());
					workflowHistoryTOnew.setMessageForUser(obj.getMessageForUser());
					workflowHistoryTOnew.setLastUpdateDate(DateUtils.getStartTime(new Date()));
					workflowHistoryTOnew.setAction_performed_by(workFlowRequestTO.getAction_performed_by());
					workflowHistoryTOnew.setAction_performed_by_role(workFlowRequestTO.getAction_performed_by_role());
					workflowHistoryTOnew.setAction_performed_by_name(workFlowRequestTO.getAction_performed_by_name());
					getHibernateTemplate().update(workflowHistoryTOnew);
					historyLevelOrder = obj.getLevelOrder();
					if (historyLevelOrder != (workflowHistoryTO.size() - 1)) {
						currentLevelOrder = historyLevelOrder + 1;
					}
				}
			}
			for (WorkflowHistoryTO obj : workflowHistoryTO) {
				if (obj.getLevelOrder().equals(currentLevelOrder)) {
					currentOwner = obj.getUserTO().getId();// set that level
					break;
				} else if (obj.getLevelOrder() == (workflowHistoryTO.size() - 1)) {
					currentOwner = workFlowRequestTO.getWorkflowCurrentTO().getLoggedInUser();// current
					currentLevelOrder = (long) (workflowHistoryTO.size() - 1);// current
					break;
				}
			}
			if (historyLevelOrder <= (workflowHistoryTO.size() - 1)) {
				workflowCurrentTO.setLevelOrder(currentLevelOrder);
				if (historyLevelOrder == (workflowHistoryTO.size() - 1)) {
					workflowCurrentTO.getWfStatusTO().setId(3L);// set status
				} else {
					workflowCurrentTO.getWfStatusTO().setId(2L);// else set
				}
				workflowCurrentTO.setCurrentOwner(currentOwner);
				WorkflowStatusTO wfStatusTO = (WorkflowStatusTO) getHibernateTemplate().find("from WorkflowStatusTO where id = ?", workflowCurrentTO.getWfStatusTO().getId()).get(0);
				WorkflowCurrentTO WorkflowCurrentTOnew = (WorkflowCurrentTO) getHibernateTemplate().find("from WorkflowCurrentTO where id =?", workflowCurrentTO.getReqId()).get(0);
				WorkflowCurrentTOnew.setCurrentOwner(workflowCurrentTO.getCurrentOwner());
				WorkflowCurrentTOnew.setLevelOrder(workflowCurrentTO.getLevelOrder());
				WorkflowCurrentTOnew.setWfStatusTO(wfStatusTO);
				getHibernateTemplate().update(WorkflowCurrentTOnew);
				if (workflowCurrentTO.getWfStatusTO().getId() == 3) {
					logger.info("WorkFlowDAOImpl updateRequest");
				}
				if (workflowCurrentTO.getWorkFlowTO().getId() == 3) {
					DetachedCriteria criteria = DetachedCriteria.forClass(ReservationTO.class);
					if (workflowCurrentTO.getEntity_id() != null) {
						criteria.add(Restrictions.like("id", workflowCurrentTO.getEntity_id()));
					}
					ReservationTO dbReservationDtls = (ReservationTO) getHibernateTemplate().findByCriteria(criteria).get(0);
					String allocationMode = dbReservationDtls.getDisruptive();
					Long resvStatus = dbReservationDtls.getStatus().getId();
					if (resvStatus == 84L) {
						if (allocationMode.equals(CMMConstants.Framework.ReservationStatus.RESERVATION_SHARED)) {
							List<ReservationTO> reservationList1 = new ArrayList<ReservationTO>(0);
							String query2 = "select r from ReservationTO as r where r.environments.id =?  and ((r.startTime <= ? and r.endTime >= ? and r.endTime <= ?) or (r.endTime >= ? and r.startTime >= ? and r.startTime <= ?) or (r.startTime <= ? and r.endTime >= ?) or (r.startTime >= ? and r.startTime <= ? and r.endTime >= ? and r.endTime <= ?)) and (r.startTime != ? and r.endTime != ?) and r.status.id IN (81, 84) and r.id !=?";
							reservationList1 = (List<ReservationTO>) getHibernateTemplate().find(query2, dbReservationDtls.getEnvironments().getId(), dbReservationDtls.getStartTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getId());
							Long countSharedApproved = 0L;
							Long countDisruptiveApproved = 0L;
							Long countDisruptivePending = 0L;
							List<ReservationTO> sharedApprovedList = new ArrayList<ReservationTO>(0);
							List<ReservationTO> disruptiveApprovedList = new ArrayList<ReservationTO>(0);
							List<ReservationTO> sharedPendingList = new ArrayList<ReservationTO>(0);
							List<ReservationTO> disruptivePendingList = new ArrayList<ReservationTO>(0);
							for (ReservationTO reservationToObj : reservationList1) {
								if ("S".equalsIgnoreCase(reservationToObj.getDisruptive()) && (reservationToObj.getStatus().getId() == 81L)) {
									sharedApprovedList.add(reservationToObj);
									countSharedApproved++;
								}
								if ("S".equalsIgnoreCase(reservationToObj.getDisruptive()) && (reservationToObj.getStatus().getId() == 84L)) {
									sharedPendingList.add(reservationToObj);
								}
								if (!"S".equalsIgnoreCase(reservationToObj.getDisruptive()) && (reservationToObj.getStatus().getId() == 81L)) {
									disruptiveApprovedList.add(reservationToObj);
									countDisruptiveApproved++;
								}
								if (!"S".equalsIgnoreCase(reservationToObj.getDisruptive()) && (reservationToObj.getStatus().getId() == 84L)) {
									countDisruptivePending++;
									disruptivePendingList.add(reservationToObj);
								}
							}
							if ((countSharedApproved < 2L) && (countDisruptiveApproved == 0L)) {
								Long conflictingStatus = 0L;
								if (countDisruptivePending == 0L) {
									StatusTO status = new StatusTO();
									status.setId(CMMConstants.Framework.Entity.RESERVATION_STATUS_APPROVED);
									dbReservationDtls.setStatus(status);
									dbReservationDtls.setIsconflicting(conflictingStatus);
									getHibernateTemplate().update(dbReservationDtls);
								} else if (countDisruptivePending > 0) {
									for (ReservationTO resTo : disruptivePendingList) {
										conflictingStatus = 1L;
										resTo.setIsconflicting(conflictingStatus);
										getHibernateTemplate().update(resTo);
									}
									StatusTO status = new StatusTO();
									status.setId(CMMConstants.Framework.Entity.RESERVATION_STATUS_APPROVED);
									dbReservationDtls.setStatus(status);
									conflictingStatus = 1L;
									dbReservationDtls.setIsconflicting(conflictingStatus);
									getHibernateTemplate().update(dbReservationDtls);
								}
							}
							if (countDisruptiveApproved == 1L) {
								Long conflictingStatus = 0L;
								if (countDisruptivePending == 0L) {
									List<Long> selectedReservations = new ArrayList<Long>(0);
									Long reservationId = disruptiveApprovedList.get(0).getId();
									selectedReservations.add(reservationId);
									disruptiveApprovedList.get(0).setSelectedReservations(selectedReservations);
									reservationDAO.deleteReservations(disruptiveApprovedList.get(0), statusValue);
									StatusTO status1 = new StatusTO();
									status1.setId(CMMConstants.Framework.Entity.RESERVATION_STATUS_APPROVED);
									dbReservationDtls.setStatus(status1);
									getHibernateTemplate().update(dbReservationDtls);
								}
								if (countDisruptivePending > 0L) {
									for (ReservationTO resTo : sharedPendingList) {
										conflictingStatus = 1L;
										resTo.setIsconflicting(conflictingStatus);
										getHibernateTemplate().update(resTo);
									}
									for (ReservationTO resTo : disruptivePendingList) {
										conflictingStatus = 1L;
										resTo.setIsconflicting(conflictingStatus);
										getHibernateTemplate().update(resTo);
									}
									StatusTO status = new StatusTO();
									status.setId(CMMConstants.Framework.Entity.RESERVATION_STATUS_APPROVED);
									dbReservationDtls.setStatus(status);
									conflictingStatus = 1L;
									dbReservationDtls.setIsconflicting(conflictingStatus);
									getHibernateTemplate().update(dbReservationDtls);
									List<Long> selectedReservations = new ArrayList<Long>(0);
									Long reservationId = disruptiveApprovedList.get(0).getId();
									selectedReservations.add(reservationId);
									disruptiveApprovedList.get(0).setSelectedReservations(selectedReservations);
									reservationDAO.deleteReservations(disruptiveApprovedList.get(0), statusValue);
								}
							}
						}
						if (allocationMode.equals(CMMConstants.Framework.ReservationStatus.RESERVATION_DISRUPTIVE) || allocationMode.equals(CMMConstants.Framework.ReservationStatus.RESERVATION_LOCKED)) {
							dbReservationDtls.setEndTime(workFlowRequestTO.getReservationTO().get(0).getEndTime());
							dbReservationDtls.setStartTime(workFlowRequestTO.getReservationTO().get(0).getStartTime());
							getHibernateTemplate().update(dbReservationDtls);
							String query3 = "select r from ReservationTO as r where r.environments.id =?  and ((r.startTime <= ? and r.endTime >= ? and r.endTime <= ?) or (r.endTime >= ? and r.startTime >= ? and r.startTime <= ?) or (r.startTime <= ? and r.endTime >= ?) or (r.startTime >= ? and r.startTime <= ? and r.endTime >= ? and r.endTime <= ?)) and (r.startTime != ? and r.endTime != ?) and r.status.id =? and r.id !=?";
							List<ReservationTO> reservation3 = (List<ReservationTO>) getHibernateTemplate().find(query3, dbReservationDtls.getEnvironments().getId(), dbReservationDtls.getStartTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getStartTime(), CMMConstants.Framework.Entity.RESERVATION_STATUS_APPROVED, dbReservationDtls.getId());
							for (ReservationTO res : reservation3) {
								List<Long> selectedReservations = new ArrayList<Long>(0);
								Long reservationId = res.getId();
								selectedReservations.add(reservationId);
								res.setSelectedReservations(selectedReservations);
								reservationDAO.deleteReservations(res, statusValue);
							}
							String query4 = "select r from ReservationTO as r where r.environments.id=? and ((r.startTime >= ? and r.endTime <= ?) or (r.startTime <= ? and r.endTime >= ?) or (r.startTime <= ? and r.endTime > ?) or (r.startTime < ? and  r.endTime >= ?)) and r.status.id=? and r.id !=? ";
							List<ReservationTO> reservation4 = (List<ReservationTO>) getHibernateTemplate().find(query4, dbReservationDtls.getEnvironments().getId(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getEndTime(), CMMConstants.Framework.Entity.RESERVATION_STATUS_PENDING, dbReservationDtls.getId());
							Long countSharedPending1 = 0L;
							Long countDisruptivePending1 = 0L;
							Long countLockedPending1 = 0L;
							List<ReservationTO> sharedPendingList1 = new ArrayList<ReservationTO>(0);
							List<ReservationTO> disruptivePendingList1 = new ArrayList<ReservationTO>(0);
							List<ReservationTO> lockedPendingList1 = new ArrayList<ReservationTO>(0);
							for (ReservationTO reservationToObj : reservation4) {
								if ("S".equalsIgnoreCase(reservationToObj.getDisruptive()) && (reservationToObj.getStatus().getId() == 84L)) {
									countSharedPending1++;
									sharedPendingList1.add(reservationToObj);
								}
								if (!"D".equalsIgnoreCase(reservationToObj.getDisruptive()) && (reservationToObj.getStatus().getId() == 84L)) {
									countDisruptivePending1++;
									disruptivePendingList1.add(reservationToObj);
								}
								if (!"L".equalsIgnoreCase(reservationToObj.getDisruptive()) && (reservationToObj.getStatus().getId() == 84L)) {
									countLockedPending1++;
									lockedPendingList1.add(reservationToObj);
								}
							}
							if ((countSharedPending1 > 0) || (countDisruptivePending1 > 0) || (countLockedPending1 > 0)) {
								dbReservationDtls.setIsconflicting(1L);
								getHibernateTemplate().update(dbReservationDtls);
								for (ReservationTO res : sharedPendingList1) {
									res.setIsconflicting(1L);
									getHibernateTemplate().update(res);
								}
								for (ReservationTO res : disruptivePendingList1) {
									res.setIsconflicting(1L);
									getHibernateTemplate().update(res);
								}
								for (ReservationTO res : lockedPendingList1) {
									res.setIsconflicting(1L);
									getHibernateTemplate().update(res);// Saumya
								}
							} else {
								dbReservationDtls.setIsconflicting(0L);
								getHibernateTemplate().update(dbReservationDtls);
							}
							StatusTO statusTo = new StatusTO();
							statusTo.setId(CMMConstants.Framework.Entity.RESERVATION_STATUS_APPROVED);
							dbReservationDtls.setStatus(statusTo);
							dbReservationDtls.setEndTime(workFlowRequestTO.getReservationTO().get(0).getEndTime());
							dbReservationDtls.setStartTime(workFlowRequestTO.getReservationTO().get(0).getStartTime());
							getHibernateTemplate().update(dbReservationDtls);
						}
					}
				}
			}
			return workflowCurrentTO;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : approveRequest", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : approveRequest", he);
		}
	}
	
	@Override
	public WorkflowCurrentTO fetchWorkflowDetail(Long parentRequestId) throws CMMException {
	
		try {
			WorkflowCurrentTO workflowObj = new WorkflowCurrentTO();
			List<WorkflowCurrentTO> workflowCurrentList = (List<WorkflowCurrentTO>) getHibernateTemplate().find("from WorkflowCurrentTO where serviceRequestId =?", parentRequestId);
			if (workflowCurrentList.size() > 0L) {
				workflowObj = workflowCurrentList.get(0);
			}
			return workflowObj;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : getStatusList", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : getStatusList", he);
		}
	}
	
	@Override
	public void updatePipelineRequestDetail(Long serviceRequestId) throws CMMException {
	
		try {
			List<PipelineRequestDetailsTO> pipelineRequests = (List<PipelineRequestDetailsTO>) getHibernateTemplate().find("from PipelineRequestDetailsTO where requestId =? and phaseExecutionOrder=?", serviceRequestId, 0L);
			for (PipelineRequestDetailsTO pipeline : pipelineRequests) {
				pipeline.setStatusId(CMMConstants.Framework.Entity.SERVICE_REQUEST_UNDER_IMPLEMENTATION);
				getHibernateTemplate().update(pipeline);
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : getStatusList", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : getStatusList", he);
		}
	}
	
	@Override
	public WorkflowCurrentTO returnWorkFlowServiceId(Long userId) throws CMMException {
	
		try {
			Long userId1 = null;
			List<Long> userIds = new ArrayList<Long>();
			List<Long> userIdList = (List<Long>) getHibernateTemplate().find("select userId from DelegatedUserTO where delegatedUserId=? ", userId);
			if (!userIdList.isEmpty()) {
				userId1 = userIdList.get(0);
				userIds.add(userId1);
			}
			userIds.add(userId);
			WorkflowCurrentTO workflow_Current = new WorkflowCurrentTO();
			String query = String.format("from WorkflowCurrentTO wcto where wcto.wfStatusTO.id = 2L and (wcto.currentOwner = %d OR  wcto.userTO.id = %d  OR wcto.currentOwner = %d) order by wcto.serviceRequestId desc limit 1", userId, userId, userId1);
			List<WorkflowCurrentTO> wcto = (List<WorkflowCurrentTO>) getHibernateTemplate().find(query);
			if (!wcto.isEmpty()) {
				workflow_Current = wcto.get(0);
			}
			return workflow_Current;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : returnWorkFlowServiceId", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : returnWorkFlowServiceId", he);
		}
	}
	
	@Override
	public List<WorkflowCurrentTO> onLoadWorkListForAgentDeployment(Long userId) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			List<WorkflowCurrentTO> dbWorklists = new ArrayList<WorkflowCurrentTO>(0);
			String query = " select wcto ,buto.name, appto.appName,pto.name from WorkflowCurrentTO wcto,BusinessUnitTO buto, ApplicationTO appto ,ProjectsTO pto  where wcto.clientId =buto.clientId and wcto.applicationId =appto.id and wcto.projectId =pto.id  and ( wcto.currentOwner =" + userId + " OR  wcto.userTO.id = " + userId + ")  and wcto.wfStatusTO.id = 2L and wcto.workFlowTO.id=13L";
			Query query1 = session.createQuery(query);
			List<Object[]> temp = query1.list();
			for (Object[] obj : temp) {
				BusinessUnitTO buto = new BusinessUnitTO();
				ProjectsTO pto = new ProjectsTO();
				ApplicationTO ato = new ApplicationTO();
				WorkflowCurrentTO workflowCurrentTOnew = (WorkflowCurrentTO) obj[0];
				Long currOwnerId = workflowCurrentTOnew.getCurrentOwner();
				StringBuilder userQuery = new StringBuilder("select u.name from UserTO u where u.id=?");
				String userName = (String) getHibernateTemplate().find(userQuery.toString(), currOwnerId).get(0);// to
				workflowCurrentTOnew.setCurrentOwnerName(userName);
				buto.setName(obj[1].toString());
				workflowCurrentTOnew.setBusinessUnitTO(buto);
				ato.setAppName(obj[2].toString());
				workflowCurrentTOnew.setAppTO(ato);
				pto.setName(obj[3].toString());
				workflowCurrentTOnew.setProjectsTO(pto);
				workflowCurrentTOnew.setDeploymentPipelineFlag("No");
				if (workflowCurrentTOnew.getServiceRequestId() != null) {
					List<ServiceRequestTO> serviceRequestToList = (List<ServiceRequestTO>) getHibernateTemplate().find("from ServiceRequestTO where id =?", workflowCurrentTOnew.getServiceRequestId());
					if (serviceRequestToList.size() > 0L) {
						ServiceRequestTO serviceRequestTO = new ServiceRequestTO();
						serviceRequestTO = serviceRequestToList.get(0);
						if ((serviceRequestTO.getPipelineRequest() != null) && "Y".equalsIgnoreCase(serviceRequestTO.getPipelineRequest())) {
							workflowCurrentTOnew.setDeploymentPipelineFlag("Yes");
						}
					}
				}
				dbWorklists.add(workflowCurrentTOnew);
			}
			return dbWorklists;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : onLoadWorkListForAgentDeployment", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : onLoadWorkListForAgentDeployment", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<WorkflowCurrentTO> searchWorkListForAgentDeployment(WorkflowCurrentTO workflowCurrentTO) throws CMMException {
	
		DateFormat localFormatter = new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy");
		String dateFromStr = null;
		String dateToStr = null;
		Date dateFrom = null;
		Date dateTo = null;
		Calendar cal = Calendar.getInstance();
		String formatedFromDate = null;
		String formatedToDate = null;
		DateFormat formatter1 = new SimpleDateFormat("yyyy-MM-dd");
		if (workflowCurrentTO.getFromDate() != null) {
			dateFromStr = workflowCurrentTO.getFromDate();
			try {
				dateFrom = localFormatter.parse(dateFromStr);
				cal.setTime(dateFrom);
				formatedFromDate = cal.get(Calendar.YEAR) + "-" + (cal.get(Calendar.MONTH) + 1) + "-" + cal.get(Calendar.DATE);
				dateFrom = formatter1.parse(formatedFromDate);
			} catch (ParseException e) {
				throw new CMMException("Error parsing date ", e);
			}
		}
		if (workflowCurrentTO.getToDate() != null) {
			dateToStr = workflowCurrentTO.getToDate();
			try {
				dateTo = localFormatter.parse(dateToStr);
				cal.setTime(dateTo);
				formatedToDate = cal.get(Calendar.YEAR) + "-" + (cal.get(Calendar.MONTH) + 1) + "-" + cal.get(Calendar.DATE);
				dateTo = formatter1.parse(formatedToDate);
			} catch (ParseException e) {
				throw new CMMException("Error parsing date ", e);
			}
		}
		Session session = null;
		try {
			session = getSession();
			List<WorkflowCurrentTO> dbWorklists = new ArrayList<WorkflowCurrentTO>(0);
			String query = " select distinct wcto ,buto.name, appto.appName, pto.name from WorkflowCurrentTO wcto,BusinessUnitTO buto, ApplicationTO appto ,ProjectsTO pto ,WorkflowHistoryTO whto where wcto.clientId =buto.clientId and wcto.applicationId =appto.id and wcto.projectId =pto.id and whto.wf_current_id =wcto.reqId and wcto.workFlowTO.id=13L and ( wcto.currentOwner =" + workflowCurrentTO.getLoggedInUser() + " OR  wcto.userTO.id = " + workflowCurrentTO.getLoggedInUser() + ")";
			if ((workflowCurrentTO.getRequestId() != null) && (workflowCurrentTO.getRequestId() > 0)) {
				query = query + " and wcto.reqId = " + workflowCurrentTO.getRequestId();
			}
			if ((workflowCurrentTO.getServiceRequestId() != null) && (workflowCurrentTO.getServiceRequestId() > 0)) {
				query = query + " and wcto.serviceRequestId = " + workflowCurrentTO.getServiceRequestId();
			}
			if ((workflowCurrentTO.getEntity_id() != null) && (workflowCurrentTO.getEntity_id() > 0)) {
				query = query + " and wcto.entity_id = " + workflowCurrentTO.getEntity_id();
			}
			if (workflowCurrentTO.getSelectedApp() != -1) {
				query = query + " and appto.id = " + workflowCurrentTO.getSelectedApp();
			}
			if (workflowCurrentTO.getSelectedWorkFlowAction() != -1) {
				query = query + " and wcto.workFlowTO.id = " + workflowCurrentTO.getSelectedWorkFlowAction();
			}
			if ((workflowCurrentTO.getSelectedStatus() != 4) && (workflowCurrentTO.getSelectedStatus() > 0L)) {
				query = query + " and wcto.wfStatusTO.id = " + workflowCurrentTO.getSelectedStatus();
			}
			if (workflowCurrentTO.getSelectedStatus() == 4) {
				query = query + " and wcto.wfStatusTO.id = " + workflowCurrentTO.getSelectedStatus();
			}
			if ((workflowCurrentTO.getFromDate() != null) && (workflowCurrentTO.getToDate() == null)) {
				query = query + " and wcto.requestDate >=:datefrom";
			}
			if ((workflowCurrentTO.getToDate() != null) && (workflowCurrentTO.getFromDate() == null)) {
				query = query + " and wcto.requestDate <=:dateto ";
			}
			if ((workflowCurrentTO.getToDate() != null) && (workflowCurrentTO.getFromDate() != null)) {
				query = query + " and wcto.requestDate >=:datefrom  and wcto.requestDate <=:dateto ";
			}
			Query query1 = session.createQuery(query);
			if ((workflowCurrentTO.getFromDate() != null) && (workflowCurrentTO.getToDate() == null)) {
				query1.setDate("datefrom", dateFrom);
			}
			if ((workflowCurrentTO.getToDate() != null) && (workflowCurrentTO.getFromDate() == null)) {
				query1.setDate("dateto", dateTo);
			}
			if ((workflowCurrentTO.getToDate() != null) && (workflowCurrentTO.getFromDate() != null)) {
				query1.setDate("datefrom", dateFrom);
				query1.setDate("dateto", dateTo);
			}
			List<Object[]> temp = query1.list();
			for (Object[] obj : temp) {
				BusinessUnitTO buto = new BusinessUnitTO();
				ProjectsTO pto = new ProjectsTO();
				ApplicationTO ato = new ApplicationTO();
				WorkflowCurrentTO workflowCurrentTOnew = (WorkflowCurrentTO) obj[0];
				Long currOwnerId = workflowCurrentTOnew.getCurrentOwner();
				StringBuilder userQuery = new StringBuilder("select u.name from UserTO u where u.id=?");
				String userName = (String) getHibernateTemplate().find(userQuery.toString(), currOwnerId).get(0);// to
				buto.setName(obj[1].toString());
				workflowCurrentTOnew.setBusinessUnitTO(buto);
				ato.setAppName(obj[2].toString());
				workflowCurrentTOnew.setAppTO(ato);
				pto.setName(obj[3].toString());
				workflowCurrentTOnew.setProjectsTO(pto);
				workflowCurrentTOnew.setCurrentOwnerName(userName);
				dbWorklists.add(workflowCurrentTOnew);
			}
			return dbWorklists;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : searchWorkListForAgentDeployment", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : searchWorkListForAgentDeployment", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public WorkFlowRequestTO viewEnvReqWorkflowForAgentDeployment(Long reqId) throws CMMException {
	
		WorkFlowRequestTO worklist = new WorkFlowRequestTO();// this TO contains
		String query = " select wcto ,buto.name, appto.appName,pto.name from WorkflowCurrentTO wcto,BusinessUnitTO buto, ApplicationTO appto ,ProjectsTO pto  where wcto.clientId =buto.clientId and wcto.applicationId =appto.id and wcto.projectId =pto.id";
		DetachedCriteria criteria2 = DetachedCriteria.forClass(WorkflowHistoryTO.class);
		Session session = null;
		try {
			if (reqId != null) {
				query = query + "  and wcto.reqId =" + reqId;
			}
			session = getSession();
			Query query3 = session.createQuery(query);// session closed in
			Object[] temps = (Object[]) query3.list().get(0);
			BusinessUnitTO buto = new BusinessUnitTO();
			ProjectsTO pto = new ProjectsTO();
			ApplicationTO ato = new ApplicationTO();
			WorkflowCurrentTO dbCurrentWorklist = (WorkflowCurrentTO) temps[0];
			buto.setName(temps[1].toString());
			dbCurrentWorklist.setBusinessUnitTO(buto);
			ato.setAppName(temps[2].toString());
			dbCurrentWorklist.setAppTO(ato);
			pto.setName(temps[3].toString());
			dbCurrentWorklist.setProjectsTO(pto);
			if (reqId != null) {
				criteria2.add(Restrictions.like("wf_current_id", reqId));
				criteria2.addOrder(Order.asc("levelOrder"));
			}
			List<WorkflowHistoryTO> dbHistoryWorklist = new LinkedList<WorkflowHistoryTO>();
			dbHistoryWorklist = (List<WorkflowHistoryTO>) getHibernateTemplate().findByCriteria(criteria2);
			StringBuilder query2 = new StringBuilder("select r.name from RoleTO r where r.id=?");
			for (WorkflowHistoryTO obj : dbHistoryWorklist) {
				String roleName = (String) getHibernateTemplate().find(query2.toString(), obj.getStatusChangedByRole()).get(0);
				obj.setStatusChangedByRoleName(roleName);
			}
			worklist.setWorkflowHistoryTO(dbHistoryWorklist);
			worklist.setWorkflowCurrentTO(dbCurrentWorklist);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : viewEnvReqWorkflow", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : viewEnvReqWorkflow", he);
		} catch (Exception e) {
			logger.error(e);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : viewEnvReqWorkflow", e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return worklist;
	}
	
	@Override
	public List<WorkflowCurrentTO> onLoadWorkListForAgentDeployment(Long userId, List<Long> clientIdlist) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			List<WorkflowCurrentTO> dbWorklists = new ArrayList<WorkflowCurrentTO>(0);
			String query = " select wcto ,buto.name, appto.appName,pto.name from WorkflowCurrentTO wcto,BusinessUnitTO buto, ApplicationTO appto ,ProjectsTO pto  where wcto.clientId =buto.clientId and wcto.applicationId =appto.id and wcto.projectId =pto.id  and ( wcto.currentOwner =" + userId + " OR  wcto.userTO.id = " + userId + ")  and wcto.wfStatusTO.id = 2L and wcto.workFlowTO.id=13L and wcto.clientId in (:clientIdlist)";
			Query query1 = session.createQuery(query);
			query1.setParameterList("clientIdlist", clientIdlist);
			List<Object[]> temp = query1.list();
			for (Object[] obj : temp) {
				BusinessUnitTO buto = new BusinessUnitTO();
				ProjectsTO pto = new ProjectsTO();
				ApplicationTO ato = new ApplicationTO();
				WorkflowCurrentTO workflowCurrentTOnew = (WorkflowCurrentTO) obj[0];
				Long currOwnerId = workflowCurrentTOnew.getCurrentOwner();
				StringBuilder userQuery = new StringBuilder("select u.name from UserTO u where u.id=?");
				String userName = (String) getHibernateTemplate().find(userQuery.toString(), currOwnerId).get(0);
				workflowCurrentTOnew.setCurrentOwnerName(userName);
				buto.setName(obj[1].toString());
				workflowCurrentTOnew.setBusinessUnitTO(buto);
				ato.setAppName(obj[2].toString());
				workflowCurrentTOnew.setAppTO(ato);
				pto.setName(obj[3].toString());
				workflowCurrentTOnew.setProjectsTO(pto);
				workflowCurrentTOnew.setDeploymentPipelineFlag("No");
				if (workflowCurrentTOnew.getServiceRequestId() != null) {
					List<ServiceRequestTO> serviceRequestToList = (List<ServiceRequestTO>) getHibernateTemplate().find("from ServiceRequestTO where id =?", workflowCurrentTOnew.getServiceRequestId());
					if (serviceRequestToList.size() > 0L) {
						ServiceRequestTO serviceRequestTO = new ServiceRequestTO();
						serviceRequestTO = serviceRequestToList.get(0);
						if ((serviceRequestTO.getPipelineRequest() != null) && "Y".equalsIgnoreCase(serviceRequestTO.getPipelineRequest())) {
							workflowCurrentTOnew.setDeploymentPipelineFlag("Yes");
						}
					}
				}
				dbWorklists.add(workflowCurrentTOnew);
			}
			return dbWorklists;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : onLoadWorkListForAgentDeployment", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : onLoadWorkListForAgentDeployment", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<ReservationTO> fetchChildReservations(Long entity_id) throws CMMException {
	
		try {
			List<ReservationTO> childReservation = (List<ReservationTO>) getHibernateTemplate().find("from ReservationTO where parentId =?", entity_id);
			for (int j = 0; j < childReservation.size(); j++) {
				String name = (String) getHibernateTemplate().find("select name from UserTO where id=?", childReservation.get(j).getUserId()).get(0);
				childReservation.get(j).setUserName(name);
			}
			return childReservation;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : getStatusList", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : getStatusList", he);
		}
	}
	
	@Override
	public Long getIsRepetitiveReservation(Long entity_id) throws CMMException {
	
		Long isRept = 0L;
		try {
			String hql = String.format("from ReservationTO where id=%d", entity_id);
			List<ReservationTO> childReservation = (List<ReservationTO>) getHibernateTemplate().find(hql);
			for (ReservationTO reservationTO : childReservation) {
				isRept = reservationTO.getIsRepetetive();
			}
			return isRept;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : getStatusList", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : getStatusList", he);
		}
	}
	
	@Override
	public List<ReservationTO> fetchConflictForChild(List<ReservationTO> childReservations) throws CMMException {
	
		try {
			List<ReservationTO> tempReservation = new ArrayList<ReservationTO>();
			for (ReservationTO dbReservationDtls : childReservations) {
				if (dbReservationDtls.getIsconflicting() == 1) {
					String query1 = "select r.id,r.startTime,r.endTime,r.userId,am.name , s.statusDesc,r.testingType from ReservationTO r,StatusTO s,AllocationMasterTO am  where s.id = r.status.id and r.environments.id=? and ((r.startTime >= ? and r.endTime <= ?) or (r.startTime <= ? and r.endTime >= ?) or (r.startTime <= ? and r.endTime > ?) or (r.startTime < ? and  r.endTime >= ?)) and r.disruptive =am.id and r.status.id=? and r.id !=? and r.isconflicting=1L and r.disruptive=am.id ";
					List<Object[]> conflictidList = (List<Object[]>) getHibernateTemplate().find(query1, dbReservationDtls.getEnvironments().getId(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getEndTime(), CMMConstants.Framework.Entity.RESERVATION_STATUS_APPROVED, dbReservationDtls.getId());
					if (!conflictidList.isEmpty()) {
						for (Object[] temp : conflictidList) {
							ReservationTO reservations = new ReservationTO();
							reservations.setId(Long.parseLong(temp[0].toString()));
							reservations.setStartTime((Date) temp[1]);
							reservations.setEndTime((Date) temp[2]);
							reservations.setUserId(Long.parseLong(temp[3].toString()));
							reservations.setDisruptive(temp[4].toString());
							reservations.setStatusDesc(temp[5].toString());
							reservations.setTestingType(Long.parseLong(temp[6].toString()));
							int testingtype = Integer.parseInt(temp[6].toString());
							switch (testingtype) {
								case 1:
									reservations.setTestingType1("Regression");
									break;
								case 2:
									reservations.setTestingType1("Functional");
									break;
								case 3:
									reservations.setTestingType1("UAT");
									break;
								case 4:
									reservations.setTestingType1("Performance Testing");
									break;
								case 5:
									reservations.setTestingType1("Compatibility Testing");
									break;
								case 6:
									reservations.setTestingType1("Integration Testing");
									break;
								case 7:
									reservations.setTestingType1("End-To-End Testing");
									break;
								default:
									reservations.setTestingType1("Not defined");
									break;
							}
							tempReservation.add(reservations);
						}
					}
				}
			}
			return tempReservation;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : getStatusList", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : getStatusList", he);
		}
	}
	
	@Override
	public List<ReservationTO> viewChildConfict(Long parentReservationId) throws CMMException {
	
		List<ReservationTO> tempReservation = new ArrayList<ReservationTO>();
		try {
			ReservationTO dbReservationDtls = (ReservationTO) getHibernateTemplate().find("from ReservationTO where id=?", parentReservationId).get(0);
			String query1 = "select r.id,r.startTime,r.endTime,r.userId,am.name , s.statusDesc,r.testingType from ReservationTO r,StatusTO s,AllocationMasterTO am  where s.id = r.status.id and r.environments.id=? and ((r.startTime >= ? and r.endTime <= ?) or (r.startTime <= ? and r.endTime >= ?) or (r.startTime <= ? and r.endTime > ?) or (r.startTime < ? and  r.endTime >= ?)) and r.disruptive =am.id and r.status.id=? and r.id !=? and r.isconflicting=1L and r.disruptive=am.id ";
			List<Object[]> conflictidList = (List<Object[]>) getHibernateTemplate().find(query1, dbReservationDtls.getEnvironments().getId(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getEndTime(), CMMConstants.Framework.Entity.RESERVATION_STATUS_APPROVED, dbReservationDtls.getId());
			if (!conflictidList.isEmpty()) {
				for (Object[] temp : conflictidList) {
					ReservationTO reservations = new ReservationTO();
					reservations.setId(Long.parseLong(temp[0].toString()));
					reservations.setStartTime((Date) temp[1]);
					reservations.setEndTime((Date) temp[2]);
					reservations.setUserId(Long.parseLong(temp[3].toString()));
					reservations.setDisruptive(temp[4].toString());
					reservations.setStatusDesc(temp[5].toString());
					reservations.setTestingType(Long.parseLong(temp[6].toString()));
					int testingtype = Integer.parseInt(temp[6].toString());
					switch (testingtype) {
						case 1:
							reservations.setTestingType1("Regression");
							break;
						case 2:
							reservations.setTestingType1("Functional");
							break;
						case 3:
							reservations.setTestingType1("UAT");
							break;
						case 4:
							reservations.setTestingType1("Performance Testing");
							break;
						case 5:
							reservations.setTestingType1("Compatibility Testing");
							break;
						case 6:
							reservations.setTestingType1("Integration Testing");
							break;
						case 7:
							reservations.setTestingType1("End-To-End Testing");
							break;
						default:
							reservations.setTestingType1("Not defined");
							break;
					}
					tempReservation.add(reservations);
				}
			}
			return tempReservation;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : getStatusList", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : getStatusList", he);
		}
	}
	
	public void checkChild(ReservationTO dbReservationDtls) throws CMMException {
	
		try {
			Long statusValue = 85L;
			dbReservationDtls.getStartTime();
			dbReservationDtls.getEndTime();
			Long Parentid = dbReservationDtls.getId();
			String allocationMode = dbReservationDtls.getDisruptive();
			List<ReservationTO> work_id = (List<ReservationTO>) getHibernateTemplate().find("from ReservationTO where ParentId=? ", Parentid);
			if (allocationMode.equals(CMMConstants.Framework.ReservationStatus.RESERVATION_SHARED)) {
				List<ReservationTO> reservationList1 = new ArrayList<ReservationTO>(0);
				String query2 = "select r from ReservationTO as r where r.environments.id =?  and ((r.startTime <= ? and r.endTime >= ? and r.endTime <= ?) or (r.endTime >= ? and r.startTime >= ? and r.startTime <= ?) or (r.startTime <= ? and r.endTime >= ?) or (r.startTime >= ? and r.startTime <= ? and r.endTime >= ? and r.endTime <= ?)) and (r.startTime != ? and r.endTime != ?) and r.status.id IN (81, 84) and r.id !=?";
				reservationList1 = (List<ReservationTO>) getHibernateTemplate().find(query2, dbReservationDtls.getEnvironments().getId(), dbReservationDtls.getStartTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getId());
				Long countSharedApproved = 0L;
				Long countDisruptiveApproved = 0L;
				Long countDisruptivePending = 0L;
				List<ReservationTO> sharedApprovedList = new ArrayList<ReservationTO>(0);
				List<ReservationTO> disruptiveApprovedList = new ArrayList<ReservationTO>(0);
				List<ReservationTO> sharedPendingList = new ArrayList<ReservationTO>(0);
				List<ReservationTO> disruptivePendingList = new ArrayList<ReservationTO>(0);
				for (ReservationTO reservationToObj : reservationList1) {
					if ("S".equalsIgnoreCase(reservationToObj.getDisruptive()) && (reservationToObj.getStatus().getId() == 81L)) {
						sharedApprovedList.add(reservationToObj);
						countSharedApproved++;
					}
					if ("S".equalsIgnoreCase(reservationToObj.getDisruptive()) && (reservationToObj.getStatus().getId() == 84L)) {
						sharedPendingList.add(reservationToObj);
					}
					if (!"S".equalsIgnoreCase(reservationToObj.getDisruptive()) && (reservationToObj.getStatus().getId() == 81L)) {
						disruptiveApprovedList.add(reservationToObj);
						countDisruptiveApproved++;
					}
					if (!"S".equalsIgnoreCase(reservationToObj.getDisruptive()) && (reservationToObj.getStatus().getId() == 84L)) {
						countDisruptivePending++;
						disruptivePendingList.add(reservationToObj);
					}
				}
				if ((countSharedApproved < 2L) && (countDisruptiveApproved == 0L)) {
					Long conflictingStatus = 0L;
					if (countDisruptivePending == 0L) {
						StatusTO status = new StatusTO();
						status.setId(CMMConstants.Framework.Entity.RESERVATION_STATUS_APPROVED);
						dbReservationDtls.setStatus(status);
						dbReservationDtls.setIsconflicting(conflictingStatus);
						getHibernateTemplate().update(dbReservationDtls);
					} else if (countDisruptivePending > 0) {
						for (ReservationTO resTo : disruptivePendingList) {
							conflictingStatus = 1L;
							resTo.setIsconflicting(conflictingStatus);
							getHibernateTemplate().update(resTo);
						}
						StatusTO status = new StatusTO();
						status.setId(CMMConstants.Framework.Entity.RESERVATION_STATUS_APPROVED);
						dbReservationDtls.setStatus(status);
						conflictingStatus = 1L;
						dbReservationDtls.setIsconflicting(conflictingStatus);
						getHibernateTemplate().update(dbReservationDtls);
					}
				}
				if (countDisruptiveApproved == 1L) {
					Long conflictingStatus = 0L;
					if (countDisruptivePending == 0L) {
						List<Long> selectedReservations = new ArrayList<Long>(0);
						Long reservationId = disruptiveApprovedList.get(0).getId();
						selectedReservations.add(reservationId);
						disruptiveApprovedList.get(0).setSelectedReservations(selectedReservations);
						reservationDAO.deleteReservations(disruptiveApprovedList.get(0), statusValue);
						StatusTO status1 = new StatusTO();
						status1.setId(CMMConstants.Framework.Entity.RESERVATION_STATUS_APPROVED);
						dbReservationDtls.setStatus(status1);
						getHibernateTemplate().update(dbReservationDtls);
					}
					if (countDisruptivePending > 0L) {
						for (ReservationTO resTo : sharedPendingList) {
							conflictingStatus = 1L;
							resTo.setIsconflicting(conflictingStatus);
							getHibernateTemplate().update(resTo);
						}
						for (ReservationTO resTo : disruptivePendingList) {
							conflictingStatus = 1L;
							resTo.setIsconflicting(conflictingStatus);
							getHibernateTemplate().update(resTo);
						}
						StatusTO status = new StatusTO();
						status.setId(CMMConstants.Framework.Entity.RESERVATION_STATUS_APPROVED);
						dbReservationDtls.setStatus(status);
						conflictingStatus = 1L;
						dbReservationDtls.setIsconflicting(conflictingStatus);
						getHibernateTemplate().update(dbReservationDtls);
						List<Long> selectedReservations = new ArrayList<Long>(0);
						Long reservationId = disruptiveApprovedList.get(0).getId();
						selectedReservations.add(reservationId);
						disruptiveApprovedList.get(0).setSelectedReservations(selectedReservations);
						reservationDAO.deleteReservations(disruptiveApprovedList.get(0), statusValue);
					}
				}
			}
			if (allocationMode.equals(CMMConstants.Framework.ReservationStatus.RESERVATION_DISRUPTIVE) || allocationMode.equals(CMMConstants.Framework.ReservationStatus.RESERVATION_LOCKED)) {
				if (dbReservationDtls.getIsconflicting() == 1L) {
					String query3 = "select r from ReservationTO as r where r.environments.id =?  and ((r.startTime <= ? and r.endTime >= ? and r.endTime <= ?) or (r.endTime >= ? and r.startTime >= ? and r.startTime <= ?) or (r.startTime <= ? and r.endTime >= ?) or (r.startTime >= ? and r.startTime <= ? and r.endTime >= ? and r.endTime <= ?)) and (r.startTime != ? and r.endTime != ?) and r.status.id =? and r.id !=?";
					List<ReservationTO> reservation3 = (List<ReservationTO>) getHibernateTemplate().find(query3, dbReservationDtls.getEnvironments().getId(), dbReservationDtls.getStartTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getStartTime(), CMMConstants.Framework.Entity.RESERVATION_STATUS_APPROVED, dbReservationDtls.getId());
					for (ReservationTO res : reservation3) {
						List<Long> selectedReservations = new ArrayList<Long>(0);
						Long reservationId = res.getId();
						selectedReservations.add(reservationId);
						res.setSelectedReservations(selectedReservations);
						reservationDAO.deleteReservations(res, statusValue);
					}
				}
				StatusTO statusTo = new StatusTO();
				statusTo.setId(CMMConstants.Framework.Entity.RESERVATION_STATUS_APPROVED);
				dbReservationDtls.setStatus(statusTo);
				getHibernateTemplate().update(dbReservationDtls);
				/*
				 * Changes by Saumya for pending conflict request with isConflicting flag as 1, start
				 */
				String query4 = "select r from ReservationTO as r where r.environments.id=? and ((r.startTime >= ? and r.endTime <= ?) or (r.startTime <= ? and r.endTime >= ?) or (r.startTime <= ? and r.endTime > ?) or (r.startTime < ? and  r.endTime >= ?)) and r.status.id=? and r.id !=? ";
				List<ReservationTO> reservation4 = (List<ReservationTO>) getHibernateTemplate().find(query4, dbReservationDtls.getEnvironments().getId(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getEndTime(), CMMConstants.Framework.Entity.RESERVATION_STATUS_PENDING, dbReservationDtls.getId());
				Long countSharedPending1 = 0L;
				Long countDisruptivePending1 = 0L;
				Long countLockedPending1 = 0L;
				List<ReservationTO> sharedPendingList1 = new ArrayList<ReservationTO>(0);
				List<ReservationTO> disruptivePendingList1 = new ArrayList<ReservationTO>(0);
				List<ReservationTO> lockedPendingList1 = new ArrayList<ReservationTO>(0);
				for (ReservationTO reservationToObj : reservation4) {
					if ("S".equalsIgnoreCase(reservationToObj.getDisruptive()) && (reservationToObj.getStatus().getId() == 84L)) {
						countSharedPending1++;
						sharedPendingList1.add(reservationToObj);
					}
					if (!"D".equalsIgnoreCase(reservationToObj.getDisruptive()) && (reservationToObj.getStatus().getId() == 84L)) {
						countDisruptivePending1++;
						disruptivePendingList1.add(reservationToObj);
					}
					if (!"L".equalsIgnoreCase(reservationToObj.getDisruptive()) && (reservationToObj.getStatus().getId() == 84L)) {
						countLockedPending1++;
						lockedPendingList1.add(reservationToObj);
					}
				}
				if ((countSharedPending1 > 0) || (countDisruptivePending1 > 0) || (countLockedPending1 > 0)) {
					dbReservationDtls.setIsconflicting(1L);
					getHibernateTemplate().update(dbReservationDtls);
					for (ReservationTO res : sharedPendingList1) {
						res.setIsconflicting(1L);
						getHibernateTemplate().update(res);
					}
					for (ReservationTO res : disruptivePendingList1) {
						res.setIsconflicting(1L);
						getHibernateTemplate().update(res);
					}
					for (ReservationTO res : lockedPendingList1) {
						res.setIsconflicting(1L);
						getHibernateTemplate().update(res);// Saumya
					}
				}
				/*
				 * Changes by Saumya for pending conflict request with isConflicting flag as 1,end
				 */
				else {
					dbReservationDtls.setIsconflicting(0L);
					getHibernateTemplate().update(dbReservationDtls);
				}
			}// disruptive
			for (ReservationTO work : work_id) {
				if (allocationMode.equals(CMMConstants.Framework.ReservationStatus.RESERVATION_SHARED)) {
					List<ReservationTO> reservationList1 = new ArrayList<ReservationTO>(0);
					String query2 = "select r from ReservationTO as r where r.environments.id =?  and ((r.startTime <= ? and r.endTime >= ? and r.endTime <= ?) or (r.endTime >= ? and r.startTime >= ? and r.startTime <= ?) or (r.startTime <= ? and r.endTime >= ?) or (r.startTime >= ? and r.startTime <= ? and r.endTime >= ? and r.endTime <= ?)) and (r.startTime != ? and r.endTime != ?) and r.status.id IN (81, 84) and r.id !=?";
					reservationList1 = (List<ReservationTO>) getHibernateTemplate().find(query2, work.getEnvironments().getId(), work.getStartTime(), work.getStartTime(), work.getEndTime(), work.getEndTime(), work.getStartTime(), work.getEndTime(), work.getStartTime(), work.getEndTime(), work.getStartTime(), work.getEndTime(), work.getStartTime(), work.getEndTime(), work.getEndTime(), work.getStartTime(), work.getId());
					Long countSharedApproved = 0L;
					Long countDisruptiveApproved = 0L;
					Long countDisruptivePending = 0L;
					List<ReservationTO> sharedApprovedList = new ArrayList<ReservationTO>(0);
					List<ReservationTO> disruptiveApprovedList = new ArrayList<ReservationTO>(0);
					List<ReservationTO> sharedPendingList = new ArrayList<ReservationTO>(0);
					List<ReservationTO> disruptivePendingList = new ArrayList<ReservationTO>(0);
					for (ReservationTO reservationToObj : reservationList1) {
						if ("S".equalsIgnoreCase(reservationToObj.getDisruptive()) && (reservationToObj.getStatus().getId() == 81L)) {
							sharedApprovedList.add(reservationToObj);
							countSharedApproved++;
						}
						if ("S".equalsIgnoreCase(reservationToObj.getDisruptive()) && (reservationToObj.getStatus().getId() == 84L)) {
							sharedPendingList.add(reservationToObj);
						}
						if (!"S".equalsIgnoreCase(reservationToObj.getDisruptive()) && (reservationToObj.getStatus().getId() == 81L)) {
							disruptiveApprovedList.add(reservationToObj);
							countDisruptiveApproved++;
						}
						if (!"S".equalsIgnoreCase(reservationToObj.getDisruptive()) && (reservationToObj.getStatus().getId() == 84L)) {
							countDisruptivePending++;
							disruptivePendingList.add(reservationToObj);
						}
					}
					if ((countSharedApproved < 2L) && (countDisruptiveApproved == 0L)) {
						Long conflictingStatus = 0L;
						if (countDisruptivePending == 0L) {
							StatusTO status = new StatusTO();
							status.setId(CMMConstants.Framework.Entity.RESERVATION_STATUS_APPROVED);
							work.setStatus(status);
							work.setIsconflicting(conflictingStatus);
							getHibernateTemplate().update(work);
						} else if (countDisruptivePending > 0) {
							for (ReservationTO resTo : disruptivePendingList) {
								conflictingStatus = 1L;
								resTo.setIsconflicting(conflictingStatus);
								getHibernateTemplate().update(resTo);
							}
							StatusTO status = new StatusTO();
							status.setId(CMMConstants.Framework.Entity.RESERVATION_STATUS_APPROVED);
							work.setStatus(status);
							conflictingStatus = 1L;
							work.setIsconflicting(conflictingStatus);
							getHibernateTemplate().update(work);
						}
					}
					if (countDisruptiveApproved == 1L) {
						Long conflictingStatus = 0L;
						if (countDisruptivePending == 0L) {
							List<Long> selectedReservations = new ArrayList<Long>(0);
							Long reservationId = disruptiveApprovedList.get(0).getId();
							selectedReservations.add(reservationId);
							disruptiveApprovedList.get(0).setSelectedReservations(selectedReservations);
							reservationDAO.deleteReservations(disruptiveApprovedList.get(0), statusValue);
							StatusTO status1 = new StatusTO();
							status1.setId(CMMConstants.Framework.Entity.RESERVATION_STATUS_APPROVED);
							work.setStatus(status1);
							getHibernateTemplate().update(work);
						}
						if (countDisruptivePending > 0L) {
							for (ReservationTO resTo : sharedPendingList) {
								conflictingStatus = 1L;
								resTo.setIsconflicting(conflictingStatus);
								getHibernateTemplate().update(resTo);
							}
							for (ReservationTO resTo : disruptivePendingList) {
								conflictingStatus = 1L;
								resTo.setIsconflicting(conflictingStatus);
								getHibernateTemplate().update(resTo);
							}
							StatusTO status = new StatusTO();
							status.setId(CMMConstants.Framework.Entity.RESERVATION_STATUS_APPROVED);
							work.setStatus(status);
							conflictingStatus = 1L;
							work.setIsconflicting(conflictingStatus);
							getHibernateTemplate().update(work);
							List<Long> selectedReservations = new ArrayList<Long>(0);
							Long reservationId = disruptiveApprovedList.get(0).getId();
							selectedReservations.add(reservationId);
							disruptiveApprovedList.get(0).setSelectedReservations(selectedReservations);
							reservationDAO.deleteReservations(disruptiveApprovedList.get(0), statusValue);
						}
					}
				}
				if (allocationMode.equals(CMMConstants.Framework.ReservationStatus.RESERVATION_DISRUPTIVE) || allocationMode.equals(CMMConstants.Framework.ReservationStatus.RESERVATION_LOCKED)) {
					if (work.getIsconflicting() == 1L) {
						String query3 = "select r from ReservationTO as r where r.environments.id =?  and ((r.startTime <= ? and r.endTime >= ? and r.endTime <= ?) or (r.endTime >= ? and r.startTime >= ? and r.startTime <= ?) or (r.startTime <= ? and r.endTime >= ?) or (r.startTime >= ? and r.startTime <= ? and r.endTime >= ? and r.endTime <= ?)) and (r.startTime != ? and r.endTime != ?) and r.status.id =? and r.id !=?";
						List<ReservationTO> reservation3 = (List<ReservationTO>) getHibernateTemplate().find(query3, work.getEnvironments().getId(), work.getStartTime(), work.getStartTime(), work.getEndTime(), work.getEndTime(), work.getStartTime(), work.getEndTime(), work.getStartTime(), work.getEndTime(), work.getStartTime(), work.getEndTime(), work.getStartTime(), work.getEndTime(), work.getEndTime(), work.getStartTime(), CMMConstants.Framework.Entity.RESERVATION_STATUS_APPROVED, work.getId());
						for (ReservationTO res : reservation3) {
							List<Long> selectedReservations = new ArrayList<Long>(0);
							Long reservationId = res.getId();
							selectedReservations.add(reservationId);
							res.setSelectedReservations(selectedReservations);
							reservationDAO.deleteReservations(res, statusValue);
						}
					}
					StatusTO statusTo = new StatusTO();
					statusTo.setId(CMMConstants.Framework.Entity.RESERVATION_STATUS_APPROVED);
					work.setStatus(statusTo);
					getHibernateTemplate().update(work);
					/*
					 * Changes by Saumya for pending conflict request with isConflicting flag as 1, start
					 */
					String query4 = "select r from ReservationTO as r where r.environments.id=? and ((r.startTime >= ? and r.endTime <= ?) or (r.startTime <= ? and r.endTime >= ?) or (r.startTime <= ? and r.endTime > ?) or (r.startTime < ? and  r.endTime >= ?)) and r.status.id=? and r.id !=? ";
					List<ReservationTO> reservation4 = (List<ReservationTO>) getHibernateTemplate().find(query4, work.getEnvironments().getId(), work.getStartTime(), work.getEndTime(), work.getStartTime(), work.getEndTime(), work.getStartTime(), work.getStartTime(), work.getEndTime(), work.getEndTime(), CMMConstants.Framework.Entity.RESERVATION_STATUS_PENDING, work.getId());
					Long countSharedPending1 = 0L;
					Long countDisruptivePending1 = 0L;
					Long countLockedPending1 = 0L;
					List<ReservationTO> sharedPendingList1 = new ArrayList<ReservationTO>(0);
					List<ReservationTO> disruptivePendingList1 = new ArrayList<ReservationTO>(0);
					List<ReservationTO> lockedPendingList1 = new ArrayList<ReservationTO>(0);
					for (ReservationTO reservationToObj : reservation4) {
						if ("S".equalsIgnoreCase(reservationToObj.getDisruptive()) && (reservationToObj.getStatus().getId() == 84L)) {
							countSharedPending1++;
							sharedPendingList1.add(reservationToObj);
						}
						if (!"D".equalsIgnoreCase(reservationToObj.getDisruptive()) && (reservationToObj.getStatus().getId() == 84L)) {
							countDisruptivePending1++;
							disruptivePendingList1.add(reservationToObj);
						}
						if (!"L".equalsIgnoreCase(reservationToObj.getDisruptive()) && (reservationToObj.getStatus().getId() == 84L)) {
							countLockedPending1++;
							lockedPendingList1.add(reservationToObj);
						}
					}
					if ((countSharedPending1 > 0) || (countDisruptivePending1 > 0) || (countLockedPending1 > 0)) {
						work.setIsconflicting(1L);
						getHibernateTemplate().update(work);
						for (ReservationTO res : sharedPendingList1) {
							res.setIsconflicting(1L);
							getHibernateTemplate().update(res);
						}
						for (ReservationTO res : disruptivePendingList1) {
							res.setIsconflicting(1L);
							getHibernateTemplate().update(res);
						}
						for (ReservationTO res : lockedPendingList1) {
							res.setIsconflicting(1L);
							getHibernateTemplate().update(res);// Saumya
						}
					}
					/*
					 * Changes by Saumya for pending conflict request with isConflicting flag as 1,end
					 */
					else {
						work.setIsconflicting(0L);
						getHibernateTemplate().update(work);
					}
				}// disruptive
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : getStatusList", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : getStatusList", he);
		}
	}
	
	@Override
	public String getReservationToDate(Long entityId) throws CMMException {
	
		try {
			Timestamp tp = (Timestamp) getHibernateTemplate().find("select endTime from ReservationTO where id=?", entityId).get(0);
			DateFormat localDf = new SimpleDateFormat("dd/MM/yyyy");
			return localDf.format(tp);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : onLoadWorkListForAgentDeployment", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : onLoadWorkListForAgentDeployment", he);
		}
	}
	
	@Override
	public Long getWorkflowHistoryId(Long workFlowCurrentId) throws CMMException {
	
		try {
			return (Long) getHibernateTemplate().find("select lastUpdateBy from WorkflowHistoryTO where lastUpdateBy is not null and wf_current_id =?", workFlowCurrentId).get(0);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : onLoadWorkListForAgentDeployment", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : onLoadWorkListForAgentDeployment", he);
		}
	}
	
	@Override
	public Long getUserIdFrmDelegationId(Long id) throws CMMException {
	
		Long userId = null;
		List<Long> userIdList = (List<Long>) getHibernateTemplate().find("select userId from DelegatedUserTO where delegatedUserId=? ", id);
		if (!userIdList.isEmpty()) {
			userId = userIdList.get(0);
		}
		return userId;
	}
}
