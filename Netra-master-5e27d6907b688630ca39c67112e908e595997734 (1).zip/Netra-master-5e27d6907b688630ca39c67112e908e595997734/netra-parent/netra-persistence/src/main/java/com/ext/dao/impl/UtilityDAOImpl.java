package com.ext.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.exception.ConstraintViolationException;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.UtilityDAO;
import com.framework.common.CMMConstants;
import com.framework.exception.CMMException;
import com.framework.to.ApplicationTO;
import com.framework.to.EnvironmentApplicationTO;
import com.framework.to.ProjectsTO;
import com.framework.to.ServiceRequestTO;
import com.framework.to.TestingToolTO;
import com.framework.to.TestingToolsTO;

public class UtilityDAOImpl extends HibernateDaoSupport implements UtilityDAO {
	
	private static final Logger LOG = Logger.getLogger(UtilityDAOImpl.class);
	
	@Override
	public TestingToolsTO getTestingToolsDetails(Long requestId, Long testToolId) throws CMMException {
	
		List<ServiceRequestTO> serviceRequestTO = (List<ServiceRequestTO>) getHibernateTemplate().find("from ServiceRequestTO where id =?", requestId);
		TestingToolsTO testingTools = new TestingToolsTO();
		Long applicationId = 0L;
		if (!serviceRequestTO.isEmpty()) {
			ServiceRequestTO serviceRequest = serviceRequestTO.get(0);
			for (EnvironmentApplicationTO temp : serviceRequest.getEnvironmentTO().getEnvironmentApplicationTO()) {
				for (EnvironmentApplicationTO envApp : temp.getEnvironmentTO().getEnvironmentApplicationTO()) {
					applicationId = envApp.getApplicationTO().getId();
				}
			}
			List<TestingToolsTO> testingToolsTO = (List<TestingToolsTO>) getHibernateTemplate().find("from TestingToolsTO where applicationId =? and testingToolId = ? ", applicationId, testToolId);
			if (!testingToolsTO.isEmpty()) {
				testingTools = testingToolsTO.get(0);
			} else {
				List<ApplicationTO> applicationList = (List<ApplicationTO>) getHibernateTemplate().find("from ApplicationTO where id =?", applicationId);
				if (!applicationList.isEmpty()) {
					ApplicationTO application = applicationList.get(0);
					Long projectId = application.getProjectTO().getId();
					testingToolsTO = (List<TestingToolsTO>) getHibernateTemplate().find("from TestingToolsTO where projectId=? and testingToolId = ?", projectId, testToolId);
					if (!testingToolsTO.isEmpty()) {
						testingTools = testingToolsTO.get(0);
					} else {
						List<ProjectsTO> projectList = (List<ProjectsTO>) getHibernateTemplate().find("from ProjectsTO where id =?", projectId);
						if (!projectList.isEmpty()) {
							ProjectsTO project = projectList.get(0);
							Long businessUnitId = project.getClientId();
							testingToolsTO = (List<TestingToolsTO>) getHibernateTemplate().find("from TestingToolsTO where businessUnitId=? and testingToolId = ?", businessUnitId, testToolId);
							if (!testingToolsTO.isEmpty()) {
								testingTools = testingToolsTO.get(0);
							}
						}
					}
				}
			}
		}
		return testingTools;
	}
	
	@Override
	public TestingToolsTO fetchTestingToolsDetails(Long applicationId, Long testToolId) throws CMMException {
	
		TestingToolsTO testingTools = new TestingToolsTO();
		List<TestingToolsTO> testingToolsTO = (List<TestingToolsTO>) getHibernateTemplate().find("from TestingToolsTO where applicationId =? and testingToolId = ? ", applicationId, testToolId);
		if (!testingToolsTO.isEmpty()) {
			testingTools = testingToolsTO.get(0);
		} else {
			List<ApplicationTO> applicationList = (List<ApplicationTO>) getHibernateTemplate().find("from ApplicationTO where id =?", applicationId);
			if (!applicationList.isEmpty()) {
				ApplicationTO application = applicationList.get(0);
				Long projectId = application.getProjectTO().getId();
				testingToolsTO = (List<TestingToolsTO>) getHibernateTemplate().find("from TestingToolsTO where projectId=? and testingToolId = ?", projectId, testToolId);
				if (!testingToolsTO.isEmpty()) {
					testingTools = testingToolsTO.get(0);
				} else {
					List<ProjectsTO> projectList = (List<ProjectsTO>) getHibernateTemplate().find("from ProjectsTO where id =?", projectId);
					if (!projectList.isEmpty()) {
						ProjectsTO project = projectList.get(0);
						Long businessUnitId = project.getClientId();
						testingToolsTO = (List<TestingToolsTO>) getHibernateTemplate().find("from TestingToolsTO where businessUnitId=? and testingToolId = ?", businessUnitId, testToolId);
						if (!testingToolsTO.isEmpty()) {
							testingTools = testingToolsTO.get(0);
						}
					}
				}
			}
		}
		return testingTools;
	}
	
	@Override
	public String getPortForSoftware(Long envDetailsId) throws CMMException {
	
		Map<String, String> paramtersMap = new HashMap<String, String>(0);
		Session session = null;
		List<Object[]> objList = null;
		try {
			session = getSession();
			String query = "select ed.propertyValue , n.parameterPathName from EnvSoftParamDetailsTO ed inner join ed.environmentSoftParamsTO e inner join ed.nolioProcessParametersTO n where e.environmentDetailsTO.id = :envDetailId";
			Query q = session.createQuery(query);
			q.setParameter("envDetailId", envDetailsId);
			objList = q.list();
			for (Object[] obj : objList) {
				paramtersMap.put((String) obj[0], (String) obj[1]);
			}
			for (Entry<String, String> temp : paramtersMap.entrySet()) {
				String pathname = temp.getValue();
				int index = pathname.lastIndexOf("/");
				String[] name = new String[] { pathname.substring(0, index), pathname.substring(index + 1) };
				if (name[1].equalsIgnoreCase(CMMConstants.External.Tools.TestingTools.PORT)) {
					return temp.getKey();
				}
			}
		} catch (DataIntegrityViolationException div) {
			LOG.error(div);
			throw new CMMException("Problem encountered. UtilityDAOImpl : getPortForSoftware", div);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. UtilityDAOImpl : getPortForSoftware", dae);
		} catch (ConstraintViolationException e) {
			LOG.error(e);
			throw new CMMException("User Name already exists. UtilityDAOImpl : getPortForSoftware", e);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. UtilityDAOImpl : getPortForSoftware", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return null;
	}
	
	@Override
	public List<TestingToolTO> getTestData() throws CMMException {
	
		return (List<TestingToolTO>) getHibernateTemplate().find("from TestingToolTO");
	}
}
