package com.ext.dao.impl;

import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.UserGroupDAO;
import com.framework.common.CMMConstants.Framework.Entity;
import com.framework.exception.CMMException;
import com.framework.to.ApplicationTO;
import com.framework.to.UserGroupDetailsTO;
import com.framework.to.UserGroupTO;
import com.framework.to.UserTO;

public class UserGroupDAOImpl extends HibernateDaoSupport implements UserGroupDAO {
	
	private static final Logger LOGGER = Logger.getLogger(UserGroupDAOImpl.class);
	
	@Override
	public List<UserTO> getUserNamesForApp(long appId) throws CMMException {
	
		StringBuilder query = new StringBuilder("select a.name ");
		query.append("from UserTO a inner join a.userGroupDetailses b ");
		query.append("where b.id=?");
		List<UserTO> dbUsers = new ArrayList<UserTO>();
		LOGGER.debug("QERY...." + query);
		try {
			dbUsers = (List<UserTO>) getHibernateTemplate().find(query.toString(), appId);
		} catch (DataAccessException dae) {
			LOGGER.error(dae);
			throw new CMMException("Problem encountered. UserGroupDAOImpl : getUserNamesForApp", dae);
		} catch (HibernateException he) {
			LOGGER.error(he);
			throw new CMMException("Problem encountered.  UserGroupDAOImpl : getUserNamesForApp", he);
		} catch (Exception e) {
			LOGGER.error(e);
			throw new CMMException("Problem encountered.  UserGroupDAOImpl : getUserNamesForApp", e);
		}
		return dbUsers;
	}
	
	@Override
	public List<Object> getapplicationNames() throws CMMException {
	
		StringBuilder query = new StringBuilder("select a.id,a.appName ");
		query.append("from ApplicationTO a inner join a.businessUnitTO b");
		List<Object> dbAppNames = new ArrayList<Object>();
		try {
			dbAppNames = (List<Object>) getHibernateTemplate().find(query.toString());
		} catch (DataAccessException dae) {
			LOGGER.error(dae);
			throw new CMMException("Problem encountered. UserGroupDAOImpl : getapplicationNames ", dae);
		} catch (HibernateException he) {
			LOGGER.error(he);
			throw new CMMException("Problem encountered. UserGroupDAOImpl : getapplicationNames", he);
		} catch (Exception e) {
			LOGGER.error(e);
			throw new CMMException("Problem encountered. UserGroupDAOImpl : getapplicationNames", e);
		}
		return dbAppNames;
	}
	
	@Override
	public List<UserTO> getAllUserNames(Long appid) throws CMMException {
	
		List<UserTO> dbUserNames = new ArrayList<UserTO>(0);
		try {
			StringBuilder query = new StringBuilder("select b.id,b.name from ApplicationTO a inner join a.businessUnitTO b where a.id=?");
			Object[] clientid = (Object[]) getHibernateTemplate().find(query.toString(), appid).get(0);
			dbUserNames = (List<UserTO>) getHibernateTemplate().find("select u from UserTO as u , UserBusinessUnitTO as ub where u.id=ub.user.id and ub.clientId =? and u.status=?", clientid[0], Entity.USER_STATUS_ACTIVE);
		} catch (DataAccessException dae) {
			LOGGER.error(dae);
			throw new CMMException("Problem encountered. UserGroupDAOImpl : getAllUserNames", dae);
		} catch (HibernateException he) {
			LOGGER.error(he);
			throw new CMMException("Problem encountered. UserGroupDAOImpl : getAllUserNames", he);
		} catch (Exception e) {
			LOGGER.error(e);
			throw new CMMException("Problem encountered. UserGroupDAOImpl : getAllUserNames", e);
		}
		return dbUserNames;
	}
	
	@Override
	public UserGroupTO getUserGrpName(Long appid) throws CMMException {
	
		UserGroupTO userGroupTO = new UserGroupTO();
		try {
			Object[] dbusergrpname = (Object[]) getHibernateTemplate().find("select u.id,u.name from UserGroupTO u , ApplicationTO a where u.id=a.userGroups.id and  a.id=?", appid).get(0);
			Long uid = (Long) dbusergrpname[0];
			userGroupTO.setId(uid);
			String username = (String) dbusergrpname[1];
			userGroupTO.setName(username);
			List<Object> dbUserNames = (List<Object>) getHibernateTemplate().find("select u.id,u.name from UserGroupDetailsTO ud inner join ud.users u where ud.userGroups.id=? and u.status=?", uid, Entity.USER_STATUS_ACTIVE);
			List<UserTO> users = new ArrayList<UserTO>();
			for (int i = 0; i < dbUserNames.size(); i++) {
				UserTO appTO = new UserTO();
				Object[] obj = (Object[]) dbUserNames.get(i);
				Long id = (Long) obj[0];
				appTO.setId(id);
				String name = (String) obj[1];
				appTO.setName(name);
				users.add(appTO);
			}
			userGroupTO.setUserList(users);
		} catch (DataAccessException dae) {
			LOGGER.error(dae);
			throw new CMMException("Problem encountered. UserGroupDAOImpl : getUserGrpName", dae);
		} catch (HibernateException he) {
			LOGGER.error(he);
			throw new CMMException("Problem encountered.  UserGroupDAOImpl : getUserGrpName", he);
		} catch (Exception e) {
			LOGGER.error(e);
			throw new CMMException("Problem encountered.  UserGroupDAOImpl : getUserGrpName", e);
		}
		return userGroupTO;
	}
	
	@Override
	public void userGrpUpdate(UserGroupDetailsTO userGrpDtlsTO) throws CMMException {
	
		try {
			UserGroupTO temp = (UserGroupTO) getHibernateTemplate().find("from UserGroupTO where id=?", userGrpDtlsTO.getId()).get(0);
			temp.getUserGroupDetailses().clear();
			for (Long id : userGrpDtlsTO.getSelectedUserName()) {
				UserGroupDetailsTO to = new UserGroupDetailsTO();
				UserTO userTo = new UserTO();
				userTo.setId(id);
				to.setUsers(userTo);
				to.setUserGroups(temp);
				temp.getUserGroupDetailses().add(to);
			}
			temp.setName(userGrpDtlsTO.getUserGroups().getName());
			getHibernateTemplate().saveOrUpdate(temp);
		} catch (DataAccessException dae) {
			LOGGER.error(dae);
			throw new CMMException("Problem encountered. UserGroupDAOImpl : userGrpUpdate", dae);
		} catch (HibernateException he) {
			LOGGER.error(he);
			throw new CMMException("Problem encountered.  UserGroupDAOImpl : userGrpUpdate", he);
		} catch (Exception e) {
			LOGGER.error(e);
			throw new CMMException("Problem encountered.  UserGroupDAOImpl : userGrpUpdate", e);
		}
	}
	
	@Override
	public List<String> getAllUserEmails(Long appid) throws CMMException {
	
		List<String> userEmailList = new ArrayList<String>(0);
		try {
			List<ApplicationTO> appList = (List<ApplicationTO>) getHibernateTemplate().find("from ApplicationTO where id=?", appid);
			if (!appList.isEmpty()) {
				List<UserTO> userList = (List<UserTO>) getHibernateTemplate().find("select u.users from UserGroupDetailsTO u where u.userGroups.id=? and u.users.status=?", appList.get(0).getSelectedUserGroup(), Entity.USER_STATUS_ACTIVE);
				for (UserTO user : userList) {
					userEmailList.add(user.getEmail().trim());
				}
			}
		} catch (DataAccessException dae) {
			LOGGER.error(dae);
			throw new CMMException("Problem encountered. UserGroupDAOImpl : getAllUserEmails", dae);
		} catch (HibernateException he) {
			LOGGER.error(he);
			throw new CMMException("Problem encountered. UserGroupDAOImpl : getAllUserEmails", he);
		} catch (Exception e) {
			LOGGER.error(e);
			throw new CMMException("Problem encountered. UserGroupDAOImpl : getAllUserEmails", e);
		}
		return userEmailList;
	}
}
