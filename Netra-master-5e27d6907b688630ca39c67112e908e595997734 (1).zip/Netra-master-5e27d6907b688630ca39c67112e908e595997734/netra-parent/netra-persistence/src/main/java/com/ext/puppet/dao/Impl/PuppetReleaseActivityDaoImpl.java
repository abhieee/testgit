package com.ext.puppet.dao.Impl;

import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.puppet.dao.PuppetReleaseActivityDao;
import com.framework.exception.CMMException;
import com.framework.puppetMaster.to.PuppetActivitySoftwareMappingTO;
import com.framework.puppetMaster.to.PuppetMasterDetailsTO;
import com.framework.puppetMaster.to.PuppetProcessParametersTO;
import com.framework.puppetMaster.to.PuppetReleaseActivityTO;
import com.framework.to.ApplicationReleaseDbTO;
import com.framework.to.SoftwareTO;
import com.framework.to.SoftwareTaskMappingTO;
import com.framework.to.SoftwareconfigTO;
import com.framework.to.ZabbixSoftwareMappingTO;

public class PuppetReleaseActivityDaoImpl extends HibernateDaoSupport implements PuppetReleaseActivityDao {
	
	private static final Logger LOGGER = Logger.getLogger(PuppetReleaseActivityDaoImpl.class);
	private String className = "PuppetReleaseActivityDaoImpl";
	
	@Override
	@SuppressWarnings("unchecked")
	public String fetchMappedSoftwareType(Long mappedSoftwareId) throws CMMException {
	
		String methodName = "fetchMappedSoftwareType";
		try {
			List<SoftwareTO> mappedSoftwareList = (List<SoftwareTO>) getHibernateTemplate().find("from SoftwareTO where id=" + mappedSoftwareId);
			if (mappedSoftwareList.isEmpty()) {
				throw new CMMException("No records found for mappedSoftwareId: " + mappedSoftwareId);
			}
			return mappedSoftwareList.get(0).getType();
		} catch (DataAccessException | HibernateException dae) {
			LOGGER.error("Error in " + className + " :" + methodName, dae);
			throw new CMMException("Problem encountered." + className + " :" + methodName, dae);
		}
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public List<PuppetMasterDetailsTO> getPuppetMasterDetails() throws CMMException {
	
		String methodName = "getPuppetMasterDetails";
		try {
			List<PuppetMasterDetailsTO> puppetMasterDetailsList = (List<PuppetMasterDetailsTO>) getHibernateTemplate().find("from PuppetMasterDetailsTO");
			if (!puppetMasterDetailsList.isEmpty()) {
				return puppetMasterDetailsList;
			} else {
				LOGGER.debug("puppetMasterDetailsList is empty");
				throw new CMMException("Problem encountered. " + className + " :" + methodName);
			}
		} catch (DataAccessException | HibernateException dae) {
			LOGGER.error("Error in " + className + " :" + methodName, dae);
			throw new CMMException("Problem encountered. " + className + " :" + methodName, dae);
		}
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public String getPuppetParameters(Long processId) throws CMMException {
	
		String methodName = "getPuppetParameters";
		try {
			LOGGER.info("to fetch the puppet process parameters for the puppet");
			String puppetParameters = " ";
			List<PuppetProcessParametersTO> puppetProcessParameters = (List<PuppetProcessParametersTO>) getHibernateTemplate().find("from PuppetProcessParametersTO where process_Id=" + processId);
			if (puppetProcessParameters == null) {
				LOGGER.debug("No data found in database for PuppetProcessParametersTO");
				throw new CMMException("No activity list found.");
			}
			for (PuppetProcessParametersTO a : puppetProcessParameters) {
				puppetParameters = puppetParameters + " " + a.getParameterValue();
			}
			LOGGER.debug("********************puppetParameters*************" + puppetParameters);
			return puppetParameters;
		} catch (DataAccessException | HibernateException dae) {
			LOGGER.error("Error in " + className + " :" + methodName, dae);
			throw new CMMException("Problem encountered." + className + " :" + methodName, dae);
		}
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public String getaddtionalDBParameters(long requestId) throws CMMException {
	
		String methodName = "getaddtionalDBParameters";
		try {
			LOGGER.info("to fetch the application Release  parameters for the puppet");
			String dBParameters = " ";
			List<ApplicationReleaseDbTO> applReleaseDBParameters = (List<ApplicationReleaseDbTO>) getHibernateTemplate().find("from ApplicationReleaseDbTO where RequestId=" + requestId);
			if (applReleaseDBParameters == null) {
				LOGGER.debug("No data found in database for ApplicationReleaseDbTO");
				throw new CMMException("No activity list found.");
			}
			for (ApplicationReleaseDbTO a : applReleaseDBParameters) {
				LOGGER.debug("dBParameters" + a.getSchemaName() + "________" + a.getDatabaseScripts() + "__________" + a.getRollbackScriptPath() + "______________" + a.getRollbackOrder());
				dBParameters = dBParameters + " " + a.getSchemaName();
			}
			LOGGER.debug("********************dBParameters*************" + dBParameters);
			return dBParameters;
		} catch (DataAccessException | HibernateException dae) {
			LOGGER.error("Error in " + className + " :" + methodName, dae);
			throw new CMMException("Problem encountered. " + className + " :" + methodName, dae);
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<PuppetReleaseActivityTO> getAllActivity() throws CMMException {
	
		String methodName = "getAllActivity";
		try {
			List<PuppetReleaseActivityTO> puppetReleaseActivityList = (List<PuppetReleaseActivityTO>) getHibernateTemplate().find("from PuppetReleaseActivityTO");
			if (puppetReleaseActivityList == null) {
				LOGGER.debug("No acitvity found in database");
				throw new CMMException("No activity list found.");
			}
			return puppetReleaseActivityList;
		} catch (DataAccessException | HibernateException dae) {
			LOGGER.error("Error in " + className + " :" + methodName, dae);
			throw new CMMException("Problem encountered." + className + " :" + methodName, dae);
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<PuppetReleaseActivityTO> getAllPuppetReleaseActivities() throws CMMException {
	
		String methodName = "getAllPuppetReleaseActivities";
		try {
			List<PuppetReleaseActivityTO> puppetReleaseActivityList = (List<PuppetReleaseActivityTO>) getHibernateTemplate().find("from PuppetReleaseActivityTO");
			if (puppetReleaseActivityList == null) {
				LOGGER.debug("No acitvity found in database");
				throw new CMMException("No activity list found.");
			}
			return puppetReleaseActivityList;
		} catch (DataAccessException | HibernateException dae) {
			LOGGER.error("Error in  " + className + " :" + methodName, dae);
			throw new CMMException("Problem encountered.  " + className + " :" + methodName, dae);
		}
	}
	
	@SuppressWarnings({ "unchecked", "deprecation" })
	@Override
	public boolean definePuppetActivitiesForSoftware(PuppetActivitySoftwareMappingTO mapping) throws CMMException {
	
		String methodName = "definePuppetActivitiesForSoftware";
		boolean flag = false;
		Long softwareConfigId = null;
		Session session = null;
		try {
			if (mapping.getSoftwareconfigTO().getId() != null) {
				DetachedCriteria criteria1 = DetachedCriteria.forClass(PuppetActivitySoftwareMappingTO.class);
				criteria1.createAlias("softwareconfigTO", "sConfig", CriteriaSpecification.INNER_JOIN);
				criteria1.add(Restrictions.eq("sConfig.id", mapping.getSoftwareconfigTO().getId()));
				List<PuppetActivitySoftwareMappingTO> acitivityList = (List<PuppetActivitySoftwareMappingTO>) getHibernateTemplate().findByCriteria(criteria1);
				for (PuppetActivitySoftwareMappingTO temp : acitivityList) {
					Transaction tx1 = null;
					session = getSession();
					tx1 = session.beginTransaction();
					String hql1 = "Delete from PuppetActivityExecOrderTO where puppetActivitySoftwareMappingTOP.activitySoftwareMapId = :activitySoftwareMapId";
					Query query1 = session.createQuery(hql1);
					query1.setParameter("activitySoftwareMapId", temp.getActivitySoftwareMapId());
					query1.executeUpdate();
					String hql2 = "Delete from PuppetActivitySoftwareMappingTO where activitySoftwareMapId = :activitySoftwareMapId";
					Query query2 = session.createQuery(hql2);
					query2.setParameter("activitySoftwareMapId", temp.getActivitySoftwareMapId());
					query2.executeUpdate();
					tx1.commit();
				}
				softwareConfigId = mapping.getSoftwareconfigTO().getId();
			} else {
				softwareConfigId = (Long) getHibernateTemplate().find("select MAX(id) from SoftwareconfigTO where deviceId=?", mapping.getSoftwareconfigTO().getDeviceId()).get(0);
			}
			SoftwareconfigTO sTo = (SoftwareconfigTO) getHibernateTemplate().find("from SoftwareconfigTO where id=? ", softwareConfigId).get(0);
			Transaction tx = null;
			session = getSession();
			tx = session.beginTransaction();
			String hql = "from PuppetReleaseActivityTO where activityId in (:PuppetActivityId)";
			Query q = session.createQuery(hql);
			q.setParameterList("PuppetActivityId", mapping.getDefinedPuppetActivities());
			List<Object[]> obj = q.list();
			tx.commit();
			PuppetActivitySoftwareMappingTO temp = new PuppetActivitySoftwareMappingTO();
			for (Object activity : obj) {
				PuppetReleaseActivityTO puppetObj = (PuppetReleaseActivityTO) activity;
				temp.setSoftwareconfigTO(sTo);
				temp.setPuppetReleaseActivityTO(puppetObj);
				temp.setActivityId(puppetObj.getActivityId());
				getHibernateTemplate().save(temp);
			}
			flag = true;
		} catch (DataAccessException | HibernateException dae) {
			LOGGER.error("Error in " + className + " :" + methodName, dae);
			throw new CMMException("Problem encountered. " + className + " :" + methodName, dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return flag;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<PuppetReleaseActivityTO> getPuppetSoftwareActivitites(long softwareConfigId) throws CMMException {
	
		String methodName = "getPuppetSoftwareActivitites";
		List<PuppetReleaseActivityTO> puppetReleaseActivityTOList = new ArrayList<PuppetReleaseActivityTO>();
		try {
			List<PuppetActivitySoftwareMappingTO> puppetActivitySoftwareMappingTO = (List<PuppetActivitySoftwareMappingTO>) getHibernateTemplate().find("from PuppetActivitySoftwareMappingTO where softwareconfigTO.id =?", softwareConfigId);
			if (puppetActivitySoftwareMappingTO == null) {
				LOGGER.debug("No acitvity found in database");
				throw new CMMException("No activity list found.");
			}
			for (PuppetActivitySoftwareMappingTO temp : puppetActivitySoftwareMappingTO) {
				PuppetReleaseActivityTO puppetReleaseActivityTO = temp.getPuppetReleaseActivityTO();
				puppetReleaseActivityTOList.add(puppetReleaseActivityTO);
			}
			return puppetReleaseActivityTOList;
		} catch (DataAccessException | HibernateException dae) {
			LOGGER.error("Error in  " + className + " :" + methodName, dae);
			throw new CMMException("Problem encountered.  " + className + " :" + methodName, dae);
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public long fetchMappedActivitySoftwareId(long activityId, long softwareId) throws CMMException {
	
		String methodName = "fetchMappedActivitySoftwareId";
		try {
			List<PuppetActivitySoftwareMappingTO> activitySoftwareMapList = (List<PuppetActivitySoftwareMappingTO>) getHibernateTemplate().find("from PuppetActivitySoftwareMappingTO where puppetReleaseActivityTO.activityId=? and softwareconfigTO.id=?", activityId, softwareId);
			if (activitySoftwareMapList.isEmpty()) {
				throw new CMMException("No records found for activityId: " + activityId);
			}
			return activitySoftwareMapList.get(0).getActivitySoftwareMapId();
		} catch (DataAccessException | HibernateException dae) {
			LOGGER.error("Error in " + className + " :" + methodName, dae);
			throw new CMMException("Problem encountered. " + className + " :" + methodName, dae);
		}
	}
	
	@Override
	public List<PuppetReleaseActivityTO> getAllRemainingActivities() throws CMMException {
	
		String methodName = "getAllRemainingActivities";
		try {
			List<PuppetReleaseActivityTO> puppetReleaseActivityList = (List<PuppetReleaseActivityTO>) getHibernateTemplate().find("from PuppetReleaseActivityTO");
			if (puppetReleaseActivityList == null) {
				LOGGER.debug("No acitvity found in database");
				throw new CMMException("No activity list found.");
			}
			return puppetReleaseActivityList;
		} catch (DataAccessException | HibernateException dae) {
			LOGGER.error("Error in " + className + " :" + methodName, dae);
			throw new CMMException("Problem encountered. " + className + " :" + methodName, dae);
		}
	}
	
	@Override
	public SoftwareconfigTO addSoftwarePuppetMapDetails(SoftwareTO softwareTO) throws CMMException {
	
		SoftwareconfigTO temp = null;
		Session session = null;
		try {
			List<SoftwareconfigTO> list = (List<SoftwareconfigTO>) getHibernateTemplate().find("from SoftwareconfigTO where deviceId=? and version=?", softwareTO.getId(), softwareTO.getVersion());
			if ((list != null) && !list.isEmpty()) {
				temp = list.get(0);
				/* Deleting existing data */
				if ((temp.getTargetFlag() != null) && "W".equals(temp.getTargetFlag())) {
					if ((temp.getInstallerLocationWindows() != null) && (temp.getTargetLocationWindows() != null)) {
						temp.setInstallerLocationWindows("");
						temp.setTargetLocationWindows("");
					}
				}
				if ((temp.getTargetFlag() != null) && "L".equals(temp.getTargetFlag())) {
					if ((temp.getInstallerLocationLinux() != null) && (temp.getTargetLocationLinux() != null)) {
						temp.setInstallerLocationLinux("");
						temp.setTargetLocationLinux("");
					}
				}
				if ((temp.getTargetFlag() != null) && "B".equals(temp.getTargetFlag())) {
					if ((temp.getInstallerLocationLinux() != null) && (temp.getTargetLocationLinux() != null) && (temp.getInstallerLocationWindows() != null) && (temp.getTargetLocationWindows() != null)) {
						temp.setInstallerLocationLinux("");
						temp.setTargetLocationLinux("");
						temp.setInstallerLocationWindows("");
						temp.setTargetLocationWindows("");
					}
				}
				/*
				 * if(temp.getParameters() != null){ temp.setParameters(""); }
				 */
				getHibernateTemplate().saveOrUpdate(temp);
				/* Deleting existing data */
				List<SoftwareTaskMappingTO> SoftwareTaskMappingToList = (List<SoftwareTaskMappingTO>) getHibernateTemplate().find("from SoftwareTaskMappingTO where softwareConfigId=?", temp.getId());
				if (SoftwareTaskMappingToList != null) {
					for (SoftwareTaskMappingTO SoftwareTaskMap : SoftwareTaskMappingToList) {
						getHibernateTemplate().delete(SoftwareTaskMap);
					}
				}
				Long taskOrder = 0L;
				for (Long taskId : softwareTO.getTasks()) {
					SoftwareTaskMappingTO sofTaskMap = new SoftwareTaskMappingTO();
					sofTaskMap.setSoftwareConfigId(temp.getId());
					sofTaskMap.setTaskId(taskId);
					sofTaskMap.setTaskOrder(taskOrder);
					getHibernateTemplate().save(sofTaskMap);
					taskOrder++;
				}
			}
			/*
			 * if (softwareTO.getParameters() != null) { if (softwareTO.getParameters().toString().length() > 2) {
			 * temp.setParameters(softwareTO.getParameters().toString().substring(1, softwareTO.getParameters().toString().length() - 1)); } }
			 */
			temp.setTargetFlag(softwareTO.getTargetFlag());
			temp.setInstallerLocationLinux(softwareTO.getInstallerLocationLinux());
			temp.setInstallerLocationWindows(softwareTO.getInstallerLocationWindows());
			temp.setTargetLocationLinux(softwareTO.getTargetLocationLinux());
			temp.setTargetLocationWindows(softwareTO.getTargetLocationWindows());
			getHibernateTemplate().saveOrUpdate(temp);
			List<ZabbixSoftwareMappingTO> zabbixSoftwareMappingToP = (List<ZabbixSoftwareMappingTO>) getHibernateTemplate().find("from ZabbixSoftwareMappingTO where softwareConfigId =? ", temp.getId());
			if (zabbixSoftwareMappingToP != null) {
				for (int i = 0; i < zabbixSoftwareMappingToP.size(); i++) {
					ZabbixSoftwareMappingTO zabbixSoftwareMapTO = zabbixSoftwareMappingToP.get(i);
					getHibernateTemplate().delete(zabbixSoftwareMapTO);
				}
			}
			for (Long tempObj : softwareTO.getSelectedTemplates()) {
				ZabbixSoftwareMappingTO zabbixSoftwareMappingTO = new ZabbixSoftwareMappingTO();
				zabbixSoftwareMappingTO.setTemplateid(tempObj);
				zabbixSoftwareMappingTO.setSoftwareConfigId(temp.getId());
				for (ZabbixSoftwareMappingTO tempTemplate : softwareTO.getZabbixTemplatesList()) {
					if (tempTemplate.getTemplateid().equals(tempObj)) {
						zabbixSoftwareMappingTO.setName(tempTemplate.getName());
					}
				}
				getHibernateTemplate().save(zabbixSoftwareMappingTO);
			}
		} catch (DataAccessException | HibernateException ce) {
			LOGGER.error(ce);
			throw new CMMException("problem encountered. PuppetReleaseActivityDaoImpl : addSoftwarePuppetMapDetails", ce);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return temp;
	}
}
