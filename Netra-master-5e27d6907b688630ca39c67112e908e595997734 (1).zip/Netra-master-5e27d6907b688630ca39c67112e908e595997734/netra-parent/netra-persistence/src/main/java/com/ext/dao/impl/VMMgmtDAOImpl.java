package com.ext.dao.impl;

import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.VMMgmtDAO;
import com.framework.exception.CMMException;
import com.framework.to.VMDetailsTO;

public class VMMgmtDAOImpl extends HibernateDaoSupport implements VMMgmtDAO {
	
	@Override
	public boolean addVmDetails(VMDetailsTO vmDetailsTO) throws CMMException {
	
		try {
			getHibernateTemplate().save(vmDetailsTO);
			return true;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.VMMgmtDAOImpl:addVmDetails", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.VMMgmtDAOImpl:addVmDetails", he);
		}
	}
	
	@Override
	public VMDetailsTO getVMDetails(VMDetailsTO vmTO) throws CMMException {
	
		try {
			vmTO.setServerTemplateId(vmTO.getServerTemplateId());
			vmTO.setEnvironmentId(vmTO.getEnvironmentId());
			List<VMDetailsTO> vmDetailsTO = (List<VMDetailsTO>) getHibernateTemplate().find("from VMDetailsTO where serverTemplateId=?and environmentId=?", vmTO.getServerTemplateId(), vmTO.getEnvironmentId());
			if ((vmDetailsTO != null) && !vmDetailsTO.isEmpty()) {
				return vmDetailsTO.get(0);
			}
			return null;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.VMMgmtDAOImpl:getVMDetails", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.VMMgmtDAOImpl:getVMDetails", he);
		}
	}
	
	@Override
	public VMDetailsTO getEnvVMDetails(long hardwareId, long serverGrpId, long environmentId) throws CMMException {
	
		try {
			List<VMDetailsTO> vmDetailsTOList = (List<VMDetailsTO>) getHibernateTemplate().find("from VMDetailsTO where serverTemplateId=? and serverGroupId=? and environmentId=?", hardwareId, serverGrpId, environmentId);
			if ((vmDetailsTOList == null) || vmDetailsTOList.isEmpty()) {
				throw new CMMException("No Environment VM details found for serverTemplateId: " + hardwareId + " and serverGroupId: " + serverGrpId);
			}
			return vmDetailsTOList.get(0);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.VMMgmtDAOImpl:getEnvVMDetails", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.VMMgmtDAOImpl:getEnvVMDetails", he);
		}
	}
	
	@Override
	public VMDetailsTO getEnvMDetailsByRequestId(long requestId) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			VMDetailsTO vmDetailsTO = (VMDetailsTO) session.createCriteria(VMDetailsTO.class).add(Restrictions.eq("serviceRequestId", requestId)).uniqueResult();
			if (vmDetailsTO == null) {
				throw new CMMException("No Vm details records found for requestId:" + requestId);
			}
			return vmDetailsTO;
		} catch (DataAccessException dae) {
			throw new CMMException("Error in fetching environment vm details for requestId:" + requestId, dae);
		} catch (HibernateException he) {
			throw new CMMException("Error in fetching environment vm details for requestId:" + requestId, he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public VMDetailsTO getEnvMachineDetails(long machineId, long serverGrpId, long environmentId) throws CMMException {
	
		try {
			List<VMDetailsTO> vmDetailsTOList = (List<VMDetailsTO>) getHibernateTemplate().find("from VMDetailsTO where machineId=? and serverGroupId=? and environmentId=?", machineId, serverGrpId, environmentId);
			if ((vmDetailsTOList == null) || vmDetailsTOList.isEmpty()) {
				throw new CMMException("No Environment VM details found for machineId: " + machineId + " and serverGroupId: " + serverGrpId);
			}
			return vmDetailsTOList.get(0);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered.VMMgmtDAOImpl:getEnvMachineDetails", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.VMMgmtDAOImpl:getEnvMachineDetails", he);
		}
	}
}
