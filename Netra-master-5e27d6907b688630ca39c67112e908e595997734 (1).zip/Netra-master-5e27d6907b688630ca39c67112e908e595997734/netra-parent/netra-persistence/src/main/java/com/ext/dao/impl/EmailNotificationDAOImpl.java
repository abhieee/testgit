package com.ext.dao.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.exception.ConstraintViolationException;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.EmailNotificationDAO;
import com.framework.common.CMMConstants;
import com.framework.exception.CMMException;
import com.framework.to.BusinessUnitTO;
import com.framework.to.EmailNotificationTO;
import com.framework.to.MailSetupMappingTO;
import com.framework.to.MailSetupRoleMappingTO;
import com.framework.to.MailSetupTO;
import com.framework.to.MsgHistoryTO;
import com.framework.to.ProjectsTO;
import com.framework.to.RoleTO;
import com.framework.to.ServiceMailTO;
import com.framework.to.ServiceRequestHistoryTO;
import com.framework.to.ServiceRequestTO;
import com.framework.to.ServiceTO;
import com.framework.to.UserTO;

public class EmailNotificationDAOImpl extends HibernateDaoSupport implements EmailNotificationDAO {
	
	private static final Long ACTIVE_USER_STATUS = 11L;
	
	@Override
	public List<ServiceTO> fetchServiceList() throws CMMException {
	
		try {
			return (List<ServiceTO>) getHibernateTemplate().find("from ServiceTO where id not in (21L,24L) and subServiceFlag =?  and status=? ", CMMConstants.Framework.ServiceFlag.SERVICE_FLAG_Y, CMMConstants.Framework.Entity.SERVICES_ACTIVE);
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationParameterDAOImpl : fetchActivitySoftMapDetail", dae);
		}
	}
	
	@Override
	public List<RoleTO> fetchRoleList() throws CMMException {
	
		try {
			return (List<RoleTO>) getHibernateTemplate().find("select r from RoleTO r, RoleLevelTO rl where r.id = rl.roleTO.id and r.statusTO.id =?", CMMConstants.Framework.Entity.ROLE_STATUS_ACTIVE);
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationParameterDAOImpl : fetchActivitySoftMapDetail", dae);
		}
	}
	
	@Override
	public Long submitEmailNotificationDetails(EmailNotificationTO emailTO) throws CMMException {
	
		try {
			MailSetupTO mailSetuoTo = new MailSetupTO();
			mailSetuoTo.setServiceId(emailTO.getSelectedService());
			mailSetuoTo.setReceiverTo(emailTO.getDestinationName());
			mailSetuoTo.setReceiverCc(emailTO.getCcName());
			mailSetuoTo.setMessage(emailTO.getMessage());
			if (emailTO.getSelectedService() != 4) {
				if (emailTO.getSelectedAction().equalsIgnoreCase(CMMConstants.Framework.Action.SUCCESS)) {
					mailSetuoTo.setAction(CMMConstants.Framework.Action.SUCCESS_FLAG);
				}
				if (emailTO.getSelectedAction().equalsIgnoreCase(CMMConstants.Framework.Action.FAILURE)) {
					mailSetuoTo.setAction(CMMConstants.Framework.Action.FAILURE_FLAG);
				}
				if (emailTO.getSelectedAction().equalsIgnoreCase(CMMConstants.Framework.Action.BOTH)) {
					mailSetuoTo.setAction(CMMConstants.Framework.Action.BOTH_FLAG);
				}
			}
			Long mailSetUpId = (Long) getHibernateTemplate().save(mailSetuoTo);
			for (Long role : emailTO.getDefinedRoles()) {
				MailSetupRoleMappingTO mailSetupRoleMap = new MailSetupRoleMappingTO();
				mailSetupRoleMap.setRoleId(role);
				mailSetupRoleMap.setMailSetupId(mailSetUpId);
				getHibernateTemplate().save(mailSetupRoleMap);
			}
			if (emailTO.getSelectedProjectList() != null) {
				for (Long projectId : emailTO.getSelectedProjectList()) {
					List<ProjectsTO> projects = (List<ProjectsTO>) getHibernateTemplate().find("from ProjectsTO where id=?", projectId);
					if (projects.size() > 0L) {
						MailSetupMappingTO mailSetupMapping = new MailSetupMappingTO();
						ProjectsTO project = new ProjectsTO();
						project = projects.get(0);
						mailSetupMapping.setClientId(project.getClientId());
						mailSetupMapping.setProjectId(project.getId());
						mailSetupMapping.setMailSetupId(mailSetUpId);
						getHibernateTemplate().save(mailSetupMapping);
					}
				}
			} else {
				for (Long buId : emailTO.getSelectedBuList()) {
					MailSetupMappingTO mailSetupMapping = new MailSetupMappingTO();
					mailSetupMapping.setClientId(buId);
					mailSetupMapping.setMailSetupId(mailSetUpId);
					getHibernateTemplate().save(mailSetupMapping);
				}
			}
			return mailSetUpId;
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationParameterDAOImpl : fetchActivitySoftMapDetail", dae);
		}
	}
	
	@Override
	public List<RoleTO> fetchDefinedRoles(List<Long> definedRoles) throws CMMException {
	
		List<RoleTO> roleList = new ArrayList<RoleTO>(0);
		for (Long role : definedRoles) {
			RoleTO roleObj = (RoleTO) getHibernateTemplate().find("from RoleTO where id =?", role).get(0);
			roleList.add(roleObj);
		}
		return roleList;
	}
	
	@Override
	public EmailNotificationTO fetchExistingMailDetails(EmailNotificationTO emailTO) throws CMMException {
	
		List<MailSetupTO> mailsetupToList = (List<MailSetupTO>) getHibernateTemplate().find("from MailSetupTO where id =? ", emailTO.getSelectedId());
		emailTO.setSelectedRoles(new ArrayList<RoleTO>(0));
		emailTO.setSelectedAction("");
		emailTO.setDestinationName("");
		emailTO.setCcName("");
		emailTO.setMessage("");
		if (mailsetupToList.size() > 0L) {
			List<MailSetupRoleMappingTO> mailsetupRoleMapToList = (List<MailSetupRoleMappingTO>) getHibernateTemplate().find("from MailSetupRoleMappingTO where mailSetupId =? ", mailsetupToList.get(0).getId());
			List<MailSetupMappingTO> mailsetupMappingToList = (List<MailSetupMappingTO>) getHibernateTemplate().find("from MailSetupMappingTO  where  mailSetupId =? and clientId =?", mailsetupToList.get(0).getId(), emailTO.getSelectedClientId());
			List<RoleTO> selectedRoles = new ArrayList<RoleTO>(0);
			List<BusinessUnitTO> selectedBus = new ArrayList<BusinessUnitTO>(0);
			List<ProjectsTO> selectedProjects = new ArrayList<ProjectsTO>(0);
			for (MailSetupRoleMappingTO mailSetup : mailsetupRoleMapToList) {
				RoleTO roleObj = (RoleTO) getHibernateTemplate().find("from RoleTO where id =?", mailSetup.getRoleId()).get(0);
				selectedRoles.add(roleObj);
			}
			if (!mailsetupMappingToList.isEmpty()) {
				if (mailsetupMappingToList.get(0).getProjectId() != null) {
					for (MailSetupMappingTO mailSetupProject : mailsetupMappingToList) {
						ProjectsTO projectObj = (ProjectsTO) getHibernateTemplate().find("from ProjectsTO where id =?", mailSetupProject.getProjectId()).get(0);
						selectedProjects.add(projectObj);
					}
					BusinessUnitTO buObj = (BusinessUnitTO) getHibernateTemplate().find("select distinct b from BusinessUnitTO b where b.id =?", mailsetupMappingToList.get(0).getClientId()).get(0);
					selectedBus.add(buObj);
				} else {
					BusinessUnitTO buObj = (BusinessUnitTO) getHibernateTemplate().find("select distinct b from BusinessUnitTO b where b.id =?", mailsetupMappingToList.get(0).getClientId()).get(0);
					selectedBus.add(buObj);
				}
			}
			emailTO.setBusinessUnitList(selectedBus);
			emailTO.setProjectList(selectedProjects);
			emailTO.setMailsetupRoleMapToList(mailsetupRoleMapToList);
			emailTO.setSelectedRoles(selectedRoles);
			emailTO.setSelectedService(mailsetupToList.get(0).getServiceId());
			if (emailTO.getSelectedService() != 4) {
				if (mailsetupToList.get(0).getAction().equalsIgnoreCase(CMMConstants.Framework.Action.SUCCESS_FLAG)) {
					emailTO.setSelectedAction(CMMConstants.Framework.Action.SUCCESS);
				}
				if (mailsetupToList.get(0).getAction().equalsIgnoreCase(CMMConstants.Framework.Action.FAILURE_FLAG)) {
					emailTO.setSelectedAction(CMMConstants.Framework.Action.FAILURE);
				}
				if (mailsetupToList.get(0).getAction().equalsIgnoreCase(CMMConstants.Framework.Action.BOTH_FLAG)) {
					emailTO.setSelectedAction(CMMConstants.Framework.Action.BOTH);
				}
			}
			emailTO.setDestinationName(mailsetupToList.get(0).getReceiverTo());
			emailTO.setCcName(mailsetupToList.get(0).getReceiverCc());
			emailTO.setMessage(mailsetupToList.get(0).getMessage());
			List<ServiceTO> serviceTo = (List<ServiceTO>) getHibernateTemplate().find("from ServiceTO where id =? ", mailsetupToList.get(0).getServiceId());
			ServiceTO service = new ServiceTO();
			if (!serviceTo.isEmpty()) {
				service = serviceTo.get(0);
			}
			emailTO.setServiceName(service.getName());
		}
		emailTO.setMailsetupToList(mailsetupToList);
		return emailTO;
	}
	
	@Override
	public List<String> fetchUsersListForMail(Long requestId) throws CMMException {
	
		List<UserTO> users = new ArrayList<UserTO>(0);
		List<UserTO> userToList = new ArrayList<UserTO>(0);
		List<String> userStrList1 = new ArrayList<String>(0);
		List<String> userToListFinal = new ArrayList<String>(0);
		List<Long> applicationIds = new ArrayList<Long>(0);
		List<Long> applicationIdMail = new ArrayList<Long>(0);
		Session session = null;
		Long applicationId = 0L;
		List<String> userStrList = new ArrayList<String>(0);
		try {
			MailSetupTO mailSetup = new MailSetupTO();
			session = getSession();
			ServiceRequestTO requestTo = (ServiceRequestTO) getHibernateTemplate().find("from ServiceRequestTO where id =?", requestId).get(0);
			Long serviceId = requestTo.getServiceId();
			if (requestTo.getServiceId().equals(CMMConstants.Framework.Service.CREATE_ENVIRONMENT_SERVICE_ID)) {
				applicationId = (Long) getHibernateTemplate().find("select ea.applicationTO.id from EnvironmentApplicationTO ea, ServiceRequestTO s where s.environmentId = ea.environmentTO.id and s.id=?", requestTo.getId()).get(0);
			} else {
				applicationId = requestTo.getApplicationId();
			}
			Long clientId = (Long) getHibernateTemplate().find("select clientId from ApplicationTO where id =?", applicationId).get(0);
			List<MailSetupTO> mailsetupTO = (List<MailSetupTO>) getHibernateTemplate().find("select distinct m from MailSetupTO m , MailSetupMappingTO ms where m.id = ms.mailSetupId and m.serviceId =? and ms.clientId=?", serviceId, clientId);
			if ((mailsetupTO != null) && !mailsetupTO.isEmpty()) {
				mailSetup = mailsetupTO.get(0);
			} else {
				return userToListFinal;
			}
			List<MailSetupMappingTO> mailSetupMappingToList = (List<MailSetupMappingTO>) getHibernateTemplate().find("from MailSetupMappingTO where mailSetupId =?", mailSetup.getId());
			for (MailSetupMappingTO msm : mailSetupMappingToList) {
				if (msm.getProjectId() == null) {
					applicationIdMail = (List<Long>) getHibernateTemplate().find("select distinct a.id from ApplicationTO a, MailSetupMappingTO msm ,ClientTO c, MailSetupTO ms where a.clientId=msm.clientId and ms.id=msm.mailSetupId and ms.serviceId =? and msm.clientId =?", serviceId, clientId);
				} else {
					Long projectId = (Long) getHibernateTemplate().find("select selectedProject from ApplicationTO where id =?", applicationId).get(0);
					applicationIdMail = (List<Long>) getHibernateTemplate().find("	select distinct a.id from ApplicationTO a, MailSetupMappingTO msm ,ClientTO c, ProjectsTO p, MailSetupTO ms where a.clientId=msm.clientId and a.selectedProject=msm.projectId and ms.id=msm.mailSetupId and ms.serviceId =? and msm.clientId =? and msm.projectId=?", serviceId, clientId, projectId);
				}
			}
			if (requestTo.getApplicationId() == null) {
				applicationIds = (List<Long>) getHibernateTemplate().find("select applicationTO.id from EnvironmentApplicationTO where environmentTO.id =?", requestTo.getEnvironmentId());
			} else {
				applicationIdMail.addAll(applicationIds);
				applicationIdMail.add(requestTo.getApplicationId());
			}
			String hql = "select distinct up.userTO from UserGroupDetailsTO  ugd , UserPrivilegeTO up, MailSetupTO ms , MailSetupRoleMappingTO msrm , ApplicationTO a, UserGroupTO ug where up.id=ugd.users.id and ms.id=msrm.mailSetupId and ms.serviceId=(:serviceId) and msrm.roleId = up.roleId and a.selectedUserGroup=ug.id and a.id in (:ApplicationId) and ug.id=ugd.userGroups.id and a.selectedUserGroup=ug.id and up.userTO.status = " + ACTIVE_USER_STATUS;
			Query q = session.createQuery(hql);
			q.setParameterList("ApplicationId", applicationIdMail);
			q.setParameter("serviceId", requestTo.getServiceId());
			List<Object[]> obj = q.list();
			for (Object temp : obj) {
				userToList.add((UserTO) temp);
			}
			for (UserTO user : userToList) {
				boolean flag = false;
				for (UserTO user1 : users) {
					if (user.getId() == user1.getId()) {
						flag = true;
					}
				}
				if (flag == false) {
					users.add(user);
				}
			}
			for (UserTO user : users) {
				String userEmailId = user.getEmail();
				userStrList.add(userEmailId);
			}
			MailSetupTO mailSetupTo = new MailSetupTO();
			mailSetupTo = fetchReceiverDetails(requestTo.getServiceId(), requestTo.getId());
			if (!"".equalsIgnoreCase(mailSetupTo.getReceiverTo())) {
				String recieverTo = mailSetupTo.getReceiverTo();
				String recieverToNew = recieverTo.trim();
				String[] emailArray = recieverToNew.split(",");
				userStrList1 = Arrays.asList(emailArray);
			}
			userToListFinal.addAll(userStrList);
			userToListFinal.addAll(userStrList1);
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationParameterDAOImpl : fetchActivitySoftMapDetail", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return userToListFinal;
	}
	
	@Override
	public List<String> fetchCcUsersListForMail(Long requestId) throws CMMException {
	
		Session session = null;
		List<String> userStrList = new ArrayList<String>(0);
		try {
			session = getSession();
			ServiceRequestTO requestTo = (ServiceRequestTO) getHibernateTemplate().find("from ServiceRequestTO where id =?", requestId).get(0);
			MailSetupTO mailSetup = new MailSetupTO();
			mailSetup = fetchReceiverDetails(requestTo.getServiceId(), requestTo.getId());
			if (!("".equalsIgnoreCase(mailSetup.getReceiverCc())) && (null != mailSetup.getReceiverCc())) {
				String recieverCc = mailSetup.getReceiverCc();
				String recieverCcNew = recieverCc.trim();
				String[] emailArray = recieverCcNew.split(",");
				userStrList = Arrays.asList(emailArray);
			}
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. EmailNotificationDAOImpl : fetchCcUsersListForMail", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return userStrList;
	}
	
	@Override
	public MailSetupTO fetchReceiverDetails(Long serviceId, Long requestId) throws CMMException {
	
		try {
			MailSetupTO mailSetup = new MailSetupTO();
			Long applicationId;
			Long clientId;
			List<Long> applicationIdMail;
			ServiceRequestTO requestTo = (ServiceRequestTO) getHibernateTemplate().find("from ServiceRequestTO where id =?", requestId).get(0);
			if (requestTo.getServiceId().equals(CMMConstants.Framework.Service.CREATE_MULTIPLE_ENVIRONMENT_SERVICE_ID)) {
				applicationIdMail = (List<Long>) getHibernateTemplate().find("select ea.applicationTO.id from EnvironmentApplicationTO ea, ServiceRequestTO s where s.environmentId = ea.environmentTO.id and s.id=?", requestTo.getId());
				clientId = (Long) getHibernateTemplate().findByNamedParam("select clientId from ApplicationTO where id in (:applicationIds) ", "applicationIds", applicationIdMail).get(0);
			} else {
				if (requestTo.getServiceId().equals(CMMConstants.Framework.Service.CREATE_ENVIRONMENT_SERVICE_ID)) {
					applicationId = (Long) getHibernateTemplate().find("select ea.applicationTO.id from EnvironmentApplicationTO ea, ServiceRequestTO s where s.environmentId = ea.environmentTO.id and s.id=?", requestTo.getId()).get(0);
				} else {
					applicationId = requestTo.getApplicationId();
				}
				clientId = (Long) getHibernateTemplate().find("select clientId from ApplicationTO where id =?", applicationId).get(0);
			}
			List<MailSetupTO> mailsetupTO = (List<MailSetupTO>) getHibernateTemplate().find("select distinct m from MailSetupTO m, MailSetupMappingTO ms where m.id = ms.mailSetupId and m.serviceId =? and ms.clientId=?", serviceId, clientId);
			if ((mailsetupTO != null) && !mailsetupTO.isEmpty()) {
				mailSetup = mailsetupTO.get(0);
			}
			return mailSetup;
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : fetchUsersListForReservationMail", dae);
		}
	}
	
	@Override
	public void updateMessageHistory(MsgHistoryTO msgHistory) throws CMMException {
	
		getHibernateTemplate().save(msgHistory);
	}
	
	@Override
	public ServiceTO fetchServiceName(long longValue) throws CMMException {
	
		List<ServiceTO> serviceTo = (List<ServiceTO>) getHibernateTemplate().find("from ServiceTO where id =? ", longValue);
		ServiceTO service = new ServiceTO();
		if (!serviceTo.isEmpty()) {
			service = serviceTo.get(0);
		}
		return service;
	}
	
	@Override
	public List fetchUsersListForReservationMail(Long applicationIds) throws CMMException {
	
		List<UserTO> users = new ArrayList<UserTO>(0);
		List<UserTO> userToList = new ArrayList<UserTO>(0);
		Session session = null;
		List<String> userStrList = new ArrayList<String>(0);
		List<String> userStrList1 = new ArrayList<String>(0);
		List<String> userStrListFinal = new ArrayList<String>(0);
		List<Long> applicationIdMail = new ArrayList<Long>(0);
		List<String> userToListFinal = new ArrayList<String>(0);
		try {
			session = getSession();
			MailSetupTO mailSetup = new MailSetupTO();
			Long clientId = (Long) getHibernateTemplate().find("select clientId from ApplicationTO where id =?", applicationIds).get(0);
			List<MailSetupTO> mailsetupTO = (List<MailSetupTO>) getHibernateTemplate().find("select distinct m from MailSetupTO m , MailSetupMappingTO ms where m.id = ms.mailSetupId and m.serviceId =? and ms.clientId=?", CMMConstants.Framework.Service.MAKE_RESERVATION_SERVICE, clientId);
			if ((mailsetupTO != null) && !mailsetupTO.isEmpty()) {
				mailSetup = mailsetupTO.get(0);
			} else {
				return userToListFinal;
			}
			List<MailSetupMappingTO> mailSetupMappingToList = (List<MailSetupMappingTO>) getHibernateTemplate().find("from MailSetupMappingTO where mailSetupId =?", mailSetup.getId());
			for (MailSetupMappingTO msm : mailSetupMappingToList) {
				if (msm.getProjectId() == null) {
					applicationIdMail = (List<Long>) getHibernateTemplate().find("select distinct a.id from ApplicationTO a, MailSetupMappingTO msm ,ClientTO c, MailSetupTO ms where a.clientId=msm.clientId and ms.id=msm.mailSetupId and ms.serviceId =? and msm.clientId =?", CMMConstants.Framework.Service.MAKE_RESERVATION_SERVICE, clientId);
				} else {
					Long projectId = (Long) getHibernateTemplate().find("select selectedProject from ApplicationTO where id =?", applicationIds).get(0);
					applicationIdMail = (List<Long>) getHibernateTemplate().find("select distinct a.id from ApplicationTO a, MailSetupMappingTO msm ,ClientTO c, ProjectsTO p, MailSetupTO ms where a.clientId=msm.clientId and a.selectedProject=msm.projectId and ms.id=msm.mailSetupId and ms.serviceId =? and msm.clientId=? and msm.projectId=?", CMMConstants.Framework.Service.MAKE_RESERVATION_SERVICE, clientId, projectId);
				}
			}
			applicationIdMail.add(applicationIds);
			String hql = "select distinct up.userTO from UserGroupDetailsTO  ugd , UserPrivilegeTO up, MailSetupTO ms , MailSetupRoleMappingTO msrm , ApplicationTO a, UserGroupTO ug where up.id=ugd.users.id and ms.id=msrm.mailSetupId and ms.serviceId=(:serviceId) and msrm.roleId = up.roleId and a.selectedUserGroup=ug.id and a.id in (:ApplicationId) and ug.id=ugd.userGroups.id and a.selectedUserGroup=ug.id and up.userTO.status = " + ACTIVE_USER_STATUS;
			Query q = session.createQuery(hql);
			q.setParameterList("ApplicationId", applicationIdMail);
			q.setParameter("serviceId", CMMConstants.Framework.Service.MAKE_RESERVATION_SERVICE);
			List<Object[]> obj = q.list();
			for (Object temp : obj) {
				userToList.add((UserTO) temp);
			}
			for (UserTO user : userToList) {
				boolean flag = false;
				for (UserTO user1 : users) {
					if (user.getId() == user1.getId()) {
						flag = true;
					}
				}
				if (flag == false) {
					users.add(user);
				}
			}
			for (UserTO user : users) {
				String userEmailId = user.getEmail();
				userStrList.add(userEmailId);
			}
			MailSetupTO mailSetup1 = new MailSetupTO();
			mailSetup1 = fetchReceiverDetailsForReservations(CMMConstants.Framework.Service.MAKE_RESERVATION_SERVICE, clientId);
			if (!"".equalsIgnoreCase(mailSetup1.getReceiverTo())) {
				String recieverTo = mailSetup1.getReceiverTo();
				String recieverToNew = recieverTo.trim();
				String[] emailArray = recieverToNew.split(",");
				userStrList1 = Arrays.asList(emailArray);
			}
			userStrListFinal.addAll(userStrList);
			userStrListFinal.addAll(userStrList1);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : fetchUsersListForReservationMail", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : fetchUsersListForReservationMail", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return userStrListFinal;
	}
	
	@Override
	public List fetchUsersListForReservationMailCc(Long applicationIds) throws CMMException {
	
		List<String> userStrList = new ArrayList<String>(0);
		MailSetupTO mailSetup = new MailSetupTO();
		Long clientId = (Long) getHibernateTemplate().find("select clientId from ApplicationTO where id =?", applicationIds).get(0);
		mailSetup = fetchReceiverDetailsForReservations(CMMConstants.Framework.Service.MAKE_RESERVATION_SERVICE, clientId);
		if (!"".equalsIgnoreCase(mailSetup.getReceiverCc())) {
			String recieverCc = mailSetup.getReceiverCc();
			String recieverCcNew = recieverCc.trim();
			String[] emailArray = recieverCcNew.split(",");
			userStrList = Arrays.asList(emailArray);
		}
		return userStrList;
	}
	
	public MailSetupTO fetchReceiverDetailsForReservations(Long serviceId, Long clientId) throws CMMException {
	
		MailSetupTO mailSetup = new MailSetupTO();
		List<MailSetupTO> mailsetupTO = (List<MailSetupTO>) getHibernateTemplate().find("select m from MailSetupTO m, MailSetupMappingTO ms where m.id = ms.mailSetupId and m.serviceId =? and ms.clientId=?", serviceId, clientId);
		if ((mailsetupTO != null) && !mailsetupTO.isEmpty()) {
			mailSetup = mailsetupTO.get(0);
		}
		return mailSetup;
	}
	
	@Override
	public List<String> fetchUsersListToMailForEnvironment(Long envId) throws CMMException {
	
		List<UserTO> users = new ArrayList<UserTO>(0);
		List<UserTO> userToList = new ArrayList<UserTO>(0);
		List<Long> applicationIds = new ArrayList<Long>(0);
		Session session = null;
		List<String> userStrList = new ArrayList<String>(0);
		try {
			session = getSession();
			applicationIds = (List<Long>) getHibernateTemplate().find("select applicationTO.id from EnvironmentApplicationTO where environmentTO.id =?", envId);
			String hql = "select distinct up.userTO from UserGroupDetailsTO  ugd , UserPrivilegeTO up , ApplicationTO a, UserGroupTO ug where up.id=ugd.users.id and a.selectedUserGroup=ug.id and a.id in (:ApplicationId) and ug.id=ugd.userGroups.id and a.selectedUserGroup=ug.id";
			Query q = session.createQuery(hql);
			q.setParameterList("ApplicationId", applicationIds);
			List<Object[]> obj = q.list();
			for (Object temp : obj) {
				userToList.add((UserTO) temp);
			}
			for (UserTO user : userToList) {
				boolean flag = false;
				for (UserTO user1 : users) {
					if (user.getId() == user1.getId()) {
						flag = true;
					}
				}
				if (flag == false) {
					users.add(user);
				}
			}
			for (UserTO user : users) {
				String userEmailId = user.getEmail();
				userStrList.add(userEmailId);
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. EmailNotificationDAOImpl : fetchUsersListToMailForEnvironment", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. EmailNotificationDAOImpl : fetchUsersListToMailForEnvironment", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return userStrList;
	}
	
	@Override
	public ServiceRequestTO fetchServiceDetailsMail(Long requestId) throws CMMException {
	
		try {
			return (ServiceRequestTO) getHibernateTemplate().find("from ServiceRequestTO where id =?", requestId).get(0);
		} catch (Exception he) {
			logger.error(he);
			throw new CMMException("Problem encountered. EmailNotificationDAOImpl : fetchUsersListToMailForEnvironment", he);
		}
	}
	
	@Override
	public List<ServiceRequestHistoryTO> fetchServiceMessages(Long serviceRequestId) throws CMMException {
	
		return (List<ServiceRequestHistoryTO>) getHibernateTemplate().find("from ServiceRequestHistoryTO where RequestId =?", serviceRequestId);
	}
	
	@Override
	public List<ServiceMailTO> fetchServiceMessage() throws CMMException {
	
		return (List<ServiceMailTO>) getHibernateTemplate().find("from ServiceMailTO");
	}
	
	public List<BusinessUnitTO> fetchBusinessUnit(Long selectedService) throws CMMException {
	
		try {
			List<BusinessUnitTO> clientTOList = new ArrayList<BusinessUnitTO>();
			List<Long> serviceClientIds = (List<Long>) getHibernateTemplate().find("select distinct clientId from ServiceClientTO sc where sc.serviceTO.id =? ", selectedService);
			clientTOList = (List<BusinessUnitTO>) getHibernateTemplate().findByNamedParam("from BusinessUnitTO c where  c.status=" + CMMConstants.Framework.Entity.BUSINESS_ACTIVE + "and c.clientId in (:clientIds) ", "clientIds", serviceClientIds);
			return clientTOList;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl:searchPolicy.", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl:searchPolicy.", he);
		}
	}
	
	@Override
	public List<EmailNotificationTO> searchEmail(EmailNotificationTO emailTO, List<Long> clientIdlist) throws CMMException {
	
		Session session = null;
		session = getSession();
		boolean whereSet = false;
		String Query = "";
		String s = "";
		String strInnerQuery = "";
		try {
			session = getSession();
			if (clientIdlist != null) {
				for (Long clientId : clientIdlist) {
					strInnerQuery = strInnerQuery + "," + clientId.toString();
				}
			}
			if ((strInnerQuery != "") && !strInnerQuery.isEmpty()) {
				s = strInnerQuery.substring(1, strInnerQuery.length());
			}
			List<EmailNotificationTO> emailList = new ArrayList<EmailNotificationTO>();
			Long serviceId = emailTO.getSelectedService();
			if ((emailTO.getSelectedBUId() == 0) || (emailTO.getSelectedBUId() < 0L) || "0".equalsIgnoreCase(s)) {
				Query = "select Distinct s.name, c.name, r.name, m.action, p.name, m.id, ms.clientId  from MailSetupTO m,  MailSetupRoleMappingTO mr, RoleTO r, ServiceTO s, MailSetupMappingTO ms  left join ms.businessUnitTO c left join ms.projectsTo p where  m.id = mr.mailSetupId and  m.id = ms.mailSetupId  and mr.roleId = r.id  and m.serviceId = s.id ";
				if ((emailTO.getSelectedBUId() != null) && (emailTO.getSelectedBUId() > 0L) && (emailTO.getSelectedProjectId() == 0L)) {
					if (whereSet) {
						Query = Query + " and ms.clientId = " + emailTO.getSelectedBUId();
					} else {
						Query = Query + " and ms.clientId = " + emailTO.getSelectedBUId();
						whereSet = true;
					}
				}
				if ((emailTO.getSelectedProjectId() != null) && (emailTO.getSelectedProjectId() > 0L)) {
					if (whereSet) {
						Query = Query + " and ms.projectId = " + emailTO.getSelectedProjectId();
					} else {
						Query = Query + " and ms.projectId = " + emailTO.getSelectedProjectId();
						whereSet = true;
					}
				}
				if ((emailTO.getSelectedService() != null) && (emailTO.getSelectedService() > 0L)) {
					if (whereSet) {
						Query = Query + " and m.serviceId = " + serviceId;
					} else {
						Query = Query + " and m.serviceId = " + serviceId;
						whereSet = true;
					}
				}
				if ((emailTO.getSelectedRole() != null) && (emailTO.getSelectedRole() > 0L)) {
					if (whereSet) {
						Query = Query + " and mr.roleId = " + emailTO.getSelectedRole();
					} else {
						Query = Query + " and mr.roleId = " + emailTO.getSelectedRole();
						whereSet = true;
					}
				}
			} else {
				Query = "select Distinct s.name, c.name, r.name, m.action, p.name , m.id, ms.clientId  from MailSetupTO m,  MailSetupRoleMappingTO mr, RoleTO r, ServiceTO s, MailSetupMappingTO ms  left join ms.businessUnitTO c left join ms.projectsTo p where  m.id = mr.mailSetupId and  m.id = ms.mailSetupId  and mr.roleId = r.id  and m.serviceId = s.id  and c.clientId in (" + s + ")";
				if ((emailTO.getSelectedBUId() != null) && (emailTO.getSelectedBUId() > 0L) && (emailTO.getSelectedProjectId() == 0L)) {
					if (whereSet) {
						Query = Query + " and ms.clientId = " + emailTO.getSelectedBUId();
					} else {
						Query = Query + " and ms.clientId = " + emailTO.getSelectedBUId();
						whereSet = true;
					}
				}
				if ((emailTO.getSelectedProjectId() != null) && (emailTO.getSelectedProjectId() > 0L)) {
					if (whereSet) {
						Query = Query + " and ms.projectId = " + emailTO.getSelectedProjectId();
					} else {
						Query = Query + " and ms.projectId = " + emailTO.getSelectedProjectId();
						whereSet = true;
					}
				}
				if ((emailTO.getSelectedService() != null) && (emailTO.getSelectedService() > 0L)) {
					if (whereSet) {
						Query = Query + " and m.serviceId = " + serviceId;
					} else {
						Query = Query + " and m.serviceId = " + serviceId;
						whereSet = true;
					}
				}
				if ((emailTO.getSelectedRole() != null) && (emailTO.getSelectedRole() > 0L)) {
					if (whereSet) {
						Query = Query + " and mr.roleId = " + emailTO.getSelectedRole();
					} else {
						Query = Query + " and mr.roleId = " + emailTO.getSelectedRole();
						whereSet = true;
					}
				}
			}
			Query = Query + " group by ms.clientId, m.serviceId ";
			Query q = session.createQuery(Query);
			List<Object[]> searchList = (List<Object[]>) getHibernateTemplate().find(Query);
			q.setFirstResult(emailTO.getFirstResult());
			q.setMaxResults(emailTO.getTableSize());
			for (Object[] temp : searchList) {
				EmailNotificationTO emailNotifications = new EmailNotificationTO();
				emailNotifications.setServiceName(temp[0].toString());
				emailNotifications.setBuName(temp[1].toString());
				if (temp[2] == null) {
					emailNotifications.setRoleCount("Zero");
				} else {
					emailNotifications.setRoleCount("One");
					emailNotifications.setRoleName(temp[2].toString());
				}
				if (temp[3] == null) {
					emailNotifications.setActionExist("Zero");
				} else {
					emailNotifications.setActionExist("One");
					emailNotifications.setActionName(temp[3].toString());
				}
				if (temp[4] == null) {
					emailNotifications.setProjectCount("Zero");
				} else {
					emailNotifications.setProjectCount("One");
					emailNotifications.setProjectName(temp[4].toString());
				}
				emailNotifications.setSelectedId((Long) temp[5]);
				emailNotifications.setSelectedClientId((Long) temp[6]);
				emailList.add(emailNotifications);
			}
			return emailList;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl:searchPolicy.", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl:searchPolicy.", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public boolean editEmailNotificationDetails(EmailNotificationTO emailTO) throws CMMException {
	
		try {
			Long selectedBuList = emailTO.getSelectedBuLists().get(0);
			MailSetupTO mst = (MailSetupTO) getHibernateTemplate().find("select distinct m from MailSetupTO m, MailSetupMappingTO ms where m.id = ms.mailSetupId and m.serviceId =? and ms.clientId=?", emailTO.getSelectedService(), selectedBuList).get(0);
			if (mst != null) {
				List<MailSetupRoleMappingTO> mailsetupRoleMapToList = (List<MailSetupRoleMappingTO>) getHibernateTemplate().find("from MailSetupRoleMappingTO where mailSetupId =? ", mst.getId());
				List<MailSetupMappingTO> mailsetupMappingToList = (List<MailSetupMappingTO>) getHibernateTemplate().find("from MailSetupMappingTO where mailSetupId =? and clientId=?", mst.getId(), selectedBuList);
				for (MailSetupRoleMappingTO roleMap : mailsetupRoleMapToList) {
					getHibernateTemplate().delete(roleMap);
				}
				for (MailSetupMappingTO setupMap : mailsetupMappingToList) {
					getHibernateTemplate().delete(setupMap);
				}
			}
			MailSetupTO mailSetuoTo = new MailSetupTO();
			if (mst != null) {
				mailSetuoTo.setId(mst.getId());
				mailSetuoTo.setServiceId(emailTO.getSelectedService());
				mailSetuoTo.setReceiverTo(emailTO.getDestinationName());
				mailSetuoTo.setReceiverCc(emailTO.getCcName());
				mailSetuoTo.setMessage(emailTO.getMessage());
				if (emailTO.getSelectedAction().equalsIgnoreCase(CMMConstants.Framework.Action.SUCCESS)) {
					mailSetuoTo.setAction(CMMConstants.Framework.Action.SUCCESS_FLAG);
				}
				if (emailTO.getSelectedAction().equalsIgnoreCase(CMMConstants.Framework.Action.FAILURE)) {
					mailSetuoTo.setAction(CMMConstants.Framework.Action.FAILURE_FLAG);
				}
				if (emailTO.getSelectedAction().equalsIgnoreCase(CMMConstants.Framework.Action.BOTH)) {
					mailSetuoTo.setAction(CMMConstants.Framework.Action.BOTH_FLAG);
				}
				getHibernateTemplate().update(mailSetuoTo);
				for (Long role : emailTO.getDefinedRoles()) {
					MailSetupRoleMappingTO mailSetupRoleMap = new MailSetupRoleMappingTO();
					mailSetupRoleMap.setRoleId(role);
					mailSetupRoleMap.setMailSetupId(mst.getId());
					getHibernateTemplate().save(mailSetupRoleMap);
				}
				if (emailTO.getSelectedProjectList() != null) {
					for (Long projectId : emailTO.getSelectedProjectList()) {
						List<ProjectsTO> projects = (List<ProjectsTO>) getHibernateTemplate().find("from ProjectsTO where id=?", projectId);
						if (projects.size() > 0L) {
							MailSetupMappingTO mailSetupMapping = new MailSetupMappingTO();
							ProjectsTO project = new ProjectsTO();
							project = projects.get(0);
							mailSetupMapping.setClientId(project.getClientId());
							mailSetupMapping.setProjectId(project.getId());
							mailSetupMapping.setMailSetupId(mst.getId());
							getHibernateTemplate().save(mailSetupMapping);
						}
					}
				} else {
					for (Long buId : emailTO.getSelectedBuLists()) {
						MailSetupMappingTO mailSetupMapping = new MailSetupMappingTO();
						mailSetupMapping.setClientId(buId);
						mailSetupMapping.setMailSetupId(mst.getId());
						getHibernateTemplate().save(mailSetupMapping);
					}
				}
			}
		} catch (ConstraintViolationException ce) {
			logger.error(ce);
			throw new CMMException("Template Name already exists.", ce);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. BareMetalDAOImpl:editTemplate", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. BareMetalDAOImpl:editTemplate", he);
		}
		return true;
	}
	
	@Override
	public List<ServiceTO> fetchService(Long selectedProjectId) throws CMMException {
	
		try {
			List<ServiceTO> servcieTOList = new ArrayList<ServiceTO>();
			Long serviceId = 0L;
			List<Long> serviceClientIds = (List<Long>) getHibernateTemplate().find("select distinct ms.serviceId from MailSetupMappingTO msm , MailSetupTO ms where  ms.id=msm.mailSetupId and msm.projectId =?", selectedProjectId);
			if ((serviceClientIds != null) && !serviceClientIds.isEmpty()) {
				serviceId = serviceClientIds.get(0);
			}
			servcieTOList = (List<ServiceTO>) getHibernateTemplate().find("from ServiceTO s where  s.status=" + CMMConstants.Framework.Entity.SERVICES_ACTIVE + "and s.id =?", serviceId);
			return servcieTOList;
		} catch (ConstraintViolationException ce) {
			logger.error(ce);
			throw new CMMException("Template Name already exists.", ce);
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. BareMetalDAOImpl:editTemplate", dae);
		}
	}
	
	@Override
	public List<ProjectsTO> searchAllProjectsForEmail(Long selectedId, Long selectedClientId) throws CMMException {
	
		try {
			List<Object[]> projectList = (List<Object[]>) getHibernateTemplate().find("select distinct ms.projectId from  MailSetupMappingTO ms where ms.mailSetupId=? and ms.clientId=?", selectedId, selectedClientId);
			return (List<ProjectsTO>) getHibernateTemplate().findByNamedParam("from ProjectsTO p where  p.id in (:projectIds) ", "projectIds", projectList);
		} catch (ConstraintViolationException ce) {
			logger.error(ce);
			throw new CMMException("Template Name already exists.", ce);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. BareMetalDAOImpl:editTemplate", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. BareMetalDAOImpl:editTemplate", he);
		}
	}
	
	@Override
	public List<RoleTO> searchAllRolesForEmail(Long selectedId) throws CMMException {
	
		try {
			List<Long> roleList = (List<Long>) getHibernateTemplate().find("select distinct mr.roleId from  MailSetupRoleMappingTO mr where mr.mailSetupId=?", selectedId);
			return (List<RoleTO>) getHibernateTemplate().findByNamedParam("from RoleTO r where  r.id in (:roleIds) ", "roleIds", roleList);
		} catch (ConstraintViolationException ce) {
			logger.error(ce);
			throw new CMMException("Template Name already exists.", ce);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. BareMetalDAOImpl:editTemplate", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. BareMetalDAOImpl:editTemplate", he);
		}
	}
	
	@Override
	public List<ProjectsTO> fetchProjectListForMultipleBU(List<Long> selectedBus) throws CMMException {
	
		List<ProjectsTO> projectList = new ArrayList<ProjectsTO>(0);
		try {
			for (Long clientId : selectedBus) {
				List<ProjectsTO> projects = new ArrayList<ProjectsTO>(0);
				projects = (List<ProjectsTO>) getHibernateTemplate().find("from ProjectsTO where clientId=? and status=?", clientId, CMMConstants.Framework.Entity.PROJECT_STATUS_EXISTING);
				for (ProjectsTO project : projects) {
					projectList.add(project);
				}
			}
			return projectList;
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getAllProjects", dae);
		}
	}
	
	@Override
	public MailSetupTO fetchReceiverDetailsForReservation(long makeReservationService, Long applicationId) throws CMMException {
	
		MailSetupTO mailSetup = new MailSetupTO();
		Long clientId = (Long) getHibernateTemplate().find("select clientId from ApplicationTO where id =?", applicationId).get(0);
		List<MailSetupTO> mailsetupTO = (List<MailSetupTO>) getHibernateTemplate().find("select m from MailSetupTO m , MailSetupMappingTO ms where m.id = ms.mailSetupId and m.serviceId =? and ms.clientId=?", makeReservationService, clientId);
		if ((mailsetupTO != null) && !mailsetupTO.isEmpty()) {
			mailSetup = mailsetupTO.get(0);
		}
		return mailSetup;
	}
	
	@Override
	public boolean checkBuConfiguration(EmailNotificationTO emailTO) throws CMMException {
	
		try {
			List<Long> selectedBuList = emailTO.getSelectedBuList();
			List<MailSetupTO> mailsetupToList = (List<MailSetupTO>) getHibernateTemplate().findByNamedParam("select m from MailSetupTO m , MailSetupMappingTO ms where m.id = ms.mailSetupId and m.serviceId =" + emailTO.getSelectedService() + " and ms.clientId in (:clientIds)", "clientIds", selectedBuList);
			if (mailsetupToList.isEmpty()) {
				return true;
			}
			return false;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getAllProjects", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.  ApplicationDAOImpl : getAllProjects", he);
		}
	}
	
	@Override
	public List<UserTO> fetchCurrentOwnerName(Long currentOwnerId) throws CMMException {
	
		try {
			return (List<UserTO>) getHibernateTemplate().find("from UserTO where id =? ", currentOwnerId);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getAllProjects", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.  ApplicationDAOImpl : getAllProjects", he);
		}
	}
	
	@Override
	public List<UserTO> fetchCurrentOwner(Long resId) throws CMMException {
	
		List<UserTO> userTo = new ArrayList<UserTO>();
		Long currentOwnerId = (Long) getHibernateTemplate().find("select currentOwner from WorkflowCurrentTO where entity_id =?", resId).get(0);
		if (currentOwnerId != null) {
			userTo = (List<UserTO>) getHibernateTemplate().find("select distinct u from UserTO u where u.id =? ", currentOwnerId);
		}
		return userTo;
	}
}