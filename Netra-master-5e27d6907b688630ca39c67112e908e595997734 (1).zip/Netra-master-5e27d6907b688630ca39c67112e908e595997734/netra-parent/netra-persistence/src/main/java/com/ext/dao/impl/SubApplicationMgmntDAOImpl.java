package com.ext.dao.impl;

import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.SubApplicationMgmntDAO;
import com.framework.exception.CMMException;
import com.framework.to.ApplicationTO;
import com.framework.to.EnvironmentTO;
import com.framework.to.SubAppTO;

public class SubApplicationMgmntDAOImpl extends HibernateDaoSupport implements SubApplicationMgmntDAO {
	
	private static final Logger LOG = Logger.getLogger(SubApplicationMgmntDAOImpl.class);
	
	@Override
	public List<Object> getapplicationNames() throws CMMException {
	
		try {
			StringBuilder query = new StringBuilder("select a.id,a.appName,b.id,a.projectTO ");
			query.append("from ApplicationTO a inner join a.businessUnitTO b");
			return (List<Object>) getHibernateTemplate().find(query.toString());
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.SubApplicationMgmntDAOImpl:getapplicationNames", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.SubApplicationMgmntDAOImpl:getapplicationNames", he);
		}
	}
	
	@Override
	public List<ApplicationTO> getAllSubApps(Long appid) throws CMMException {
	
		try {
			StringBuilder queryForCid = new StringBuilder("select a.businessUnitTO.id from ApplicationTO a where a.id=?");
			Long dbCid = (Long) getHibernateTemplate().find(queryForCid.toString(), appid).get(0);
			StringBuilder query = new StringBuilder("from ApplicationTO a  where a.id<>? and a.businessUnitTO.id=?");
			return (List<ApplicationTO>) getHibernateTemplate().find(query.toString(), appid, dbCid);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.SubApplicationMgmntDAOImpl:getAllSubApps", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.SubApplicationMgmntDAOImpl:getAllSubApps", he);
		}
	}
	
	@Override
	public List<ApplicationTO> getAllSubAppsRight(Long appid) throws CMMException {
	
		List<ApplicationTO> subApplicationList = new ArrayList<ApplicationTO>();
		try {
			StringBuilder query = new StringBuilder("select b.childAppId from ApplicationTO a inner join a.applicationTreesForParentAppId b where a.id=? ");
			List<Object[]> applicationList = (List<Object[]>) getHibernateTemplate().find(query.toString(), appid);
			if ((applicationList != null) && !applicationList.isEmpty()) {
				String hql = "from ApplicationTO where id in (:listParam)";
				String[] params = { "listParam" };
				Object[] values = { applicationList };
				subApplicationList = (List<ApplicationTO>) getHibernateTemplate().findByNamedParam(hql, params, values);
			}
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.SubApplicationMgmntDAOImpl:getAllSubAppsRight", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.SubApplicationMgmntDAOImpl:getAllSubAppsRight", he);
		}
		return subApplicationList;
	}
	
	@Override
	public void subAppUpdate(SubAppTO subAppTO) throws CMMException {
	
		try {
			ApplicationTO temp = (ApplicationTO) getHibernateTemplate().find("from ApplicationTO where id=?", subAppTO.getId()).get(0);
			temp.getApplicationTreesForParentAppId().clear();
			for (Long id : subAppTO.getSelectedSubAppRight()) {
				SubAppTO to = new SubAppTO();
				to.setChildAppId(id);
				to.setModifiedbyId(subAppTO.getModifiedbyId());
				to.setModifiedDate(subAppTO.getModifiedDate());
				to.setCreatedById(subAppTO.getCreatedById());
				to.setCreatedDate(subAppTO.getCreatedDate());
				ApplicationTO appto = new ApplicationTO();
				appto.setId(subAppTO.getId());
				appto.getApplicationTreesForParentAppId().add(to);
				to.setApplicationsByParentAppId(appto);
				temp.getApplicationTreesForParentAppId().add(to);
			}
			getHibernateTemplate().update(temp);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.SubApplicationMgmntDAOImpl:subAppUpdate", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.SubApplicationMgmntDAOImpl:subAppUpdate", he);
		}
	}
	
	@Override
	public List<EnvironmentTO> getEnvs(Long appId) throws CMMException {
	
		try {
			return (List<EnvironmentTO>) getHibernateTemplate().find("from EnvironmentTO where applicationId=?", appId);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.SubApplicationMgmntDAOImpl:getEnvs", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.SubApplicationMgmntDAOImpl:getEnvs", he);
		}
	}
}
