package com.ext.dao.impl;

import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.util.StringUtils;
import com.ext.dao.MonitoringDockerDAO;
import com.framework.common.CMMConstants;
import com.framework.exception.CMMException;
import com.framework.to.DockerServerConfigurationTO;
import com.framework.to.EnvironmentDockerTO;
import com.framework.to.EnvironmentTO;

/**
 * @author TCS
 */
public class MonitoringDockerDAOImpl extends HibernateDaoSupport implements MonitoringDockerDAO {
	
	private static final Logger LOG = Logger.getLogger(MonitoringDockerDAOImpl.class);
	
	@Override
	public List<EnvironmentTO> searchEnv(EnvironmentTO environmentTO) throws CMMException {
	
		Session session = null;
		List<EnvironmentTO> envList = new ArrayList<EnvironmentTO>();
		String query = null;
		try {
			session = getSession();
			long invalidStatus = CMMConstants.Framework.Entity.ENVIRONMENT_STATUS_INVALID;
			query = "select distinct e.id,e.ENVIRONMENT_NAME,s.STATUS_DESC from environments e , environment_application m , status s, environment_docker_details d where m.environment_id =e.id  and e.STATUS = s.id and e.STATUS != " + invalidStatus + " and d.ENVIRONMENT_ID = e.id and d.CONTAINER_IP IS NOT NULL and d.CONTAINER_ID IS NOT NULL";
			if (StringUtils.hasText(environmentTO.getEnvironmentName())) {
				query = query + " and e.ENVIRONMENT_NAME  like'" + environmentTO.getEnvironmentName() + "%'";
			}
			query = query + " ORDER BY e.ID ";
			Query q = session.createSQLQuery(query);
			List<Object[]> objList = q.list();
			for (Object[] temp : objList) {
				EnvironmentTO envObj = new EnvironmentTO();
				envObj.setId(((Integer) temp[0]).longValue());
				envObj.setEnvironmentName((String) temp[1]);
				envObj.setEnvStatus((String) temp[2]);
				envList.add(envObj);
			}
			return envList;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.MonitoringDockerDAOImpl:searchEnv.", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.MonitoringDockerDAOImpl:searchEnv.", he);
		}
	}
	
	@Override
	public List<EnvironmentDockerTO> searchDockerDetails(EnvironmentTO environmentTO) throws CMMException {
	
		Session session = null;
		List<EnvironmentDockerTO> envList = new ArrayList<EnvironmentDockerTO>();
		String query = null;
		try {
			session = getSession();
			query = "select distinct e.id,d.CONTAINER_IP,d.CONTAINER_ID from environments e , environment_docker_details d where d.ENVIRONMENT_ID = e.id and d.CONTAINER_IP IS NOT NULL and d.CONTAINER_ID IS NOT NULL";
			if (StringUtils.hasText(environmentTO.getEnvironmentName())) {
				query = query + " and e.ENVIRONMENT_NAME  like'" + environmentTO.getEnvironmentName() + "%'";
			}
			query = query + " ORDER BY e.ID ";
			Query q = session.createSQLQuery(query);
			List<Object[]> objList = q.list();
			for (Object[] temp : objList) {
				EnvironmentDockerTO envObj = new EnvironmentDockerTO();
				envObj.setEnvId(((Integer) temp[0]).longValue());
				envObj.setContainerIp((String) temp[1]);
				envObj.setContainerID((String) temp[2]);
				envList.add(envObj);
			}
			return envList;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.MonitoringDockerDAOImpl:searchEnv.", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.MonitoringDockerDAOImpl:searchEnv.", he);
		}
	}
	
	@Override
	public EnvironmentTO searchEnvDocker(String containerID) throws CMMException {
	
		try {
			EnvironmentDockerTO envDock = new EnvironmentDockerTO();
			EnvironmentTO env = new EnvironmentTO();
			envDock = (EnvironmentDockerTO) getHibernateTemplate().find("from EnvironmentDockerTO where containerID=?", containerID).get(0);
			env = (EnvironmentTO) getHibernateTemplate().find("from EnvironmentTO where id=?", envDock.getEnvId()).get(0);
			return env;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.MonitoringDockerDAOImpl:searchEnvDocker.", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.MonitoringDockerDAOImpl:searchEnvDocker.", he);
		}
	}
	
	@Override
	public List<DockerServerConfigurationTO> dockerServerConf(String containerID) throws CMMException {
	
		Session session = null;
		String query = null;
		try {
			session = getSession();
			List<DockerServerConfigurationTO> dockServer = new ArrayList<DockerServerConfigurationTO>();
			query = "select distinct d.username,d.password,d.server_ip,d.port from docker_server_config d , environment_docker_details e, application_profile_docker a where e.CONTAINER_ID = \"" + containerID + "\" and a.PROFILE_ID = e.PROFILE_ID and d.server_ip = a.SERVER_IP";
			Query q = session.createSQLQuery(query);
			List<Object[]> objList = q.list();
			for (Object[] temp : objList) {
				DockerServerConfigurationTO dock = new DockerServerConfigurationTO();
				dock.setUsername((String) temp[0]);
				dock.setPassword((String) temp[1]);
				dock.setServerIp((String) temp[2]);
				dock.setPort(((Integer) temp[3]).longValue());
				dockServer.add(dock);
			}
			return dockServer;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.MonitoringDockerDAOImpl:dockerServerConf.", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.MonitoringDockerDAOImpl:dockerServerConf.", he);
		}
	}
	
	@Override
	public String searchEnvName(Long envID) throws CMMException {
	
		try {
			EnvironmentTO env = new EnvironmentTO();
			env = (EnvironmentTO) getHibernateTemplate().find("from EnvironmentTO where id=?", envID).get(0);
			return env.getEnvironmentName();
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.MonitoringDockerDAOImpl:searchEnvDocker.", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.MonitoringDockerDAOImpl:searchEnvDocker.", he);
		}
	}
}