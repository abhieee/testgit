package com.ext.dao.impl;

import java.util.ArrayList;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.DataMaskingToolsDao;
import com.framework.exception.CMMException;
import com.framework.to.DataMaskingConfigTO;
import com.framework.to.DataMaskingToolTO;
import com.framework.to.TestingToolTO;

public class DataMaskingToolsDaoImpl extends HibernateDaoSupport implements DataMaskingToolsDao {
	
	@Override
	public List<DataMaskingConfigTO> getAllDataMaskingToolsConfigDetailsForApp(Long applicationId, Long projectId, Long buId, String toolName, Long searchCount, int firstResult, int tableSize, List<Long> buList) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			Criteria criteria = session.createCriteria(DataMaskingConfigTO.class);
			if ((applicationId != null) && (applicationId > 0)) {
				criteria.add(Restrictions.eq("selectedApplicationId", applicationId));
			}
			if ((projectId != null) && (projectId > 0)) {
				criteria.add(Restrictions.eq("selectedProjectId", projectId));
			}
			if ((buId != null) && (buId > 0)) {
				criteria.add(Restrictions.eq("selectedBUId", buId));
			}
			if (toolName != null) {
				criteria.add(Restrictions.like("selectedDataMaskToolName", toolName));
			}
			List<DataMaskingConfigTO> dataMaskToolsList = new ArrayList<DataMaskingConfigTO>();
			if (buId == null) {
				if (buList.get(0) == 0L) {
					String query = "select s from DataMaskingConfigTO s where s.selectedDataMaskToolName=:toolName";
					if (searchCount == 0) {
						Query q = session.createQuery(query);
						q.setParameter("toolName", toolName);
						dataMaskToolsList = q.list();
					} else {
						criteria.setFirstResult(firstResult);
						criteria.setMaxResults(tableSize);
						Query q = session.createQuery(query);
						dataMaskToolsList = q.list();
					}
				} else {
					String query = "select d from DataMaskingConfigTO d where d.selectedDataMaskToolName=:toolName and d.selectedBUId in(:buList)";
					if (searchCount == 0) {
						Query q = session.createQuery(query);
						q.setParameterList("buList", buList);
						q.setParameter("toolName", toolName);
						dataMaskToolsList = q.list();
					} else {
						criteria.setFirstResult(firstResult);
						criteria.setMaxResults(tableSize);
						Query q = session.createQuery(query);
						q.setParameterList("buList", buList);
						dataMaskToolsList = q.list();
					}
				}
			}
			if ((buId != null) && (buId > 0)) {
				if (searchCount == 0) {
					dataMaskToolsList = criteria.list();
				} else {
					criteria.setFirstResult(firstResult);
					criteria.setMaxResults(tableSize);
					dataMaskToolsList = criteria.list();
				}
			}
			List<DataMaskingConfigTO> dataMaskToolsConfigList = new ArrayList<DataMaskingConfigTO>();
			for (DataMaskingConfigTO dataMaskToolsTO : dataMaskToolsList) {
				if ((dataMaskToolsTO.getApplicationTO() != null) && (dataMaskToolsTO.getApplicationTO().getAppName() != null)) {
					dataMaskToolsTO.setApplicationName(dataMaskToolsTO.getApplicationTO().getAppName());
				}
				if ((dataMaskToolsTO.getProjectsTO() != null) && (dataMaskToolsTO.getProjectsTO().getName() != null)) {
					dataMaskToolsTO.setProjectName(dataMaskToolsTO.getProjectsTO().getName());
				}
				if ((dataMaskToolsTO.getClientTO() != null) && (dataMaskToolsTO.getClientTO().getName() != null)) {
					dataMaskToolsTO.setBuName(dataMaskToolsTO.getClientTO().getName());
				}
				if (dataMaskToolsTO.getSelectedDataMaskToolName() != null) {
					dataMaskToolsTO.setSelectedDataMaskToolName(dataMaskToolsTO.getSelectedDataMaskToolName());
				}
				dataMaskToolsConfigList.add(dataMaskToolsTO);
			}
			if ((dataMaskToolsList == null) || (dataMaskToolsList.size() < 0)) {
				throw new CMMException("No Testing Tools configuration found for application");
			}
			return dataMaskToolsConfigList;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.TestingToolsDaoImpl:getAllTestingToolsConfigDetailsForApp", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.TestingToolsDaoImpl:getAllTestingToolsConfigDetailsForApp", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public boolean saveDataMaskingToolConfigDetails(DataMaskingConfigTO dataMaskToolsTO) throws CMMException {
	
		Session session = null;
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(DataMaskingConfigTO.class);
			if (dataMaskToolsTO.getSelectedBUId() != null) {
				criteria.add(Restrictions.eq("selectedBUId", dataMaskToolsTO.getSelectedBUId()));
			}
			if (dataMaskToolsTO.getSelectedProjectId() != null) {
				criteria.add(Restrictions.eq("selectedProjectId", dataMaskToolsTO.getSelectedProjectId()));
			} else {
				criteria.add(Restrictions.isNull("selectedProjectId"));
			}
			if (dataMaskToolsTO.getSelectedApplicationId() != null) {
				criteria.add(Restrictions.eq("selectedApplicationId", dataMaskToolsTO.getSelectedApplicationId()));
			} else {
				criteria.add(Restrictions.isNull("selectedApplicationId"));
			}
			if (dataMaskToolsTO.getSelectedDataMaskToolName() != null) {
				criteria.add(Restrictions.like("selectedDataMaskToolName", dataMaskToolsTO.getSelectedDataMaskToolName()));
			}
			List<DataMaskingConfigTO> tTList = (List<DataMaskingConfigTO>) getHibernateTemplate().findByCriteria(criteria);
			if (!tTList.isEmpty()) {
				return false;
			}
			Long dataMaskToolConfigId = (Long) getHibernateTemplate().save(dataMaskToolsTO);
			if ((dataMaskToolConfigId == null) || (dataMaskToolConfigId <= 0)) {
				throw new CMMException("Problem encountered.DataMaskingToolsDaoImpl:saveDataMaskingToolConfigDetails");
			}
			return true;
		} catch (DataIntegrityViolationException divE) {
			logger.error(divE);
			throw new CMMException("Problem encountered.DataMaskingToolsDaoImpl:saveDataMaskingToolConfigDetails", divE);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.DataMaskingToolsDaoImpl:saveDataMaskingToolConfigDetails", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public DataMaskingConfigTO getConfigDetailsById(Long dataMaskToolConfigId) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			List<DataMaskingConfigTO> dataMaskToolsConfigList = session.createCriteria(DataMaskingConfigTO.class).add(Restrictions.eq("id", dataMaskToolConfigId)).list();
			if ((dataMaskToolsConfigList == null) || (dataMaskToolsConfigList.size() < 0)) {
				throw new CMMException("No data masking tools details found for application");
			}
			return dataMaskToolsConfigList.get(0);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.TestingToolsDaoImpl:getConfigDetailsById", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.TestingToolsDaoImpl:getConfigDetailsById", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public boolean updateDataMaskingToolsConfigDetails(DataMaskingConfigTO dataMaskToolsTO) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			DataMaskingConfigTO dataMaskListTO_Old = getHibernateTemplate().get(DataMaskingConfigTO.class, dataMaskToolsTO.getId());
			dataMaskListTO_Old.setSelectedBUId(dataMaskToolsTO.getSelectedBUId());
			dataMaskListTO_Old.setSelectedProjectId(dataMaskToolsTO.getSelectedProjectId());
			dataMaskListTO_Old.setSelectedApplicationId(dataMaskToolsTO.getSelectedApplicationId());
			dataMaskListTO_Old.setSelectedDataMaskToolName(dataMaskToolsTO.getSelectedDataMaskToolName());
			dataMaskListTO_Old.setIp(dataMaskToolsTO.getIp());
			dataMaskListTO_Old.setOptimLocation(dataMaskToolsTO.getOptimLocation());
			getHibernateTemplate().update(dataMaskListTO_Old);
			return true;
		} catch (DataIntegrityViolationException divE) {
			logger.error("Problem encountered.DataMaskingToolsDaoImpl:updateDataMaskingToolsConfigDetails", divE);
			return false;
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.DataMaskingToolsDaoImpl:updateDataMaskingToolsConfigDetails", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<DataMaskingToolTO> getAllDataMaskingToolName() throws CMMException {
	
		try {
			return (List<DataMaskingToolTO>) getHibernateTemplate().find("from DataMaskingToolTO");
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.DataMaskingToolsDaoImpl : getAllDataMaskingToolName", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.DataMaskingToolsDaoImpl : getAllDataMaskingToolName", he);
		}
	}
	
	@Override
	public String getToolNameById(Long toolId) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			return (String) session.createCriteria(TestingToolTO.class).add(Restrictions.eq("id", toolId)).setProjection(Projections.property("name")).uniqueResult();
		} catch (DataAccessException dae) {
			throw new CMMException("Error in fetching toolName for toolId " + toolId, dae);
		} catch (HibernateException he) {
			throw new CMMException("Can not fetch data from database for toolName", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
}
