/**
 *
 */
package com.ext.dao.impl;

import java.util.List;
import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.PlatformMasterDAO;
import com.framework.exception.CMMException;
import com.framework.to.PlatformMasterTO;

/**
 * @author 460650
 */
public class PlatformMasterDAOImpl extends HibernateDaoSupport implements PlatformMasterDAO {
	
	private static final Logger LOG = Logger.getLogger(PlatformMasterDAOImpl.class);
	
	@Override
	public List<PlatformMasterTO> fetchAllPlatforms() throws CMMException {
	
		try {
			return (List<PlatformMasterTO>) getHibernateTemplate().find("from PlatformMasterTO");
		} catch (DataAccessException ex) {
			LOG.error("PlatformMasterDAOImpl:fetchAllPlatforms");
			throw new CMMException("Data can not be accessed from DB" + ex.getMessage(), ex);
		} catch (HibernateException e) {
			LOG.error("PlatformMasterDAOImpl:fetchAllPlatforms");
			throw new CMMException("DB Exception" + e.getMessage(), e);
		}
	}
}
