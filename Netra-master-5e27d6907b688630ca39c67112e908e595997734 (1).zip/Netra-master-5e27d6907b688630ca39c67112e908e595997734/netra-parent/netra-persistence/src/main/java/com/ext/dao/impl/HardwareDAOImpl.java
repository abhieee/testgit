package com.ext.dao.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.classic.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.hibernate.exception.ConstraintViolationException;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.HardwareDAO;
import com.framework.common.CMMConstants;
import com.framework.exception.CMMException;
import com.framework.to.BusinessUnit_InvTO;
import com.framework.to.CIServerTO;
import com.framework.to.HardwareTO;
import com.framework.to.ProvisionedMachinePhysicalTO;
import com.framework.to.ProvisionedMachineTO;
import com.framework.to.ProvisionedPlatformTO;
import com.framework.to.ServerTemplatePropertyTO;

/**
 * @author TCS
 */
public class HardwareDAOImpl extends HibernateDaoSupport implements HardwareDAO {
	
	private static final Logger LOGGER = Logger.getLogger(HardwareDAOImpl.class);
	
	@Override
	public void addHardware(ProvisionedMachineTO provisionedMachineTO, ProvisionedPlatformTO provisionedPlatformTO) throws CMMException {
	
		try {
			Long provisionedPlatformTemplateId = (Long) getHibernateTemplate().save(provisionedPlatformTO);
			provisionedMachineTO.setProvisionedPlatformTemplateId(provisionedPlatformTemplateId);
			ProvisionedMachinePhysicalTO physicalmachine = new ProvisionedMachinePhysicalTO();
			physicalmachine.setUsername(provisionedMachineTO.getUsername());
			physicalmachine.setPassword(provisionedMachineTO.getPassword());
			Long provisionedmachineId = (Long) getHibernateTemplate().save(provisionedMachineTO);
			physicalmachine.setProvisionedMachineId(provisionedmachineId);
			getHibernateTemplate().save(physicalmachine);
			for (ServerTemplatePropertyTO servertemplateproperty : provisionedMachineTO.getServerTemplateProperty()) {
				if (servertemplateproperty != null) {
					String pName, pValue;
					pName = servertemplateproperty.getPropertyName();
					pValue = servertemplateproperty.getPropertyValue();
					if ("".equals(pName) || "".equals(pValue)) {
						LOGGER.info("pName is and pValue has no value ");
					} else {
						ServerTemplatePropertyTO propTemp = new ServerTemplatePropertyTO();
						propTemp.setPropertyName(servertemplateproperty.getPropertyName());
						propTemp.setPropertyValue(servertemplateproperty.getPropertyValue());
						propTemp.setProvision_machine_id(provisionedmachineId);
						getHibernateTemplate().save(propTemp);
					}
				}
			}
		} catch (ConstraintViolationException ce) {
			LOGGER.error(ce);
			throw new CMMException("Hardware Name already exists.", ce);
		} catch (DataAccessException dae) {
			LOGGER.error(dae);
			throw new CMMException("Problem encountered. HardwareDAOImpl:addHardware", dae);
		} catch (HibernateException he) {
			LOGGER.error(he);
			throw new CMMException("Problem encountered. HardwareDAOImpl:addHardware", he);
		}
	}
	
	@Override
	public ProvisionedMachineTO getHardwareDetails(ProvisionedMachineTO provisionedMachineTO) throws CMMException {
	
		try {
			ProvisionedMachineTO prMacTO = (ProvisionedMachineTO) getHibernateTemplate().find("from ProvisionedMachineTO where id=?", provisionedMachineTO.getId()).get(0);
			long provision_machine_id;
			provision_machine_id = prMacTO.getId();
			List<ServerTemplatePropertyTO> servertemplateproperty = (List<ServerTemplatePropertyTO>) getHibernateTemplate().find("from ServerTemplatePropertyTO where  provision_machine_id=?", provision_machine_id);
			prMacTO.setServerTemplateProperty(servertemplateproperty);
			return prMacTO;
		} catch (DataAccessException dae) {
			LOGGER.error(dae);
			throw new CMMException("Problem encountered. HardwareDAOImpl:getHardwareDetails", dae);
		} catch (HibernateException he) {
			LOGGER.error(he);
			throw new CMMException("Problem encountered. HardwareDAOImpl:getHardwareDetails", he);
		}
	}
	
	@Override
	public void editHardware(ProvisionedMachineTO provisionedMachineTO, ProvisionedPlatformTO provisionedPlatformTO) throws CMMException {
	
		Session session = null;
		try {
			if ("187".equals(provisionedMachineTO.getServerStatus())) {
				provisionedMachineTO.setServerStatus("ACT");
			} else {
				provisionedMachineTO.setServerStatus("ICT");
			}
			getHibernateTemplate().saveOrUpdate(provisionedPlatformTO);
			provisionedMachineTO.setProvisionedPlatformTemplateId(provisionedPlatformTO.getId());
			getHibernateTemplate().update(provisionedMachineTO);
			Long provisionedmachineId = provisionedMachineTO.getId();
			ProvisionedMachinePhysicalTO physicalmachine = new ProvisionedMachinePhysicalTO();
			physicalmachine.setUsername(provisionedMachineTO.getUsername());
			physicalmachine.setPassword(provisionedMachineTO.getPassword());
			physicalmachine.setProvisionedMachineId(provisionedmachineId);
			if (provisionedMachineTO.getPhysicalmachineId() != 0) {
				physicalmachine.setId(provisionedMachineTO.getPhysicalmachineId());
				getHibernateTemplate().update(physicalmachine);
			} else {
				Long id = (Long) getHibernateTemplate().save(physicalmachine);
				provisionedMachineTO.setPhysicalmachineId(id);
			}
			List<Long> IdTemp = new ArrayList<Long>();
			for (ServerTemplatePropertyTO servertemplateproperty : provisionedMachineTO.getServerTemplateProperty()) {
				Long IdTemp1 = servertemplateproperty.getId();
				if (IdTemp1 != null) {
					IdTemp.add(IdTemp1);
				}
			}
			session = (Session) getSession();
			String query = "from ServerTemplatePropertyTO u where  u.provision_machine_id=:provisionedmachineId and u.id not in (:IdTemp) ";
			Query q = session.createQuery(query);
			q.setParameter("provisionedmachineId", provisionedmachineId);
			q.setParameterList("IdTemp", IdTemp);
			if (!IdTemp.isEmpty()) {
				List<ServerTemplatePropertyTO> servertemplateproperty1 = q.list();
				getHibernateTemplate().deleteAll(servertemplateproperty1);
			}
			for (ServerTemplatePropertyTO servertemplateproperty : provisionedMachineTO.getServerTemplateProperty()) {
				if ((servertemplateproperty != null) && (servertemplateproperty.getId() != null)) {
					String pName, pValue;
					pName = servertemplateproperty.getPropertyName();
					pValue = servertemplateproperty.getPropertyValue();
					if ("".equals(pName) || "".equals(pValue)) {
						LOGGER.info("pName is and pValue has no value ");
					} else {
						ServerTemplatePropertyTO propTemp = new ServerTemplatePropertyTO();
						propTemp.setPropertyName(servertemplateproperty.getPropertyName());
						propTemp.setPropertyValue(servertemplateproperty.getPropertyValue());
						propTemp.setProvision_machine_id(provisionedmachineId);
						propTemp.setId(servertemplateproperty.getId());
						getHibernateTemplate().update(propTemp);
					}
				} else if ((servertemplateproperty != null) && (servertemplateproperty.getId() == null) && (servertemplateproperty.getPropertyName() != null) && (servertemplateproperty.getPropertyValue() != null)) {
					String pName, pValue;
					pName = servertemplateproperty.getPropertyName();
					pValue = servertemplateproperty.getPropertyValue();
					if ("".equals(pName) || "".equals(pValue)) {
						LOGGER.info("pName is and pValue has no value ");
					} else {
						ServerTemplatePropertyTO propTemp = new ServerTemplatePropertyTO();
						propTemp.setPropertyName(servertemplateproperty.getPropertyName());
						propTemp.setPropertyValue(servertemplateproperty.getPropertyValue());
						propTemp.setProvision_machine_id(provisionedmachineId);
						getHibernateTemplate().save(propTemp);
					}
				}
			}
		} catch (ConstraintViolationException ce) {
			LOGGER.error(ce);
			throw new CMMException("Hardware Name already exists.", ce);
		} catch (DataAccessException dae) {
			LOGGER.error(dae);
			throw new CMMException("Problem encountered. HardwareDAOImpl:editHardware", dae);
		} catch (HibernateException he) {
			LOGGER.error(he);
			throw new CMMException("Problem encountered. HardwareDAOImpl:editHardware", he);
		}
	}
	
	@Override
	public void deleteHardwareTemplateProperty(String deleteTemplateProperty) throws CMMException {
	
		try {
			List<String> ids = Arrays.asList(deleteTemplateProperty.split("\\s*,\\s*"));
			for (String id : ids) {
				Long id1 = Long.parseLong(id);
				ServerTemplatePropertyTO propTemp = new ServerTemplatePropertyTO();
				propTemp.setId(id1);
				getHibernateTemplate().delete(propTemp);
			}
		} catch (ConstraintViolationException ce) {
			LOGGER.error(ce);
			throw new CMMException("Problem encountered.deleteHardwareTemplateProperty", ce);
		} catch (DataAccessException dae) {
			LOGGER.error(dae);
			throw new CMMException("Problem encountered.deleteHardwareTemplateProperty", dae);
		} catch (HibernateException he) {
			LOGGER.error(he);
			throw new CMMException("Problem encountered. deleteHardwareTemplateProperty", he);
		}
	}
	
	@Override
	public List<HardwareTO> getAllHardwares() throws CMMException {
	
		try {
			return (List<HardwareTO>) getHibernateTemplate().find("from HardwareTO");
		} catch (DataAccessException dae) {
			LOGGER.error(dae);
			throw new CMMException("Problem encountered. HardwareDAOImpl:getAllHardwares", dae);
		} catch (HibernateException he) {
			LOGGER.error(he);
			throw new CMMException("Problem encountered. HardwareDAOImpl:getAllHardwares", he);
		}
	}
	
	@Override
	public List<ProvisionedMachineTO> searchHardware(ProvisionedMachineTO provisionedMachineTO) throws CMMException {
	
		Session session = (Session) getSession();
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(ProvisionedMachineTO.class, "provisionedMachine");
			criteria.add(Restrictions.eq("provisionedMachineType", CMMConstants.Framework.MachineTypes.MACHINE_TYPE_PHYSICAL));
			criteria.createAlias("provisionedMachine.provisionedPlatform", "provisionedPlatform");
			if (!"-1".equalsIgnoreCase(provisionedMachineTO.getSelectedPlatform())) {
				criteria.add(Restrictions.eq("provisionedPlatform.family", provisionedMachineTO.getSelectedPlatform()));
			}
			if (!"".equalsIgnoreCase(provisionedMachineTO.getName().trim())) {
				criteria.add(Restrictions.like("name", "%" + provisionedMachineTO.getName() + "%"));
			}
			if (!"0".equalsIgnoreCase(String.valueOf(provisionedMachineTO.getRAM()))) {
				if (!"0".equalsIgnoreCase(String.valueOf(provisionedMachineTO.getRAM()))) {
					criteria.add(Restrictions.eq("RAM", provisionedMachineTO.getRAM()));
				}
			}
			if (!"0".equalsIgnoreCase(String.valueOf(provisionedMachineTO.getCPU()))) {
				if (!"0".equalsIgnoreCase(String.valueOf(provisionedMachineTO.getCPU().toString()))) {
					criteria.add(Restrictions.eq("CPU", provisionedMachineTO.getCPU()));
				}
			}
			if (!"".equalsIgnoreCase(provisionedMachineTO.getIp().trim())) {
				criteria.add(Restrictions.like("ip", "%" + provisionedMachineTO.getIp() + "%"));
			}
			if (!"".equalsIgnoreCase(provisionedMachineTO.getHostName().trim())) {
				criteria.add(Restrictions.like("hostName", "%" + provisionedMachineTO.getHostName() + "%"));
			}
			if (!"".equalsIgnoreCase(provisionedMachineTO.getArchitecture().trim())) {
				criteria.add(Restrictions.like("architecture", "%" + provisionedMachineTO.getArchitecture() + "%"));
			}
			if (!"".trim().equalsIgnoreCase(provisionedMachineTO.getMacAddress())) {
				criteria.add(Restrictions.like("macAddress", "%" + provisionedMachineTO.getMacAddress() + "%"));
			}
			List<ProvisionedMachineTO> provisionedMachineList = new ArrayList<ProvisionedMachineTO>();
			if (provisionedMachineTO.getSearchCount() == 0) {
				provisionedMachineList = (List<ProvisionedMachineTO>) getHibernateTemplate().findByCriteria(criteria);
			} else {
				criteria.getExecutableCriteria(session).setFirstResult(provisionedMachineTO.getFirstResult());
				criteria.getExecutableCriteria(session).setMaxResults(provisionedMachineTO.getTableSize());
				provisionedMachineList = (List<ProvisionedMachineTO>) getHibernateTemplate().findByCriteria(criteria);
			}
			List<ProvisionedMachineTO> provisionedMachineList1 = new ArrayList<ProvisionedMachineTO>();
			for (ProvisionedMachineTO provisionedMachine : provisionedMachineList) {
				long provision_machine_id;
				provision_machine_id = provisionedMachine.getId();
				List<ServerTemplatePropertyTO> servertemplateproperty = (List<ServerTemplatePropertyTO>) getHibernateTemplate().find("from ServerTemplatePropertyTO  where provision_machine_id=?", provision_machine_id);
				provisionedMachine.setServerTemplateProperty(servertemplateproperty);
				provisionedMachineList1.add(provisionedMachine);
			}
			return provisionedMachineList1;
		} catch (DataAccessException dae) {
			LOGGER.error(dae);
			throw new CMMException("Problem encountered. HardwareDAOImpl:searchHardware", dae);
		} catch (HibernateException he) {
			LOGGER.error(he);
			throw new CMMException("Problem encountered. HardwareDAOImpl:searchHardware", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public void deleteHardware(HardwareTO hardwareTO) throws CMMException {
	
		try {
			HardwareTO to = (HardwareTO) getHibernateTemplate().find("from HardwareTO where id=?", hardwareTO.getId()).get(0);
			to.setStatus(CMMConstants.Framework.Entity.HARDWARE_STATUS_INACTIVE);
			getHibernateTemplate().update(to);
		} catch (DataAccessException dae) {
			LOGGER.error(dae);
			throw new CMMException("Problem encountered. HardwareDAOImpl:deleteHardware", dae);
		} catch (HibernateException he) {
			LOGGER.error(he);
			throw new CMMException("Problem encountered. HardwareDAOImpl:deleteHardware", he);
		}
	}
	
	@Override
	public boolean checkName(ProvisionedMachineTO provisionedMachineTO) throws CMMException {
	
		boolean flag = false;
		try {
			List<HardwareTO> hardware = (List<HardwareTO>) getHibernateTemplate().find("from ProvisionedMachineTO where name=? and id<>?", provisionedMachineTO.getName(), provisionedMachineTO.getId());
			if (!hardware.isEmpty()) {
				flag = true;
			} else {
				flag = false;
			}
		} catch (DataAccessException dae) {
			LOGGER.error(dae);
			throw new CMMException("Problem encountered. HardwareDAOImpl:checkName", dae);
		} catch (HibernateException he) {
			LOGGER.error(he);
			throw new CMMException("Problem encountered. HardwareDAOImpl:checkName", he);
		}
		return flag;
	}
	
	@Override
	public List<HardwareTO> getAllHardware() throws CMMException {
	
		return (List<HardwareTO>) getHibernateTemplate().find("from HardwareTO");
	}
	
	@Override
	public List<HardwareTO> getHWdetails(HardwareTO hardwareTO) throws CMMException {
	
		try {
			List<HardwareTO> hardwareList = new ArrayList<HardwareTO>();
			LOGGER.info("Hardware Status:::::" + hardwareTO.getStatus());
			DetachedCriteria criteria = DetachedCriteria.forClass(HardwareTO.class);
			if (hardwareTO.getStatus() != 0) {
				criteria.add(Restrictions.eq("status", hardwareTO.getStatus()));
			}
			hardwareList = (List<HardwareTO>) getHibernateTemplate().findByCriteria(criteria);
			return hardwareList;
		} catch (DataAccessException dae) {
			LOGGER.error(dae);
			throw new CMMException("Problem encountered. HardwareDAOImpl:getHWdetails", dae);
		} catch (HibernateException he) {
			LOGGER.error(he);
			throw new CMMException("Problem encountered. HardwareDAOImpl:getHWdetails", he);
		}
	}
	
	@Override
	public List<Object[]> getHardwareUtilizationDetails(HardwareTO hardwareTO) throws CMMException {
	
		hardwareTO.getClientId();
		hardwareTO.getProjectId();
		final Date fromDate = hardwareTO.getFromDate();
		final Date toDate = hardwareTO.getToDate();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		formatter.format(fromDate);
		formatter.format(toDate);
		return null;
	}
	
	@Override
	public List<Object[]> getHardwareUtilizationPerc(HardwareTO hardwareTO) throws CMMException {
	
		hardwareTO.getClientId();
		hardwareTO.getProjectId();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		formatter.format(hardwareTO.getFromDate());
		formatter.format(hardwareTO.getToDate());
		return null;
	}
	
	@Override
	public List<BusinessUnit_InvTO> searchServerMasterList(Long clientId, List<Long> clientIdlist) throws CMMException {
	
		List<BusinessUnit_InvTO> detailsList = null;
		Session session = (Session) getSession();
		String clientIdlist1 = clientIdlist.toString();
		clientIdlist1 = clientIdlist1.substring(1, clientIdlist1.indexOf(']'));
		session.beginTransaction();
		try {
			String query = "select bu from BusinessUnit_InvTO as bu";
			if (!(clientId == 0)) {
				query = query + " where bu.clientId in (" + clientIdlist1 + ")";
			}
			detailsList = (List<BusinessUnit_InvTO>) getHibernateTemplate().find(query);
			return detailsList;
		} catch (DataAccessException dae) {
			LOGGER.error(dae);
			throw new CMMException("Problem encountered. searchServerMasterList", dae);
		} catch (HibernateException he) {
			LOGGER.error(he);
			throw new CMMException("Problem encountered. searchServerMasterList", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<HardwareTO> getHardwareList() throws CMMException {
	
		try {
			return (List<HardwareTO>) getHibernateTemplate().find("from HardwareTO");
		} catch (DataAccessException dae) {
			LOGGER.error(dae);
			throw new CMMException("Problem encountered. HardwareDAOImpl:getHardwareList", dae);
		} catch (HibernateException he) {
			LOGGER.error(he);
			throw new CMMException("Problem encountered. HardwareDAOImpl:getHardwareList", he);
		}
	}
	
	@Override
	public boolean addCIServer(CIServerTO ciServerTO) throws CMMException {
	
		try {
			getHibernateTemplate().save(ciServerTO);
			return true;
		} catch (DataAccessException dae) {
			LOGGER.error(dae);
			throw new CMMException("Problem encountered. HardwareDAOImpl:addCIServer", dae);
		} catch (HibernateException he) {
			LOGGER.error(he);
			throw new CMMException("Problem encountered. HardwareDAOImpl:addCIServer", he);
		}
	}
	
	@Override
	public List<ProvisionedMachineTO> fetchProvisionedMachineList() throws CMMException {
	
		try {
			List<ProvisionedMachineTO> provisionedMachineList = (List<ProvisionedMachineTO>) getHibernateTemplate().find("from ProvisionedMachineTO");
			if ((provisionedMachineList == null) || provisionedMachineList.isEmpty()) {
				throw new CMMException("No data present in provisioned machine  table.");
			}
			return provisionedMachineList;
		} catch (DataAccessException dae) {
			throw new CMMException("Can not fetch provisioned machine details:: ", dae);
		} catch (HibernateException he) {
			throw new CMMException("Can not access database:: ", he);
		}
	}
	
	public String getStatus(Long id) throws CMMException {
	
		try {
			String hql = "select statusDesc from StatusTO where id=?";
			List<String> list = (List<String>) getHibernateTemplate().find(hql, id);
			return list.get(0);
		} catch (DataAccessException dae) {
			LOGGER.error(dae);
			throw new CMMException("Problem encountered. HardwareDAOImpl : getStatus", dae);
		} catch (HibernateException he) {
			LOGGER.error(he);
			throw new CMMException("Problem encountered. HardwareDAOImpl : getStatus", he);
		}
	}
	
	@Override
	public boolean checkNameAddServer(ProvisionedMachineTO provisionedMachineTO) throws CMMException {
	
		boolean flag = false;
		try {
			List<HardwareTO> hardware = (List<HardwareTO>) getHibernateTemplate().find("from ProvisionedMachineTO where name=?", provisionedMachineTO.getName());
			if (!hardware.isEmpty()) {
				flag = true;
			} else {
				flag = false;
			}
		} catch (DataAccessException dae) {
			LOGGER.error(dae);
			throw new CMMException("Problem encountered. HardwareDAOImpl:checkName", dae);
		} catch (HibernateException he) {
			LOGGER.error(he);
			throw new CMMException("Problem encountered. HardwareDAOImpl:checkName", he);
		}
		return flag;
	}
}
