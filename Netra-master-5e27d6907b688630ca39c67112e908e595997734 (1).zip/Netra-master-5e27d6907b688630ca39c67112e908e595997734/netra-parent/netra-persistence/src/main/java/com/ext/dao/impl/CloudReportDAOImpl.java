package com.ext.dao.impl;

import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.exception.ConstraintViolationException;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.CloudReportDAO;
import com.framework.common.CMMConstants;
import com.framework.exception.CMMException;
import com.framework.to.ApplicationTO;
import com.framework.to.EnvironmentApplicationTO;
import com.framework.to.EnvironmentTO;
import com.framework.to.ProjectsTO;
import com.framework.to.ProvisionedMachineTO;
import com.framework.to.VmModelBUMappingTO;
import com.framework.to.VmModelProjectMappingTO;
import com.framework.to.VmReportTO;

public class CloudReportDAOImpl extends HibernateDaoSupport implements CloudReportDAO {
	
	private static final Logger LOG = Logger.getLogger(CloudReportDAOImpl.class);
	
	@Override
	public void saveModel(VmReportTO vmReportTO) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			getHibernateTemplate().save(vmReportTO);
		} catch (DataIntegrityViolationException div) {
			logger.error(div);
			throw new CMMException("Problem encountered.CloudReportDAOImpl:saveModel", div);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.CloudReportDAOImpl:saveModel", dae);
		} catch (ConstraintViolationException e) {
			logger.error(e);
			throw new CMMException("Problem encountered. CloudReportDAOImpl:saveModel", e);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. CloudReportDAOImpl:saveModel", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<VmReportTO> getAllModel() throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			List<VmReportTO> vmCostModel = new ArrayList<VmReportTO>();
			vmCostModel = (List<VmReportTO>) getHibernateTemplate().find("from VmReportTO");
			return vmCostModel;
		} catch (DataIntegrityViolationException div) {
			logger.error(div);
			throw new CMMException("Problem encountered.CloudReportDAOImpl:saveModel", div);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.CloudReportDAOImpl:saveModel", dae);
		} catch (ConstraintViolationException e) {
			logger.error(e);
			throw new CMMException("Problem encountered. CloudReportDAOImpl:saveModel", e);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. CloudReportDAOImpl:saveModel", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public void saveMapping(VmReportTO vmReportTO) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			VmModelBUMappingTO vmModelMap = new VmModelBUMappingTO();
			vmModelMap.setModelId(vmReportTO.getSelectedModel());
			vmModelMap.setBuId(vmReportTO.getSelectedBU());
			getHibernateTemplate().save(vmModelMap);
		} catch (DataIntegrityViolationException div) {
			logger.error(div);
			throw new CMMException("Problem encountered.CloudReportDAOImpl:saveModel", div);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.CloudReportDAOImpl:saveModel", dae);
		} catch (ConstraintViolationException e) {
			logger.error(e);
			throw new CMMException("Problem encountered. CloudReportDAOImpl:saveModel", e);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. CloudReportDAOImpl:saveModel", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public void saveProjectModelMapping(VmReportTO vmReportTO) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			VmModelProjectMappingTO vmModelMap = new VmModelProjectMappingTO();
			vmModelMap.setModelId(vmReportTO.getSelectedModel());
			vmModelMap.setProjectId(vmReportTO.getSelectedProject());
			List<VmModelProjectMappingTO> vmModelProjectTo = (List<VmModelProjectMappingTO>) getHibernateTemplate().find("from VmModelProjectMappingTO where projectId=?", vmReportTO.getSelectedProject());
			if (!vmModelProjectTo.isEmpty()) {
				VmModelProjectMappingTO temp = vmModelProjectTo.get(0);
				temp.setModelId(vmReportTO.getSelectedModel());
				temp.setProjectId(vmReportTO.getSelectedProject());
				getHibernateTemplate().update(temp);
			} else {
				getHibernateTemplate().save(vmModelMap);
			}
		} catch (DataIntegrityViolationException div) {
			logger.error(div);
			throw new CMMException("Problem encountered.CloudReportDAOImpl:saveModel", div);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.CloudReportDAOImpl:saveModel", dae);
		} catch (ConstraintViolationException e) {
			logger.error(e);
			throw new CMMException("Problem encountered. CloudReportDAOImpl:saveModel", e);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. CloudReportDAOImpl:saveModel", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<ProvisionedMachineTO> getProvisionedMachineList(VmReportTO vmReportTO) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			List<ProvisionedMachineTO> pmTOList = new ArrayList<ProvisionedMachineTO>();
			List<ApplicationTO> applicationIdList = new ArrayList<ApplicationTO>();
			applicationIdList = (List<ApplicationTO>) getHibernateTemplate().find("SELECT id FROM ApplicationTO  WHERE selectedProject =?", vmReportTO.getSelectedProject());
			if (!applicationIdList.isEmpty()) {
				List<EnvironmentApplicationTO> environmentTOList = new ArrayList<EnvironmentApplicationTO>();
				StringBuilder query = new StringBuilder();
				query.append("from EnvironmentApplicationTO where APPLICATION_ID in(:idList)");
				environmentTOList = (List<EnvironmentApplicationTO>) getHibernateTemplate().findByNamedParam(query.toString(), "idList", applicationIdList);
				if (!environmentTOList.isEmpty()) {
					List<Long> environmentIdList = new ArrayList<Long>();
					for (EnvironmentApplicationTO temp : environmentTOList) {
						environmentIdList.add(temp.getEnvironmentTO().getId());
					}
					List<EnvironmentTO> environmentTO = new ArrayList<EnvironmentTO>();
					StringBuilder queryEnv = new StringBuilder();
					queryEnv.append(" from EnvironmentTO where id in(:idList)");
					environmentTO = (List<EnvironmentTO>) getHibernateTemplate().findByNamedParam(queryEnv.toString(), "idList", environmentIdList);
					if (!environmentTO.isEmpty()) {
						List<Long> provisionedMachineIdList = new ArrayList<Long>();
						StringBuilder query2 = new StringBuilder();
						query2.append("SELECT DISTINCT provisionedMachineId from EnvironmentDetailsTO where environment in(:idList)");
						provisionedMachineIdList = (List<Long>) getHibernateTemplate().findByNamedParam(query2.toString(), "idList", environmentTO);
						StringBuilder query3 = new StringBuilder();
						String tmpQuery = "from ProvisionedMachineTO where id in(:idList)";
						if (!vmReportTO.getFromDate().isEmpty() && !vmReportTO.getToDate().isEmpty()) {
							tmpQuery = tmpQuery + " and updatedOn >= '" + vmReportTO.getFromDate() + "' and updatedOn<= '" + vmReportTO.getToDate() + "'";
						}
						query3.append(tmpQuery);
						pmTOList = (List<ProvisionedMachineTO>) getHibernateTemplate().findByNamedParam(query3.toString(), "idList", provisionedMachineIdList);
					}
				}
			}
			return pmTOList;
		} catch (DataIntegrityViolationException div) {
			logger.error(div);
			throw new CMMException("Problem encountered.CloudReportDAOImpl:saveModel", div);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.CloudReportDAOImpl:saveModel", dae);
		} catch (ConstraintViolationException e) {
			logger.error(e);
			throw new CMMException("Problem encountered. CloudReportDAOImpl:saveModel", e);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. CloudReportDAOImpl:saveModel", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public VmReportTO getModelDetailforBU(long businessUnit) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			VmReportTO vmReportTO = new VmReportTO();
			VmModelBUMappingTO vmModelBUMappingTO = new VmModelBUMappingTO();
			vmModelBUMappingTO = (VmModelBUMappingTO) getHibernateTemplate().find("from VmModelBUMappingTO  where CLIENT =?", businessUnit).get(0);
			vmReportTO = (VmReportTO) getHibernateTemplate().find("from VmReportTO  where id =?", vmModelBUMappingTO.getModelId()).get(0);
			return vmReportTO;
		} catch (DataIntegrityViolationException div) {
			logger.error(div);
			throw new CMMException("Problem encountered.CloudReportDAOImpl:saveModel", div);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.CloudReportDAOImpl:saveModel", dae);
		} catch (ConstraintViolationException e) {
			logger.error(e);
			throw new CMMException("Problem encountered. CloudReportDAOImpl:saveModel", e);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. CloudReportDAOImpl:saveModel", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public VmReportTO getModelDetailforProject(long projectId) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			VmReportTO vmReportTO = new VmReportTO();
			VmModelProjectMappingTO vmModelProjectMappingTO = new VmModelProjectMappingTO();
			vmModelProjectMappingTO = (VmModelProjectMappingTO) getHibernateTemplate().find("from VmModelProjectMappingTO  where projectId =?", projectId).get(0);
			vmReportTO = (VmReportTO) getHibernateTemplate().find("from VmReportTO  where id =?", vmModelProjectMappingTO.getModelId()).get(0);
			return vmReportTO;
		} catch (DataIntegrityViolationException div) {
			logger.error(div);
			throw new CMMException("Problem encountered.CloudReportDAOImpl:saveModel", div);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.CloudReportDAOImpl:saveModel", dae);
		} catch (ConstraintViolationException e) {
			logger.error(e);
			throw new CMMException("Problem encountered. CloudReportDAOImpl:saveModel", e);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. CloudReportDAOImpl:saveModel", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<ProjectsTO> getAllProjects() throws CMMException {
	
		try {
			return (List<ProjectsTO>) getHibernateTemplate().find("from ProjectsTO where status=?", CMMConstants.Framework.Entity.PROJECT_STATUS_EXISTING);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.  CloudReportDAOImpl : getAllProjects", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.   CloudReportDAOImpl : getAllProjects", he);
		}
	}
	
	@Override
	public boolean checkModelName(String modelName) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			boolean flag = false;
			List<VmReportTO> list = (List<VmReportTO>) getHibernateTemplate().find("from VmReportTO where modelName=?", modelName);
			if (!list.isEmpty()) {
				flag = true;
			}
			return flag;
		} catch (DataIntegrityViolationException div) {
			logger.error(div);
			throw new CMMException("Problem encountered.CloudReportDAOImpl:saveModel", div);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.CloudReportDAOImpl:saveModel", dae);
		} catch (ConstraintViolationException e) {
			logger.error(e);
			throw new CMMException("Problem encountered. CloudReportDAOImpl:saveModel", e);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. CloudReportDAOImpl:saveModel", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
}