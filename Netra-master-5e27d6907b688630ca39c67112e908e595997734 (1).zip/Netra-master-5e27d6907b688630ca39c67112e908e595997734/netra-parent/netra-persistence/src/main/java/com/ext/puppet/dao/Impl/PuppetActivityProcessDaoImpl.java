/**
 *
 */
package com.ext.puppet.dao.Impl;

import java.util.ArrayList;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.exception.ConstraintViolationException;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.puppet.dao.PuppetActivityProcessDao;
import com.framework.exception.CMMException;
import com.framework.puppetMaster.to.PuppetActivityExecOrderTO;
import com.framework.puppetMaster.to.PuppetActivityProcessOrderTO;
import com.framework.puppetMaster.to.PuppetActivitySoftwareMappingTO;
import com.framework.puppetMaster.to.PuppetProcessSoftwareMapping;
import com.framework.puppetMaster.to.PuppetReleaseActivityTO;

/**
 * @author 584175
 */
public class PuppetActivityProcessDaoImpl extends HibernateDaoSupport implements PuppetActivityProcessDao {
	
	@Override
	public List<PuppetActivityProcessOrderTO> fetchPuppetSoftProcessMapByActivityID(long mapActivityId) throws CMMException {
	
		List<PuppetActivityProcessOrderTO> puppetActivityProcessList = new ArrayList<PuppetActivityProcessOrderTO>();
		try {
			puppetActivityProcessList = (List<PuppetActivityProcessOrderTO>) getHibernateTemplate().findByCriteria(DetachedCriteria.forClass(PuppetActivityProcessOrderTO.class).add(Restrictions.eq("puppetActivitySoftwareMappingTO.activitySoftwareMapId", mapActivityId)).addOrder(Order.asc("processOrder")));
			if (puppetActivityProcessList == null) {
				logger.debug("No record found for activityId::" + mapActivityId);
				throw new CMMException("No activity mapping found for given activityId::" + mapActivityId);
			}
		} catch (DataAccessException | HibernateException da) {
			logger.error("Error in PuppetActivityProcessDaoImpl: fetchPuppetSoftProcessMapByActivityID ", da);
			throw new CMMException("Problem encountered. PuppetActivityProcessDaoImpl : fetchPuppetSoftProcessMapByActivityID", da);
		}
		return puppetActivityProcessList;
	}
	
	@Override
	public void saveOrderedPuppetProcessForActivity(PuppetReleaseActivityTO puppetReleaseActivityTO) throws CMMException {
	
		try {
			List<Long> orderedProcessList = new ArrayList<Long>();
			List<Long> procList = puppetReleaseActivityTO.getPuppetProcessSoftwareMapOrderedList();
			for (Long l : procList) {
				PuppetProcessSoftwareMapping npSoftMap = getPuppetProcessSoftwareMapping(puppetReleaseActivityTO, l);
				orderedProcessList.add(npSoftMap.getSoftwareProcessMappingId());
			}
			PuppetActivitySoftwareMappingTO activitySoftwareMappingToP = getActivitySoftwareMapping(puppetReleaseActivityTO);
			List<PuppetActivityProcessOrderTO> puppetActivityProcessOrderTOprevious = (List<PuppetActivityProcessOrderTO>) getHibernateTemplate().find("from PuppetActivityProcessOrderTO where puppetActivitySoftwareMappingTO.activitySoftwareMapId =? ", activitySoftwareMappingToP.getActivitySoftwareMapId());
			if (puppetActivityProcessOrderTOprevious != null) {
				for (int i = 0; i < puppetActivityProcessOrderTOprevious.size(); i++) {
					PuppetActivityProcessOrderTO puppetActivityProcessOrderTO = puppetActivityProcessOrderTOprevious.get(i);
					getHibernateTemplate().delete(puppetActivityProcessOrderTO);
				}
			}
			for (int i = 0; i < orderedProcessList.size(); i++) {
				PuppetProcessSoftwareMapping puppetProcessSoftwareMapping = new PuppetProcessSoftwareMapping();
				puppetProcessSoftwareMapping.setSoftwareProcessMappingId(orderedProcessList.get(i));
				PuppetActivityProcessOrderTO puppetActivityProcessOrderTO = new PuppetActivityProcessOrderTO();
				puppetActivityProcessOrderTO.setPuppetProcessSoftwareMapping(puppetProcessSoftwareMapping);
				puppetActivityProcessOrderTO.setPuppetActivitySoftwareMappingTO(activitySoftwareMappingToP);
				puppetActivityProcessOrderTO.setProcessOrder(i);
				getHibernateTemplate().saveOrUpdate(puppetActivityProcessOrderTO);
				logger.debug("Puppet processes saved successfully for ActivityId:: " + puppetReleaseActivityTO.getSelectedActivityId());
			}
		} catch (DataIntegrityViolationException | HibernateException div) {
			logger.error(div);
			throw new CMMException("Problem encountered. PuppetActivityProcessDaoImpl : saveOrderedPuppetProcessForActivity", div);
		}
	}
	
	@Override
	public void saveOrderedActivities(PuppetReleaseActivityTO puppetReleaseActivityTO) throws CMMException {
	
		Session session = null;
		try {
			PuppetActivitySoftwareMappingTO puppetActivitySoftwareMappingToP = getActivitySoftwareMapping(puppetReleaseActivityTO);
			List<PuppetActivityExecOrderTO> puppetActivityExecOrderTOprevious = new ArrayList<PuppetActivityExecOrderTO>();
			puppetActivityExecOrderTOprevious = (List<PuppetActivityExecOrderTO>) getHibernateTemplate().find("from PuppetActivityExecOrderTO where puppetActivitySoftwareMappingTOP.activitySoftwareMapId =? ", puppetActivitySoftwareMappingToP.getActivitySoftwareMapId());
			if (puppetActivityExecOrderTOprevious != null) {
				for (int i = 0; i < puppetActivityExecOrderTOprevious.size(); i++) {
					PuppetActivityExecOrderTO puppetActivityExecOrderTO = puppetActivityExecOrderTOprevious.get(i);
					getHibernateTemplate().delete(puppetActivityExecOrderTO);
				}
			}
			Transaction tx = null;
			session = getSession();
			tx = session.beginTransaction();
			String hql = "from  PuppetActivitySoftwareMappingTO where softwareconfigTO.id = ? and puppetReleaseActivityTO.activityId = ? )";
			Query q = session.createQuery(hql);
			q.setParameter(0, puppetReleaseActivityTO.getSoftwareId());
			q.setParameter(1, puppetReleaseActivityTO.getSelectedActivityId());
			List<Object[]> obj = q.list();
			tx.commit();
			PuppetActivityExecOrderTO puppetActivityExecOrderTO = new PuppetActivityExecOrderTO();
			for (int i = 0; i < obj.size(); i++) {
				Object activitySoftware = obj.get(i);
				puppetActivityExecOrderTO.setPuppetActivitySoftwareMappingTO((PuppetActivitySoftwareMappingTO) activitySoftware);
				puppetActivityExecOrderTO.setPuppetActivitySoftwareMappingTOP(puppetActivitySoftwareMappingToP);
				puppetActivityExecOrderTO.setExeOrder(i);
				getHibernateTemplate().save(puppetActivityExecOrderTO);
				logger.debug("Activities saved successfully for ActivityId:: " + puppetReleaseActivityTO.getSelectedActivityId());
			}
		} catch (DataIntegrityViolationException | HibernateException div) {
			logger.error(div);
			throw new CMMException("Problem encountered. PuppetActivityProcessDaoImpl : saveOrderedActivities", div);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	public PuppetActivitySoftwareMappingTO getActivitySoftwareMapping(PuppetReleaseActivityTO puppetReleaseActivityTO) throws CMMException {
	
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(PuppetActivitySoftwareMappingTO.class);
			criteria.createAlias("softwareconfigTO", "soft", CriteriaSpecification.LEFT_JOIN);
			criteria.createAlias("puppetReleaseActivityTO", "acti", CriteriaSpecification.LEFT_JOIN);
			criteria.add(Restrictions.eq("soft.id", puppetReleaseActivityTO.getSoftwareId()));
			criteria.add(Restrictions.eq("acti.activityId", puppetReleaseActivityTO.getSelectedActivityId()));
			return (PuppetActivitySoftwareMappingTO) getHibernateTemplate().findByCriteria(criteria).get(0);
		} catch (DataAccessException | HibernateException div) {
			logger.error("Error in PuppetActivityProcessDaoImpl: getActivitySoftwareMapping ", div);
			throw new CMMException("Problem encountered. PuppetActivityProcessDaoImpl : getActivitySoftwareMapping", div);
		}
	}
	
	public PuppetProcessSoftwareMapping getPuppetProcessSoftwareMapping(PuppetReleaseActivityTO puppetReleaseActivityTO, Long processId) throws CMMException {
	
		try {
			PuppetProcessSoftwareMapping puppetProcessSoftwareMapping = new PuppetProcessSoftwareMapping();
			DetachedCriteria criteria = DetachedCriteria.forClass(PuppetProcessSoftwareMapping.class);
			criteria.createAlias("softwareConfigTO", "soft", CriteriaSpecification.LEFT_JOIN);
			criteria.createAlias("puppetProcess", "pup", CriteriaSpecification.LEFT_JOIN);
			criteria.add(Restrictions.eq("soft.id", puppetReleaseActivityTO.getSoftwareId()));
			criteria.add(Restrictions.eq("pup.processId", processId));
			puppetProcessSoftwareMapping = (PuppetProcessSoftwareMapping) getHibernateTemplate().findByCriteria(criteria).get(0);
			return puppetProcessSoftwareMapping;
		} catch (DataAccessException | HibernateException div) {
			logger.error("Error in PuppetActivityProcessDaoImpl: getPuppetProcessSoftwareMapping ", div);
			throw new CMMException("Problem encountered. PuppetActivityProcessDaoImpl : getPuppetProcessSoftwareMapping", div);
		}
	}
	
	@Override
	public List<PuppetActivityProcessOrderTO> fetchPuppetProcessOrder(PuppetReleaseActivityTO puppetReleaseActivityTO) throws CMMException {
	
		try {
			List<Long> puppetActivitySoftwareMappingTO = (List<Long>) getHibernateTemplate().find("select activitySoftwareMapId from PuppetActivitySoftwareMappingTO  where softwareconfigTO.id = ? ", Long.parseLong(puppetReleaseActivityTO.getSelectedVersion()));
			List<Long> puppetProcessSoftwareMapping = (List<Long>) getHibernateTemplate().find("select softwareProcessMappingId from PuppetProcessSoftwareMapping where softwareConfigTO.id = ? ", Long.parseLong(puppetReleaseActivityTO.getSelectedVersion()));
			if (!puppetActivitySoftwareMappingTO.isEmpty() && !puppetProcessSoftwareMapping.isEmpty()) {
				String paramNames[] = { "mapIds", "puppetIds" };
				Object[] values = { puppetActivitySoftwareMappingTO, puppetProcessSoftwareMapping };
				return (List<PuppetActivityProcessOrderTO>) getHibernateTemplate().findByNamedParam(" from PuppetActivityProcessOrderTO where puppetActivitySoftwareMappingTO.activitySoftwareMapId in(:mapIds) and puppetProcessSoftwareMapping.softwareProcessMappingId in (:puppetIds) Order by puppetActivitySoftwareMappingTO.activitySoftwareMapId,processOrder ", paramNames, values);
			} else {
				return null;
			}
		} catch (ConstraintViolationException ce) {
			logger.error(ce);
			throw new CMMException("Problem encountered. PuppetActivityProcessDaoImpl : fetchPuppetProcessOrder", ce);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. PuppetActivityProcessDaoImpl : fetchPuppetProcessOrder", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. PuppetActivityProcessDaoImpl : fetchPuppetProcessOrder", he);
		} catch (Exception e) {
			logger.error(e);
			throw new CMMException("Problem encountered. PuppetActivityProcessDaoImpl : fetchPuppetProcessOrder", e);
		}
	}
	
	@Override
	public List<PuppetActivityExecOrderTO> fetchOrderedActivities(PuppetReleaseActivityTO puppetReleaseActivityTO) throws CMMException {
	
		try {
			PuppetActivitySoftwareMappingTO activitySoftwareMappingTO = (PuppetActivitySoftwareMappingTO) getHibernateTemplate().find("from PuppetActivitySoftwareMappingTO where softwareconfigTO.id = ? and puppetReleaseActivityTO.activityId =?", puppetReleaseActivityTO.getSelectedVersion(), puppetReleaseActivityTO.getSelectedActivityId()).get(0);
			return (List<PuppetActivityExecOrderTO>) getHibernateTemplate().find("from  PuppetActivityExecOrderTO where puppetActivitySoftwareMappingTOP.activitySoftwareMapId = ?  order by exeOrder ", activitySoftwareMappingTO.getActivitySoftwareMapId());
		} catch (DataAccessException | HibernateException ce) {
			logger.error("Error in PuppetActivityProcessDaoImpl: fetchOrderedActivities ", ce);
			throw new CMMException("Problem encountered. PuppetActivityProcessDaoImpl : fetchOrderedActivities", ce);
		}
	}
}
