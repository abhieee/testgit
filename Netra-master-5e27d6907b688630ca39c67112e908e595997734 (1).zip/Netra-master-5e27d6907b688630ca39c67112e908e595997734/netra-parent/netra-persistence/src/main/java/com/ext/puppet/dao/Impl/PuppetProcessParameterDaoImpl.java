package com.ext.puppet.dao.Impl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.engine.SessionFactoryImplementor;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.puppet.dao.PuppetProcessParameterDao;
import com.framework.exception.CMMException;
import com.framework.puppetMaster.to.PuppetProcess;
import com.framework.puppetMaster.to.PuppetProcessParametersTO;

/**
 * @author 584175
 */
public class PuppetProcessParameterDaoImpl extends HibernateDaoSupport implements PuppetProcessParameterDao {
	
	@Override
	public void updateParameterValue(long parameterId, String parameterValue) throws CMMException {
	
		PuppetProcessParametersTO puppetProcessParametersTO = getPuppetParameters(parameterId);
		puppetProcessParametersTO.setParameterValue(parameterValue);
		try {
			getHibernateTemplate().update(puppetProcessParametersTO);
		} catch (DataAccessException | HibernateException he) {
			logger.error("Error in PuppetProcessParameterDaoImpl:updateParameterValue ", he);
			throw new CMMException("Problem encountered. PuppetReleaseActivityDaoImpl : fetchMappedSoftwareType", he);
		}
	}
	
	@Override
	public PuppetProcessParametersTO getPuppetParameters(long parameterId) throws CMMException {
	
		try {
			return (PuppetProcessParametersTO) getHibernateTemplate().find("from PuppetProcessParametersTO where parameterId=?", parameterId).get(0);
		} catch (DataAccessException | HibernateException dae) {
			logger.error("Error in PuppetProcessParameterDaoImpl: getPuppetParameters ", dae);
			throw new CMMException("Problem encountered. PuppetReleaseActivityDaoImpl :  getPuppetParameters", dae);
		}
	}
	
	@Override
	public long fetchParameters(long serviceId, long applicationReleaseDbId, String rollback) throws CMMException, SQLException {
	
		logger.debug(":::fetchParameters:::serviceId::::" + serviceId + "::applicationReleaseDbId::" + applicationReleaseDbId + "::rollback:::" + rollback);
		long paramMapId;
		Session session = null;
		Connection conn = null;
		java.sql.CallableStatement cs = null;
		try {
			session = getSession();
			SessionFactoryImplementor sfi = (SessionFactoryImplementor) session.getSessionFactory();
			org.hibernate.connection.ConnectionProvider cp = sfi.getConnectionProvider();
			conn = cp.getConnection();
			cs = conn.prepareCall("{call ParamMapping(?,?,?,?)}");
			cs.setInt(1, (int) serviceId);
			cs.setInt(2, (int) applicationReleaseDbId);
			cs.setString(3, rollback);
			cs.registerOutParameter(4, java.sql.Types.INTEGER);
			cs.execute();
			paramMapId = cs.getLong(4);
			if (paramMapId <= 0) {
				throw new CMMException();
			}
			return paramMapId;
		} catch (DataAccessException | HibernateException dae) {
			logger.error("Error in PuppetProcessParameterDaoImpl: fetchParameters ", dae);
			throw new CMMException("Problem encountered. PuppetReleaseActivityDaoImpl :  fetchParameters", dae);
		} finally {
			if (session != null) {
				session.close();
			}
			if (cs != null) {
				cs.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
	}
	
	@Override
	public List<PuppetProcess> getAllPuppetProcessList() throws CMMException {
	
		List<PuppetProcess> puppetProcessList = new ArrayList<PuppetProcess>();
		PuppetProcess a = new PuppetProcess();
		a.setProcessFullPath("Install_MYsql");
		PuppetProcess a1 = new PuppetProcess();
		a1.setProcessFullPath("Install_MYsql2");
		PuppetProcess a2 = new PuppetProcess();
		a2.setProcessFullPath("Install_MYsql3");
		PuppetProcess a3 = new PuppetProcess();
		a3.setProcessFullPath("Install_MYsql4");
		PuppetProcess a4 = new PuppetProcess();
		a4.setProcessFullPath("Install_MYsql5");
		PuppetProcess a5 = new PuppetProcess();
		a5.setProcessFullPath("Install_MYsql6");
		puppetProcessList.add(a);
		puppetProcessList.add(a1);
		puppetProcessList.add(a2);
		puppetProcessList.add(a3);
		puppetProcessList.add(a4);
		puppetProcessList.add(a5);
		return puppetProcessList;
	}
}
