package com.ext.dao.impl;

import java.util.List;
import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.JMeterDAO;
import com.framework.exception.CMMException;

public class JMeterDAOImpl extends HibernateDaoSupport implements JMeterDAO {
	
	private static final Logger LOG = Logger.getLogger(JMeterDAOImpl.class);
	
	@Override
	public List<String> getUserEmailByRequestId(Long requestId) throws CMMException {
	
		List<String> emailList = null;
		String hql = "SELECT u.email FROM UserTO u, UserGroupDetailsTO ugd, UserGroupTO ug, EnvironmentApplicationTO ea, ServiceRequestTO sr WHERE u.id=ugd.users.id AND ugd.userGroups.id=ug.id AND ug.applications.id=ea.applicationTO.id AND sr.environmentId=ea.environmentTO.id AND sr.id=?";
		try {
			emailList = (List<String>) getHibernateTemplate().find(hql, requestId);
		} catch (DataAccessException | HibernateException e) {
			LOG.error(e);
			throw new CMMException("Problem encountered. JMeterDAOImpl : getUserEmailByRequestId", e);
		}
		return emailList;
	}
}
