package com.ext.dao.impl;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Hibernate;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.engine.SessionFactoryImplementor;
import org.hibernate.exception.ConstraintViolationException;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.ApplicationProfileDAO;
import com.ext.dao.ServiceRequestDAO;
import com.framework.common.CMMConstants;
import com.framework.common.CMMConstants.Framework;
import com.framework.exception.CMMException;
import com.framework.nolio.to.NolioProcessParametersTO;
import com.framework.to.ActivitySoftwareMappingTO;
import com.framework.to.ApplicationProfileDetailsAWSTO;
import com.framework.to.ApplicationProfileDetailsTO;
import com.framework.to.ApplicationProfileMappingTO;
import com.framework.to.ApplicationProfileTO;
import com.framework.to.ApplicationReleaseBuildTO;
import com.framework.to.ApplicationReleaseDbTO;
import com.framework.to.ApplicationReleaseNexusDetailsTO;
import com.framework.to.ApplicationReleasePhaseTO;
import com.framework.to.ApplicationReleaseSharedDetailsTO;
import com.framework.to.ApplicationReleaseSharedMappingTO;
import com.framework.to.ApplicationReleaseSourcecodeTO;
import com.framework.to.ApplicationReleaseTO;
import com.framework.to.ApplicationTO;
import com.framework.to.BusinessUnitTO;
import com.framework.to.ClientTO;
import com.framework.to.DeploymentPipelineForJiraTO;
import com.framework.to.EnvSoftParamDetailsTO;
import com.framework.to.EnvTypeTO;
import com.framework.to.EnvironmentApplicationTO;
import com.framework.to.EnvironmentDetailsTO;
import com.framework.to.EnvironmentDockerTO;
import com.framework.to.EnvironmentSoftParamsTO;
import com.framework.to.EnvironmentSoftwareAttributeTO;
import com.framework.to.EnvironmentTO;
import com.framework.to.JIRAConfigTO;
import com.framework.to.MachineTemplateAwsTO;
import com.framework.to.MachineTemplateBareMetalTO;
import com.framework.to.MachineTemplateOSTO;
import com.framework.to.MachineTemplateTO;
import com.framework.to.MachineVMWareTO;
import com.framework.to.MultipleProfileDetailsTO;
import com.framework.to.MultipleProfilesTO;
import com.framework.to.NetraNexusDetailsTO;
import com.framework.to.PipelineRequestDetailsTO;
import com.framework.to.PlatformTemplateAwsTO;
import com.framework.to.PlatformTemplateBareMetalTO;
import com.framework.to.PlatformTemplateOSTO;
import com.framework.to.PlatformTemplateTO;
import com.framework.to.ProjectsTO;
import com.framework.to.ProvisionedMachineAwsTO;
import com.framework.to.ProvisionedMachineOSTO;
import com.framework.to.ProvisionedMachineTO;
import com.framework.to.ProvisionedMachineVMWareTO;
import com.framework.to.ProvisionedMachineVmwareBareMetalTO;
import com.framework.to.ProvisionedPlatformOSTO;
import com.framework.to.ProvisionedPlatformTO;
import com.framework.to.ProvisionedPlatformVmwareBareMetalTO;
import com.framework.to.ProvisionedTemplateVMWareTO;
import com.framework.to.ProvisionedTemplatesAwsTO;
import com.framework.to.QuartzHistoryTO;
import com.framework.to.ReleasePlanningPhasesTO;
import com.framework.to.ReleasePlanningTO;
import com.framework.to.RepoTO;
import com.framework.to.RepositoryMasterTO;
import com.framework.to.ServiceJiraMappingTO;
import com.framework.to.ServiceRequestDetailsTO;
import com.framework.to.ServiceRequestHistoryTO;
import com.framework.to.ServiceRequestTO;
import com.framework.to.ServiceTO;
import com.framework.to.SonarDetailTO;
import com.framework.to.StatusTO;
import com.framework.to.SubEnvironmentMappingTO;
import com.framework.to.TargetServerVO;
import com.framework.to.TemplateVMWareTO;
import com.framework.to.TestingPhaseTO;
import com.framework.to.TestingToolsTO;
import com.framework.to.UserDefinedEnvParamsTO;
import com.framework.to.UserTO;
import com.framework.to.VMDetailsTO;
import com.framework.to.WorkFlowLevelTO;
import com.framework.to.WorkFlowTO;
import com.framework.to.WorkflowCurrentTO;
import com.framework.utility.DateUtils;

public class ServiceRequestDAOImpl extends HibernateDaoSupport implements ServiceRequestDAO {
	
	private static final Logger LOG = Logger.getLogger(ServiceRequestDAOImpl.class);
	ServiceRequestDAO serviceRequestDAO;
	@Autowired
	ApplicationProfileDAO applicationProfileDAO;
	
	public ApplicationProfileDAO getApplicationProfileDAO() {
	
		return applicationProfileDAO;
	}
	
	public void setApplicationProfileDAO(ApplicationProfileDAO applicationProfileDAO) {
	
		this.applicationProfileDAO = applicationProfileDAO;
	}
	
	@Override
	public ServiceRequestTO fetchServiceRequestDeatilsForPuppetAction() throws CMMException {
	
		try {
			List<ServiceRequestTO> list = (List<ServiceRequestTO>) getHibernateTemplate().find("from ServiceRequestTO where actionFlag= ? and statusId= ?", CMMConstants.Framework.ServiceRequestStatus.SERVICE_REQUEST_ACTIVE, CMMConstants.Framework.Entity.SERVICE_REQUEST_UNDER_IMPLEMENTATION);
			if (!list.isEmpty()) {
				return list.get(0);
			}
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl:fetchServiceRequestDeatilsForPuppetAction", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl:fetchServiceRequestDeatilsForPuppetAction", he);
		}
		return null;
	}
	
	@SuppressWarnings({ "deprecation", "unchecked" })
	@Override
	public ReleasePlanningTO getReleasePlanningDetails(Long id) throws CMMException {
	
		Session session;
		session = getSession();
		ReleasePlanningTO releasePlanning;
		Criteria criteria = session.createCriteria(ReleasePlanningTO.class, "plannings");
		Criteria criteriaPhases = session.createCriteria(ReleasePlanningPhasesTO.class, "phases");
		try {
			criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			List<ReleasePlanningTO> releasePlanningList;
			criteriaPhases.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			List<ReleasePlanningPhasesTO> releasePlanningPhasesList;
			if ((id != null) && (id > 0)) {
				criteria.add(Restrictions.eq("plannings.id", id));
			} else {
				throw new CMMException("Problem encountered.ReleasePlanningDAOImpl:getReleasePlanningDetails.");
			}
			releasePlanningList = criteria.list();
			if ((releasePlanningList != null) && !releasePlanningList.isEmpty()) {
				releasePlanning = releasePlanningList.get(0);
				criteriaPhases.add(Restrictions.eq("phases.releasePlanningId", id));
				releasePlanningPhasesList = criteriaPhases.list();
				List<Long> releasePlanningPhasesIds = new ArrayList<>();
				for (ReleasePlanningPhasesTO releasePlanningPhasesTO : releasePlanningPhasesList) {
					releasePlanningPhasesIds.add(releasePlanningPhasesTO.getApplicationPhaseId());
				}
				releasePlanning.setSelectedPhaseIds(releasePlanningPhasesIds);
			} else {
				throw new CMMException("Problem encountered.ReleasePlanningDAOImpl:getReleasePlanningDetails.");
			}
			if ((releasePlanning.getSelectedBUId() != null) && (releasePlanning.getSelectedBUId() > 0)) {
				ClientTO bu = (ClientTO) getEntityDetails(releasePlanning.getSelectedBUId(), ClientTO.class);
				if (bu != null) {
					releasePlanning.setSelectedBUName(bu.getName());
				}
			}
			if ((releasePlanning.getSelectedProjectId() != null) && (releasePlanning.getSelectedProjectId() > 0)) {
				ProjectsTO project = (ProjectsTO) getEntityDetails(releasePlanning.getSelectedProjectId(), ProjectsTO.class);
				if (project != null) {
					releasePlanning.setSelectedProjectName(project.getName());
				}
			}
			if ((releasePlanning.getSelectedApplicationId() != null) && (releasePlanning.getSelectedApplicationId() > 0)) {
				ApplicationTO application = (ApplicationTO) getEntityDetails(releasePlanning.getSelectedApplicationId(), ApplicationTO.class);
				if (application != null) {
					releasePlanning.setSelectedApplicationName(application.getAppName());
				}
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.ReleasePlanningDAOImpl:getReleasePlanningDetails.", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.ReleasePlanningDAOImpl:getReleasePlanningDetails.", he);
		}
		return releasePlanning;
	}
	
	@SuppressWarnings({ "deprecation", "unchecked", "rawtypes" })
	private Object getEntityDetails(Long id, Class cls) throws CMMException {
	
		Session session;
		session = getSession();
		Criteria criteria = session.createCriteria(cls, "entity");
		try {
			criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			List<Object> entityList;
			if ((id != null) && (id > 0)) {
				criteria.add(Restrictions.eq("entity.id", id));
			} else {
				throw new CMMException("Problem encountered.ReleasePlanningDAOImpl:getEntityDetails.");
			}
			entityList = criteria.list();
			if ((entityList != null) && !entityList.isEmpty()) {
				return entityList.get(0);
			} else {
				throw new CMMException("Problem encountered.ReleasePlanningDAOImpl:getEntityDetails.");
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.ReleasePlanningDAOImpl:getEntityDetails.", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.ReleasePlanningDAOImpl:getEntityDetails.", he);
		}
	}
	
	@Override
	public List<ServiceTO> getAllServices() throws CMMException {
	
		try {
			return (List<ServiceTO>) getHibernateTemplate().find("from ServiceTO where status= ? and subServiceFlag= ? order by name", CMMConstants.Framework.Entity.SERVICES_ACTIVE, CMMConstants.Framework.ServiceFlag.SUBSERVICE_FLAG_Y);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl:getAllServices()", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl:getAllServices()", he);
		}
	}
	
	@Override
	public List<ServiceTO> getAllServices(Long clientId) throws CMMException {
	
		List<ServiceTO> servTO = new ArrayList<ServiceTO>(0);
		Session session = getSession();
		try {
			String hql = "select s.id,s.name from ServiceTO s inner join s.serviceClientTO c where c.clientId=(:clientId)";
			Query q = session.createQuery(hql);
			q.setParameter("clientId", clientId);
			List<Object[]> obj = q.list();
			for (Object[] temp : obj) {
				ServiceTO services = new ServiceTO();
				services.setId((Long) temp[0]);
				services.setName(temp[1].toString());
				servTO.add(services);
			}
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl:getAllServices(Long)", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl:getAllServices(Long)", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return servTO;
	}
	
	@Override
	public List<ServiceTO> getAllServicesNew(Long clientId, Long roleId) throws CMMException {
	
		List<ServiceTO> servTO = new ArrayList<ServiceTO>(0);
		Session session = getSession();
		try {
			String hql = "select distinct s.id,s.name from ServiceTO s inner join s.serviceClientTO c where c.clientId=(:clientId) and c.roleId = (:roleId)";
			Query q = session.createQuery(hql);
			q.setParameter("clientId", clientId);
			q.setParameter("roleId", roleId);
			List<Object[]> obj = q.list();
			for (Object[] temp : obj) {
				ServiceTO services = new ServiceTO();
				services.setId((Long) temp[0]);
				services.setName(temp[1].toString());
				servTO.add(services);
			}
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl:getAllServices(Long)", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl:getAllServices(Long)", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return servTO;
	}
	
	@Override
	public List<ApplicationProfileTO> getAllProfiles(Long appId) throws CMMException {
	
		try {
			List<ApplicationProfileMappingTO> mapTOList = (List<ApplicationProfileMappingTO>) getHibernateTemplate().find("from ApplicationProfileMappingTO where applicationTO.id=?", appId);
			if ((mapTOList != null) && !mapTOList.isEmpty()) {
				List<Long> appProfileId = new ArrayList<Long>(0);
				for (ApplicationProfileMappingTO mapTo : mapTOList) {
					appProfileId.add(mapTo.getProfileId());
				}
				return (List<ApplicationProfileTO>) getHibernateTemplate().findByNamedQueryAndNamedParam("fetchProfileName", "appProfileId", appProfileId);
			}
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl:getAllProfiles(Long)", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl:getAllProfiles(Long)", he);
		}
		return new ArrayList<ApplicationProfileTO>(0);
	}
	
	@Override
	public List<ApplicationProfileTO> getAllProfiles2(Long appId) throws CMMException {
	
		try {
			List<ApplicationProfileMappingTO> mapTOList = (List<ApplicationProfileMappingTO>) getHibernateTemplate().find("from ApplicationProfileMappingTO where applicationTO.id=?", appId);
			if ((mapTOList != null) && !mapTOList.isEmpty()) {
				List<Long> appProfileId = new ArrayList<Long>(0);
				for (ApplicationProfileMappingTO mapTo : mapTOList) {
					appProfileId.add(mapTo.getProfileId());
				}
				return (List<ApplicationProfileTO>) getHibernateTemplate().findByNamedQueryAndNamedParam("fetchProfileName2", "appProfileId", appProfileId);
			}
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl:getAllProfiles(Long)", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl:getAllProfiles(Long)", he);
		}
		return new ArrayList<ApplicationProfileTO>(0);
	}
	
	@Override
	public List<EnvironmentSoftwareAttributeTO> loadAttributesDetails(Long softwareConfigId, Long environmentId) throws CMMException {
	
		List<EnvironmentSoftwareAttributeTO> softwareAttributeList;
		DetachedCriteria criteria = DetachedCriteria.forClass(EnvironmentSoftwareAttributeTO.class);
		criteria.add(Restrictions.eq("softwareConfigId", softwareConfigId));
		criteria.add(Restrictions.eq("envId", environmentId));
		try {
			softwareAttributeList = (List<EnvironmentSoftwareAttributeTO>) getHibernateTemplate().findByCriteria(criteria);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl:loadAttributesDetails", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl:loadAttributesDetails", he);
		}
		return softwareAttributeList;
	}
	
	@Override
	public boolean getInstallationStatus(Long softwareConfigId, Long environmentId) throws CMMException {
	
		List<EnvironmentDetailsTO> environmentDetailsList = new ArrayList<EnvironmentDetailsTO>();
		DetachedCriteria criteria = DetachedCriteria.forClass(EnvironmentDetailsTO.class);
		criteria.add(Restrictions.eq("mappedSoftwareId", softwareConfigId));
		criteria.add(Restrictions.eq("environment.id", environmentId));
		try {
			environmentDetailsList = (List<EnvironmentDetailsTO>) getHibernateTemplate().findByCriteria(criteria);
			if ((environmentDetailsList != null) && !environmentDetailsList.isEmpty()) {
				if ("Y".equals(environmentDetailsList.get(0).getInstallationStatus())) {
					return true;
				} else {
					return false;
				}
			} else {
				return false;
			}
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl:loadAttributesDetails", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl:loadAttributesDetails", he);
		}
	}
	
	@Override
	public boolean saveAttributesDetails(List<EnvironmentSoftwareAttributeTO> environmentSoftwareAttributeListTO) throws CMMException {
	
		for (EnvironmentSoftwareAttributeTO environmentSoftwareAttributeTO : environmentSoftwareAttributeListTO) {
			DetachedCriteria criteria = DetachedCriteria.forClass(EnvironmentSoftwareAttributeTO.class);
			criteria.add(Restrictions.eq("id", environmentSoftwareAttributeTO.getId()));
			if ((getHibernateTemplate().findByCriteria(criteria) != null) && (getHibernateTemplate().findByCriteria(criteria).size() > 0)) {
				EnvironmentSoftwareAttributeTO environmentSoftwareAttribute = (EnvironmentSoftwareAttributeTO) getHibernateTemplate().findByCriteria(criteria).get(0);
				environmentSoftwareAttribute.setAttributeValue(environmentSoftwareAttributeTO.getAttributeValue());
				getHibernateTemplate().update(environmentSoftwareAttribute);
			} else {
				return false;
			}
		}
		return true;
	}
	
	@Override
	public List<ApplicationProfileTO> getAllProfiles() throws CMMException {
	
		try {
			return (List<ApplicationProfileTO>) getHibernateTemplate().find("from ApplicationProfileTO");
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl:getAllProfiles()", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl:getAllProfiles()", he);
		}
	}
	
	@Override
	public List<TestingPhaseTO> getAllTestingCycles() throws CMMException {
	
		try {
			return (List<TestingPhaseTO>) getHibernateTemplate().find("from TestingPhaseTO");
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl:getAllTestingCycles()", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl:getAllTestingCycles()", he);
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<EnvTypeTO> getAllEnvTypes() throws CMMException {
	
		try {
			return (List<EnvTypeTO>) getHibernateTemplate().find("from EnvTypeTO");
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl:getAllEnvTypes()", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl:getAllEnvTypes()", he);
		}
	}
	
	@Override
	public int generateWorkflow(EnvironmentTO addEnv, ServiceRequestTO requestTO) throws CMMException {
	
		int success = -1;
		Session session = null;
		try {
			DetachedCriteria criteria1 = DetachedCriteria.forClass(WorkFlowLevelTO.class);
			criteria1.add(Restrictions.eq("clientId", requestTO.getClientId()));
			criteria1.add(Restrictions.eq("workflowId", requestTO.getWorkFlowId()));
			getHibernateTemplate().findByCriteria(criteria1);
			Connection conn = null;
			java.sql.CallableStatement cs = null;
			session = getSession();
			try {
				SessionFactoryImplementor sfi = (SessionFactoryImplementor) session.getSessionFactory();
				org.hibernate.connection.ConnectionProvider cp = sfi.getConnectionProvider();
				conn = cp.getConnection();
				cs = conn.prepareCall("{call initiate_workflow_environment(?,?,?,?,?)}");
				if (requestTO.getServiceId() == 8) {
					cs.setLong(1, requestTO.getPromotedEnvironment());
					cs.setLong(2, requestTO.getWorkFlowId());
					cs.setLong(3, addEnv.getCreatedById());
					cs.setLong(4, requestTO.getId());
					cs.registerOutParameter(5, java.sql.Types.INTEGER);
					cs.execute();
					success = cs.getInt(5);
				} else {
					
					
					cs.setLong(1, requestTO.getEnvironmentId());
					cs.setLong(2, requestTO.getWorkFlowId());
					cs.setLong(3, addEnv.getCreatedById());
					cs.setLong(4, requestTO.getId());
					cs.registerOutParameter(5, java.sql.Types.INTEGER);
					cs.execute();
					success = cs.getInt(5);
				}
			} finally {
				if (cs != null) {
					cs.close();
				}
				if (conn != null) {
					conn.close();
				}
			}
			if (success == 1) {
				WorkflowCurrentTO workflowCurrentTo = (WorkflowCurrentTO) getHibernateTemplate().find("from WorkflowCurrentTO where serviceRequestId=?", requestTO.getId()).get(0);
				if (workflowCurrentTo.getWfStatusTO().getId() == 3L) {
					return -1;
				}
			}
			return success;
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl:generateWorkflow", dae);
		} catch (SQLException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl:generateWorkflow", e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public boolean defineApplicationsForEnvironment(EnvironmentApplicationTO mapping) throws CMMException {
	
		boolean flag = false;
		Session session = null;
		try {
			session = getSession();
			String hql = "from ApplicationTO where id in (:ApplicationId)";
			Query q = session.createQuery(hql);
			q.setParameterList("ApplicationId", mapping.getDefinedApplications());
			List<Object[]> obj = q.list();
			EnvironmentApplicationTO envMappingTO = new EnvironmentApplicationTO();
			for (Object app : obj) {
				envMappingTO.setApplicationTO((ApplicationTO) app);
				envMappingTO.getEnvironmentTO().setId(mapping.getEnvironmentTO().getId());
				getHibernateTemplate().save(envMappingTO);
			}
			flag = true;
			return flag;
		} catch (ConstraintViolationException ce) {
			throw new CMMException("problem encountered ServiceRequestDAOImpl:defineApplicationsForEnvironment", ce);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl:defineApplicationsForEnvironment", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl:defineApplicationsForEnvironment", he);
		} catch (Exception e) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl:defineApplicationsForEnvironment", e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	public List<ApplicationProfileDetailsTO> fetchProfileDetails(Long id) throws CMMException {
	
		try {
			List<ApplicationProfileDetailsTO> temp = new ArrayList<ApplicationProfileDetailsTO>(0);
			List<Object[]> objList = (List<Object[]>) getHibernateTemplate().find("from ApplicationProfileDetailsTO a inner join a.profile b  where b.id=?", id);
			for (Object[] list : objList) {
				temp.add((ApplicationProfileDetailsTO) list[0]);
			}
			return temp;
		} catch (DataAccessException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl:fetchProfileDetails", e);
		} catch (HibernateException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl:fetchProfileDetails", e);
		}
	}
	
	@Override
	public List<EnvironmentApplicationTO> getAllReleasesforAppEnv(Long envid, Long appid) throws CMMException {
	
		try {
			return (List<EnvironmentApplicationTO>) getHibernateTemplate().find("from EnvironmentApplicationTO where applicationTO.id=? and environmentTO.id=?", appid, envid);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl:getAllReleasesforAppEnv", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl:getAllReleasesforAppEnv", he);
		}
	}
	
	@Override
	public ApplicationReleaseTO fetchParentRelease(Long subrel) throws CMMException {
	
		try {
			return (ApplicationReleaseTO) getHibernateTemplate().find("from ApplicationReleaseTO where id=?", subrel).get(0);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl:fetchParentRelease", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl:fetchParentRelease", he);
		}
	}
	
	@Override
	public List<ApplicationReleaseTO> getAllApplicationReleases(Long applicationProfileId) throws CMMException {
	
		try {
			return (List<ApplicationReleaseTO>) getHibernateTemplate().find("from ApplicationReleaseTO where applicationProfileId=?", applicationProfileId);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getAllApplicationReleases", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getAllApplicationReleases", he);
		}
	}
	
	@Override
	public List<ServiceRequestTO> searchServiceRequestList(ServiceRequestTO serviceRequestTO) throws CMMException {
	
		try {
			List<ServiceRequestTO> servicerequestList = new ArrayList<ServiceRequestTO>(0);
			DetachedCriteria criteria = DetachedCriteria.forClass(ServiceRequestTO.class);
			criteria.add(Restrictions.ne("statusId", CMMConstants.Framework.Entity.SERVICE_REQUEST_NOT_SUBMITTED));
			Date dateFrom = null;
			Date dateTo = null;
			Calendar cal = Calendar.getInstance();
			String formatedFromDate = null;
			String formatedToDate = null;
			DateFormat formatter1 = new SimpleDateFormat("yyyy-MM-dd");
			if (serviceRequestTO.getStartTime() != null) {
				try {
					cal.setTime(serviceRequestTO.getStartTime());
					formatedFromDate = cal.get(Calendar.YEAR) + "-" + (cal.get(Calendar.MONTH) + 1) + "-" + cal.get(Calendar.DATE);
					dateFrom = formatter1.parse(formatedFromDate);
				} catch (ParseException e) {
					throw new CMMException("Error parsing date ", e);
				}
			}
			if (serviceRequestTO.getEndTime() != null) {
				try {
					cal.setTime(serviceRequestTO.getEndTime());
					formatedToDate = cal.get(Calendar.YEAR) + "-" + (cal.get(Calendar.MONTH) + 1) + "-" + cal.get(Calendar.DATE);
					dateTo = formatter1.parse(formatedToDate);
				} catch (ParseException e) {
					throw new CMMException("Error parsing date ", e);
				}
			}
			if (serviceRequestTO.getUserId() == 1) {
				if (((serviceRequestTO.getRequestId() != null) && (serviceRequestTO.getRequestId() != 0)) || (serviceRequestTO.getSelectedService() > 0L) || (serviceRequestTO.getStartTime() != null) || (serviceRequestTO.getEndTime() != null)) {
					if ((serviceRequestTO.getRequestId() != null) && (serviceRequestTO.getRequestId() != 0)) {
						criteria.add(Restrictions.eq("id", serviceRequestTO.getRequestId()));
					}
					if (serviceRequestTO.getSelectedService() > 0L) {
						criteria.add(Restrictions.eq("serviceTO.id", serviceRequestTO.getSelectedService()));
					}
					if (serviceRequestTO.getStartTime() != null) {
						criteria.add(Restrictions.ge("createdByDate", dateFrom));
					}
					if (serviceRequestTO.getEndTime() != null) {
						criteria.add(Restrictions.le("createdByDate", dateTo));
					}
				} else {
					if ((serviceRequestTO.getRequestId() != null) && (serviceRequestTO.getRequestId() != 0)) {
						criteria.add(Restrictions.eq("id", serviceRequestTO.getRequestId()));
					}
					if (serviceRequestTO.getSelectedService() > 0L) {
						criteria.add(Restrictions.eq("serviceTO.id", serviceRequestTO.getSelectedService()));
					}
					if (serviceRequestTO.getStartTime() != null) {
						criteria.add(Restrictions.ge("createdByDate", dateFrom));
					}
					if (serviceRequestTO.getEndTime() != null) {
						criteria.add(Restrictions.le("createdByDate", dateTo));
					}
					criteria.addOrder(Order.asc("id"));
					if (serviceRequestTO.getSearchCount() == 0) {
						return (List<ServiceRequestTO>) getHibernateTemplate().findByCriteria(criteria);
					}
					Session session = getSession();
					criteria.getExecutableCriteria(session).setFirstResult(serviceRequestTO.getFirstResult());
					criteria.getExecutableCriteria(session).setMaxResults(serviceRequestTO.getTableSize());
					List<ServiceRequestTO> temp = (List<ServiceRequestTO>) getHibernateTemplate().findByCriteria(criteria);
					for (ServiceRequestTO hd : temp) {
						if (hd.getCreatedByDate() != null) {
							hd.setCreatedByDateStr(DateUtils.getjQueryDateTimeNew(hd.getCreatedByDate()));
						}
						servicerequestList.add(hd);
					}
					return servicerequestList;
				}
			} else {
				if ((serviceRequestTO.getRequestId() != null) && (serviceRequestTO.getRequestId() != 0)) {
					criteria.add(Restrictions.eq("id", serviceRequestTO.getRequestId()));
				}
				if (serviceRequestTO.getSelectedService() > 0L) {
					criteria.add(Restrictions.eq("serviceTO.id", serviceRequestTO.getSelectedService()));
				}
				criteria.add(Restrictions.eq("createdById", serviceRequestTO.getUserId()));
				if (serviceRequestTO.getStartTime() != null) {
					criteria.add(Restrictions.ge("createdByDate", dateFrom));
				}
				if (serviceRequestTO.getEndTime() != null) {
					criteria.add(Restrictions.le("createdByDate", dateTo));
				}
			}
			criteria.addOrder(Order.asc("id"));
			if (serviceRequestTO.getSearchCount() == 0) {
				return (List<ServiceRequestTO>) getHibernateTemplate().findByCriteria(criteria);
			}
			Session session = getSession();
			criteria.getExecutableCriteria(session).setFirstResult(serviceRequestTO.getFirstResult());
			criteria.getExecutableCriteria(session).setMaxResults(serviceRequestTO.getTableSize());
			List<ServiceRequestTO> temp = (List<ServiceRequestTO>) getHibernateTemplate().findByCriteria(criteria);
			for (ServiceRequestTO hd : temp) {
				if (hd.getCreatedByDate() != null) {
					hd.setCreatedByDateStr(DateUtils.getjQueryDateTimeNew(hd.getCreatedByDate()));
				}
				servicerequestList.add(hd);
			}
			return servicerequestList;
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl: searchServiceRequestList", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl: searchServiceRequestList", he);
		}
	}
	
	@Override
	public List<ServiceRequestTO> searchCompletedServiceStatus(ServiceRequestTO serviceRequestTO) throws CMMException {
	
		try {
			return (List<ServiceRequestTO>) getHibernateTemplate().find("from ServiceRequestTO where statusId= ?", serviceRequestTO.getStatus());
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl: searchCompletedServiceStatus", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl: searchCompletedServiceStatus.", he);
		}
	}
	
	@Override
	public String getRelease(String appName1) throws CMMException {
	
		try {
			Long appId = (Long) getHibernateTemplate().find("select a.id from ApplicationTO a where a.appName =?", appName1).get(0);
			return (String) getHibernateTemplate().find("select ar.name from ApplicationReleaseTO ar where ar.applicationTO.id =?", appId).get(0);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl: getRelease", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl: getRelease", he);
		} catch (Exception e) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl: getRelease", e);
		}
	}
	
	@Override
	public List<MultipleProfilesTO> searchMultipleProfileList(MultipleProfilesTO multipleProfilesTO) throws CMMException {
	
		try {
			List<MultipleProfilesTO> multipleprofileList = new ArrayList<MultipleProfilesTO>(0);
			DetachedCriteria criteria = DetachedCriteria.forClass(MultipleProfilesTO.class);
			List<MultipleProfilesTO> temp = (List<MultipleProfilesTO>) getHibernateTemplate().findByCriteria(criteria);
			for (MultipleProfilesTO hd : temp) {
				multipleprofileList.add(hd);
			}
			return multipleprofileList;
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl: searchMultipleProfileList", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl: searchMultipleProfileList.", he);
		}
	}
	
	@Override
	public List<ServiceRequestHistoryTO> getRequestDetails(Long selectRequestId) throws CMMException {
	
		try {
			return (List<ServiceRequestHistoryTO>) getHibernateTemplate().find("from ServiceRequestHistoryTO where RequestId =? group by comments order by id desc", selectRequestId);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getRequestDetails", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl: getRequestDetails", he);
		}
	}
	
	@Override
	public List<ServiceRequestHistoryTO> getRequestDetailsForPipeline(Long selectRequestId) throws CMMException {
	
		try {
			return (List<ServiceRequestHistoryTO>) getHibernateTemplate().find("from ServiceRequestHistoryTO where RequestId =? order by id desc", selectRequestId);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getRequestDetails", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl: getRequestDetails", he);
		}
	}
	
	@Override
	public List<ApplicationTO> getAllApplications(Long environmentId) throws CMMException {
	
		try {
			List<EnvironmentApplicationTO> environmentApplicationTOList = (List<EnvironmentApplicationTO>) getHibernateTemplate().find("from EnvironmentApplicationTO where environmentTO.id =? order by id desc", environmentId);
			List<ApplicationTO> applicationTOList = new ArrayList<ApplicationTO>(0);
			for (EnvironmentApplicationTO environmentApplicationTO : environmentApplicationTOList) {
				ApplicationTO applicationTo = environmentApplicationTO.getApplicationTO();
				applicationTOList.add(applicationTo);
			}
			return applicationTOList;
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getRequestDetails", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl: getRequestDetails", he);
		}
	}
	
	@Override
	public List<QuartzHistoryTO> fetchSchedulingRequestDetails(Long selectRequestId) throws CMMException {
	
		try {
			return (List<QuartzHistoryTO>) getHibernateTemplate().find("from QuartzHistoryTO where requestId =? order by firedTime", selectRequestId);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getRequestDetails", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl: getRequestDetails", he);
		}
	}
	
	@Override
	public Long getWorkflowIdforCA(Long id) throws CMMException {
	
		Long workflowId;
		try {
			workflowId = (Long) getHibernateTemplate().find("select w.id from WorkflowCurrentTO w where w.serviceRequestId=?", id).get(0);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getRequestDetails", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl: getRequestDetails", he);
		} catch (IndexOutOfBoundsException cmm) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl: getRequestDetails", cmm);
		}
		return workflowId;
	}
	
	@Override
	public VMDetailsTO fetchVMDetail(Long selectedEnvironment, Long hardwareid, Long serverGpNum) throws CMMException {
	
		try {
			List<VMDetailsTO> vmList = (List<VMDetailsTO>) getHibernateTemplate().find("from VMDetailsTO where environmentId =? and serverTemplateId=? and serverGroupId=?", selectedEnvironment, hardwareid, serverGpNum);
			if (!vmList.isEmpty()) {
				return vmList.get(0);
			}
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: fetchVMDetail", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: fetchVMDetail", he);
		}
		return null;
	}
	
	@Override
	public ApplicationProfileTO fetchMultiEnvReqDetails(Long selectRequestId) throws CMMException {
	
		try {
			List<ApplicationProfileTO> appProfileList = (List<ApplicationProfileTO>) getHibernateTemplate().find("from ApplicationProfileTO where id =?", selectRequestId);
			if (!appProfileList.isEmpty()) {
				return appProfileList.get(0);
			}
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl: fetchMultiEnvReqDetails", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: fetchMultiEnvReqDetails", he);
		}
		return null;
	}
	
	@Override
	public List<MultipleProfileDetailsTO> searchMultiEnvReqList(MultipleProfileDetailsTO multipleProfileDetailsTO) throws CMMException {
	
		List<MultipleProfileDetailsTO> multiEnvList = null;
		try {
			multiEnvList = (List<MultipleProfileDetailsTO>) getHibernateTemplate().find("from MultipleProfileDetailsTO where selectedMultipleProfile =?", multipleProfileDetailsTO.getSelectedMultipleProfile());
			return multiEnvList;
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: searchMultiEnvReqList", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: searchMultiEnvReqList", he);
		}
	}
	
	@Override
	public ServiceRequestTO addSubAppDetails(MultipleProfileDetailsTO multipleProfileDetailsTO) throws CMMException {
	
		Session session = null;
		ServiceRequestTO requestTO1 = new ServiceRequestTO();
		int success = -1;
		try {
			session = getSession();
			Long serverGroupCheck = null;
			Long provisionedMachineId = null;
			Long provisionedPlatformId = null;
			EnvironmentTO envTO = new EnvironmentTO();
			if (multipleProfileDetailsTO.getEnvName() != null) {
				envTO.setCreatedById(multipleProfileDetailsTO.getCreatedById());
				envTO.setCreatedByDate(DateUtils.getStartTime(new Date()));
				envTO.setModifiedbyId(multipleProfileDetailsTO.getModifiedbyId());
				envTO.setModifiedbyDate(DateUtils.getStartTime(new Date()));
				envTO.setStatus(23L);
				envTO.setEnvironmentName(multipleProfileDetailsTO.getEnvName());
				envTO.setEnvTypeId(multipleProfileDetailsTO.getSelectedEnvType());
				envTO.setTaggedProjects(multipleProfileDetailsTO.getTaggedProjects());
				envTO.setServiceId(multipleProfileDetailsTO.getSelectedService());
				getHibernateTemplate().save(envTO);
				EnvironmentTO e1 = (EnvironmentTO) getHibernateTemplate().find(" from EnvironmentTO where environmentName =?", multipleProfileDetailsTO.getEnvName()).get(0);
				EnvironmentTO envTO1 = null;
				for (MultipleProfileDetailsTO det : multipleProfileDetailsTO.getMpList()) {
					if (det.isDoProvisioning()) {
						envTO1 = new EnvironmentTO();
						envTO1.setCreatedById(multipleProfileDetailsTO.getCreatedById());
						envTO1.setCreatedByDate(DateUtils.getStartTime(new Date()));
						envTO1.setModifiedbyId(multipleProfileDetailsTO.getModifiedbyId());
						envTO1.setModifiedbyDate(DateUtils.getStartTime(new Date()));
						envTO1.setReservationCheck("N");
						if (det.isDoMonitoring()) {
							envTO1.setMonitoringRequired("Y");
						} else {
							envTO1.setMonitoringRequired("N");
						}
						if ((multipleProfileDetailsTO.getRoleId() == 0L) || (multipleProfileDetailsTO.getRoleId() == 1L)) {
							envTO1.setStatus(23L);
						} else {
							envTO1.setStatus(25L);
						}
						envTO1.setEnvironmentName(det.getSubApplication());
						envTO1.setEnvTypeId(multipleProfileDetailsTO.getSelectedEnvType());
						envTO1.setProfileId(det.getSelectedProfiles());
						envTO1.setServiceId(multipleProfileDetailsTO.getSelectedService());
						serverGroupCheck = null;
						List<ApplicationProfileDetailsTO> profDetails = fetchProfileDetails(det.getSelectedProfiles());
						for (ApplicationProfileDetailsTO sf : profDetails) {
							EnvironmentDetailsTO environmentDetailsTO1 = new EnvironmentDetailsTO();
							environmentDetailsTO1.setMappedSoftwareId(sf.getMappedSoftwareId());
							environmentDetailsTO1.setServerGroup(sf.getServerGroup());
							environmentDetailsTO1.setInstallationRequired(sf.getInstallRequired());
							environmentDetailsTO1.setInstallationStatus("N");
							if ("N".equalsIgnoreCase(sf.getExistingMachineFlag())) {
								if (!sf.getServerGroup().equals(serverGroupCheck)) {
									provisionedPlatformId = maintainPlatformTemplateVersions(sf.getPlatformTemplateId());
									provisionedMachineId = maintainMachineTemplateVersions(provisionedPlatformId, sf.getMachineTemplateId(), sf.getServerGroup(), sf.getProfileId());
									serverGroupCheck = sf.getServerGroup();
								}
							} else {
								provisionedPlatformId = sf.getExistingPlatformId();
								provisionedMachineId = sf.getExistingMachineId();
							}
							environmentDetailsTO1.setProvisionedPlatformId(provisionedPlatformId);
							environmentDetailsTO1.setProvisionedMachineId(provisionedMachineId);
							environmentDetailsTO1.setEnvironment(envTO1);
							envTO1.getEnvironmentDetails().add(environmentDetailsTO1);
						}
						Long subEnvId = (Long) getHibernateTemplate().save(envTO1);
						saveEnvSoftwareAttributes(det, subEnvId);
						EnvironmentApplicationTO envAppTO = new EnvironmentApplicationTO();
						ApplicationTO appTO = new ApplicationTO();
						appTO.setId(det.getSelectedApplication());
						envAppTO.setApplicationTO(appTO);
						envAppTO.setEnvironmentTO(envTO1);
						envAppTO.setSelectedTestingPhase(det.getSelectedTestingPhase());
						ApplicationReleaseTO apprel = new ApplicationReleaseTO();
						if ((det.getSelectedApplicationReleaseMinor() != null) && (det.getSelectedApplicationReleaseMinor() > 0)) {
							apprel.setId(det.getSelectedApplicationReleaseMinor());
							envAppTO.setApplicationReleaseTO(apprel);
						} else if ((det.getSelectedApplicationRelease() != null) && (det.getSelectedApplicationRelease() > 0)) {
							apprel.setId(det.getSelectedApplicationRelease());
							envAppTO.setApplicationReleaseTO(apprel);
						} else {
							envAppTO.setApplicationReleaseTO(null);
						}
						envTO1.getEnvironmentApplicationTO().add(envAppTO);
						getHibernateTemplate().update(envTO1);
						SubEnvironmentMappingTO subEnvironmentMappingTO = new SubEnvironmentMappingTO();
						subEnvironmentMappingTO.setEnvironmentId(e1.getId());
						subEnvironmentMappingTO.setSubEnvronmentId(subEnvId);
						getHibernateTemplate().save(subEnvironmentMappingTO);
					} else {
						envTO1 = new EnvironmentTO();
						envTO1 = (EnvironmentTO) getHibernateTemplate().find("from EnvironmentTO where id=?", det.getSubEnvId()).get(0);
						envTO1.setReservationCheck("Y");
						getHibernateTemplate().update(envTO1);
						saveEnvSoftwareAttributes(det, envTO1.getId());
						SubEnvironmentMappingTO subEnvironmentMappingTO = new SubEnvironmentMappingTO();
						subEnvironmentMappingTO.setEnvironmentId(e1.getId());
						subEnvironmentMappingTO.setSubEnvronmentId(det.getSubEnvId());
						getHibernateTemplate().save(subEnvironmentMappingTO);
					}
				}
				for (MultipleProfileDetailsTO multipleProfileDetails : multipleProfileDetailsTO.getMpList()) {
					EnvironmentApplicationTO parentEnvAppTO = new EnvironmentApplicationTO();
					parentEnvAppTO.setEnvironmentTO(e1);
					ApplicationTO appTO = new ApplicationTO();
					appTO.setId(multipleProfileDetails.getSelectedApplication());
					parentEnvAppTO.setApplicationTO(appTO);
					ApplicationReleaseTO applicationReleaseTO = new ApplicationReleaseTO();
					applicationReleaseTO.setId(multipleProfileDetails.getSelectedApplicationRelease());
					parentEnvAppTO.setApplicationReleaseTO(applicationReleaseTO);
					parentEnvAppTO.setSelectedTestingPhase(multipleProfileDetails.getSelectedTestingPhase());
					getHibernateTemplate().save(parentEnvAppTO);
				}
				requestTO1.setStatusId(141L);
				requestTO1.setServiceId(multipleProfileDetailsTO.getSelectedService());
				requestTO1.setActionFlag("Y");
				requestTO1.setEnvironmentId(e1.getId());
				requestTO1.setCreatedById(multipleProfileDetailsTO.getCreatedById());
				requestTO1.setCreatedByDate(DateUtils.getStartTime(new Date()));
				requestTO1.setModifiedbyId(multipleProfileDetailsTO.getModifiedbyId());
				requestTO1.setModifiedbyDate(DateUtils.getStartTime(new Date()));
				requestTO1.setClientId(multipleProfileDetailsTO.getClientId());
				requestTO1.setWorkFlowId(multipleProfileDetailsTO.getWorkFlowId());
				requestTO1.setRemark(multipleProfileDetailsTO.getRemark());
				requestTO1.setStartTime(multipleProfileDetailsTO.getStartTime());
				requestTO1.setEndTime(multipleProfileDetailsTO.getEndTime());
				requestTO1.setIsScheduled(multipleProfileDetailsTO.getIsScheduled());
				requestTO1.setCronExp(multipleProfileDetailsTO.getCronExp());
				getHibernateTemplate().save(requestTO1);
				requestTO1.setSuccess(success);
				if (requestTO1.getClientId() != 0) {
					success = generateWorkflow(envTO1, requestTO1);
					requestTO1.setSuccess(success);
				}
				if (success == -1) {
					for (MultipleProfileDetailsTO multipleProfileDetails : multipleProfileDetailsTO.getMpList()) {
						if (multipleProfileDetails.isDoProvisioning()) {
							Long envStatus = CMMConstants.Framework.Entity.ENVIRONMENT_STATUS_UNDERIMPLEMENTATION;
							Long reqStatus = CMMConstants.Framework.Entity.SERVICE_REQUEST_UNDER_IMPLEMENTATION;
							session.createQuery("update EnvironmentTO e set e.status=? where e.id = ? ").setParameter(0, envStatus).setParameter(1, envTO1.getId()).executeUpdate();
							session.createQuery("update EnvironmentTO e set e.status=? where e.id = ? ").setParameter(0, envStatus).setParameter(1, envTO.getId()).executeUpdate();
							session.createQuery("update ServiceRequestTO r set r.statusId=? where r.id = ? ").setParameter(0, reqStatus).setParameter(1, requestTO1.getId()).executeUpdate();
							requestTO1.setSuccess(success);
							return requestTO1;
						} else {
							Long envStatus = CMMConstants.Framework.Entity.ENVIRONMENT_STATUS_AVAILABLE;
							Long reqStatus = CMMConstants.Framework.Entity.SERVICE_REQUEST_UNDER_IMPLEMENTATION;
							session.createQuery("update EnvironmentTO e set e.status=? where e.id = ? ").setParameter(0, envStatus).setParameter(1, envTO1.getId()).executeUpdate();
							session.createQuery("update EnvironmentTO e set e.status=? where e.id = ? ").setParameter(0, envStatus).setParameter(1, envTO.getId()).executeUpdate();
							session.createQuery("update ServiceRequestTO r set r.statusId=? where r.id = ? ").setParameter(0, reqStatus).setParameter(1, requestTO1.getId()).executeUpdate();
							requestTO1.setSuccess(success);
							return requestTO1;
						}
					}
				}
				return requestTO1;
			}
		} catch (ConstraintViolationException e) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl: addSubAppDetails.", e);
		} catch (DataIntegrityViolationException div) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl: addSubAppDetails", div);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: addSubAppDetails", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: addSubAppDetails", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return null;
	}
	
	private void saveEnvSoftwareAttributes(MultipleProfileDetailsTO det, Long envId) throws CMMException {
	
		for (EnvironmentSoftwareAttributeTO envSoftwareAttributeTO : det.getEnvSoftwareAttributeList()) {
			envSoftwareAttributeTO.setEnvId(envId);
			getHibernateTemplate().save(envSoftwareAttributeTO);
		}
	}
	
	@Override
	public List<MultipleProfileDetailsTO> searchMultiEnvReqListDetails(MultipleProfileDetailsTO multipleProfileDetailsTO) throws CMMException {
	
		List<MultipleProfileDetailsTO> multiEnvList = new ArrayList<MultipleProfileDetailsTO>(0);
		List<MultipleProfileDetailsTO> multiEnvListNew = new ArrayList<MultipleProfileDetailsTO>(0);
		try {
			List<Object[]> objList = (List<Object[]>) getHibernateTemplate().find("from MultipleProfileDetailsTO a inner join a.profile b inner join a.applicationTO c where a.selectedMultipleProfile =?", multipleProfileDetailsTO.getSelectedMultipleProfile());
			if (!objList.isEmpty()) {
				for (Object[] list : objList) {
					multiEnvList.add((MultipleProfileDetailsTO) list[0]);
				}
				for (MultipleProfileDetailsTO mp : multiEnvList) {
					mp.setMultipleProfileId(mp.getSelectedMultipleProfile());
					mp.setAppName(mp.getApplicationTO().getAppName());
					mp.setProfileName(mp.getProfile().getName());
					mp.setProfileId(mp.getProfile().getId());
					multiEnvListNew.add(mp);
				}
				return multiEnvListNew;
			} else {
				return new ArrayList<MultipleProfileDetailsTO>(0);
			}
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: searchMultiEnvReqListDetails", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: searchMultiEnvReqListDetails", he);
		}
	}
	
	@Override
	public void updateServiceRequest(String flag, Long requestId) throws CMMException {
	
		try {
			ServiceRequestTO serviceRequest = (ServiceRequestTO) getHibernateTemplate().find("from ServiceRequestTO where id=?", requestId).get(0);
			serviceRequest.setActionFlag(flag);
			if (flag.equalsIgnoreCase(CMMConstants.Framework.ServiceRequestStatus.SERVICE_REQUEST_COMPLETED)) {
				serviceRequest.setStatusId(143L);
			} else if (flag.equalsIgnoreCase(CMMConstants.Framework.ServiceRequestStatus.SERVICE_REQUEST_ERROR)) {
				serviceRequest.setStatusId(143L);
			}
			getHibernateTemplate().update(serviceRequest);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: updateServiceRequest", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: updateServiceRequest", he);
		}
	}
	
	@Override
	public List<EnvironmentTO> getAllEnvironments(Long selectedProfile) throws CMMException {
	
		try {
			return (List<EnvironmentTO>) getHibernateTemplate().find("select DISTINCT e from EnvironmentTO e,EnvironmentDetailsTO ed, ProvisionedMachineTO pm where e.profileId=? and e.status=? and ed.environment.id=e.id and pm.ip is not null and ed.provisionedMachineId=pm.id", selectedProfile, Framework.Entity.ENVIRONMENT_AVAILABLE);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getAllEnvironments", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getAllEnvironments", he);
		}
	}
	
	@Override
	public List<EnvironmentTO> getAllVirtualEnvironments(Long selectedProfile) throws CMMException {
	
		try {
			return (List<EnvironmentTO>) getHibernateTemplate().find("select DISTINCT e from EnvironmentTO e, EnvironmentDetailsTO ed, ProvisionedMachineTO pm where e.profileId=? and e.status=? and ed.environment.id=e.id and pm.provisionedMachineType=? and pm.ip is not null and ed.provisionedMachineId=pm.id", selectedProfile, Framework.Entity.ENVIRONMENT_AVAILABLE, "VIRTUAL");
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getAllEnvironments", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getAllEnvironments", he);
		}
	}
	
	@Override
	public List<EnvironmentTO> getAllEnvironmentsForUndeployment(Long selectedProfile) throws CMMException {
	
		try {
			return (List<EnvironmentTO>) getHibernateTemplate().find("select DISTINCT e from EnvironmentTO e, EnvironmentApplicationTO ea where e.profileId=? and e.status=? and ea.environmentTO.id = e.id and ea.releaseId is not null", selectedProfile, Framework.Entity.ENVIRONMENT_AVAILABLE);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getAllEnvironments", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getAllEnvironments", he);
		}
	}
	
	@Override
	public List<EnvironmentTO> getEnvironmentsWithSourceCodeForUndeployment(Long selectedProfile) throws CMMException {
	
		List<EnvironmentTO> envFinal = new ArrayList<EnvironmentTO>();
		try {
			List<EnvironmentTO> env = (List<EnvironmentTO>) getHibernateTemplate().find("select DISTINCT e from EnvironmentTO e, EnvironmentApplicationTO ea where e.profileId=? and e.status=? and ea.environmentTO.id = e.id and ea.releaseId is not null", selectedProfile, Framework.Entity.ENVIRONMENT_AVAILABLE);
			if (env != null) {
				if (!env.isEmpty()) {
					for (EnvironmentTO en : env) {
						List<ApplicationReleaseSourcecodeTO> envLst = (List<ApplicationReleaseSourcecodeTO>) getHibernateTemplate().find("select DISTINCT source from ApplicationReleaseSourcecodeTO source, EnvironmentApplicationTO ea where source.applicationReleaseId = ea.releaseId and ea.environmentTO.id =?", en.getId());
						if (envLst != null) {
							if (!envLst.isEmpty()) {
								envFinal.add(en);
							}
						}
					}
				}
			}
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getAllEnvironments", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getAllEnvironments", he);
		}
		return envFinal;
	}
	
	@Override
	public List<EnvironmentTO> getAllEnvironmentsForApplicationReleaseRollback(Long selectedProfile) throws CMMException {
	
		try {
			return (List<EnvironmentTO>) getHibernateTemplate().find("select e from EnvironmentTO e ,EnvironmentApplicationTO ea where e.profileId=? and e.status=? and ea.releaseId is not null and e.id=ea.environmentTO.id", selectedProfile, Framework.Entity.ENVIRONMENT_AVAILABLE);
		} catch (ConstraintViolationException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: editVM", e);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getAllEnvironments", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getAllEnvironments", he);
		} catch (Exception e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: restartServer", e);
		}
	}
	
	@Override
	public List<EnvironmentTO> getAllEnvironmentsAccToPhases(Long selectedProfile, Long selectedTestingCycle) throws CMMException {
	
		try {
			return (List<EnvironmentTO>) getHibernateTemplate().find("from EnvironmentTO where profileId=? and status=?", selectedProfile, Framework.Entity.ENVIRONMENT_AVAILABLE);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getAllEnvironmentsAccToPhases", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getAllEnvironmentsAccToPhases", he);
		}
	}
	
	@Override
	public List<EnvironmentTO> getAllEnvironmentsAccToPhasesForTC(Long selectedTestingCycle) throws CMMException {
	
		try {
			return (List<EnvironmentTO>) getHibernateTemplate().find("from EnvironmentTO where status=?", Framework.Entity.ENVIRONMENT_AVAILABLE);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getAllEnvironmentsAccToPhasesForTC", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getAllEnvironmentsAccToPhasesForTC", he);
		}
	}
	
	@Override
	public List<ProvisionedMachineTO> fetchVMDetails(Long id) throws CMMException {
	
		try {
			String machineType = "";
			Long provId;
			String query = "select  ed.provisionedMachineId from EnvironmentTO e,EnvironmentDetailsTO ed where e.id=ed.environment.id  and e.id=?";
			provId = (Long) getHibernateTemplate().find(query, id).get(0);
			if (provId != null) {
				String query2 = "select p.virtualMachineType from ProvisionedMachineTO p where p.id=?";
				machineType = (String) getHibernateTemplate().find(query2, provId).get(0);
			}
			List<ProvisionedMachineTO> provisionedMachineList = new ArrayList<ProvisionedMachineTO>(0);
			DetachedCriteria criteria = DetachedCriteria.forClass(EnvironmentTO.class, "env");
			criteria.add(Restrictions.eq("env.id", id));
			criteria.createAlias("environmentDetails", "ed", CriteriaSpecification.INNER_JOIN);
			criteria.createAlias("ed.provisionedMachine", "pm", CriteriaSpecification.INNER_JOIN);
			if (machineType != null) {
				if (machineType.equalsIgnoreCase(CMMConstants.Framework.MachineTypes.MACHINE_TYPE_OPENSTACK)) {
					criteria.createAlias("pm.provisionedMachineOSTOSet", "pmos", CriteriaSpecification.INNER_JOIN);
				}
			}
			criteria.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);
			List<EnvironmentTO> environmentTO = (List<EnvironmentTO>) getHibernateTemplate().findByCriteria(criteria);
			for (EnvironmentTO pv : environmentTO) {
				List<EnvironmentDetailsTO> envDetailsList = new ArrayList<EnvironmentDetailsTO>(pv.getEnvironmentDetails());
				for (EnvironmentDetailsTO envDetails : envDetailsList) {
					provisionedMachineList.add(envDetails.getProvisionedMachine());
				}
			}
			HashSet<ProvisionedMachineTO> hashSet = new HashSet<ProvisionedMachineTO>(0);
			hashSet.addAll(provisionedMachineList);
			provisionedMachineList.clear();
			provisionedMachineList.addAll(hashSet);
			return provisionedMachineList;
		} catch (DataAccessException | HibernateException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: fetchVMDetails", e);
		}
	}
	
	@Override
	public List<ProvisionedMachineTO> getVMDetailsForAppDashboard(Long id) throws CMMException {
	
		List<ProvisionedMachineTO> list2 = new ArrayList<ProvisionedMachineTO>(0);
		List<EnvironmentDetailsTO> list1 = (List<EnvironmentDetailsTO>) getHibernateTemplate().find("select e from EnvironmentDetailsTO e where e.provisionedMachine.id is not null and e.environment.id=?", id);
		if (!list1.isEmpty()) {
			list2 = (List<ProvisionedMachineTO>) getHibernateTemplate().find("select p from ProvisionedMachineTO p where p.id=?", list1.get(0).getProvisionedMachineId());
		}
		return list2;
	}
	
	@Override
	public ServiceRequestTO editVM(ServiceRequestTO requestTO) throws CMMException {
	
		try {
			getHibernateTemplate().save(requestTO);
			for (ProvisionedMachineTO details : requestTO.getProvisionedMachineDetails()) {
				ServiceRequestDetailsTO reqDetailsTO = new ServiceRequestDetailsTO();
				reqDetailsTO.setRequestId(requestTO.getId());
				reqDetailsTO.setProvisionedMachineId(details.getId());
				getHibernateTemplate().save(reqDetailsTO);
			}
			for (ProvisionedMachineTO details : requestTO.getProvisionedMachineDetails()) {
				ProvisionedMachineTO vmTO = (ProvisionedMachineTO) getHibernateTemplate().find(" from ProvisionedMachineTO where id =?", details.getId()).get(0);
				vmTO.setCPU(details.getCPU());
				vmTO.setRAM(details.getRAM());
				vmTO.setServiceRequestId(requestTO.getId());
				getHibernateTemplate().update(vmTO);
				String type = vmTO.getVirtualMachineType();
				if (type != null) {
					if (type.equalsIgnoreCase(CMMConstants.Framework.MachineTypes.MACHINE_TYPE_OPENSTACK)) {
						ProvisionedMachineOSTO provisionedMachineOSTO = vmTO.getProvisionedMachineOSTOSet().iterator().next();
						provisionedMachineOSTO.setFlavorId(details.getSelectedFlavorId());
						provisionedMachineOSTO.setFlavorType(details.getSelectedFlavorType());
						provisionedMachineOSTO.setDisk(details.getCurrentDisk());
						getHibernateTemplate().update(provisionedMachineOSTO);
					}
				}
			}
			int success = -1;
			EnvironmentTO envTO = new EnvironmentTO();
			envTO.setId(requestTO.getEnvironmentId());
			envTO.setCreatedById(requestTO.getCreatedById());
			requestTO.setSuccess(success);
		} catch (ConstraintViolationException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: editVM", e);
		} catch (DataAccessException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: editVM", e);
		} catch (HibernateException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: editVM", e);
		}
		return requestTO;
	}
	
	@Override
	public ServiceRequestTO restartServer(ServiceRequestTO requestTO) throws CMMException {
	
		try {
			ServiceRequestDetailsTO serReqDetTo = new ServiceRequestDetailsTO();
			getHibernateTemplate().save(requestTO);
			for (ServiceRequestTO reqTo : requestTO.getAppSerSoftListForm()) {
				serReqDetTo.setProfileId(requestTO.getSelectedProfiles());
				serReqDetTo.setEnvironmentId(requestTO.getSelectedEnvironment());
				serReqDetTo.setRequestId(requestTO.getId());
				serReqDetTo.setEnvironmentdetailsId(reqTo.getEnvironmentdetailsId());
				getHibernateTemplate().save(serReqDetTo);
				int success = -1;
				EnvironmentTO envTO = new EnvironmentTO();
				envTO.setId(requestTO.getSelectedEnvironment());
				envTO.setCreatedById(requestTO.getCreatedById());
				if (requestTO.getClientId() != 0) {
					success = generateWorkflow(envTO, requestTO);
					requestTO.setSuccess(success);
				}
				requestTO.setSuccess(success);
			}
			return requestTO;
		} catch (ConstraintViolationException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: restartServer", e);
		} catch (DataAccessException | HibernateException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: restartServer", e);
		}
	}
	
	@Override
	public ServiceRequestTO applicationUndeployment(ServiceRequestTO requestTO) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			getHibernateTemplate().save(requestTO);
			for (ServiceRequestTO envAppTo : requestTO.getAppSerSoftListForm()) {
				ServiceRequestDetailsTO serReqDetTo = new ServiceRequestDetailsTO();
				serReqDetTo.setProfileId(requestTO.getProfileId());
				serReqDetTo.setEnvironmentId(requestTO.getEnvironmentId());
				serReqDetTo.setRequestId(requestTO.getId());
				serReqDetTo.setEnvironmentdetailsId(envAppTo.getEnvironmentdetailsId());
				serReqDetTo.setSelectedApplicationRelease(requestTO.getAppReleaseList().get(0).getApplicationReleaseTO().getId());
				serReqDetTo.setApplicationId(requestTO.getAppReleaseList().get(0).getApplicationTO().getId());
				serReqDetTo.setWarName(requestTO.getWarName());
				getHibernateTemplate().save(serReqDetTo);
				int success = -1;
				EnvironmentTO envTO = new EnvironmentTO();
				envTO.setId(requestTO.getEnvironmentId());
				envTO.setCreatedById(requestTO.getCreatedById());
				if (requestTO.getClientId() != 0) {
					success = generateWorkflow(envTO, requestTO);
					requestTO.setSuccess(success);
				}
				if (success == -1) {
					Long envStatus = CMMConstants.Framework.Entity.ENVIRONMENT_STATUS_UNDERIMPLEMENTATION;
					Long reqStatus = CMMConstants.Framework.Entity.SERVICE_REQUEST_UNDER_IMPLEMENTATION;
					session.createQuery("update EnvironmentTO e set e.status=? where e.id = ? ").setParameter(0, envStatus).setParameter(1, envTO.getId()).executeUpdate();
					session.createQuery("update ServiceRequestTO r set r.statusId=? where r.id = ? ").setParameter(0, reqStatus).setParameter(1, requestTO.getId()).executeUpdate();
					requestTO.setSuccess(success);
				}
			}
		} catch (ConstraintViolationException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: applicationUndeployment", e);
		} catch (DataAccessException | HibernateException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: applicationUndeployment", e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return requestTO;
	}
	
	@Override
	public boolean validateEnvName(String subapp) throws CMMException {
	
		try {
			List<EnvironmentTO> profTO = (List<EnvironmentTO>) getHibernateTemplate().find("from EnvironmentTO where environmentName=?", subapp);
			return !profTO.isEmpty();
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: validateEnvName", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: validateEnvName", he);
		}
	}
	
	@Override
	public List<ApplicationReleaseTO> fetchReleaseList(Long profileId, Long appId) throws CMMException {
	
		try {
			return (List<ApplicationReleaseTO>) getHibernateTemplate().find("from ApplicationReleaseTO where applicationProfileId=? and applicationId=? and type=? and status=?", profileId, appId, CMMConstants.Framework.ApplicationRelease.PARENT_APPLICATION_RELEASE, CMMConstants.Framework.Entity.APPLICATION_RELEASE_ACTIVE);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: fetchRReleaseList(Long , Long)", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: fetchReleaseList(Long , Long)", he);
		}
	}
	
	@Override
	public List<ApplicationReleaseTO> fetchReleaseList(Long profileId) throws CMMException {
	
		try {
			return (List<ApplicationReleaseTO>) getHibernateTemplate().find("from ApplicationReleaseTO where applicationProfileId=? and type=?", profileId, CMMConstants.Framework.ApplicationRelease.PARENT_APPLICATION_RELEASE);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: fetchReleaseList(Long)", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: fetchReleaseList(Long)", he);
		}
	}
	
	@Override
	public List<ApplicationReleaseTO> getAllMinorReleases(Long majorReleaseId) throws CMMException {
	
		try {
			return (List<ApplicationReleaseTO>) getHibernateTemplate().find("from ApplicationReleaseTO where parentReleaseId=? and type=?", majorReleaseId, CMMConstants.Framework.ApplicationRelease.SUB_APPLICATION_RELEASE);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getAllMinorReleases", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getAllMinorReleases", he);
		}
	}
	
	@Override
	public List<ApplicationReleaseTO> getAllMinorReleases(Long majorReleaseId, Long selectedEnvironment, Long applicationId) throws CMMException {
	
		Long minorRelease = null;
		try {
			List<EnvironmentApplicationTO> envAppTO = (List<EnvironmentApplicationTO>) getHibernateTemplate().find("from EnvironmentApplicationTO where applicationTO.id=? and environmentTO.id=?", applicationId, selectedEnvironment);
			if ("S".equalsIgnoreCase(envAppTO.get(0).getApplicationReleaseTO().getType())) {
				minorRelease = envAppTO.get(0).getReleaseId();
			}
			List<ApplicationReleaseTO> relTO = (List<ApplicationReleaseTO>) getHibernateTemplate().find("from ApplicationReleaseTO where parentReleaseId=? and type=?", majorReleaseId, CMMConstants.Framework.ApplicationRelease.SUB_APPLICATION_RELEASE);
			for (int i = relTO.size() - 1; i > -1; i--) {
				if (relTO.get(i).getId().equals(minorRelease)) {
					relTO.remove(relTO.get(i));
				}
			}
			return relTO;
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getAllMinorReleases", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getAllMinorReleases", he);
		}
	}
	
	@Override
	public List<EnvironmentApplicationTO> fetchAppRelList(Long envId) throws CMMException {
	
		try {
			return (List<EnvironmentApplicationTO>) getHibernateTemplate().find("from EnvironmentApplicationTO where environmentTO.id=?", envId);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: fetchAppRelList", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: fetchAppRelList", he);
		}
	}
	
	@Override
	public ServiceRequestTO fetchServiceRequestByRequestId(long requestId) throws CMMException {
	
		try {
			List<ServiceRequestTO> serviceRequestList = (List<ServiceRequestTO>) getHibernateTemplate().find("from ServiceRequestTO where id=?", requestId);
			if ((serviceRequestList == null) || serviceRequestList.isEmpty()) {
				logger.debug("No record found in Service Request table for requestId:: " + requestId);
				throw new CMMException("No record found in Service Request table for requestId:: " + requestId);
			}
			return serviceRequestList.get(0);
		} catch (DataAccessException dae) {
			logger.error("Error in fetching service request for requestId:: " + requestId);
			throw new CMMException("Can not access service request for requestId: " + dae.getMessage(), dae);
		} catch (HibernateException he) {
			logger.error("Error while fetching service request for requestId:: " + requestId);
			throw new CMMException("Problem while fetching service request." + he.getMessage(), he);
		}
	}
	
	@Override
	public List<ApplicationReleaseTO> getAllReleases(Long selectedEnvironment) throws CMMException {
	
		try {
			List<ServiceRequestTO> reqTO = (List<ServiceRequestTO>) getHibernateTemplate().find("from ServiceRequestTO where environmentId=? and (serviceId ='2' or serviceId='5') order by applicationReleaseId desc", selectedEnvironment);
			if (reqTO.isEmpty()) {
				throw new CMMException("NO Release present with corresponding environment.");
			}
			List<Long> applicationRelIdList = new ArrayList<Long>(0);
			for (int i = 0; i < reqTO.size(); i++) {
				applicationRelIdList.add(reqTO.get(i).getApplicationReleaseId());
			}
			return (List<ApplicationReleaseTO>) getHibernateTemplate().findByNamedQueryAndNamedParam("request.fetchReleaseName", "applicationRelIdList", applicationRelIdList);
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getAllReleases", dae);
		}
	}
	
	@Override
	public ServiceRequestTO submitRollBack(ServiceRequestTO requestTO) throws CMMException {
	
		try {
			getHibernateTemplate().save(requestTO);
			int success = -1;
			EnvironmentTO envTO = new EnvironmentTO();
			envTO.setId(requestTO.getEnvironmentId());
			envTO.setCreatedById(requestTO.getCreatedById());
			if (requestTO.getClientId() != 0) {
				success = generateWorkflow(envTO, requestTO);
				if (success == 1) {
					requestTO.setStatusId(141L);
					getHibernateTemplate().update(requestTO);
				}
				requestTO.setSuccess(success);
			}
			requestTO.setSuccess(success);
		} catch (ConstraintViolationException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: submitRollBack", e);
		} catch (DataAccessException | HibernateException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: submitRollBack", e);
		}
		return requestTO;
	}
	
	@Override
	public List<EnvironmentTO> getAllEnvironmentsAccToPhases1(Long selectedProfile, Long selectedTestingCycle1) throws CMMException {
	
		try {
			return (List<EnvironmentTO>) getHibernateTemplate().find("from EnvironmentTO where profileId=? and status=?", selectedProfile, Framework.Entity.ENVIRONMENT_AVAILABLE);
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getAllEnvironmentsAccToPhases1", dae);
		}
	}
	
	@Override
	public ServiceRequestTO submitPromotedDetails(ServiceRequestTO requestTO) throws CMMException {
	
		try {
			Serializable save = getHibernateTemplate().save(requestTO);
			int success = -1;
			EnvironmentTO envTO = new EnvironmentTO();
			envTO.setId(requestTO.getPromotedEnvironment());
			envTO.setCreatedById(requestTO.getCreatedById());
			if (requestTO.getClientId() != 0) {
				success = generateWorkflow(envTO, requestTO);
				requestTO.setSuccess(success);
			}
			requestTO.setId((Long) save);
			requestTO.setSuccess(success);
		} catch (ConstraintViolationException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: submitPromotedDetails", e);
		} catch (DataAccessException | HibernateException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: submitPromotedDetails", e);
		}
		return requestTO;
	}
	
	@Override
	public long getMinReqIdByCurrentReleaseId(long envId, long currentReleaseId) throws CMMException {
	
		Session session = getSession();
		try {
			return (Long) session.createCriteria(ServiceRequestTO.class).add(Restrictions.eq("environmentId", envId)).add(Restrictions.eq("applicationReleaseId", currentReleaseId)).setProjection(Projections.max("id")).uniqueResult();
		} catch (DataAccessException dae) {
			throw new CMMException("Error in fetching requestId for current releaseId:" + currentReleaseId, dae);
		} catch (HibernateException he) {
			throw new CMMException("Can not fetch data from database current releaseId:" + currentReleaseId, he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public long getMaxReqIdByRollbackReleaseId(long envId, long rollBackReleaseId) throws CMMException {
	
		Session session = getSession();
		try {
			return (Long) session.createCriteria(ServiceRequestTO.class).add(Restrictions.eq("environmentId", envId)).add(Restrictions.eq("applicationReleaseId", rollBackReleaseId)).setProjection(Projections.min("id")).uniqueResult();
		} catch (DataAccessException dae) {
			throw new CMMException("Error in fetching requestId for rollback releaseId:" + rollBackReleaseId, dae);
		} catch (HibernateException he) {
			throw new CMMException("Can not fetch data from database rollback releaseId:" + rollBackReleaseId, he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<Long> getAllRollbackRequestIds(long minRequestId, long maxRequestId, long applicationId, long environmentId) throws CMMException {
	
		Session session = getSession();
		try {
			List<Long> requestIdList = session.createCriteria(ServiceRequestTO.class).add(Restrictions.between("id", minRequestId, maxRequestId)).add(Restrictions.eq("applicationTO.id", applicationId)).add(Restrictions.eq("environmentId", environmentId)).add(Restrictions.eq("statusTO.id", CMMConstants.Framework.Entity.SERVICE_REQUEST_STATUS_COMPLETED)).add(Restrictions.eq("actionFlag", CMMConstants.Framework.ServiceRequestStatus.SERVICE_REQUEST_COMPLETED)).add(Restrictions.eq("serviceTO.id", CMMConstants.Framework.Service.SERVICE_ID)).setProjection(Projections.property("id")).addOrder(Order.desc("id")).list();
			if ((requestIdList == null) || requestIdList.isEmpty()) {
				throw new CMMException("No records found for release between " + minRequestId + " and " + maxRequestId);
			}
			return requestIdList;
		} catch (DataAccessException dae) {
			throw new CMMException("Error in fetching requestId for release between " + minRequestId + " and " + maxRequestId, dae);
		} catch (HibernateException he) {
			throw new CMMException("Can not fetch data from database for release between" + minRequestId + " and " + maxRequestId, he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<Long> getAllDBScriptsRequestIds(long minRequestId, long maxRequestId, long applicationId, long environmentId) throws CMMException {
	
		Session session = getSession();
		try {
			List<Long> requestIdList = session.createCriteria(ServiceRequestTO.class).add(Restrictions.between("id", minRequestId, maxRequestId)).add(Restrictions.eq("applicationTO.id", applicationId)).add(Restrictions.eq("environmentId", environmentId)).add(Restrictions.eq("statusTO.id", CMMConstants.Framework.Entity.SERVICE_REQUEST_STATUS_COMPLETED)).add(Restrictions.eq("actionFlag", CMMConstants.Framework.ServiceRequestStatus.SERVICE_REQUEST_COMPLETED)).add(Restrictions.eq("serviceTO.id", CMMConstants.Framework.Service.SERVICE_ID)).setProjection(Projections.property("id")).addOrder(Order.asc("id")).list();
			if ((requestIdList == null) || requestIdList.isEmpty()) {
				throw new CMMException("No records found for release between " + minRequestId + " and " + maxRequestId);
			}
			return requestIdList;
		} catch (DataAccessException dae) {
			throw new CMMException("Error in fetching data for release between " + minRequestId + " and " + maxRequestId, dae);
		} catch (HibernateException he) {
			throw new CMMException("Can not fetch data for release between" + minRequestId + " and " + maxRequestId, he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<ServiceTO> getServicesForYes() throws CMMException {
	
		try {
			return (List<ServiceTO>) getHibernateTemplate().find("from ServiceTO where status= ? and flag= ? ", CMMConstants.Framework.Entity.SERVICES_ACTIVE, CMMConstants.Framework.ServiceFlag.SERVICE_FLAG_Y);
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getServicesForYes", dae);
		}
	}
	
	@Override
	public List<ServiceTO> getServicesForNo() throws CMMException {
	
		try {
			return (List<ServiceTO>) getHibernateTemplate().find("from ServiceTO where status= ?  and flag= ?  ", CMMConstants.Framework.Entity.SERVICES_ACTIVE, CMMConstants.Framework.ServiceFlag.SERVICE_FLAG_N);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getServicesForNo", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getServicesForNo", he);
		}
	}
	
	@Override
	public List<ServiceTO> getServicesForYes(Long clientId) throws CMMException {
	
		List<ServiceTO> servTO = new ArrayList<ServiceTO>(0);
		Session session = null;
		try {
			session = getSession();
			String hql = "select s.id,s.name from ServiceTO s inner join s.serviceClientTO c where c.clientId=(:clientId) and s.flag=:serviceFlag";
			Query q = session.createQuery(hql);
			q.setParameter("clientId", clientId);
			q.setParameter("serviceFlag", CMMConstants.Framework.ServiceFlag.SERVICE_FLAG_Y);
			List<Object[]> obj = q.list();
			for (Object[] temp : obj) {
				ServiceTO services = new ServiceTO();
				services.setId((Long) temp[0]);
				services.setName(temp[1].toString());
				servTO.add(services);
			}
			return servTO;
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getServicesForYes", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getServicesForYes", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public ServiceRequestTO caLisaAgentSubmit(ServiceRequestTO requestTO) throws CMMException {
	
		try {
			getHibernateTemplate().save(requestTO);
			for (ServiceRequestDetailsTO serReqDetTo : requestTO.getServiceRequestDetList()) {
				serReqDetTo.setRequestId(requestTO.getId());
				getHibernateTemplate().save(serReqDetTo);
				int success = -1;
				requestTO.setSuccess(success);
			}
		} catch (ConstraintViolationException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: caLisaAgentSubmit", e);
		} catch (DataAccessException | HibernateException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: caLisaAgentSubmit", e);
		}
		return requestTO;
	}
	
	@Override
	public boolean checkName(EnvironmentTO envTO) {
	
		List<Object[]> objList = (List<Object[]>) getHibernateTemplate().find("select e.id from EnvironmentTO e where environmentName=? ", envTO.getEnvironmentName());
		return !objList.isEmpty();
	}
	
	@Override
	public long getSoftwareIdForEnvDetailsId(long environmentDetailsId) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			return (Long) session.createCriteria(EnvironmentDetailsTO.class).add(Restrictions.eq("id", environmentDetailsId)).setProjection(Projections.property("mappedSoftwareId")).uniqueResult();
		} catch (DataAccessException dae) {
			throw new CMMException("Error in fetching softwareConfigId for environmentDetailsId " + environmentDetailsId, dae);
		} catch (HibernateException he) {
			throw new CMMException("Can not fetch data from database for softwareConfigId", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	/*
	 * this method adds request for environment creation..it also copies data from original tables to provisioned tables was created while switching from
	 * hardwareId to machineId
	 */
	@Override
	public ServiceRequestTO createEnvironmentForMachine(EnvironmentTO environmentTO, ServiceRequestTO requestTO) throws CMMException {
	
		Session session = getSession();
		try {
			String type = "machine";
			EnvironmentApplicationTO envAppTO = new EnvironmentApplicationTO();
			List<EnvironmentApplicationTO> envAppTOList = new ArrayList<EnvironmentApplicationTO>();
			Long serverGroupCheck = null;
			Long provisionedMachineId = null;
			Long provisionedPlatformId = null;
			requestTO.setApplicationId(null);
			requestTO.setApplicationReleaseId(null);
			requestTO.setStatusId(141L);
			requestTO.setServiceId(1L);
			requestTO.setActionFlag("Y");
			requestTO.setEnvironmentId(null);
			requestTO.setCreatedById(requestTO.getCreatedById());
			requestTO.setCreatedByDate(requestTO.getCreatedByDate());
			getHibernateTemplate().save(requestTO);
			EnvironmentTO addEnv = new EnvironmentTO();
			addEnv.setEnvironmentName(environmentTO.getEnvironmentName());
			addEnv.setMonitoringRequired(environmentTO.getMonitoringRequired());
			addEnv.setReservationCheck(environmentTO.getReservationCheck());
			addEnv.setStatus(environmentTO.getStatus());
			addEnv.setProfileId(environmentTO.getProfileId());
			addEnv.setEnvTypeId(requestTO.getSelectedEnvType());
			addEnv.setCreatedById(environmentTO.getCreatedById());
			addEnv.setCreatedByDate(environmentTO.getCreatedByDate());
			if (!(environmentTO.getPropertyName() == null)) {
				type = environmentTO.getPropertyName();
			}
			if (!requestTO.getAppList().isEmpty()) {
				for (ApplicationTO tempApp : requestTO.getAppList()) {
					EnvironmentApplicationTO envAppTO1 = new EnvironmentApplicationTO();
					envAppTO1.setApplicationTO(tempApp);
					envAppTO1.setEnvironmentTO(addEnv);
					ApplicationReleaseTO apprel = new ApplicationReleaseTO();
					if ((tempApp.getSelectedApplicationReleaseMinor() != null) && (tempApp.getSelectedApplicationReleaseMinor() > 0)) {
						apprel.setId(tempApp.getSelectedApplicationReleaseMinor());
						envAppTO1.setApplicationReleaseTO(apprel);
						envAppTO1.setSelectedTestingPhase(tempApp.getSelectedTestingPhase());
					} else if ((tempApp.getSelectedApplicationRelease() != null) && (tempApp.getSelectedApplicationRelease() > 0)) {
						apprel.setId(tempApp.getSelectedApplicationRelease());
						envAppTO1.setApplicationReleaseTO(apprel);
						envAppTO1.setSelectedTestingPhase(tempApp.getSelectedTestingPhase());
					}
					envAppTOList.add(envAppTO1);
				}
				addEnv.getEnvironmentApplicationTO().addAll(envAppTOList);
			} else {
				List<ApplicationTO> appTO = new ArrayList<ApplicationTO>(0);
				List<Long> appList = environmentTO.getDefinedApplications();
				appTO = (List<ApplicationTO>) getHibernateTemplate().findByNamedQueryAndNamedParam("fetchApplicationId", "appList", appList);
				for (ApplicationTO tempApp : appTO) {
					EnvironmentApplicationTO envAppTO1 = new EnvironmentApplicationTO();
					envAppTO1.setApplicationTO(tempApp);
					envAppTO1.setEnvironmentTO(addEnv);
					envAppTOList.add(envAppTO1);
				}
				addEnv.getEnvironmentApplicationTO().addAll(envAppTOList);
				/** Code Change for bug 2595 ends here */
			}
			/** code for setting mapping for environment application table ends */
			/** code for copying profile details to environment details begins */
			for (EnvironmentDetailsTO details : environmentTO.getEnvironmentDetails()) {
				EnvironmentDetailsTO temp = new EnvironmentDetailsTO();
				temp.setMappedSoftwareId(details.getMappedSoftwareId());
				temp.setServerGroup(details.getServerGroup());
				temp.setInstallationRequired(details.getInstallationRequired());
				temp.setInstallationStatus("N");
				if ("N".equalsIgnoreCase(details.getExistingMachineFlag())) {
					if (!details.getServerGroup().equals(serverGroupCheck)) {
						provisionedPlatformId = maintainPlatformTemplateVersions(details.getProvisionedPlatformId());
						provisionedMachineId = maintainMachineTemplateVersions(provisionedPlatformId, details.getProvisionedMachineId(), details.getServerGroup(), environmentTO.getProfileId());
						serverGroupCheck = details.getServerGroup();
					}
				} else if ("B".equalsIgnoreCase(details.getExistingMachineFlag())) {
					if (!details.getServerGroup().equals(serverGroupCheck)) {
						provisionedPlatformId = maintainPlatformTemplateVersions(details.getProvisionedPlatformId());
						provisionedMachineId = maintainMachineTemplateVersions(provisionedPlatformId, details.getProvisionedMachineId(), details.getServerGroup(), environmentTO.getProfileId());
						serverGroupCheck = details.getServerGroup();
					}
					temp.setIpAddBare(details.getIpAddBare());
				} else if (type.contains(CMMConstants.Framework.MachineTypes.MACHINE_TYPE_DOCKER)) {
					String Name = "Docker_" + environmentTO.getProfileId();
					ProvisionedMachineTO provisionedMachineTO = (ProvisionedMachineTO) getHibernateTemplate().find("from ProvisionedMachineTO where name=?", Name).get(0);
					provisionedMachineId = provisionedMachineTO.getId();
					ProvisionedPlatformTO provisionedPlatformTO = (ProvisionedPlatformTO) getHibernateTemplate().find("from ProvisionedPlatformTO where name=?", Name).get(0);
					provisionedPlatformId = provisionedPlatformTO.getId();
				}// docker stop
				else { //for physical machines
					provisionedPlatformId = details.getProvisionedPlatformId();
					provisionedMachineId = details.getProvisionedMachineId();
				}
				temp.setProvisionedPlatformId(provisionedPlatformId);
				temp.setProvisionedMachineId(provisionedMachineId);
				DetachedCriteria criteria = DetachedCriteria.forClass(ActivitySoftwareMappingTO.class, "activitysoftware");
				criteria.add(Restrictions.eq("activitysoftware.softwareconfigTO.id", details.getMappedSoftwareId()));
				criteria.add(Restrictions.eq("activitysoftware.caReleaseActivityTO.activityId", 1L));
				List<ActivitySoftwareMappingTO> activitySoftwareMappingTO = (List<ActivitySoftwareMappingTO>) getHibernateTemplate().findByCriteria(criteria);
				if ((activitySoftwareMappingTO != null) && !activitySoftwareMappingTO.isEmpty()) {
					for (EnvironmentSoftParamsTO tempProperty : details.getEnvironmentSoftwareParametersTO()) {
						Set<EnvironmentSoftParamsTO> environmentSoftwareParametersTO = new HashSet<EnvironmentSoftParamsTO>(0);
						EnvironmentSoftParamsTO environmentSoftParamsTO = new EnvironmentSoftParamsTO();
						environmentSoftParamsTO.setInsertUpdateFlag("I");
						environmentSoftParamsTO.setLatestValueFlag("L");
						environmentSoftParamsTO.setServiceRequestTO(requestTO);
						environmentSoftParamsTO.setActivityId(1);
						environmentSoftParamsTO.setEnvironmentApplicationTO(envAppTO);
						environmentSoftParamsTO.setActivitySoftwareMappingTO(activitySoftwareMappingTO.get(0));
						for (EnvSoftParamDetailsTO property : tempProperty.getEnvSoftParamDetailsTO()) {
							EnvSoftParamDetailsTO envSoftParamDetailsTO = new EnvSoftParamDetailsTO();
							envSoftParamDetailsTO.setPropertyValue(property.getPropertyValue());
							envSoftParamDetailsTO.setParameterId(property.getParameterId());
							envSoftParamDetailsTO.setEnvironmentSoftParamsTO(environmentSoftParamsTO);
							environmentSoftParamsTO.getEnvSoftParamDetailsTO().add(envSoftParamDetailsTO);
							environmentSoftwareParametersTO.add(environmentSoftParamsTO);
						}
						environmentSoftParamsTO.setEnvironmentDetailsTO(temp);
						temp.setEnvironmentSoftwareParametersTO(environmentSoftwareParametersTO);
					}
				}
				temp.setEnvironment(addEnv);
				addEnv.getEnvironmentDetails().add(temp);
			}
			/** code for copying profile details to environment details ends */
			Long environmentId = (Long) getHibernateTemplate().save(addEnv);
			for (EnvironmentSoftwareAttributeTO envSoftwareAttributeTO : requestTO.getEnvSoftwareAttributeList()) {
				envSoftwareAttributeTO.setEnvId(environmentId);
				envSoftwareAttributeTO.setAttributeValue(envSoftwareAttributeTO.getAttributeValueTemp());
				getHibernateTemplate().save(envSoftwareAttributeTO);
			}
			Long requestId = requestTO.getId();
			requestTO.setEnvironmentId(addEnv.getId());
			int success = -1;
			getHibernateTemplate().update(requestTO);
			if (!type.contains(CMMConstants.Framework.MachineTypes.MACHINE_TYPE_DOCKER)) {
				for (EnvironmentDetailsTO temp : addEnv.getEnvironmentDetails()) {
					Long proMachineId = temp.getProvisionedMachineId();
					ProvisionedMachineTO provisionedMachineTO = new ProvisionedMachineTO();
					List<ProvisionedMachineTO> provisionedMachineList = (List<ProvisionedMachineTO>) getHibernateTemplate().find("from ProvisionedMachineTO where id=?", proMachineId);
					if (!provisionedMachineList.isEmpty()) {
						provisionedMachineTO = provisionedMachineList.get(0);
					}
					if (provisionedMachineTO != null) {
						if (provisionedMachineTO.getProvisionedMachineType().equalsIgnoreCase(CMMConstants.Framework.MachineTypes.MACHINE_TYPE_VIRTUAL)) {
							if ((provisionedMachineTO.getVirtualMachineType() != null) && provisionedMachineTO.getVirtualMachineType().equalsIgnoreCase(CMMConstants.Framework.MachineTypes.MACHINE_TYPE_VMWARE_BAREMETAL)) {
								String machineName = "VM" + (temp.getServerGroup() + 1) + "_" + requestId + "_EV_" + environmentId;
								provisionedMachineTO.setName(machineName);
								provisionedMachineTO.setIp(temp.getIpAddBare());
								getHibernateTemplate().update(provisionedMachineTO);
							} else {
								String machineName = "VM" + (temp.getServerGroup() + 1) + "_" + requestId + "_EV_" + environmentId;
								provisionedMachineTO.setName(machineName);
								getHibernateTemplate().update(provisionedMachineTO);
							}
						}
					}
				}
				if (requestTO.getClientId() != 0) {
					success = generateWorkflow(addEnv, requestTO);
					requestTO.setSuccess(success);
				}
			}
			if (type.contains(CMMConstants.Framework.MachineTypes.MACHINE_TYPE_DOCKER)) {
				EnvironmentDockerTO environmentDockerTO = new EnvironmentDockerTO();
				String namedocker = CMMConstants.Framework.MachineTypes.MACHINE_TYPE_DOCKER + "_";
				Long pid = environmentTO.getProfileId();
				namedocker = namedocker + pid;
				ProvisionedMachineTO provisionedMachineTO = new ProvisionedMachineTO();
				List<ProvisionedMachineTO> provisionedMachineList = (List<ProvisionedMachineTO>) getHibernateTemplate().find("from ProvisionedMachineTO where name=?", namedocker);
				if (!provisionedMachineList.isEmpty()) {
					provisionedMachineTO = provisionedMachineList.get(0);
				}
				environmentDockerTO.setProfileId(environmentTO.getProfileId());
				environmentDockerTO.setContainerIp(environmentTO.getDockerContainerIP());
				environmentDockerTO.setEnvId(environmentId);
				getHibernateTemplate().save(environmentDockerTO);
				provisionedMachineTO.setIp(environmentDockerTO.getContainerIp());
				getHibernateTemplate().update(provisionedMachineTO);
			}
			if (success == -1) {
				Long envStatus = CMMConstants.Framework.Entity.ENVIRONMENT_STATUS_UNDERIMPLEMENTATION;
				Long reqStatus = CMMConstants.Framework.Entity.SERVICE_REQUEST_UNDER_IMPLEMENTATION;
				session.createQuery("update EnvironmentTO e set e.status=? where e.id = ? ").setParameter(0, envStatus).setParameter(1, environmentId).executeUpdate();
				session.createQuery("update ServiceRequestTO r set r.statusId=? where r.id = ? ").setParameter(0, reqStatus).setParameter(1, requestId).executeUpdate();
				requestTO.setSuccess(success);
			}
			if ((success == 0) || (success == -2)) {
				EnvironmentTO environmentTO2 = (EnvironmentTO) getHibernateTemplate().find("from EnvironmentTO where id=?", environmentId).get(0);
				List<Object> env = (List<Object>) getHibernateTemplate().find("from EnvironmentDetailsTO e where e.environment.id=?", environmentTO2.getId());
				for (Object temp : env) {
					getHibernateTemplate().delete(temp);
				}
				List<Object> envAppList = (List<Object>) getHibernateTemplate().find("from EnvironmentApplicationTO e where e.environmentTO.id=?", environmentTO2.getId());
				for (Object temp1 : envAppList) {
					getHibernateTemplate().delete(temp1);
				}
				String serviceQuery = "delete from ServiceRequestTO as e where e.environmentId= " + environmentId;
				session.createQuery(serviceQuery).executeUpdate();
				String query = CMMConstants.Presentation.Reporting.DELETE_ENVIRONMENT;
				query = query + " where e.id= " + environmentId;
				session.createQuery(query).executeUpdate();
			}
			List<UserDefinedEnvParamsTO> userDefinedEnvParamsTOList = new ArrayList<UserDefinedEnvParamsTO>(0);
			if (!requestTO.getParametersList().isEmpty()) {
				for (NolioProcessParametersTO nolioProcessParametersTO : requestTO.getParametersList()) {
					UserDefinedEnvParamsTO userDefinedEnvParamsTO = new UserDefinedEnvParamsTO();
					userDefinedEnvParamsTO.setEnvId(environmentId);
					userDefinedEnvParamsTO.setNolioProcessParameterValue(nolioProcessParametersTO.getParameterValue());
					if (nolioProcessParametersTO.getParameterType().equalsIgnoreCase(CMMConstants.Framework.GlobalParameters.NOLIO_PARAMETER)) {
						userDefinedEnvParamsTO.setNolioProcessParameterId(nolioProcessParametersTO.getParameterId());
						userDefinedEnvParamsTO.setScriptParameterId(null);
					}
					if (nolioProcessParametersTO.getParameterType().equalsIgnoreCase(CMMConstants.Framework.GlobalParameters.SCRIPT_PARAMETER)) {
						userDefinedEnvParamsTO.setScriptParameterId(nolioProcessParametersTO.getParameterId());
						userDefinedEnvParamsTO.setNolioProcessParameterId(null);
					}
					userDefinedEnvParamsTOList.add(userDefinedEnvParamsTO);
					getHibernateTemplate().save(userDefinedEnvParamsTO);
				}
			} else {
				List<NolioProcessParametersTO> userDefinedParametersList = new ArrayList<NolioProcessParametersTO>(0);
				List<ApplicationProfileDetailsTO> profDetails = applicationProfileDAO.fetchProfileDetails(requestTO.getSelectedProfiles());
				for (ApplicationProfileDetailsTO applicationProfileDetailsTO : profDetails) {
					if (applicationProfileDetailsTO.getSoftwareConfig() != null) {
						userDefinedParametersList.addAll(applicationProfileDAO.getUserDefinedReleaseParameters(applicationProfileDetailsTO.getSoftwareConfig().getId()));
					}
				}
				for (NolioProcessParametersTO nolioProcessParametersTO : userDefinedParametersList) {
					UserDefinedEnvParamsTO userDefinedEnvParamsTO = new UserDefinedEnvParamsTO();
					userDefinedEnvParamsTO.setEnvId(environmentId);
					userDefinedEnvParamsTO.setNolioProcessParameterValue(nolioProcessParametersTO.getParameterValue());
					if (nolioProcessParametersTO.getParameterType().equalsIgnoreCase(CMMConstants.Framework.GlobalParameters.NOLIO_PARAMETER)) {
						userDefinedEnvParamsTO.setNolioProcessParameterId(nolioProcessParametersTO.getParameterId());
						userDefinedEnvParamsTO.setScriptParameterId(null);
					}
					if (nolioProcessParametersTO.getParameterType().equalsIgnoreCase(CMMConstants.Framework.GlobalParameters.SCRIPT_PARAMETER)) {
						userDefinedEnvParamsTO.setScriptParameterId(nolioProcessParametersTO.getParameterId());
						userDefinedEnvParamsTO.setNolioProcessParameterId(null);
					}
					userDefinedEnvParamsTOList.add(userDefinedEnvParamsTO);
					getHibernateTemplate().save(userDefinedEnvParamsTO);
				}
			}
			return requestTO;
		} catch (ConstraintViolationException e) {
			throw new CMMException("Environment Name already exists.", e);
		} catch (DataAccessException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl:createEnvironment", e);
		} catch (HibernateException e) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl:createEnvironment", e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	private Long maintainPlatformTemplateVersions(Long platformTemplateId) {
	
		PlatformTemplateTO platformTemplateTO = new PlatformTemplateTO();
		List<PlatformTemplateTO> platformTemplateList = (List<PlatformTemplateTO>) getHibernateTemplate().find("from PlatformTemplateTO where id=?", platformTemplateId);
		if (!platformTemplateList.isEmpty()) {
			platformTemplateTO = platformTemplateList.get(0);
		}
		String platformType = platformTemplateTO.getType();
		ProvisionedPlatformTO provisionedPlatformTO = new ProvisionedPlatformTO();
		provisionedPlatformTO.setPlatformTemplateName(platformTemplateTO.getName());
		provisionedPlatformTO.setType(platformTemplateTO.getType());
		provisionedPlatformTO.setFamily(platformTemplateTO.getFamily());
		provisionedPlatformTO.setDistribution(platformTemplateTO.getDistribution());
		provisionedPlatformTO.setVersion(platformTemplateTO.getVersion());
		provisionedPlatformTO.setPack(platformTemplateTO.getPack());
		provisionedPlatformTO.setArchitecture(platformTemplateTO.getArchitecture());
		provisionedPlatformTO.setPlatformTemplateStatus(platformTemplateTO.getStatus());
		provisionedPlatformTO.setPlatformTemplateId(platformTemplateTO.getId());
		Long provisionedPlatformId = (Long) getHibernateTemplate().save(provisionedPlatformTO);
		if ((platformType != null) && platformType.equalsIgnoreCase(CMMConstants.Framework.MachineTypes.MACHINE_TYPE_EC2)) {
			PlatformTemplateAwsTO platformTemplateAwsTO = new PlatformTemplateAwsTO();
			List<PlatformTemplateAwsTO> platformTemplateAwsList = (List<PlatformTemplateAwsTO>) getHibernateTemplate().find("from PlatformTemplateAwsTO where platformTemplate.id=?", platformTemplateId);
			if (!platformTemplateAwsList.isEmpty()) {
				platformTemplateAwsTO = platformTemplateAwsList.get(0);
			}
			if (platformTemplateAwsTO != null) {
				ProvisionedTemplatesAwsTO provisionedTemplatesAwsTO = new ProvisionedTemplatesAwsTO();
				provisionedTemplatesAwsTO.setAwsAccountId(platformTemplateAwsTO.getAwsAccountId());
				provisionedTemplatesAwsTO.setImageId(platformTemplateAwsTO.getImageId());
				provisionedTemplatesAwsTO.setProvisionedPlatformId(provisionedPlatformId);
				getHibernateTemplate().save(provisionedTemplatesAwsTO);
			}
		}
		if ((platformType != null) && platformType.equalsIgnoreCase(CMMConstants.Framework.MachineTypes.MACHINE_TYPE_OPENSTACK)) {
			PlatformTemplateOSTO platformTemplateOSTO = new PlatformTemplateOSTO();
			List<PlatformTemplateOSTO> platformTemplateOSList = (List<PlatformTemplateOSTO>) getHibernateTemplate().find("from PlatformTemplateOSTO where platformTemplate.id=?", platformTemplateId);
			if (!platformTemplateOSList.isEmpty()) {
				platformTemplateOSTO = platformTemplateOSList.get(0);
			}
			if (platformTemplateOSTO != null) {
				ProvisionedPlatformOSTO provisionedPlatformOSTO = new ProvisionedPlatformOSTO();
				provisionedPlatformOSTO.setImageId(platformTemplateOSTO.getImageId());
				provisionedPlatformOSTO.setImageName(platformTemplateOSTO.getImageName());
				provisionedPlatformOSTO.setProvisionedPlatformId(provisionedPlatformId);
				getHibernateTemplate().save(provisionedPlatformOSTO);
			}
		}
		if ((platformType != null) && platformType.equalsIgnoreCase(CMMConstants.Framework.MachineTypes.MACHINE_TYPE_VMWARE)) {
			TemplateVMWareTO templateVMWareTO = new TemplateVMWareTO();
			List<TemplateVMWareTO> templateVMWareList = (List<TemplateVMWareTO>) getHibernateTemplate().find("from TemplateVMWareTO where platformTemplate.id=?", platformTemplateId);
			if (!templateVMWareList.isEmpty()) {
				templateVMWareTO = templateVMWareList.get(0);
			}
			if (templateVMWareTO != null) {
				ProvisionedTemplateVMWareTO provisionedTemplateVMWareTO = new ProvisionedTemplateVMWareTO();
				provisionedTemplateVMWareTO.setVmTemplateName(templateVMWareTO.getVmTemplateName());
				provisionedTemplateVMWareTO.setProvisionedPlatformId(provisionedPlatformId);
				getHibernateTemplate().save(provisionedTemplateVMWareTO);
			}
		}
		if ((platformType != null) && platformType.equalsIgnoreCase(CMMConstants.Framework.MachineTypes.MACHINE_TYPE_VMWARE_BAREMETAL)) {
			PlatformTemplateBareMetalTO platformTemplateBareMetalTO = new PlatformTemplateBareMetalTO();
			List<PlatformTemplateBareMetalTO> platformTemplateBareMetalList = (List<PlatformTemplateBareMetalTO>) getHibernateTemplate().find("from PlatformTemplateBareMetalTO where platformTemplate.id=?", platformTemplateId);
			if (!platformTemplateBareMetalList.isEmpty()) {
				platformTemplateBareMetalTO = platformTemplateBareMetalList.get(0);
			}
			if (platformTemplateBareMetalTO != null) {
				ProvisionedPlatformVmwareBareMetalTO provisionedPlatformVmwareBareMetalTO = new ProvisionedPlatformVmwareBareMetalTO();
				provisionedPlatformVmwareBareMetalTO.setProvisionedPlatformId(provisionedPlatformId);
				provisionedPlatformVmwareBareMetalTO.setIsoFilePath(platformTemplateBareMetalTO.getIsoFilePath());
				getHibernateTemplate().save(provisionedPlatformVmwareBareMetalTO);
			}
		}
		return provisionedPlatformId;
	}
	
	public Long maintainMachineTemplateVersions(Long provisionedPlatformId, Long machineTemplateId, Long serverGroupId, Long profileId) {
	
		MachineTemplateTO machineTemplateTO = new MachineTemplateTO();
		List<MachineTemplateTO> machineTemplateList = (List<MachineTemplateTO>) getHibernateTemplate().find("from MachineTemplateTO where id=?", machineTemplateId);
		if (!machineTemplateList.isEmpty()) {
			machineTemplateTO = machineTemplateList.get(0);
		}
		String machineType = machineTemplateTO.getType();
		ProvisionedMachineTO provisionedMachineTO = new ProvisionedMachineTO();
		provisionedMachineTO.setCPU(Long.parseLong(machineTemplateTO.getCPU()));
		provisionedMachineTO.setRAM(Long.parseLong(machineTemplateTO.getRAM()));
		provisionedMachineTO.setArchitecture(machineTemplateTO.getArchitecture());
		provisionedMachineTO.setProvisionedMachineType(CMMConstants.Framework.MachineTypes.MACHINE_TYPE_VIRTUAL);
		provisionedMachineTO.setVirtualMachineType(machineTemplateTO.getType());
		provisionedMachineTO.setProvisionedPlatformTemplateId(provisionedPlatformId);
		Long provisionedMachineId = (Long) getHibernateTemplate().save(provisionedMachineTO);
		if ((machineType != null) && machineType.equalsIgnoreCase(CMMConstants.Framework.MachineTypes.MACHINE_TYPE_EC2)) {
			MachineTemplateAwsTO machineTemplateAwsTO = (MachineTemplateAwsTO) getHibernateTemplate().find("from MachineTemplateAwsTO where machineTemplate.id=?", machineTemplateId).get(0);
			ApplicationProfileDetailsAWSTO applicationProfileDetailsAWSTO = (ApplicationProfileDetailsAWSTO) getHibernateTemplate().find("from ApplicationProfileDetailsAWSTO where applicationProfile.id=? and serverGroup=?", profileId, serverGroupId).get(0);
			if (machineTemplateAwsTO != null) {
				ProvisionedMachineAwsTO provisionedMachineAwsTO = new ProvisionedMachineAwsTO();
				provisionedMachineAwsTO.setAwsAccountId(machineTemplateAwsTO.getAwsAccountId());
				provisionedMachineAwsTO.setInstanceType(machineTemplateAwsTO.getInstanceType());
				provisionedMachineAwsTO.setAvailabilityZone(applicationProfileDetailsAWSTO.getAvalabilityZone());
				provisionedMachineAwsTO.setKeyPair(applicationProfileDetailsAWSTO.getKey());
				provisionedMachineAwsTO.setProvisionedMachineTemplateId(provisionedMachineId);
				provisionedMachineAwsTO.setServerGroup(serverGroupId);
				getHibernateTemplate().save(provisionedMachineAwsTO);
			}
		}
		if ((machineType != null) && machineType.equalsIgnoreCase(CMMConstants.Framework.MachineTypes.MACHINE_TYPE_OPENSTACK)) {
			MachineTemplateOSTO machineTemplateOSTO = (MachineTemplateOSTO) getHibernateTemplate().find("from MachineTemplateOSTO where machineTemplate.id=?", machineTemplateId).get(0);
			if (machineTemplateOSTO != null) {
				ProvisionedMachineOSTO provisionedMachineOSTO = new ProvisionedMachineOSTO();
				provisionedMachineOSTO.setFlavorId(machineTemplateOSTO.getFlavorId());
				provisionedMachineOSTO.setFlavorType(machineTemplateOSTO.getFlavorType());
				provisionedMachineOSTO.setDisk(machineTemplateOSTO.getDisk());
				provisionedMachineOSTO.setUsername(machineTemplateOSTO.getUsername());
				provisionedMachineOSTO.setPassword(machineTemplateOSTO.getPassword());
				provisionedMachineOSTO.setProvisionedMachineId(provisionedMachineId);
				getHibernateTemplate().save(provisionedMachineOSTO);
			}
		}
		if ((machineType != null) && machineType.equalsIgnoreCase(CMMConstants.Framework.MachineTypes.MACHINE_TYPE_VMWARE)) {
			MachineVMWareTO machineVMWareTO = (MachineVMWareTO) getHibernateTemplate().find("from MachineVMWareTO where machineTemplate.id=?", machineTemplateId).get(0);
			if (machineVMWareTO != null) {
				ProvisionedMachineVMWareTO provisionedMachineVMWareTO = new ProvisionedMachineVMWareTO();
				provisionedMachineVMWareTO.setProvisionedMachineTemplateId(provisionedMachineId);
				provisionedMachineVMWareTO.setUsername(machineVMWareTO.getUsername());
				provisionedMachineVMWareTO.setPassword(machineVMWareTO.getPassword());
				getHibernateTemplate().save(provisionedMachineVMWareTO);
			}
		}
		if ((machineType != null) && machineType.equalsIgnoreCase(CMMConstants.Framework.MachineTypes.MACHINE_TYPE_VMWARE_BAREMETAL)) {
			MachineTemplateBareMetalTO machineTemplateBareMetalTO = (MachineTemplateBareMetalTO) getHibernateTemplate().find("from MachineTemplateBareMetalTO where machineTemplateTO.id=?", machineTemplateId).get(0);
			if (machineTemplateBareMetalTO != null) {
				ProvisionedMachineVmwareBareMetalTO provisionedMachineVmwareBareMetalTO = new ProvisionedMachineVmwareBareMetalTO();
				provisionedMachineVmwareBareMetalTO.setProvisionedMachineTemplateId(provisionedMachineId);
				provisionedMachineVmwareBareMetalTO.setDiskMode(machineTemplateBareMetalTO.getDiskMode());
				provisionedMachineVmwareBareMetalTO.setHardDiskSize(machineTemplateBareMetalTO.getHardDiskSize());
				provisionedMachineVmwareBareMetalTO.setUsername(machineTemplateBareMetalTO.getUsername());
				provisionedMachineVmwareBareMetalTO.setPassword(machineTemplateBareMetalTO.getPassword());
				getHibernateTemplate().save(provisionedMachineVmwareBareMetalTO);
			}
		}
		return provisionedMachineId;
	}
	
	@Override
	public ServiceRequestTO submitBuild(ServiceRequestTO serviceReqTO) throws CMMException {
	
		int success = -1;
		try {
			serviceReqTO.setEnvironmentId(null);
			getHibernateTemplate().save(serviceReqTO);
			serviceReqTO.setClientId(serviceReqTO.getClientId());
			serviceReqTO.setWorkFlowId(serviceReqTO.getWorkFlowId());
			if (serviceReqTO.getClientId() != null) {
				if (serviceReqTO.getClientId() != 0) {
					success = serviceRequestDAO.generateWorkflowForBuildService(serviceReqTO);
					serviceReqTO.setSuccess(success);
				}
				serviceReqTO.setSuccess(success);
			}
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Problem encountered. submitBuild", dae);
		}
		return serviceReqTO;
	}
	
	@Override
	public ServiceRequestTO runCodeAnalysis(ServiceRequestTO serviceReqTO) throws CMMException {
	
		int success = -1;
		try {
			serviceReqTO.setEnvironmentId(null);
			getHibernateTemplate().save(serviceReqTO);
			serviceReqTO.setSuccess(success);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. runCodeAnalysis", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. runCodeAnalysis", he);
		}
		return serviceReqTO;
	}
	
	@Override
	public Long getWorkflowId(Long req) {
	
		Long workflowId = 0L;
		List<WorkflowCurrentTO> workFlowCurrentList = (List<WorkflowCurrentTO>) getHibernateTemplate().find("from WorkflowCurrentTO where request_id =?", req);
		for (WorkflowCurrentTO w : workFlowCurrentList) {
			workflowId = w.getReqId();
		}
		return workflowId;
	}
	
	public ServiceRequestDAO getServiceRequestDAO() {
	
		return serviceRequestDAO;
	}
	
	public void setServiceRequestDAO(ServiceRequestDAO serviceRequestDAO) {
	
		this.serviceRequestDAO = serviceRequestDAO;
	}
	
	@Override
	public PlatformTemplateTO loadTemplates(Long platformTemplateId) throws CMMException {
	
		try {
			return (PlatformTemplateTO) getHibernateTemplate().find("from PlatformTemplateTO where id =?", platformTemplateId).get(0);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. SoftwareDAOImpl:getSoftwareDetails", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. SoftwareDAOImpl:getSoftwareDetails", he);
		}
	}
	
	@Override
	public List<ApplicationReleaseTO> getAllApplicationReleasesForApplication(Long applicationId) throws CMMException {
	
		try {
			return (List<ApplicationReleaseTO>) getHibernateTemplate().find("from ApplicationReleaseTO where applicationId =? and status=?", applicationId, CMMConstants.Framework.Entity.APPLICATION_RELEASE_ACTIVE);
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Problem encountered. SoftwareDAOImpl:getAllApplicationReleasesForApplication", dae);
		}
	}
	
	@Override
	public List<ApplicationReleaseTO> getAppReleasesMappedWithBuildForApplication(Long applicationId) throws CMMException {
	
		try {
			List<ApplicationReleaseTO> release = new ArrayList<ApplicationReleaseTO>();
			List<ApplicationReleaseTO> allReleases = (List<ApplicationReleaseTO>) getHibernateTemplate().find("from ApplicationReleaseTO where applicationId =? and status=?", applicationId, CMMConstants.Framework.Entity.APPLICATION_RELEASE_ACTIVE);
			if (allReleases != null) {
				if (!allReleases.isEmpty()) {
					for (ApplicationReleaseTO rel : allReleases) {
						List<ApplicationReleaseBuildTO> rel_BuildLst = (List<ApplicationReleaseBuildTO>) getHibernateTemplate().find("from ApplicationReleaseBuildTO where applicationReleaseId =? ", rel.getId());
						if (rel_BuildLst != null) {
							if (!rel_BuildLst.isEmpty()) {
								release.add(rel);
							}
						}
					}
				}
			}
			return release;
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Problem encountered. SoftwareDAOImpl:getAllApplicationReleasesForApplication", dae);
		}
	}
	
	@Override
	public int generateWorkflowForBuildService(ServiceRequestTO serviceReqTO) throws CMMException {
	
		int success = -1;
		Session session = null;
		try {
			DetachedCriteria criteria1 = DetachedCriteria.forClass(WorkFlowLevelTO.class);
			criteria1.add(Restrictions.eq("clientId", serviceReqTO.getClientId()));
			criteria1.add(Restrictions.eq("workflowId", serviceReqTO.getWorkFlowId()));
			List<WorkFlowLevelTO> levelList = (List<WorkFlowLevelTO>) getHibernateTemplate().findByCriteria(criteria1);
			if (!levelList.isEmpty()) {
				Connection conn = null;
				java.sql.CallableStatement cs = null;
				session = getSession();
				try {
					conn = ((SessionFactoryImplementor) session.getSessionFactory()).getConnectionProvider().getConnection();
					cs = conn.prepareCall("{call initiate_workflow_build(?,?,?,?,?)}");
					cs.setLong(1, serviceReqTO.getApplicationId());
					cs.setLong(2, serviceReqTO.getWorkFlowId());
					cs.setLong(3, serviceReqTO.getCreatedById());
					cs.setLong(4, serviceReqTO.getId());
					cs.registerOutParameter(5, java.sql.Types.INTEGER);
					cs.execute();
					success = cs.getInt(5);
				} finally {
					if (cs != null) {
						cs.close();
					}
					if (conn != null) {
						conn.close();
					}
				}
				if (success == 1) {
					WorkflowCurrentTO workflowCurrentTo = (WorkflowCurrentTO) getHibernateTemplate().find("from WorkflowCurrentTO where serviceRequestId=?", serviceReqTO.getId()).get(0);
					if (workflowCurrentTo.getWfStatusTO().getId() == 3L) {
						return -1;
					}
				}
				return success;
			}
			return success;
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl:generateWorkflow", dae);
		} catch (SQLException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl:generateWorkflow", e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<ProvisionedMachineTO> getMachineDetails(String ip) throws CMMException {
	
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(ProvisionedMachineTO.class);
			criteria.add(Restrictions.isNotNull("ip"));
			criteria.add(Restrictions.isNotNull("name"));
			criteria.add(Restrictions.eq("serverStatus", CMMConstants.Framework.Status.ACTIVE));
			criteria.add(Restrictions.eq("provisionedMachineType", CMMConstants.Framework.MachineTypes.MACHINE_TYPE_PHYSICAL));
			criteria.add(Restrictions.eq("ip", ip));
			return (List<ProvisionedMachineTO>) getHibernateTemplate().findByCriteria(criteria);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl : getPhysicalMachinesDetailsForRequest", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl : getPhysicalMachinesDetailsForRequest", he);
		}
	}
	
	@Override
	public List<ProvisionedMachineTO> getMachineDetailsFromName(String name) throws CMMException {
	
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(ProvisionedMachineTO.class);
			criteria.add(Restrictions.isNotNull("ip"));
			criteria.add(Restrictions.isNotNull("name"));
			criteria.add(Restrictions.eq("serverStatus", CMMConstants.Framework.Status.ACTIVE));
			criteria.add(Restrictions.eq("name", name));
			return (List<ProvisionedMachineTO>) getHibernateTemplate().findByCriteria(criteria);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl : getPhysicalMachinesDetailsForRequest", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl : getPhysicalMachinesDetailsForRequest", he);
		}
	}
	
	@Override
	public List<ProvisionedMachineTO> getPhysicalMachinesDetailsForRequest(String ip) throws CMMException {
	
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(ProvisionedMachineTO.class);
			criteria.add(Restrictions.isNotNull("ip"));
			criteria.add(Restrictions.isNotNull("name"));
			criteria.add(Restrictions.eq("ip", ip));
			criteria.add(Restrictions.eq("serverStatus", CMMConstants.Framework.Status.ACTIVE));
			criteria.add(Restrictions.eq("provisionedMachineType", CMMConstants.Framework.MachineTypes.MACHINE_TYPE_PHYSICAL));
			return (List<ProvisionedMachineTO>) getHibernateTemplate().findByCriteria(criteria);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl : getPhysicalMachinesDetailsForRequest", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl : getPhysicalMachinesDetailsForRequest", he);
		}
	}
	
	@Override
	public List<ProvisionedMachineTO> getPhysicalMachinesDetailsForRequest() throws CMMException {
	
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(ProvisionedMachineTO.class);
			criteria.add(Restrictions.isNotNull("ip"));
			criteria.add(Restrictions.isNotNull("name"));
			criteria.add(Restrictions.eq("serverStatus", CMMConstants.Framework.Status.ACTIVE));
			criteria.add(Restrictions.eq("provisionedMachineType", CMMConstants.Framework.MachineTypes.MACHINE_TYPE_PHYSICAL));
			return (List<ProvisionedMachineTO>) getHibernateTemplate().findByCriteria(criteria);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl : getPhysicalMachinesDetailsForRequest", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl : getPhysicalMachinesDetailsForRequest", he);
		}
	}
	
	@Override
	public int generateWorkflowForCodeAnalysis(ServiceRequestTO serviceReqTO) throws CMMException {
	
		return 0;
	}
	
	@Override
	public List<EnvironmentTO> getEnvironmentListForApplications(Long selectedApplication) throws CMMException {
	
		List<EnvironmentTO> envList = new ArrayList<EnvironmentTO>(0);
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(EnvironmentApplicationTO.class, "envAppTO");
			criteria.add(Restrictions.eq("envAppTO.applicationTO.id", selectedApplication));
			List<EnvironmentApplicationTO> envAppList = (List<EnvironmentApplicationTO>) getHibernateTemplate().findByCriteria(criteria);
			for (EnvironmentApplicationTO envApp : envAppList) {
				EnvironmentTO env = new EnvironmentTO();
				env.setId(envApp.getEnvironmentTO().getId());
				env.setEnvironmentName(envApp.getEnvironmentTO().getEnvironmentName());
				envList.add(env);
			}
			return envList;
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getEnvironmentListForApplications", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getEnvironmentListForApplications", he);
		}
	}
	
	@Override
	public List<ProvisionedMachineTO> getProvisionedMachineDetailsByReqId(long requestId) throws CMMException {
	
		List<ServiceRequestDetailsTO> reqList = new ArrayList<ServiceRequestDetailsTO>(0);
		List<ProvisionedMachineTO> provisionedMachineList = new ArrayList<ProvisionedMachineTO>();
		ProvisionedMachineTO machine = new ProvisionedMachineTO();
		DetachedCriteria criteria = DetachedCriteria.forClass(ServiceRequestDetailsTO.class, "serviceReqTO");
		criteria.add(Restrictions.eq("requestId", requestId));
		reqList = (List<ServiceRequestDetailsTO>) getHibernateTemplate().findByCriteria(criteria);
		if (!reqList.isEmpty()) {
			for (ServiceRequestDetailsTO p : reqList) {
				Long id = p.getProvisionedMachineId();
				if (id != null) {
					machine = (ProvisionedMachineTO) getHibernateTemplate().find("from ProvisionedMachineTO where id=?", id).get(0);
					provisionedMachineList.add(machine);
				}
			}
		}
		return provisionedMachineList;
	}
	
	@Override
	public TestingToolsTO getTestingToolsDetails(Long requestId, Long testToolId) throws CMMException {
	
		List<ServiceRequestTO> serviceRequestTO = (List<ServiceRequestTO>) getHibernateTemplate().find("from ServiceRequestTO where id =?", requestId);
		TestingToolsTO testingTools = new TestingToolsTO();
		Long applicationId = 0L;
		if (!serviceRequestTO.isEmpty()) {
			ServiceRequestTO serviceRequest = serviceRequestTO.get(0);
			for (EnvironmentApplicationTO temp : serviceRequest.getEnvironmentTO().getEnvironmentApplicationTO()) {
				for (EnvironmentApplicationTO envApp : temp.getEnvironmentTO().getEnvironmentApplicationTO()) {
					applicationId = envApp.getApplicationTO().getId();
				}
			}
			List<TestingToolsTO> testingToolsTO = (List<TestingToolsTO>) getHibernateTemplate().find("from TestingToolsTO where applicationId =?  and testingToolId =? ", applicationId, testToolId);
			if (!testingToolsTO.isEmpty()) {
				testingTools = testingToolsTO.get(0);
			} else {
				List<ApplicationTO> applicationList = (List<ApplicationTO>) getHibernateTemplate().find("from ApplicationTO where id =?", applicationId);
				if (!applicationList.isEmpty()) {
					ApplicationTO application = applicationList.get(0);
					Long projectId = application.getProjectTO().getId();
					testingToolsTO = (List<TestingToolsTO>) getHibernateTemplate().find("from TestingToolsTO where projectId=? and testingToolId = ?", projectId, testToolId);
					if (!testingToolsTO.isEmpty()) {
						testingTools = testingToolsTO.get(0);
					} else {
						List<ProjectsTO> projectList = (List<ProjectsTO>) getHibernateTemplate().find("from ProjectsTO where id =?", projectId);
						if (!projectList.isEmpty()) {
							ProjectsTO project = projectList.get(0);
							Long businessUnitId = project.getClientId();
							testingToolsTO = (List<TestingToolsTO>) getHibernateTemplate().find("from TestingToolsTO where businessUnitId=? and testingToolId = ?", businessUnitId, testToolId);
							if (!testingToolsTO.isEmpty()) {
								testingTools = testingToolsTO.get(0);
							}
						}
					}
				}
			}
		}
		return testingTools;
	}
	
	@Override
	public ServiceRequestTO submitDeploymentRequest(Map<Long, List<ServiceRequestTO>> environmentServiceMapping, List<ServiceRequestTO> serviceReqTo, boolean generateServicelevelWorkFlow, Map<Long, List<Long>> phaseEnvironmentMapping, List<PipelineRequestDetailsTO> pipelineRequestDetails, Long userId, Long applicationId, Long applicationReleaseId, String isScheduled, String cronExp) throws CMMException {
	
		Session session = getSession();
		try {
			boolean checkParentWorkFlowDefined = false;
			ServiceRequestTO parentRequest = new ServiceRequestTO();
			List<Long> submittedRequestIds = new ArrayList<Long>(0);
			ApplicationTO application = (ApplicationTO) getHibernateTemplate().find("from ApplicationTO where id=?", applicationId).get(0);
			parentRequest.setApplicationId(applicationId);
			parentRequest.setApplicationReleaseId(applicationReleaseId);
			parentRequest.setServiceId(17L);
			if (generateServicelevelWorkFlow) {
				parentRequest.setChildWorkflowFlag("Y");
			}
			parentRequest.setActionFlag("Y");
			parentRequest.setEnvironmentId(null);
			parentRequest.setCreatedById(userId);
			parentRequest.setCreatedByDate(new Date());
			parentRequest.setPipelineRequest("Y");
			parentRequest.setClientId(application.getBusinessUnitTO().getClientId());
			parentRequest.setWorkFlowId(17L);
			parentRequest.setStatusId(141L);
			parentRequest.setIsScheduled(isScheduled);
			parentRequest.setCronExp(cronExp);
			getHibernateTemplate().save(parentRequest);
			submittedRequestIds.add(parentRequest.getId());
			for (PipelineRequestDetailsTO detail : pipelineRequestDetails) {
				if (detail.getPhaseExecutionOrder() != 0L) {
					detail.setRequestId(parentRequest.getId());
					detail.setStatusId(145L);
					parentRequest.getPipelineRequestDetails().add(detail);
				}
			}
			int success = -1;
			Long roleId = null;
			String hql = "select c.roleId from UserPrivilegeTO c where c.id=(:id)";
			Query q = session.createQuery(hql);
			q.setParameter("id", userId);
			List<Long> users = q.list();
			if (users.size() > 0L) {
				roleId = users.get(0);
			}
			if (roleId != 0) {
				success = generateWorkflowForBuildService(parentRequest);
			}
			if (success == 1) {
				checkParentWorkFlowDefined = true;
				parentRequest.setStatusId(141L);
				for (PipelineRequestDetailsTO detail : pipelineRequestDetails) {
					if (detail.getPhaseExecutionOrder() == 0L) {
						detail.setRequestId(parentRequest.getId());
						detail.setStatusId(141L);
						parentRequest.getPipelineRequestDetails().add(detail);
					}
				}
			} else if (success == -1) {
				parentRequest.setStatusId(142L);
				for (PipelineRequestDetailsTO detail : pipelineRequestDetails) {
					if (detail.getPhaseExecutionOrder() == 0L) {
						detail.setRequestId(parentRequest.getId());
						if (generateServicelevelWorkFlow) {
							detail.setStatusId(141L);
						} else {
							detail.setStatusId(142L);
						}
						parentRequest.getPipelineRequestDetails().add(detail);
					}
				}
			}
			getHibernateTemplate().update(parentRequest);
			int successFlagForWorkFlowChildRequest = -1;
			List<Long> envsForPhaseZero = phaseEnvironmentMapping.get(0L);
			for (Long envId : envsForPhaseZero) {
				boolean startServiceidentified = false;
				int startServiceorder = 0;
				List<ServiceRequestTO> serviceListForEnv = environmentServiceMapping.get(envId);
				for (ServiceRequestTO service : serviceListForEnv) {
					service.setParentRequestId(parentRequest.getId());
					service.setCreatedById(userId);
					service.setCreatedByDate(new Date());
					service.setPipelineRequest("Y");
					List<WorkFlowTO> wrkFlwList = (List<WorkFlowTO>) getHibernateTemplate().find("from WorkFlowTO where linkedServiceId=?", service.getServiceId());
					WorkFlowTO wrkFlw = new WorkFlowTO();
					if (wrkFlwList.size() > 0L) {
						wrkFlw = wrkFlwList.get(0);
					}
					service.setWorkFlowId(wrkFlw.getId());
					service.setClientId(application.getBusinessUnitTO().getClientId());
					if ((service.getStatusId() != null) && (service.getStatusId() == 146)) {
						service.setStatusId(146L);
						getHibernateTemplate().save(service);
						submittedRequestIds.add(service.getId());
					} else {
						if (startServiceidentified == false) {
							startServiceidentified = true;
						} else {
							startServiceorder++;
						}
						getHibernateTemplate().save(service);
						boolean checkflag = false;
						if (generateServicelevelWorkFlow) {
							if (roleId != 0) {
								successFlagForWorkFlowChildRequest = generateWorkflowForBuildService(service);
							}
							if (successFlagForWorkFlowChildRequest == 1) {
								service.setStatusId(141L);
								getHibernateTemplate().update(service);
							}
							if (successFlagForWorkFlowChildRequest == -1) {
								checkflag = true;
							}
						} else {
							checkflag = true;
						}
						if (checkflag) {
							if (startServiceorder == 0) {
								if (checkParentWorkFlowDefined == false) {
									service.setStatusId(145L);
									getHibernateTemplate().update(service);
									for (PipelineRequestDetailsTO detail : pipelineRequestDetails) {
										if (detail.getPhaseExecutionOrder() == 0L) {
											detail.setRequestId(parentRequest.getId());
											detail.setStatusId(142L);
											getHibernateTemplate().update(detail);
										}
									}
								} else {
									service.setStatusId(145L);
									getHibernateTemplate().update(service);
								}
							} else {
								service.setStatusId(145L);
								getHibernateTemplate().update(service);
							}
						}
					}
				}
			}
			for (PipelineRequestDetailsTO pipelineReqDet : pipelineRequestDetails) {
				if (pipelineReqDet.getPhaseExecutionOrder() > 0L) {
					List<Long> envs = phaseEnvironmentMapping.get(pipelineReqDet.getPhaseExecutionOrder());
					for (Long envId : envs) {
						List<ServiceRequestTO> serviceListForEnv = environmentServiceMapping.get(envId);
						for (ServiceRequestTO service : serviceListForEnv) {
							service.setPipelineRequest("Y");
							service.setParentRequestId(parentRequest.getId());
							service.setCreatedById(userId);
							service.setCreatedByDate(new Date());
							List<WorkFlowTO> wrkFlwList = (List<WorkFlowTO>) getHibernateTemplate().find("from WorkFlowTO where linkedServiceId=?", service.getServiceId());
							WorkFlowTO wrkFlw = new WorkFlowTO();
							if (wrkFlwList.size() > 0L) {
								wrkFlw = wrkFlwList.get(0);
							}
							service.setWorkFlowId(wrkFlw.getId());
							service.setClientId(application.getBusinessUnitTO().getClientId());
							getHibernateTemplate().save(service);
							if (generateServicelevelWorkFlow) {
								if ((service.getStatusId() != null) && (service.getStatusId() != 146)) {
									if (roleId != 0) {
										successFlagForWorkFlowChildRequest = generateWorkflowForBuildService(service);
									}
									if (successFlagForWorkFlowChildRequest == 1) {
										service.setStatusId(141L);
									} else {
										service.setStatusId(145L);
									}
								} else {
									service.setStatusId(146L);
								}
								submittedRequestIds.add(service.getId());
							} else {
								service.setStatusId(145L);
							}
							getHibernateTemplate().update(service);
						}
					}
				}
			}
			parentRequest.setSuccess(success);
			return parentRequest;
		} catch (ConstraintViolationException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: submitSoftwareInstallation", e);
		} catch (DataAccessException | HibernateException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: submitSoftwareInstallation", e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<ApplicationReleaseTO> fetchReleaseListForRollback(Long selectedProfile, Long applicationId, Long selectedEnvironment) throws CMMException {
	
		List<ApplicationReleaseTO> appRelList = new ArrayList<ApplicationReleaseTO>(0);
		List<EnvironmentApplicationTO> envAppList = (List<EnvironmentApplicationTO>) getHibernateTemplate().find("from EnvironmentApplicationTO where applicationTO.id=? and environmentTO.id =?", applicationId, selectedEnvironment);
		if (envAppList.size() > 0L) {
			EnvironmentApplicationTO envAppObj = new EnvironmentApplicationTO();
			envAppObj = envAppList.get(0);
			if (envAppObj.getApplicationReleaseTO() != null) {
				List<ApplicationReleaseTO> appReleaseList = (List<ApplicationReleaseTO>) getHibernateTemplate().find("from ApplicationReleaseTO where status=? and applicationProfileId =? and applicationId =? and id < ?", CMMConstants.Framework.Entity.APPLICATION_RELEASE_ACTIVE, selectedProfile, applicationId, envAppObj.getApplicationReleaseTO().getId());
				for (ApplicationReleaseTO appRel : appReleaseList) {
					appRelList.add(appRel);
				}
			} else {
				List<ApplicationReleaseTO> appReleaseList = (List<ApplicationReleaseTO>) getHibernateTemplate().find("from ApplicationReleaseTO where status=? and applicationProfileId=? and applicationId =?", CMMConstants.Framework.Entity.APPLICATION_RELEASE_ACTIVE, selectedProfile, applicationId);
				appRelList = appReleaseList;
			}
		}
		return appRelList;
	}
	
	@Override
	public List<ApplicationReleaseTO> fetchReleaseListForRollbackWithPlan(Long selectedProfile, Long applicationId, Long selectedEnvironment, Long relPlanId) throws CMMException {
	
		List<ApplicationReleaseTO> appRelList = new ArrayList<ApplicationReleaseTO>(0);
		if (relPlanId != 0) {
			String q1 = String.format("select a from EnvironmentApplicationTO a where applicationTO.id=%d and environmentTO.id =%d", applicationId, selectedEnvironment);
			List<EnvironmentApplicationTO> envAppList = (List<EnvironmentApplicationTO>) getHibernateTemplate().find(q1);
			if (envAppList.size() > 0L) {
				EnvironmentApplicationTO envAppObj = new EnvironmentApplicationTO();
				envAppObj = envAppList.get(0);
				if (envAppObj.getApplicationReleaseTO() != null) {
					String q2 = String.format("select a from ApplicationReleaseTO a where status=%d and applicationProfileId =%d and applicationId =%d and a.releasePlanningTO.id=%d and id < %d", CMMConstants.Framework.Entity.APPLICATION_RELEASE_ACTIVE, selectedProfile, applicationId, relPlanId, envAppObj.getApplicationReleaseTO().getId());
					List<ApplicationReleaseTO> appReleaseList = (List<ApplicationReleaseTO>) getHibernateTemplate().find(q2);
					for (ApplicationReleaseTO appRel : appReleaseList) {
						appRelList.add(appRel);
					}
				} else {
					String q3 = String.format("select a from ApplicationReleaseTO a where status=? and applicationProfileId=? and applicationId =? and a.releasePlanningTO.id=%d", CMMConstants.Framework.Entity.APPLICATION_RELEASE_ACTIVE, selectedProfile, applicationId, relPlanId);
					List<ApplicationReleaseTO> appReleaseList = (List<ApplicationReleaseTO>) getHibernateTemplate().find(q3);
					appRelList = appReleaseList;
				}
			}
		}
		return appRelList;
	}
	
	@Override
	public List<ApplicationReleaseTO> fetchExistingReleases(Long selectedApplication, Long selectedEnvironment, Long selectedProfile) throws CMMException {
	
		List<ApplicationReleaseTO> appRelList = new ArrayList<>(0);
		List<EnvironmentApplicationTO> envAppList = (List<EnvironmentApplicationTO>) getHibernateTemplate().find("from EnvironmentApplicationTO where applicationTO.id=? and environmentTO.id =?", selectedApplication, selectedEnvironment);
		if (envAppList.size() > 0L) {
			EnvironmentApplicationTO envAppObj = new EnvironmentApplicationTO();
			envAppObj = envAppList.get(0);
			if (envAppObj.getApplicationReleaseTO() != null) {
				envAppObj.getApplicationReleaseTO().getId();
				List<ApplicationReleaseTO> appReleaseList = (List<ApplicationReleaseTO>) getHibernateTemplate().find("from ApplicationReleaseTO where status=? and applicationProfileId =? and applicationId =? and id > ?", CMMConstants.Framework.Entity.APPLICATION_RELEASE_ACTIVE, selectedProfile, selectedApplication, envAppObj.getApplicationReleaseTO().getId());
				for (ApplicationReleaseTO appRel : appReleaseList) {
					appRelList.add(appRel);
				}
			} else {
				List<ApplicationReleaseTO> appReleaseList = (List<ApplicationReleaseTO>) getHibernateTemplate().find("from ApplicationReleaseTO where  status=? and applicationProfileId=? and applicationId =?", CMMConstants.Framework.Entity.APPLICATION_RELEASE_ACTIVE, selectedProfile, selectedApplication);
				appRelList = appReleaseList;
			}
		}
		return appRelList;
	}
	
	@Override
	public List<ApplicationReleaseTO> fetchNewReleases(Long selectedApplication, Long selectedEnv, Long currentReleasePlan, Long currentRelease) throws CMMException {
	
		List<ApplicationReleaseTO> relPlanList = new ArrayList<>();
		try {
			relPlanList = (List<ApplicationReleaseTO>) getHibernateTemplate().find("from ApplicationReleaseTO r where r.applicationTO.id=? and r.releasePlanningTO.id=? and r.id>?", selectedApplication, currentReleasePlan, currentRelease);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getEnvironmentListForApplications", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getEnvironmentListForApplications", he);
		} catch (Exception e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: submitSoftwareInstallation", e);
		}
		return relPlanList;
	}
	
	@Override
	public ServiceRequestTO submitSoftwareInstallation(ServiceRequestTO requestTO) throws CMMException {
	
		try {
			int success = -1;
			EnvironmentTO envTO = new EnvironmentTO();
			ServiceRequestDetailsTO serReqDetTo = new ServiceRequestDetailsTO();
			getHibernateTemplate().save(requestTO);
			for (ServiceRequestTO reqTo : requestTO.getAppSerSoftListForm()) {
				serReqDetTo.setProfileId(requestTO.getSelectedProfiles());
				serReqDetTo.setEnvironmentId(requestTO.getSelectedEnvironment());
				serReqDetTo.setRequestId(requestTO.getId());
				serReqDetTo.setEnvironmentdetailsId(reqTo.getEnvironmentdetailsId());
				serReqDetTo.setSoftwaresRequested(reqTo.getSelectedSoftwareConfigIdForInstallation());
				getHibernateTemplate().save(serReqDetTo);
				EnvironmentDetailsTO EnvDetailsObj = (EnvironmentDetailsTO) getHibernateTemplate().find("from EnvironmentDetailsTO where id=?", reqTo.getEnvironmentdetailsId()).get(0);
				if (!("Y".equals(EnvDetailsObj.getInstallationRequired().toString()) && "Y".equals(EnvDetailsObj.getInstallationStatus().toString()))) {
					if (!"".equalsIgnoreCase(reqTo.getSelectedSoftwareForInstallation())) {
						EnvDetailsObj.setInstallationRequired("Y");
						EnvDetailsObj.setInstallationStatus("N");
					} else {
						EnvDetailsObj.setInstallationRequired("N");
						EnvDetailsObj.setInstallationStatus("N");
					}
				}
				getHibernateTemplate().update(EnvDetailsObj);
				envTO.setId(requestTO.getSelectedEnvironment());
				envTO.setCreatedById(requestTO.getCreatedById());
			}
			if (requestTO.getClientId() != 0) {
				success = generateWorkflow(envTO, requestTO);
				requestTO.setSuccess(success);
				if (success == -1) {
					requestTO.setStatusId(CMMConstants.Framework.Entity.SERVICE_REQUEST_UNDER_IMPLEMENTATION);
					getHibernateTemplate().update(requestTO);
				}
			}
			requestTO.setSuccess(success);
			return requestTO;
		} catch (ConstraintViolationException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: submitSoftwareInstallation", e);
		} catch (DataAccessException | HibernateException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: submitSoftwareInstallation", e);
		}
	}
	
	@Override
	public List<ServiceRequestTO> fetchAllPipelineRequestForParent(long parentRequestId, Long environmentId) throws CMMException {
	
		try {
			List<ServiceRequestTO> serviceRequestList = (List<ServiceRequestTO>) getHibernateTemplate().find("from ServiceRequestTO where parentRequestId=? and environmentId=? order by childRequestExecutionOrder", parentRequestId, environmentId);
			if ((serviceRequestList == null) || serviceRequestList.isEmpty()) {
				LOG.debug("no data present in DB for Parent Request Id :: " + parentRequestId);
			}
			return serviceRequestList;
		} catch (ConstraintViolationException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: fetchAllPipelineRequestForParent", e);
		} catch (DataAccessException | HibernateException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: fetchAllPipelineRequestForParent", e);
		}
	}
	
	@Override
	public List<ServiceRequestTO> fetchAllPipelineRequestChild(long parentRequestId) throws CMMException {
	
		try {
			List<ServiceRequestTO> serviceRequestList = (List<ServiceRequestTO>) getHibernateTemplate().find("from ServiceRequestTO where parentRequestId=? order by childRequestExecutionOrder", parentRequestId);
			if ((serviceRequestList == null) || serviceRequestList.isEmpty()) {
				LOG.debug("no data present in DB for Parent Request Id :: " + parentRequestId);
			}
			return serviceRequestList;
		} catch (ConstraintViolationException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: fetchAllPipelineRequestForParent", e);
		} catch (DataAccessException | HibernateException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: fetchAllPipelineRequestForParent", e);
		}
	}
	
	@Override
	public void updateServiceRequestStatus(long requestId, long serviceStatus) throws CMMException {
	
		try {
			ServiceRequestTO serviceRequestTO = (ServiceRequestTO) getHibernateTemplate().find("from ServiceRequestTO where id=?", requestId).get(0);
			serviceRequestTO.setStatusId(serviceStatus);
			getHibernateTemplate().update(serviceRequestTO);
		} catch (ConstraintViolationException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: updateServiceRequestStatus", e);
		} catch (DataAccessException | HibernateException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: updateServiceRequestStatus", e);
		}
	}
	
	@Override
	public List<PipelineRequestDetailsTO> fetchPipelineRequestDetails(long parentRequestId) throws CMMException {
	
		try {
			List<PipelineRequestDetailsTO> pipelineRequestDetailsList = (List<PipelineRequestDetailsTO>) getHibernateTemplate().find("from PipelineRequestDetailsTO where requestId=? order by phaseExecutionOrder", parentRequestId);
			if ((pipelineRequestDetailsList == null) || pipelineRequestDetailsList.isEmpty()) {
				LOG.debug("no data present in DB for Parent Request Id :: " + parentRequestId);
			}
			return pipelineRequestDetailsList;
		} catch (ConstraintViolationException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: fetchPipelineRequestDetails", e);
		} catch (DataAccessException | HibernateException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: fetchPipelineRequestDetails", e);
		}
	}
	
	@Override
	public void updateEnvStatusInPipelineRequestDetails(Long parentRequestId, Long environmentId, Long statusId) throws CMMException {
	
		try {
			PipelineRequestDetailsTO pipelineRequestDetailsTO = (PipelineRequestDetailsTO) getHibernateTemplate().find("from PipelineRequestDetailsTO where requestId=? and environmentId=?", parentRequestId, environmentId).get(0);
			pipelineRequestDetailsTO.setStatusId(statusId);
			getHibernateTemplate().update(pipelineRequestDetailsTO);
		} catch (ConstraintViolationException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: fetchPipelineRequestDetails", e);
		} catch (DataAccessException | HibernateException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: fetchPipelineRequestDetails", e);
		}
	}
	
	@Override
	public PipelineRequestDetailsTO fetchPhaseListforLoadingPipelineRequest(Long parentRequestId) throws CMMException {
	
		List<TestingPhaseTO> testingPhases = new ArrayList<TestingPhaseTO>(0);
		PipelineRequestDetailsTO pipelineRequestDetail = new PipelineRequestDetailsTO();
		try {
			List<Object[]> phaseList = (List<Object[]>) getHibernateTemplate().find("select distinct phaseId,phaseExecutionOrder from PipelineRequestDetailsTO where requestId=? order by phaseExecutionOrder", parentRequestId);
			for (Object[] phase : phaseList) {
				List<TestingPhaseTO> phaseList1 = (List<TestingPhaseTO>) getHibernateTemplate().find("from TestingPhaseTO where id=?", phase[0]);
				if (phaseList1.size() > 0L) {
					PipelineRequestDetailsTO pipelineReq = (PipelineRequestDetailsTO) getHibernateTemplate().find("from PipelineRequestDetailsTO where requestId=? and phaseId=?", parentRequestId, phase[0]).get(0);
					TestingPhaseTO testingPhase = phaseList1.get(0);
					testingPhase.setPhaseExecutionOrder(pipelineReq.getPhaseExecutionOrder());
					testingPhase.setPhaseStatus(pipelineReq.getStatusId());
					testingPhases.add(testingPhase);
				}
			}
			pipelineRequestDetail.setTestingPhases(testingPhases);
			return pipelineRequestDetail;
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getEnvironmentListForApplications", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getEnvironmentListForApplications", he);
		}
	}
	
	@Override
	public List<EnvironmentTO> fetchEnvironmentList(Long selectedPhase, long parentRequestId) throws CMMException {
	
		try {
			List<EnvironmentTO> environments = new ArrayList<EnvironmentTO>(0);
			List<PipelineRequestDetailsTO> environmentList = (List<PipelineRequestDetailsTO>) getHibernateTemplate().find("from PipelineRequestDetailsTO where requestId=? and phaseId =?", parentRequestId, selectedPhase);
			for (PipelineRequestDetailsTO env : environmentList) {
				List<EnvironmentTO> envList = (List<EnvironmentTO>) getHibernateTemplate().find("from EnvironmentTO where id =?", env.getEnvironmentId());
				List<StatusTO> statusList = (List<StatusTO>) getHibernateTemplate().find("from StatusTO where id =?", env.getStatusId());
				if (statusList.size() > 0L) {
					envList.get(0).setStatusTO(statusList.get(0));
				} else {
					envList.get(0).setStatusTO(null);
				}
				if (envList.size() > 0L) {
					environments.add(envList.get(0));
				}
			}
			return environments;
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getEnvironmentListForApplications", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getEnvironmentListForApplications", he);
		}
	}
	
	@Override
	public ServiceRequestTO fetchRequestDetail(Long selectedRequestId) throws CMMException {
	
		try {
			ServiceRequestTO serviceRequest = new ServiceRequestTO();
			List<ServiceRequestTO> reqList = (List<ServiceRequestTO>) getHibernateTemplate().find("from ServiceRequestTO where id =?", selectedRequestId);
			if (reqList.size() > 0L) {
				serviceRequest = reqList.get(0);
			}
			return serviceRequest;
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getEnvironmentListForApplications", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getEnvironmentListForApplications", he);
		}
	}
	
	@Override
	public ServiceRequestTO executeServiceAgain(Long requestId) throws CMMException {
	
		ServiceRequestTO serviceRequest = new ServiceRequestTO();
		try {
			List<ServiceRequestTO> serList = (List<ServiceRequestTO>) getHibernateTemplate().find("from ServiceRequestTO where id =? ", requestId);
			if (serList.size() > 0L) {
				serviceRequest = serList.get(0);
			}
			serviceRequest.setStatusId(CMMConstants.Framework.Entity.SERVICE_REQUEST_UNDER_IMPLEMENTATION);
			serviceRequest.setActionFlag(CMMConstants.Framework.ServiceRequestStatus.SERVICE_REQUEST_ACTIVE);
			getHibernateTemplate().update(serviceRequest);
		} catch (Exception e) {
			LOG.error("Problem encountered. ServiceRequestDAOImpl: executeServiceAgain", e);
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl:executeServiceAgain", e);
		}
		return serviceRequest;
	}
	
	@Override
	public List<ServiceRequestTO> fetchAllChildRequestForPipeline(long parentRequestId) throws CMMException {
	
		try {
			List<ServiceRequestTO> childRequestsList = (List<ServiceRequestTO>) getHibernateTemplate().find("from ServiceRequestTO where parentRequestId=?", parentRequestId);
			if ((childRequestsList == null) || childRequestsList.isEmpty()) {
				LOG.debug("no data present in DB for Parent Request Id :: " + parentRequestId);
			}
			return childRequestsList;
		} catch (ConstraintViolationException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: fetchAllChildRequestForPipeline", e);
		} catch (DataAccessException | HibernateException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: fetchAllChildRequestForPipeline", e);
		}
	}
	
	@Override
	public RepositoryMasterTO getRepositoryDetails(Long applicationReleaseId) throws CMMException {
	
		RepositoryMasterTO repositoryMasterTO = new RepositoryMasterTO();
		List<RepositoryMasterTO> repositoryMasterTOList = (List<RepositoryMasterTO>) getHibernateTemplate().find("from RepositoryMasterTO where applicationRelease.id =?", applicationReleaseId);
		if ((repositoryMasterTOList != null) && !repositoryMasterTOList.isEmpty()) {
			repositoryMasterTO = repositoryMasterTOList.get(0);
		}
		return repositoryMasterTO;
	}
	
	@Override
	public ApplicationReleaseSharedDetailsTO getSharedDetailsForRelease(Long applicationReleaseId) throws CMMException {
	
		DetachedCriteria criteria = DetachedCriteria.forClass(RepositoryMasterTO.class, "repo");
		criteria.add(Restrictions.eq("applicationRelease.id", applicationReleaseId));
		List<RepositoryMasterTO> repoMasterTo = (List<RepositoryMasterTO>) getHibernateTemplate().findByCriteria(criteria);
		DetachedCriteria criteria1 = DetachedCriteria.forClass(ApplicationReleaseSharedMappingTO.class, "appRelMapping");
		criteria1.add(Restrictions.eq("appRelMapping.repositoryMaster.id", repoMasterTo.get(0).getId()));
		List<ApplicationReleaseSharedMappingTO> applicationReleaseSharedMappingTO = (List<ApplicationReleaseSharedMappingTO>) getHibernateTemplate().findByCriteria(criteria1);
		DetachedCriteria criteria2 = DetachedCriteria.forClass(ApplicationReleaseSharedDetailsTO.class, "appReleaseSharedDetails");
		criteria2.add(Restrictions.eq("appReleaseSharedDetails.id", applicationReleaseSharedMappingTO.get(0).getSharedResourceId()));
		List<ApplicationReleaseSharedDetailsTO> applicationReleaseSharedDetailsTO = (List<ApplicationReleaseSharedDetailsTO>) getHibernateTemplate().findByCriteria(criteria2);
		return applicationReleaseSharedDetailsTO.get(0);
	}
	
	@Override
	public ApplicationReleaseNexusDetailsTO getNexusDetailsForRelease(Long applicationReleaseId) throws CMMException {
	
		DetachedCriteria criteria = DetachedCriteria.forClass(RepositoryMasterTO.class, "repo");
		criteria.add(Restrictions.eq("applicationRelease.id", applicationReleaseId));
		List<RepositoryMasterTO> repoMasterTo = (List<RepositoryMasterTO>) getHibernateTemplate().findByCriteria(criteria);
		DetachedCriteria criteria1 = DetachedCriteria.forClass(ApplicationReleaseSharedMappingTO.class, "appRelMapping");
		criteria1.add(Restrictions.eq("appRelMapping.repositoryMaster.id", repoMasterTo.get(0).getId()));
		List<ApplicationReleaseSharedMappingTO> applicationReleaseSharedMappingTO = (List<ApplicationReleaseSharedMappingTO>) getHibernateTemplate().findByCriteria(criteria1);
		DetachedCriteria criteria2 = DetachedCriteria.forClass(ApplicationReleaseNexusDetailsTO.class, "appReleaseNexusDetails");
		criteria2.add(Restrictions.eq("appReleaseNexusDetails.id", applicationReleaseSharedMappingTO.get(0).getSharedNexusId()));
		List<ApplicationReleaseNexusDetailsTO> applicationReleaseNexusDetailsTO = (List<ApplicationReleaseNexusDetailsTO>) getHibernateTemplate().findByCriteria(criteria2);
		return applicationReleaseNexusDetailsTO.get(0);
	}
	
	public int generateWorkFlowForAgentDeployment(ServiceRequestTO requestTO) throws CMMException {
	
		int success = -1;
		Session session = null;
		try {
			DetachedCriteria criteria1 = DetachedCriteria.forClass(WorkFlowLevelTO.class);
			criteria1.add(Restrictions.eq("clientId", requestTO.getClientId()));
			criteria1.add(Restrictions.eq("workflowId", requestTO.getWorkFlowId()));
			getHibernateTemplate().findByCriteria(criteria1);
			Connection conn = null;
			java.sql.CallableStatement cs = null;
			session = getSession();
			try {
				conn = ((SessionFactoryImplementor) session.getSessionFactory()).getConnectionProvider().getConnection();
				cs = conn.prepareCall("{call agent_deployment_workflow_generation(?,?,?,?,?)}");
				cs.setLong(1, requestTO.getProvisionedMachineId());
				cs.setLong(2, requestTO.getWorkFlowId());
				cs.setLong(3, requestTO.getCreatedById());
				cs.setLong(4, requestTO.getId());
				cs.registerOutParameter(5, java.sql.Types.INTEGER);
				cs.execute();
				success = cs.getInt(5);
			} finally {
				if (cs != null) {
					cs.close();
				}
				if (conn != null) {
					conn.close();
				}
			}
			if (success == 1) {
				WorkflowCurrentTO workflowCurrentTo = (WorkflowCurrentTO) getHibernateTemplate().find("from WorkflowCurrentTO where serviceRequestId=?", requestTO.getId()).get(0);
				if (workflowCurrentTo.getWfStatusTO().getId() == 3L) {
					return -1;
				}
			}
			return success;
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl:generateWorkflow", dae);
		} catch (SQLException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl:generateWorkflow", e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<ServiceRequestTO> fetchAllPipelineRequest() throws CMMException {
	
		try {
			return (List<ServiceRequestTO>) getHibernateTemplate().find("from ServiceRequestTO where serviceId=? order by id", CMMConstants.Framework.Service.DEPLOYMENT_PIPELINE_SERVICE_ID);
		} catch (ConstraintViolationException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: fetchAllPipelineRequest", e);
		} catch (DataAccessException | HibernateException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: fetchAllPipelineRequest", e);
		}
	}
	
	@Override
	public List<DeploymentPipelineForJiraTO> fetchAllJiraPipelineRequest() throws CMMException {
	
		Session session = null;
		List<DeploymentPipelineForJiraTO> jiraDeploymentPipelineList = new ArrayList<DeploymentPipelineForJiraTO>();
		try {
			session = getSession();
			StringBuilder query = new StringBuilder("Select a.Request_id id, a.Status_id statusId, a.Action_Flag actionFlag, b.jira_issue jira_issue from service_request a, service_jira_mapping b");
			query.append(" where a.Service_id= ");
			query.append(CMMConstants.Framework.Service.DEPLOYMENT_PIPELINE_SERVICE_ID);
			query.append(" and a.Status_id=");
			query.append(CMMConstants.Framework.Entity.SERVICE_REQUEST_UNDER_IMPLEMENTATION);
			query.append(" and b.deployment_flag=");
			query.append("'N'");
			query.append(" and a.Request_id = b.service_req_id");
			query.append(" and a.Action_Flag ='Y' ");
			List resultWithAliasedBean = session.createSQLQuery(query.toString()).addScalar("id", Hibernate.LONG).addScalar("statusId", Hibernate.LONG).addScalar("actionFlag", Hibernate.STRING).addScalar("jira_issue", Hibernate.STRING).setResultTransformer(Transformers.aliasToBean(DeploymentPipelineForJiraTO.class)).list();
			if (!resultWithAliasedBean.isEmpty()) {
				jiraDeploymentPipelineList = resultWithAliasedBean;
			}
			return jiraDeploymentPipelineList;
		} catch (ConstraintViolationException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: fetchAllJiraPipelineRequest", e);
		} catch (DataAccessException | HibernateException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: fetchAllJiraPipelineRequest", e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public void updateJiraDeploymentFlag(String jiraDeploymentFlag, Long id) throws CMMException {
	
		Session session = getSession();
		try {
			session.createQuery("update ServiceJiraMappingTO s set s.deployment_flag=?  where s.service_req_id= ? ").setParameter(0, jiraDeploymentFlag).setParameter(1, id).executeUpdate();
		} catch (HibernateException ex) {
			throw new CMMException("Error in updateJiraDeploymentFlag ", ex);
		} catch (Exception e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: fetchAllJiraPipelineRequest", e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<EnvironmentTO> getEnvironmentListForApplicationsRelease(Long selectedApplication) throws CMMException {
	
		List<EnvironmentTO> envList = new ArrayList<EnvironmentTO>(0);
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(EnvironmentApplicationTO.class, "envAppTO");
			criteria.add(Restrictions.eq("envAppTO.applicationTO.id", selectedApplication));
			List<EnvironmentApplicationTO> envAppList = (List<EnvironmentApplicationTO>) getHibernateTemplate().findByCriteria(criteria);
			for (EnvironmentApplicationTO envApp : envAppList) {
				EnvironmentTO env = new EnvironmentTO();
				if (envApp.getEnvironmentTO().getStatus().equals(CMMConstants.Framework.Entity.ENVIRONMENT_STATUS_AVAILABLE)) {
					env.setId(envApp.getEnvironmentTO().getId());
					env.setEnvironmentName(envApp.getEnvironmentTO().getEnvironmentName());
					envList.add(env);
				}
			}
			return envList;
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getEnvironmentListForApplications", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getEnvironmentListForApplications", he);
		}
	}
	
	@Override
	public NetraNexusDetailsTO getNetraNexusDetails() throws CMMException {
	
		NetraNexusDetailsTO netraNexusDetailsTO = new NetraNexusDetailsTO();
		try {
			List<NetraNexusDetailsTO> netraNexusDetailsList = (List<NetraNexusDetailsTO>) getHibernateTemplate().find("from NetraNexusDetailsTO");
			if (!netraNexusDetailsList.isEmpty()) {
				return netraNexusDetailsList.get(0);
			}
		} catch (ConstraintViolationException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getNetraNexusDetails", e);
		} catch (DataAccessException | HibernateException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getNetraNexusDetails", e);
		}
		return netraNexusDetailsTO;
	}
	
	@Override
	public String fetchRepoNameById(Long repoId) throws CMMException {
	
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(RepoTO.class);
			criteria.add(Restrictions.eq("repoid", repoId));
			criteria.setProjection(Projections.property("repoName"));
			return (String) getHibernateTemplate().findByCriteria(criteria).get(0);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl : fetchRepoNameById", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl : fetchRepoNameById", he);
		}
	}
	
	@Override
	public void updatePipelineDetailsStatus(PipelineRequestDetailsTO pipelineRequestDetailsTO) throws CMMException {
	
		try {
			boolean flag = true;
			List<ServiceRequestTO> serviceRequestList = (List<ServiceRequestTO>) getHibernateTemplate().find("from ServiceRequestTO where parentRequestId=? and environmentId=?", pipelineRequestDetailsTO.getRequestId(), pipelineRequestDetailsTO.getEnvironmentId());
			for (ServiceRequestTO service : serviceRequestList) {
				if (!((service.getStatusId() == CMMConstants.Framework.Entity.SERVICE_REQUEST_STATUS_COMPLETED) && CMMConstants.Framework.ServiceRequestStatus.SERVICE_REQUEST_COMPLETED.equals(service.getActionFlag()))) {
					flag = false;
					break;
				}
			}
			if (flag) {
				pipelineRequestDetailsTO.setStatusId(CMMConstants.Framework.Entity.SERVICE_REQUEST_STATUS_COMPLETED);
				getHibernateTemplate().update(pipelineRequestDetailsTO);
			}
		} catch (ConstraintViolationException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: fetchAllPipelineRequest", e);
		} catch (DataAccessException | HibernateException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: fetchAllPipelineRequest", e);
		}
	}
	
	@Override
	public ServiceRequestTO submitServiceRequest(ServiceRequestTO requestTO) throws CMMException {
	
		try {
			getHibernateTemplate().save(requestTO);
			int success = -1;
			EnvironmentTO envTO = new EnvironmentTO();
			envTO.setId(requestTO.getEnvironmentId());
			envTO.setCreatedById(requestTO.getCreatedById());
			if (requestTO.getClientId() != 0) {
				success = generateWorkflow(envTO, requestTO);
				requestTO.setSuccess(success);
			}
			requestTO.setSuccess(success);
		} catch (ConstraintViolationException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: submitServiceRequest", e);
		} catch (DataAccessException | HibernateException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: submitServiceRequest", e);
		}
		return requestTO;
	}
	
	@Override
	public List<EnvironmentTO> fetchEnvDetails(long selectedRequestId) throws CMMException {
	
		List<EnvironmentTO> environments = new ArrayList<EnvironmentTO>();
		try {
			List<Long> envList1 = (List<Long>) getHibernateTemplate().find("select distinct environmentId from PipelineRequestDetailsTO where requestId = ?", selectedRequestId);
			if (!envList1.isEmpty()) {
				for (int i = 0; i < envList1.size(); i++) {
					List<EnvironmentTO> environment = new ArrayList<EnvironmentTO>();
					Long env = envList1.get(i);
					environment = (List<EnvironmentTO>) getHibernateTemplate().find("from EnvironmentTO where id =?", env);
					if (environment.size() > 0L) {
						environments.add(environment.get(0));
					}
				}
			}
		} catch (Exception e) {
			LOG.error("Problem encountered. ServiceRequestDAOImpl: fetchEnvDetails", e);
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl:fetchEnvDetails", e);
		}
		return environments;
	}
	
	@Override
	public List<ReleasePlanningTO> getReleasePlannings(Long id) throws CMMException {
	
		List<ReleasePlanningTO> releasePlanningList = new ArrayList<>(0);
		try {
			if (id != null) {
				releasePlanningList = (List<ReleasePlanningTO>) getHibernateTemplate().find("from ReleasePlanningTO where applicationTO.id=?", id);
			}
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Problem encountered. getReleasePlannings", dae);
		}
		return releasePlanningList;
	}
	
	@Override
	public List<ReleasePlanningTO> getReleasePlanningNameFromId(Long id) throws CMMException {
	
		List<ReleasePlanningTO> releasePlanningList = new ArrayList<>(0);
		try {
			if (id != null) {
				releasePlanningList = (List<ReleasePlanningTO>) getHibernateTemplate().find("from ReleasePlanningTO where id=?", id);
			}
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Problem encountered. getReleasePlannings", dae);
		}
		return releasePlanningList;
	}
	
	@Override
	public List<ApplicationReleaseBuildTO> getAppReleaseBuildByReleaseAndPhaseId(long releaseId, long phaseId) throws CMMException {
	
		List<ApplicationReleaseBuildTO> applicationReleaseBuildList;
		try {
			applicationReleaseBuildList = (List<ApplicationReleaseBuildTO>) getHibernateTemplate().find("from ApplicationReleaseBuildTO where applicationReleaseId=? and selectedTestingPhase=?", releaseId, phaseId);
			if (applicationReleaseBuildList.isEmpty()) {
				applicationReleaseBuildList = (List<ApplicationReleaseBuildTO>) getHibernateTemplate().find("from ApplicationReleaseBuildTO where applicationReleaseId=? and selectedTestingPhase=?", releaseId, 0L);
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseBuildDAOImpl: fetchAppReleaseBuildByReleaseAndPhaseId", dae);
		} catch (HibernateException e) {
			logger.error(e);
			throw new CMMException("Problem encountered. ApplicationReleaseBuildDAOImpl: fetchAppReleaseBuildByReleaseAndPhaseId", e);
		}
		return applicationReleaseBuildList;
	}
	
	@Override
	public List<ApplicationReleaseBuildTO> getAppReleaseTestByReleaseAndPhaseId(long releaseId, long phaseId) throws CMMException {
	
		List<ApplicationReleaseBuildTO> applicationReleaseBuildList;
		try {
			applicationReleaseBuildList = (List<ApplicationReleaseBuildTO>) getHibernateTemplate().find("from ApplicationReleaseTestTO where applicationReleaseId=? and selectedTestingPhase=?", releaseId, phaseId);
			if (applicationReleaseBuildList.isEmpty()) {
				applicationReleaseBuildList = (List<ApplicationReleaseBuildTO>) getHibernateTemplate().find("from ApplicationReleaseBuildTO where applicationReleaseId=? and selectedTestingPhase=?", releaseId, 0L);
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseTestDAOImpl: fetchAppReleaseTestByReleaseAndPhaseId", dae);
		} catch (HibernateException e) {
			logger.error(e);
			throw new CMMException("Problem encountered. ApplicationReleaseTestDAOImpl: fetchAppReleaseTestByReleaseAndPhaseId", e);
		}
		return applicationReleaseBuildList;
	}
	
	@Override
	public List<ApplicationReleaseSourcecodeTO> fetchAppReleaseSourceCodeByReleaseAndPhaseId(long releaseId, long phaseId) throws CMMException {
	
		List<ApplicationReleaseSourcecodeTO> applicationReleaseSourceCodeList;
		try {
			applicationReleaseSourceCodeList = (List<ApplicationReleaseSourcecodeTO>) getHibernateTemplate().find("from ApplicationReleaseSourcecodeTO where applicationReleaseId=? and selectedTestingPhase=?", releaseId, phaseId);
			if (applicationReleaseSourceCodeList.isEmpty()) {
				applicationReleaseSourceCodeList = (List<ApplicationReleaseSourcecodeTO>) getHibernateTemplate().find("from ApplicationReleaseSourcecodeTO where applicationReleaseId=? and selectedTestingPhase=?", releaseId, 0L);
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseSourceCodeDAOImpl : getAppReleaseSourceCodeByReleaseAndPhaseId ", dae);
		} catch (HibernateException e) {
			logger.error(e);
			throw new CMMException("Problem encountered. ApplicationReleaseSourceCodeDAOImpl : getAppReleaseSourceCodeByReleaseAndPhaseId ", e);
		}
		return applicationReleaseSourceCodeList;
	}
	
	@Override
	public List<ApplicationReleaseDbTO> fetchAppReleaseDbDetailsByReleaseAndPhaseId(long releaseId, long phaseId) throws CMMException {
	
		List<ApplicationReleaseDbTO> applicationReleaseDbDetailList = new ArrayList<>();
		try {
			applicationReleaseDbDetailList = (List<ApplicationReleaseDbTO>) getHibernateTemplate().find("from ApplicationReleaseDbTO where applicationRelease.id=? and selectedTestingPhase=?", releaseId, phaseId);
			if (applicationReleaseDbDetailList.isEmpty()) {
				applicationReleaseDbDetailList = (List<ApplicationReleaseDbTO>) getHibernateTemplate().find("from ApplicationReleaseDbTO where applicationRelease.id=? and selectedTestingPhase=?", releaseId, 0L);
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ServiceRequestDaoImpl : fetchAppReleaseDbDetailsByReleaseAndPhaseId ", dae);
		} catch (HibernateException e) {
			logger.error(e);
			throw new CMMException("Problem encountered. ServiceRequestDaoImpl : fetchAppReleaseDbDetailsByReleaseAndPhaseId ", e);
		}
		return applicationReleaseDbDetailList;
	}
	
	@Override
	public List<SonarDetailTO> getCodeReviewByReleaseAndPhaseId(long releaseId, long phaseId) throws CMMException {
	
		List<SonarDetailTO> codeRevList = new ArrayList<>();
		try {
			codeRevList = (List<SonarDetailTO>) getHibernateTemplate().find("from SonarDetailTO where applicationReleaseId=? and selectedTestingPhase=?", releaseId, phaseId);
			if (codeRevList.isEmpty()) {
				codeRevList = (List<SonarDetailTO>) getHibernateTemplate().find("from SonarDetailTO where applicationReleaseId=? and selectedTestingPhase=?", releaseId, 0L);
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ServiceRequestDaoImpl : getCodeReviewByReleaseAndPhaseId ", dae);
		} catch (HibernateException e) {
			logger.error(e);
			throw new CMMException("Problem encountered. ServiceRequestDaoImpl : getCodeReviewByReleaseAndPhaseId ", e);
		}
		return codeRevList;
	}
	
	@Override
	public List<ApplicationReleaseTO> getReleaseProfiles(Long id) throws CMMException {
	
		List<ApplicationReleaseTO> releaseProfileList = new ArrayList<>(0);
		try {
			if (id != null) {
				releaseProfileList = (List<ApplicationReleaseTO>) getHibernateTemplate().find("from ApplicationReleaseTO where releasePlanningTO.id=?", id);
			}
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Problem encountered. getReleaseProfiles", dae);
		}
		return releaseProfileList;
	}
	
	@Override
	public List<TestingPhaseTO> getPhases(Long id) throws CMMException {
	
		List<ReleasePlanningPhasesTO> planningPhaseList = new ArrayList<>(0);
		List<TestingPhaseTO> phaseList = new ArrayList<>(0);
		try {
			if (id != null) {
				planningPhaseList = (List<ReleasePlanningPhasesTO>) getHibernateTemplate().find("from ReleasePlanningPhasesTO where releasePlanningTO.id=?", id);
			}
			for (ReleasePlanningPhasesTO releasePlanningPhasesTO : planningPhaseList) {
				phaseList.add(releasePlanningPhasesTO.getTestingPhaseTO());
			}
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Problem encountered. getPhases", dae);
		}
		return phaseList;
	}
	
	@Override
	public String fetchEnvName(long selectedRequestId) throws CMMException {
	
		try {
			List<String> envNames = (List<String>) getHibernateTemplate().find("select environmentName from EnvironmentTO where id=?", selectedRequestId);
			if ((envNames == null) || envNames.isEmpty()) {
				return "";
			}
			return envNames.get(0);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: fetchEnvName", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: fetchEnvName", he);
		}
	}
	
	@Override
	public List<TestingPhaseTO> getAppSpecificTestPhase(List<Long> dapp) throws CMMException {
	
		List<ApplicationReleasePhaseTO> test = new ArrayList<ApplicationReleasePhaseTO>();
		List<TestingPhaseTO> testFinal = new ArrayList<TestingPhaseTO>();
		List<Long> appList = dapp;
		Session session = getSession();
		try {
			if (!appList.isEmpty()) {
				String hql = "Select distinct phaseId from ApplicationReleasePhaseTO where applicationId in (:appId) and status = 'Y' ";
				Query q = session.createQuery(hql);
				q.setParameterList("appId", appList);
				test = q.list();
				try {
					String hql1 = "Select id ,name from TestingPhaseTO where id in (:primaryId)";
					Query q1 = session.createQuery(hql1);
					q1.setParameterList("primaryId", test);
					List<Object[]> obj = q1.list();
					for (Object[] temp : obj) {
						TestingPhaseTO tpt = new TestingPhaseTO();
						tpt.setId(Long.parseLong(String.valueOf(temp[0])));
						tpt.setName(temp[1].toString());
						testFinal.add(tpt);
					}
				} catch (Exception e) {
					logger.error("the exception is ", e);
				}
			} else {
				testFinal = (List<TestingPhaseTO>) getHibernateTemplate().find("from TestingPhaseTO");
			}
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl:getAppSpecificTestPhase()", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl:getAppSpecificTestPhase()", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return testFinal;
	}
	
	@Override
	public List<ServiceRequestTO> searchServiceToUnschedule(ServiceRequestTO servicerequestTO) {
	
		Long userId1 = servicerequestTO.getUserId();
		DateFormat df = new SimpleDateFormat("dd MMM, yyyy HH:00");
		DateFormat df2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:00");
		StringBuilder query = new StringBuilder("select s.id ,s.cronExp ,s.serviceId ,s.environmentId ,s.statusId,s.actionFlag from ServiceRequestTO s  LEFT JOIN s.workflowCurrentTO wrf where s.isScheduled='Y' AND s.createdById=? AND s.cronExp <> null AND s.cronExp <> \'\' AND (wrf.wfStatusTO Is NULL OR wrf.wfStatusTO not in  (5 , 6))");
		List<ServiceRequestTO> requestUnscheduleList = new ArrayList<ServiceRequestTO>();
		List<Object[]> obj = new ArrayList<Object[]>();
		try {
			if (servicerequestTO.getSelectedService() != 0) {
				query.append(String.format(" and s.serviceId =%d", servicerequestTO.getSelectedService()));
			}
			if (servicerequestTO.getRequestId() != 0) {
				query.append(String.format(" and s.id =%d", servicerequestTO.getRequestId()));
			}
			if (!"".equals(servicerequestTO.getStartTimeStr()) && "".equals(servicerequestTO.getEndTimeStr())) {
				String startDate = df2.format(df.parse(servicerequestTO.getStartTimeStr()));
				query.append(" and s.createdByDate >= '" + startDate + "'");
			}
			if ("".equals(servicerequestTO.getStartTimeStr()) && !"".equals(servicerequestTO.getEndTimeStr())) {
				String endDate = df2.format(df.parse(servicerequestTO.getEndTimeStr()));
				query.append(" and s.createdByDate <= '" + endDate + "'");
			}
			if (!"".equals(servicerequestTO.getStartTimeStr()) && !"".equals(servicerequestTO.getEndTimeStr())) {
				String startDate = df2.format(df.parse(servicerequestTO.getStartTimeStr()));
				String endDate = df2.format(df.parse(servicerequestTO.getEndTimeStr()));
				query.append(" and s.createdByDate >= '" + startDate + "' and s.createdByDate <= '" + endDate + "'");
			}
			if (servicerequestTO.getSearchCount() == 0) {
				obj = (List<Object[]>) getHibernateTemplate().find(query.toString(), userId1);
			} else {
				obj = (List<Object[]>) getHibernateTemplate().find(query.toString(), userId1).subList(servicerequestTO.getFirstResult(), servicerequestTO.getFirstResult() + servicerequestTO.getTableSize());
			}
			for (Object[] serviceRequestTOentity : obj) {
				ServiceRequestTO toEntity = new ServiceRequestTO();
				toEntity.setId((Long) serviceRequestTOentity[0]);
				toEntity.setCronExp((String) serviceRequestTOentity[1]);
				toEntity.setServiceId((Long) serviceRequestTOentity[2]);
				toEntity.setEnvironmentId((Long) serviceRequestTOentity[3]);
				toEntity.setStatusId((Long) serviceRequestTOentity[4]);
				toEntity.setActionFlag((String) serviceRequestTOentity[5]);
				requestUnscheduleList.add(toEntity);
			}
		} catch (Exception ex) {
			logger.error("Problem encountered.ServiceRequestDAOImpl: searchCompletedServiceStatus.", ex);
		}
		return requestUnscheduleList;
	}
	
	@Override
	public void changeFlagForUnschedule(Long requestId) {
	
		Session session = getSession();
		try {
			session.createQuery("update ServiceRequestTO s set s.isScheduled='N' , s.statusId= ? , s.actionFlag=? where s.id = ? ").setParameter(0, CMMConstants.Framework.Entity.SERVICE_REQUEST_STATUS_COMPLETED).setParameter(1, CMMConstants.Framework.ServiceRequestStatus.SERVICE_REQUEST_COMPLETED).setParameter(2, requestId).executeUpdate();
		} catch (HibernateException ex) {
			LOG.error("Problem encountered.ServiceRequestDAOImpl: changeFlagForUnschedule", ex);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<ServiceTO> getAllServicesToUnschedule(Long clientId, Long roleId) throws CMMException {
	
		List<ServiceTO> servTO = new ArrayList<ServiceTO>(0);
		Session session = getSession();
		try {
			if (clientId == 0) {
				return (List<ServiceTO>) getHibernateTemplate().find("from ServiceTO where status= ? and subServiceFlag= ? ", CMMConstants.Framework.Entity.SERVICES_ACTIVE, CMMConstants.Framework.ServiceFlag.SUBSERVICE_FLAG_Y);
			}
			String hql = "select s.id,s.name from ServiceTO s inner join s.serviceClientTO c where c.clientId=(:clientId) and c.roleId = (:roleId)";
			Query q = session.createQuery(hql);
			q.setParameter("clientId", clientId);
			q.setParameter("roleId", roleId);
			List<Object[]> obj = q.list();
			for (Object[] temp : obj) {
				ServiceTO services = new ServiceTO();
				services.setId((Long) temp[0]);
				services.setName(temp[1].toString());
				servTO.add(services);
			}
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl:getAllServices(Long)", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl:getAllServices(Long)", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return servTO;
	}
	
	@Override
	public List<TestingPhaseTO> getPhasesForApplication(Long id) throws CMMException {
	
		try {
			return (List<TestingPhaseTO>) getHibernateTemplate().find("select t from ApplicationReleasePhaseTO a, TestingPhaseTO t where a.testingPhase.id=t.id and a.stat like 'Y' and a.applicationId=?", id);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getPhasesForApplication", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl: getPhasesForApplication", he);
		}
	}
	
	@Override
	public List<TestingPhaseTO> getPhasesForApplicationAndRelease(Long releaseId) throws CMMException {
	
		try {
			List<TestingPhaseTO> phases = new ArrayList<TestingPhaseTO>(0);
			phases = (List<TestingPhaseTO>) getHibernateTemplate().find("select t from ReleasePlanningPhasesTO r, TestingPhaseTO t where r.testingPhaseTO.id=t.id and r.releasePlanningTO.id=?", releaseId);
			return phases;
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getPhasesForApplicationAndRelease", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl: getPhasesForApplicationAndRelease", he);
		}
	}
	
	@Override
	public List<TestingPhaseTO> getPhasesForApplication1(Long id, Long pid) throws CMMException {
	
		try {
			ApplicationReleasePhaseTO app = (ApplicationReleasePhaseTO) getHibernateTemplate().find("from ApplicationReleasePhaseTO where phaseId=? and applicationId=?", pid, id).get(0);
			List<TestingPhaseTO> phases = new ArrayList<TestingPhaseTO>(0);
			phases = (List<TestingPhaseTO>) getHibernateTemplate().find("select t from ApplicationReleasePhaseTO a, TestingPhaseTO t where a.testingPhase.id=t.id and a.stat like 'Y' and a.applicationId=? and a.order > ?", id, app.getOrder());
			return phases;
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getPhasesForApplication", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl: getPhasesForApplication", he);
		}
	}
	
	@Override
	public List<TestingPhaseTO> getPhasesForAppAndRel(Long applicationId, Long phaseId, Long releaseId) throws CMMException {
	
		try {
			ApplicationReleasePhaseTO app = (ApplicationReleasePhaseTO) getHibernateTemplate().find("from ApplicationReleasePhaseTO where phaseId=? and applicationId=? and releasePlanningTO.id=?", phaseId, applicationId, releaseId).get(0);
			return (List<TestingPhaseTO>) getHibernateTemplate().find("select t from ApplicationReleasePhaseTO a, TestingPhaseTO t where a.testingPhase.id=t.id and a.stat like 'Y' and a.applicationId=? and a.releasePlanningTO.id=? and a.order > ?", applicationId, releaseId, app.getOrder());
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getPhasesForAppAndRel", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl: getPhasesForAppAndRel", he);
		}
	}
	
	@Override
	public List<EnvironmentTO> getAllEnvironmentsAccToPhases2(Long selectedApplication, Long selectedTestingCycle) throws CMMException {
	
		try {
			return (List<EnvironmentTO>) getHibernateTemplate().find("select e from EnvironmentTO e,EnvironmentApplicationTO ea where ea.environmentTO.id= e.id  and ea.applicationTO.id=? and ea.testingPhaseTO.id=? and status=?", selectedApplication, selectedTestingCycle, Framework.Entity.ENVIRONMENT_AVAILABLE);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getAllEnvironmentsAccToPhases", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getAllEnvironmentsAccToPhases", he);
		}
	}
	
	@Override
	public List<EnvironmentTO> getAllEnvironmentsAccToPhases3(Long selectedApplication, Long selectedTestingCycle) throws CMMException {
	
		try {
			return (List<EnvironmentTO>) getHibernateTemplate().find("select e from EnvironmentTO e,EnvironmentApplicationTO ea where ea.environmentTO.id= e.id  and ea.applicationTO.id=? and ea.testingPhaseTO.id=? and status=? and ea.applicationReleaseTO.id is not null", selectedApplication, selectedTestingCycle, Framework.Entity.ENVIRONMENT_AVAILABLE);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getAllEnvironmentsAccToPhases", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getAllEnvironmentsAccToPhases", he);
		}
	}
	
	@Override
	public List<EnvironmentTO> getEnvAccToPhaseAndRelease(Long selectedApplication, Long selectedTestingCycle, Long selectedRelease) throws CMMException {
	
		try {
			return (List<EnvironmentTO>) getHibernateTemplate().find("select e from EnvironmentTO e,EnvironmentApplicationTO ea where ea.environmentTO.id= e.id  and ea.applicationTO.id=? and ea.testingPhaseTO.id=? and status=? and ea.applicationReleaseTO.releasePlanningTO.id=? and ea.applicationReleaseTO.id is not null", selectedApplication, selectedTestingCycle, Framework.Entity.ENVIRONMENT_AVAILABLE, selectedRelease);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getAllEnvironmentsAccToPhases", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getAllEnvironmentsAccToPhases", he);
		}
	}
	
	@Override
	public List<EnvironmentTO> getAllEnvironmentsAccToPhasesTC1(Long selectedApplication, Long selectedTestingCycle) throws CMMException {
	
		try {
			return (List<EnvironmentTO>) getHibernateTemplate().find("select e from EnvironmentTO e,EnvironmentApplicationTO ea where ea.environmentTO.id= e.id and ea.applicationTO.id=? and e.profileId is not null and ea.testingPhaseTO.id=? and status=?", selectedApplication, selectedTestingCycle, Framework.Entity.ENVIRONMENT_AVAILABLE);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getAllEnvironmentsAccToPhases", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getAllEnvironmentsAccToPhases", he);
		}
	}
	
	@Override
	public List<EnvironmentTO> getEnvAccToPhaseAndReleasePhases(Long selectedApplication, Long selectedTestingCycle, Long selectedRelease) throws CMMException {
	
		try {
			return (List<EnvironmentTO>) getHibernateTemplate().find("select e from EnvironmentTO e,EnvironmentApplicationTO ea where ea.environmentTO.id= e.id and ea.applicationTO.id=? and e.profileId is not null and ea.testingPhaseTO.id=? and status=? and ea.applicationReleaseTO.releasePlanningTO.id=?", selectedApplication, selectedTestingCycle, Framework.Entity.ENVIRONMENT_AVAILABLE, selectedRelease);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getEnvAccToPhaseAndReleasePhases", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getEnvAccToPhaseAndReleasePhases", he);
		}
	}
	
	@Override
	public List<EnvironmentTO> getAllEnvForSelectedApplication(Long selectedApplication, Long selectedEnvironment) throws CMMException {
	
		try {
			return (List<EnvironmentTO>) getHibernateTemplate().find("select e from EnvironmentTO e, EnvironmentApplicationTO ea where ea.environmentTO.id=e.id and ea.applicationTO.id=? and e.profileId is not null and status=? and e.id <> ?", selectedApplication, Framework.Entity.ENVIRONMENT_AVAILABLE, selectedEnvironment);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getEnvAccToPhaseAndReleasePhases", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getEnvAccToPhaseAndReleasePhases", he);
		}
	}
	
	@Override
	public List<ProvisionedMachineOSTO> fetchProvisionedMachineOSDetails(Long provisionedMachineId) throws CMMException {
	
		try {
			return (List<ProvisionedMachineOSTO>) getHibernateTemplate().find("from ProvisionedMachineOSTO where provisionedMachineId=?", provisionedMachineId);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getAllEnvironmentsAccToPhases", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getAllEnvironmentsAccToPhases", he);
		}
	}
	
	@Override
	public List<ApplicationTO> getAllApplication(Long requestId) throws CMMException {
	
		try {
			return (List<ApplicationTO>) getHibernateTemplate().find("SELECT a from ApplicationTO a, ServiceRequestTO s where s.applicationId=a.id and s.id =?", requestId);
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getAllApplication", dae);
		}
	}
	
	@Override
	public ApplicationReleaseTO getReleaseForApplications(Long requestId) throws CMMException {
	
		try {
			List<ApplicationReleaseTO> appRelList = (List<ApplicationReleaseTO>) getHibernateTemplate().find("SELECT r from ServiceRequestTO s, ApplicationReleaseTO r where s.applicationReleaseId=r.id and s.id=?", requestId);
			ApplicationReleaseTO apprel = new ApplicationReleaseTO();
			if (appRelList.size() > 0L) {
				apprel = appRelList.get(0);
			}
			return apprel;
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getAllApplication", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getAllApplication", he);
		}
	}
	
	@Override
	public List<String> getReleaseForMultipleEnvironment(Long environmentId) throws CMMException {
	
		List<String> appRelNameList = new ArrayList<String>();
		try {
			List<Long> appRelIdSubList = (List<Long>) getHibernateTemplate().find("SELECT envApp.releaseId from EnvironmentApplicationTO envApp where envApp.environmentTO.id =? ", environmentId);
			for (Long relId : appRelIdSubList) {
				List<String> relName = (List<String>) getHibernateTemplate().find("SELECT appRel.name from ApplicationReleaseTO appRel where appRel.id =? ", relId);
				if (!relName.isEmpty()) {
					appRelNameList.add(relName.get(0));
				} else {
					appRelNameList.add("NA");
				}
			}
			return appRelNameList;
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getReleaseForMultipleEnvironment", dae);
		}
	}
	
	@Override
	public List<String> getApplicationsForMultipleEnvironment(Long environmentId) throws CMMException {
	
		List<String> appNameList = new ArrayList<String>();
		try {
			List<Long> appRelIdList = new ArrayList<Long>();
			List<Long> subEnvIdList = (List<Long>) getHibernateTemplate().find("SELECT env.id from EnvironmentTO env where env.parentEnv=?", environmentId);
			for (Long subEnv : subEnvIdList) {
				List<Long> appRelIdSubList = (List<Long>) getHibernateTemplate().find("SELECT envApp.applicationTO.id from EnvironmentApplicationTO envApp where envApp.environmentTO.id =? ", subEnv);
				appRelIdList.add(appRelIdSubList.get(0));
			}
			for (Long appId : appRelIdList) {
				List<String> relName = (List<String>) getHibernateTemplate().find("SELECT app.appName from ApplicationTO app where app.id =? ", appId);
				appNameList.add(relName.get(0));
			}
			return appNameList;
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getReleaseForMultipleEnvironment", dae);
		}
	}
	
	@Override
	public List<ApplicationTO> getAllApplicationForServiceDetails(Long requestId) throws CMMException {
	
		try {
			return (List<ApplicationTO>) getHibernateTemplate().find("SELECT a from ApplicationTO a, ServiceRequestTO s,ServiceRequestDetailsTO sd where s.applicationId=a.id and s.id=sd.requestId and s.id =?", requestId);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getAllApplicationForServiceDetails", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getAllApplicationForServiceDetails", he);
		}
	}
	
	@Override
	public void resetVMDetails(int noCPU, int memoryMB, Long id) {
	
		try {
			ProvisionedMachineTO Platformto = (ProvisionedMachineTO) getHibernateTemplate().find("from ProvisionedMachineTO where id=?", id).get(0);
			Platformto.setCPU((long) noCPU);
			Platformto.setRAM((long) memoryMB);
			getHibernateTemplate().update(Platformto);
		} catch (DataIntegrityViolationException | ConstraintViolationException div) {
			LOG.error("Problem encountered. ServiceRequestDAOImpl: resetVMDetails", div);
		} catch (DataAccessException | HibernateException dae) {
			LOG.error("Problem encountered. ServiceRequestDAOImpl: resetVMDetails", dae);
		}
	}
	
	@Override
	public void updateServiceRequestRelease(Long requestid, Long environmentid) throws CMMException {
	
		try {
			Long currentReleaseId = (Long) getHibernateTemplate().find("select releaseId from EnvironmentApplicationTO e where e.environmentTO.id=?", environmentid).get(0);
			ServiceRequestTO serv = new ServiceRequestTO();
			serv = (ServiceRequestTO) getHibernateTemplate().find("from ServiceRequestTO where id=?", requestid).get(0);
			serv.setApplicationReleaseId(currentReleaseId);
			getHibernateTemplate().update(serv);
		} catch (DataIntegrityViolationException | ConstraintViolationException div) {
			LOG.error(div);
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: updateServiceRequestRelease", div);
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: updateServiceRequestRelease", dae);
		}
	}
	
	@Override
	public void updateServiceRequestReleaseForCreateEnv(Long requestid, Long environmentid) throws CMMException {
	
		try {
			EnvironmentApplicationTO ea = new EnvironmentApplicationTO();
			ServiceRequestTO serv = (ServiceRequestTO) getHibernateTemplate().find("from ServiceRequestTO where id=?", requestid).get(0);
			serv.setApplicationReleaseId(null);
			getHibernateTemplate().update(serv);
			ea = (EnvironmentApplicationTO) getHibernateTemplate().find("from EnvironmentApplicationTO a where a.environmentTO.id=?", environmentid).get(0);
			ea.setReleaseId(null);
			getHibernateTemplate().update(ea);
		} catch (DataIntegrityViolationException | ConstraintViolationException div) {
			LOG.error(div);
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: updateServiceRequestRelease", div);
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: updateServiceRequestRelease", dae);
		}
	}
	
	@Override
	public List<EnvironmentTO> fetchEnvironments(Long numberOfDays) throws CMMException {
	
		List<EnvironmentTO> environments = new ArrayList<EnvironmentTO>();
		Date currentDate = DateUtils.getStartTime(new Date());
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		formatter.format(currentDate);
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(ServiceRequestTO.class, "serviceRequest");
			Calendar c = Calendar.getInstance();
			c.add(Calendar.DATE, Integer.parseInt(numberOfDays.toString()));
			String dateStr = formatter.format(c.getTime());
			Date formattedDate = formatter.parse(dateStr);
			criteria.add(Restrictions.eq("endTime", formattedDate));
			criteria.add(Restrictions.eq("statusId", CMMConstants.Framework.Entity.SERVICE_REQUEST_STATUS_COMPLETED));
			List<ServiceRequestTO> serviceRequestTO = (List<ServiceRequestTO>) getHibernateTemplate().findByCriteria(criteria);
			EnvironmentTO environment = new EnvironmentTO();
			for (ServiceRequestTO serviceRequest : serviceRequestTO) {
				environment = (EnvironmentTO) getHibernateTemplate().find("select e from EnvironmentTO e where e.id=? ", serviceRequest.getEnvironmentId()).get(0);
				environments.add(environment);
			}
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: fetchEnvironments", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: fetchEnvironments", he);
		} catch (ParseException pe) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: fetchEnvironments", pe);
		}
		return environments;
	}
	
	@Override
	public List<EnvironmentTO> fetchEnvironmentsForDeletion() throws CMMException {
	
		List<EnvironmentTO> environments = new ArrayList<EnvironmentTO>();
		Date currentDate = DateUtils.getStartTime(new Date());
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		String formattedCurrentDate = formatter.format(currentDate);
		try {
			environments = (List<EnvironmentTO>) getHibernateTemplate().find("select e from EnvironmentTO e , ServiceRequestTO s  where s.environmentId = e.id and s.endTime = ? group by e.environmentName", formattedCurrentDate);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: fetchEnvironmentsForDeletion", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: fetchEnvironmentsForDeletion", he);
		}
		return environments;
	}
	
	@Override
	public EnvironmentDockerTO getEnvDockerDetails(long envID) throws CMMException {
	
		try {
			return (EnvironmentDockerTO) getHibernateTemplate().find("from EnvironmentDockerTO where envId=?", envID).get(0);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl:getEnvDockerDetails()", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl:getEnvDockerDetails()", he);
		}
	}
	
	@Override
	public ServiceRequestTO submitDbRefreshRequest(ServiceRequestTO requestTO) throws CMMException {
	
		try {
			getHibernateTemplate().save(requestTO);
		} catch (ConstraintViolationException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: submitServiceRequest", e);
		} catch (DataAccessException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: submitServiceRequest", e);
		} catch (HibernateException e) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: submitServiceRequest", e);
		}
		return requestTO;
	}
	
	/***** jira change start *****/
	@Override
	public void updateJiraServiceReqMapping(ServiceJiraMappingTO serJiraMapTO) throws CMMException {
	
		try {
			getHibernateTemplate().save(serJiraMapTO);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. submitBuild", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. submitBuild", he);
		}
	}
	
	@Override
	public String getJiraIssueForServiceRequest(Long reqId) throws CMMException {
	
		String issue = null;
		ServiceJiraMappingTO servJiraMapTO = null;
		List<ServiceJiraMappingTO> issueList = new ArrayList<ServiceJiraMappingTO>();
		try {
			servJiraMapTO = new ServiceJiraMappingTO();
			issueList = (List<ServiceJiraMappingTO>) getHibernateTemplate().find("from ServiceJiraMappingTO where service_req_id=?", reqId);
			if (!issueList.isEmpty()) {
				servJiraMapTO = issueList.get(0);
				issue = servJiraMapTO.getJira_issue();
			}
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. submitBuild", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. submitBuild", he);
		}
		return issue;
	}
	
	@Override
	public String getSelectedApplicationName(Long appID) throws CMMException {
	
		ApplicationTO appTo = (ApplicationTO) getHibernateTemplate().find("from ApplicationTO where id=?", appID).get(0);
		return appTo.getAppName();
	}
	
	@Override
	public String getSelectedReleaseName(Long relID) throws CMMException {
	
		ApplicationReleaseTO appRelTo = (ApplicationReleaseTO) getHibernateTemplate().find("from ApplicationReleaseTO where id=?", relID).get(0);
		return appRelTo.getName();
	}
	
	@Override
	public JIRAConfigTO getJiraConfiguration() throws CMMException {
	
		JIRAConfigTO jiraconfig = new JIRAConfigTO();
		try {
			List<JIRAConfigTO> list = (List<JIRAConfigTO>) getHibernateTemplate().find("from JIRAConfigTO where toolName=?", CMMConstants.Framework.JiraServiceName.TRACKING_TOOL);
			if (!list.isEmpty()) {
				jiraconfig = list.get(0);
			}
			return jiraconfig;
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. getJiraConfiguration", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. getJiraConfiguration", he);
		}
	}
	
	/***** jira change ends *****/
	/** For Service Count Dashboard **/
	@Override
	public List<ServiceRequestTO> getBuildList(UserTO userTo, Long serviceId) throws CMMException {
	
		List<ServiceRequestTO> list = new ArrayList<ServiceRequestTO>(0);
		try {
			if (userTo.getClientId() == 0L) {
				list = (List<ServiceRequestTO>) getHibernateTemplate().find("from ServiceRequestTO where actionFlag in ('C','E') and serviceId in (" + CMMConstants.Framework.Service.RELEASE_DEPLOYMENT_SERVICE + " , " + CMMConstants.Framework.Service.BUILD_SERVICE_ID + " , " + CMMConstants.Framework.Service.APPLICATION_DEPLOYMENT_SERVICE + "," + CMMConstants.Framework.Service.CREATE_ENVIRONMENT_SERVICE_ID + "," + CMMConstants.Framework.Service.CODE_ANALYSIS_SERVICE_ID + "," + CMMConstants.Framework.Service.DATABASE_REFRESH_SERVICE_ID + " )  order by id desc");
			} else {
				list = (List<ServiceRequestTO>) getHibernateTemplate().find("from ServiceRequestTO where actionFlag in ('C','E') and serviceId in (" + CMMConstants.Framework.Service.RELEASE_DEPLOYMENT_SERVICE + " , " + CMMConstants.Framework.Service.BUILD_SERVICE_ID + " , " + CMMConstants.Framework.Service.APPLICATION_DEPLOYMENT_SERVICE + "," + CMMConstants.Framework.Service.CREATE_ENVIRONMENT_SERVICE_ID + "," + CMMConstants.Framework.Service.CODE_ANALYSIS_SERVICE_ID + "," + CMMConstants.Framework.Service.DATABASE_REFRESH_SERVICE_ID + " )  and createdById =" + userTo.getId() + " order by id desc");
			}
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. getBuildList", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. getBuildList", he);
		}
		return list;
	}
	
	@Override
	public List<ServiceRequestTO> getBuildForBU(UserTO userTo, Long clientId) throws CMMException {
	
		List<ServiceRequestTO> list = new ArrayList<ServiceRequestTO>(0);
		List<ServiceRequestTO> list1 = new ArrayList<ServiceRequestTO>(0);
		List<Long> appIds = new ArrayList<Long>(0);
		try {
			appIds = (List<Long>) getHibernateTemplate().find("select id from ApplicationTO where clientId=?", clientId);
			if (!appIds.isEmpty()) {
				if (userTo.getClientId() == 0L) {
					list = (List<ServiceRequestTO>) getHibernateTemplate().findByNamedParam("from ServiceRequestTO where actionFlag in ('C','E') and serviceId in (" + CMMConstants.Framework.Service.RELEASE_DEPLOYMENT_SERVICE + " , " + CMMConstants.Framework.Service.BUILD_SERVICE_ID + " , " + CMMConstants.Framework.Service.APPLICATION_DEPLOYMENT_SERVICE + "," + CMMConstants.Framework.Service.CREATE_ENVIRONMENT_SERVICE_ID + "," + CMMConstants.Framework.Service.CODE_ANALYSIS_SERVICE_ID + "," + CMMConstants.Framework.Service.DATABASE_REFRESH_SERVICE_ID + " )  and applicationId in (:applicationIds) order by id desc", "applicationIds", appIds);
				} else {
					list = (List<ServiceRequestTO>) getHibernateTemplate().findByNamedParam("from ServiceRequestTO where actionFlag in ('C','E') and serviceId in (" + CMMConstants.Framework.Service.RELEASE_DEPLOYMENT_SERVICE + " , " + CMMConstants.Framework.Service.BUILD_SERVICE_ID + " , " + CMMConstants.Framework.Service.APPLICATION_DEPLOYMENT_SERVICE + "," + CMMConstants.Framework.Service.CREATE_ENVIRONMENT_SERVICE_ID + "," + CMMConstants.Framework.Service.CODE_ANALYSIS_SERVICE_ID + "," + CMMConstants.Framework.Service.DATABASE_REFRESH_SERVICE_ID + " )  and applicationId in (:applicationIds) and createdById =" + userTo.getId() + " order by id desc", "applicationIds", appIds);
				}
			}
			list1 = getBuildForBUEnv(userTo, clientId);
			if (!list1.isEmpty()) {
				list.addAll(list1);
			}
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Problem encountered. getBuildForBU", dae);
		}
		return list;
	}
	
	public List<ServiceRequestTO> getBuildForBUEnv(UserTO userTo, Long clientId) throws CMMException {
	
		List<ServiceRequestTO> list = new ArrayList<ServiceRequestTO>(0);
		List<Long> envIds = new ArrayList<Long>(0);
		try {
			envIds = (List<Long>) getHibernateTemplate().find("select ea.environmentTO.id from ApplicationTO a, EnvironmentApplicationTO ea where a.id=ea.applicationTO.id  and a.clientId=?", clientId);
			if (!envIds.isEmpty()) {
				if (userTo.getClientId() == 0L) {
					list = (List<ServiceRequestTO>) getHibernateTemplate().findByNamedParam("from ServiceRequestTO where actionFlag in ('C','E') and serviceId in (" + CMMConstants.Framework.Service.CREATE_ENVIRONMENT_SERVICE_ID + " )  and environmentId in (:environmentIds) order by id desc", "environmentIds", envIds);
				} else {
					list = (List<ServiceRequestTO>) getHibernateTemplate().findByNamedParam("from ServiceRequestTO where actionFlag in ('C','E') and serviceId in (" + CMMConstants.Framework.Service.CREATE_ENVIRONMENT_SERVICE_ID + " )  and environmentId in (:environmentIds) and createdById =" + userTo.getId() + " order by id desc", "environmentIds", envIds);
				}
			}
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. getBuildForBU", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. getBuildForBU", he);
		}
		return list;
	}
	
	@Override
	public List<ServiceRequestTO> getBuildForProject(UserTO userTo, Long projectId) throws CMMException {
	
		List<ServiceRequestTO> list = new ArrayList<ServiceRequestTO>(0);
		List<ServiceRequestTO> list1 = new ArrayList<ServiceRequestTO>(0);
		List<Long> appIds = new ArrayList<Long>(0);
		try {
			appIds = (List<Long>) getHibernateTemplate().find("select id from ApplicationTO where selectedProject=?", projectId);
			if (!appIds.isEmpty()) {
				if (userTo.getClientId() == 0L) {
					list = (List<ServiceRequestTO>) getHibernateTemplate().findByNamedParam("from ServiceRequestTO where actionFlag in ('C','E') and serviceId in (" + CMMConstants.Framework.Service.RELEASE_DEPLOYMENT_SERVICE + " , " + CMMConstants.Framework.Service.BUILD_SERVICE_ID + " , " + CMMConstants.Framework.Service.APPLICATION_DEPLOYMENT_SERVICE + "," + CMMConstants.Framework.Service.CREATE_ENVIRONMENT_SERVICE_ID + "," + CMMConstants.Framework.Service.CODE_ANALYSIS_SERVICE_ID + "," + CMMConstants.Framework.Service.DATABASE_REFRESH_SERVICE_ID + " )  and applicationId in (:applicationIds) order by id desc", "applicationIds", appIds);
				} else {
					list = (List<ServiceRequestTO>) getHibernateTemplate().findByNamedParam("from ServiceRequestTO where actionFlag in ('C','E') and serviceId in (" + CMMConstants.Framework.Service.RELEASE_DEPLOYMENT_SERVICE + " , " + CMMConstants.Framework.Service.BUILD_SERVICE_ID + " , " + CMMConstants.Framework.Service.APPLICATION_DEPLOYMENT_SERVICE + "," + CMMConstants.Framework.Service.CREATE_ENVIRONMENT_SERVICE_ID + "," + CMMConstants.Framework.Service.CODE_ANALYSIS_SERVICE_ID + "," + CMMConstants.Framework.Service.DATABASE_REFRESH_SERVICE_ID + " )  and applicationId in (:applicationIds) and createdById =" + userTo.getId() + " order by id desc", "applicationIds", appIds);
				}
			}
			list1 = getBuildForProjectEnv(userTo, projectId);
			if (!list1.isEmpty()) {
				list.addAll(list1);
			}
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. getBuildForProject", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. getBuildForProject", he);
		} catch (Exception he) {
			throw new CMMException("Problem encountered. getBuildForProject", he);
		}
		return list;
	}
	
	public List<ServiceRequestTO> getBuildForProjectEnv(UserTO userTo, Long projectId) throws CMMException {
	
		List<ServiceRequestTO> list = new ArrayList<ServiceRequestTO>(0);
		List<Long> envIds = new ArrayList<Long>(0);
		try {
			envIds = (List<Long>) getHibernateTemplate().find("select ea.environmentTO.id from ApplicationTO a, EnvironmentApplicationTO ea where a.id=ea.applicationTO.id  and a.selectedProject=?", projectId);
			if (!envIds.isEmpty()) {
				if (userTo.getClientId() == 0L) {
					list = (List<ServiceRequestTO>) getHibernateTemplate().findByNamedParam("from ServiceRequestTO where actionFlag in ('C','E') and serviceId in (" + CMMConstants.Framework.Service.CREATE_ENVIRONMENT_SERVICE_ID + " )  and environmentId in (:environmentIds) order by id desc", "environmentIds", envIds);
				} else {
					list = (List<ServiceRequestTO>) getHibernateTemplate().findByNamedParam("from ServiceRequestTO where actionFlag in ('C','E') and serviceId in (" + CMMConstants.Framework.Service.CREATE_ENVIRONMENT_SERVICE_ID + " )  and environmentId in (:environmentIds) and createdById =" + userTo.getId() + " order by id desc", "environmentIds", envIds);
				}
			}
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. getBuildForBU", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. getBuildForBU", he);
		}
		return list;
	}
	
	@Override
	public List<ServiceRequestTO> getBuildListForApp(UserTO userTo, Long applicationId) throws CMMException {
	
		List<ServiceRequestTO> list = new ArrayList<ServiceRequestTO>(0);
		List<ServiceRequestTO> list1 = new ArrayList<ServiceRequestTO>(0);
		try {
			if (userTo.getClientId() == 0L) {
				list = (List<ServiceRequestTO>) getHibernateTemplate().find("from ServiceRequestTO where actionFlag in ('C','E') and serviceId in (" + CMMConstants.Framework.Service.RELEASE_DEPLOYMENT_SERVICE + " , " + CMMConstants.Framework.Service.BUILD_SERVICE_ID + " , " + CMMConstants.Framework.Service.APPLICATION_DEPLOYMENT_SERVICE + "," + CMMConstants.Framework.Service.CREATE_ENVIRONMENT_SERVICE_ID + "," + CMMConstants.Framework.Service.CODE_ANALYSIS_SERVICE_ID + "," + CMMConstants.Framework.Service.DATABASE_REFRESH_SERVICE_ID + " )  and applicationId =" + applicationId + " order by id desc");
			} else {
				list = (List<ServiceRequestTO>) getHibernateTemplate().find("from ServiceRequestTO where actionFlag in ('C','E') and serviceId in (" + CMMConstants.Framework.Service.RELEASE_DEPLOYMENT_SERVICE + " , " + CMMConstants.Framework.Service.BUILD_SERVICE_ID + " , " + CMMConstants.Framework.Service.APPLICATION_DEPLOYMENT_SERVICE + "," + CMMConstants.Framework.Service.CREATE_ENVIRONMENT_SERVICE_ID + "," + CMMConstants.Framework.Service.CODE_ANALYSIS_SERVICE_ID + "," + CMMConstants.Framework.Service.DATABASE_REFRESH_SERVICE_ID + " )  and applicationId =" + applicationId + " and createdById =" + userTo.getId() + " order by id desc");
			}
			list1 = getBuildForAppEnv(userTo, applicationId);
			if (!list1.isEmpty()) {
				list.addAll(list1);
			}
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. getBuildListForApp", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. getBuildListForApp", he);
		}
		return list;
	}
	
	public List<ServiceRequestTO> getBuildForAppEnv(UserTO userTo, Long applicationId) throws CMMException {
	
		List<ServiceRequestTO> list = new ArrayList<ServiceRequestTO>(0);
		List<Long> envIds = new ArrayList<Long>(0);
		try {
			envIds = (List<Long>) getHibernateTemplate().find("select ea.environmentTO.id from ApplicationTO a, EnvironmentApplicationTO ea where a.id=ea.applicationTO.id  and ea.applicationTO.id=?", applicationId);
			if (!envIds.isEmpty()) {
				if (userTo.getClientId() == 0L) {
					list = (List<ServiceRequestTO>) getHibernateTemplate().findByNamedParam("from ServiceRequestTO where actionFlag in ('C','E') and serviceId in (" + CMMConstants.Framework.Service.CREATE_ENVIRONMENT_SERVICE_ID + " )  and environmentId in (:environmentIds) order by id desc", "environmentIds", envIds);
				} else {
					list = (List<ServiceRequestTO>) getHibernateTemplate().findByNamedParam("from ServiceRequestTO where actionFlag in ('C','E') and serviceId in (" + CMMConstants.Framework.Service.CREATE_ENVIRONMENT_SERVICE_ID + " )  and environmentId in (:environmentIds) and createdById =" + userTo.getId() + " order by id desc", "environmentIds", envIds);
				}
			}
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. getBuildForBU", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. getBuildForBU", he);
		}
		return list;
	}
	
	@Override
	public List<ServiceRequestTO> getBuildListForRelease(UserTO userTo, Long releaseId) throws CMMException {
	
		List<ServiceRequestTO> list = new ArrayList<ServiceRequestTO>(0);
		List<ServiceRequestTO> list1 = new ArrayList<ServiceRequestTO>(0);
		try {
			if (userTo.getClientId() == 0L) {
				list = (List<ServiceRequestTO>) getHibernateTemplate().find("from ServiceRequestTO where actionFlag in ('C','E') and serviceId in (" + CMMConstants.Framework.Service.RELEASE_DEPLOYMENT_SERVICE + " , " + CMMConstants.Framework.Service.BUILD_SERVICE_ID + " , " + CMMConstants.Framework.Service.APPLICATION_DEPLOYMENT_SERVICE + "," + CMMConstants.Framework.Service.CREATE_ENVIRONMENT_SERVICE_ID + "," + CMMConstants.Framework.Service.CODE_ANALYSIS_SERVICE_ID + "," + CMMConstants.Framework.Service.DATABASE_REFRESH_SERVICE_ID + " )  and applicationReleaseId =" + releaseId + " order by id desc");
			} else {
				list = (List<ServiceRequestTO>) getHibernateTemplate().find("from ServiceRequestTO where actionFlag in ('C','E') and serviceId in (" + CMMConstants.Framework.Service.RELEASE_DEPLOYMENT_SERVICE + " , " + CMMConstants.Framework.Service.BUILD_SERVICE_ID + " , " + CMMConstants.Framework.Service.APPLICATION_DEPLOYMENT_SERVICE + "," + CMMConstants.Framework.Service.CREATE_ENVIRONMENT_SERVICE_ID + "," + CMMConstants.Framework.Service.CODE_ANALYSIS_SERVICE_ID + "," + CMMConstants.Framework.Service.DATABASE_REFRESH_SERVICE_ID + " )  and applicationReleaseId =" + releaseId + " and createdById =" + userTo.getId() + " order by id desc");
			}
			list1 = getBuildForReleaseEnv(userTo, releaseId);
			if (!list1.isEmpty()) {
				list.addAll(list1);
			}
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. getBuildListForApp", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. getBuildListForApp", he);
		}
		return list;
	}
	
	public List<ServiceRequestTO> getBuildForReleaseEnv(UserTO userTo, Long releaseId) throws CMMException {
	
		List<ServiceRequestTO> list = new ArrayList<ServiceRequestTO>(0);
		List<Long> envIds = new ArrayList<Long>(0);
		try {
			envIds = (List<Long>) getHibernateTemplate().find("select ea.environmentTO.id from ApplicationTO a, EnvironmentApplicationTO ea where a.id=ea.applicationTO.id  and ea.applicationReleaseTO.id=?", releaseId);
			if (!envIds.isEmpty()) {
				if (userTo.getClientId() == 0L) {
					list = (List<ServiceRequestTO>) getHibernateTemplate().findByNamedParam("from ServiceRequestTO where actionFlag in ('C','E') and serviceId in (" + CMMConstants.Framework.Service.CREATE_ENVIRONMENT_SERVICE_ID + " )  and environmentId in (:environmentIds) order by id desc", "environmentIds", envIds);
				} else {
					list = (List<ServiceRequestTO>) getHibernateTemplate().findByNamedParam("from ServiceRequestTO where actionFlag in ('C','E') and serviceId in (" + CMMConstants.Framework.Service.CREATE_ENVIRONMENT_SERVICE_ID + " )  and environmentId in (:environmentIds) and createdById =" + userTo.getId() + " order by id desc", "environmentIds", envIds);
				}
			}
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. getBuildForBU", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. getBuildForBU", he);
		}
		return list;
	}
	
	@Override
	public List<ServiceTO> getServicesForDashBoard() throws CMMException {
	
		List<ServiceTO> list = new ArrayList<ServiceTO>(0);
		try {
			list = (List<ServiceTO>) getHibernateTemplate().find("from ServiceTO where id in (" + CMMConstants.Framework.Service.BUILD_SERVICE_ID + "," + CMMConstants.Framework.Service.APPLICATION_DEPLOYMENT_SERVICE + "," + CMMConstants.Framework.Service.RELEASE_DEPLOYMENT_SERVICE + "," + CMMConstants.Framework.Service.CODE_ANALYSIS_SERVICE_ID + "," + CMMConstants.Framework.Service.DATABASE_REFRESH_SERVICE_ID + "," + CMMConstants.Framework.Service.CREATE_ENVIRONMENT_SERVICE_ID + ")");
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. getServicesForDashBoard", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. getServicesForDashBoard", he);
		}
		return list;
	}
	
	@Override
	public List<ApplicationReleaseTO> getReleaseForApplication(Long applicationId) throws CMMException {
	
		List<ApplicationReleaseTO> release = new ArrayList<ApplicationReleaseTO>(0);
		try {
			release = (List<ApplicationReleaseTO>) getHibernateTemplate().find("from ApplicationReleaseTO where applicationId =? and status=?", applicationId, CMMConstants.Framework.Entity.APPLICATION_RELEASE_ACTIVE);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. getReleaseForApplication", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. getReleaseForApplication", he);
		}
		return release;
	}
	
	@Override
	public List<BusinessUnitTO> getAllBU(UserTO userTo) throws CMMException {
	
		List<BusinessUnitTO> clients = new ArrayList<BusinessUnitTO>(0);
		try {
			if (userTo.getClientId() == 0) {
				clients = (List<BusinessUnitTO>) getHibernateTemplate().find("from BusinessUnitTO where status=" + CMMConstants.Framework.Entity.BUSINESS_ACTIVE);
			} else {
				clients = (List<BusinessUnitTO>) getHibernateTemplate().findByNamedParam("from BusinessUnitTO where status=" + CMMConstants.Framework.Entity.BUSINESS_ACTIVE + " and clientId in ( :clientList)", "clientList", userTo.getClientList());
			}
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. getAllBU", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. getAllBU", he);
		} catch (Exception he) {
			throw new CMMException("Problem encountered. getAllBU", he);
		}
		return clients;
	}
	
	@Override
	public List<ProjectsTO> getProject(UserTO userTO, Long clientId) throws CMMException {
	
		List<ProjectsTO> projects = new ArrayList<ProjectsTO>(0);
		try {
			projects = (List<ProjectsTO>) getHibernateTemplate().find("from ProjectsTO where clientId=?", clientId);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. getProject", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. getProject", he);
		}
		return projects;
	}
	
	@Override
	public List<ApplicationTO> getApplications(Long projectId) throws CMMException {
	
		List<ApplicationTO> applications = new ArrayList<ApplicationTO>(0);
		try {
			applications = (List<ApplicationTO>) getHibernateTemplate().find("from ApplicationTO where selectedProject=?", projectId);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. getProject", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. getProject", he);
		}
		return applications;
	}
	
	@Override
	public List<ServiceRequestTO> getAllRequestForService(ServiceRequestTO req) throws CMMException {
	
		List<ServiceRequestTO> requests = new ArrayList<ServiceRequestTO>(0);
		String formatedDate;
		Calendar cal = Calendar.getInstance();
		cal.set(req.getYear(), req.getMonthForDay(), req.getDay());
		formatedDate = cal.get(Calendar.YEAR) + "-" + (cal.get(Calendar.MONTH) + 1) + "-" + cal.get(Calendar.DATE);
		req.setFormatDate(formatedDate);
		try {
			if (req.getService() != 1L) {
				if (req.getClientId() == 0L) {
					if ((req.getSelectedBu() != -1) && (req.getSelectedProject() == -1)) {
						requests = (List<ServiceRequestTO>) getHibernateTemplate().find("select s from ServiceRequestTO s, ApplicationTO a, BusinessUnitTO b, ProjectsTO p where s.applicationTO.id=a.id and a.businessUnitTO.clientId=b.clientId and a.projectTO.id=p.id and a.clientId=" + req.getSelectedBu() + " and s.actionFlag ='" + req.getActionFlagForGraph() + "' and s.serviceId =" + req.getService() + " and s.createdByDate='" + formatedDate + "'");
					}
					if ((req.getSelectedProject() != -1) && (req.getSelectedApplication() == -1)) {
						requests = (List<ServiceRequestTO>) getHibernateTemplate().find("select s from ServiceRequestTO s, ApplicationTO a, BusinessUnitTO b, ProjectsTO p where s.applicationTO.id=a.id and a.businessUnitTO.clientId=b.clientId and a.projectTO.id=p.id and a.selectedProject=" + req.getSelectedProject() + " and s.actionFlag ='" + req.getActionFlagForGraph() + "' and s.serviceId =" + req.getService() + " and s.createdByDate='" + formatedDate + "'");
					}
					if ((req.getSelectedApplication() != -1) && (req.getSelectedApplicationRelease() == -1)) {
						requests = (List<ServiceRequestTO>) getHibernateTemplate().find("select s from ServiceRequestTO s, ApplicationTO a, BusinessUnitTO b, ProjectsTO p where s.applicationTO.id=a.id and a.businessUnitTO.clientId=b.clientId and a.projectTO.id=p.id and s.actionFlag ='" + req.getActionFlagForGraph() + "' and s.serviceId =" + req.getService() + " and s.createdByDate='" + formatedDate + "' and s.applicationId=" + req.getSelectedApplication());
					}
					if (req.getSelectedApplicationRelease() != -1) {
						requests = (List<ServiceRequestTO>) getHibernateTemplate().find("select s from ServiceRequestTO s, ApplicationTO a, BusinessUnitTO b, ProjectsTO p where s.applicationTO.id=a.id and a.businessUnitTO.clientId=b.clientId and a.projectTO.id=p.id and s.actionFlag ='" + req.getActionFlagForGraph() + "' and s.serviceId =" + req.getService() + " and s.createdByDate='" + formatedDate + "' and s.applicationReleaseId=" + req.getSelectedApplicationRelease());
					}
					if ((req.getSelectedBu() == -1) && (req.getSelectedProject() == -1) && (req.getSelectedApplication() == -1) && (req.getSelectedApplicationRelease() == -1)) {
						requests = (List<ServiceRequestTO>) getHibernateTemplate().find("select s from ServiceRequestTO s, ApplicationTO a, BusinessUnitTO b, ProjectsTO p where s.applicationTO.id=a.id and a.businessUnitTO.clientId=b.clientId and a.projectTO.id=p.id and s.actionFlag ='" + req.getActionFlagForGraph() + "' and s.serviceId =" + req.getService() + " and s.createdByDate='" + formatedDate + "'");
					}
				} else {
					if ((req.getSelectedBu() != -1) && (req.getSelectedProject() == -1)) {
						requests = (List<ServiceRequestTO>) getHibernateTemplate().find("select s from ServiceRequestTO s, ApplicationTO a, BusinessUnitTO b, ProjectsTO p where s.applicationTO.id=a.id and a.businessUnitTO.clientId=b.clientId and a.projectTO.id=p.id and a.clientId=" + req.getSelectedBu() + " and s.actionFlag ='" + req.getActionFlagForGraph() + "' and s.serviceId =" + req.getService() + " and s.createdByDate='" + formatedDate + "'" + " and s.createdById=" + req.getUserId());
					}
					if ((req.getSelectedProject() != -1) && (req.getSelectedApplication() == -1)) {
						requests = (List<ServiceRequestTO>) getHibernateTemplate().find("select s from ServiceRequestTO s, ApplicationTO a, BusinessUnitTO b, ProjectsTO p where s.applicationTO.id=a.id and a.businessUnitTO.clientId=b.clientId and a.projectTO.id=p.id and a.selectedProject=" + req.getSelectedProject() + " and s.actionFlag ='" + req.getActionFlagForGraph() + "' and s.serviceId =" + req.getService() + " and s.createdByDate='" + formatedDate + "'" + " and s.createdById=" + req.getUserId());
					}
					if ((req.getSelectedApplication() != -1) && (req.getSelectedApplicationRelease() == -1)) {
						requests = (List<ServiceRequestTO>) getHibernateTemplate().find("select s from ServiceRequestTO s, ApplicationTO a, BusinessUnitTO b, ProjectsTO p where s.applicationTO.id=a.id and a.businessUnitTO.clientId=b.clientId and a.projectTO.id=p.id and s.actionFlag ='" + req.getActionFlagForGraph() + "' and s.serviceId =" + req.getService() + " and s.createdByDate='" + formatedDate + "' and s.applicationId=" + req.getSelectedApplication() + " and s.createdById=" + req.getUserId());
					}
					if (req.getSelectedApplicationRelease() != -1) {
						requests = (List<ServiceRequestTO>) getHibernateTemplate().find("select s from ServiceRequestTO s, ApplicationTO a, BusinessUnitTO b, ProjectsTO p where s.applicationTO.id=a.id and a.businessUnitTO.clientId=b.clientId and a.projectTO.id=p.id and s.actionFlag ='" + req.getActionFlagForGraph() + "' and s.serviceId =" + req.getService() + " and s.createdByDate='" + formatedDate + "' and s.applicationReleaseId=" + req.getSelectedApplicationRelease() + " and s.createdById=" + req.getUserId());
					}
					if ((req.getSelectedBu() == -1) && (req.getSelectedProject() == -1) && (req.getSelectedApplication() == -1) && (req.getSelectedApplicationRelease() == -1)) {
						requests = (List<ServiceRequestTO>) getHibernateTemplate().find("select s from ServiceRequestTO s, ApplicationTO a, BusinessUnitTO b, ProjectsTO p where s.applicationTO.id=a.id and a.businessUnitTO.clientId=b.clientId and a.projectTO.id=p.id and s.actionFlag ='" + req.getActionFlagForGraph() + "' and s.serviceId =" + req.getService() + " and s.createdByDate='" + formatedDate + "' and s.createdById=" + req.getUserId());
					}
				}
			} else {
				requests = getAllRequestEnv(req);
			}
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Problem encountered. getAllRequestForService", dae);
		}
		return requests;
	}
	
	public List<ServiceRequestTO> getAllRequestEnv(ServiceRequestTO req) throws CMMException {
	
		List<ServiceRequestTO> requests = new ArrayList<ServiceRequestTO>(0);
		try {
			if (req.getClientId() == 0L) {
				if ((req.getSelectedBu() != -1) && (req.getSelectedProject() == -1)) {
					requests = (List<ServiceRequestTO>) getHibernateTemplate().find("select s from ServiceRequestTO s, ApplicationTO a, BusinessUnitTO b, ProjectsTO p, EnvironmentTO e, EnvironmentApplicationTO ea where  a.businessUnitTO.clientId=b.clientId and a.projectTO.id=p.id and e.id=ea.environmentTO.id and a.id=ea.applicationTO.id and e.id=s.environmentTO.id and a.clientId=" + req.getSelectedBu() + " and s.actionFlag ='" + req.getActionFlagForGraph() + "' and s.serviceId =" + req.getService() + " and s.createdByDate='" + req.getFormatDate() + "'");
				}
				if ((req.getSelectedProject() != -1) && (req.getSelectedApplication() == -1)) {
					requests = (List<ServiceRequestTO>) getHibernateTemplate().find("select s from ServiceRequestTO s, ApplicationTO a, BusinessUnitTO b, ProjectsTO p, EnvironmentTO e, EnvironmentApplicationTO ea where  a.businessUnitTO.clientId=b.clientId and a.projectTO.id=p.id and e.id=ea.environmentTO.id and a.id=ea.applicationTO.id and e.id=s.environmentTO.id and a.selectedProject=" + req.getSelectedProject() + " and s.actionFlag ='" + req.getActionFlagForGraph() + "' and s.serviceId =" + req.getService() + " and s.createdByDate='" + req.getFormatDate() + "'");
				}
				if ((req.getSelectedApplication() != -1) && (req.getSelectedApplicationRelease() == -1)) {
					requests = (List<ServiceRequestTO>) getHibernateTemplate().find("select s from ServiceRequestTO s, ApplicationTO a, BusinessUnitTO b, ProjectsTO p, EnvironmentTO e, EnvironmentApplicationTO ea where a.businessUnitTO.clientId=b.clientId and a.projectTO.id=p.id and e.id=ea.environmentTO.id and a.id=ea.applicationTO.id and e.id=s.environmentTO.id and s.actionFlag ='" + req.getActionFlagForGraph() + "' and s.serviceId =" + req.getService() + " and s.createdByDate='" + req.getFormatDate() + "' and  ea.applicationTO.id=" + req.getSelectedApplication());
				}
				if (req.getSelectedApplicationRelease() != -1) {
					requests = (List<ServiceRequestTO>) getHibernateTemplate().find("select s from ServiceRequestTO s, ApplicationTO a, BusinessUnitTO b, ProjectsTO p, EnvironmentTO e, EnvironmentApplicationTO ea where  a.businessUnitTO.clientId=b.clientId and a.projectTO.id=p.id and e.id=ea.environmentTO.id and a.id=ea.applicationTO.id and e.id=s.environmentTO.id and s.actionFlag ='" + req.getActionFlagForGraph() + "' and s.serviceId =" + req.getService() + " and s.createdByDate='" + req.getFormatDate() + "' and  ea.applicationReleaseTO.id=" + req.getSelectedApplicationRelease());
				}
				if ((req.getSelectedBu() == -1) && (req.getSelectedProject() == -1) && (req.getSelectedApplication() == -1) && (req.getSelectedApplicationRelease() == -1)) {
					requests = (List<ServiceRequestTO>) getHibernateTemplate().find("select s from ServiceRequestTO s, ApplicationTO a, BusinessUnitTO b, ProjectsTO p, EnvironmentTO e, EnvironmentApplicationTO ea where a.businessUnitTO.clientId=b.clientId and a.projectTO.id=p.id and e.id=ea.environmentTO.id and a.id=ea.applicationTO.id and e.id=s.environmentTO.id and s.actionFlag ='" + req.getActionFlagForGraph() + "' and s.serviceId =" + req.getService() + " and s.createdByDate='" + req.getFormatDate() + "'");
				}
			} else {
				if ((req.getSelectedBu() != -1) && (req.getSelectedProject() == -1)) {
					requests = (List<ServiceRequestTO>) getHibernateTemplate().find("select s from ServiceRequestTO s, ApplicationTO a, BusinessUnitTO b, ProjectsTO p, EnvironmentTO e, EnvironmentApplicationTO ea where  a.businessUnitTO.clientId=b.clientId and a.projectTO.id=p.id and e.id=ea.environmentTO.id and a.id=ea.applicationTO.id and e.id=s.environmentTO.id and a.clientId=" + req.getSelectedBu() + " and s.actionFlag ='" + req.getActionFlagForGraph() + "' and s.serviceId =" + req.getService() + " and s.createdByDate='" + req.getFormatDate() + "'" + " and s.createdById=" + req.getUserId());
				}
				if ((req.getSelectedProject() != -1) && (req.getSelectedApplication() == -1)) {
					requests = (List<ServiceRequestTO>) getHibernateTemplate().find("select s from ServiceRequestTO s, ApplicationTO a, BusinessUnitTO b, ProjectsTO p, EnvironmentTO e, EnvironmentApplicationTO ea where  a.businessUnitTO.clientId=b.clientId and a.projectTO.id=p.id and e.id=ea.environmentTO.id and a.id=ea.applicationTO.id and e.id=s.environmentTO.id and a.selectedProject=" + req.getSelectedProject() + " and s.actionFlag ='" + req.getActionFlagForGraph() + "' and s.serviceId =" + req.getService() + " and s.createdByDate='" + req.getFormatDate() + "'" + " and s.createdById=" + req.getUserId());
				}
				if ((req.getSelectedApplication() != -1) && (req.getSelectedApplicationRelease() == -1)) {
					requests = (List<ServiceRequestTO>) getHibernateTemplate().find("select s from ServiceRequestTO s, ApplicationTO a, BusinessUnitTO b, ProjectsTO p, EnvironmentTO e, EnvironmentApplicationTO ea where  a.businessUnitTO.clientId=b.clientId and a.projectTO.id=p.id and e.id=ea.environmentTO.id and a.id=ea.applicationTO.id and e.id=s.environmentTO.id and s.actionFlag ='" + req.getActionFlagForGraph() + "' and s.serviceId =" + req.getService() + " and s.createdByDate='" + req.getFormatDate() + "' and  ea.applicationTO.id=" + req.getSelectedApplication() + " and s.createdById=" + req.getUserId());
				}
				if (req.getSelectedApplicationRelease() != -1) {
					requests = (List<ServiceRequestTO>) getHibernateTemplate().find("select s from ServiceRequestTO s, ApplicationTO a, BusinessUnitTO b, ProjectsTO p, EnvironmentTO e, EnvironmentApplicationTO ea where  a.businessUnitTO.clientId=b.clientId and a.projectTO.id=p.id and e.id=ea.environmentTO.id and a.id=ea.applicationTO.id and e.id=s.environmentTO.id and s.actionFlag ='" + req.getActionFlagForGraph() + "' and s.serviceId =" + req.getService() + " and s.createdByDate='" + req.getFormatDate() + "' and  ea.applicationReleaseTO.id=" + req.getSelectedApplicationRelease() + " and s.createdById=" + req.getUserId());
				}
				if ((req.getSelectedBu() == -1) && (req.getSelectedProject() == -1) && (req.getSelectedApplication() == -1) && (req.getSelectedApplicationRelease() == -1)) {
					requests = (List<ServiceRequestTO>) getHibernateTemplate().find("select s from ServiceRequestTO s, ApplicationTO a, BusinessUnitTO b, ProjectsTO p, EnvironmentTO e, EnvironmentApplicationTO ea where a.businessUnitTO.clientId=b.clientId and a.projectTO.id=p.id and e.id=ea.environmentTO.id and a.id=ea.applicationTO.id and e.id=s.environmentTO.id and s.actionFlag ='" + req.getActionFlagForGraph() + "' and s.serviceId =" + req.getService() + " and s.createdByDate='" + req.getFormatDate() + "' and s.createdById=" + req.getUserId());
				}
			}
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. getAllRequestEnv", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. getAllRequestEnv", he);
		}
		return requests;
	}
	
	@Override
	public List<ServiceRequestTO> getAllRequestForServiceMonth(ServiceRequestTO req) throws CMMException {
	
		List<ServiceRequestTO> requests = new ArrayList<ServiceRequestTO>(0);
		String formatedFromDate = null;
		String formatedToDate = null;
		formatedFromDate = req.getYear() + "-" + (req.getMonthForDay() + 1) + "-" + 1;
		formatedToDate = req.getYear() + "-" + (req.getMonthForDay() + 2) + "-" + 1;
		req.setFormatDate(formatedFromDate);
		req.setFormatDate1(formatedToDate);
		try {
			if (req.getService() != 1L) {
				if (req.getClientId() == 0L) {
					if ((req.getSelectedBu() != -1) && (req.getSelectedProject() == -1)) {
						requests = (List<ServiceRequestTO>) getHibernateTemplate().find("select s from ServiceRequestTO s, ApplicationTO a, BusinessUnitTO b, ProjectsTO p where s.applicationTO.id=a.id and a.businessUnitTO.clientId=b.clientId and a.projectTO.id=p.id and a.clientId=" + req.getSelectedBu() + " and s.actionFlag ='" + req.getActionFlagForGraph() + "' and s.serviceId =" + req.getService() + " and s.createdByDate >='" + formatedFromDate + "' and s.createdByDate < '" + formatedToDate + "'");
					}
					if ((req.getSelectedProject() != -1) && (req.getSelectedApplication() == -1)) {
						requests = (List<ServiceRequestTO>) getHibernateTemplate().find("select s from ServiceRequestTO s, ApplicationTO a, BusinessUnitTO b, ProjectsTO p where s.applicationTO.id=a.id and a.businessUnitTO.clientId=b.clientId and a.projectTO.id=p.id and s.applicationTO.id=a.id and a.selectedProject=" + req.getSelectedProject() + " and s.actionFlag ='" + req.getActionFlagForGraph() + "' and s.serviceId =" + req.getService() + " and s.createdByDate >='" + formatedFromDate + "' and s.createdByDate < '" + formatedToDate + "'");
					}
					if ((req.getSelectedApplication() != -1) && (req.getSelectedApplicationRelease() == -1)) {
						requests = (List<ServiceRequestTO>) getHibernateTemplate().find("select s from ServiceRequestTO s, ApplicationTO a, BusinessUnitTO b, ProjectsTO p where s.applicationTO.id=a.id and a.businessUnitTO.clientId=b.clientId and a.projectTO.id=p.id and s.actionFlag ='" + req.getActionFlagForGraph() + "' and s.serviceId =" + req.getService() + " and s.createdByDate >='" + formatedFromDate + "' and s.createdByDate < '" + formatedToDate + "'  and s.applicationId=" + req.getSelectedApplication());
					}
					if (req.getSelectedApplicationRelease() != -1) {
						requests = (List<ServiceRequestTO>) getHibernateTemplate().find("select s from ServiceRequestTO s, ApplicationTO a, BusinessUnitTO b, ProjectsTO p where s.applicationTO.id=a.id and a.businessUnitTO.clientId=b.clientId and a.projectTO.id=p.id and s.actionFlag ='" + req.getActionFlagForGraph() + "' and s.serviceId =" + req.getService() + " and s.createdByDate >='" + formatedFromDate + "' and s.createdByDate < '" + formatedToDate + "'  and s.applicationReleaseId=" + req.getSelectedApplicationRelease());
					}
					if ((req.getSelectedBu() == -1) && (req.getSelectedProject() == -1) && (req.getSelectedApplication() == -1) && (req.getSelectedApplicationRelease() == -1)) {
						requests = (List<ServiceRequestTO>) getHibernateTemplate().find("select s from ServiceRequestTO s, ApplicationTO a, BusinessUnitTO b, ProjectsTO p where s.applicationTO.id=a.id and a.businessUnitTO.clientId=b.clientId and a.projectTO.id=p.id and s.actionFlag ='" + req.getActionFlagForGraph() + "' and s.serviceId =" + req.getService() + " and s.createdByDate >='" + formatedFromDate + "' and s.createdByDate < '" + formatedToDate + "'");
					}
				} else {
					if ((req.getSelectedBu() != -1) && (req.getSelectedProject() == -1)) {
						requests = (List<ServiceRequestTO>) getHibernateTemplate().find("select s from ServiceRequestTO s, ApplicationTO a, BusinessUnitTO b, ProjectsTO p where s.applicationTO.id=a.id and a.businessUnitTO.clientId=b.clientId and a.projectTO.id=p.id and a.clientId=" + req.getSelectedBu() + " and s.actionFlag ='" + req.getActionFlagForGraph() + "' and s.serviceId =" + req.getService() + " and s.createdByDate >='" + formatedFromDate + "' and s.createdByDate < '" + formatedToDate + "'" + " and s.createdById=" + req.getUserId());
					}
					if ((req.getSelectedProject() != -1) && (req.getSelectedApplication() == -1)) {
						requests = (List<ServiceRequestTO>) getHibernateTemplate().find("select s from ServiceRequestTO s, ApplicationTO a, BusinessUnitTO b, ProjectsTO p where s.applicationTO.id=a.id and a.businessUnitTO.clientId=b.clientId and a.projectTO.id=p.id and a.selectedProject=" + req.getSelectedProject() + " and s.actionFlag ='" + req.getActionFlagForGraph() + "' and s.serviceId =" + req.getService() + " and s.createdByDate >='" + formatedFromDate + "' and s.createdByDate < '" + formatedToDate + "'" + " and s.createdById=" + req.getUserId());
					}
					if ((req.getSelectedApplication() != -1) && (req.getSelectedApplicationRelease() == -1)) {
						requests = (List<ServiceRequestTO>) getHibernateTemplate().find("select s from ServiceRequestTO s, ApplicationTO a, BusinessUnitTO b, ProjectsTO p where s.applicationTO.id=a.id and a.businessUnitTO.clientId=b.clientId and a.projectTO.id=p.id and s.actionFlag ='" + req.getActionFlagForGraph() + "' and s.serviceId =" + req.getService() + " and s.createdByDate >='" + formatedFromDate + "' and s.createdByDate < '" + formatedToDate + "'  and s.applicationId=" + req.getSelectedApplication() + " and s.createdById=" + req.getUserId());
					}
					if (req.getSelectedApplicationRelease() != -1) {
						requests = (List<ServiceRequestTO>) getHibernateTemplate().find("select s from ServiceRequestTO s, ApplicationTO a, BusinessUnitTO b, ProjectsTO p where s.applicationTO.id=a.id and a.businessUnitTO.clientId=b.clientId and a.projectTO.id=p.id and s.actionFlag ='" + req.getActionFlagForGraph() + "' and s.serviceId =" + req.getService() + " and s.createdByDate >='" + formatedFromDate + "' and s.createdByDate < '" + formatedToDate + "'  and s.applicationReleaseId=" + req.getSelectedApplicationRelease() + " and s.createdById=" + req.getUserId());
					}
					if ((req.getSelectedBu() == -1) && (req.getSelectedProject() == -1) && (req.getSelectedApplication() == -1) && (req.getSelectedApplicationRelease() == -1)) {
						requests = (List<ServiceRequestTO>) getHibernateTemplate().find("select s from ServiceRequestTO s, ApplicationTO a, BusinessUnitTO b, ProjectsTO p where s.applicationTO.id=a.id and a.businessUnitTO.clientId=b.clientId and a.projectTO.id=p.id and s.actionFlag ='" + req.getActionFlagForGraph() + "' and s.serviceId =" + req.getService() + " and s.createdByDate >='" + formatedFromDate + "' and s.createdByDate < '" + formatedToDate + "'" + " and s.createdById=" + req.getUserId());
					}
				}
			} else {
				requests = getAllRequestEnvMonth(req);
			}
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. getAllRequestForService", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. getAllRequestForService", he);
		}
		return requests;
	}
	
	public List<ServiceRequestTO> getAllRequestEnvMonth(ServiceRequestTO req) throws CMMException {
	
		List<ServiceRequestTO> requests = new ArrayList<ServiceRequestTO>(0);
		try {
			if (req.getClientId() == 0L) {
				if ((req.getSelectedBu() != -1) && (req.getSelectedProject() == -1)) {
					requests = (List<ServiceRequestTO>) getHibernateTemplate().find("select s from ServiceRequestTO s, ApplicationTO a, BusinessUnitTO b, ProjectsTO p, EnvironmentTO e, EnvironmentApplicationTO ea where a.businessUnitTO.clientId=b.clientId and a.projectTO.id=p.id and e.id=ea.environmentTO.id and a.id=ea.applicationTO.id and e.id=s.environmentTO.id and a.clientId=" + req.getSelectedBu() + " and s.actionFlag ='" + req.getActionFlagForGraph() + "' and s.serviceId =" + req.getService() + " and s.createdByDate >='" + req.getFormatDate() + "' and s.createdByDate < '" + req.getFormatDate1() + "'");
				}
				if ((req.getSelectedProject() != -1) && (req.getSelectedApplication() == -1)) {
					requests = (List<ServiceRequestTO>) getHibernateTemplate().find("select s from ServiceRequestTO s, ApplicationTO a, BusinessUnitTO b, ProjectsTO p, EnvironmentTO e, EnvironmentApplicationTO ea where a.businessUnitTO.clientId=b.clientId and a.projectTO.id=p.id and e.id=ea.environmentTO.id and a.id=ea.applicationTO.id and e.id=s.environmentTO.id and a.selectedProject=" + req.getSelectedProject() + " and s.actionFlag ='" + req.getActionFlagForGraph() + "' and s.serviceId =" + req.getService() + " and s.createdByDate >='" + req.getFormatDate() + "' and s.createdByDate < '" + req.getFormatDate1() + "'");
				}
				if ((req.getSelectedApplication() != -1) && (req.getSelectedApplicationRelease() == -1)) {
					requests = (List<ServiceRequestTO>) getHibernateTemplate().find("select s from ServiceRequestTO s, ApplicationTO a, BusinessUnitTO b, ProjectsTO p, EnvironmentTO e, EnvironmentApplicationTO ea where  a.businessUnitTO.clientId=b.clientId and a.projectTO.id=p.id and e.id=ea.environmentTO.id and a.id=ea.applicationTO.id and e.id=s.environmentTO.id and s.actionFlag ='" + req.getActionFlagForGraph() + "' and s.serviceId =" + req.getService() + " and s.createdByDate >='" + req.getFormatDate() + "' and s.createdByDate < '" + req.getFormatDate1() + "'  and ea.applicationTO.id=" + req.getSelectedApplication());
				}
				if (req.getSelectedApplicationRelease() != -1) {
					requests = (List<ServiceRequestTO>) getHibernateTemplate().find("select s from ServiceRequestTO s, ApplicationTO a, BusinessUnitTO b, ProjectsTO p, EnvironmentTO e, EnvironmentApplicationTO ea where  a.businessUnitTO.clientId=b.clientId and a.projectTO.id=p.id and e.id=ea.environmentTO.id and a.id=ea.applicationTO.id and e.id=s.environmentTO.id and s.actionFlag ='" + req.getActionFlagForGraph() + "' and s.serviceId =" + req.getService() + " and s.createdByDate >='" + req.getFormatDate() + "' and s.createdByDate < '" + req.getFormatDate1() + "'  and ea.applicationReleaseTO.id=" + req.getSelectedApplicationRelease());
				}
				if ((req.getSelectedBu() == -1) && (req.getSelectedProject() == -1) && (req.getSelectedApplication() == -1) && (req.getSelectedApplicationRelease() == -1)) {
					requests = (List<ServiceRequestTO>) getHibernateTemplate().find("select s from ServiceRequestTO s, ApplicationTO a, BusinessUnitTO b, ProjectsTO p, EnvironmentTO e, EnvironmentApplicationTO ea where   a.businessUnitTO.clientId=b.clientId and a.projectTO.id=p.id and e.id=ea.environmentTO.id and a.id=ea.applicationTO.id and e.id=s.environmentTO.id and s.actionFlag ='" + req.getActionFlagForGraph() + "' and s.serviceId =" + req.getService() + " and s.createdByDate >='" + req.getFormatDate() + "' and s.createdByDate < '" + req.getFormatDate1() + "'");
				}
			} else {
				if ((req.getSelectedBu() != -1) && (req.getSelectedProject() == -1)) {
					requests = (List<ServiceRequestTO>) getHibernateTemplate().find("select s from ServiceRequestTO s, ApplicationTO a, BusinessUnitTO b, ProjectsTO p, EnvironmentTO e, EnvironmentApplicationTO ea where  a.businessUnitTO.clientId=b.clientId and a.projectTO.id=p.id and e.id=ea.environmentTO.id and a.id=ea.applicationTO.id and e.id=s.environmentTO.id and a.clientId=" + req.getSelectedBu() + " and s.actionFlag ='" + req.getActionFlagForGraph() + "' and s.serviceId =" + req.getService() + " and s.createdByDate >='" + req.getFormatDate() + "' and s.createdByDate < '" + req.getFormatDate1() + "'" + " and s.createdById=" + req.getUserId());
				}
				if ((req.getSelectedProject() != -1) && (req.getSelectedApplication() == -1)) {
					requests = (List<ServiceRequestTO>) getHibernateTemplate().find("select s from ServiceRequestTO s, ApplicationTO a, BusinessUnitTO b, ProjectsTO p, EnvironmentTO e, EnvironmentApplicationTO ea where  a.businessUnitTO.clientId=b.clientId and a.projectTO.id=p.id and e.id=ea.environmentTO.id and a.id=ea.applicationTO.id and e.id=s.environmentTO.id and a.selectedProject=" + req.getSelectedProject() + " and s.actionFlag ='" + req.getActionFlagForGraph() + "' and s.serviceId =" + req.getService() + " and s.createdByDate >='" + req.getFormatDate() + "' and s.createdByDate < '" + req.getFormatDate1() + "'" + " and s.createdById=" + req.getUserId());
				}
				if ((req.getSelectedApplication() != -1) && (req.getSelectedApplicationRelease() == -1)) {
					requests = (List<ServiceRequestTO>) getHibernateTemplate().find("select s from ServiceRequestTO s, ApplicationTO a, BusinessUnitTO b, ProjectsTO p, EnvironmentTO e, EnvironmentApplicationTO ea where  a.businessUnitTO.clientId=b.clientId and a.projectTO.id=p.id and e.id=ea.environmentTO.id and a.id=ea.applicationTO.id and e.id=s.environmentTO.id and s.actionFlag ='" + req.getActionFlagForGraph() + "' and s.serviceId =" + req.getService() + " and s.createdByDate >='" + req.getFormatDate() + "' and s.createdByDate < '" + req.getFormatDate1() + "'  and ea.applicationTO.id=" + req.getSelectedApplication() + " and s.createdById=" + req.getUserId());
				}
				if (req.getSelectedApplicationRelease() != -1) {
					requests = (List<ServiceRequestTO>) getHibernateTemplate().find("select s from ServiceRequestTO s, ApplicationTO a, BusinessUnitTO b, ProjectsTO p, EnvironmentTO e, EnvironmentApplicationTO ea where  a.businessUnitTO.clientId=b.clientId and a.projectTO.id=p.id and e.id=ea.environmentTO.id and a.id=ea.applicationTO.id and e.id=s.environmentTO.id and s.actionFlag ='" + req.getActionFlagForGraph() + "' and s.serviceId =" + req.getService() + " and s.createdByDate >='" + req.getFormatDate() + "' and s.createdByDate < '" + req.getFormatDate1() + "'  and ea.applicationReleaseTO.id=" + req.getSelectedApplicationRelease() + " and s.createdById=" + req.getUserId());
				}
				if ((req.getSelectedBu() == -1) && (req.getSelectedProject() == -1) && (req.getSelectedApplication() == -1) && (req.getSelectedApplicationRelease() == -1)) {
					requests = (List<ServiceRequestTO>) getHibernateTemplate().find("select s from ServiceRequestTO s, ApplicationTO a, BusinessUnitTO b, ProjectsTO p, EnvironmentTO e, EnvironmentApplicationTO ea where  a.businessUnitTO.clientId=b.clientId and a.projectTO.id=p.id and e.id=ea.environmentTO.id and a.id=ea.applicationTO.id and e.id=s.environmentTO.id and s.actionFlag ='" + req.getActionFlagForGraph() + "' and s.serviceId =" + req.getService() + " and s.createdByDate >='" + req.getFormatDate() + "' and s.createdByDate < '" + req.getFormatDate1() + "'" + " and s.createdById=" + req.getUserId());
				}
			}
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. getAllRequestEnv", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. getAllRequestEnv", he);
		}
		return requests;
	}
	
	@Override
	public Long getCurrentOwnerId(Long req) throws CMMException {
	
		Long workflowId = 0L;
		List<WorkflowCurrentTO> workFlowCurrentList = (List<WorkflowCurrentTO>) getHibernateTemplate().find("from WorkflowCurrentTO where request_id =?", req);
		if (workFlowCurrentList.size() > 0) {
			workflowId = workFlowCurrentList.get(0).getCurrentOwner();
		}
		return workflowId;
	}
	
	@Override
	public List<String> getApplicationNames(Long envId) throws CMMException {
	
		List<String> appNames = new ArrayList<String>(0);
		try {
			appNames = (List<String>) getHibernateTemplate().find("select a.appName from ApplicationTO a, EnvironmentTO e, EnvironmentApplicationTO ea where e.id=ea.environmentTO.id and a.id=ea.applicationTO.id and e.id =?", envId);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. getApplicationNames", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. getApplicationNames", he);
		}
		return appNames;
	}
	
	@Override
	public void updateRequestListStatus(ServiceRequestTO requestTO) throws CMMException {
	
		try {
			requestTO.setActionFlag(CMMConstants.Framework.ServiceRequestStatus.SERVICE_REQUEST_ACTIVE);
			requestTO.setStatusId(CMMConstants.Framework.Entity.SERVICE_REQUEST_UNDER_IMPLEMENTATION);
			getHibernateTemplate().update(requestTO);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. getApplicationNames", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. getApplicationNames", he);
		}
	}
	
	@Override
	public TargetServerVO getTargetServerDetails(Long provMachineId) throws CMMException {
	
		try {
			Session session = getSession();
			String query = CMMConstants.External.Tools.TestingTools.QUERY_TARGET_SERVER_DETAILS;
			query = query + ":machineID";
			Query q = session.createQuery(query);
			q.setParameter("machineID", provMachineId);
			List<TargetServerVO> lTargetServerVO = q.setResultTransformer(Transformers.aliasToBean(TargetServerVO.class)).list();
			if ((lTargetServerVO != null) && !lTargetServerVO.isEmpty()) {
				return lTargetServerVO.get(0);
			} else {
				return null;
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.TestingToolnDAOImpl : getTargetServerDetails", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.  TestingToolnDAOImpl : getTargetServerDetails", he);
		}
	}
	
	@Override
	public TestingToolsTO getTestConfigDetails(Long applicationId, Long testToolId) throws CMMException {
	
		TestingToolsTO testingTools = new TestingToolsTO();
		List<TestingToolsTO> testingToolsTO = (List<TestingToolsTO>) getHibernateTemplate().find("from TestingToolsTO where applicationId =?  and testingToolId =? ", applicationId, testToolId);
		if (!testingToolsTO.isEmpty()) {
			testingTools = testingToolsTO.get(0);
		} else {
			List<ApplicationTO> applicationList = (List<ApplicationTO>) getHibernateTemplate().find("from ApplicationTO where id =?", applicationId);
			if (!applicationList.isEmpty()) {
				ApplicationTO application = applicationList.get(0);
				Long projectId = application.getProjectTO().getId();
				testingToolsTO = (List<TestingToolsTO>) getHibernateTemplate().find("from TestingToolsTO where projectId=? and testingToolId = ?", projectId, testToolId);
				if (!testingToolsTO.isEmpty()) {
					testingTools = testingToolsTO.get(0);
				} else {
					List<ProjectsTO> projectList = (List<ProjectsTO>) getHibernateTemplate().find("from ProjectsTO where id =?", projectId);
					if (!projectList.isEmpty()) {
						ProjectsTO project = projectList.get(0);
						Long businessUnitId = project.getClientId();
						testingToolsTO = (List<TestingToolsTO>) getHibernateTemplate().find("from TestingToolsTO where businessUnitId=? and testingToolId = ?", businessUnitId, testToolId);
						if (!testingToolsTO.isEmpty()) {
							testingTools = testingToolsTO.get(0);
						}
					}
				}
			}
		}
		return testingTools;
	}
	
	@Override
	public List<ProvisionedMachineTO> getProvisionMachineByEnvId(List<Long> id) throws CMMException {
	
		List<ProvisionedMachineTO> machines = new ArrayList<>(0);
		try {
			machines = (List<ProvisionedMachineTO>) getHibernateTemplate().findByNamedParam("select p from ProvisionedMachineTO p where p.id in (:ids)", "ids", id);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.TestingToolnDAOImpl : getProvisionMachineByEnvId", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.  TestingToolnDAOImpl : getProvisionMachineByEnvId", he);
		}
		return machines;
	}
	
	@Override
	public ProvisionedMachineTO getProvisionedMachineById(Long provMachineId) throws CMMException {
	
		ProvisionedMachineTO lProvisionedMachineTO = null;
		List<ProvisionedMachineTO> machines = new ArrayList<>(0);
		try {
			machines = (List<ProvisionedMachineTO>) getHibernateTemplate().findByNamedParam("select p from ProvisionedMachineTO p where p.id = (:ids)", "ids", provMachineId);
			if ((machines != null) && !machines.isEmpty()) {
				lProvisionedMachineTO = machines.get(0);
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.TestingToolnDAOImpl : getProvisionMachineByEnvId", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.  TestingToolnDAOImpl : getProvisionMachineByEnvId", he);
		}
		return lProvisionedMachineTO;
	}
	
	@Override
	public JIRAConfigTO getJiraCredentialsFromBUIdProjectId(JIRAConfigTO jiraConfigTO) throws CMMException {
	
		Session session = null;
		Long buId = jiraConfigTO.getBuId();
		Long projectId = jiraConfigTO.getProjectId();
		try {
			List<JIRAConfigTO> jiraConfigTOListForNullProjId;
			if ((buId != null) && (projectId != null)) {
				List<JIRAConfigTO> jiraConfigTOList = (List<JIRAConfigTO>) getHibernateTemplate().find("from JIRAConfigTO where buId=? and projectId=?", buId, projectId);
				if (jiraConfigTOList.isEmpty()) {
					jiraConfigTOListForNullProjId = (List<JIRAConfigTO>) getHibernateTemplate().find("from JIRAConfigTO where buId=? and projectId is null", buId);
					if (jiraConfigTOListForNullProjId.isEmpty()) {
						jiraConfigTOList = new ArrayList<JIRAConfigTO>();
					} else {
						jiraConfigTO = jiraConfigTOListForNullProjId.get(0);
					}
				} else {
					jiraConfigTO = jiraConfigTOList.get(0);
				}
				return jiraConfigTO;
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl:searchJiraConfig", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl:searchJiraConfig", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return jiraConfigTO;
	}
	
	@Override
	public List<JIRAConfigTO> getJiraCredentialsFromBUId(JIRAConfigTO jiraConfigTO) throws CMMException {
	
		Session session = null;
		Long buId = jiraConfigTO.getBuId();
		try {
			if (buId != null) {
				return (List<JIRAConfigTO>) getHibernateTemplate().find("from JIRAConfigTO where buId=? ", buId);
			}
			return null;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl:searchJiraConfig", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl:searchJiraConfig", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public Long fetchEnvName(String environmentName) throws CMMException {
	
		Long envId = 0L;
		try {
			List<EnvironmentTO> envList = (List<EnvironmentTO>) getHibernateTemplate().find("from EnvironmentTO where environmentName=? ", environmentName);
			for (EnvironmentTO env : envList) {
				envId = env.getId();
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.TestingToolnDAOImpl : getProvisionMachineByEnvId", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.  TestingToolnDAOImpl : getProvisionMachineByEnvId", he);
		}
		return envId;
	}
}
