package com.ext.dao.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.hibernate.HibernateException;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.PhaseManagementDAO;
import com.framework.exception.CMMException;
import com.framework.to.ApplicationReleasePhaseTO;
import com.framework.to.ReleasePlanningPhasesTO;
import com.framework.to.ReleasePlanningTO;
import com.framework.to.TestingPhaseTO;

/**
 * PhaseManagementDAOImpl is implementing interface PhaseManagementDAO and extends HibernateDaoSupport for crud operation with database. It is used to implement
 * the functionality of Phase Management of Lifecycle module.
 */
public class PhaseManagementDAOImpl extends HibernateDaoSupport implements PhaseManagementDAO {
	
	/**
	 * Provides a map of TestingPhaseTO.
	 *
	 * @return A Map which contains the value in the form of key value pair. The Long variable contains the key while the TestingPhaseTO contains the
	 *         corresponding testing phase.
	 */
	public Map<Long, TestingPhaseTO> getTestingPhasesMap() {
	
		Map<Long, TestingPhaseTO> testingPhasesMap = new HashMap<Long, TestingPhaseTO>(0);
		List<TestingPhaseTO> testingPhaseList = (List<TestingPhaseTO>) getHibernateTemplate().find("from TestingPhaseTO");
		for (TestingPhaseTO testingPhase : testingPhaseList) {
			testingPhasesMap.put(testingPhase.getId(), testingPhase);
		}
		return testingPhasesMap;
	}
	
	/**
	 * Search the release phase list for a specific application profile which further corresponds to a specific application.
	 *
	 * @param releaseId
	 *                The release phase id for which the testing phases are to be displayed.
	 * @return The list of all the testing phases which correspond to selected release id.
	 */
	@Override
	public List<ApplicationReleasePhaseTO> getPhaseListforServiceManagement(Long releaseId) throws CMMException {
	
		ApplicationReleasePhaseTO phase = null;
		List<ApplicationReleasePhaseTO> applicationReleasePhaseList = new ArrayList<ApplicationReleasePhaseTO>(0);
		try {
			List<Object[]> objList = (List<Object[]>) getHibernateTemplate().find("select r.id,t.name,t.id,r.order from ApplicationReleasePhaseTO r ,TestingPhaseTO t WHERE r.phaseId = t.id AND r.applicationId=? AND r.stat=? ORDER BY r.order", releaseId, "Y");
			for (Object[] obj : objList) {
				phase = new ApplicationReleasePhaseTO();
				phase.setId((Long) obj[0]);
				phase.setName((String) obj[1]);
				phase.setPhaseId((Long) obj[2]);
				phase.setOrder((Long) obj[3]);
				applicationReleasePhaseList.add(phase);
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getPhaseListforServiceManagement", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getPhaseListforServiceManagement", he);
		}
		return applicationReleasePhaseList;
	}
	
	@Override
	public List<ApplicationReleasePhaseTO> getPhaseListforServiceManagement(Long selectedApplication, Long selectedReleasePlan) throws CMMException {
	
		ApplicationReleasePhaseTO phase = null;
		List<ApplicationReleasePhaseTO> applicationReleasePhaseList = new ArrayList<ApplicationReleasePhaseTO>(0);
		try {
			String hql = String.format("select r.id, t.name, t.id, r.order from ApplicationReleasePhaseTO r, TestingPhaseTO t WHERE r.phaseId = t.id AND r.applicationId=%d AND r.releasePlanningTO.id=%d AND r.stat in ('Y') ORDER BY r.order", selectedApplication, selectedReleasePlan);
			List<Object[]> objList = (List<Object[]>) getHibernateTemplate().find(hql);
			for (Object[] obj : objList) {
				phase = new ApplicationReleasePhaseTO();
				phase.setId((Long) obj[0]);
				phase.setName((String) obj[1]);
				phase.setPhaseId((Long) obj[2]);
				phase.setOrder((Long) obj[3]);
				applicationReleasePhaseList.add(phase);
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getPhaseListforServiceManagement", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getPhaseListforServiceManagement", he);
		}
		return applicationReleasePhaseList;
	}
	
	@Override
	public void saveTestingPhases(List<ApplicationReleasePhaseTO> releasePhaseList, Long applicationId, Long releasePlanId) throws CMMException {
	
		try {
			List<ApplicationReleasePhaseTO> existingReleasePhaseList = (List<ApplicationReleasePhaseTO>) getHibernateTemplate().find("from ApplicationReleasePhaseTO r where r.applicationId=? AND r.releasePlanningTO.id=?", applicationId, releasePlanId);
			int flag = 0;
			if (existingReleasePhaseList.isEmpty()) {
				for (ApplicationReleasePhaseTO tmp : releasePhaseList) {
					getHibernateTemplate().saveOrUpdate(tmp);
				}
			} else {
				for (ApplicationReleasePhaseTO newValue : releasePhaseList) {
					for (ApplicationReleasePhaseTO tempObj : existingReleasePhaseList) {
						if (newValue.getPhaseId().equals(tempObj.getPhaseId())) {
							tempObj.setApplicationId(newValue.getApplicationId());
							tempObj.setPhaseId(newValue.getPhaseId());
							tempObj.setApplicationId(newValue.getApplicationId());
							tempObj.setOrder(newValue.getOrder());
							tempObj.setStat(newValue.getStat());
							tempObj.setModifiedbyId(newValue.getModifiedbyId());
							tempObj.setModifiedDate(newValue.getModifiedDate());
							tempObj.setSelectedReleasePlan(newValue.getSelectedReleasePlan());
							getHibernateTemplate().update(tempObj);
							flag = 1;
							break;
						}
					}
					if (flag != 1) {
						getHibernateTemplate().save(newValue);
					}
					flag = 0;
				}
				flag = 0;
				for (ApplicationReleasePhaseTO tempObj : existingReleasePhaseList) {
					for (ApplicationReleasePhaseTO newValue : releasePhaseList) {
						if (newValue.getPhaseId().equals(tempObj.getPhaseId())) {
							flag = 1;
						}
					}
					if (flag != 1) {
						tempObj.setStat("N");
						getHibernateTemplate().update(tempObj);
					}
					flag = 0;
				}
			}
		} catch (DataAccessException | HibernateException e) {
			throw new CMMException("Problem encountered. PhaseManagementDAOImpl: savePhaseListforPhaseManagement", e);
		}
	}
	
	@Override
	public List<TestingPhaseTO> searchAlltestingPhases(Long applicationId, Long releasePlanId) throws CMMException {
	
		List<TestingPhaseTO> testingPhaseList = new ArrayList<TestingPhaseTO>(0);
		Map<Long, TestingPhaseTO> testingPhasesMap = getTestingPhasesMap();
		try {
			List<ApplicationReleasePhaseTO> releasePhaseList = (List<ApplicationReleasePhaseTO>) getHibernateTemplate().find("from ApplicationReleasePhaseTO r where r.applicationId=? AND r.releasePlanningTO.id=? and r.stat='Y' order by order", applicationId, releasePlanId);
			for (ApplicationReleasePhaseTO releasePhase : releasePhaseList) {
				testingPhaseList.add(testingPhasesMap.get(releasePhase.getPhaseId()));
			}
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Problem encountered. PhaseManagementDAOImpl: searchAlltestingPhases", dae);
		}
		return testingPhaseList;
	}
	
	@Override
	public List<TestingPhaseTO> getReleasePlanTestingPhases(Long releasePlanId) throws CMMException {
	
		List<TestingPhaseTO> testingPhaseList = new ArrayList<TestingPhaseTO>(0);
		Map<Long, TestingPhaseTO> testingPhasesMap = getTestingPhasesMap();
		try {
			List<ReleasePlanningPhasesTO> releasePhaseList = (List<ReleasePlanningPhasesTO>) getHibernateTemplate().find("from ReleasePlanningPhasesTO r where r.releasePlanningTO.id=?", releasePlanId);
			for (ReleasePlanningPhasesTO releasePhase : releasePhaseList) {
				testingPhaseList.add(testingPhasesMap.get(releasePhase.getApplicationPhaseId()));
			}
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Problem encountered. PhaseManagementDAOImpl: getReleasePlanTestingPhases", dae);
		}
		return testingPhaseList;
	}
	
	@Override
	public List<ReleasePlanningTO> getReleasePlanning(Long id) throws CMMException {
	
		List<ReleasePlanningTO> releasePlanningList = new ArrayList<ReleasePlanningTO>(0);
		try {
			if (id != null) {
				releasePlanningList = (List<ReleasePlanningTO>) getHibernateTemplate().find("from ReleasePlanningTO where applicationTO.id=?", id);
			}
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Problem encountered. PhaseManagementDAOImpl: getReleasePlanning", dae);
		}
		return releasePlanningList;
	}
	
	@Override
	public List<TestingPhaseTO> getAllTestingCycles(Long id) throws CMMException {
	
		List<TestingPhaseTO> phasesList = new ArrayList<TestingPhaseTO>(0);
		try {
			if (id != null) {
				phasesList = (List<TestingPhaseTO>) getHibernateTemplate().find("select testingPhaseTO from ReleasePlanningPhasesTO r where r.releasePlanningTO.id=?", id);
			}
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Problem encountered. PhaseManagementDAOImpl: getAllTestingCycles", dae);
		}
		return phasesList;
	}
}