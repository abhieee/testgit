package com.ext.dao.impl;

import java.util.ArrayList;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.hibernate.exception.ConstraintViolationException;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.ReleasePlanningDAO;
import com.framework.exception.CMMException;
import com.framework.to.ApplicationTO;
import com.framework.to.ClientTO;
import com.framework.to.ProjectsTO;
import com.framework.to.ReleasePlanningPhasesTO;
import com.framework.to.ReleasePlanningTO;

public class ReleasePlanningDAOImpl extends HibernateDaoSupport implements ReleasePlanningDAO {
	
	@Override
	public Long releasePlanningAdd(ReleasePlanningTO releasePlanningTO) throws CMMException {
	
		Long releasePlanningId;
		try {
			releasePlanningId = (Long) getHibernateTemplate().save(releasePlanningTO);
			if (releasePlanningTO.getSelectedPhaseIds() != null) {
				for (Long phaseId : releasePlanningTO.getSelectedPhaseIds()) {
					ReleasePlanningPhasesTO releasePlanningPhase = new ReleasePlanningPhasesTO();
					releasePlanningPhase.setReleasePlanningId(releasePlanningId);
					releasePlanningPhase.setApplicationPhaseId(phaseId);
					getHibernateTemplate().save(releasePlanningPhase);
				}
			} else {
				throw new CMMException("Problem encountered.ReleasePlanningDAOImpl:releasePlanningAdd");
			}
		} catch (DataIntegrityViolationException | ConstraintViolationException div) {
			logger.error(div);
			throw new CMMException("Problem encountered.ReleasePlanningDAOImpl:releasePlanningAdd", div);
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.ReleasePlanningDAOImpl:releasePlanningAdd", dae);
		}
		return releasePlanningId;
	}
	
	@SuppressWarnings({ "deprecation", "unchecked" })
	@Override
	public boolean releasePlanningEdit(ReleasePlanningTO releasePlanningTO) throws CMMException {
	
		Session session;
		session = getSession();
		Criteria criteria = session.createCriteria(ReleasePlanningPhasesTO.class, "releasePlanningPhase");
		try {
			if ((releasePlanningTO.getId() != null) && (releasePlanningTO.getId() > 0)) {
				getHibernateTemplate().update(releasePlanningTO);
				criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
				List<ReleasePlanningPhasesTO> releasePlanningPhaseList;
				criteria.add(Restrictions.eq("releasePlanningPhase.releasePlanningId", releasePlanningTO.getId()));
				releasePlanningPhaseList = criteria.list();
				getHibernateTemplate().deleteAll(releasePlanningPhaseList);
				for (Long phaseId : releasePlanningTO.getSelectedPhaseIds()) {
					ReleasePlanningPhasesTO releasePlanningPhase = new ReleasePlanningPhasesTO();
					releasePlanningPhase.setReleasePlanningId(releasePlanningTO.getId());
					releasePlanningPhase.setApplicationPhaseId(phaseId);
					getHibernateTemplate().save(releasePlanningPhase);
				}
			} else {
				throw new CMMException("Problem encountered.ReleasePlanningDAOImpl:releasePlanningEdit.");
			}
		} catch (DataIntegrityViolationException | ConstraintViolationException div) {
			logger.error(div);
			throw new CMMException("Problem encountered.ReleasePlanningDAOImpl:releasePlanningEdit", div);
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.ReleasePlanningDAOImpl:releasePlanningEdit", dae);
		}
		return true;
	}
	
	@SuppressWarnings({ "deprecation", "unchecked" })
	@Override
	public boolean checkName(ReleasePlanningTO releasePlanningTO) throws CMMException {
	
		boolean flag = false;
		Session session;
		session = getSession();
		Criteria criteria = session.createCriteria(ReleasePlanningTO.class, "plannings");
		try {
			criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			List<ReleasePlanningTO> releasePlanningList;
			if (!"".equals(releasePlanningTO.getName().trim())) {
				criteria.add(Restrictions.eq("plannings.name", releasePlanningTO.getName()));
			}
			if ((releasePlanningTO.getId() != null) && (releasePlanningTO.getId() > 0)) {
				criteria.add(Restrictions.ne("plannings.id", releasePlanningTO.getId()));
			}
			criteria.add(Restrictions.gt("plannings.id", 0L));
			releasePlanningList = criteria.list();
			if (!releasePlanningList.isEmpty()) {
				flag = true;
			} else {
				flag = false;
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.ReleasePlanningDAOImpl:checkName.", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.ReleasePlanningDAOImpl:checkName.", he);
		}
		return flag;
	}
	
	@SuppressWarnings({ "deprecation", "unchecked" })
	@Override
	public ReleasePlanningTO getReleasePlanningDetails(Long id) throws CMMException {
	
		Session session;
		session = getSession();
		ReleasePlanningTO releasePlanning;
		Criteria criteria = session.createCriteria(ReleasePlanningTO.class, "plannings");
		Criteria criteriaPhases = session.createCriteria(ReleasePlanningPhasesTO.class, "phases");
		try {
			criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			List<ReleasePlanningTO> releasePlanningList;
			criteriaPhases.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			List<ReleasePlanningPhasesTO> releasePlanningPhasesList;
			if ((id != null) && (id > 0)) {
				criteria.add(Restrictions.eq("plannings.id", id));
			} else {
				throw new CMMException("Problem encountered.ReleasePlanningDAOImpl:getReleasePlanningDetails.");
			}
			releasePlanningList = criteria.list();
			if ((releasePlanningList != null) && !releasePlanningList.isEmpty()) {
				releasePlanning = releasePlanningList.get(0);
				criteriaPhases.add(Restrictions.eq("phases.releasePlanningId", id));
				releasePlanningPhasesList = criteriaPhases.list();
				List<Long> releasePlanningPhasesIds = new ArrayList<>();
				for (ReleasePlanningPhasesTO releasePlanningPhasesTO : releasePlanningPhasesList) {
					releasePlanningPhasesIds.add(releasePlanningPhasesTO.getApplicationPhaseId());
				}
				releasePlanning.setSelectedPhaseIds(releasePlanningPhasesIds);
			} else {
				throw new CMMException("Problem encountered.ReleasePlanningDAOImpl:getReleasePlanningDetails.");
			}
			if ((releasePlanning.getSelectedBUId() != null) && (releasePlanning.getSelectedBUId() > 0)) {
				ClientTO bu = (ClientTO) getEntityDetails(releasePlanning.getSelectedBUId(), ClientTO.class);
				if (bu != null) {
					releasePlanning.setSelectedBUName(bu.getName());
				}
			}
			if ((releasePlanning.getSelectedProjectId() != null) && (releasePlanning.getSelectedProjectId() > 0)) {
				ProjectsTO project = (ProjectsTO) getEntityDetails(releasePlanning.getSelectedProjectId(), ProjectsTO.class);
				if (project != null) {
					releasePlanning.setSelectedProjectName(project.getName());
				}
			}
			if ((releasePlanning.getSelectedApplicationId() != null) && (releasePlanning.getSelectedApplicationId() > 0)) {
				ApplicationTO application = (ApplicationTO) getEntityDetails(releasePlanning.getSelectedApplicationId(), ApplicationTO.class);
				if (application != null) {
					releasePlanning.setSelectedApplicationName(application.getAppName());
				}
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.ReleasePlanningDAOImpl:getReleasePlanningDetails.", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.ReleasePlanningDAOImpl:getReleasePlanningDetails.", he);
		}
		return releasePlanning;
	}
	
	@SuppressWarnings({ "deprecation", "unchecked", "rawtypes" })
	private Object getEntityDetails(Long id, Class cls) throws CMMException {
	
		Session session;
		session = getSession();
		Criteria criteria = session.createCriteria(cls, "entity");
		try {
			criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			List<Object> entityList;
			if ((id != null) && (id > 0)) {
				criteria.add(Restrictions.eq("entity.id", id));
			} else {
				throw new CMMException("Problem encountered.ReleasePlanningDAOImpl:getEntityDetails.");
			}
			entityList = criteria.list();
			if ((entityList != null) && !entityList.isEmpty()) {
				return entityList.get(0);
			} else {
				throw new CMMException("Problem encountered.ReleasePlanningDAOImpl:getEntityDetails.");
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.ReleasePlanningDAOImpl:getEntityDetails.", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.ReleasePlanningDAOImpl:getEntityDetails.", he);
		}
	}
	
	@SuppressWarnings({ "deprecation", "unchecked" })
	@Override
	public List<ReleasePlanningTO> searchReleasePlanning(ReleasePlanningTO releasePlanningTO, List<Long> clientIdlist) throws CMMException {
	
		Session session = null;
		session = getSession();
		Criteria criteria = session.createCriteria(ReleasePlanningTO.class, "plannings");
		try {
			criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			List<ReleasePlanningTO> releasePlanningList = new ArrayList<>();
			if ((releasePlanningTO.getSelectedReleaseId() != null) && (releasePlanningTO.getSelectedReleaseId() > 0)) {
				criteria.add(Restrictions.eq("plannings.id", releasePlanningTO.getSelectedReleaseId()));
			}
			if ((releasePlanningTO.getSelectedBUId() != null) && (releasePlanningTO.getSelectedBUId() > 0)) {
				criteria.add(Restrictions.eq("plannings.clientTO.id", releasePlanningTO.getSelectedBUId()));
			}
			if ((releasePlanningTO.getSelectedProjectId() != null) && (releasePlanningTO.getSelectedProjectId() > 0)) {
				criteria.add(Restrictions.eq("plannings.projectsTO.id", releasePlanningTO.getSelectedProjectId()));
			}
			if ((releasePlanningTO.getSelectedApplicationId() != null) && (releasePlanningTO.getSelectedApplicationId() > 0)) {
				criteria.add(Restrictions.eq("plannings.applicationTO.id", releasePlanningTO.getSelectedApplicationId()));
			}
			criteria.add(Restrictions.gt("plannings.id", 0L));
			releasePlanningList = criteria.list();
			return releasePlanningList;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. searchReleasePlanning : ", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. searchReleasePlanning : ", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
}