package com.ext.dao.impl;

import java.util.Date;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.hibernate.exception.ConstraintViolationException;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.BusinessUnitDAO;
import com.framework.common.CMMConstants;
import com.framework.exception.CMMException;
import com.framework.to.BusinessUnitTO;
import com.framework.to.StatusTO;

public class BusinessUnitDAOImpl extends HibernateDaoSupport implements BusinessUnitDAO {
	
	@Override
	public List<BusinessUnitTO> searchBusinessUnit(BusinessUnitTO businessunitTO) throws CMMException {
	
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(BusinessUnitTO.class);
			if (!"".equalsIgnoreCase(businessunitTO.getName().trim())) {
				criteria.add(Restrictions.like("name", "%" + businessunitTO.getName() + "%"));
			}
			if (businessunitTO.getSelectedStatus() > 0L) {
				criteria.add(Restrictions.eq("statusTO.id", businessunitTO.getSelectedStatus()));
			}
			if (businessunitTO.getClientId() != 0L) {
				criteria.add(Restrictions.in("clientId", businessunitTO.getClientList()));
			}
			if (businessunitTO.getSearchCount() == 0) {
				return (List<BusinessUnitTO>) getHibernateTemplate().findByCriteria(criteria);
			}
			Session session = getSession();
			criteria.getExecutableCriteria(session).setFirstResult(businessunitTO.getFirstResult());
			criteria.getExecutableCriteria(session).setMaxResults(businessunitTO.getTableSize());
			return (List<BusinessUnitTO>) getHibernateTemplate().findByCriteria(criteria);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. BusinessUnitDAOImpl:searchBusinessUnit", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. BusinessUnitDAOImpl:searchBusinessUnit", he);
		}
	}
	
	@Override
	public void addBusinessUnit(BusinessUnitTO businessUnitTO) throws CMMException {
	
		try {
			businessUnitTO.setCreatedDate(new Date());
			getHibernateTemplate().save(businessUnitTO);
		} catch (DataIntegrityViolationException div) {
			logger.error(div);
			throw new CMMException("Problem encountered. BusinessUnitDAOImpl:addBusinessUnit", div);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. BusinessUnitDAOImpl:addBusinessUnit", dae);
		} catch (ConstraintViolationException e) {
			logger.error(e);
			throw new CMMException("Problem encountered. BusinessUnitDAOImpl:addBusinessUnit", e);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. BusinessUnitDAOImpl:addBusinessUnit", he);
		}
	}
	
	@Override
	public boolean checkName(BusinessUnitTO businessUnitTO) throws CMMException {
	
		try {
			List<BusinessUnitTO> unit = (List<BusinessUnitTO>) getHibernateTemplate().find("from BusinessUnitTO where name=? and clientId<>? ", businessUnitTO.getName(), businessUnitTO.getClientId());
			return !unit.isEmpty();
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. BusinessUnitDAOImpl:checkName", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. BusinessUnitDAOImpl:checkName", he);
		}
	}
	
	@Override
	public void editBusinessUnit(BusinessUnitTO businessUnitTO) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			businessUnitTO.setStatus(businessUnitTO.getSelectedStatus());
			Query query = session.createQuery("update BusinessUnitTO set name = :name, status =:status, remark =:remark, modifiedbyId=:modifiedbyId , modifiedDate=:modifiedDate  where clientId = :id");
			query.setParameter("name", businessUnitTO.getName());
			query.setParameter("status", businessUnitTO.getStatus());
			query.setParameter("remark", businessUnitTO.getRemark());
			query.setParameter("id", businessUnitTO.getClientId());
			query.setParameter("modifiedbyId", businessUnitTO.getModifiedbyId());
			query.setParameter("modifiedDate", businessUnitTO.getModifiedDate());
			query.executeUpdate();
		} catch (ConstraintViolationException ce) {
			logger.error(ce);
			throw new CMMException("Problem encountered. BusinessUnitDAOImpl:editBusinessUnit", ce);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. BusinessUnitDAOImpl:editBusinessUnit", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. BusinessUnitDAOImpl:editBusinessUnit", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public BusinessUnitTO getBusinesUnitDetails(BusinessUnitTO businessUnitTO) throws CMMException {
	
		try {
			BusinessUnitTO busTO = (BusinessUnitTO) getHibernateTemplate().find("from BusinessUnitTO where clientId=?", businessUnitTO.getClientId()).get(0);
			busTO.setSelectedStatus(busTO.getStatus());
			return busTO;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. BusinessUnitDAOImpl:getBusinesUnitDetails", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. BusinessUnitDAOImpl:getBusinesUnitDetails", he);
		}
	}
	
	@Override
	public List<StatusTO> getStatusList() throws CMMException {
	
		try {
			return (List<StatusTO>) getHibernateTemplate().find("from StatusTO where entityId=?", CMMConstants.Framework.Entity.BUSINESS);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. BusinessUnitDAOImpl:getStatusList", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. BusinessUnitDAOImpl:getStatusList", he);
		}
	}
	
	@Override
	public BusinessUnitTO getBusinessUnitDetails(BusinessUnitTO BusinessUnitTO) throws CMMException {
	
		return null;
	}
}
