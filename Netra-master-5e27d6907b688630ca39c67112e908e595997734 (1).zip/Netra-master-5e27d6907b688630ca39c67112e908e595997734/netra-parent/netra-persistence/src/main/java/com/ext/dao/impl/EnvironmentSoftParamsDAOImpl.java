/**
 *
 */
package com.ext.dao.impl;

import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.EnvironmentSoftParamsDAO;
import com.framework.exception.CMMException;
import com.framework.to.EnvironmentSoftParamsTO;

/**
 * @author 460650
 */
public class EnvironmentSoftParamsDAOImpl extends HibernateDaoSupport implements EnvironmentSoftParamsDAO {
	
	@Override
	public void saveSoftwareParamsForEnv(EnvironmentSoftParamsTO environmentSoftParamsTO) throws CMMException {
	
		try {
			getHibernateTemplate().save(environmentSoftParamsTO);
		} catch (DataIntegrityViolationException e) {
			logger.error(e);
			throw new CMMException("Problem encountered. EnvironmentSoftParamsDAOImpl:saveSoftwareParamsForEnv", e);
		} catch (HibernateException e) {
			logger.error(e);
			throw new CMMException("Problem encountered. EnvironmentSoftParamsDAOImpl:saveSoftwareParamsForEnv", e);
		}
	}
	
	@Override
	public List<EnvironmentSoftParamsTO> getSoftwareParamsForEnv(long envId, long activityId) throws CMMException {
	
		try {
			return (List<EnvironmentSoftParamsTO>) getHibernateTemplate().find("from EnvironmentSoftParamsTO where environmentDetailsTO.id=? and activityId=?", envId, activityId);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. EnvironmentSoftParamsDAOImpl:getSoftwareParamsForEnv", dae);
		} catch (HibernateException e) {
			logger.error(e);
			throw new CMMException("Problem encountered. EnvironmentSoftParamsDAOImpl:getSoftwareParamsForEnv", e);
		}
	}
	
	@Override
	public List<EnvironmentSoftParamsTO> getSoftwareParamsByEnvAppId(long environmentApplicationId) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			List<EnvironmentSoftParamsTO> environmentSoftParamsList = session.createCriteria(EnvironmentSoftParamsTO.class).add(Restrictions.eq("environmentApplicationMapId", environmentApplicationId)).list();
			if ((environmentSoftParamsList == null) || (environmentSoftParamsList.size() < 0)) {
				throw new CMMException("No environment software parameters found for environmentApplicationId:: " + environmentApplicationId);
			}
			return environmentSoftParamsList;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. EnvironmentSoftParamsDAOImpl:getSoftwareParamsByEnvAppId", dae);
		} catch (HibernateException e) {
			logger.error(e);
			throw new CMMException("Problem encountered. EnvironmentSoftParamsDAOImpl:getSoftwareParamsByEnvAppId", e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
}
