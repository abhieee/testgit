package com.ext.dao.impl;

import java.util.List;
import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Transaction;
import org.hibernate.classic.Session;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.AccessMgmtDAO;
import com.framework.common.CMMConstants;
import com.framework.exception.CMMException;
import com.framework.to.AccessTO;
import com.framework.to.RoleTO;
import com.framework.to.ScreenTO;
import com.framework.to.UserPrivilegeTOInsert;

/**
 * @author TCS
 */
public class AccessMgmtDAOImpl extends HibernateDaoSupport implements AccessMgmtDAO {
	
	private static final Logger LOGGER = Logger.getLogger(AccessMgmtDAOImpl.class);
	private static final String PBLMENCOUNTEREDGETALLROLES = "Problem encountered. AccessMgmtDAOImpl : getAllRoles";	
	@Override
	public void addAccess(AccessTO accessMgmtTO) throws CMMException {
	
		try {
			getHibernateTemplate().save(accessMgmtTO);
		} catch (DataAccessException e) {
			LOGGER.error(e);
			throw new CMMException("Problem encountered. AccessMgmtDAOImpl : addAccess", e);
		} catch (HibernateException e) {
			LOGGER.error(e);
			throw new CMMException("Problem encountered. AccessMgmtDAOImpl : addAccess", e);
		}
	}
	
	@Override
	public AccessTO getAccessDetails(AccessTO accessMgmtTO) throws CMMException {
	
		try {
			return (AccessTO) getHibernateTemplate().find("from AccessMgmtTO where id=?", accessMgmtTO.getId()).get(0);
		} catch (DataAccessException e) {
			LOGGER.error(e);
			throw new CMMException("Problem encountered. AccessMgmtDAOImpl : getAccessDetails", e);
		} catch (HibernateException e) {
			LOGGER.error(e);
			throw new CMMException("Problem encountered. AccessMgmtDAOImpl : getAccessDetails", e);
		}
	}
	
	@Override
	public void editAccess(AccessTO accessMgmtTO) throws CMMException {
	
		try {
			getHibernateTemplate().update(accessMgmtTO);
		} catch (DataAccessException e) {
			LOGGER.error(e);
			throw new CMMException("Problem encountered. AccessMgmtDAOImpl : editAccess", e);
		} catch (HibernateException e) {
			LOGGER.error(e);
			throw new CMMException("Problem encountered. AccessMgmtDAOImpl : editAccess", e);
		}
	}
	
	@Override
	public List<RoleTO> getAllRoles() throws CMMException {
	
		try {
			return (List<RoleTO>) getHibernateTemplate().find("select r from RoleTO r, RoleLevelTO rt where r.id =rt.roleId and r.id > 0 and r.status=?", CMMConstants.Framework.Entity.ROLE_STATUS_ACTIVE);
		} catch (DataAccessException e) {
			LOGGER.error(e);
			throw new CMMException(PBLMENCOUNTEREDGETALLROLES, e);
		} catch (HibernateException e) {
			LOGGER.error(e);
			throw new CMMException(PBLMENCOUNTEREDGETALLROLES, e);
		}
	}
	
	@Override
	public List<RoleTO> getAllRoleForAdd() throws CMMException {
	
		try {
			return (List<RoleTO>) getHibernateTemplate().find("select r from RoleTO r where r.id > 0 and r.status=?", CMMConstants.Framework.Entity.ROLE_STATUS_ACTIVE);
		} catch (DataAccessException e) {
			LOGGER.error(e);
			throw new CMMException(PBLMENCOUNTEREDGETALLROLES, e);
		} catch (HibernateException e) {
			LOGGER.error(e);
			throw new CMMException(PBLMENCOUNTEREDGETALLROLES, e);
		}
	}
	
	@Override
	public List<RoleTO> getAllRoleForDefineOrder() throws CMMException {
	
		try {
			return (List<RoleTO>) getHibernateTemplate().find("select r from RoleTO r, RoleLevelTO rt where r.id =rt.roleId and r.id > 0 and r.status=?", CMMConstants.Framework.Entity.ROLE_STATUS_ACTIVE);
		} catch (DataAccessException e) {
			LOGGER.error(e);
			throw new CMMException(PBLMENCOUNTEREDGETALLROLES, e);
		} catch (HibernateException e) {
			LOGGER.error(e);
			throw new CMMException(PBLMENCOUNTEREDGETALLROLES, e);
		}
	}
	
	@Override
	public List<ScreenTO> getAllScreens() throws CMMException {
	
		try {
			return (List<ScreenTO>) getHibernateTemplate().find("from ScreenTO order by id");
		} catch (DataAccessException e) {
			LOGGER.error(e);
			throw new CMMException("Problem encountered. AccessMgmtDAOImpl : getAllScreens", e);
		} catch (HibernateException e) {
			LOGGER.error(e);
			throw new CMMException("Problem encountered. AccessMgmtDAOImpl : getAllScreens", e);
		}
	}
	
	@Override
	public List<ScreenTO> getAllParentScreens() throws CMMException {
	
		try {
			return (List<ScreenTO>) getHibernateTemplate().find("select distinct screensByParentScreenId from ScreenTreeTO");
		} catch (DataAccessException e) {
			LOGGER.error(e);
			throw new CMMException("Problem encountered. AccessMgmtDAOImpl : getAllParentScreens", e);
		} catch (HibernateException e) {
			LOGGER.error(e);
			throw new CMMException("Problem encountered. AccessMgmtDAOImpl : getAllParentScreens", e);
		}
	}
	
	@Override
	public List<Object[]> getScreenTree() throws CMMException {
	
		try {
			return (List<Object[]>) getHibernateTemplate().find("select s2.name,s1.screensByChildScreenId.id,s1.screensByParentScreenId.id,s2.actionStr,s2.adminAccess from ScreenTreeTO s1 inner join s1.screensByChildScreenId s2");
		} catch (DataAccessException e) {
			LOGGER.error(e);
			throw new CMMException("Problem encountered. AccessMgmtDAOImpl : getScreenTree", e);
		} catch (HibernateException e) {
			LOGGER.error(e);
			throw new CMMException("Problem encountered. AccessMgmtDAOImpl : getScreenTree", e);
		}
	}
	
	@Override
	public List<AccessTO> getScreenAccess(AccessTO accessMgmtTO) throws CMMException {
	
		try {
			return (List<AccessTO>) getHibernateTemplate().find("from AccessTO where roleId=?  order by id", accessMgmtTO.getRoleId());
		} catch (DataAccessException e) {
			LOGGER.error(e);
			throw new CMMException("Problem encountered. AccessMgmtDAOImpl : getScreenAccess", e);
		} catch (HibernateException e) {
			LOGGER.error(e);
			throw new CMMException("Problem encountered. AccessMgmtDAOImpl : getScreenAccess", e);
		}
	}
	
	@Override
	public RoleTO getRole(RoleTO roleTO) throws CMMException {
	
		try {
			return (RoleTO) getHibernateTemplate().find("from RoleTO where name=?", roleTO.getName()).get(0);
		} catch (DataAccessException e) {
			LOGGER.error(e);
			throw new CMMException("Problem encountered. AccessMgmtDAOImpl : getRole", e);
		} catch (HibernateException e) {
			LOGGER.error(e);
			throw new CMMException("Problem encountered. AccessMgmtDAOImpl : getRole", e);
		}
	}
	
	@Override
	public List<RoleTO> getAllRoles(Long clientId) throws CMMException {
	
		try {
			return (List<RoleTO>) getHibernateTemplate().find("from RoleTO where clientId=?", clientId);
		} catch (DataAccessException e) {
			LOGGER.error(e);
			throw new CMMException(PBLMENCOUNTEREDGETALLROLES, e);
		} catch (HibernateException e) {
			LOGGER.error(e);
			throw new CMMException(PBLMENCOUNTEREDGETALLROLES, e);
		}
	}
	
	@Override
	public void deleteAccess(AccessTO accessMgmtTO) throws CMMException {
	
		Transaction tx = null;
		Session session = null;
		try {
			session = (Session) getSession();
			tx = session.beginTransaction();
			session.createQuery("delete from AccessTO where roleId= :roleId").setLong("roleId", accessMgmtTO.getRoleId()).executeUpdate();
			tx.commit();
		} catch (DataAccessException e) {
			LOGGER.error(e);
			throw new CMMException("Problem encountered. AccessMgmtDAOImpl : deleteAccess", e);
		} catch (HibernateException e) {
			LOGGER.error(e);
			throw new CMMException("Problem encountered. AccessMgmtDAOImpl : deleteAccess", e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<RoleTO> getAllRolesForAccessMgmt(Long userId, Long clientId) throws CMMException {
	
		try {
			UserPrivilegeTOInsert userpriv = (UserPrivilegeTOInsert) getHibernateTemplate().find("from UserPrivilegeTOInsert where id=?", userId).get(0);
			Long roleId = userpriv.getRoleId();
			if ((clientId == 0) && (roleId == 1)) {
				return (List<RoleTO>) getHibernateTemplate().find("from RoleTO where id != 0 and status<>?", CMMConstants.Framework.Entity.ROLE_STATUS_INACTIVE);
			} else {
				return (List<RoleTO>) getHibernateTemplate().find("from RoleTO where id != 0 and id>? and status<>?", roleId, CMMConstants.Framework.Entity.ROLE_STATUS_INACTIVE);
			}
		} catch (DataAccessException e) {
			LOGGER.error(e);
			throw new CMMException(PBLMENCOUNTEREDGETALLROLES, e);
		} catch (HibernateException e) {
			LOGGER.error(e);
			throw new CMMException(PBLMENCOUNTEREDGETALLROLES, e);
		}
	}
}
