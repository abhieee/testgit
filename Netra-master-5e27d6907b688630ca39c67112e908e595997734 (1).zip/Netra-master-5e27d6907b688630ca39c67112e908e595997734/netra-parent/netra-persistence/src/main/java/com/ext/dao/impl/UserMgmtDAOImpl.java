package com.ext.dao.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Random;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.SearchControls;
import org.apache.log4j.Logger;
import org.hibernate.FetchMode;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.exception.ConstraintViolationException;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.ldap.core.AttributesMapper;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.util.StringUtils;
import com.ext.dao.UserMgmtDAO;
import com.framework.common.CMMConstants;
import com.framework.exception.CMMException;
import com.framework.to.BusinessUnitTO;
import com.framework.to.ClientTO;
import com.framework.to.DelegatedUserTO;
import com.framework.to.ForgotPassTO;
import com.framework.to.RoleLevelTO;
import com.framework.to.SecurityAnswersTO;
import com.framework.to.SecurityQusetionsTO;
import com.framework.to.StatusTO;
import com.framework.to.UserBusinessUnitTO;
import com.framework.to.UserGroupTO;
import com.framework.to.UserPrivilegeTO;
import com.framework.to.UserPrivilegeTOInsert;
import com.framework.to.UserTO;
import com.framework.utility.DateUtils;

/**
 * @author TCS
 */
public class UserMgmtDAOImpl extends HibernateDaoSupport implements UserMgmtDAO {
	
	private static final Logger LOG = Logger.getLogger(UserMgmtDAOImpl.class);
	private static final Long ACTIVE_USER_STATUS = 11L;
	
	@Override
	public UserTO fetchUserDetails(Long userId) throws CMMException {
	
		try {
			return getHibernateTemplate().get(UserTO.class, userId);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : fetchUserDetails", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : fetchUserDetails", he);
		}
	}
	
	@Override
	public UserTO getUserById(UserTO userTO) throws CMMException {
	
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(UserTO.class);
			criteria.add(Restrictions.eq("id", userTO.getId()));
			criteria.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);
			UserTO dbUser = (UserTO) getHibernateTemplate().findByCriteria(criteria).get(0);
			List<Long> roles = getUserRoles(userTO);
			for (Long role : roles) {
				dbUser.setRole(role.toString());
			}
			return dbUser;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : getUserById", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : getUserById", he);
		}
	}
	
	@Override
	public void addUser(UserTO userTO) throws CMMException {
	
		try {
			UserBusinessUnitTO userBusinessUnit = null;
			for (Long temp : userTO.getClientList()) {
				userBusinessUnit = new UserBusinessUnitTO();
				userBusinessUnit.setClientId(temp);
				userBusinessUnit.setUser(userTO);
				userTO.getUserBusinessUnit().add(userBusinessUnit);
			}
			userTO.getUserBusinessUnit().add(userBusinessUnit);
			userTO.setCreatedDate(new Date());
			getHibernateTemplate().save(userTO);
		} catch (DataIntegrityViolationException div) {
			LOG.error(div);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : addUser", div);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : addUser", dae);
		} catch (ConstraintViolationException e) {
			LOG.error(e);
			throw new CMMException("User Name already exists. UserMgmtDAOImpl : addUser", e);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : addUser", he);
		}
	}
	
	@Override
	public List<BusinessUnitTO> getSavedClientList(Long userId) throws CMMException {
	
		try {
			String hql = String.format("select Distinct c from BusinessUnitTO c, UserBusinessUnitTO u  where u.clientId=c.clientId and u.user.id=%d", userId);
			return (List<BusinessUnitTO>) getHibernateTemplate().find(hql);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : getSavedClientList", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : getSavedClientList", he);
		}
	}
	
	@Override
	public void changePassword(UserTO userTO) throws CMMException {
	
		try {
			UserTO to = (UserTO) getHibernateTemplate().find("from UserTO where id=?", userTO.getId()).get(0);
			to.setModifiedbyDate(DateUtils.getStartTime(new Date()));
			to.setModifiedbyId(userTO.getId());
			to.setPasswordEnc(userTO.getPasswordEnc());
			to.setLastPasswordChanged(new Date());
			to.setModifiedDate(DateUtils.getStartTime(new Date()));
			getHibernateTemplate().update(to);
		} catch (DataIntegrityViolationException div) {
			LOG.error(div);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : changePassword", div);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : changePassword", dae);
		} catch (ConstraintViolationException e) {
			LOG.error(e);
			throw new CMMException("User Name already exists. UserMgmtDAOImpl : changePassword", e);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : changePassword", he);
		}
	}
	
	@Override
	public Long deleteUser(UserTO userTO) throws CMMException {
	
		try {
			List<Long> objList = (List<Long>) getHibernateTemplate().find("select status from UserTO where id=?", userTO.getId());
			for (Long obj : objList) {
				Long status = obj;
				if (status == 12L) {
					return -1L;
				}
			}
			UserTO to = (UserTO) getHibernateTemplate().find("from UserTO where id=?", userTO.getId()).get(0);
			to.setStatus(CMMConstants.Framework.Entity.USER_STATUS_INACTIVE);
			getHibernateTemplate().update(to);
			return 1L;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : deleteUser", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : deleteUser", he);
		}
	}
	
	@Override
	public List<String> getAllUserNames() throws CMMException {
	
		try {
			return (List<String>) getHibernateTemplate().find("select name from UserTO");
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : getAllUserNames", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : getAllUserNames", he);
		}
	}
	
	@Override
	public List<ClientTO> getAllClients(Long clientId) throws CMMException {
	
		try {
			if (clientId == 0) {
				return (List<ClientTO>) getHibernateTemplate().find("from ClientTO where status=?", CMMConstants.Framework.Entity.BUSINESS_ACTIVE);
			} else {
				return (List<ClientTO>) getHibernateTemplate().find("from ClientTO where id=? and status=?", clientId, CMMConstants.Framework.Entity.BUSINESS_ACTIVE);
			}
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : getAllClients", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : getAllClients", he);
		}
	}
	
	@Override
	public List<ClientTO> getAllClientsForAccessMgmt() throws CMMException {
	
		try {
			return (List<ClientTO>) getHibernateTemplate().find("from ClientTO where clientId != 0L");
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : getAllClientsForAccessMgmt", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : getAllClientsForAccessMgmt", he);
		}
	}
	
	@Override
	public List<StatusTO> getStatusList() throws CMMException {
	
		try {
			return (List<StatusTO>) getHibernateTemplate().find("from StatusTO where entityId=?", CMMConstants.Framework.Entity.USER);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : getStatusList", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : getStatusList", he);
		}
	}
	
	@Override
	public List<UserTO> searchUser(UserTO userTO, List<BusinessUnitTO> businessUnitTOList) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			List<Long> clientIdList = new ArrayList<Long>();
			List<UserTO> userList = new ArrayList<UserTO>();
			if (userTO.getSelectedClientList() != null) {
				for (Long businessUnit : userTO.getSelectedClientList()) {
					clientIdList.add(businessUnit);
				}
			} else {
				for (BusinessUnitTO businessUnitTO : businessUnitTOList) {
					clientIdList.add(businessUnitTO.getClientId());
				}
			}
			if (userTO.getName().isEmpty() && (userTO.getSelectedClientList() == null) && userTO.getFullName().isEmpty() && userTO.getEmail().isEmpty() && (userTO.getSelectedRole() == null)) {
				String query = "select distinct u from UserTO u , UserPrivilegeTO up , UserBusinessUnitTO ubu where ubu.user.id=u.id  and ubu.user.id = up.id and  up.roleId  <> 0 and u.clientId in (:clientIdList)";
				Query q;
				if (userTO.getSearchCount() == 0) {
					q = session.createQuery(query);
				} else {
					Query q1 = session.createQuery(query).setFirstResult(userTO.getFirstResult());
					q = q1.setMaxResults(userTO.getTableSize());
				}
				q.setParameterList("clientIdList", clientIdList);
				userList.addAll(q.list());
				for (UserTO to : userList) {
					Long roleId = getUserRoles(to).get(0);
					String roleName = getRoleName(roleId);
					to.setRole(roleName);
				}
				return userList;
			} else {
				String query = "select distinct u from UserTO u , UserPrivilegeTO up , UserBusinessUnitTO ubu where ubu.user.id=u.id  and ubu.user.id = up.id and  up.roleId  <> 0 and ubu.clientId in (:clientIdList)";
				if (StringUtils.hasText(userTO.getName())) {
					String username = userTO.getName().replace("_", "/_");
					query = query + "and (u.name  like '%" + username + "%' escape '/' )";
				}
				if (StringUtils.hasText(userTO.getFullName())) {
					query = query + " and u.fullName  like'%" + userTO.getFullName() + "%' ";
				}
				if (StringUtils.hasText(userTO.getEmail())) {
					query = query + " and u.email  like'%" + userTO.getEmail() + "%' ";
				}
				if (userTO.getSelectedRole() != null) {
					query = query + " and up.roleId= " + userTO.getSelectedRole();
				}
				Query q;
				if (userTO.getSearchCount() == 0) {
					q = session.createQuery(query);
				} else {
					Query q1 = session.createQuery(query).setFirstResult(userTO.getFirstResult());
					q = q1.setMaxResults(userTO.getTableSize());
				}
				q.setParameterList("clientIdList", clientIdList);
				userList.addAll(q.list());
				for (UserTO to : userList) {
					Long roleId = getUserRoles(to).get(0);
					String roleName = getRoleName(roleId);
					to.setRole(roleName);
				}
				return userList;
			}
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : searchUser", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : searchUser", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<UserTO> searchLdapUser(UserTO userTO) throws CMMException {
	
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(UserTO.class);
			if (StringUtils.hasText(userTO.getName())) {
				criteria.add(Restrictions.like("name", "%" + userTO.getName() + "%"));
			}
			return (List<UserTO>) getHibernateTemplate().findByCriteria(criteria);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : searchLdapUser", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : searchLdapUser", he);
		}
	}
	
	@Override
	public List<Long> getUserRoles(UserTO userTO) throws CMMException {
	
		try {
			return (List<Long>) getHibernateTemplate().find("select r.id from UserTO u inner join u.roles r where u.id=?", userTO.getId());
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : getUserRoles", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : getUserRoles", he);
		}
	}
	
	@Override
	public void modifyUser(UserTO userTO) throws CMMException {
	
		Transaction tx = null;
		Session session = null;
		try {
			session = getSession();
			tx = session.beginTransaction();
			session.createQuery("delete from UserPrivilegeTO where id= :userId").setLong("userId", userTO.getId()).executeUpdate();
			UserTO to = (UserTO) getHibernateTemplate().find("from UserTO where id=?", userTO.getId()).get(0);
			to.setClientId(userTO.getClientId());
			to.setClientList(userTO.getClientList());
			to.setEmail(userTO.getEmail());
			to.setFullName(userTO.getFullName());
			to.setId(userTO.getId());
			to.setPhone(userTO.getPhone());
			to.setUserRoles(userTO.getUserRoles());
			to.setModifiedbyId(userTO.getId());
			to.setModifiedDate(DateUtils.getStartTime(new Date()));
			to.setStatus(userTO.getStatus());
			to.setSelectedSupervisorId(userTO.getSelectedSupervisorId());
			to.setAddress(userTO.getAddress());
			to.getUserBusinessUnit().clear();
			for (UserBusinessUnitTO temp : userTO.getUserBusinessUnit()) {
				UserBusinessUnitTO userBusinessUnitTO = new UserBusinessUnitTO();
				userBusinessUnitTO.setUser(to);
				userBusinessUnitTO.setClientId(temp.getClientId());
				to.getUserBusinessUnit().add(userBusinessUnitTO);
			}
			getHibernateTemplate().update(to);
			tx.commit();
			tx = session.beginTransaction();
			for (UserPrivilegeTO role : to.getUserRoles()) {
				UserPrivilegeTO privilegeTO = new UserPrivilegeTO();
				privilegeTO.setId(to.getId());
				privilegeTO.setRoleId(role.getId());
				UserPrivilegeTOInsert insert = new UserPrivilegeTOInsert();
				insert.setId(to.getId());
				insert.setRoleId(role.getId());
				getHibernateTemplate().save(insert);
			}
			tx.commit();
		} catch (DataIntegrityViolationException div) {
			LOG.error(div);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : modifyUser", div);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : modifyUser", dae);
		} catch (ConstraintViolationException e) {
			LOG.error(e);
			throw new CMMException("User Name already exists. UserMgmtDAOImpl : modifyUser", e);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : modifyUser", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public UserTO getUserProfileById(UserTO userTO) throws CMMException {
	
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(UserTO.class, "user");
			criteria.add(Restrictions.eq("id", userTO.getId()));
			criteria.setFetchMode("user.roles", FetchMode.JOIN);
			criteria.createAlias("roles", "role", CriteriaSpecification.LEFT_JOIN);
			criteria.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);
			return (UserTO) getHibernateTemplate().findByCriteria(criteria).get(0);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : getUserProfileById", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : getUserProfileById", he);
		}
	}
	
	@Override
	public void modifyUserProfile(UserTO userTO) throws CMMException {
	
		try {
			getHibernateTemplate().update(userTO);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : modifyUserProfile", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : modifyUserProfile", he);
		}
	}
	
	@Override
	public String getUserStatusDesc(Long status) throws CMMException {
	
		try {
			return (String) getHibernateTemplate().find("select statusDesc from StatusTO where id=?", status).get(0);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : getUserStatusDesc", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : getUserStatusDesc", he);
		}
	}
	
	@Override
	public UserTO getUserByName(String checkUsername) throws CMMException {
	
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(UserTO.class);
			criteria.createAlias("roles", "role", CriteriaSpecification.LEFT_JOIN);
			criteria.add(Restrictions.eq("name", checkUsername));
			criteria.add(Restrictions.eq("status", CMMConstants.Framework.Entity.USER_STATUS_ACTIVE));
			criteria.addOrder(Order.desc("role.id"));
			criteria.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);
			List<UserTO> dbUser = (List<UserTO>) getHibernateTemplate().findByCriteria(criteria);
			UserTO user = null;
			if (!dbUser.isEmpty()) {
				user = dbUser.get(0);
			}
			return user;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : getUserByName", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : getUserByName", he);
		}
	}
	
	@Override
	public boolean checkUsername(UserTO userTO) throws CMMException {
	
		try {
			List<UserTO> user = (List<UserTO>) getHibernateTemplate().find("from UserTO where name=?", userTO.getName());
			return !user.isEmpty();
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : checkUsername", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : checkUsername", he);
		}
	}
	
	@Override
	public List<UserTO> getAllUsers() throws CMMException {
	
		return (List<UserTO>) getHibernateTemplate().find("from UserTO");
	}
	
	@Override
	public String fetchEmailIds(Long applicationId) throws CMMException {
	
		try {
			List<Object[]> list = (List<Object[]>) getHibernateTemplate().find("SELECT distinct us.email as email FROM UserGroupTO u,UserGroupDetailsTO ug,users us WHERE u.id = ug.userGroups.id and ug.users.id= us.id and u.applicationId=?", applicationId);
			String emailList = null;
			for (Object[] temp : list) {
				if (emailList == null) {
					emailList = Arrays.toString(temp);
				} else {
					emailList = emailList + "," + Arrays.toString(temp);
				}
			}
			return emailList;
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : fetchEmailIds", he);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : fetchEmailIds", dae);
		}
	}
	
	@Override
	public List<UserTO> getSupervisorUserNames(List<Long> clientList, Long roleId) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			List<RoleLevelTO> roleLevelList = new ArrayList<RoleLevelTO>(0);
			List<UserTO> userList = new ArrayList<UserTO>(0);
			List<Object[]> objList = (List<Object[]>) getHibernateTemplate().find("from RoleTO  r, RoleLevelTO  rl where r.id= rl.roleId and r.id = ?", roleId);
			if (!objList.isEmpty()) {
				for (Object[] rolelevel : objList) {
					roleLevelList.add((RoleLevelTO) rolelevel[1]);
				}
				Long roleOrder = roleLevelList.get(0).getRoleLevelOrder();
				String query = "SELECT distinct ubu.user.id, u.name, up.roleId from UserTO u ,UserPrivilegeTO up , RoleLevelTO  rl, UserBusinessUnitTO ubu where ubu.user.id=u.id and ubu.user.id = up.id and rl.roleId = up.roleId and u.status =:activeUserStatus and ubu.clientId in (:clientList)";
				if (roleOrder != null) {
					query = query + " and rl.roleLevelOrder > :roleOrder";
				}
				Query q = session.createQuery(query);
				q.setParameterList("clientList", clientList);
				q.setParameter("activeUserStatus", ACTIVE_USER_STATUS);
				if (roleOrder != null) {
					q.setParameter("roleOrder", roleOrder);
				}
				List<Object[]> obj = q.list();
				if (obj != null) {
					for (Object[] temp : obj) {
						UserTO user = new UserTO();
						user.setId((Long) temp[0]);
						user.setName(temp[1].toString());
						user.setRoleId((Long) temp[2]);
						userList.add(user);
					}
				}
				return userList;
			} else {
				String query = "SELECT distinct ubu.user.id,u.name,up.roleId FROM UserTO u, UserPrivilegeTO up, UserBusinessUnitTO ubu where ubu.user.id= up.id and u.status =:activeUserStatus and ubu.clientId in (:clientList)";
				if (roleId != 1) {
					query = query + " and up.roleId < " + roleId;
				} else {
					query = query + " and up.roleId = " + roleId;
				}
				Query q = session.createQuery(query);
				q.setParameterList("clientList", clientList);
				q.setParameter("activeUserStatus", ACTIVE_USER_STATUS);
				List<Object[]> obj = q.list();
				if (obj != null) {
					for (Object[] temp : obj) {
						UserTO user = new UserTO();
						user.setId((Long) temp[0]);
						user.setName(temp[1].toString());
						user.setRoleId((Long) temp[2]);
						userList.add(user);
					}
				}
				return userList;
			}
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : getSupervisorUserNames", he);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : getSupervisorUserNames", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<UserTO> getThisWeekAddedUserList() throws CMMException {
	
		try {
			Date currentDate = DateUtils.getStartTime(new Date());
			Date lastWeekDate = DateUtils.addDays(currentDate, -7);
			DetachedCriteria criteria = DetachedCriteria.forClass(UserTO.class);
			criteria.add(Restrictions.ge("createdDate", lastWeekDate));
			return (List<UserTO>) getHibernateTemplate().findByCriteria(criteria);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : getThisWeekAddedUserList", he);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : getThisWeekAddedUserList", dae);
		}
	}
	
	@Override
	public List<UserTO> getAllUserNamesForEditSupervisor(List<Long> clientId, Long roleId, Long userId) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			List<RoleLevelTO> roleLevelList = new ArrayList<RoleLevelTO>(0);
			List<UserTO> userList = new ArrayList<UserTO>(0);
			List<Object[]> objList = (List<Object[]>) getHibernateTemplate().find("from RoleTO  r, RoleLevelTO  rl where r.id= rl.roleId and r.id = ?", roleId);
			if (!objList.isEmpty()) {
				for (Object[] rolelevel : objList) {
					roleLevelList.add((RoleLevelTO) rolelevel[1]);
				}
				Long roleOrder = roleLevelList.get(0).getRoleLevelOrder();
				String query = "SELECT distinct ubu.user.id, u.name, up.roleId from UserTO u ,UserPrivilegeTO up , RoleLevelTO  rl, UserBusinessUnitTO ubu  where ubu.user.id=u.id and ubu.user.id = up.id and rl.roleId = up.roleId and u.status =:activeUserStatus and ubu.clientId in (:clientId) and ubu.user.id <> :userId";
				if (roleOrder != null) {
					query = query + " and rl.roleLevelOrder > :roleOrder";
				}
				Query q = session.createQuery(query);
				q.setParameterList("clientId", clientId);
				q.setParameter("activeUserStatus", ACTIVE_USER_STATUS);
				q.setParameter("userId", userId);
				if (roleOrder != null) {
					q.setParameter("roleOrder", roleOrder);
				}
				List<Object[]> obj = q.list();
				if (obj != null) {
					for (Object[] temp : obj) {
						UserTO user = new UserTO();
						user.setId((Long) temp[0]);
						user.setName(temp[1].toString());
						user.setRoleId((Long) temp[2]);
						userList.add(user);
					}
				}
				return userList;
			} else {
				String query = "SELECT distinct ubu.user.id, u.name, up.roleId FROM UserTO u, UserPrivilegeTO up, UserBusinessUnitTO ubu where ubu.user.id=u.id and ubu.user.id= up.id and u.status =:activeUserStatus and ubu.clientId in (:clientId) and ubu.user.id <> :userId and up.roleId < :roleId";
				Query q = session.createQuery(query);
				q.setParameterList("clientId", clientId);
				q.setParameter("activeUserStatus", ACTIVE_USER_STATUS);
				q.setParameter("userId", userId);
				q.setParameter("roleId", roleId);
				List<Object[]> obj = q.list();
				if (obj != null) {
					for (Object[] temp : obj) {
						UserTO user = new UserTO();
						user.setId((Long) temp[0]);
						user.setName(temp[1].toString());
						user.setRoleId((Long) temp[2]);
						userList.add(user);
					}
				}
				return userList;
			}
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : getAllUserNamesForEditSupervisor", he);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : getAllUserNamesForEditSupervisor", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<Object[]> getUserRequests(UserTO userTO) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			final Long userId = userTO.getId();
			List<Object[]> list = null;
			String query = "select sr.request_id,sr.service_id,sc.service_name,sr.application_id,a.application_name, sr.application_release_id, ar.release_name,sr.environment_id,sr.starttime,sr.endtime,sr.created_by,u.name,sr.status_id,s.status_desc from service_request sr left outer join services sc on sr.service_id = sc.service_id left outer join applications a on sr.application_id = a.id left outer join application_release ar on sr.application_release_id = ar.id and sr.application_id = ar.application_id left outer join users u on sr.created_by = u.id left outer join status s on sr.status_id = s.id where sr.created_by = ? order by sr.request_id";
			SQLQuery sqlQuery = session.createSQLQuery(query);
			sqlQuery.setParameter(0, userId);
			list = sqlQuery.list();
			return list;
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : getUserRequests", he);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : getUserRequests", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<UserGroupTO> getUserGroupByUserId(Long id) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			String query = "SELECT ug.* FROM users u ,user_group_details ugds ,user_groups ug where u.id = ugds.user_id and ugds.group_Id = ug.id and u.id = ? ";
			SQLQuery sqlQuery = session.createSQLQuery(query);
			sqlQuery.setParameter(0, id);
			List<Object[]> ovbjectlist = sqlQuery.list();
			List<UserGroupTO> usergroupList = new ArrayList<UserGroupTO>();
			for (Object[] temp : ovbjectlist) {
				UserGroupTO userGroupTO = new UserGroupTO();
				userGroupTO.setId(Long.parseLong(((Number) temp[0]).toString()));
				usergroupList.add(userGroupTO);
			}
			return usergroupList;
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.", he);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public String getUserEmailByRequestId(Long requestId) throws CMMException {
	
		List<String> emailList = null;
		String hql = "SELECT u.email FROM UserTO u, UserGroupDetailsTO ugd, UserGroupTO ug, EnvironmentApplicationTO ea, ServiceRequestTO sr WHERE u.id=ugd.users.id AND ugd.userGroups.id=ug.id AND ug.applications.id=ea.applicationTO.id AND sr.environmentId=ea.environmentTO.id AND sr.id=?";
		try {
			emailList = (List<String>) getHibernateTemplate().find(hql, requestId);
		} catch (DataAccessException | HibernateException e) {
			throw new CMMException("Problem encountered : getUserEmailByRequestId", e);
		}
		StringBuilder emailBuild = new StringBuilder(0);
		for (String email : emailList) {
			emailBuild.append(email).append(",");
		}
		String emailIds = emailBuild.toString();
		emailIds = emailIds.substring(0, emailIds.length() - 1);
		return emailIds;
	}
	
	@Override
	public Long forgotPass(String username) throws CMMException {
	
		String user_source;
		Long flag = 0L;
		List<UserTO> userList = (List<UserTO>) getHibernateTemplate().find("from UserTO where name=?", username);
		if (!userList.isEmpty()) {
			flag = 2L;
		}
		if (flag == 2L) {
			List<UserTO> userType = (List<UserTO>) getHibernateTemplate().find("from UserTO where name=?", username);
			for (UserTO forgot : userType) {
				user_source = forgot.getUserSource();
				if ("TEMS".equals(user_source)) {
					flag = 1L;
				} else {
					flag = 3L;
				}
			}
		}
		return flag;
	}
	
	@Override
	public List<String> getSecurityQusetions() {
	
		List<String> q = new ArrayList<String>();
		List<SecurityQusetionsTO> questions = (List<SecurityQusetionsTO>) getHibernateTemplate().find("from SecurityQusetionsTO");
		String ques;
		for (SecurityQusetionsTO work : questions) {
			ques = work.getName();
			q.add(ques);
		}
		return q;
	}
	
	@Override
	public List<String> getSecurityQuesForPwd() {
	
		int j;
		List<String> random_questions = new ArrayList<String>();
		List<String> q = getSecurityQusetions();
		Random random = new Random();
		int i = q.size();
		for (j = 0; j < 2; j++) {
			int index = random.nextInt(q.size());
			while (index == i) {
				index = random.nextInt(q.size());
			}
			random_questions.add(q.get(index));
			i = index;
		}
		return random_questions;
	}
	
	@Override
	public void setSecurityQA(SecurityAnswersTO security_ans, Long user_id) {
	
		int i = 0;
		SecurityAnswersTO security_answer = new SecurityAnswersTO();
		Long ques_id = 1L;
		Long flag = 0L;
		List<SecurityAnswersTO> ans = (List<SecurityAnswersTO>) getHibernateTemplate().find("from SecurityAnswersTO where user_id=?", user_id);
		if (ans.isEmpty()) {
			flag = 1L;
		}
		if (flag == 1L) {
			for (i = 0; i < 3; i++) {
				security_answer.setAnswer_name(security_ans.getS_ans().get(i));
				security_answer.setQuestion_id(ques_id);
				security_answer.setUser_id(user_id);
				ques_id++;
				getHibernateTemplate().save(security_answer);
			}
		} else {
			for (SecurityAnswersTO security_ans1 : ans) {
				security_ans1.setAnswer_name(security_ans.getS_ans().get(i));
				security_ans1.setQuestion_id(ques_id);
				ques_id++;
				i++;
				getHibernateTemplate().update(security_ans1);
			}
		}
	}
	
	@Override
	public List<BusinessUnitTO> getBUName(List<UserBusinessUnitTO> userBusinessUnitTO) {
	
		List<BusinessUnitTO> BUlist = new ArrayList<BusinessUnitTO>(0);
		for (UserBusinessUnitTO temp : userBusinessUnitTO) {
			BusinessUnitTO businessUnitTO = new BusinessUnitTO();
			businessUnitTO = (BusinessUnitTO) getHibernateTemplate().find("from BusinessUnitTO where id =?", temp.getClientId()).get(0);
			BUlist.add(businessUnitTO);
		}
		return BUlist;
	}
	
	@Override
	public ForgotPassTO getForgotPwd(ForgotPassTO forgotPassTO) {
	
		String username = forgotPassTO.getUsername();
		List<Long> list = (List<Long>) getHibernateTemplate().find("SELECT id FROM UserTO u WHERE name=?", username);
		Long userid = list.get(0);
		String ques1 = forgotPassTO.getQues1();
		String ques2 = forgotPassTO.getQues2();
		List<Long> quesList1 = (List<Long>) getHibernateTemplate().find("SELECT id FROM SecurityQusetionsTO WHERE name=?", ques1);
		List<Long> quesList2 = (List<Long>) getHibernateTemplate().find("SELECT id FROM SecurityQusetionsTO WHERE name=?", ques2);
		String answer = forgotPassTO.getAns1();
		Long quesId = quesList1.get(0);
		List<SecurityAnswersTO> ans = (List<SecurityAnswersTO>) getHibernateTemplate().find("from SecurityAnswersTO where answer_name=? and question_id=? and user_id=?", answer, quesId, userid);
		String answer2 = forgotPassTO.getAns2();
		Long quesId2 = quesList2.get(0);
		List<SecurityAnswersTO> ans2 = (List<SecurityAnswersTO>) getHibernateTemplate().find("from SecurityAnswersTO where answer_name=? and question_id=? and user_id=?", answer2, quesId2, userid);
		if (ans.size() == 1) {
			forgotPassTO.setUserId(userid);
			forgotPassTO.setFlag(1L);
		} else {
			forgotPassTO.setFlag(0L);
		}
		if (ans2.size() == 1) {
			forgotPassTO.setUserId(userid);
			forgotPassTO.setFlag1(1L);
		} else {
			forgotPassTO.setFlag1(0L);
		}
		return forgotPassTO;
	}
	
	@Override
	public void changeForgotPwd(ForgotPassTO forgotPassTO) {
	
		UserTO to = (UserTO) getHibernateTemplate().find("from UserTO where id=?", forgotPassTO.getUserId()).get(0);
		to.setPasswordEnc(forgotPassTO.getPasswordEnc());
		to.setModifiedbyDate(DateUtils.getStartTime(new Date()));
		to.setModifiedbyId(forgotPassTO.getUserId());
		to.setLastPasswordChanged(new Date());
		to.setModifiedDate(DateUtils.getStartTime(new Date()));
		getHibernateTemplate().update(to);
	}
	
	@Override
	public UserBusinessUnitTO getUserBusinessUnitTODetailsForClientId(Long clientId) {
	
		return ((List<UserBusinessUnitTO>) getHibernateTemplate().find("from UserBusinessUnitTO ubu where ubu.clientId=?", clientId)).get(0);
	}
	
	@Override
	public UserTO getUserDetails(Long userId) throws CMMException {
	
		try {
			List<UserTO> userToList = (List<UserTO>) getHibernateTemplate().find("from UserTO where id=?", userId);
			return userToList.get(0);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : getUserDetails", he);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : getUserDetails", dae);
		}
	}
	
	@Override
	public Boolean checkQuesExist(String username) {
	
		List<Long> list = (List<Long>) getHibernateTemplate().find("SELECT id FROM UserTO u WHERE name=?", username);
		Long userid = list.get(0);
		List<Long> checklist = (List<Long>) getHibernateTemplate().find("SELECT answers_id FROM SecurityAnswersTO s WHERE user_id=?", userid);
		if (checklist.isEmpty()) {
			return false;
		}
		return true;
	}
	
	@Override
	public String getOldPassword(Long userId) {
	
		UserTO to = (UserTO) getHibernateTemplate().find("from UserTO where id=?", userId).get(0);
		return to.getPasswordEnc();
	}
	
	@Override
	public List<UserTO> getUserDetails(String userName) throws CMMException {
	
		try {
			List<UserTO> userToList = (List<UserTO>) getHibernateTemplate().find("from UserTO where name=?", userName);
			if (!userToList.isEmpty()) {
				UserTO usr = userToList.get(0);
				List<Long> roleId = (List<Long>) getHibernateTemplate().find("select u.roleId from UserPrivilegeTO u where id=?", usr.getId());
				userToList.get(0).setRoleId(roleId.get(0));
			}
			return userToList;
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : getUserDetails", he);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : getUserDetails", dae);
		}
	}
	
	private LdapTemplate ldapTemplate;
	private String searchQuery = "(&(objectClass=person)(objectCategory=person)(userPrincipalName=*)(name=%s))";
	
	public void setSearchQuery(String searchQuery) {
	
		this.searchQuery = searchQuery;
	}
	
	public void setLdapTemplate(LdapTemplate ldapTemplate) {
	
		this.ldapTemplate = ldapTemplate;
	}
	
	@Override
	public List<UserTO> searchUserActiveDirectory(String username) {
	
		String searchQueryPopulated = String.format(searchQuery, StringUtils.isEmpty(username) ? "*" : "*" + username + "*");
		List<UserTO> searchResults = new ArrayList<UserTO>();
		try {
			ldapTemplate.setIgnorePartialResultException(true);
			SearchControls controls = new SearchControls();
			controls.setSearchScope(SearchControls.SUBTREE_SCOPE);
			controls.setReturningAttributes(new String[] { "displayName", "mail", "userPrincipalName", "sAMAccountName" });
			searchResults = ldapTemplate.search("", searchQueryPopulated, controls, new UserTOAttributesMapper());
		} catch (Exception ce) {
			logger.error("Exception is fetching Users freom AD", ce);
		}
		return searchResults;
	}
	
	private class UserTOAttributesMapper implements AttributesMapper {
		
		@Override
		public UserTO mapFromAttributes(Attributes attrs) throws NamingException {
		
			UserTO userTO = new UserTO();
			Attribute attributeName = attrs.get("displayName");
			if (attributeName != null) {
				userTO.setFullName((String) attributeName.get());
			}
			Attribute attributeMail = attrs.get("mail");
			if (attributeMail != null) {
				userTO.setEmail((String) attributeMail.get());
			} else {
				Attribute attributeUPN = attrs.get("userPrincipalName");
				userTO.setEmail((String) attributeUPN.get());
			}
			Attribute attributeUPN = attrs.get("userPrincipalName");
			userTO.setUsername(((String) attributeUPN.get()).split("\\@")[0]);
			return userTO;
		}
	}
	
	public String getRoleName(Long role) throws CMMException {
	
		try {
			List<String> userRoleslist = (List<String>) getHibernateTemplate().find("select name from RoleTO  where id=?", role);
			return userRoleslist.get(0);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : getUserRoles", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : getUserRoles", he);
		}
	}
	
	@Override
	public List<UserTO> searchUser(UserTO userTO) throws CMMException {
	
		try {
			Session session = null;
			List<UserTO> userList = new ArrayList<UserTO>();
			session = getSession();
			List<Long> delegatedId = (List<Long>) getHibernateTemplate().find("select userId from DelegatedUserTO");
			delegatedId.add(userTO.getId());
			String query = "select distinct u from UserTO u ,UserPrivilegeTO up,RoleTO r, UserBusinessUnitTO ubu where  ubu.user.id=u.id  and ubu.user.id = up.id and ubu.clientId=(:clientId) and up.roleId=(:roleId) and u.id not in(:id)  and u.status <>(:status)";
			Query q;
			if (userTO.getSearchCount() == 0) {
				q = session.createQuery(query);
			} else {
				Query q1 = session.createQuery(query).setFirstResult(userTO.getFirstResult());
				q = q1.setMaxResults(userTO.getTableSize());
			}
			q.setParameter("clientId", userTO.getClientId());
			q.setParameter("roleId", userTO.getRoleId());
			q.setParameterList("id", delegatedId);
			q.setParameter("status", 12L);
			userList.addAll(q.list());
			return userList;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : getUserRoles", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : getUserRoles", he);
		}
	}
	
	@Override
	public boolean delegateAccess(DelegatedUserTO delegatedUserTO) throws CMMException {
	
		try {
			getHibernateTemplate().save(delegatedUserTO);
			return true;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : getUserRoles", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : getUserRoles", he);
		}
	}
	
	@Override
	public UserTO revokeAccess(Long userId) throws CMMException {
	
		UserTO userTO = null;
		try {
			List<UserTO> to = (List<UserTO>) getHibernateTemplate().find("select u from UserTO u, DelegatedUserTO d where userId=? and u.id=d.delegatedUserId", userId);
			if (!to.isEmpty()) {
				userTO = to.get(0);
			}
			return userTO;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : getUserRoles", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : getUserRoles", he);
		}
	}
	
	@Override
	public boolean revokeAccessSubmit(Long userId) throws CMMException {
	
		Transaction tx = null;
		Session session = null;
		try {
			session = getSession();
			tx = session.beginTransaction();
			session.createQuery("delete from DelegatedUserTO where userId= :userId").setLong("userId", userId).executeUpdate();
			tx.commit();
			return true;
		} catch (DataAccessException e) {
			LOG.error(e);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : revokeAccessSubmit", e);
		} catch (HibernateException e) {
			LOG.error(e);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : revokeAccessSubmit", e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public boolean checkUserAlreadyDeledgated(Long userId) throws CMMException {
	
		Session session = null;
		try {
			boolean flag;
			List<UserTO> to = (List<UserTO>) getHibernateTemplate().find("from DelegatedUserTO d where delegatedUserId=?", userId);
			if (!to.isEmpty()) {
				flag = true;
			} else {
				flag = false;
			}
			return flag;
		} catch (DataAccessException e) {
			LOG.error(e);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : revokeAccessSubmit", e);
		} catch (HibernateException e) {
			LOG.error(e);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : revokeAccessSubmit", e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public boolean checkDelegationDoneAlready(Long userId) throws CMMException {
	
		Session session = null;
		try {
			boolean flag;
			List<UserTO> to = (List<UserTO>) getHibernateTemplate().find("from DelegatedUserTO d where userId=?", userId);
			if (!to.isEmpty()) {
				flag = true;
			} else {
				flag = false;
			}
			return flag;
		} catch (DataAccessException e) {
			LOG.error(e);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : revokeAccessSubmit", e);
		} catch (HibernateException e) {
			LOG.error(e);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : revokeAccessSubmit", e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
}