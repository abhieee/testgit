package com.ext.dao.impl;

import java.sql.Blob;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.sql.rowset.serial.SerialBlob;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.DockerDao;
import com.framework.exception.CMMException;
import com.framework.to.DockerServerConfigurationTO;
import com.framework.to.DockerTemplateTO;
import com.framework.to.EnvironmentDockerTO;
import com.framework.to.RepositoryTO;

public class DockerDaoImpl extends HibernateDaoSupport implements DockerDao {
	
	private static final Logger LOG = Logger.getLogger(DockerDaoImpl.class);
	
	@Override
	public void saveTemplate(DockerTemplateTO dockerTemplateTO) throws CMMException {
	
		try {
			byte[] configFileByt = dockerTemplateTO.getFileData();
			Blob configFile = new SerialBlob(configFileByt);
			dockerTemplateTO.setTemplateData(configFile);
			getHibernateTemplate().save(dockerTemplateTO);
		} catch (DataAccessException | HibernateException | SQLException e) {
			throw new CMMException("Problem encountered.DockerDaoImpl:saveTemplate", e);
		}
	}
	
	@Override
	public List<DockerTemplateTO> searchDockerTemplate() throws CMMException {
	
		List<DockerTemplateTO> dockerTemplateTO = new ArrayList<DockerTemplateTO>(0);
		try {
			dockerTemplateTO = (List<DockerTemplateTO>) getHibernateTemplate().find("from DockerTemplateTO ");
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Problem encountered.DockerDaoImpl:searchDockerTemplate", dae);
		}
		return dockerTemplateTO;
	}
	
	@Override
	public boolean checkTemplateName(String templateName) throws CMMException {
	
		List<DockerTemplateTO> templateList = null;
		try {
			templateList = (List<DockerTemplateTO>) getHibernateTemplate().find("from DockerTemplateTO where templateName=?", templateName);
			return !templateList.isEmpty();
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Problem encountered.DockerDaoImpl:checkTemplateName", dae);
		}
	}
	
	@Override
	public DockerTemplateTO getDockerTemplatebyId(Long templateId) throws CMMException {
	
		DockerTemplateTO dockerTemplateTO = new DockerTemplateTO();
		try {
			dockerTemplateTO = (DockerTemplateTO) getHibernateTemplate().find("from DockerTemplateTO where id=?", templateId).get(0);
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Problem encountered.DockerDaoImpl:getDockerTemplatebyId", dae);
		}
		return dockerTemplateTO;
	}
	
	@Override
	public List<DockerTemplateTO> searchDockerTemplatesByName(DockerTemplateTO dockerTemplate) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			Criteria criteria = session.createCriteria(DockerTemplateTO.class, "dockerTemplateTO");
			if (dockerTemplate.getTemplateName() == null) {
				dockerTemplate.setTemplateName("");
			}
			if (!"".equalsIgnoreCase(dockerTemplate.getTemplateName().trim())) {
				criteria.add(Restrictions.like("templateName", "%" + dockerTemplate.getTemplateName() + "%"));
			}
			List<DockerTemplateTO> dockerTemplateList = criteria.list();
			if (dockerTemplate.getSearchCount() == 0) {
				dockerTemplateList = criteria.list();
			} else {
				criteria.setFirstResult(dockerTemplate.getFirstResult());
				criteria.setMaxResults(dockerTemplate.getTableSize());
				dockerTemplateList = criteria.list();
			}
			if (dockerTemplateList.isEmpty()) {
				dockerTemplateList = null;
				return dockerTemplateList;
			} else {
				return dockerTemplateList;
			}
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Problem encountered.ServiceRequestDAOImpl:searchDockerTemplatesByName", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public void editTemplateDetails(DockerTemplateTO dockerTemplate) throws CMMException {
	
		try {
			byte[] configFileByt = dockerTemplate.getTemplateDataStr().getBytes();
			Blob configFile = new SerialBlob(configFileByt);
			dockerTemplate.setTemplateData(configFile);
			getHibernateTemplate().update(dockerTemplate);
		} catch (DataAccessException | HibernateException | SQLException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. DockerDaoImpl: editTemplateDetails", dae);
		}
	}
	
	@Override
	public List<DockerServerConfigurationTO> getAllDockerServerDetails() throws CMMException {
	
		List<DockerServerConfigurationTO> dockerServerConfigurationTO = new ArrayList<DockerServerConfigurationTO>();
		Session session = null;
		try {
			dockerServerConfigurationTO = (List<DockerServerConfigurationTO>) getHibernateTemplate().find("from DockerServerConfigurationTO");
			return dockerServerConfigurationTO;
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Problem encountered.DockerDaoImpl:getAllDockerServerDetails", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<DockerServerConfigurationTO> getToDockerServerList(String selectedServerIp) throws CMMException {
	
		List<DockerServerConfigurationTO> dockerServerConfigurationTO = new ArrayList<DockerServerConfigurationTO>();
		Session session = null;
		try {
			dockerServerConfigurationTO = (List<DockerServerConfigurationTO>) getHibernateTemplate().find("from DockerServerConfigurationTO where serverIp NOT IN (?)", selectedServerIp);
			return dockerServerConfigurationTO;
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Problem encountered.DockerDaoImpl:getToDockerServerList", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<DockerServerConfigurationTO> getDockerServerDetailsByIP(String ip) throws CMMException {
	
		List<DockerServerConfigurationTO> dockerServerConfigurationTO = new ArrayList<DockerServerConfigurationTO>();
		Session session = null;
		try {
			dockerServerConfigurationTO = (List<DockerServerConfigurationTO>) getHibernateTemplate().find("from DockerServerConfigurationTO where serverIp=?", ip);
			if (!dockerServerConfigurationTO.isEmpty()) {
				return dockerServerConfigurationTO;
			} else {
				dockerServerConfigurationTO = null;
				return dockerServerConfigurationTO;
			}
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Problem encountered.DockerDaoImpl:getDockerServerDetailsByIP", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public void saveContainerIP(String containerIP, Long envId, String containerID) throws CMMException {
	
		try {
			EnvironmentDockerTO envDocker = (EnvironmentDockerTO) getHibernateTemplate().find("from EnvironmentDockerTO where envId=?", envId).get(0);
			envDocker.setContainerIp(containerIP);
			envDocker.setContainerID(containerID);
			getHibernateTemplate().update(envDocker);
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Problem encountered.DockerDaoImpl:saveContainerIP", dae);
		}
	}
	
	@Override
	public EnvironmentDockerTO getDockerEnvDetails(Long envId) throws CMMException {
	
		try {
			return (EnvironmentDockerTO) getHibernateTemplate().find("from EnvironmentDockerTO where envId=?", envId).get(0);
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Problem encountered.DockerDaoImpl:getDockerEnvDetails", dae);
		}
	}
	
	@Override
	public List<RepositoryTO> getRepositoryList() throws CMMException {
	
		return (List<RepositoryTO>) getHibernateTemplate().find("from RepositoryTO ");
	}
	
	@Override
	public RepositoryTO getRepositoryDetail(long repoId) throws CMMException {
	
		RepositoryTO repo = new RepositoryTO();
		List<RepositoryTO> repoList = (List<RepositoryTO>) getHibernateTemplate().find("from RepositoryTO where id=? ", repoId);
		if (!repoList.isEmpty()) {
			repo = repoList.get(0);
		}
		return repo;
	}
}
