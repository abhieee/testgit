package com.ext.dao.impl;

import java.util.ArrayList;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.hibernate.exception.ConstraintViolationException;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.RoleDao;
import com.framework.common.CMMConstants;
import com.framework.exception.CMMException;
import com.framework.to.RoleLevelTO;
import com.framework.to.RoleTO;
import com.framework.to.StatusTO;

public class RoleDaoImpl extends HibernateDaoSupport implements RoleDao {
	
	@Override
	public RoleTO addRole(RoleTO roleTO) throws CMMException {
	
		try {
			getHibernateTemplate().save(roleTO);
		} catch (DataIntegrityViolationException div) {
			logger.error(div);
			throw new CMMException("Problem encountered.RoleDaoImpl:addRole", div);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.RoleDaoImpl:addRole", dae);
		} catch (ConstraintViolationException e) {
			logger.error(e);
			throw new CMMException("Problem encountered.RoleDaoImpl:addRole", e);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.RoleDaoImpl:addRole", he);
		}
		return roleTO;
	}
	
	@Override
	public void defineRole(RoleLevelTO roleLevelTO) throws CMMException {
	
		try {
			List<RoleLevelTO> rolelevelList = (List<RoleLevelTO>) getHibernateTemplate().find(" from RoleLevelTO ");
			getHibernateTemplate().deleteAll(rolelevelList);// deleting the
			Long counter = 0L;
			for (Long roleId : roleLevelTO.getDefinedRoles()) {
				RoleLevelTO temp = new RoleLevelTO();
				counter++;
				temp.setRoleLevelOrder(counter);// setting the level order of
				temp.setRoleId(roleId);
				getHibernateTemplate().save(temp);
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : defineWorkflow ", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : defineWorkflow", he);
		}
	}
	
	@Override
	public List<StatusTO> getStatusList() throws CMMException {
	
		try {
			return (List<StatusTO>) getHibernateTemplate().find("from StatusTO where entityId=?", CMMConstants.Framework.Entity.ROLE);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. RoleDaoImpl: getStatusList", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. RoleDaoImpl: getStatusList", he);
		}
	}
	
	@Override
	public List<RoleTO> searchRole(RoleTO roleTO) throws CMMException {
	
		Session session = null;
		session = getSession();
		Criteria criteria = session.createCriteria(RoleTO.class, "rolesTO");
		try {
			List<RoleTO> roleList = new ArrayList<RoleTO>();
			List<RoleTO> temp = new ArrayList<RoleTO>();
			if (!"".equalsIgnoreCase(roleTO.getName().trim())) {
				criteria.add(Restrictions.like("name", "%" + roleTO.getName() + "%"));
			}
			if (roleTO.getSelectedStatus() > 0L) {
				criteria.add(Restrictions.eq("statusTO.id", roleTO.getSelectedStatus()));
			}
			criteria.add(Restrictions.gt("id", 0L));
			if (roleTO.getSearchCount() == 0) {
				temp = criteria.list();
			} else {
				criteria.setFirstResult(roleTO.getFirstResult());
				criteria.setMaxResults(roleTO.getTableSize());
				temp = criteria.list();
			}
			for (RoleTO hd : temp) {
				roleList.add(hd);
			}
			return roleList;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. RoleDaoImpl: searchRole", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. RoleDaoImpl: searchRole", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public RoleTO loadRoleDetails(RoleTO roleTO) throws CMMException {
	
		try {
			RoleTO rolesTO = (RoleTO) getHibernateTemplate().find("from RoleTO where id=?", roleTO.getId()).get(0);
			rolesTO.setSelectedStatus(rolesTO.getStatus());
			rolesTO.setRemarks(rolesTO.getRemarks());
			return rolesTO;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.RoleDaoImpl:loadRoleDetails", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.RoleDaoImpl:loadRoleDetails", he);
		}
	}
	
	@Override
	public List<RoleTO> getDefinedRoles(String roleId) throws CMMException {
	
		List<RoleTO> dbRoles = new ArrayList<RoleTO>();
		StringBuilder query = new StringBuilder("select r.name from RoleTO r where r.id=?");// to get the name
		try {
			List<RoleLevelTO> roles = (List<RoleLevelTO>) getHibernateTemplate().find("from RoleLevelTO ");
			for (RoleLevelTO obj : roles) {
				RoleTO roleTO = new RoleTO();
				String roleName = (String) getHibernateTemplate().find(query.toString(), obj.getRoleId()).get(0);
				roleTO.setName(roleName);
				roleTO.setId(obj.getRoleId());
				dbRoles.add(roleTO);
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.RoleDaoImpl : getDefinedRoles", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.RoleDaoImpl : getDefinedRoles", he);
		} catch (Exception e) {
			logger.error(e);
			throw new CMMException("Problem encountered.RoleDaoImpl : getDefinedRoles", e);
		}
		return dbRoles;
	}
	
	@Override
	public void editRole(RoleTO roleTO) throws CMMException {
	
		try {
			roleTO.setStatus(roleTO.getSelectedStatus());
			getHibernateTemplate().update(roleTO);
		} catch (ConstraintViolationException ce) {
			logger.error(ce);
			throw new CMMException("Problem encountered.RoleDaoImpl:editProject", ce);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.RoleDaoImpl:editProject", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.RoleDaoImpl:editProject", he);
		}
	}
	
	@Override
	public boolean checkName(RoleTO roleTO) throws CMMException {
	
		boolean flag = false;
		try {
			List<RoleTO> unit = (List<RoleTO>) getHibernateTemplate().find("from RoleTO where name=?", roleTO.getName());
			if (!unit.isEmpty()) {
				flag = true;
			} else {
				flag = false;
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.RoleDaoImpl:checkName.", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.RoleDaoImpl:checkName.", he);
		}
		return flag;
	}
}
