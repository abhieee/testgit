package com.ext.dao.impl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.SoftwareDAO;
import com.framework.common.CMMConstants;
import com.framework.exception.CMMException;
import com.framework.nolio.to.CAActivityProcessOrderTO;
import com.framework.nolio.to.NolioProcessParametersTO;
import com.framework.nolio.to.NolioProcessSoftwareMapping;
import com.framework.to.ActivitySoftwareMappingTO;
import com.framework.to.EnvironmentDetailsTO;
import com.framework.to.ParameterTO;
import com.framework.to.SoftwareTO;
import com.framework.to.SoftwareTemplatePropertyTO;
import com.framework.to.SoftwareconfigTO;
import com.framework.to.StatusTO;
import com.framework.to.ZabbixSoftwareMappingTO;
import com.framework.utility.DateUtils;

/**
 * @author TCS
 */
public class SoftwareDAOImpl extends HibernateDaoSupport implements SoftwareDAO {
	
	private static final Logger LOG = Logger.getLogger(SoftwareDAOImpl.class);
	
	@Override
	public SoftwareTO addSoftware(SoftwareTO softwareTO) throws CMMException {
	
		try {
			SoftwareconfigTO temp = new SoftwareconfigTO();
			temp.setPatch("0.00");
			temp.setRemark(softwareTO.getRemark());
			temp.setVersion(softwareTO.getVersion());
			temp.setCreatedByDate(DateUtils.getStartTime(new Date()));
			temp.setCreatedById(softwareTO.getCreatedById());
			temp.setEffectiveDate(DateUtils.getStartTime(new Date()));
			temp.setEffectiveRelease(softwareTO.getEffectiveRelease());
			temp.setStatusId(61L);
			temp.setSoftware(softwareTO);
			/** Client's Enhancement **/
			temp.getSoftwareTemplatePropertyTO().clear();
			softwareTO.getSoftwareconfigs().add(temp);
			/** Client's Enhancement ends **/
			Serializable save = getHibernateTemplate().save(softwareTO);
			Long softwareId = (Long) save;
			SoftwareTO software = new SoftwareTO();
			software.setId(softwareId);
			for (SoftwareconfigTO tt : softwareTO.getSoftwareconfigs()) {
				software.setSoftwareconfigsId(tt.getId());
				for (SoftwareTemplatePropertyTO paramTO : softwareTO.getProp()) {
					SoftwareTemplatePropertyTO softAttrTO = new SoftwareTemplatePropertyTO();
					softAttrTO.setParameterTO(getParam(paramTO.getParamId()));
					softAttrTO.setSoftwareConfigTO(tt);
					softAttrTO.setValue(paramTO.getValue());
					getHibernateTemplate().save(softAttrTO);
				}
			}
			return software;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. SoftwareDAOImpl:addSoftware", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. SoftwareDAOImpl:addSoftware", he);
		}
	}
	
	@Override
	public SoftwareTO addExsitingSoftware(SoftwareTO softwareTO) throws CMMException {
	
		try {
			softwareTO.setCreatedByDate(DateUtils.getStartTime(new Date()));
			softwareTO.setModifiedbyDate(DateUtils.getStartTime(new Date()));
			SoftwareconfigTO temp = new SoftwareconfigTO();
			if (softwareTO.getParameters() != null) {
				if (softwareTO.getParameters().toString().length() > 2) {
					temp.setParameters(softwareTO.getParameters().toString().substring(1, softwareTO.getParameters().toString().length() - 1));
				}
			} else {
				temp.setParameters(null);
			}
			temp.setPatch("1.0");
			temp.setRemark(softwareTO.getRemark());
			temp.setVersion(softwareTO.getVersion());
			temp.setCreatedByDate(DateUtils.getStartTime(new Date()));
			temp.setModifiedbyDate(DateUtils.getStartTime(new Date()));
			temp.setCreatedById(softwareTO.getCreatedById());
			temp.setModifiedbyId(softwareTO.getCreatedById());
			temp.setEffectiveDate(DateUtils.getStartTime(new Date()));
			temp.setEffectiveRelease("1.0");
			temp.setStatusId(61L);
			temp.setSoftware(softwareTO);
			/** client's enhancement **/
			temp.getSoftwareTemplatePropertyTO().clear();
			/** client's enhancement **/
			softwareTO.getSoftwareconfigs().add(temp);
			getHibernateTemplate().saveOrUpdate(softwareTO);
			SoftwareTO software = new SoftwareTO();
			software.setId(softwareTO.getId());
			for (SoftwareconfigTO tt : softwareTO.getSoftwareconfigs()) {
				software.setSoftwareconfigsId(tt.getId());
				for (SoftwareTemplatePropertyTO paramTO : softwareTO.getProp()) {
					SoftwareTemplatePropertyTO softAttrTO = new SoftwareTemplatePropertyTO();
					softAttrTO.setParameterTO(getParam(paramTO.getParamId()));
					softAttrTO.setSoftwareConfigTO(tt);
					softAttrTO.setValue(paramTO.getValue());
					getHibernateTemplate().save(softAttrTO);
				}
			}
			return software;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. SoftwareDAOImpl:addExsitingSoftware", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. SoftwareDAOImpl:addExsitingSoftware", he);
		}
	}
	
	@Override
	public SoftwareTO getSoftwareDetails(Long selectSoftwareId, Long selectedSoftwareConfigId) throws CMMException {
	
		try {
			List<Long> taskIds = new ArrayList<>();
			SoftwareTO softwaredetails = new SoftwareTO();
			softwaredetails = (SoftwareTO) getHibernateTemplate().find("from SoftwareTO where id =?", selectSoftwareId).get(0);
			SoftwareconfigTO softwareconfigdetails = new SoftwareconfigTO();
			softwareconfigdetails = (SoftwareconfigTO) getHibernateTemplate().find("from SoftwareconfigTO where deviceId=?", selectSoftwareId).get(0);
			softwaredetails.setVersion(softwareconfigdetails.getVersion());
			softwaredetails.setTargetFlag(softwareconfigdetails.getTargetFlag());
			softwaredetails.setInstallerLocationLinux(softwareconfigdetails.getInstallerLocationLinux());
			softwaredetails.setInstallerLocationWindows(softwaredetails.getInstallerLocationWindows());
			softwaredetails.setTargetLocationLinux(softwaredetails.getTargetLocationLinux());
			softwaredetails.setTargetLocationWindows(softwaredetails.getTargetLocationWindows());
			softwaredetails.setSelectedZabbixTemplates((List<ZabbixSoftwareMappingTO>) getHibernateTemplate().find("from ZabbixSoftwareMappingTO where softwareConfigId=?", selectedSoftwareConfigId));
			taskIds = (List<Long>) getHibernateTemplate().find("select taskId from SoftwareTaskMappingTO  where softwareConfigId=? order by taskOrder asc", selectedSoftwareConfigId);
			softwaredetails.setTasks(taskIds);
			return softwaredetails;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. SoftwareDAOImpl:getSoftwareDetails", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. SoftwareDAOImpl:getSoftwareDetails", he);
		}
	}
	
	@Override
	public Long editSoftware(SoftwareTO softwareTO) throws CMMException {
	
		Long softwareConfigId = null;
		try {
			SoftwareTO softwareDetails = getSoftwareDetails(softwareTO.getId(), softwareTO.getSoftwareconfigsId());
			SoftwareTO fetchSoftware = getSoftwareDetails(softwareTO.getId(), softwareTO.getSoftwareconfigsId());
			softwareDetails.setId(softwareTO.getId());
			softwareDetails.setName(softwareTO.getName());
			softwareDetails.setManufacturer(softwareTO.getManufacturer());
			softwareDetails.setModel(softwareTO.getModel());
			softwareDetails.setModifiedbyId(softwareTO.getModifiedbyId());
			softwareDetails.setModifiedbyDate(DateUtils.getStartTime(new Date()));
			softwareDetails.setType(softwareTO.getType());
			SoftwareconfigTO softwareconfigTO = new SoftwareconfigTO();
			for (SoftwareconfigTO temp : softwareDetails.getSoftwareconfigs()) {
				if (temp.getId().longValue() == softwareTO.getSoftwareconfigsId().longValue()) {
					softwareconfigTO = temp;
					break;
				}
			}
			softwareDetails.getSoftwareconfigs().clear();
			softwareconfigTO.setVersion(softwareTO.getVersion());
			softwareconfigTO.setRemark(softwareTO.getRemark());
			softwareconfigTO.setStatusId(softwareTO.getStatusId());
			softwareconfigTO.setModifiedbyDate(DateUtils.getStartTime(new Date()));
			softwareconfigTO.setModifiedbyId(softwareTO.getModifiedbyId());
			softwareconfigTO.setSoftware(softwareDetails);
			softwareDetails.getSoftwareconfigs().add(softwareconfigTO);
			Set<SoftwareconfigTO> softwareconfigsTO = new HashSet<SoftwareconfigTO>(0);
			Iterator<SoftwareconfigTO> iterator = fetchSoftware.getSoftwareconfigs().iterator();
			while (iterator.hasNext()) {
				SoftwareconfigTO setElement = iterator.next();
				if (setElement.getId().equals(softwareTO.getSoftwareconfigsId())) {
					setElement.setVersion(softwareTO.getVersion());
					setElement.setRemark(softwareTO.getRemark());
					setElement.setStatusId(softwareTO.getStatusId());
					setElement.setModifiedbyDate(DateUtils.getStartTime(new Date()));
					setElement.setModifiedbyId(softwareTO.getModifiedbyId());
					setElement.setSoftware(softwareDetails);
					softwareconfigsTO.add(setElement);
				} else {
					softwareconfigsTO.add(setElement);
				}
			}
			softwareDetails.getSoftwareconfigs().addAll(softwareconfigsTO);
			getHibernateTemplate().merge(softwareDetails);
			SoftwareTO software = new SoftwareTO();
			software.setId(softwareTO.getId());
			if (!softwareDetails.getSoftwareconfigs().isEmpty()) {
				List<SoftwareTemplatePropertyTO> list = (List<SoftwareTemplatePropertyTO>) getHibernateTemplate().find("from SoftwareTemplatePropertyTO where softwareConfigTO.id=? ", softwareTO.getSoftwareconfigsId());
				if ((list != null) && !list.isEmpty()) {
					Iterator<SoftwareTemplatePropertyTO> itList = list.iterator();
					while (itList.hasNext()) {
						SoftwareTemplatePropertyTO emp = itList.next();
						getHibernateTemplate().delete(emp);
					}
				}
			}
			software.setSoftwareconfigsId(softwareconfigTO.getId());
			for (SoftwareTemplatePropertyTO paramTO : softwareTO.getProp()) {
				SoftwareTemplatePropertyTO softAttrTO = new SoftwareTemplatePropertyTO();
				softAttrTO.setParameterTO(getParam(paramTO.getParamId()));
				softAttrTO.setSoftwareConfigTO(softwareconfigTO);
				softAttrTO.setValue(paramTO.getValue());
				getHibernateTemplate().save(softAttrTO);
			}
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. SoftwareDAOImpl:editSoftware", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. SoftwareDAOImpl:editSoftware", he);
		}
		return softwareConfigId;
	}
	
	@Override
	public List<SoftwareTO> getAllSoftwares() throws CMMException {
	
		try {
			List<SoftwareTO> softwareList = new ArrayList<SoftwareTO>();
			List<Object[]> obj = (List<Object[]>) getHibernateTemplate().find("select s.name,s.manufacturer,s.model,s.id,s.type,sc.version,sc.patch,sc.remark, sc.id,sc.statusId from SoftwareTO s inner join s.softwareconfigs sc ");
			for (Object[] temp : obj) {
				SoftwareTO softwaredetails = new SoftwareTO();
				softwaredetails.setName(temp[0].toString());
				softwaredetails.setManufacturer(temp[1].toString());
				softwaredetails.setModel(temp[2].toString());
				softwaredetails.setId((Long) temp[3]);
				softwaredetails.setType(temp[4].toString());
				softwaredetails.setVersion(temp[5].toString());
				if (temp[7] != null) {
					softwaredetails.setRemark(temp[7].toString());
				}
				softwaredetails.setSoftwareconfigsId((Long) temp[8]);
				softwaredetails.setStatusId((Long) temp[9]);
				softwareList.add(softwaredetails);
			}
			return softwareList;
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. SoftwareDAOImpl:getAllSoftwares", dae);
		}
	}
	
	@Override
	public List<SoftwareconfigTO> searchSoftwareAll(SoftwareTO softwareTO) throws CMMException {
	
		Session session = null;
		List<SoftwareconfigTO> softwareList = new ArrayList<>();
		session = getSession();
		Criteria criteria = session.createCriteria(SoftwareconfigTO.class, "softwareconfig");
		criteria.createAlias("softwareconfig.software", "software", Criteria.LEFT_JOIN);
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		if (!"".equalsIgnoreCase(softwareTO.getName()) && !(softwareTO.getName() == null)) {
			criteria.add(Restrictions.like("software.name", "%" + softwareTO.getName() + "%"));
		}
		if (!"".equalsIgnoreCase(softwareTO.getType()) && !(softwareTO.getType() == null)) {
			String softwareType = softwareTO.getType().replace("_", "/_");
			criteria.add(Restrictions.like("software.type", "%" + softwareType + "%"));
		}
		if (!"".equalsIgnoreCase(softwareTO.getModel()) && !(softwareTO.getModel() == null)) {
			criteria.add(Restrictions.like("software.model", "%" + softwareTO.getModel() + "%"));
		}
		if (!"".equalsIgnoreCase(softwareTO.getManufacturer()) && !(softwareTO.getManufacturer() == null)) {
			criteria.add(Restrictions.like("software.manufacturer", "%" + softwareTO.getManufacturer() + "%"));
		}
		try {
			if (softwareTO.getSearchCount() == 0) {
				softwareList = criteria.list();
			} else {
				criteria.setFirstResult(softwareTO.getFirstResult());
				criteria.setMaxResults(softwareTO.getTableSize());
				softwareList = criteria.list();
			}
			return softwareList;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. SoftwareDAOImpl:searchSoftware", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. SoftwareDAOImpl:searchSoftware", he);
		}
	}
	
	@Override
	public List<SoftwareconfigTO> searchSoftwareAllForProfile(SoftwareTO softwareTO) throws CMMException {
	
		Session session = null;
		List<SoftwareconfigTO> softwareList = new ArrayList<>();
		session = getSession();
		Criteria criteria = session.createCriteria(SoftwareconfigTO.class, "softwareconfig");
		criteria.createAlias("softwareconfig.software", "software", Criteria.LEFT_JOIN);
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		criteria.add(Restrictions.eq("softwareconfig.statusId", CMMConstants.Framework.Entity.SOFTWARES_AVAILABLE));
		if (!"".equalsIgnoreCase(softwareTO.getName()) && !(softwareTO.getName() == null)) {
			criteria.add(Restrictions.like("software.name", "%" + softwareTO.getName() + "%"));
		}
		if (!"".equalsIgnoreCase(softwareTO.getType()) && !(softwareTO.getType() == null)) {
			String softwareType = softwareTO.getType().replace("_", "/_");
			criteria.add(Restrictions.like("software.type", "%" + softwareType + "%"));
		}
		if (!"".equalsIgnoreCase(softwareTO.getModel()) && !(softwareTO.getModel() == null)) {
			criteria.add(Restrictions.like("software.model", "%" + softwareTO.getModel() + "%"));
		}
		if (!"".equalsIgnoreCase(softwareTO.getManufacturer()) && !(softwareTO.getManufacturer() == null)) {
			criteria.add(Restrictions.like("software.manufacturer", "%" + softwareTO.getManufacturer() + "%"));
		}
		try {
			if (softwareTO.getSearchCount() == 0) {
				softwareList = criteria.list();
			} else {
				criteria.setFirstResult(softwareTO.getFirstResult());
				criteria.setMaxResults(softwareTO.getTableSize());
				softwareList = criteria.list();
			}
			return softwareList;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. SoftwareDAOImpl:searchSoftware", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. SoftwareDAOImpl:searchSoftware", he);
		}
	}
	
	@Override
	public List<SoftwareTO> searchSoftware(SoftwareTO softwareTO) throws CMMException {
	
		Session session = null;
		List<SoftwareTO> softwareList = new ArrayList<>();
		session = getSession();
		Criteria criteria = session.createCriteria(SoftwareTO.class, "software");
		criteria.setFetchMode("SoftwareconfigTO", FetchMode.JOIN);
		if (!"".equalsIgnoreCase(softwareTO.getName()) && !(softwareTO.getName() == null)) {
			criteria.add(Restrictions.like("software.name", "%" + softwareTO.getName() + "%"));
		}
		if (!"".equalsIgnoreCase(softwareTO.getType()) && !(softwareTO.getType() == null)) {
			String softwareType = softwareTO.getType().replace("_", "/_");
			criteria.add(Restrictions.like("software.type", "%" + softwareType + "%"));
		}
		if (!"".equalsIgnoreCase(softwareTO.getModel()) && !(softwareTO.getModel() == null)) {
			criteria.add(Restrictions.like("software.model", "%" + softwareTO.getModel() + "%"));
		}
		if (!"".equalsIgnoreCase(softwareTO.getManufacturer()) && !(softwareTO.getManufacturer() == null)) {
			criteria.add(Restrictions.like("software.manufacturer", "%" + softwareTO.getManufacturer() + "%"));
		}
		try {
			if (softwareTO.getSearchCount() == 0) {
				softwareList = criteria.list();
			} else {
				criteria.setFirstResult(softwareTO.getFirstResult());
				criteria.setMaxResults(softwareTO.getTableSize());
				softwareList = criteria.list();
			}
			return softwareList;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. SoftwareDAOImpl:searchSoftware", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. SoftwareDAOImpl:searchSoftware", he);
		}
	}
	
	@Override
	public List<StatusTO> fetchSoftwareStatusList(Long entityId) throws CMMException {
	
		try {
			return (List<StatusTO>) getHibernateTemplate().find("from StatusTO where entityId =?", entityId);
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. SoftwareDAOImpl:fetchSoftwareStatusList", dae);
		}
	}
	
	@Override
	public SoftwareTO fetchSoftwareVersionDetails(Long id) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			SoftwareTO softwaredetails = new SoftwareTO();
			SoftwareconfigTO softwareconfigTO = (SoftwareconfigTO) session.createQuery("from SoftwareconfigTO where id = :softConfigTOId").setLong("softConfigTOId", id).uniqueResult();
			softwaredetails.getSoftwareconfigs().add(softwareconfigTO);
			softwaredetails.setId(softwareconfigTO.getSoftware().getId());
			softwaredetails.setName(softwareconfigTO.getSoftware().getName());
			softwaredetails.setManufacturer(softwareconfigTO.getSoftware().getManufacturer());
			softwaredetails.setModel(softwareconfigTO.getSoftware().getModel());
			softwaredetails.setType(softwareconfigTO.getSoftware().getType());
			softwaredetails.setSoftwareconfigsId(softwareconfigTO.getId());
			softwaredetails.setVersion(softwareconfigTO.getVersion());
			return softwaredetails;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.SoftwareDAOImpl:fetchSoftwareVersionDetails", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.SoftwareDAOImpl:fetchSoftwareVersionDetails", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<NolioProcessParametersTO> getSoftwareProperties(Long id) throws CMMException {
	
		List<NolioProcessParametersTO> nolioProcessParametersTOs = new ArrayList<NolioProcessParametersTO>();
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(ActivitySoftwareMappingTO.class, "activitysoftware");
			criteria.add(Restrictions.eq("activitysoftware.softwareconfigTO.id", id));
			criteria.add(Restrictions.eq("activitysoftware.caReleaseActivityTO.activityId", 1L));
			List<ActivitySoftwareMappingTO> activitySoftwareMappingTO = (List<ActivitySoftwareMappingTO>) getHibernateTemplate().findByCriteria(criteria);
			if ((activitySoftwareMappingTO != null) && !activitySoftwareMappingTO.isEmpty()) {
				DetachedCriteria criteria1 = DetachedCriteria.forClass(CAActivityProcessOrderTO.class, "activityProcessOrderTO");
				criteria1.add(Restrictions.eq("activityProcessOrderTO.activitySoftwareMappingTO.activitySoftwareMapId", activitySoftwareMappingTO.get(0).getActivitySoftwareMapId()));
				List<CAActivityProcessOrderTO> activityProcessOrderTO = (List<CAActivityProcessOrderTO>) getHibernateTemplate().findByCriteria(criteria1);
				if ((activityProcessOrderTO != null) && !activityProcessOrderTO.isEmpty()) {
					for (CAActivityProcessOrderTO temp : activityProcessOrderTO) {
						DetachedCriteria criteria2 = DetachedCriteria.forClass(NolioProcessSoftwareMapping.class, "nolioProcessSoftwareMapping");
						criteria2.add(Restrictions.eq("nolioProcessSoftwareMapping.softwareProcessMappingId", temp.getNolioProcessSoftwareMapping().getSoftwareProcessMappingId()));
						List<NolioProcessSoftwareMapping> nolioProcessSoftwareMapping = (List<NolioProcessSoftwareMapping>) getHibernateTemplate().findByCriteria(criteria2);
						for (NolioProcessParametersTO nolioProcessParametersTO : nolioProcessSoftwareMapping.get(0).getNolioProcess().getNolioProcessParameters()) {
							nolioProcessParametersTOs.add(nolioProcessParametersTO);
						}
					}
				}
			}
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.SoftwareDAOImpl:getSoftwareProperties", dae);
		}
		return nolioProcessParametersTOs;
	}
	
	@Override
	public List<Long> getZabbixTemplatesForSoftware(Long softwareConfigId) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			List<Long> templateIds = session.createCriteria(ZabbixSoftwareMappingTO.class).add(Restrictions.eq("softwareConfigId", softwareConfigId)).setProjection(Projections.property("templateid")).list();
			if ((templateIds == null) || (templateIds.size() < 0)) {
				throw new CMMException("Problem encountered. SoftwareDAOImpl-->getZabbixTemplatesForSoftware. Cannot fetch Zabbix templates for softwareConfigId :: " + softwareConfigId);
			}
			return templateIds;
		} catch (DataAccessException dae) {
			throw new CMMException("Error in fetching templates for softwareConfigId " + softwareConfigId, dae);
		} catch (HibernateException he) {
			throw new CMMException("Can not fetch data from database for softwareConfigId", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public boolean isSoftwarePresent(String strSoftwareName, String Version) throws CMMException {
	
		boolean isPresent = false;
		try {
			List<SoftwareconfigTO> softwareconfigTO = (List<SoftwareconfigTO>) getHibernateTemplate().find("SELECT sc FROM SoftwareconfigTO sc ,SoftwareTO s  where s.name=?  AND s.id=sc.deviceId AND sc.version=?", strSoftwareName, Version);
			if (!softwareconfigTO.isEmpty()) {
				isPresent = true;
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. SoftwareDAOImpl:fetchSoftwareStatusList", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. SoftwareDAOImpl:fetchSoftwareStatusList", he);
		}
		return isPresent;
	}
	
	@Override
	public List<ParameterTO> getAllParameters() throws CMMException {
	
		try {
			List<ParameterTO> parametersList = (List<ParameterTO>) getHibernateTemplate().find("from ParameterTO");
			if (parametersList == null) {
				logger.debug("No record found in database.");
				throw new CMMException("No record found.");
			}
			return parametersList;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. getAllParameters : ", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. getAllParameters : ", he);
		}
	}
	
	@Override
	public SoftwareconfigTO fetchSoftwareDetails(Long softwareId, String version) throws CMMException {
	
		try {
			SoftwareconfigTO softwareConfTO = new SoftwareconfigTO();
			List<SoftwareconfigTO> softwaredetails = (List<SoftwareconfigTO>) getHibernateTemplate().find("from SoftwareconfigTO where deviceId =? AND version = ?", softwareId, version);
			if ((softwaredetails != null) && !softwaredetails.isEmpty()) {
				softwareConfTO = softwaredetails.get(0);
			}
			return softwareConfTO;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. SoftwareDAOImpl:fetchSoftwareDetails", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. SoftwareDAOImpl:fetchSoftwareDetails", he);
		}
	}
	
	@Override
	public boolean isSoftwarePresentUpdate(String strSoftwareName, String Version, Long id) throws CMMException {
	
		boolean isPresent = false;
		try {
			List<SoftwareconfigTO> softwareconfigTO = (List<SoftwareconfigTO>) getHibernateTemplate().find("SELECT sc FROM SoftwareconfigTO sc ,SoftwareTO s  where s.name=?  AND s.id=sc.deviceId AND sc.version=? AND s.id <> ?", strSoftwareName, Version, id);
			if (!softwareconfigTO.isEmpty()) {
				isPresent = true;
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. SoftwareDAOImpl:fetchSoftwareStatusList", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. SoftwareDAOImpl:fetchSoftwareStatusList", he);
		}
		return isPresent;
	}
	
	@Override
	public Long removeSoftwarePropertyRow(Long softwareConfigId) throws CMMException {
	
		try {
			String Query = "FROM SoftwareTemplatePropertyTO softwaretemplate where softwaretemplate.softwareconfigTO.id = " + softwareConfigId + ")";
			List<SoftwareTemplatePropertyTO> softwareProperty = (List<SoftwareTemplatePropertyTO>) getHibernateTemplate().find(Query);
			for (SoftwareTemplatePropertyTO temp : softwareProperty) {
				getHibernateTemplate().delete(temp);
			}
			return 1L;
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. SoftwareDAOImpl:removeSoftwarePropertyRow", dae);
		}
	}
	
	void templateFunction(Set<SoftwareTemplatePropertyTO> softwareTemplatePropertySet) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			Transaction tx = session.beginTransaction();
			for (SoftwareTemplatePropertyTO sto : softwareTemplatePropertySet) {
				if (sto.getId() != null) {
					SoftwareTemplatePropertyTO softTO = (SoftwareTemplatePropertyTO) getHibernateTemplate().find("from SoftwareTemplatePropertyTO where id=? AND SOFTWARECONFIG_id=?", sto.getId(), sto.getSofwareTemplateId()).get(0);
					softTO.setSofwareTemplateId(sto.getSofwareTemplateId());
					getHibernateTemplate().saveOrUpdate(softTO);
				}
			}
			session.flush();
			session.clear();
			tx.commit();
		} catch (Exception ex) {
			LOG.error(ex);
			throw new CMMException("Problem encountered. SoftwareDAOImpl:removeSoftwarePropertyRow", ex);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<Long> getpropertydetails(Long softwareconfigsId) {
	
		List<Long> tempIds = new ArrayList<Long>();
		try {
			tempIds = (List<Long>) getHibernateTemplate().find("select s.id from SoftwareTemplatePropertyTO s WHERE softwareconfigTO.id = ?", softwareconfigsId);
		} catch (Exception e) {
			LOG.error("Error in getpropertydetails", e);
		}
		return tempIds;
	}
	
	@Override
	public List<Long> searchSoftwareForSoftwareInstallation(Long selectedEnvironment, Long serverGroup) throws CMMException {
	
		List<Long> softwareConfigIds = new ArrayList<Long>(0);
		try {
			softwareConfigIds = (List<Long>) getHibernateTemplate().find("select  mappedSoftwareId from EnvironmentDetailsTO where environment.id=? AND serverGroup=? AND installationRequired=?", selectedEnvironment, serverGroup, CMMConstants.Framework.ServiceFlag.INSTALLATION_REQUIRED_FLAG);
		} catch (Exception e) {
			LOG.error("Error in searchSoftwareForSoftwareInstallation", e);
		}
		return softwareConfigIds;
	}
	
	@Override
	public List<EnvironmentDetailsTO> searchSoftwareForSoftwaresInstallation(Long selectedEnvironment, Long serverGroup) throws CMMException {
	
		List<EnvironmentDetailsTO> EnvDetailsTOList = new ArrayList<EnvironmentDetailsTO>(0);
		try {
			EnvDetailsTOList = (List<EnvironmentDetailsTO>) getHibernateTemplate().find("from EnvironmentDetailsTO where environment.id=? AND serverGroup=? AND installationRequired=?", selectedEnvironment, serverGroup, CMMConstants.Framework.ServiceFlag.INSTALLATION_REQUIRED_FLAG);
		} catch (Exception e) {
			LOG.error(e);
			throw new CMMException("Problem encountered. SoftwareDAOImpl:searchSoftwareForSoftwaresInstallation", e);
		}
		return EnvDetailsTOList;
	}
	
	@Override
	public List<String> getDetailsForExistingSoftware(Long softwareId) throws CMMException {
	
		try {
			List<String> softwareList = new ArrayList<String>();
			List<Object[]> obj = (List<Object[]>) getHibernateTemplate().find("select s.manufacturer,s.model,s.type from SoftwareTO s where s.id=?", softwareId);
			for (Object[] temp : obj) {
				softwareList.add(temp[0].toString());
				softwareList.add(temp[1].toString());
				softwareList.add(temp[2].toString());
			}
			return softwareList;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. SoftwareDAOImpl:getAllSoftwares", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. SoftwareDAOImpl:getAllSoftwares", he);
		}
	}
	
	@Override
	public Long getSoftwareIdByConfigId(Long softwareconfigsId) throws CMMException {
	
		Long softId = 0L;
		List<Long> obj = (List<Long>) getHibernateTemplate().find("select s.deviceId from SoftwareconfigTO s where s.id= ?", softwareconfigsId);
		for (Long temp : obj) {
			softId = temp;
		}
		return softId;
	}
	
	@Override
	public List<ParameterTO> getAttributesForSoftware() throws CMMException {
	
		List<ParameterTO> paramTOList = new ArrayList<ParameterTO>(0);
		try {
			paramTOList = (List<ParameterTO>) getHibernateTemplate().find("from ParameterTO where type=?", CMMConstants.Framework.GlobalParameters.ATTRIBUTE_TYPE_SOFTWARE);
		} catch (Exception e) {
			LOG.error(e);
			throw new CMMException("Problem encountered. SoftwareDAOImpl:searchSoftwareForSoftwaresInstallation", e);
		}
		return paramTOList;
	}
	
	@Override
	public ParameterTO getParam(Long paramId) throws CMMException {
	
		ParameterTO paramTO = null;
		try {
			List<ParameterTO> paramList = (List<ParameterTO>) getHibernateTemplate().find("from ParameterTO where id=?", paramId);
			if ((paramList != null) && !paramList.isEmpty()) {
				paramTO = paramList.get(0);
			}
		} catch (Exception e) {
			LOG.error(e);
			throw new CMMException("Problem encountered. SoftwareDAOImpl:getParam", e);
		}
		return paramTO;
	}
	
	@Override
	public List<SoftwareTemplatePropertyTO> getSoftwareTempProp(Long softConfID) throws CMMException {
	
		List<SoftwareTemplatePropertyTO> softTempPropTOList = null;
		try {
			softTempPropTOList = (List<SoftwareTemplatePropertyTO>) getHibernateTemplate().find("from SoftwareTemplatePropertyTO where softwareConfigTO.id=?", softConfID);
		} catch (Exception e) {
			LOG.error(e);
			throw new CMMException("Problem encountered. SoftwareDAOImpl:getSoftwareTempProp", e);
		}
		return softTempPropTOList;
	}
	
	@Override
	public boolean isSoftwareVersionPresent(String version, Long selectedSoftwareId, Long deviceid) throws CMMException {
	
		boolean isPresent = false;
		try {
			List<SoftwareconfigTO> softwareconfigTO = (List<SoftwareconfigTO>) getHibernateTemplate().find("SELECT sc FROM SoftwareconfigTO sc ,SoftwareTO s  where  s.id=sc.deviceId AND sc.version=? AND sc.id <> ? AND sc.deviceId = ?", version, selectedSoftwareId, deviceid);
			if (!softwareconfigTO.isEmpty()) {
				isPresent = true;
			}
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. SoftwareDAOImpl:isSoftwarePresent", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. SoftwareDAOImpl:isSoftwarePresent", he);
		}
		return isPresent;
	}
}
