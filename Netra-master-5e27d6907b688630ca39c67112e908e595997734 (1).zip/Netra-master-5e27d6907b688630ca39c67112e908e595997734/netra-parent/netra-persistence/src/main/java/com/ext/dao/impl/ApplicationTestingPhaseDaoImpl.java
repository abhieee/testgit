package com.ext.dao.impl;

import java.util.ArrayList;
import java.util.List;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.ApplicationTestingPhaseDao;
import com.framework.exception.CMMException;
import com.framework.to.ApplicationReleasePhaseTO;
import com.framework.to.EnvironmentTO;
import com.framework.to.TestingPhaseTO;

public class ApplicationTestingPhaseDaoImpl extends HibernateDaoSupport implements ApplicationTestingPhaseDao {
	
	@Override
	public boolean addPhase(TestingPhaseTO testingPhaseTO) throws CMMException {
	
		List<TestingPhaseTO> result = new ArrayList<TestingPhaseTO>();
		try {
			result = (List<TestingPhaseTO>) getHibernateTemplate().find("from TestingPhaseTO where PhaseName=?", testingPhaseTO.getName());
			if (result.isEmpty()) {
				testingPhaseTO.setId(10L);
				getHibernateTemplate().save(testingPhaseTO);
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			logger.error(e);
			throw new CMMException("Problem encountered. ApplicationTestingPhaseDaoImpl : addPhase", e);
		}
	}
	
	@Override
	public List<TestingPhaseTO> searchPhase(TestingPhaseTO testingPhaseTO) throws CMMException {
	
		DetachedCriteria criteria = DetachedCriteria.forClass(TestingPhaseTO.class);
		try {
			boolean check = org.springframework.util.StringUtils.hasText(testingPhaseTO.getName());
			if (check) {
				criteria.add(Restrictions.like("name", "%" + testingPhaseTO.getName() + "%"));
			}
			if (testingPhaseTO.getSearchCount() == 0) {
				return (List<TestingPhaseTO>) getHibernateTemplate().findByCriteria(criteria);
			}
		} catch (Exception e) {
			logger.error(e);
			throw new CMMException("Problem encountered. ApplicationTestingPhaseDaoImpl : searchPhase", e);
		}
		return (List<TestingPhaseTO>) getHibernateTemplate().findByCriteria(criteria, testingPhaseTO.getFirstResult(), testingPhaseTO.getTableSize());
	}
	
	@Override
	public TestingPhaseTO loadPhase(TestingPhaseTO testingPhaseTO) {
	
		List<TestingPhaseTO> result = new ArrayList<TestingPhaseTO>();
		TestingPhaseTO testphase = new TestingPhaseTO();
		try {
			result = (List<TestingPhaseTO>) getHibernateTemplate().find("from TestingPhaseTO where id=?", testingPhaseTO.getId());
			for (TestingPhaseTO temp : result) {
				temp.getName();
				testphase.setId(temp.getId());
				testphase.setName(temp.getName());
				testphase.setColorCode(temp.getColorCode());
			}
		} catch (Exception e) {
			logger.error("Problem encountered. ApplicationTestingPhaseDaoImpl : loadPhase", e);
		}
		return testphase;
	}
	
	@Override
	public boolean editPhase(TestingPhaseTO testingPhaseTO) {
	
		TestingPhaseTO testphase = new TestingPhaseTO();
		testphase = (TestingPhaseTO) getHibernateTemplate().find("from TestingPhaseTO a where a.id=?", testingPhaseTO.getId()).get(0);
		testphase.setName(testingPhaseTO.getName());
		testphase.setColorCode(testingPhaseTO.getColorCode());
		getHibernateTemplate().update(testphase);
		return true;
	}
	
	@Override
	public List<TestingPhaseTO> getAllTestingPhases(Long applicationId) throws CMMException {
	
		List<TestingPhaseTO> testingPhaseList = new ArrayList<TestingPhaseTO>(0);
		try {
			String hql = String.format("Select a from ApplicationReleasePhaseTO a where a.applicationId=%d and a.stat in('Y')", applicationId);
			List<ApplicationReleasePhaseTO> applicationPhaseList = (List<ApplicationReleasePhaseTO>) getHibernateTemplate().find(hql);
			for (ApplicationReleasePhaseTO temp : applicationPhaseList) {
				testingPhaseList.add(temp.getTestingPhase());
			}
		} catch (Exception e) {
			logger.error(e);
			throw new CMMException("Problem encountered. ApplicationTestingPhaseDaoImpl : getAllTestingPhases", e);
		}
		return testingPhaseList;
	}
	
	@Override
	public List<TestingPhaseTO> getAllPhases() throws CMMException {
	
		List<TestingPhaseTO> testingPhaseList = new ArrayList<TestingPhaseTO>(0);
		try {
			testingPhaseList = (List<TestingPhaseTO>) getHibernateTemplate().find("from TestingPhaseTO");
		} catch (Exception e) {
			logger.error(e);
			throw new CMMException("Problem encountered. ApplicationTestingPhaseDaoImpl : getAllPhases", e);
		}
		return testingPhaseList;
	}
	
	@Override
	public List<TestingPhaseTO> getPhaseIdFromName(String name) throws CMMException {
	
		List<TestingPhaseTO> testingPhaseList = new ArrayList<TestingPhaseTO>(0);
		try {
			testingPhaseList = (List<TestingPhaseTO>) getHibernateTemplate().find("from TestingPhaseTO t where t.name=?", name);
		} catch (Exception e) {
			logger.error(e);
			throw new CMMException("Problem encountered. ApplicationTestingPhaseDaoImpl : getPhaseIdFromName", e);
		}
		return testingPhaseList;
	}
	
	@Override
	public boolean checkEnvPhaseMapping(Long envId, Long phaseId) throws CMMException {
	
		List<EnvironmentTO> envTO = new ArrayList<EnvironmentTO>(0);
		try {
			envTO = (List<EnvironmentTO>) getHibernateTemplate().find("from EnvironmentTO t inner join t.environmentPhaseTO ep where t.id=? and ep.id=?", envId, phaseId);
			if (envTO.isEmpty()) {
				return false;
			}
		} catch (Exception e) {
			logger.error(e);
			throw new CMMException("Problem encountered. ApplicationTestingPhaseDaoImpl : checkEnvPhaseMapping", e);
		}
		return true;
	}
}
