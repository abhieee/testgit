/**
 *
 */
package com.ext.dao.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.exception.ConstraintViolationException;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.ApplicationReleaseSourceCodeDAO;
import com.framework.exception.CMMException;
import com.framework.nolio.to.NolioProcessParametersTO;
import com.framework.to.ApplicationProfileDetailsTO;
import com.framework.to.ApplicationProfileMappingTO;
import com.framework.to.ApplicationProfileSoftwareParamertsTO;
import com.framework.to.ApplicationProfileTO;
import com.framework.to.ApplicationReleaseSourcecodeTO;
import com.framework.to.SoftwareTO;

/**
 * @author 460650
 */
public class ApplicationReleaseSourceCodeDAOImpl extends HibernateDaoSupport implements ApplicationReleaseSourceCodeDAO {
	
	@Override
	public List<ApplicationReleaseSourcecodeTO> getAppReleaseSourceCodeByRequestId(long requestId, long softwareConfigId) throws CMMException {
	
		List<ApplicationReleaseSourcecodeTO> applicationReleaseSourceCodeList;
		try {
			applicationReleaseSourceCodeList = (List<ApplicationReleaseSourcecodeTO>) getHibernateTemplate().find("from ApplicationReleaseSourcecodeTO where RequestId=? and softwareConfigId=?", requestId, softwareConfigId);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseSourceCodeDAOImpl : getAppReleaseSourceCodeByRequestId ", dae);
		} catch (HibernateException e) {
			logger.error(e);
			throw new CMMException("Problem encountered. ApplicationReleaseSourceCodeDAOImpl : getAppReleaseSourceCodeByRequestId ", e);
		}
		return applicationReleaseSourceCodeList;
	}
	
	@Override
	public List<ApplicationReleaseSourcecodeTO> getAppReleaseSourceCodeByReleaseId(long applicationReleaseId) throws CMMException {
	
		List<ApplicationReleaseSourcecodeTO> applicationReleaseSourceCodeList;
		try {
			applicationReleaseSourceCodeList = (List<ApplicationReleaseSourcecodeTO>) getHibernateTemplate().find("from ApplicationReleaseSourcecodeTO where applicationReleaseId=?", applicationReleaseId);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseSourceCodeDAOImpl : getAppReleaseSourceCodeByReleaseId ", dae);
		} catch (HibernateException e) {
			logger.error(e);
			throw new CMMException("Problem encountered. ApplicationReleaseSourceCodeDAOImpl : getAppReleaseSourceCodeByReleaseId ", e);
		}
		return applicationReleaseSourceCodeList;
	}
	
	@Override
	public List<ApplicationReleaseSourcecodeTO> getAppReleaseSourceCodeByReleaseAndPhaseId(long applicationReleaseId, long phaseId) throws CMMException {
	
		List<ApplicationReleaseSourcecodeTO> applicationReleaseSourceCodeList;
		try {
			applicationReleaseSourceCodeList = (List<ApplicationReleaseSourcecodeTO>) getHibernateTemplate().find("from ApplicationReleaseSourcecodeTO where applicationReleaseId=? and selectedTestingPhase=?", applicationReleaseId, phaseId);
			if (applicationReleaseSourceCodeList.isEmpty()) {
				applicationReleaseSourceCodeList = (List<ApplicationReleaseSourcecodeTO>) getHibernateTemplate().find("from ApplicationReleaseSourcecodeTO where applicationReleaseId=? and selectedTestingPhase=?", applicationReleaseId, 0L);
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseSourceCodeDAOImpl : getAppReleaseSourceCodeByReleaseAndPhaseId ", dae);
		} catch (HibernateException e) {
			logger.error(e);
			throw new CMMException("Problem encountered. ApplicationReleaseSourceCodeDAOImpl : getAppReleaseSourceCodeByReleaseAndPhaseId ", e);
		}
		return applicationReleaseSourceCodeList;
	}
	
	public ApplicationProfileTO editProfile(ApplicationProfileTO applicationProfileTO) throws CMMException {
	
		try {
			ApplicationProfileTO editEnvNew = (ApplicationProfileTO) getHibernateTemplate().find("from ApplicationProfileTO a where a.id=?", applicationProfileTO.getId()).get(0);
			editEnvNew.setName(applicationProfileTO.getName());
			editEnvNew.setStatus(applicationProfileTO.getStatus());
			editEnvNew.setModifiedbyId(applicationProfileTO.getModifiedbyId());
			editEnvNew.setModifiedbyDate(applicationProfileTO.getModifiedbyDate());
			List<ApplicationProfileDetailsTO> appProdetList = new ArrayList<ApplicationProfileDetailsTO>(0);
			List<ApplicationProfileDetailsTO> appProdetList3 = new ArrayList<ApplicationProfileDetailsTO>(0);
			List<ApplicationProfileMappingTO> appProMapList = new ArrayList<ApplicationProfileMappingTO>(0);
			for (ApplicationProfileMappingTO appProMap : editEnvNew.getApplicationProfileMapping()) {
				appProMapList.add(appProMap);
			}
			for (ApplicationProfileDetailsTO appProObj : editEnvNew.getProfileDetails()) {
				appProdetList.add(appProObj);
			}
			editEnvNew.getProfileDetails().clear();
			List<ApplicationProfileSoftwareParamertsTO> appProSoftParaToList = new ArrayList<ApplicationProfileSoftwareParamertsTO>(0);
			List<ApplicationProfileSoftwareParamertsTO> appProSoftParaToList1 = new ArrayList<ApplicationProfileSoftwareParamertsTO>(0);
			List<ApplicationProfileSoftwareParamertsTO> appProSoftParaToList2 = new ArrayList<ApplicationProfileSoftwareParamertsTO>(0);
			List<ApplicationProfileSoftwareParamertsTO> appProSoftParaToListFinalForAdd = new ArrayList<ApplicationProfileSoftwareParamertsTO>(0);
			for (ApplicationProfileDetailsTO details : applicationProfileTO.getProfileDetails()) {
				if (details.getSoftwareList().isEmpty()) {
					ApplicationProfileDetailsTO temp = new ApplicationProfileDetailsTO();
					temp.setHardwareId(details.getHardwareId());
					temp.setServerGroup(details.getServerGroup());
					temp.setProfile(editEnvNew);
					editEnvNew.getProfileDetails().add(temp);
				} else {
					for (SoftwareTO softTo : details.getSoftwareList()) {
						ApplicationProfileDetailsTO temp = new ApplicationProfileDetailsTO();
						temp.setHardwareId(details.getHardwareId());
						temp.setMappedSoftwareId(softTo.getSoftwareconfigsId());
						temp.setServerGroup(details.getServerGroup());
						List<NolioProcessParametersTO> parameters = details.getSoftwarePropertiesMapping().get(softTo.getId());
						Set<ApplicationProfileSoftwareParamertsTO> set = new HashSet<ApplicationProfileSoftwareParamertsTO>();
						if (parameters != null) {
							for (NolioProcessParametersTO temp1 : parameters) {
								ApplicationProfileSoftwareParamertsTO applicationProfileSoftwareParamertsTO = new ApplicationProfileSoftwareParamertsTO();
								applicationProfileSoftwareParamertsTO.setPropertyId(temp1.getParameterId());
								applicationProfileSoftwareParamertsTO.setPropertyValue(temp1.getParameterValue());
								applicationProfileSoftwareParamertsTO.setApplicationProfileDetails(temp);
								set.add(applicationProfileSoftwareParamertsTO);
							}
						}
						temp.setApplicationProfileSoftwareParamertsTOs(set);
						temp.setProfile(editEnvNew);
						editEnvNew.getProfileDetails().add(temp);
					}
				}
			}
			for (ApplicationProfileDetailsTO appProObj : appProdetList) {
				for (ApplicationProfileSoftwareParamertsTO parameter : appProObj.getApplicationProfileSoftwareParamertsTOs()) {
					appProSoftParaToList.add(parameter);
				}
			}
			getHibernateTemplate().update(editEnvNew);
			List<ApplicationProfileMappingTO> profMapingList = new ArrayList<ApplicationProfileMappingTO>();
			profMapingList = (List<ApplicationProfileMappingTO>) getHibernateTemplate().find("from ApplicationProfileMappingTO where profileId =?", applicationProfileTO.getId());
			getHibernateTemplate().deleteAll(profMapingList);
			for (Long app : applicationProfileTO.getDefinedApplications()) {
				ApplicationProfileMappingTO appProfMappingTO = new ApplicationProfileMappingTO();
				appProfMappingTO.setApplicationId(app);
				appProfMappingTO.setProfileId(editEnvNew.getId());
				getHibernateTemplate().save(appProfMappingTO);
			}
			List<ApplicationProfileDetailsTO> appProdetList1 = appProdetList;
			List<ApplicationProfileDetailsTO> appProdetList2 = (List<ApplicationProfileDetailsTO>) getHibernateTemplate().find("from ApplicationProfileDetailsTO where profileId =?", applicationProfileTO.getId());
			for (ApplicationProfileDetailsTO appProDet1 : appProdetList1) {
				for (ApplicationProfileDetailsTO appProDet2 : appProdetList2) {
					if (appProDet1.getHardwareId().equals(appProDet2.getHardwareId()) && appProDet1.getMappedSoftwareId().equals(appProDet2.getMappedSoftwareId()) && appProDet1.getServerGroup().equals(appProDet2.getServerGroup())) {
						appProDet2.setOldAppProDetId(appProDet1.getId());
						appProdetList2.remove(appProDet2);
						appProdetList3.add(appProDet2);
					}
					break;
				}
			}
			for (ApplicationProfileSoftwareParamertsTO para : appProSoftParaToList) {
				for (ApplicationProfileDetailsTO appPro : appProdetList3) {
					if (para.getApplicationProfileDetails().getId().equals(appPro.getOldAppProDetId())) {
						ApplicationProfileDetailsTO appProObj = new ApplicationProfileDetailsTO();
						appProObj.setId(appPro.getId());
						para.setApplicationProfileDetails(appProObj);
						appProSoftParaToList1.add(para);
						break;
					}
				}
			}
			for (ApplicationProfileSoftwareParamertsTO appProSoft : appProSoftParaToList) {
				Long applicationId = null;
				Long profileId = null;
				Long appProMapId = appProSoft.getApplicationProfileMapId();
				for (ApplicationProfileMappingTO appProMap : appProMapList) {
					Long appProMapId1 = appProMap.getId();
					appProMapId.compareTo(appProMapId1);
					if (appProMapId.compareTo(appProMapId1) == 0) {
						applicationId = appProMap.getApplicationId();
						profileId = appProMap.getProfileId();
					}
				}
				ApplicationProfileMappingTO appProMapObj = (ApplicationProfileMappingTO) getHibernateTemplate().find("from ApplicationProfileMappingTO where profileId =? and applicationId=?", profileId, applicationId).get(0);
				appProSoft.setNewAppProMapId(appProMapObj.getId());
				appProSoftParaToList2.add(appProSoft);
			}
			for (ApplicationProfileSoftwareParamertsTO appProSof2 : appProSoftParaToList2) {
				for (ApplicationProfileSoftwareParamertsTO appProSof1 : appProSoftParaToList1) {
					if (appProSof2.getApplicationProfileMapId().equals(appProSof1.getApplicationProfileMapId())) {
						appProSof1.setApplicationProfileMapId(appProSof2.getNewAppProMapId());
						appProSoftParaToListFinalForAdd.add(appProSof1);
						break;
					}
				}
			}
			for (ApplicationProfileSoftwareParamertsTO para : appProSoftParaToListFinalForAdd) {
				getHibernateTemplate().save(para);
			}
			return editEnvNew;
		} catch (DataAccessException e) {
			logger.error(e);
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : editProfile", e);
		} catch (HibernateException e) {
			logger.error(e);
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : editProfile", e);
		} catch (Exception e) {
			logger.error(e);
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : editProfile", e);
		}
	}
	
	@Override
	public boolean saveNetraPathTODB(String nolioServerPath, Long id) throws CMMException {
	
		Session session = getSession();
		try {
			String hql = "update ApplicationReleaseSourcecodeTO set tempArtifactPath = :tempArtifactPath where id = :id";
			Query q = session.createQuery(hql);
			q.setParameter("tempArtifactPath", nolioServerPath);
			q.setParameter("id", id);
			Long result = (long) q.executeUpdate();
			if (result == 1L) {
				return true;
			}
			return false;
		} catch (ConstraintViolationException ce) {
			logger.error(ce);
			throw new CMMException("Problem encountered. ApplicationReleaseSourceCodeDAOImpl: saveNetraPathTODB", ce);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseSourceCodeDAOImpl: saveNetraPathTODB", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. ApplicationReleaseSourceCodeDAOImpl: saveNetraPathTODB", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public boolean saveNetraNexusPath(String netraNexusPath, Long sourceCodeId) throws CMMException {
	
		Session session = getSession();
		try {
			String hql = "update ApplicationReleaseSourcecodeTO set netraNexusPath = :netraNexusPath where id = :sourceCodeId";
			Query q = session.createQuery(hql);
			q.setParameter("netraNexusPath", netraNexusPath);
			q.setParameter("sourceCodeId", sourceCodeId);
			Long result = (long) q.executeUpdate();
			if (result == 1L) {
				return true;
			}
			return false;
		} catch (ConstraintViolationException ce) {
			logger.error(ce);
			throw new CMMException("Problem encountered. ApplicationReleaseSourceCodeDAOImpl: saveNetraPathTODB", ce);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseSourceCodeDAOImpl: saveNetraPathTODB", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. ApplicationReleaseSourceCodeDAOImpl: saveNetraPathTODB", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
}
