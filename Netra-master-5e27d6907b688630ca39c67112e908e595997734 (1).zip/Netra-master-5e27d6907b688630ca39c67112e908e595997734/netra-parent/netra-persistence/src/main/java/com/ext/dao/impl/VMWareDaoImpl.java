package com.ext.dao.impl;

import java.util.ArrayList;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.hibernate.exception.ConstraintViolationException;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.VMWareDAO;
import com.framework.common.CMMConstants;
import com.framework.exception.CMMException;
import com.framework.to.MachineTemplateBareMetalTO;
import com.framework.to.MachineTemplateOSTO;
import com.framework.to.MachineTemplateTO;
import com.framework.to.MachineVMWareTO;
import com.framework.to.PlatformMasterTO;
import com.framework.to.PlatformTemplateBareMetalTO;
import com.framework.to.PlatformTemplateOSTO;
import com.framework.to.PlatformTemplateTO;
import com.framework.to.PlatformTypeTO;
import com.framework.to.StatusTO;
import com.framework.to.TemplateVMWareTO;
import com.framework.to.TemplatesTO;
import com.framework.to.VSphereDetailsTO;

public class VMWareDaoImpl extends HibernateDaoSupport implements VMWareDAO {
	
	@Override
	public void addVMTemplates(PlatformTemplateTO platformTemplatesTO, MachineTemplateTO machineTemplateTO, String vmTemplateName) throws CMMException {
	
		try {
			TemplateVMWareTO templateVMWareTO = new TemplateVMWareTO();
			templateVMWareTO.setVmTemplateName(vmTemplateName);
			templateVMWareTO.setPlatformTemplate(platformTemplatesTO);
			platformTemplatesTO.getPlatformTemplateVMware().add(templateVMWareTO);
			Long platformTemplateId = (Long) getHibernateTemplate().save(platformTemplatesTO);
			machineTemplateTO.setPlatformTemplateId(platformTemplateId);
			MachineVMWareTO machineVMWareTO = new MachineVMWareTO();
			machineVMWareTO.setUsername(machineTemplateTO.getUsername());
			machineVMWareTO.setPassword(machineTemplateTO.getPassword());
			machineVMWareTO.setMachineTemplate(machineTemplateTO);
			machineTemplateTO.getMachineTemplateVMware().add(machineVMWareTO);
			getHibernateTemplate().save(machineTemplateTO);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. VMWareDaoImpl : fetchPlatforms()", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. VMWareDaoImpl : fetchPlatforms()", he);
		}
	}
	
	@Override
	public Long addOSPlatformTemplate(PlatformTemplateTO platformTemplatesTO, String imageId, String imageName) throws CMMException {
	
		try {
			PlatformTemplateOSTO platformTemplateOSTO = new PlatformTemplateOSTO();
			platformTemplateOSTO.setImageId(imageId);
			platformTemplateOSTO.setImageName(imageName);
			platformTemplateOSTO.setPlatformTemplate(platformTemplatesTO);
			platformTemplatesTO.getPlatformTemplateOSTOSet().add(platformTemplateOSTO);
			Long platformTemplateId = (Long) getHibernateTemplate().save(platformTemplatesTO);
			if ((platformTemplateId == null) || (platformTemplateId < 0)) {
				throw new CMMException("Platform Template for Openatsack can not be added for imageId:: " + imageId);
			}
			return platformTemplateId;
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. VMWareDaoImpl : addOSPlatformTemplate", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. VMWareDaoImpl : addOSPlatformTemplate", he);
		}
	}
	
	@Override
	public boolean addOSMachineTemplate(MachineTemplateTO machineTemplateTO, String flavorId, String flavorType, String disk, String username, String password) throws CMMException {
	
		try {
			MachineTemplateOSTO machineTemplateOSTO = new MachineTemplateOSTO();
			machineTemplateOSTO.setFlavorId(flavorId);
			machineTemplateOSTO.setFlavorType(flavorType);
			machineTemplateOSTO.setDisk(disk);
			machineTemplateOSTO.setUsername(username);
			machineTemplateOSTO.setPassword(password);
			machineTemplateOSTO.setMachineTemplate(machineTemplateTO);
			machineTemplateTO.getMachineTemplateOSTOSet().add(machineTemplateOSTO);
			Long machineTemplateId = (Long) getHibernateTemplate().save(machineTemplateTO);
			if ((machineTemplateId == null) || (machineTemplateId < 0)) {
				throw new CMMException("Machine Template for Openatsack can not be added for flavorId:: " + flavorId);
			}
			return true;
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. VMWareDaoImpl : addOSMachineTemplate", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. VMWareDaoImpl : addOSMachineTemplate", he);
		}
	}
	
	@Override
	public List<PlatformMasterTO> fetchPlatforms() throws CMMException {
	
		List<PlatformMasterTO> platformList = new ArrayList<PlatformMasterTO>();
		try {
			platformList = (List<PlatformMasterTO>) getHibernateTemplate().find("from PlatformMasterTO");
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. VMWareDaoImpl : fetchPlatforms()", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. VMWareDaoImpl : fetchPlatforms()", he);
		}
		return platformList;
	}
	
	@Override
	public boolean checkName(PlatformTemplateTO platformTemplateTO) throws CMMException {
	
		boolean flag = false;
		try {
			List<TemplatesTO> unit = (List<TemplatesTO>) getHibernateTemplate().find("from PlatformTemplateTO where name=?", platformTemplateTO.getName());
			if (!unit.isEmpty()) {
				flag = true;
			} else {
				flag = false;
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. VMWareDaoImpl:checkName.", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. VMWareDaoImpl:checkName.", he);
		}
		return flag;
	}
	
	@Override
	public List<PlatformTypeTO> getAllPlatformTypes() throws CMMException {
	
		try {
			return (List<PlatformTypeTO>) getHibernateTemplate().find("from PlatformTypeTO");
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.VMWareDaoImpl:getAllPlatformTypes", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.VMWareDaoImpl:getAllPlatformTypes", he);
		}
	}
	
	@Override
	public List<PlatformTypeTO> getDistributionListforFamilyType(String selectedFamilyType) throws CMMException {
	
		DetachedCriteria criteria = DetachedCriteria.forClass(PlatformTypeTO.class, "platformType");
		int a = selectedFamilyType.indexOf("_");
		String value = selectedFamilyType.substring(0, a);
		String val = value + "%";
		criteria.add(Restrictions.eq("type", "Distribution"));
		criteria.add(Restrictions.like("value", val));
		return (List<PlatformTypeTO>) getHibernateTemplate().findByCriteria(criteria);
	}
	
	@Override
	public List<PlatformTypeTO> getVersionListforDistribution(String selectedDistribution) throws CMMException {
	
		DetachedCriteria criteria = DetachedCriteria.forClass(PlatformTypeTO.class, "platformType");
		int a = selectedDistribution.indexOf("_");
		String value = selectedDistribution.substring(0, a);
		String val = value + "%";
		criteria.add(Restrictions.eq("type", "Version"));
		criteria.add(Restrictions.like("value", val));
		return (List<PlatformTypeTO>) getHibernateTemplate().findByCriteria(criteria);
	}
	
	@Override
	public List<PlatformTypeTO> getPackListforVersion(String selectedVersion) throws CMMException {
	
		DetachedCriteria criteria = DetachedCriteria.forClass(PlatformTypeTO.class, "platformType");
		int a = selectedVersion.indexOf("_");
		String value = selectedVersion.substring(0, a);
		String val = value + "%";
		criteria.add(Restrictions.eq("type", "Pack"));
		criteria.add(Restrictions.like("value", val));
		return (List<PlatformTypeTO>) getHibernateTemplate().findByCriteria(criteria);
	}
	
	@Override
	public List<PlatformTemplateTO> fetchPlatformTemplateList() throws CMMException {
	
		try {
			return (List<PlatformTemplateTO>) getHibernateTemplate().find("from PlatformTemplateTO");
		} catch (DataAccessException dae) {
			throw new CMMException("Can not fetch machine details:: ", dae);
		} catch (HibernateException he) {
			throw new CMMException("Can not access database:: ", he);
		}
	}
	
	@Override
	public List<PlatformTemplateTO> searchTemplates(PlatformTemplateTO platformTemplateTO) throws CMMException {
	
		try {
			List<PlatformTemplateBareMetalTO> platformTemplateBareMetalTO = (List<PlatformTemplateBareMetalTO>) getHibernateTemplate().find("from PlatformTemplateBareMetalTO");
			List<MachineTemplateBareMetalTO> machineTemplateBareMetalTO = (List<MachineTemplateBareMetalTO>) getHibernateTemplate().find("from MachineTemplateBareMetalTO");
			List<PlatformTemplateTO> templateList = new ArrayList<PlatformTemplateTO>();
			StringBuilder Query = new StringBuilder("");
			if (platformTemplateBareMetalTO.isEmpty() || machineTemplateBareMetalTO.isEmpty()) {
				Query.append(" select p,p.name,p.family,p.distribution,p.version,p.pack,p.architecture,m.CPU,m.RAM,p.id,m.id from  PlatformTemplateTO as p , TemplateVMWareTO as v, MachineTemplateTO as m, MachineVMWareTO  as mv where v.platformTemplate.id = p.id and m.platformTemplateId = p.id and mv.machineTemplate.id = m.id and length(trim(p.name))>0 and p.status =");
				Query.append(CMMConstants.Framework.PlatformTemplateStatus.PLATFORM_TEMPLATE_AVAILABLE);
			} else {
				Query.append("select distinct p,p.name,p.family,p.distribution,p.version,p.pack,p.architecture,m.CPU,m.RAM,p.id,m.id from  PlatformTemplateTO as p, MachineTemplateTO as m where m.platformTemplateId = p.id and length(trim(p.name))>0 and p.status =");
				Query.append(CMMConstants.Framework.PlatformTemplateStatus.PLATFORM_TEMPLATE_AVAILABLE);
			}
			if (!"".equalsIgnoreCase(platformTemplateTO.getName().trim())) {
				String name = platformTemplateTO.getName();
				Query.append(" and p.name  like '%");
				Query.append(name);
				Query.append("%'");
			}
			if (!"".equalsIgnoreCase(platformTemplateTO.getFamily().trim())) {
				String familyName = platformTemplateTO.getFamily();
				Query.append(" and p.name  like '%");
				Query.append(familyName);
				Query.append("%'");
			}
			if (!"".equalsIgnoreCase(platformTemplateTO.getArchitecture().trim())) {
				Query.append(" and p.architecture  like '%");
				Query.append(platformTemplateTO.getArchitecture());
				Query.append("%'");
			}
			if (!"".equalsIgnoreCase(platformTemplateTO.getCpu().trim())) {
				Query.append(" and m.CPU  like '%");
				Query.append(platformTemplateTO.getCpu());
				Query.append("%'");
			}
			if (!"".equalsIgnoreCase(platformTemplateTO.getRam().trim())) {
				Query.append(" and m.RAM  like '%");
				Query.append(platformTemplateTO.getRam());
				Query.append("%'");
			}
			List<Object[]> obj = (List<Object[]>) getHibernateTemplate().find(Query.toString());
			for (Object a[] : obj) {
				PlatformTemplateTO temp = (PlatformTemplateTO) a[0];
				temp.setName(a[1].toString());
				temp.setFamily(a[2].toString());
				temp.setDistribution(a[3].toString());
				temp.setVersion(a[4].toString());
				if (a[5] == null) {
					temp.setPack("-");
				} else {
					temp.setPack(a[5].toString());
				}
				temp.setArchitecture(a[6].toString());
				if (a[7] == null) {
					temp.setCpu("-");
				} else {
					temp.setCpu(a[7].toString());
				}
				if (a[8] == null) {
					temp.setRam("-");
				} else {
					temp.setRam(a[8].toString());
				}
				temp.setPlatformTemplateId(a[9].toString());
				temp.setMachineTemplateId(a[10].toString());
				templateList.add(temp);
			}
			return templateList;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : searchAppProfile", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : searchAppProfile", he);
		}
	}
	
	@Override
	public List<PlatformTemplateTO> searchTemplatesForOS(PlatformTemplateTO platformTemplateTO) throws CMMException {
	
		try {
			List<PlatformTemplateTO> templateList = new ArrayList<PlatformTemplateTO>();
			StringBuilder query = new StringBuilder("");
			query.append("select p,p.name,p.family,p.distribution,p.version,p.pack,p.architecture,m.CPU,m.RAM,p.id,m.id from PlatformTemplateTO as p , PlatformTemplateOSTO as v, MachineTemplateTO as m, MachineTemplateOSTO  as mv where v.platformTemplate.id = p.id and m.platformTemplateId = p.id and mv.machineTemplate.id = m.id and p.status=?");
			if (!"".equalsIgnoreCase(platformTemplateTO.getName().trim())) {
				String name = platformTemplateTO.getName();
				query.append(" and p.name  like '%");
				query.append(name);
				query.append("%'");
			}
			if (!"".equalsIgnoreCase(platformTemplateTO.getFamily().trim())) {
				String familyName = platformTemplateTO.getFamily();
				query.append(" and p.family  like '%");
				query.append(familyName);
				query.append("%'");
			}
			if (!"".equalsIgnoreCase(platformTemplateTO.getArchitecture().trim())) {
				query.append(" and p.architecture  like '%");
				query.append(platformTemplateTO.getArchitecture());
				query.append("%'");
			}
			if (!"".equalsIgnoreCase(platformTemplateTO.getCpu().trim())) {
				query.append(" and m.CPU  like '%");
				query.append(platformTemplateTO.getCpu());
				query.append("%'");
			}
			if (!"".equalsIgnoreCase(platformTemplateTO.getRam().trim())) {
				query.append(" and m.RAM  like '%");
				query.append(platformTemplateTO.getRam());
				query.append("%'");
			}
			List<Object[]> obj = (List<Object[]>) getHibernateTemplate().find(query.toString(), CMMConstants.Framework.PlatformTemplateStatus.PLATFORM_TEMPLATE_AVAILABLE);
			for (Object a[] : obj) {
				PlatformTemplateTO temp = (PlatformTemplateTO) a[0];
				temp.setName(a[1].toString());
				temp.setFamily(a[2].toString());
				temp.setDistribution(a[3].toString());
				temp.setVersion(a[4].toString());
				if (a[5] == null) {
					temp.setPack("-");
				} else {
					temp.setPack(a[5].toString());
				}
				temp.setArchitecture(a[6].toString());
				if (a[7] == null) {
					temp.setCpu("-");
				} else {
					temp.setCpu(a[7].toString());
				}
				if (a[8] == null) {
					temp.setRam("-");
				} else {
					temp.setRam(a[8].toString());
				}
				temp.setPlatformTemplateId(a[9].toString());
				temp.setMachineTemplateId(a[10].toString());
				templateList.add(temp);
			}
			return templateList;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : searchAppProfile", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : searchAppProfile", he);
		}
	}
	
	@Override
	public List<PlatformTemplateTO> searchTemplatesForBareMetal(PlatformTemplateTO platformTemplateTO) throws CMMException {
	
		try {
			List<PlatformTemplateTO> templateList = new ArrayList<PlatformTemplateTO>();
			StringBuilder query = new StringBuilder(" select p,p.name,p.family,p.distribution,p.version,p.pack,p.architecture,m.CPU,m.RAM,p.id,m.id from  PlatformTemplateTO as p , PlatformTemplateBareMetalTO as v, MachineTemplateTO as m, MachineTemplateBareMetalTO as mv where v.platformTemplate.id = p.id and m.platformTemplateId = p.id and mv.machineTemplateTO.id = m.id ");
			if (!"".equalsIgnoreCase(platformTemplateTO.getName().trim())) {
				String name = platformTemplateTO.getName();
				query.append(" and p.name  like '%");
				query.append(name);
				query.append("%'");
			}
			if (!"".equalsIgnoreCase(platformTemplateTO.getFamily().trim())) {
				String familyName = platformTemplateTO.getFamily();
				query.append(" and p.family  like '%");
				query.append(familyName);
				query.append("%'");
			}
			if (!"".equalsIgnoreCase(platformTemplateTO.getArchitecture().trim())) {
				query.append(" and p.architecture  like '%");
				query.append(platformTemplateTO.getArchitecture());
				query.append("%'");
			}
			if (!"".equalsIgnoreCase(platformTemplateTO.getCpu().trim())) {
				query.append(" and m.CPU  like '%");
				query.append(platformTemplateTO.getCpu());
				query.append("%'");
			}
			if (!"".equalsIgnoreCase(platformTemplateTO.getRam().trim())) {
				query.append(" and m.RAM  like '%");
				query.append(platformTemplateTO.getRam());
				query.append("%'");
			}
			List<Object[]> obj = (List<Object[]>) getHibernateTemplate().find(query.toString());
			for (Object a[] : obj) {
				PlatformTemplateTO temp = (PlatformTemplateTO) a[0];
				temp.setName(a[1].toString());
				temp.setFamily(a[2].toString());
				temp.setDistribution(a[3].toString());
				temp.setVersion(a[4].toString());
				if (a[5] == null) {
					temp.setPack("-");
				} else {
					temp.setPack(a[5].toString());
				}
				temp.setArchitecture(a[6].toString());
				if (a[7] == null) {
					temp.setCpu("-");
				} else {
					temp.setCpu(a[7].toString());
				}
				if (a[8] == null) {
					temp.setRam("-");
				} else {
					temp.setRam(a[8].toString());
				}
				temp.setPlatformTemplateId(a[9].toString());
				temp.setMachineTemplateId(a[10].toString());
				templateList.add(temp);
			}
			return templateList;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : searchTemplatesForBareMetal", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : searchTemplatesForBareMetal", he);
		}
	}
	
	@Override
	public List<PlatformTemplateTO> searchVMWare(PlatformTemplateTO platformTemplateTO) throws CMMException {
	
		Session session = getSession();
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(PlatformTemplateTO.class, "provisionedMachine");
			if (!"".equalsIgnoreCase(platformTemplateTO.getName().trim())) {
				criteria.add(Restrictions.like("name", "%" + platformTemplateTO.getName() + "%"));
			}
			if (!"-1".equalsIgnoreCase(platformTemplateTO.getFamily().trim())) {
				criteria.add(Restrictions.like("family", "%" + platformTemplateTO.getFamily() + "%"));
			}
			if (platformTemplateTO.getStatus() > 0L) {
				criteria.add(Restrictions.eq("statusTO.id", platformTemplateTO.getStatus()));
			}
			List<PlatformTemplateTO> templateList = new ArrayList<PlatformTemplateTO>(0);
			if (platformTemplateTO.getSearchCount() == 0) {
				templateList = (List<PlatformTemplateTO>) getHibernateTemplate().findByCriteria(criteria);
				return templateList;
			}
			criteria.getExecutableCriteria(session).setFirstResult(platformTemplateTO.getFirstResult());
			criteria.getExecutableCriteria(session).setMaxResults(platformTemplateTO.getTableSize());
			templateList = (List<PlatformTemplateTO>) getHibernateTemplate().findByCriteria(criteria);
			return templateList;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. HardwareDAOImpl:searchHardware", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. HardwareDAOImpl:searchHardware", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<StatusTO> getStatusList() throws CMMException {
	
		try {
			return (List<StatusTO>) getHibernateTemplate().find("from StatusTO where entityId=?", CMMConstants.Framework.Entity.TEMPLATE);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. VMWareDaoImpl:getStatusList", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. VMWareDaoImpl:getStatusList", he);
		}
	}
	
	@Override
	public PlatformTemplateTO loadTemplateDetails(PlatformTemplateTO platformTemplatesTO) throws CMMException {
	
		try {
			PlatformTemplateTO templateTO = (PlatformTemplateTO) getHibernateTemplate().find("from PlatformTemplateTO where id=?", platformTemplatesTO.getId()).get(0);
			Long platformTemplateId = templateTO.getId();
			if ("VMWARE".equalsIgnoreCase(templateTO.getType())) {
				List<Object[]> obj = (List<Object[]>) getHibernateTemplate().find("select mv.username, mv.password FROM MachineVMWareTO mv, MachineTemplateTO m where m.id=mv.machineTemplate.id and m.platformTemplateId=?", platformTemplateId);
				for (Object a[] : obj) {
					templateTO.setUsername(a[0].toString());
					templateTO.setPassword(a[1].toString());
				}
			}
			if ("VMWARE_BARE".equalsIgnoreCase(templateTO.getType())) {
				List<Object[]> obj = (List<Object[]>) getHibernateTemplate().find("select mv.username, mv.password FROM MachineTemplateBareMetalTO mv, MachineTemplateTO m where m.id=mv.machineTemplateTO.id and m.platformTemplateId=?", platformTemplateId);
				for (Object a[] : obj) {
					templateTO.setUsername(a[0].toString());
					templateTO.setPassword(a[1].toString());
				}
			}
			if ("OPENSTACK".equalsIgnoreCase(templateTO.getType())) {
				List<Object[]> obj = (List<Object[]>) getHibernateTemplate().find("select mv.username, mv.password FROM MachineTemplateOSTO mv, MachineTemplateTO m where m.id=mv.machineTemplate.id and m.platformTemplateId=?", platformTemplateId);
				for (Object a[] : obj) {
					templateTO.setUsername(a[0].toString());
					templateTO.setPassword(a[1].toString());
				}
			}
			return templateTO;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. VMWareDaoImpl:loadTemplateDetails", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. VMWareDaoImpl:loadTemplateDetails", he);
		}
	}
	
	@Override
	public void editBusinessUnit(PlatformTemplateTO platformTemplatesTO) throws CMMException {
	
		try {
			Long platformTemplateId = platformTemplatesTO.getId();
			PlatformTemplateTO platformTemplate = (PlatformTemplateTO) getHibernateTemplate().find("from PlatformTemplateTO where id=?", platformTemplateId).get(0);
			platformTemplatesTO.setType(platformTemplate.getType());
			Long machineTemplateId = (Long) getHibernateTemplate().find("select m.id from MachineTemplateTO m where m.platformTemplateId=?", platformTemplateId).get(0);
			MachineTemplateTO MachineTemplateTO = new MachineTemplateTO();
			MachineTemplateTO.setId(machineTemplateId);
			if ("VMWARE".equalsIgnoreCase(platformTemplate.getType())) {
				MachineVMWareTO machineTemplateVmware = new MachineVMWareTO();
				machineTemplateVmware.setPassword(platformTemplatesTO.getPassword());
				machineTemplateVmware.setUsername(platformTemplatesTO.getUsername());
				machineTemplateVmware.setMachineTemplate(MachineTemplateTO);
				Long machineTempId = machineTemplateVmware.getMachineTemplate().getId();
				Long id = (Long) getHibernateTemplate().find("select mv.id from MachineVMWareTO mv where mv.machineTemplate.id =?", machineTempId).get(0);
				machineTemplateVmware.setId(id);
				getHibernateTemplate().update(machineTemplateVmware);
			}
			if ("OPENSTACK".equalsIgnoreCase(platformTemplate.getType())) {
				MachineTemplateOSTO machineTemplateOpenstack = new MachineTemplateOSTO();
				machineTemplateOpenstack.setPassword(platformTemplatesTO.getPassword());
				machineTemplateOpenstack.setUsername(platformTemplatesTO.getUsername());
				machineTemplateOpenstack.setMachineTemplate(MachineTemplateTO);
				Long machineTempId = machineTemplateOpenstack.getMachineTemplate().getId();
				List<MachineTemplateOSTO> MachineTemplateOpenstackList = (List<MachineTemplateOSTO>) getHibernateTemplate().find("from MachineTemplateOSTO mv where mv.machineTemplate.id =?", machineTempId);
				for (MachineTemplateOSTO m : MachineTemplateOpenstackList) {
					machineTemplateOpenstack.setId(m.getId());
					machineTemplateOpenstack.setFlavorId(m.getFlavorId());
					machineTemplateOpenstack.setFlavorType(m.getFlavorType());
					machineTemplateOpenstack.setDisk(m.getDisk());
				}
				getHibernateTemplate().update(machineTemplateOpenstack);
			}
			if ("VMWARE_BARE".equalsIgnoreCase(platformTemplate.getType())) {
				MachineTemplateBareMetalTO machineTemplateBareMetal = new MachineTemplateBareMetalTO();
				machineTemplateBareMetal.setPassword(platformTemplatesTO.getPassword());
				machineTemplateBareMetal.setUsername(platformTemplatesTO.getUsername());
				machineTemplateBareMetal.setMachineTemplateTO(MachineTemplateTO);
				Long machineTempId = machineTemplateBareMetal.getMachineTemplateTO().getId();
				List<MachineTemplateBareMetalTO> machineTemplateBareMetalList = (List<MachineTemplateBareMetalTO>) getHibernateTemplate().find("from MachineTemplateBareMetalTO mv where mv.machineTemplateTO.id =?", machineTempId);
				for (MachineTemplateBareMetalTO m : machineTemplateBareMetalList) {
					machineTemplateBareMetal.setId(m.getId());
					machineTemplateBareMetal.setDiskMode(m.getDiskMode());
					machineTemplateBareMetal.setHardDiskSize(m.getHardDiskSize());
				}
				getHibernateTemplate().update(machineTemplateBareMetal);
			}
			getHibernateTemplate().update(platformTemplatesTO);
		} catch (ConstraintViolationException ce) {
			logger.error(ce);
			throw new CMMException("Problem encountered. VMVareDAOImpl:editBusinessUnit", ce);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. VMVareDAOImpl:editBusinessUnit", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. VMVareDAOImpl:editBusinessUnit", he);
		}
	}
	
	@Override
	public List<VSphereDetailsTO> getDataCenteList() throws CMMException {
	
		try {
			return (List<VSphereDetailsTO>) getHibernateTemplate().find("from VSphereDetailsTO where cloudType in ('D','EX') ");
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.VMWareDaoImpl:getDataCenteList", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.VMWareDaoImpl:getDataCenteList", he);
		}
	}
	
	@Override
	public List<VSphereDetailsTO> getDataCenteListForPolicy(String cloudType) throws CMMException {
	
		try {
			return (List<VSphereDetailsTO>) getHibernateTemplate().find("from VSphereDetailsTO where cloudType = ?", cloudType);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.VMWareDaoImpl:getDataCenteList", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.VMWareDaoImpl:getDataCenteList", he);
		}
	}
}
