/**
 *
 */
package com.ext.puppet.dao.Impl;

import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.puppet.dao.PuppetProcessDao;
import com.framework.common.CMMConstants;
import com.framework.exception.CMMException;
import com.framework.puppetMaster.to.PuppetProcess;
import com.framework.puppetMaster.to.PuppetProcessParametersTO;
import com.framework.puppetMaster.to.PuppetProcessSoftwareMapping;
import com.framework.to.SoftwareTO;
import com.framework.to.SoftwareconfigTO;

/**
 * @author 460650
 */
public class PuppetProcessDaoImpl extends HibernateDaoSupport implements PuppetProcessDao {
	
	private static final Logger LOGGER = Logger.getLogger(PuppetProcessDaoImpl.class);
	
	@Override
	public PuppetProcess addPuppetProcess(PuppetProcess puppetProcess) throws CMMException {
	
		PuppetProcess createdPuppetProcess = null;
		try {
			long puppetProcessId = (Long) getHibernateTemplate().save(puppetProcess);
			createdPuppetProcess = getPuppetProcessInfoByProcessId(puppetProcessId);
			if (createdPuppetProcess == null) {
				LOGGER.debug("No puppet process records found for processId::" + puppetProcessId);
				throw new CMMException("No Puppet process found for processId:: " + puppetProcessId);
			}
		} catch (DataAccessException | HibernateException div) {
			LOGGER.error("Error in PuppetProcessDaoImpl:addPuppetProcess", div);
			throw new CMMException("Problem encountered.PuppetProcessDaoImpl:addPuppetProcess", div);
		}
		return createdPuppetProcess;
	}
	
	@Override
	public List<PuppetProcess> searchPuppetProcess(PuppetProcess puppetProcess) throws CMMException {
	
		try {
			List<PuppetProcess> puppetprocessList = new ArrayList<PuppetProcess>();
			DetachedCriteria criteria = DetachedCriteria.forClass(PuppetProcess.class);
			if (puppetProcess.getProcessId() > 0L) {
				criteria.add(Restrictions.eq("processId", puppetProcess.getProcessId()));
			}
			if (!"".equalsIgnoreCase(puppetProcess.getProcessFullPath().trim())) {
				criteria.add(Restrictions.like("processFullPath", puppetProcess.getProcessFullPath()));
			}
			List<PuppetProcess> temp = (List<PuppetProcess>) getHibernateTemplate().findByCriteria(criteria);
			for (PuppetProcess hd : temp) {
				puppetprocessList.add(hd);
			}
			return puppetprocessList;
		} catch (DataAccessException | HibernateException dae) {
			LOGGER.error("Error in PuppetProcessDaoImpl:searchPuppetProcess", dae);
			throw new CMMException("Problem encountered.PuppetProcessDaoImpl:searchPuppetProcess", dae);
		}
	}
	
	@Override
	public List<SoftwareTO> getSoftwareList() throws CMMException {
	
		try {
			List<SoftwareTO> temp = (List<SoftwareTO>) getHibernateTemplate().find("from SoftwareTO");
			if (temp == null) {
				throw new CMMException("No software list found.");
			}
			return temp;
		} catch (DataAccessException | HibernateException dae) {
			LOGGER.error("Error in PuppetProcessDaoImpl:getSoftwareList", dae);
			throw new CMMException("Problem encountered.PuppetProcessDaoImpl:getSoftwareList", dae);
		}
	}
	
	@Override
	public PuppetProcess getPuppetProcessInfoByProcessId(long processId) throws CMMException {
	
		PuppetProcess puppetProcess = null;
		try {
			puppetProcess = getHibernateTemplate().get(PuppetProcess.class, processId);
			if (puppetProcess == null) {
				LOGGER.debug("No puppet process records found for processId::" + processId);
				throw new CMMException("No Puppet process found for processId:: " + processId);
			}
		} catch (DataAccessException | HibernateException e) {
			LOGGER.error("Problem encountered.PuppetProcessDaoImpl:getPuppetProcessInfoByProcessId" + processId);
			throw new CMMException("Problem encountered.PuppetProcessDaoImpl:getPuppetProcessInfoByProcessId", e);
		}
		return puppetProcess;
	}
	
	@Override
	public PuppetProcess getPuppetProcessDetails(PuppetProcess puppetProcess) throws CMMException {
	
		try {
			return (PuppetProcess) getHibernateTemplate().find("from PuppetProcessTO where processId=?", puppetProcess.getProcessId()).get(0);
		} catch (DataAccessException | HibernateException dae) {
			LOGGER.error("Error in PuppetProcessDaoImpl:getPuppetProcessDetails", dae);
			throw new CMMException("Problem encountered.PuppetProcessDaoImpl:getPuppetProcessDetails", dae);
		}
	}
	
	@Override
	public void editPuppetProcessDetails(PuppetProcess puppetProcess) throws CMMException {
	
		try {
			PuppetProcess puppetprocess = (PuppetProcess) getHibernateTemplate().find("from PuppetProcessTO where processId=?", puppetProcess.getProcessId()).get(0);
			puppetprocess.setProcessFullPath(puppetProcess.getProcessFullPath());
			getHibernateTemplate().update(puppetprocess);
		} catch (DataAccessException | HibernateException ce) {
			LOGGER.error("Error in PuppetProcessDaoImpl:editPuppetProcessDetails", ce);
			throw new CMMException("Problem encountered.PuppetProcessDaoImpl:editPuppetProcessDetails", ce);
		}
	}
	
	@Override
	public List<Long> getPuppetProcessForOS(long osType) throws CMMException {
	
		List<Long> puppetProcessList = new ArrayList<Long>();
		try {
			puppetProcessList = (List<Long>) getHibernateTemplate().find("select processId from PuppetProcess where platformMasterTO.platformId=?", osType);
			if (puppetProcessList == null) {
				LOGGER.debug("No puppet process records found for osType::" + osType);
				throw new CMMException("No Puppet process found for osType:: " + osType);
			}
		} catch (DataAccessException | HibernateException dae) {
			LOGGER.error("Error in accessing data for osType :PuppetProcessDaoImpl:getPuppetProcessForOS", dae);
		}
		return puppetProcessList;
	}
	
	@Override
	public List<PuppetProcess> getAllPuppetProcess() throws CMMException {
	
		List<PuppetProcess> process = new ArrayList<PuppetProcess>();
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(PuppetProcess.class);
			process = (List<PuppetProcess>) getHibernateTemplate().findByCriteria(criteria);
		} catch (DataAccessException | HibernateException ce) {
			LOGGER.error("Error in PuppetProcessDaoImpl:getAllPuppetProcess", ce);
			throw new CMMException("Problem encountered.PuppetProcessDaoImpl:getAllPuppetProcess", ce);
		}
		return process;
	}
	
	@Override
	public boolean definePuppetProcessForSoftware(PuppetProcessSoftwareMapping mapping) throws CMMException {
	
		boolean flag = false;
		Long softwareConfigId = null;
		Session session = null;
		Session session1 = null;
		try {
			if (mapping.getSoftwareConfigId() != null) {
				DetachedCriteria criteria1 = DetachedCriteria.forClass(PuppetProcessSoftwareMapping.class);
				criteria1.createAlias("softwareConfigTO", "sConfig", CriteriaSpecification.INNER_JOIN);
				criteria1.add(Restrictions.eq("sConfig.deviceId", mapping.getSoftwareId()));
				List<PuppetProcessSoftwareMapping> puppetProcessList = (List<PuppetProcessSoftwareMapping>) getHibernateTemplate().findByCriteria(criteria1);
				for (PuppetProcessSoftwareMapping tempList : puppetProcessList) {
					Long softwareProcessMappingId = tempList.getSoftwareProcessMappingId();
					Transaction tx1 = null;
					session1 = getSession();
					tx1 = session1.beginTransaction();
					String hql = "Delete from PuppetProcessSoftwareMapping where softwareProcessMappingId = :softwareProcessMappingId";
					String hql1 = "Delete from PuppetActivityProcessOrderTO where puppetProcessSoftwareMapping.softwareProcessMappingId = :softwareProcessMappingId";
					Query query1 = session1.createQuery(hql1);
					query1.setParameter("softwareProcessMappingId", softwareProcessMappingId);
					query1.executeUpdate();
					Query query = session1.createQuery(hql);
					query.setParameter("softwareProcessMappingId", softwareProcessMappingId);
					query.executeUpdate();
					tx1.commit();
				}
				softwareConfigId = mapping.getSoftwareConfigId();
			} else {
				softwareConfigId = (Long) getHibernateTemplate().find("select MAX(id) from SoftwareconfigTO where deviceId=?", mapping.getSoftwareId()).get(0);
			}
			SoftwareconfigTO sTo = (SoftwareconfigTO) getHibernateTemplate().find("from SoftwareconfigTO where id=? ", softwareConfigId).get(0);
			Transaction tx = null;
			session = getSession();
			tx = session.beginTransaction();
			String hql = "from PuppetProcess where processId in (:PprocessId)";
			Query q = session.createQuery(hql);
			q.setParameterList("PprocessId", mapping.getPuppetProcessList());
			List<Object[]> obj = q.list();
			tx.commit();
			PuppetProcessSoftwareMapping temp = new PuppetProcessSoftwareMapping();
			for (Object process : obj) {
				temp.setSoftwareConfigTO(sTo);
				temp.setPuppetProcess((PuppetProcess) process);
				getHibernateTemplate().save(temp);
			}
			flag = true;
			return flag;
		} catch (DataAccessException | HibernateException ce) {
			LOGGER.error("Error in PuppetProcessDaoImpl:definePuppetProcessForSoftware", ce);
			throw new CMMException("Problem encountered.PuppetProcessDaoImpl:definePuppetProcessForSoftware", ce);
		} finally {
			if (session != null) {
				session.close();
			}
			if (session1 != null) {
				session1.close();
			}
		}
	}
	
	@Override
	public PuppetProcess getPuppetProcessInfoByProcessName(String processFullPath) throws CMMException {
	
		PuppetProcess puppetProcess = null;
		Session session = null;
		try {
			session = getSession();
			puppetProcess = (PuppetProcess) session.createCriteria(PuppetProcess.class).add(Restrictions.eq("processFullPath", processFullPath)).add(Restrictions.eq("status", CMMConstants.External.Puppet.Puppet_PROCESS_ACTIVE)).uniqueResult();
		} catch (DataAccessException | HibernateException e) {
			LOGGER.error("Problem encountered.PuppetProcessDaoImpl:getPuppetProcessInfoByProcessName", e);
			throw new CMMException("Problem encountered.PuppetProcessDaoImpl:getPuppetProcessInfoByProcessName", e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		if (puppetProcess != null) {
			return puppetProcess;
		} else {
			LOGGER.error("Problem encountered.PuppetProcessDaoImpl:getPuppetProcessInfoByProcessName");
			throw new CMMException("Problem encountered.PuppetProcessDaoImpl:getPuppetProcessInfoByProcessName");
		}
	}
	
	@Override
	public PuppetProcessParametersTO getParams(PuppetProcessParametersTO puppetProcessParametersTO) throws CMMException {
	
		PuppetProcessParametersTO puppetProcessParametersTOFromDB = new PuppetProcessParametersTO();
		try {
			puppetProcessParametersTOFromDB = (PuppetProcessParametersTO) getHibernateTemplate().find("from PuppetProcessParametersTO where parameter_Id=?", puppetProcessParametersTO.getParameterId()).get(0);
		} catch (DataAccessException | HibernateException dae) {
			LOGGER.error("Problem encountered.PuppetProcessDaoImpl:getParams", dae);
			throw new CMMException("Problem encountered.PuppetProcessDaoImpl:getParams", dae);
		}
		if (puppetProcessParametersTOFromDB != null) {
			return puppetProcessParametersTOFromDB;
		} else {
			LOGGER.error("Problem encountered.PuppetProcessDaoImpl:getParams");
			throw new CMMException("Problem encountered.PuppetProcessDaoImpl: getParams");
		}
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public List<PuppetProcessParametersTO> searchPuppetParameters(PuppetProcessParametersTO puppetProcessParametersTO) throws CMMException {
	
		try {
			List<PuppetProcessParametersTO> puppetProcessParametersList = (List<PuppetProcessParametersTO>) getHibernateTemplate().find("from PuppetProcessParametersTO where process_Id=?", puppetProcessParametersTO.getProcessId());
			LOGGER.debug("puppetProcessParametersList size:::::" + puppetProcessParametersList.size());
			return puppetProcessParametersList;
		} catch (DataAccessException | HibernateException dae) {
			LOGGER.error("Problem encountered.PuppetProcessDaoImpl:searchPuppetParameters", dae);
			throw new CMMException("Problem encountered. PuppetProcessDaoImpl:searchPuppetParameters", dae);
		}
	}
	
	@Override
	public boolean updateParameters(PuppetProcessParametersTO puppetProcessParametersTO) throws CMMException {
	
		Session session = null;
		LOGGER.debug("updateParameters Action   DAO");
		LOGGER.debug("puppetProcessParametersTO.getParameterPathName()" + puppetProcessParametersTO.getParameterPathName());
		LOGGER.debug("puppetProcessParametersTO.getParameterValue()" + puppetProcessParametersTO.getParameterValue());
		LOGGER.debug("puppetProcessParametersTO.getParameterId()" + puppetProcessParametersTO.getParameterId());
		int flag = 20;
		try {
			session = getSession();
			session.createQuery("update PuppetProcessParametersTO r set r.parameterPathName=?, r.parameterValue=? where r.parameterId = ? ").setParameter(0, puppetProcessParametersTO.getParameterPathName()).setParameter(1, puppetProcessParametersTO.getParameterValue()).setParameter(2, puppetProcessParametersTO.getParameterId()).executeUpdate();
			LOGGER.debug("updateParameters Action   DAO flag" + flag);
		} catch (DataAccessException | HibernateException dae) {
			LOGGER.error("Problem encountered.PuppetProcessDaoImpl:updateParameters", dae);
			throw new CMMException("Problem encountered. PuppetProcessDaoImpl:updateParameters", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return true;
	}
	
	@Override
	public boolean deleteParameters(PuppetProcessParametersTO puppetProcessParametersTO) throws CMMException {
	
		Session session = null;
		int flag = 20;
		try {
			session = getSession();
			flag = session.createQuery("delete from PuppetProcessParametersTO where parameterId=:parameterId").setParameter("parameterId", puppetProcessParametersTO.getParameterId()).executeUpdate();
			LOGGER.debug("deleteeParameters   DAO flag" + flag);
		} catch (DataAccessException | HibernateException dae) {
			LOGGER.error("Problem encountered.PuppetProcessDaoImpl:deleteeParameters", dae);
			throw new CMMException("Problem encountered. PuppetProcessDaoImpl:deleteeParameters", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return true;
	}
}
