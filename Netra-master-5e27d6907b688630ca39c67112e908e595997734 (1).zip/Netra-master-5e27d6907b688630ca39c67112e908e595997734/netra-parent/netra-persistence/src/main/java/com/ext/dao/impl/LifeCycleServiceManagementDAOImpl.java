package com.ext.dao.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.LifeCycleServiceManagementDAO;
import com.framework.common.CMMConstants;
import com.framework.exception.CMMException;
import com.framework.to.ApplicationReleasePhaseTO;
import com.framework.to.EnvironmentTO;
import com.framework.to.LifeCycleServiceManagementEnvironmentTO;
import com.framework.to.LifeCycleServiceManagementServiceTO;
import com.framework.to.LifeCycleServiceManagementTO;
import com.framework.to.ServiceTO;

/**
 * LifeCycleServiceManagementDAOImpl is implementing interface LifeCycleServiceManagementDAO and extends HibernateDaoSupport for crud operation with database.
 * It is used to implement the functionality of Service Management of Life Cycle module.
 */
public class LifeCycleServiceManagementDAOImpl extends HibernateDaoSupport implements LifeCycleServiceManagementDAO {
	
	private static final Logger LOG = Logger.getLogger(LifeCycleServiceManagementDAOImpl.class);
	
	/**
	 * Fetch environment values returns information about environment that a user can add into Life Cycle.
	 *
	 * @param selectedApplication
	 *                The Applications upon which environments are fetched.
	 * @return A Map of Long and String which has ID and name for each environment.
	 * @throws CMMException
	 */
	@Override
	public Map<Long, String> getEnvironmentForServiceManagement(Long selectedApplication, Long selectedPhase, Long selectedRelease) throws CMMException {
	
		Map<Long, String> envMap = new HashMap<Long, String>(0);
		try {
			List<Object[]> objList;
			List<Long> planningPhaseList = new ArrayList<>(0);
			List<Long> envList = new ArrayList<>(0);
			if (selectedRelease != null) {
				String hql = String.format("select r.id from ApplicationReleasePhaseTO r, TestingPhaseTO t WHERE r.phaseId = t.id AND r.applicationId=%d AND r.releasePlanningTO.id=%d AND r.stat in ('Y') ORDER BY r.order", selectedApplication, selectedRelease);
				planningPhaseList = (List<Long>) getHibernateTemplate().find(hql);
			}
			planningPhaseList.remove(selectedPhase);
			Session session = getSession();
			if (!planningPhaseList.isEmpty()) {
				String hql = "from LifeCycleServiceManagementTO lc where lc.releasePhaseId in (:planningPhaseList)";
				Query q = session.createQuery(hql);
				q.setParameterList("planningPhaseList", planningPhaseList);
				List<LifeCycleServiceManagementTO> lifeCycleServiceManagementList = q.list();
				List<LifeCycleServiceManagementEnvironmentTO> lifeCycleServiceManagementEnvironmentList = new ArrayList<>(0);
				for (LifeCycleServiceManagementTO lifeCycleServiceManagement : lifeCycleServiceManagementList) {
					Set<LifeCycleServiceManagementEnvironmentTO> lifeCycleServiceManagementEnvironment = lifeCycleServiceManagement.getLifeCycleServiceMgmtEnvironment();
					lifeCycleServiceManagementEnvironmentList.addAll(lifeCycleServiceManagementEnvironment);
				}
				for (LifeCycleServiceManagementEnvironmentTO lifeCycleServiceManagementEnvironmentTO : lifeCycleServiceManagementEnvironmentList) {
					envList.add(lifeCycleServiceManagementEnvironmentTO.getEnvironmentId());
				}
			}
			objList = (List<Object[]>) getHibernateTemplate().find("select e.id, e.environmentName from EnvironmentApplicationTO a, EnvironmentTO e, EnvironmentDetailsTO ed, ProvisionedMachineTO pm WHERE a.environmentTO.id=e.id AND a.applicationTO.id=? and e.status=? and ed.environment.id=e.id and pm.ip is not null and e.profileId is not null and ed.provisionedMachineId=pm.id", selectedApplication, CMMConstants.Framework.Entity.ENVIRONMENT_AVAILABLE);
			for (Object[] obj : objList) {
				if (!envList.contains(obj[0])) {
					envMap.put((Long) obj[0], (String) obj[1]);
				}
			}
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. LifeCycleServiceManagementDAOImpl: getEnvironmentForServiceManagement", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. LifeCycleServiceManagementDAOImpl: getEnvironmentForServiceManagement", he);
		}
		return envMap;
	}
	
	/**
	 * Fetch Services values returns information about services that a user can add into Life Cycle.
	 *
	 * @return A Map of Long and String which has ID and name for each service.
	 * @throws CMMException
	 */
	@Override
	public Map<Long, String> getServiceForServiceManagement() throws CMMException {
	
		try {
			Map<Long, String> serviceMap = new HashMap<Long, String>(0);
			List<ServiceTO> serviceList = (List<ServiceTO>) getHibernateTemplate().find("from ServiceTO where flag =?", CMMConstants.Framework.ServiceFlag.LIFECYCLE_FLAG);
			for (ServiceTO service : serviceList) {
				serviceMap.put(service.getId(), service.getName());
			}
			return serviceMap;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. LifeCycleServiceManagementDAOImpl: getServiceForServiceManagement", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. LifeCycleServiceManagementDAOImpl: getServiceForServiceManagement", he);
		}
	}
	
	/**
	 * Add all details for service management, service management environments and service management services.
	 *
	 * @param serviceManagement
	 *                All the Life Cycle service management details that are to be saved in the database.
	 * @throws CMMException
	 */
	@Override
	public void addServiceManagementDetails(LifeCycleServiceManagementTO serviceManagement) throws CMMException {
	
		try {
			List<LifeCycleServiceManagementTO> lifeCycleServiceManagementList = (List<LifeCycleServiceManagementTO>) getHibernateTemplate().find("from LifeCycleServiceManagementTO where releasePhaseId =?", serviceManagement.getReleasePhaseId());
			if (lifeCycleServiceManagementList.isEmpty()) {
				getHibernateTemplate().save(serviceManagement);
			} else {
				LifeCycleServiceManagementTO lifeCycleServiceManagement = lifeCycleServiceManagementList.get(0);
				lifeCycleServiceManagement.setModifiedbyId(serviceManagement.getModifiedbyId());
				lifeCycleServiceManagement.setModifiedDate(new Date());
				lifeCycleServiceManagement.getLifeCycleServiceMgmtEnvironment().clear();
				lifeCycleServiceManagement.getLifeCycleServiceMgmtService().clear();
				for (LifeCycleServiceManagementEnvironmentTO env : serviceManagement.getLifeCycleServiceMgmtEnvironment()) {
					env.setLifeCycleServiceManagement(lifeCycleServiceManagement);
					lifeCycleServiceManagement.getLifeCycleServiceMgmtEnvironment().add(env);
				}
				for (LifeCycleServiceManagementServiceTO srvc : serviceManagement.getLifeCycleServiceMgmtService()) {
					srvc.setLifeCycleServiceManagement(lifeCycleServiceManagement);
					lifeCycleServiceManagement.getLifeCycleServiceMgmtService().add(srvc);
				}
				getHibernateTemplate().update(lifeCycleServiceManagement);
			}
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. LifeCycleServiceManagementDAOImpl: addServiceManagementDetails", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. LifeCycleServiceManagementDAOImpl: addServiceManagementDetails", he);
		}
	}
	
	/**
	 * Fetch service management details returns information about services that a user can use in Life Cycle.
	 *
	 * @param phaseId
	 *                The phase ID upon which service details are fetched.
	 * @return A instance of LifeCycleServiceManagementTO which contains all the related information.
	 * @throws CMMException
	 */
	@Override
	public LifeCycleServiceManagementTO fetchServiceManagementDetails(Long phaseId) throws CMMException {
	
		LifeCycleServiceManagementTO serviceMgmt = null;
		Long releasePhaseId = 0L;
		try {
			List<ApplicationReleasePhaseTO> applicationReleasePhase = (List<ApplicationReleasePhaseTO>) getHibernateTemplate().find("from ApplicationReleasePhaseTO a where a.id=? ", phaseId);
			if (applicationReleasePhase.isEmpty()) {
				return serviceMgmt;
			} else {
				releasePhaseId = applicationReleasePhase.get(0).getId();
				List<LifeCycleServiceManagementTO> serviceManagementList = (List<LifeCycleServiceManagementTO>) getHibernateTemplate().find("from LifeCycleServiceManagementTO where releasePhaseId=?", releasePhaseId);
				if (!serviceManagementList.isEmpty()) {
					serviceMgmt = new LifeCycleServiceManagementTO();
					serviceMgmt.setId(serviceManagementList.get(0).getId());
					serviceMgmt.setReleasePhaseId(serviceManagementList.get(0).getReleasePhaseId());
					List<LifeCycleServiceManagementServiceTO> serviceList = (List<LifeCycleServiceManagementServiceTO>) getHibernateTemplate().find("from LifeCycleServiceManagementServiceTO where lifeCycleServiceManagement.id=? order by serviceOrder", serviceMgmt.getId());
					List<LifeCycleServiceManagementEnvironmentTO> environmentList = (List<LifeCycleServiceManagementEnvironmentTO>) getHibernateTemplate().find("from LifeCycleServiceManagementEnvironmentTO where lifeCycleServiceManagement.id=? ", serviceMgmt.getId());
					serviceMgmt.getLifeCycleServiceMgmtEnvironment().addAll(environmentList);
					serviceMgmt.setServicesList(serviceList);
				}
			}
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. LifeCycleServiceManagementDAOImpl: fetchServiceManagementDetails", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. LifeCycleServiceManagementDAOImpl: fetchServiceManagementDetails", he);
		}
		return serviceMgmt;
	}
	
	/**
	 * Interface for fetching environment list for the selected phase of the selected application.
	 *
	 * @param phaseId
	 *                The linked application-phase id.
	 * @return A list of long containing the list of the environments associated with the selected phase of the selected application.
	 * @throws CMMException
	 */
	@Override
	public List<LifeCycleServiceManagementTO> fetchLinkedEnvironmentLinkedServiceList(Long applicationPhaseLinkId) throws CMMException {
	
		try {
			return (List<LifeCycleServiceManagementTO>) getHibernateTemplate().find("from LifeCycleServiceManagementTO where releasePhaseId=?", applicationPhaseLinkId);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. LifeCycleServiceManagementDAOImpl: fetchServiceManagementDetails", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. LifeCycleServiceManagementDAOImpl: fetchServiceManagementDetails", he);
		}
	}
	
	@Override
	public List<EnvironmentTO> getEnvironmentList(List<Long> environmentIdList) throws CMMException {
	
		List<EnvironmentTO> environmentList = new ArrayList<EnvironmentTO>(0);
		try {
			for (Long envId : environmentIdList) {
				List<EnvironmentTO> environmentList1 = (List<EnvironmentTO>) getHibernateTemplate().find("from EnvironmentTO where id=?", envId);
				if (environmentList1.size() > 0L) {
					environmentList.add(environmentList1.get(0));
				}
			}
			return environmentList;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. LifeCycleServiceManagementDAOImpl: fetchServiceManagementDetails", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. LifeCycleServiceManagementDAOImpl: fetchServiceManagementDetails", he);
		}
	}
	
	@Override
	public List<ServiceTO> fetchLinkedServiceList(Long selectedPhaseId) throws CMMException {
	
		try {
			LifeCycleServiceManagementTO serviceMgmt;
			List<ServiceTO> serviceRequestList = new ArrayList<ServiceTO>(0);
			List<LifeCycleServiceManagementTO> serviceManagementList = (List<LifeCycleServiceManagementTO>) getHibernateTemplate().find("from LifeCycleServiceManagementTO where releasePhaseId=?", selectedPhaseId);
			if (!serviceManagementList.isEmpty()) {
				serviceMgmt = new LifeCycleServiceManagementTO();
				serviceMgmt.setId(serviceManagementList.get(0).getId());
				serviceMgmt.setReleasePhaseId(serviceManagementList.get(0).getReleasePhaseId());
				List<LifeCycleServiceManagementServiceTO> serviceList = (List<LifeCycleServiceManagementServiceTO>) getHibernateTemplate().find("from LifeCycleServiceManagementServiceTO where lifeCycleServiceManagement.id=? order by serviceOrder", serviceMgmt.getId());
				for (LifeCycleServiceManagementServiceTO lifeCycleService : serviceList) {
					List<ServiceTO> serviceList1 = (List<ServiceTO>) getHibernateTemplate().find("from ServiceTO where id=?", lifeCycleService.getServiceId());
					if (serviceList1.size() > 0L) {
						serviceRequestList.add(serviceList1.get(0));
					}
				}
			}
			return serviceRequestList;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. LifeCycleServiceManagementDAOImpl: fetchServiceManagementDetails", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. LifeCycleServiceManagementDAOImpl: fetchServiceManagementDetails", he);
		}
	}
	
	@Override
	public Map<Long, String> getServiceForServiceManagementList(Long selectedApplication) throws CMMException {
	
		Map<Long, String> serviceMap = new HashMap<Long, String>(0);
		try {
			Long clientId = 0L;
			clientId = (Long) getHibernateTemplate().find("select distinct a.businessUnitTO.clientId from ApplicationTO a, BusinessUnitTO c WHERE a.businessUnitTO.clientId= c.clientId and a.id =? and c.status=?", selectedApplication, CMMConstants.Framework.Entity.BUSINESS_ACTIVE).get(0);
			List<Object[]> obList = (List<Object[]>) getHibernateTemplate().find("select distinct s.id, s.name from ServiceClientTO sc , ServiceTO s WHERE s.id= sc.serviceTO.id AND sc.clientId=? AND s.flag =?", clientId, CMMConstants.Framework.ServiceFlag.LIFECYCLE_FLAG);
			for (Object[] obj : obList) {
				serviceMap.put((Long) obj[0], (String) obj[1]);
			}
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. LifeCycleServiceManagementDAOImpl: getServiceForServiceManagementList", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. LifeCycleServiceManagementDAOImpl: getServiceForServiceManagementList", he);
		}
		return serviceMap;
	}
}
