/**
 *
 */
package com.ext.dao.impl;

import java.util.ArrayList;
import java.util.List;
import org.hibernate.HibernateException;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.SoftwareConfigDAO;
import com.framework.exception.CMMException;
import com.framework.to.SoftwareTO;
import com.framework.to.SoftwareconfigTO;

/**
 * @author 460650
 */
public class SoftwareConfigDAOImpl extends HibernateDaoSupport implements SoftwareConfigDAO {
	
	@Override
	public SoftwareconfigTO getSoftwareConfigDetails(long mappedSoftwareId) throws CMMException {
	
		try {
			List<SoftwareconfigTO> softwareconfigTOList = (List<SoftwareconfigTO>) getHibernateTemplate().find("from SoftwareconfigTO where id=?", mappedSoftwareId);
			if ((softwareconfigTOList == null) || softwareconfigTOList.isEmpty()) {
				logger.debug("No record found in Softwareconfig table for requestId:: " + mappedSoftwareId);
				throw new CMMException("No record found in Softwareconfig table for requestId:: " + mappedSoftwareId);
			}
			return softwareconfigTOList.get(0);
		} catch (DataAccessException dae) {
			logger.error("Error in fetching SoftwareconfigDetails for requestId:: " + mappedSoftwareId);
			throw new CMMException("Can not access SoftwareconfigDetails for requestId: " + dae.getMessage(), dae);
		} catch (HibernateException he) {
			logger.error("Error while fetching SoftwareconfigDetails for requestId:: " + mappedSoftwareId);
			throw new CMMException("Problem while fetching SoftwareconfigDetails." + he.getMessage(), he);
		}
	}
	
	@Override
	public List<SoftwareconfigTO> getVersionForSoftware(SoftwareTO softwareTO) throws CMMException {
	
		logger.info("Inside SoftwareConfigDAOImpl ::getVersionForSoftware(softwareTO)");
		List<SoftwareconfigTO> versionList = new ArrayList<SoftwareconfigTO>();
		try {
			versionList = (List<SoftwareconfigTO>) getHibernateTemplate().find("from SoftwareconfigTO where deviceId=?", softwareTO.getId());
		} catch (DataAccessException dae) {
			logger.error("Error in fetching SoftwareconfigList for SoftwareId:: " + softwareTO.getId());
			throw new CMMException("Can not access Softwareconfig for SoftwareId: " + dae.getMessage(), dae);
		} catch (HibernateException he) {
			logger.error("Error while fetching Softwareconfig for SoftwareId:: " + softwareTO.getId());
			throw new CMMException("Problem while fetching Softwareconfig." + he.getMessage(), he);
		}
		return versionList;
	}
}
