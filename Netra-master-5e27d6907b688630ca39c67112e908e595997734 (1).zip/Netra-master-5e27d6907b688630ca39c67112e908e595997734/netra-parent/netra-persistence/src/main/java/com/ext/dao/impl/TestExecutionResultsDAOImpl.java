package com.ext.dao.impl;

import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.TestExecutionResultsDAO;
import com.framework.common.CMMConstants;
import com.framework.exception.CMMException;
import com.framework.report.AppRelDetailsVO;
import com.framework.to.ApplicationMobileTestingTO;
import com.framework.to.ApplicationReleaseTO;
import com.framework.to.ServiceRequestTO;
import com.framework.to.TestExecutionResultsTO;
import com.framework.to.TestingToolsTO;

public class TestExecutionResultsDAOImpl extends HibernateDaoSupport implements TestExecutionResultsDAO {
	
	private static final Logger LOG = Logger.getLogger(ApplicationDAOImpl.class);
	
	@Override
	public void updateTestingTools(TestingToolsTO testingToolsConfiguration) throws CMMException {
	
		try {
			getHibernateTemplate().update(testingToolsConfiguration);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.TestExecutionResultsDAOImpl:updateTestingTools", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.TestExecutionResultsDAOImpl:updateTestingTools", he);
		}
	}
	
	@Override
	public void addTestExecutionResults(TestExecutionResultsTO testExecutionResultsTO) throws CMMException {
	
		try {
			getHibernateTemplate().save(testExecutionResultsTO);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.TestExecutionResultsDAOImpl:addTestExecutionResults", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.TestExecutionResultsDAOImpl:addTestExecutionResults", he);
		}
	}
	
	@Override
	public List<TestExecutionResultsTO> searchTestResults(TestExecutionResultsTO testExecutionResultsTO) throws CMMException {
	
		try {
			String providerName = null;
			int provider = Integer.parseInt(testExecutionResultsTO.getProvider());
			switch (provider) {
				case 1:
					providerName = "SELENIUM";
					break;
				case 2:
					providerName = "QTP";
					break;
				case 3:
					providerName = "APACHE_JMETER";
					break;
				case 4:
					providerName = "TAM";
					break;
				case 5:
					providerName = "JUNIT";
					break;
				case 6:
					providerName = "MasterCraft TAM";
					break;
				default:
					providerName = "invalid";
					break;
			}
			Session session = getSession();
			String query = "select a.id from ApplicationTO a  where a.status=" + CMMConstants.Framework.Entity.APPLICATION_AVAILABLE;
			if ((testExecutionResultsTO.getSelectedBusinessUnitNew() != null) && (testExecutionResultsTO.getSelectedBusinessUnitNew().size() > 0)) {
				query = query + " and a.businessUnitTO.id IN( :bu)";
			}
			if ((testExecutionResultsTO.getSelectedProjectNew() != null) && (testExecutionResultsTO.getSelectedProjectNew().size() > 0)) {
				query = query + " and a.projectTO.id IN( :proj)";
			}
			if ((testExecutionResultsTO.getSelectedApplicationNew() != null) && (testExecutionResultsTO.getSelectedApplicationNew().size() > 0)) {
				query = query + " and a.id IN( :app)";
			}
			Query q = session.createQuery(query);
			if ((testExecutionResultsTO.getSelectedBusinessUnitNew() != null) && (testExecutionResultsTO.getSelectedBusinessUnitNew().size() > 0)) {
				q.setParameterList("bu", testExecutionResultsTO.getSelectedBusinessUnitNew());
			}
			if ((testExecutionResultsTO.getSelectedProjectNew() != null) && (testExecutionResultsTO.getSelectedProjectNew().size() > 0)) {
				q.setParameterList("proj", testExecutionResultsTO.getSelectedProjectNew());
			}
			if ((testExecutionResultsTO.getSelectedApplicationNew() != null) && (testExecutionResultsTO.getSelectedApplicationNew().size() > 0)) {
				q.setParameterList("app", testExecutionResultsTO.getSelectedApplicationNew());
			}
			List<Long> appIds = q.list();
			List<TestExecutionResultsTO> testExecutionResultsFinal = new ArrayList<TestExecutionResultsTO>();
			List<TestExecutionResultsTO> testExecutionResults = new ArrayList<TestExecutionResultsTO>();
			if (appIds != null) {
				if (!appIds.isEmpty()) {
					DetachedCriteria criteria = DetachedCriteria.forClass(ApplicationReleaseTO.class);
					criteria.add(Restrictions.in("applicationId", appIds));
					criteria.setProjection(Projections.property("id"));
					List<Long> appReleaseIdList = (List<Long>) getHibernateTemplate().findByCriteria(criteria);
					if (appReleaseIdList.size() > 0) {
						criteria = DetachedCriteria.forClass(TestExecutionResultsTO.class);
						criteria.add(Restrictions.in("appReleaseId", appReleaseIdList));
						criteria.add(Restrictions.eq("provider", providerName).ignoreCase());
						if ((testExecutionResultsTO.getStartTime() != null) && (testExecutionResultsTO.getEndTime() == null)) {
							criteria.add(Restrictions.ge("startTime", testExecutionResultsTO.getStartTime()));
						}
						if ((testExecutionResultsTO.getStartTime() == null) && (testExecutionResultsTO.getEndTime() != null)) {
							criteria.add(Restrictions.le("startTime", testExecutionResultsTO.getEndTime()));
						}
						if ((testExecutionResultsTO.getStartTime() != null) && (testExecutionResultsTO.getEndTime() != null)) {
							criteria.add(Restrictions.ge("startTime", testExecutionResultsTO.getStartTime()));
							criteria.add(Restrictions.le("startTime", testExecutionResultsTO.getEndTime()));
						}
					}
					testExecutionResults = (List<TestExecutionResultsTO>) getHibernateTemplate().findByCriteria(criteria);
					if ((testExecutionResultsTO.getSelectedEnvironmentNew() != null) && (testExecutionResultsTO.getSelectedEnvironmentNew().size() > 0)) {
						for (TestExecutionResultsTO lTestExecutionResultsTO : testExecutionResults) {
							List<ServiceRequestTO> serviceRequestTOLst = new ArrayList<ServiceRequestTO>();
							criteria = DetachedCriteria.forClass(ServiceRequestTO.class);
							criteria.add(Restrictions.idEq(lTestExecutionResultsTO.getServiceRequestId()));
							criteria.add(Restrictions.in("environmentId", testExecutionResultsTO.getSelectedEnvironmentNew()));
							serviceRequestTOLst = (List<ServiceRequestTO>) getHibernateTemplate().findByCriteria(criteria);
							if ((serviceRequestTOLst != null) && (serviceRequestTOLst.size() > 0)) {
								testExecutionResultsFinal.add(lTestExecutionResultsTO);
							}
						}
					} else {
						testExecutionResultsFinal = testExecutionResults;
					}
				}
			}
			return testExecutionResultsFinal;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. TestExecutionResultsDAOImpl : searchTestResults", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. TestExecutionResultsDAOImpl : searchTestResults", he);
		}
	}
	
	@Override
	public List<ApplicationMobileTestingTO> searchTestResultsPerfecto(ApplicationMobileTestingTO appMobileTestingTO) throws CMMException {
	
		try {
			Integer.parseInt(appMobileTestingTO.getProvider());
			Session session = getSession();
			String query = "select a.id from ApplicationTO a  where a.status=" + CMMConstants.Framework.Entity.APPLICATION_AVAILABLE;
			if ((appMobileTestingTO.getSelectedBusinessUnitNew() != null) && (appMobileTestingTO.getSelectedBusinessUnitNew().size() > 0)) {
				query = query + " and a.businessUnitTO.id IN( :bu)";
			}
			if ((appMobileTestingTO.getSelectedProjectNew() != null) && (appMobileTestingTO.getSelectedProjectNew().size() > 0)) {
				query = query + " and a.projectTO.id IN( :proj)";
			}
			if ((appMobileTestingTO.getSelectedApplicationNew() != null) && (appMobileTestingTO.getSelectedApplicationNew().size() > 0)) {
				query = query + " and a.id IN( :app)";
			}
			Query q = session.createQuery(query);
			if ((appMobileTestingTO.getSelectedBusinessUnitNew() != null) && (appMobileTestingTO.getSelectedBusinessUnitNew().size() > 0)) {
				q.setParameterList("bu", appMobileTestingTO.getSelectedBusinessUnitNew());
			}
			if ((appMobileTestingTO.getSelectedProjectNew() != null) && (appMobileTestingTO.getSelectedProjectNew().size() > 0)) {
				q.setParameterList("proj", appMobileTestingTO.getSelectedProjectNew());
			}
			if ((appMobileTestingTO.getSelectedApplicationNew() != null) && (appMobileTestingTO.getSelectedApplicationNew().size() > 0)) {
				q.setParameterList("app", appMobileTestingTO.getSelectedApplicationNew());
			}
			List<Long> appIds = q.list();
			List<ApplicationMobileTestingTO> testExecutionResultsFinal = new ArrayList<>();
			List<ApplicationMobileTestingTO> testExecutionResults = new ArrayList<>();
			if (appIds != null) {
				if (appIds.size() > 0) {
					DetachedCriteria criteria = DetachedCriteria.forClass(ApplicationMobileTestingTO.class);
					criteria.add(Restrictions.in("applicationId", appIds));
					testExecutionResults = (List<ApplicationMobileTestingTO>) getHibernateTemplate().findByCriteria(criteria);
					testExecutionResultsFinal = testExecutionResults;
				}
			}
			return testExecutionResultsFinal;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. TestExecutionResultsDAOImpl : searchTestResultsPerfecto", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. TestExecutionResultsDAOImpl : searchTestResultsPerfecto", he);
		}
	}
	
	@Override
	public TestExecutionResultsTO getTestResultsDetails(TestExecutionResultsTO testExecutionResultsTO) throws CMMException {
	
		return (TestExecutionResultsTO) getHibernateTemplate().find("from TestExecutionResultsTO where id=?", testExecutionResultsTO.getId()).get(0);
	}
	
	@Override
	public AppRelDetailsVO getDetailsFromRequest(Long reqID) throws CMMException {
	
		Session session = null;
		AppRelDetailsVO lAppRelDetailsVO = new AppRelDetailsVO();
		List<AppRelDetailsVO> lAppRelDetailsVOLst = new ArrayList<AppRelDetailsVO>();
		try {
			session = getSession();
			String query = CMMConstants.Presentation.Reporting.QUERY_DETAIL_FROM_REQUEST;
			Query q = session.createQuery(query);
			q.setParameter(0, reqID);
			lAppRelDetailsVOLst = q.setResultTransformer(Transformers.aliasToBean(AppRelDetailsVO.class)).list();
			if (!lAppRelDetailsVOLst.isEmpty()) {
				lAppRelDetailsVO = lAppRelDetailsVOLst.get(0);
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. TestExecutionResultsDAOImpl : getDetailsFromRequest", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. TestExecutionResultsDAOImpl : getDetailsFromRequest", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return lAppRelDetailsVO;
	}
	
	@Override
	public TestExecutionResultsTO getTestResultsDetailsForReport(Long serviceRequestId) throws CMMException {
	
		TestExecutionResultsTO executionResultsTO = new TestExecutionResultsTO();
		try {
			executionResultsTO = (TestExecutionResultsTO) getHibernateTemplate().find("from TestExecutionResultsTO where serviceRequestId=?", serviceRequestId).get(0);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. TestExecutionResultsDAOImpl : getTestResultsDetailsForReport", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. TestExecutionResultsDAOImpl : getTestResultsDetailsForReport", he);
		}
		return executionResultsTO;
	}
}
