package com.ext.dao.impl;

import java.util.ArrayList;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.hibernate.exception.ConstraintViolationException;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.util.StringUtils;
import com.ext.dao.SystemConfigurationDao;
import com.framework.common.CMMConstants;
import com.framework.exception.CMMException;
import com.framework.nolio.to.NolioProcess;
import com.framework.nolio.to.NolioProcessParametersTO;
import com.framework.to.AddPolicyTO;
import com.framework.to.ApplicationTO;
import com.framework.to.BuildToolTO;
import com.framework.to.CAReleaseDetailsTO;
import com.framework.to.ClientTO;
import com.framework.to.ContinuousIntegrationServerTO;
import com.framework.to.DataMaskingConfigTO;
import com.framework.to.DnsServerDetailsTO;
import com.framework.to.DockerServerConfigurationTO;
import com.framework.to.JIRAConfigTO;
import com.framework.to.LDAPDetailsTO;
import com.framework.to.ParameterTO;
import com.framework.to.PolicyMappingTO;
import com.framework.to.ProjectsTO;
import com.framework.to.RepositoryDetailsTO;
import com.framework.to.RepositoryTO;
import com.framework.to.ServiceNowConfigTO;
import com.framework.to.TestingPhaseTO;
import com.framework.to.VSphereDetailsTO;

public class SystemConfigurationDaoImpl extends HibernateDaoSupport implements SystemConfigurationDao {
	
	@Override
	public List<VSphereDetailsTO> searchVMWare(VSphereDetailsTO vSphereDetailsTO) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			Criteria criteria = session.createCriteria(VSphereDetailsTO.class, "vSphereDetailsTO");
			if (!"".equalsIgnoreCase(vSphereDetailsTO.getDataCenterName().trim())) {
				criteria.add(Restrictions.like("dataCenterName", "%" + vSphereDetailsTO.getDataCenterName() + "%"));
			}
			List<VSphereDetailsTO> vSphereList = criteria.list();
			if (vSphereDetailsTO.getSearchCount() == 0) {
				vSphereList = criteria.list();
			} else {
				criteria.setFirstResult(vSphereDetailsTO.getFirstResult());
				criteria.setMaxResults(vSphereDetailsTO.getTableSize());
				vSphereList = criteria.list();
			}
			if (vSphereList.isEmpty()) {
				vSphereList = null;
				return vSphereList;
			} else {
				return vSphereList;
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. SystemConfigurationDaoImpl : searchVMWare", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. SystemConfigurationDaoImpl : searchVMWare", he);
		}
	}
	
	@Override
	public List<ParameterTO> searchParameter(ParameterTO parameterTO) throws CMMException {
	
		Session session = null;
		session = getSession();
		Criteria criteria = session.createCriteria(ParameterTO.class, "parameterTO");
		try {
			List<ParameterTO> parameterList = new ArrayList<ParameterTO>();
			List<ParameterTO> parameterTempList = new ArrayList<ParameterTO>();
			if (!"".equalsIgnoreCase(parameterTO.getName().trim())) {
				criteria.add(Restrictions.like("name", "%" + parameterTO.getName() + "%"));
			}
			criteria.add(Restrictions.gt("id", 0L));
			if (parameterTO.getSearchCount() == 0) {
				parameterTempList = criteria.list();
			} else {
				criteria.setFirstResult(parameterTO.getFirstResult());
				criteria.setMaxResults(parameterTO.getTableSize());
				parameterTempList = criteria.list();
			}
			for (ParameterTO parameter : parameterTempList) {
				parameterList.add(parameter);
			}
			return parameterList;
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. searchParameter : ", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<RepositoryTO> searchRepository(RepositoryTO repositoryTO) throws CMMException {
	
		Session session = null;
		session = getSession();
		Criteria criteria = session.createCriteria(RepositoryTO.class, "repo").createAlias("repo.repositoryDetails", "repoDetails", Criteria.LEFT_JOIN);
		try {
			criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			List<RepositoryTO> repositoryList = new ArrayList<RepositoryTO>();
			List<RepositoryTO> repositoryTempList = new ArrayList<RepositoryTO>();
			if ((repositoryTO.getSelectedBUId() != null) && (repositoryTO.getSelectedBUId() > 0L)) {
				criteria.add(Restrictions.eq("repoDetails.buId", repositoryTO.getSelectedBUId()));
			}
			if ((repositoryTO.getSelectedProjectId() != null) && (repositoryTO.getSelectedProjectId() > 0L)) {
				criteria.add(Restrictions.eq("repoDetails.projectId", repositoryTO.getSelectedProjectId()));
			}
			if (!"".equalsIgnoreCase(repositoryTO.getRepoName().trim())) {
				criteria.add(Restrictions.like("repo.repoName", "%" + repositoryTO.getRepoName() + "%"));
			}
			if ((repositoryTO.getRepoType() != null) && (repositoryTO.getRepoType() > 0)) {
				criteria.add(Restrictions.eq("repo.repoType", repositoryTO.getRepoType()));
			}
			criteria.add(Restrictions.gt("repo.id", 0L));
			if (repositoryTO.getSearchCount() == 0) {
				repositoryTempList = criteria.list();
			} else {
				criteria.setFirstResult(repositoryTO.getFirstResult());
				criteria.setMaxResults(repositoryTO.getTableSize());
				repositoryTempList = criteria.list();
			}
			for (RepositoryTO repository : repositoryTempList) {
				repositoryList.add(repository);
			}
			return repositoryList;
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. searchRepository : ", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public boolean editParameter(ParameterTO parameterTO) throws CMMException {
	
		try {
			getHibernateTemplate().update(parameterTO);
		} catch (ConstraintViolationException ce) {
			logger.error(ce);
			throw new CMMException("Problem encountered.editParameter", ce);
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.editParameter", dae);
		}
		return true;
	}
	
	@Override
	public boolean editRepository(RepositoryTO repositoryTO) throws CMMException {
	
		try {
			Long repoId = repositoryTO.getId();
			getHibernateTemplate().update(repositoryTO);
			List<RepositoryDetailsTO> repoDetailsList = (List<RepositoryDetailsTO>) getHibernateTemplate().find("from RepositoryDetailsTO where repoConfigId=?", repoId);
			for (RepositoryDetailsTO repositoryDetailsTO : repoDetailsList) {
				getHibernateTemplate().delete(repositoryDetailsTO);
			}
			if (repositoryTO.getSelectedBuList() != null) {
				if ((repositoryTO.getSelectedBuList().size() == 1) && (repositoryTO.getSelectedProjectList() != null) && (repositoryTO.getSelectedProjectList().size() > 0)) {
					for (Long projectId : repositoryTO.getSelectedProjectList()) {
						RepositoryDetailsTO repoDetails = new RepositoryDetailsTO();
						repoDetails.setRepoConfigId(repoId);
						repoDetails.setBuId(repositoryTO.getSelectedBuList().get(0));
						repoDetails.setProjectId(projectId);
						getHibernateTemplate().save(repoDetails);
					}
				} else if (!repositoryTO.getSelectedBuList().isEmpty() && ((repositoryTO.getSelectedProjectList() == null) || repositoryTO.getSelectedProjectList().isEmpty())) {
					for (Long buId : repositoryTO.getSelectedBuList()) {
						RepositoryDetailsTO repoDetails = new RepositoryDetailsTO();
						repoDetails.setRepoConfigId(repoId);
						repoDetails.setBuId(buId);
						repoDetails.setProjectId(null);
						getHibernateTemplate().save(repoDetails);
					}
				} else {
					throw new CMMException("Problem encountered.RepositoryDaoImpl:addRepository");
				}
			}
		} catch (ConstraintViolationException ce) {
			logger.error(ce);
			throw new CMMException("Problem encountered.editRepository", ce);
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.editRepository", dae);
		}
		return true;
	}
	
	@Override
	public ParameterTO loadParameterDetails(ParameterTO parameterTO) throws CMMException {
	
		try {
			return (ParameterTO) getHibernateTemplate().find("from ParameterTO where id=?", parameterTO.getId()).get(0);
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.loadParamerDetails", dae);
		}
	}
	
	@Override
	public RepositoryTO loadRepositoryDetails(RepositoryTO repositoryTO) throws CMMException {
	
		try {
			return (RepositoryTO) getHibernateTemplate().find("from RepositoryTO where id=?", repositoryTO.getId()).get(0);
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.loadParamerDetails", dae);
		}
	}
	
	@Override
	public ParameterTO addParameter(ParameterTO parameterTO) throws CMMException {
	
		try {
			getHibernateTemplate().save(parameterTO);
		} catch (DataIntegrityViolationException | ConstraintViolationException div) {
			logger.error(div);
			throw new CMMException("Problem encountered.ParameterDaoImpl:addParameter", div);
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.ParameterDaoImpl:addParameter", dae);
		}
		return parameterTO;
	}
	
	@Override
	public RepositoryTO addRepository(RepositoryTO repositoryTO) throws CMMException {
	
		try {
			Long repoId = (Long) getHibernateTemplate().save(repositoryTO);
			if (repositoryTO.getSelectedBuList() != null) {
				if ((repositoryTO.getSelectedBuList().size() == 1) && (repositoryTO.getSelectedProjectList() != null) && (repositoryTO.getSelectedProjectList().size() > 0)) {
					for (Long projectId : repositoryTO.getSelectedProjectList()) {
						RepositoryDetailsTO repoDetails = new RepositoryDetailsTO();
						repoDetails.setRepoConfigId(repoId);
						repoDetails.setBuId(repositoryTO.getSelectedBuList().get(0));
						repoDetails.setProjectId(projectId);
						getHibernateTemplate().save(repoDetails);
					}
				} else if (!repositoryTO.getSelectedBuList().isEmpty() && ((repositoryTO.getSelectedProjectList() == null) || repositoryTO.getSelectedProjectList().isEmpty())) {
					for (Long buId : repositoryTO.getSelectedBuList()) {
						RepositoryDetailsTO repoDetails = new RepositoryDetailsTO();
						repoDetails.setRepoConfigId(repoId);
						repoDetails.setBuId(buId);
						repoDetails.setProjectId(null);
						getHibernateTemplate().save(repoDetails);
					}
				} else {
					throw new CMMException("Problem encountered.RepositoryDaoImpl:addRepository");
				}
			} else {
				throw new CMMException("Problem encountered.RepositoryDaoImpl:addRepository");
			}
		} catch (DataIntegrityViolationException | ConstraintViolationException div) {
			logger.error(div);
			throw new CMMException("Problem encountered.RepositoryDaoImpl:addRepository", div);
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.RepositoryDaoImpl:addRepository", dae);
		}
		return repositoryTO;
	}
	
	@Override
	public List<RepositoryTO> getAllRepoConfig() throws CMMException {
	
		return (List<RepositoryTO>) getHibernateTemplate().find("from RepositoryTO");
	}
	
	public List<TestingPhaseTO> searchPhase(TestingPhaseTO testingPhaseTO) throws CMMException {
	
		List<TestingPhaseTO> result = new ArrayList<TestingPhaseTO>();
		try {
			result = (List<TestingPhaseTO>) getHibernateTemplate().find("from TestingPhaseTO where PhaseName=?", testingPhaseTO.getName());
			if (result.isEmpty()) {
				result = null;
				return result;
			} else {
				return result;
			}
		} catch (Exception e) {
			logger.error(e);
			throw new CMMException("Problem encountered. ApplicationTestingPhaseDaoImpl : searchPhase", e);
		}
	}
	
	@Override
	public boolean checkName(VSphereDetailsTO vSphereDetailsTO) throws CMMException {
	
		boolean flag = false;
		try {
			if ((vSphereDetailsTO.getId() == 0L) || (vSphereDetailsTO.getId() == null)) {
				List<VSphereDetailsTO> unit = (List<VSphereDetailsTO>) getHibernateTemplate().find("from VSphereDetailsTO where dataCenterName=?", vSphereDetailsTO.getDataCenterName());
				if (!unit.isEmpty()) {
					flag = true;
				} else {
					flag = false;
				}
			} else {
				List<VSphereDetailsTO> unit = (List<VSphereDetailsTO>) getHibernateTemplate().find("from VSphereDetailsTO where dataCenterName=? and id <> ?", vSphereDetailsTO.getDataCenterName(), vSphereDetailsTO.getId());
				if (!unit.isEmpty()) {
					flag = true;
				} else {
					flag = false;
				}
			}
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl:checkName.", dae);
		}
		return flag;
	}
	
	@Override
	public boolean checkPolicyName(AddPolicyTO addPolicyTO) throws CMMException {
	
		boolean flag = false;
		List<AddPolicyTO> addPolicyToList = new ArrayList<AddPolicyTO>(0);
		List<PolicyMappingTO> policyMappingList = new ArrayList<PolicyMappingTO>(0);
		try {
			if (addPolicyTO.getSelectedApplicationList() != null) {
				addPolicyToList = (List<AddPolicyTO>) getHibernateTemplate().find("from AddPolicyTO where policyName=?", addPolicyTO.getPolicyName());
				if (addPolicyToList.size() > 0L) {
					policyMappingList = (List<PolicyMappingTO>) getHibernateTemplate().find("from PolicyMappingTO where policyDetailId=? and applicationId is not NULL", addPolicyToList.get(0).getId());
				}
			} else if (addPolicyTO.getSelectedProjectList() != null) {
				addPolicyToList = (List<AddPolicyTO>) getHibernateTemplate().find("from AddPolicyTO where policyName=?", addPolicyTO.getPolicyName());
				if (addPolicyToList.size() > 0L) {
					policyMappingList = (List<PolicyMappingTO>) getHibernateTemplate().find("from PolicyMappingTO where policyDetailId=? and applicationId is not NULL and projectId is not NULL", addPolicyToList.get(0).getId());
				}
			} else {
				addPolicyToList = (List<AddPolicyTO>) getHibernateTemplate().find("from AddPolicyTO where policyName=?", addPolicyTO.getPolicyName());
				if (addPolicyToList.size() > 0L) {
					policyMappingList = (List<PolicyMappingTO>) getHibernateTemplate().find("from PolicyMappingTO where policyDetailId=? and applicationId is not NULL and projectId is not NULL and businessUnitId is not NULL", addPolicyToList.get(0).getId());
				}
			}
			if (!policyMappingList.isEmpty()) {
				flag = true;
			} else {
				flag = false;
			}
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl:checkPolicyName.", dae);
		}
		return flag;
	}
	
	@Override
	public boolean checkNameforAddPolicy(AddPolicyTO addpolicyTo) throws CMMException {
	
		Boolean flag = false;
		try {
			List<AddPolicyTO> addpolicyTO = (List<AddPolicyTO>) getHibernateTemplate().find("from AddPolicyTO where policyName=?", addpolicyTo.getPolicyName());
			if (!addpolicyTO.isEmpty()) {
				flag = true;
			} else {
				flag = false;
			}
		} catch (ConstraintViolationException ce) {
			logger.error(ce);
			throw new CMMException("Template Name already exists.", ce);
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. BareMetalDAOImpl:editTemplate", dae);
		}
		return flag;
	}
	
	@Override
	public boolean checkNameforEdit(AddPolicyTO addpolicyTo) throws CMMException {
	
		Boolean flag = false;
		try {
			List<AddPolicyTO> addpolicyTO = (List<AddPolicyTO>) getHibernateTemplate().find("from AddPolicyTO where policyName=? and id <> ?", addpolicyTo.getPolicyName(), addpolicyTo.getId());
			if (!addpolicyTO.isEmpty()) {
				flag = true;
			} else {
				flag = false;
			}
		} catch (ConstraintViolationException ce) {
			logger.error(ce);
			throw new CMMException("Template Name already exists.", ce);
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. BareMetalDAOImpl:editTemplate", dae);
		}
		return flag;
	}
	
	@Override
	public List<AddPolicyTO> searchPolicy(AddPolicyTO addPolicyTO, List<Long> clientList) throws CMMException {
	
		Session session = null;
		List<AddPolicyTO> addPolicyToList1 = new ArrayList<AddPolicyTO>(0);
		try {
			session = getSession();
			Criteria criteria = session.createCriteria(AddPolicyTO.class, "addPolicyTO");
			if ((addPolicyTO.getPolicyName() != null) && (addPolicyTO.getPolicyName().length() > 0)) {
				criteria.add(Restrictions.like("policyName", "%" + addPolicyTO.getPolicyName() + "%"));
			}
			if (addPolicyTO.getSearchCount() == 0) {
				addPolicyToList1 = criteria.list();
			} else {
				criteria.setFirstResult(addPolicyTO.getFirstResult());
				criteria.setMaxResults(addPolicyTO.getTableSize());
				addPolicyToList1 = criteria.list();
			}
			List<AddPolicyTO> addPolicyToList = new ArrayList<AddPolicyTO>(0);
			if ((addPolicyTO.getSelectedBUId() != null) && (addPolicyTO.getSelectedBUId() >= 0L)) {
				for (AddPolicyTO addPolicy : addPolicyToList1) {
					if ((addPolicyTO.getSelectedApp() != null) && (addPolicyTO.getSelectedApp() > 0L)) {
						List<PolicyMappingTO> policyMappingList = (List<PolicyMappingTO>) getHibernateTemplate().find("from PolicyMappingTO where policyDetailId=? and applicationId =? and projectId =? and businessUnitId=?", addPolicy.getId(), addPolicyTO.getSelectedApp(), addPolicyTO.getSelectedProjectId(), addPolicyTO.getSelectedBUId());
						if (policyMappingList.size() > 0L) {
							addPolicyToList.add(addPolicy);
						}
					} else if ((addPolicyTO.getSelectedProjectId() != null) && (addPolicyTO.getSelectedProjectId() > 0L)) {
						List<PolicyMappingTO> policyMappingList = (List<PolicyMappingTO>) getHibernateTemplate().find("from PolicyMappingTO where policyDetailId=?  and projectId =? and businessUnitId=?", addPolicy.getId(), addPolicyTO.getSelectedProjectId(), addPolicyTO.getSelectedBUId());
						if (policyMappingList.size() > 0L) {
							addPolicyToList.add(addPolicy);
						}
					} else if ((addPolicyTO.getSelectedBUId() != null) && (addPolicyTO.getSelectedBUId() >= 0L)) {
						List<PolicyMappingTO> policyMappingList = (List<PolicyMappingTO>) getHibernateTemplate().find("from PolicyMappingTO where policyDetailId=?  and businessUnitId=?", addPolicy.getId(), addPolicyTO.getSelectedBUId());
						if (policyMappingList.size() > 0L) {
							addPolicyToList.add(addPolicy);
						}
					}
				}
			} else if (addPolicyTO.getUserId() != 1) {
				List<AddPolicyTO> policyaddList = new ArrayList<AddPolicyTO>(0);
				String query = "select distinct a from AddPolicyTO a,PolicyMappingTO p where a.id=p.policyDetailId and p.businessUnitId in (:clientIdlist)";
				Query q = session.createQuery(query);
				q.setParameterList("clientIdlist", clientList);
				policyaddList.addAll(q.list());
				for (AddPolicyTO pm : policyaddList) {
					for (AddPolicyTO am : addPolicyToList1) {
						if (pm.getId() == am.getId()) {
							addPolicyToList.add(am);
						}
					}
				}
			} else {
				addPolicyToList = addPolicyToList1;
			}
			List<AddPolicyTO> addpolicyToList = new ArrayList<AddPolicyTO>();
			for (AddPolicyTO policyTO : addPolicyToList) {
				List<Object[]> appList = (List<Object[]>) getHibernateTemplate().find("select distinct p.applicationId, p.applicationTo from PolicyMappingTO p  where p.policyDetailId=?", policyTO.getId());
				List<Object[]> projectList = (List<Object[]>) getHibernateTemplate().find("select distinct p.projectId, p.projectsTo from PolicyMappingTO p where p.policyDetailId=?", policyTO.getId());
				List<Object[]> buList = (List<Object[]>) getHibernateTemplate().find("select distinct p.businessUnitId, p.clientTo from PolicyMappingTO p where p.policyDetailId=?", policyTO.getId());
				if (appList.size() > 0L) {
					if (appList.size() == 1L) {
						policyTO.setApplicationTo((ApplicationTO) appList.get(0)[1]);
						policyTO.setApplicationCount("One");
					} else {
						policyTO.setApplicationCount("Multiple");
					}
				} else {
					policyTO.setApplicationCount("Zero");
				}
				if (projectList.size() > 0L) {
					if (projectList.size() == 1L) {
						policyTO.setProjectsTo((ProjectsTO) projectList.get(0)[1]);
						policyTO.setProjectCount("One");
					} else {
						policyTO.setProjectCount("Multiple");
					}
				} else {
					policyTO.setProjectCount("Zero");
				}
				if (buList.size() > 0L) {
					if (buList.size() == 1L) {
						policyTO.setClientTo((ClientTO) buList.get(0)[1]);
						policyTO.setClientCount("One");
					} else {
						policyTO.setClientCount("Multiple");
					}
				} else {
					policyTO.setClientCount("Zero");
				}
				List<ApplicationTO> apps = new ArrayList<ApplicationTO>(0);
				for (Object[] obj : appList) {
					apps.add((ApplicationTO) obj[1]);
				}
				policyTO.setApplicationList(apps);
				List<ClientTO> clients = new ArrayList<ClientTO>(0);
				for (Object[] obj : buList) {
					clients.add((ClientTO) obj[1]);
				}
				policyTO.setClientList(clients);
				List<ProjectsTO> projects = new ArrayList<ProjectsTO>(0);
				for (Object[] obj : projectList) {
					projects.add((ProjectsTO) obj[1]);
				}
				policyTO.setProjectList(projects);
				if ((policyTO.getPolicyName() != null) && (policyTO.getPolicyName().length() > 0)) {
					policyTO.setPolicyName(policyTO.getPolicyName());
				}
				addpolicyToList.add(policyTO);
			}
			return addpolicyToList;
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl:searchPolicy.", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<AddPolicyTO> loadPolicy(Long selectedId) throws CMMException {
	
		try {
			List<AddPolicyTO> addPolicyToList = (List<AddPolicyTO>) getHibernateTemplate().find("from AddPolicyTO where id=?", selectedId);
			List<Long> appList = (List<Long>) getHibernateTemplate().find("select distinct applicationId from PolicyMappingTO  where policyDetailId=?", addPolicyToList.get(0).getId());
			List<Long> projectList = (List<Long>) getHibernateTemplate().find("select distinct projectId from PolicyMappingTO where policyDetailId=?", addPolicyToList.get(0).getId());
			List<Long> buList = (List<Long>) getHibernateTemplate().find("select distinct businessUnitId from PolicyMappingTO where policyDetailId=?", addPolicyToList.get(0).getId());
			addPolicyToList.get(0).setAppIds(appList);
			addPolicyToList.get(0).setProjectIds(projectList);
			addPolicyToList.get(0).setBuIds(buList);
			return addPolicyToList;
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl:loadPolicy.", dae);
		}
	}
	
	@Override
	public List<DnsServerDetailsTO> fetchAllDnsServer() throws CMMException {
	
		try {
			return (List<DnsServerDetailsTO>) getHibernateTemplate().find("from DnsServerDetailsTO");
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl:fetchAllDnsServer", he);
		}
	}
	
	@Override
	public boolean addVMWare(VSphereDetailsTO vSphereDetailsTO) throws CMMException {
	
		try {
			getHibernateTemplate().save(vSphereDetailsTO);
		} catch (Exception e) {
			logger.error(e);
			throw new CMMException("Problem encountered. SystemConfigurationDaoImpl : addVMWare", e);
		}
		return true;
	}
	
	@Override
	public List<VSphereDetailsTO> fetchOpenstackDetails() throws CMMException {
	
		List<VSphereDetailsTO> vsphereList = null;
		try {
			vsphereList = (List<VSphereDetailsTO>) getHibernateTemplate().find("from VSphereDetailsTO where cloudType=?", CMMConstants.Framework.MachineTypes.MACHINE_TYPE_OPENSTACK);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl:checkName.", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl:checkName.", he);
		}
		return vsphereList;
	}
	
	@Override
	public VSphereDetailsTO loadVm(VSphereDetailsTO vSphereDetailsTO) throws CMMException {
	
		try {
			VSphereDetailsTO vSphereDetailTO = (VSphereDetailsTO) getHibernateTemplate().find("from VSphereDetailsTO where id=?", vSphereDetailsTO.getId()).get(0);
			vSphereDetailTO.setCloudType(vSphereDetailTO.getCloudType());
			vSphereDetailTO.setDataCenterName(vSphereDetailTO.getDataCenterName());
			vSphereDetailTO.setUsername(vSphereDetailTO.getUsername());
			vSphereDetailTO.setPassword(vSphereDetailTO.getPassword());
			vSphereDetailTO.setUrl(vSphereDetailTO.getUrl());
			return vSphereDetailTO;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. SystemConfigurationDaoImpl: loadVm", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. SystemConfigurationDaoImpl: loadVm", he);
		}
	}
	
	@Override
	public void editCloud(VSphereDetailsTO vSphereDetailsTO) throws CMMException {
	
		try {
			getHibernateTemplate().update(vSphereDetailsTO);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. SystemConfigurationDaoImpl: editCloud", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. SystemConfigurationDaoImpl: editCloud", he);
		}
	}
	
	@Override
	public boolean checkName(ParameterTO parameterTO) throws CMMException {
	
		boolean flag = false;
		try {
			List<ParameterTO> unit = (List<ParameterTO>) getHibernateTemplate().find("from ParameterTO where name=?", parameterTO.getName());
			if (!unit.isEmpty()) {
				flag = true;
			} else {
				flag = false;
			}
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl:checkName.", dae);
		}
		return flag;
	}
	
	@Override
	public boolean checkName(RepositoryTO repositoryTO) throws CMMException {
	
		boolean flag = false;
		try {
			List<RepositoryTO> unit = (List<RepositoryTO>) getHibernateTemplate().find("from RepositoryTO where repoName=?", repositoryTO.getRepoName());
			if (!unit.isEmpty()) {
				flag = true;
			} else {
				flag = false;
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl:checkName.", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl:checkName.", he);
		}
		return flag;
	}
	
	@Override
	public boolean savePolicy(AddPolicyTO addPolicyTo) throws CMMException {
	
		try {
			getHibernateTemplate().save(addPolicyTo);
			if (addPolicyTo.getSelectedApplicationList() != null) {
				for (Long appId : addPolicyTo.getSelectedApplicationList()) {
					List<ApplicationTO> applications = (List<ApplicationTO>) getHibernateTemplate().find("from ApplicationTO where id=?", appId);
					if (applications.size() > 0L) {
						PolicyMappingTO policyMappingTO = new PolicyMappingTO();
						ApplicationTO application = new ApplicationTO();
						application = applications.get(0);
						policyMappingTO.setBusinessUnitId(application.getBusinessUnitTO().getClientId());
						policyMappingTO.setProjectId(application.getProjectTO().getId());
						policyMappingTO.setApplicationId(application.getId());
						policyMappingTO.setPolicyDetailId(addPolicyTo.getId());
						getHibernateTemplate().save(policyMappingTO);
					}
				}
			} else if (addPolicyTo.getSelectedProjectList() != null) {
				for (Long projectId : addPolicyTo.getSelectedProjectList()) {
					List<ProjectsTO> projects = (List<ProjectsTO>) getHibernateTemplate().find("from ProjectsTO where id=?", projectId);
					if (projects.size() > 0L) {
						PolicyMappingTO policyMappingTO = new PolicyMappingTO();
						ProjectsTO project = new ProjectsTO();
						project = projects.get(0);
						policyMappingTO.setBusinessUnitId(project.getClientId());
						policyMappingTO.setProjectId(project.getId());
						policyMappingTO.setPolicyDetailId(addPolicyTo.getId());
						getHibernateTemplate().save(policyMappingTO);
					}
				}
			} else {
				for (Long buId : addPolicyTo.getSelectedBuList()) {
					PolicyMappingTO policyMappingTO = new PolicyMappingTO();
					policyMappingTO.setBusinessUnitId(buId);
					policyMappingTO.setPolicyDetailId(addPolicyTo.getId());
					getHibernateTemplate().save(policyMappingTO);
				}
			}
		} catch (Exception e1) {
			logger.error(e1);
			throw new CMMException("Problem encountered. SystemConfigurationDaoImpl : savePolicy", e1);
		}
		return true;
	}
	
	public boolean savePolicy1(AddPolicyTO addPolicyTo) throws CMMException {
	
		try {
			getHibernateTemplate().save(addPolicyTo);
		} catch (Exception e) {
			logger.error(e);
			throw new CMMException("Problem encountered. SystemConfigurationDaoImpl : savePolicy", e);
		}
		return true;
	}
	
	@Override
	public boolean updatePolicy(AddPolicyTO addPolicyTo) throws CMMException {
	
		try {
			List<PolicyMappingTO> policyMappingList = (List<PolicyMappingTO>) getHibernateTemplate().find("from PolicyMappingTO where policyDetailId=?", addPolicyTo.getId());
			for (PolicyMappingTO policyMap : policyMappingList) {
				getHibernateTemplate().delete(policyMap);
			}
			getHibernateTemplate().update(addPolicyTo);
			if (addPolicyTo.getSelectedApplicationList() != null) {
				for (Long appId : addPolicyTo.getSelectedApplicationList()) {
					List<ApplicationTO> applications = (List<ApplicationTO>) getHibernateTemplate().find("from ApplicationTO where id=?", appId);
					if (applications.size() > 0L) {
						PolicyMappingTO policyMappingTO = new PolicyMappingTO();
						ApplicationTO application = new ApplicationTO();
						application = applications.get(0);
						policyMappingTO.setBusinessUnitId(application.getBusinessUnitTO().getClientId());
						policyMappingTO.setProjectId(application.getProjectTO().getId());
						policyMappingTO.setApplicationId(application.getId());
						policyMappingTO.setPolicyDetailId(addPolicyTo.getId());
						getHibernateTemplate().save(policyMappingTO);
					}
				}
			} else if (addPolicyTo.getSelectedProjectList() != null) {
				for (Long projectId : addPolicyTo.getSelectedProjectList()) {
					List<ProjectsTO> projects = (List<ProjectsTO>) getHibernateTemplate().find("from ProjectsTO where id=?", projectId);
					if (projects.size() > 0L) {
						PolicyMappingTO policyMappingTO = new PolicyMappingTO();
						ProjectsTO project = new ProjectsTO();
						project = projects.get(0);
						policyMappingTO.setBusinessUnitId(project.getClientId());
						policyMappingTO.setProjectId(project.getId());
						policyMappingTO.setPolicyDetailId(addPolicyTo.getId());
						getHibernateTemplate().save(policyMappingTO);
					}
				}
			} else {
				for (Long buId : addPolicyTo.getSelectedBuList()) {
					PolicyMappingTO policyMappingTO = new PolicyMappingTO();
					policyMappingTO.setBusinessUnitId(buId);
					policyMappingTO.setPolicyDetailId(addPolicyTo.getId());
					getHibernateTemplate().save(policyMappingTO);
				}
			}
		} catch (Exception e) {
			logger.error(e);
			throw new CMMException("Problem encountered. SystemConfigurationDaoImpl : updatePolicy", e);
		}
		return true;
	}
	
	@Override
	public List<CAReleaseDetailsTO> searchCARelease(CAReleaseDetailsTO caReleaseDetailsTO) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			Criteria criteria = session.createCriteria(CAReleaseDetailsTO.class, "caReleaseDetailsTO");
			if (!"".equalsIgnoreCase(caReleaseDetailsTO.getServerName().trim())) {
				criteria.add(Restrictions.like("serverName", "%" + caReleaseDetailsTO.getServerName() + "%"));
			}
			List<CAReleaseDetailsTO> caReleaseList = criteria.list();
			if (caReleaseDetailsTO.getSearchCount() == 0) {
				caReleaseList = criteria.list();
			} else {
				criteria.setFirstResult(caReleaseDetailsTO.getFirstResult());
				criteria.setMaxResults(caReleaseDetailsTO.getTableSize());
				caReleaseList = criteria.list();
			}
			if (caReleaseList.isEmpty()) {
				caReleaseList = null;
				return caReleaseList;
			} else {
				return caReleaseList;
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. SystemConfigurationDaoImpl : searchCARelease", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. SystemConfigurationDaoImpl :searchCARelease", he);
		}
	}
	
	@Override
	public boolean addCARelease(CAReleaseDetailsTO caReleaseDetailsTO) throws CMMException {
	
		try {
			getHibernateTemplate().save(caReleaseDetailsTO);
		} catch (Exception e) {
			logger.error(e);
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl : addCARelease", e);
		}
		return true;
	}
	
	@Override
	public boolean checkNameCA(CAReleaseDetailsTO caReleaseDetailsTO) throws CMMException {
	
		boolean flag = false;
		try {
			List<CAReleaseDetailsTO> unit = (List<CAReleaseDetailsTO>) getHibernateTemplate().find("from CAReleaseDetailsTO where serverName=?", caReleaseDetailsTO.getServerName());
			if (!unit.isEmpty()) {
				flag = true;
			} else {
				flag = false;
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl:checkNameCA.", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl:checkNameCA.", he);
		}
		return flag;
	}
	
	@Override
	public List<LDAPDetailsTO> searchLDAP(LDAPDetailsTO ldapDetailsTO) throws CMMException {
	
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(LDAPDetailsTO.class);
			if (!"".equalsIgnoreCase(ldapDetailsTO.getServerName().trim())) {
				criteria.add(Restrictions.like("serverName", "%" + ldapDetailsTO.getServerName() + "%"));
			}
			List<LDAPDetailsTO> ldapList = (List<LDAPDetailsTO>) getHibernateTemplate().findByCriteria(criteria);
			if (ldapList.isEmpty()) {
				ldapList = null;
				return ldapList;
			} else {
				return ldapList;
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. SystemConfigurationDaoImpl : searchLDAP", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. SystemConfigurationDaoImpl :searchLDAP", he);
		}
	}
	
	@Override
	public boolean checkNameLDAP(LDAPDetailsTO ldapDetailsTO) throws CMMException {
	
		boolean flag = false;
		try {
			List<LDAPDetailsTO> unit = (List<LDAPDetailsTO>) getHibernateTemplate().find("from LDAPDetailsTO where serverName=?", ldapDetailsTO.getServerName());
			if (!unit.isEmpty()) {
				flag = true;
			} else {
				flag = false;
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl:checkNameLDAP", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl:checkNameLDAP", he);
		}
		return flag;
	}
	
	@Override
	public boolean addLDAP(LDAPDetailsTO ldapDetailsTO) throws CMMException {
	
		try {
			getHibernateTemplate().save(ldapDetailsTO);
		} catch (Exception e) {
			logger.error(e);
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl : addLDAP", e);
		}
		return true;
	}
	
	@Override
	public boolean saveContinuousIntegrationConfigDetails(ContinuousIntegrationServerTO continuousIntegrationServerTO) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			List<ContinuousIntegrationServerTO> ciList = session.createCriteria(ContinuousIntegrationServerTO.class).add(Restrictions.eq("selectedBUId", continuousIntegrationServerTO.getSelectedBUId())).add(Restrictions.eq("selectedProjectId", continuousIntegrationServerTO.getSelectedProjectId())).add(Restrictions.eq("selectedApplicationId", continuousIntegrationServerTO.getSelectedApplicationId())).list();
			if (!ciList.isEmpty()) {
				throw new DataIntegrityViolationException("Jenkins Server already exists for application/project/bu");
			}
			Long jenkinsConfigId = (Long) getHibernateTemplate().save(continuousIntegrationServerTO);
			if ((jenkinsConfigId == null) || (jenkinsConfigId <= 0)) {
				return false;
			}
			return true;
		} catch (DataIntegrityViolationException divE) {
			logger.error("Jenkins Server already exists for application/project/bu", divE);
			return false;
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl:saveContinuousIntegrationConfigDetails", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public ContinuousIntegrationServerTO getConfigDetailsForApp(ApplicationTO applicationTO, Long ciToolId) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			List<ContinuousIntegrationServerTO> jenkinsConfigList = session.createCriteria(ContinuousIntegrationServerTO.class).add(Restrictions.eq("selectedApplicationId", applicationTO.getId())).add(Restrictions.eq("selectedTool", ciToolId)).list();
			if ((jenkinsConfigList == null) || jenkinsConfigList.isEmpty()) {
				jenkinsConfigList = session.createCriteria(ContinuousIntegrationServerTO.class).add(Restrictions.eq("selectedProjectId", applicationTO.getProjectTO().getId())).add(Restrictions.isNull("selectedApplicationId")).add(Restrictions.eq("selectedTool", ciToolId)).list();
				if ((jenkinsConfigList == null) || jenkinsConfigList.isEmpty()) {
					jenkinsConfigList = session.createCriteria(ContinuousIntegrationServerTO.class).add(Restrictions.eq("selectedBUId", applicationTO.getBusinessUnitTO().getClientId())).add(Restrictions.isNull("selectedProjectId")).add(Restrictions.isNull("selectedApplicationId")).add(Restrictions.eq("selectedTool", ciToolId)).list();
					if ((jenkinsConfigList == null) || jenkinsConfigList.isEmpty()) {
						throw new CMMException("No CI server configuration found for application :: " + applicationTO.getAppName());
					}
				}
			}
			return jenkinsConfigList.get(0);
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl:getConfigDetailsForApp", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<RepositoryDetailsTO> getRepoDetailsForApp(ApplicationTO applicationTO) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			List<RepositoryDetailsTO> repoDetailsList = session.createCriteria(RepositoryDetailsTO.class).add(Restrictions.eq("projectId", applicationTO.getProjectTO().getId())).add(Restrictions.isNull("selectedApplicationId")).list();
			if ((repoDetailsList == null) || repoDetailsList.isEmpty()) {
				repoDetailsList = session.createCriteria(RepositoryDetailsTO.class).add(Restrictions.eq("buId", applicationTO.getBusinessUnitTO().getClientId())).add(Restrictions.isNull("selectedProjectId")).add(Restrictions.isNull("selectedApplicationId")).list();
				if ((repoDetailsList == null) || repoDetailsList.isEmpty()) {
					throw new CMMException("No Repo Config Details found for application :: " + applicationTO.getAppName());
				}
			}
			return repoDetailsList;
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl:getConfigDetailsForApp", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<ContinuousIntegrationServerTO> getAllCIServerConfigDetailsForApp(ContinuousIntegrationServerTO continuousIntgServerTO, Long applicationId, Long projectId, Long buId, Long ciToolId) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			Criteria criteria = session.createCriteria(ContinuousIntegrationServerTO.class, "ciServerTO");
			if ((applicationId != null) && (applicationId > 0)) {
				criteria.add(Restrictions.eq("selectedApplicationId", applicationId));
			}
			if ((projectId != null) && (projectId > 0)) {
				criteria.add(Restrictions.eq("selectedProjectId", projectId));
			}
			if ((buId == null) || (buId == -1L)) {
				if (continuousIntgServerTO.getClientId() != 0L) {
					criteria.add(Restrictions.in("selectedBUId", continuousIntgServerTO.getClients()));
				}
			}
			if ((buId != null) && (buId > 0)) {
				criteria.add(Restrictions.eq("selectedBUId", buId));
			}
			if ((ciToolId != null) && (ciToolId > 0)) {
				criteria.add(Restrictions.eq("selectedTool", ciToolId));
			}
			if (continuousIntgServerTO.getSearchCount() == 0) {
				return criteria.list();
			}
			criteria.setFirstResult(continuousIntgServerTO.getFirstResult());
			criteria.setMaxResults(continuousIntgServerTO.getTableSize());
			List<ContinuousIntegrationServerTO> ciServerList = criteria.list();
			List<ContinuousIntegrationServerTO> ciServerConfigList = new ArrayList<ContinuousIntegrationServerTO>();
			for (ContinuousIntegrationServerTO continuousIntegrationServerTO : ciServerList) {
				if ((continuousIntegrationServerTO.getApplicationTO() != null) && (continuousIntegrationServerTO.getApplicationTO().getAppName() != null)) {
					continuousIntegrationServerTO.setApplicationName(continuousIntegrationServerTO.getApplicationTO().getAppName());
				}
				if ((continuousIntegrationServerTO.getProjectsTO() != null) && (continuousIntegrationServerTO.getProjectsTO().getName() != null)) {
					continuousIntegrationServerTO.setProjectName(continuousIntegrationServerTO.getProjectsTO().getName());
				}
				if ((continuousIntegrationServerTO.getClientTO() != null) && (continuousIntegrationServerTO.getClientTO().getName() != null)) {
					continuousIntegrationServerTO.setBuName(continuousIntegrationServerTO.getClientTO().getName());
				}
				if ((continuousIntegrationServerTO.getBuildToolTO() != null) && (continuousIntegrationServerTO.getBuildToolTO().getName() != null)) {
					continuousIntegrationServerTO.setBuildToolName(continuousIntegrationServerTO.getBuildToolTO().getName());
				}
				ciServerConfigList.add(continuousIntegrationServerTO);
			}
			if ((ciServerList == null) || (ciServerList.size() < 0)) {
				throw new CMMException("No CI Server configuration found for application");
			}
			return ciServerConfigList;
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl:getAllCIServerConfigDetailsForApp", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public ContinuousIntegrationServerTO getConfigDetailsById(Long ciToolConfigId) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			List<ContinuousIntegrationServerTO> ciServerConfigList = session.createCriteria(ContinuousIntegrationServerTO.class).add(Restrictions.eq("id", ciToolConfigId)).list();
			if ((ciServerConfigList == null) || (ciServerConfigList.size() < 0)) {
				throw new CMMException("No CI Server configuration found for application");
			}
			return ciServerConfigList.get(0);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl:getConfigDetailsById", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl:getConfigDetailsById", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public boolean updateContinuousIntegrationConfigDetails(ContinuousIntegrationServerTO continuousIntegrationServerTO) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			List<ContinuousIntegrationServerTO> ciList = session.createCriteria(ContinuousIntegrationServerTO.class).add(Restrictions.eq("selectedBUId", continuousIntegrationServerTO.getSelectedBUId())).add(Restrictions.eq("selectedProjectId", continuousIntegrationServerTO.getSelectedProjectId())).add(Restrictions.eq("selectedApplicationId", continuousIntegrationServerTO.getSelectedApplicationId())).list();
			if (ciList.isEmpty() || (ciList.size() == 1)) {
				ContinuousIntegrationServerTO ciServerTO = getHibernateTemplate().get(ContinuousIntegrationServerTO.class, continuousIntegrationServerTO.getId());
				ciServerTO.setServerName(continuousIntegrationServerTO.getServerName());
				ciServerTO.setServerIp(continuousIntegrationServerTO.getServerIp());
				ciServerTO.setCiToolUsername(continuousIntegrationServerTO.getCiToolUsername());
				ciServerTO.setCiToolPassword(continuousIntegrationServerTO.getCiToolPassword());
				ciServerTO.setMachineUserName(continuousIntegrationServerTO.getMachineUserName());
				ciServerTO.setMachinePassword(continuousIntegrationServerTO.getMachinePassword());
				ciServerTO.setSelectedBUId(continuousIntegrationServerTO.getSelectedBUId());
				ciServerTO.setSelectedProjectId(continuousIntegrationServerTO.getSelectedProjectId());
				ciServerTO.setSelectedApplicationId(continuousIntegrationServerTO.getSelectedApplicationId());
				ciServerTO.setSelectedTool(continuousIntegrationServerTO.getSelectedTool());
				ciServerTO.setServerPort(continuousIntegrationServerTO.getServerPort());
				ciServerTO.setBaseURL(continuousIntegrationServerTO.getBaseURL());
				getHibernateTemplate().update(ciServerTO);
			} else {
				return false;
			}
			return true;
		} catch (DataIntegrityViolationException divE) {
			logger.error("Problem encountered.SystemConfigurationDaoImpl:updateContinuousIntegrationConfigDetails", divE);
			return false;
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl:updateContinuousIntegrationConfigDetails", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	public ContinuousIntegrationServerTO fetchCIConfigDetailsById(Long ciServerConfigId) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			List<ContinuousIntegrationServerTO> ciServerConfigList = session.createCriteria(ContinuousIntegrationServerTO.class).add(Restrictions.eq("id", ciServerConfigId)).list();
			if ((ciServerConfigList == null) || (ciServerConfigList.size() < 0)) {
				throw new CMMException("No CI Server configuration found for application");
			}
			return ciServerConfigList.get(0);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl:fetchCIConfigDetailsById", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl:fetchCIConfigDetailsById", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public CAReleaseDetailsTO loadCARelease(CAReleaseDetailsTO caReleaseDetailsTO) throws CMMException {
	
		try {
			return (CAReleaseDetailsTO) getHibernateTemplate().find("from CAReleaseDetailsTO where id=?", caReleaseDetailsTO.getId()).get(0);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl: loadCARelease", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl: loadCARelease", he);
		}
	}
	
	@Override
	public boolean addNolioProcessesInDB(List<NolioProcess> processList) throws CMMException {
	
		for (NolioProcess process : processList) {
			try {
				process.getNolioProcessParameters().clear();
				Long saveId = (Long) getHibernateTemplate().save(process);
				if (saveId != null) {
					if (!process.getNolioProcessParameterList().isEmpty()) {
						for (NolioProcessParametersTO parameter : process.getNolioProcessParameterList()) {
							NolioProcess nolioProcess = new NolioProcess();
							nolioProcess.setProcessId(saveId);
							NolioProcessParametersTO nolioProcessParametersTO = new NolioProcessParametersTO();
							nolioProcessParametersTO.setNolioProcess(nolioProcess);
							nolioProcessParametersTO.setStatus(CMMConstants.External.Nolio.NOLIO_PROCESS_ACTIVE);
							nolioProcessParametersTO.setParameterPathName(parameter.getParameterPathName());
							nolioProcessParametersTO.setNetraParameterMapping(CMMConstants.Framework.NetraNolioParametersMapping.NETRA_PARAMETER_MAPPED_NO);
							getHibernateTemplate().save(nolioProcessParametersTO);
						}
					}
				}
			} catch (ConstraintViolationException ce) {
				logger.error("Problem encountered.SystemConfigurationDaoImpl: addNolioProcessesInDB", ce);
			} catch (Exception e) {
				logger.error("Problem encountered.SystemConfigurationDaoImpl: addNolioProcessesInDB", e);
			}
		}
		return true;
	}
	
	@Override
	public CAReleaseDetailsTO getCAReleaseDetails() throws CMMException {
	
		try {
			List<CAReleaseDetailsTO> caReleaseList = (List<CAReleaseDetailsTO>) getHibernateTemplate().find("from CAReleaseDetailsTO");
			if ((caReleaseList == null) || caReleaseList.isEmpty()) {
				throw new CMMException("No records present in DB for CA Release");
			}
			return caReleaseList.get(0);
		} catch (DataAccessException | HibernateException e) {
			logger.error("Error in fetching CAReleaseDetails" + e.getMessage());
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl:getCAReleaseDetails", e);
		}
	}
	
	@Override
	public List<CAReleaseDetailsTO> getCAReleaseList() throws CMMException {
	
		try {
			return (List<CAReleaseDetailsTO>) getHibernateTemplate().find("from CAReleaseDetailsTO");
		} catch (DataAccessException | HibernateException e) {
			logger.error("Error in fetching CAReleaseDetails" + e.getMessage());
			throw new CMMException("Problem encountered. SystemConfigurationDaoImpl: getCAReleaseList", e);
		}
	}
	
	@Override
	public void editCARelease(CAReleaseDetailsTO caReleaseDetailsTO) throws CMMException {
	
		try {
			getHibernateTemplate().update(caReleaseDetailsTO);
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. SystemConfigurationDaoImpl: editCARelease", dae);
		}
	}
	
	@Override
	public List<ApplicationTO> fetchApplicationListForMultipleProject(List<Long> selectedBuList, List<Long> selectedProjectList, List<Long> userIds, Long clientId) throws CMMException {
	
		Session session = null;
		List<ApplicationTO> applications = new ArrayList<ApplicationTO>(0);
		try {
			if (selectedProjectList.get(0) != null) {
				session = getSession();
				String hql;
				if (clientId != 0) {
					hql = "select distinct a.id, a.appName from ProjectsTO p, ApplicationTO a inner join a.userGroups u  where u.id in (:userIds) and a.businessUnitTO.id=p.clientId and  a.businessUnitTO.id in (:businessUnitId) and a.projectTO.id=p.id and p.id in (:projectIds)";
				} else {
					hql = "select distinct a.id, a.appName from ApplicationTO a, ProjectsTO p  where a.businessUnitTO.id=p.clientId and  a.businessUnitTO.id in (:businessUnitId) and a.projectTO.id=p.id and p.id in (:projectIds)";
				}
				Query q = session.createQuery(hql);
				q.setParameterList("businessUnitId", selectedBuList);
				q.setParameterList("projectIds", selectedProjectList);
				if (clientId != 0) {
					q.setParameterList("userIds", userIds);
				}
				List<Object[]> objects = q.list();
				for (Object[] obj : objects) {
					ApplicationTO application = new ApplicationTO();
					application.setId((Long) obj[0]);
					application.setAppName((String) obj[1]);
					applications.add(application);
				}
			}
			return applications;
		} catch (ConstraintViolationException ce) {
			throw new CMMException("problem encountered SystemConfigurationDaoImpl:fetchApplicationListForMultipleProject", ce);
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Problem encountered. SystemConfigurationDaoImpl:fetchApplicationListForMultipleProject", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<ProjectsTO> searchAllProjectsForPolicy(Long selectedPolicyId) throws CMMException {
	
		List<Object[]> projectList = (List<Object[]>) getHibernateTemplate().find("select distinct p.projectId, p.projectsTo from PolicyMappingTO p where p.policyDetailId=?", selectedPolicyId);
		List<ProjectsTO> projects = new ArrayList<ProjectsTO>(0);
		for (Object[] obj : projectList) {
			projects.add((ProjectsTO) obj[1]);
		}
		return projects;
	}
	
	@Override
	public List<ClientTO> searchAllClientsForPolicy(Long selectedPolicyId) throws CMMException {
	
		List<Object[]> buList = (List<Object[]>) getHibernateTemplate().find("select distinct p.businessUnitId, p.clientTo from PolicyMappingTO p where p.policyDetailId=?", selectedPolicyId);
		List<ClientTO> clients = new ArrayList<ClientTO>(0);
		for (Object[] obj : buList) {
			clients.add((ClientTO) obj[1]);
		}
		return clients;
	}
	
	@Override
	public List<ApplicationTO> searchAllApplicationsForPolicy(Long selectedPolicyId) throws CMMException {
	
		List<Object[]> appList = (List<Object[]>) getHibernateTemplate().find("select distinct p.applicationId, p.applicationTo from PolicyMappingTO p  where p.policyDetailId=?", selectedPolicyId);
		List<ApplicationTO> apps = new ArrayList<ApplicationTO>(0);
		for (Object[] obj : appList) {
			apps.add((ApplicationTO) obj[1]);
		}
		return apps;
	}
	
	@Override
	public String policyAlreadyDefined(AddPolicyTO addPolicyTo) throws CMMException {
	
		String buProjectAppName = "";
		if (addPolicyTo.getId() == 0L) {
			addPolicyTo.setId(null);
		}
		List<PolicyMappingTO> policyMappingList = new ArrayList<PolicyMappingTO>(0);
		try {
			if (addPolicyTo.getSelectedApplicationList() != null) {
				for (Long appId : addPolicyTo.getSelectedApplicationList()) {
					if (addPolicyTo.getId() == null) {
						policyMappingList = (List<PolicyMappingTO>) getHibernateTemplate().find("from PolicyMappingTO where applicationId=?", appId);
					} else {
						policyMappingList = (List<PolicyMappingTO>) getHibernateTemplate().find("from PolicyMappingTO where applicationId=? and policyDetailId =?", appId, addPolicyTo.getId());
					}
					if (policyMappingList.size() > 0L) {
						if ("".equalsIgnoreCase(buProjectAppName)) {
							buProjectAppName = "Applevel";
						} else {
							buProjectAppName = "Applevel";
						}
					}
				}
			} else if (addPolicyTo.getSelectedProjectList() != null) {
				for (Long projectId : addPolicyTo.getSelectedProjectList()) {
					if (addPolicyTo.getId() == null) {
						policyMappingList = (List<PolicyMappingTO>) getHibernateTemplate().find("from PolicyMappingTO where projectId=? and applicationId is NULL", projectId);
					} else {
						policyMappingList = (List<PolicyMappingTO>) getHibernateTemplate().find("from PolicyMappingTO where projectId=? and applicationId is NULL and policyDetailId =?", projectId, addPolicyTo.getId());
					}
					if (policyMappingList.size() > 0L) {
						if ("".equalsIgnoreCase(buProjectAppName)) {
							buProjectAppName = "Projectlevel";
						} else {
							buProjectAppName = "Projectlevel";
						}
					}
				}
			} else {
				for (Long buId : addPolicyTo.getSelectedBuList()) {
					if (addPolicyTo.getId() == null) {
						policyMappingList = (List<PolicyMappingTO>) getHibernateTemplate().find("from PolicyMappingTO where businessUnitId=? and projectId is NULL and applicationId is NULL", buId);
					} else {
						policyMappingList = (List<PolicyMappingTO>) getHibernateTemplate().find("from PolicyMappingTO where businessUnitId=? and projectId is NULL and applicationId is NULL and policyDetailId =? ", buId, addPolicyTo.getId());
					}
					if (policyMappingList.size() > 0L) {
						if ("".equalsIgnoreCase(buProjectAppName)) {
							buProjectAppName = "Bulevel";
						} else {
							buProjectAppName = "Bulevel";
						}
					}
				}
			}
			return buProjectAppName;
		} catch (ConstraintViolationException ce) {
			throw new CMMException("problem encountered SystemConfigurationDaoImpl:policyAlreadyDefined", ce);
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Problem encountered. SystemConfigurationDaoImpl:policyAlreadyDefined", dae);
		}
	}
	
	@Override
	public String policyAlreadyDefinedEdit(AddPolicyTO addPolicyTo) throws CMMException {
	
		String buProjectAppName = "";
		List<PolicyMappingTO> policyMappingList = new ArrayList<PolicyMappingTO>(0);
		try {
			if (addPolicyTo.getSelectedApplicationList() != null) {
				for (Long appId : addPolicyTo.getSelectedApplicationList()) {
					if (addPolicyTo.getId() == null) {
						policyMappingList = (List<PolicyMappingTO>) getHibernateTemplate().find("from PolicyMappingTO where applicationId=?", appId);
					} else {
						policyMappingList = (List<PolicyMappingTO>) getHibernateTemplate().find("from PolicyMappingTO where applicationId=? and policyDetailId <> ?", appId, addPolicyTo.getId());
					}
					if (policyMappingList.size() > 0L) {
						if ("".equalsIgnoreCase(buProjectAppName)) {
							buProjectAppName = "Applevel";
						} else {
							buProjectAppName = "Applevel";
						}
					}
				}
			} else if (addPolicyTo.getSelectedProjectList() != null) {
				for (Long projectId : addPolicyTo.getSelectedProjectList()) {
					if (addPolicyTo.getId() == null) {
						policyMappingList = (List<PolicyMappingTO>) getHibernateTemplate().find("from PolicyMappingTO where projectId=? and applicationId is NULL", projectId);
					} else {
						policyMappingList = (List<PolicyMappingTO>) getHibernateTemplate().find("from PolicyMappingTO where projectId=? and applicationId is NULL and policyDetailId <> ?", projectId, addPolicyTo.getId());
					}
					if (policyMappingList.size() > 0L) {
						if ("".equalsIgnoreCase(buProjectAppName)) {
							buProjectAppName = "Projectlevel";
						} else {
							buProjectAppName = "Projectlevel";
						}
					}
				}
			} else {
				for (Long buId : addPolicyTo.getSelectedBuList()) {
					if (addPolicyTo.getId() == null) {
						policyMappingList = (List<PolicyMappingTO>) getHibernateTemplate().find("from PolicyMappingTO where businessUnitId=? and projectId is NULL and applicationId is NULL", buId);
					} else {
						policyMappingList = (List<PolicyMappingTO>) getHibernateTemplate().find("from PolicyMappingTO where businessUnitId=? and projectId is NULL and applicationId is NULL and policyDetailId <> ? ", buId, addPolicyTo.getId());
					}
					if (policyMappingList.size() > 0L) {
						if ("".equalsIgnoreCase(buProjectAppName)) {
							buProjectAppName = "Bulevel";
						} else {
							buProjectAppName = "Bulevel";
						}
					}
				}
			}
			return buProjectAppName;
		} catch (ConstraintViolationException ce) {
			throw new CMMException("problem encountered SystemConfigurationDaoImpl:policyAlreadyDefined", ce);
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Problem encountered. SystemConfigurationDaoImpl:policyAlreadyDefined", dae);
		}
	}
	
	@Override
	public boolean submitDataMaskingConfig(DataMaskingConfigTO dataMaskingConfigTO) throws CMMException {
	
		try {
			getHibernateTemplate().save(dataMaskingConfigTO);
			return true;
		} catch (ConstraintViolationException ce) {
			throw new CMMException("Problem encountered. SystemConfigurationDaoImpl:submitDataMaskingConfig", ce);
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Problem encountered. SystemConfigurationDaoImpl:submitDataMaskingConfig", dae);
		}
	}
	
	@Override
	public List<DataMaskingConfigTO> searchDataMaskingConfiguration(Long selectedApplicationId, Long selectedProjectId, Long selectedBUId, String selectedMaskTool) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			Criteria criteria = session.createCriteria(DataMaskingConfigTO.class, "dataMaskingConfigTO");
			if ((selectedApplicationId != null) && (selectedApplicationId > 0)) {
				criteria.add(Restrictions.eq("selectedApplicationId", selectedApplicationId));
			}
			if ((selectedProjectId != null) && (selectedProjectId > 0)) {
				criteria.add(Restrictions.eq("selectedProjectId", selectedProjectId));
			}
			if ((selectedBUId != null) && (selectedBUId > 0)) {
				criteria.add(Restrictions.eq("selectedBUId", selectedBUId));
			}
			if ((selectedMaskTool != "") && !selectedMaskTool.isEmpty()) {
				criteria.add(Restrictions.eq("selectedMaskTool", selectedMaskTool));
			}
			List<DataMaskingConfigTO> dataMaskingConfigList = criteria.list();
			List<DataMaskingConfigTO> datamaskConfigList = new ArrayList<DataMaskingConfigTO>();
			for (DataMaskingConfigTO dataMaskingConfigTO : dataMaskingConfigList) {
				if ((dataMaskingConfigTO.getApplicationTO() != null) && (dataMaskingConfigTO.getApplicationTO().getAppName() != null)) {
					dataMaskingConfigTO.setApplicationName(dataMaskingConfigTO.getApplicationTO().getAppName());
				}
				if ((dataMaskingConfigTO.getProjectsTO() != null) && (dataMaskingConfigTO.getProjectsTO().getName() != null)) {
					dataMaskingConfigTO.setProjectName(dataMaskingConfigTO.getProjectsTO().getName());
				}
				if ((dataMaskingConfigTO.getClientTO() != null) && (dataMaskingConfigTO.getClientTO().getName() != null)) {
					dataMaskingConfigTO.setBuName(dataMaskingConfigTO.getClientTO().getName());
				}
				datamaskConfigList.add(dataMaskingConfigTO);
			}
			if ((dataMaskingConfigList == null) || (dataMaskingConfigList.size() < 0)) {
				throw new CMMException("No Data Masking configuration found for application");
			}
			return dataMaskingConfigList;
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl:searchDataMaskingConfiguration", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public DataMaskingConfigTO getDataMaskingDetailsForApp(ApplicationTO applicationTO, String dataMaskingTool) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			List<DataMaskingConfigTO> dataMaskingConfigList = session.createCriteria(DataMaskingConfigTO.class).add(Restrictions.eq("selectedApplicationId", applicationTO.getId())).add(Restrictions.eq("selectedMaskTool", dataMaskingTool)).list();
			if ((dataMaskingConfigList == null) || dataMaskingConfigList.isEmpty()) {
				dataMaskingConfigList = session.createCriteria(DataMaskingConfigTO.class).add(Restrictions.eq("selectedProjectId", applicationTO.getProjectTO().getId())).add(Restrictions.isNull("selectedApplicationId")).add(Restrictions.eq("selectedMaskTool", dataMaskingTool)).list();
				if ((dataMaskingConfigList == null) || dataMaskingConfigList.isEmpty()) {
					dataMaskingConfigList = session.createCriteria(DataMaskingConfigTO.class).add(Restrictions.eq("selectedBUId", applicationTO.getBusinessUnitTO().getClientId())).add(Restrictions.isNull("selectedProjectId")).add(Restrictions.isNull("selectedApplicationId")).add(Restrictions.eq("selectedMaskTool", dataMaskingTool)).list();
					if ((dataMaskingConfigList == null) || dataMaskingConfigList.isEmpty()) {
						throw new CMMException("No Data Masking configuration found for application :: " + applicationTO.getAppName());
					}
				}
			}
			return dataMaskingConfigList.get(0);
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl:getDataMaskingDetailsForApp", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<BuildToolTO> fetchBuildTools() throws CMMException {
	
		try {
			return (List<BuildToolTO>) getHibernateTemplate().find("from BuildToolTO");
		} catch (DataAccessException dae) {
			throw new CMMException("Error in fetching BuildToolTO ", dae);
		} catch (HibernateException he) {
			throw new CMMException("Can not fetch data from BuildToolTO ", he);
		}
	}
	
	@Override
	public String addDockerDetails(DockerServerConfigurationTO dockerServerConfigurationTO) throws CMMException {
	
		try {
			List<DockerServerConfigurationTO> allipsList = new ArrayList<DockerServerConfigurationTO>();
			List<DockerServerConfigurationTO> dbList = new ArrayList<DockerServerConfigurationTO>();
			if (dockerServerConfigurationTO.getStatus().contains(CMMConstants.Framework.DockerStatus.ACTIVE)) {
				int w = getHibernateTemplate().find("from DockerServerConfigurationTO where status=?", dockerServerConfigurationTO.getStatus()).size();
				if (w == 0) {
					getHibernateTemplate().save(dockerServerConfigurationTO);
					return CMMConstants.Framework.Action.SUCCESS;
				} else {
					return "Active server already present";
				}
			} else {
				dbList = (List<DockerServerConfigurationTO>) getHibernateTemplate().find("from DockerServerConfigurationTO ");
				allipsList.add(dockerServerConfigurationTO);
				if (!dbList.isEmpty()) {
					for (int i = 0; i < dbList.size(); i++) {
						for (int j = 0; j < allipsList.size(); j++) {
							if (dbList.get(i).getServerIp().equalsIgnoreCase(allipsList.get(j).getServerIp())) {
								logger.debug(i + "********i-->>>" + dbList.get(i).getServerIp());
								logger.debug(j + "*********j-->>>" + allipsList.get(j).getServerIp());
								allipsList.remove(allipsList.get(j));
							}
						}
					}
					if (!allipsList.isEmpty()) {
						for (DockerServerConfigurationTO k : allipsList) {
							getHibernateTemplate().save(k);
						}
						return CMMConstants.Framework.Action.SUCCESS;
					}
				} else {
					getHibernateTemplate().save(dockerServerConfigurationTO);
					return CMMConstants.Framework.Action.SUCCESS;
				}
			}
		} catch (DataAccessException | HibernateException dae) {
			logger.error("Problem encountered.SystemConfigurationDaoImpl:addDockerDetails", dae);
		}
		return CMMConstants.Framework.Action.FAILURE;
	}
	
	@Override
	public List<DockerServerConfigurationTO> searchDockerDetails(DockerServerConfigurationTO dockerServerConfigurationTO) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			Criteria criteria = session.createCriteria(DockerServerConfigurationTO.class, "dockerServerConfigurationTO");
			if (!"".equals(dockerServerConfigurationTO.getServerIp().trim())) {
				criteria.add(Restrictions.like("serverIp", "%" + dockerServerConfigurationTO.getServerIp() + "%"));
			}
			List<DockerServerConfigurationTO> dockerServerConfList = criteria.list();
			if (dockerServerConfigurationTO.getSearchCount() == 0) {
				dockerServerConfList = criteria.list();
			} else {
				criteria.setFirstResult(dockerServerConfigurationTO.getFirstResult());
				criteria.setMaxResults(dockerServerConfigurationTO.getTableSize());
				dockerServerConfList = criteria.list();
			}
			if (dockerServerConfList.isEmpty()) {
				dockerServerConfList = null;
				return dockerServerConfList;
			} else {
				return dockerServerConfList;
			}
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. SystemConfigurationDaoImpl : searchDockerDetails", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public DockerServerConfigurationTO loadDockerDetails(Long dockerId) throws CMMException {
	
		try {
			return (DockerServerConfigurationTO) getHibernateTemplate().find("from DockerServerConfigurationTO where id=?", dockerId).get(0);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl: loadDockerDetails", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl: loadDockerDetails", he);
		}
	}
	
	@Override
	public String editDockerDetails(DockerServerConfigurationTO dockerServerConfigurationTO) throws CMMException {
	
		try {
			if (dockerServerConfigurationTO.getStatus().contains(CMMConstants.Framework.DockerStatus.ACTIVE)) {
				int w = getHibernateTemplate().find("from DockerServerConfigurationTO where status=?", dockerServerConfigurationTO.getStatus()).size();
				if (w == 0) {
					getHibernateTemplate().update(dockerServerConfigurationTO);
					return CMMConstants.Framework.Action.SUCCESS;
				} else {
					DockerServerConfigurationTO list = (DockerServerConfigurationTO) getHibernateTemplate().find("from DockerServerConfigurationTO where serverIp=?", dockerServerConfigurationTO.getServerIp()).get(0);
					if (list.getUsername().contains(dockerServerConfigurationTO.getUsername()) && list.getPassword().contains(dockerServerConfigurationTO.getPassword()) && list.getPort().equals(dockerServerConfigurationTO.getPort())) {
						return "Active server already present";
					} else {
						list.setUsername(dockerServerConfigurationTO.getUsername());
						list.setPassword(dockerServerConfigurationTO.getPassword());
						list.setPort(dockerServerConfigurationTO.getPort());
						getHibernateTemplate().update(list);
						return CMMConstants.Framework.Action.SUCCESS;
					}
				}
			} else {
				getHibernateTemplate().update(dockerServerConfigurationTO);
				return CMMConstants.Framework.Action.SUCCESS;
			}
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl:editDockerDetails", dae);
		}
	}
	
	@Override
	public List<DockerServerConfigurationTO> getDockerServerDetails() throws CMMException {
	
		try {
			List<DockerServerConfigurationTO> dockerServerConfigurationTOList = (List<DockerServerConfigurationTO>) getHibernateTemplate().find("from DockerServerConfigurationTO where status=?", CMMConstants.Framework.DockerStatus.ACTIVE);
			if (!dockerServerConfigurationTOList.isEmpty()) {
				return dockerServerConfigurationTOList;
			} else {
				dockerServerConfigurationTOList = null;
				return dockerServerConfigurationTOList;
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl: getDockerServerDetails", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl: getDockerServerDetails", he);
		}
	}
	
	@Override
	public void saveJiraConfig(JIRAConfigTO jiraConfigTO) throws CMMException {
	
		try {
			getHibernateTemplate().save(jiraConfigTO);
		} catch (DataIntegrityViolationException e) {
			logger.error(e);
			throw new CMMException("Row already exists for this tool", e);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. SystemConfigurationDaoImpl: editCARelease", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. SystemConfigurationDaoImpl: editCARelease", he);
		}
	}
	
	@Override
	public List<JIRAConfigTO> searchJiraConfig(JIRAConfigTO jiraConfigTO) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			Criteria criteria = session.createCriteria(JIRAConfigTO.class, "jiraConfigTO");
			if (!jiraConfigTO.getToolName().equalsIgnoreCase(null) && !"-1".equalsIgnoreCase(jiraConfigTO.getToolName())) {
				criteria.add(Restrictions.eq("toolName", jiraConfigTO.getToolName()));
			}
			if (jiraConfigTO.getSearchCount() == 0) {
				return criteria.list();
			}
			criteria.setFirstResult(jiraConfigTO.getFirstResult());
			criteria.setMaxResults(jiraConfigTO.getTableSize());
			List<JIRAConfigTO> jiraConfigList = criteria.list();
			if ((jiraConfigList == null) || (jiraConfigList.size() < 0)) {
				jiraConfigList = null;
			}
			return jiraConfigList;
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl:searchJiraConfig", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public JIRAConfigTO getToolDetailsForEdit(int id) throws CMMException {
	
		JIRAConfigTO jiraConfigTO = new JIRAConfigTO();
		Session session = null;
		try {
			List<JIRAConfigTO> jiraConfigTOList = (List<JIRAConfigTO>) getHibernateTemplate().find("from JIRAConfigTO where id=?", id);
			if (!jiraConfigTOList.isEmpty()) {
				jiraConfigTO = jiraConfigTOList.get(0);
			}
			return jiraConfigTO;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl:searchJiraConfig", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl:searchJiraConfig", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public boolean editToolDetails(JIRAConfigTO jiraConfigTO, int id) throws CMMException {
	
		try {
			jiraConfigTO.setId(id);
			getHibernateTemplate().update(jiraConfigTO);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. SystemConfigurationDaoImpl: editCARelease", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. SystemConfigurationDaoImpl: editCARelease", he);
		}
		return true;
	}
	
	@Override
	public String fetchBuildToolNameFromId(Long selectedTool) throws CMMException {
	
		List<BuildToolTO> buildToolList = new ArrayList<BuildToolTO>(0);
		try {
			buildToolList = (List<BuildToolTO>) getHibernateTemplate().find("from BuildToolTO where id=?", selectedTool);
			if ((buildToolList != null) && !buildToolList.isEmpty()) {
				return buildToolList.get(0).getName();
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl:fetchBuildToolNameFromId", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl:fetchBuildToolNameFromId", he);
		}
		return null;
	}
	
	//servicenow start
	@Override
	public String addSNDetails(ServiceNowConfigTO serviceNowConfigTO) throws CMMException {
	
		try {
			getHibernateTemplate().save(serviceNowConfigTO);
			return CMMConstants.Framework.Action.SUCCESS;
		} catch (DataAccessException dae) {
			logger.error("Problem encountered.SystemConfigurationDaoImpl:addSNDetails", dae);
		} catch (HibernateException he) {
			logger.error("Problem encountered.SystemConfigurationDaoImpl:addSNDetails", he);
		}
		return CMMConstants.Framework.Action.FAILURE;
	}
	
	@Override
	public List<ServiceNowConfigTO> searchSNDetails(ServiceNowConfigTO serviceNowConfigTO) throws CMMException {
	
		Session session = null;
		List<ServiceNowConfigTO> snServerConfTOList = new ArrayList<>();
		String query = null;
		try {
			session = getSession();
			query = "select id,baseURL,port,username" + " from sn_server_config";
			if (StringUtils.hasText(serviceNowConfigTO.getBaseURL())) {
				query = query + " where baseURL  like'" + serviceNowConfigTO.getBaseURL() + "%'";
			}
			Query q = session.createSQLQuery(query);
			List<Object[]> objList = q.list();
			for (Object[] temp : objList) {
				ServiceNowConfigTO envObj = new ServiceNowConfigTO();
				envObj.setId(((Integer) temp[0]).longValue());
				envObj.setBaseURL((String) temp[1]);
				envObj.setPort(((Integer) temp[2]).longValue());
				envObj.setUsername((String) temp[3]);
				snServerConfTOList.add(envObj);
			}
			return snServerConfTOList;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl:searchSNDetails.", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.SystemConfigurationDaoImpl:searchSNDetails.", he);
		}
	}
	
	@Override
	public ServiceNowConfigTO loadSNDetails(Long id) throws CMMException {
	
		ServiceNowConfigTO snServerConfTOL = new ServiceNowConfigTO();
		try {
			snServerConfTOL = (ServiceNowConfigTO) getHibernateTemplate().find("from ServiceNowConfigTO where id=?", id).get(0);
			return snServerConfTOL;
		} catch (DataAccessException dae) {
			logger.error("Problem encountered.SystemConfigurationDaoImpl:loadSNDetails", dae);
		} catch (HibernateException he) {
			logger.error("Problem encountered.SystemConfigurationDaoImpl:loadSNDetails", he);
		}
		return snServerConfTOL;
	}
	
	@Override
	public String editSNSubmit(ServiceNowConfigTO serviceNowConfigTO) throws CMMException {
	
		List<ServiceNowConfigTO> snServerConfTOL = new ArrayList<>();
		String status = "new";
		try {
			snServerConfTOL = (List<ServiceNowConfigTO>) getHibernateTemplate().find("from ServiceNowConfigTO");
			for (ServiceNowConfigTO server : snServerConfTOL) {
				if (server.getBaseURL().contains(serviceNowConfigTO.getBaseURL())) {
					if (server.getId() == serviceNowConfigTO.getId()) {
						getHibernateTemplate().update(serviceNowConfigTO);
						status = "updated";
						break;
					} else {
						return "Base URL exists";
					}
				}
			}
			if (status.contains("new")) {
				getHibernateTemplate().update(serviceNowConfigTO);
			}
			return CMMConstants.Framework.Action.SUCCESS;
		} catch (DataAccessException dae) {
			logger.error("Problem encountered.SystemConfigurationDaoImpl:editSNSubmit", dae);
		} catch (HibernateException he) {
			logger.error("Problem encountered.SystemConfigurationDaoImpl:editSNSubmit", he);
		}
		return CMMConstants.Framework.Action.FAILURE;
	}
	
	//servicenow end
	@Override
	public String toolAlreadyDefined(JIRAConfigTO jIRAConfigTO) throws CMMException {
	
		String buProjectAppName = "";
		List<JIRAConfigTO> jiraMappingList = new ArrayList<JIRAConfigTO>(0);
		try {
			if (jIRAConfigTO.getSelectedProjectList() != null) {
				for (Long projectId : jIRAConfigTO.getSelectedProjectList()) {
					jiraMappingList = (List<JIRAConfigTO>) getHibernateTemplate().find("from JIRAConfigTO where projectId=? ", projectId);
					if (jiraMappingList.size() > 0L) {
						if ("".equals(buProjectAppName)) {
							buProjectAppName = "Projectlevel";
						} else {
							buProjectAppName = "Projectlevel";
						}
					}
				}
			} else {
				for (Long buId : jIRAConfigTO.getSelectedBuList()) {
					jiraMappingList = (List<JIRAConfigTO>) getHibernateTemplate().find("from JIRAConfigTO where buId=? ", buId);
					if (jiraMappingList.size() > 0L) {
						if ("".equals(buProjectAppName)) {
							buProjectAppName = "Bulevel";
						} else {
							buProjectAppName = "Bulevel";
						}
					}
				}
			}
			return buProjectAppName;
		} catch (ConstraintViolationException ce) {
			throw new CMMException("problem encountered SystemConfigurationDaoImpl:policyAlreadyDefined", ce);
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Problem encountered. SystemConfigurationDaoImpl:policyAlreadyDefined", dae);
		}
	}
}