/**
 *
 */
package com.ext.nolio.dao.impl;

import java.sql.Connection;
import java.sql.SQLException;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.engine.SessionFactoryImplementor;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.nolio.dao.NolioProcessParameterDao;
import com.framework.exception.CMMException;
import com.framework.nolio.to.NolioProcessParametersTO;

/**
 * @author 460650
 */
public class NolioProcessParameterDaoImpl extends HibernateDaoSupport implements NolioProcessParameterDao {
	
	@Override
	public void updateParameterValue(long parameterId, String parameterValue) throws CMMException {
	
		NolioProcessParametersTO nolioProcessParametersTO = getNolioParameters(parameterId);
		nolioProcessParametersTO.setParameterValue(parameterValue);
		try {
			getHibernateTemplate().update(nolioProcessParametersTO);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. in updating nolio paramters", he);
		}
	}
	
	@Override
	public NolioProcessParametersTO getNolioParameters(long parameterId) throws CMMException {
	
		try {
			return (NolioProcessParametersTO) getHibernateTemplate().find("from NolioProcessParametersTO where parameterId=?", parameterId).get(0);
		} catch (DataAccessException dae) {
			logger.error("Error in fetching nolio parameters from database for parameterId: " + parameterId);
			throw new CMMException("Error in fetching nolio parameters from database:" + dae.getMessage(), dae);
		} catch (HibernateException he) {
			logger.error("Error in fetching nolio parameters from database for parameterId: " + parameterId);
			throw new CMMException("Error in fetching nolio parameters from database:" + he.getMessage(), he);
		}
	}
	
	@Override
	public long fetchParameters(long serviceId, long applicationReleaseDbId, String rollback) throws CMMException {
	
		long paramMapId;
		Session session = null;
		Connection conn = null;
		java.sql.CallableStatement cs = null;
		try {
			session = getSession();
			SessionFactoryImplementor sfi = (SessionFactoryImplementor) session.getSessionFactory();
			org.hibernate.connection.ConnectionProvider cp = sfi.getConnectionProvider();
			conn = cp.getConnection();
			cs = conn.prepareCall("{call ParamMapping(?,?,?,?)}");
			cs.setInt(1, (int) serviceId);
			cs.setInt(2, (int) applicationReleaseDbId);
			cs.setString(3, rollback);
			cs.registerOutParameter(4, java.sql.Types.INTEGER);
			cs.execute();
			paramMapId = cs.getLong(4);
			if (paramMapId <= 0) {
				throw new CMMException();
			}
			return paramMapId;
		} catch (DataAccessException dae) {
			logger.error("Error in fetching parameters mappingId from database for applicationReleaseDbId: " + applicationReleaseDbId);
			throw new CMMException("Error in fetching parameters mappingId from database:" + dae.getMessage(), dae);
		} catch (HibernateException | SQLException he) {
			logger.error("Error in fetching parameters mappingId from database for applicationReleaseDbId: " + applicationReleaseDbId);
			throw new CMMException("Error in fetching parameters mappingId from database:" + he.getMessage(), he);
		} finally {
			if (cs != null) {
				try {
					cs.close();
				} catch (SQLException e) {
					logger.error("Error in closing connection", e);
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					logger.error("Error in closing connection", e);
				}
			}
			if (session != null) {
				session.close();
			}
		}
	}
}
