package com.ext.dao.impl;

import java.util.ArrayList;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.hibernate.exception.ConstraintViolationException;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.VMWareBareMetalDAO;
import com.framework.common.CMMConstants;
import com.framework.exception.CMMException;
import com.framework.to.MachineTemplateBareMetalTO;
import com.framework.to.MachineTemplateTO;
import com.framework.to.PlatformTemplateBareMetalTO;
import com.framework.to.PlatformTemplateTO;
import com.framework.to.PlatformTypeTO;
import com.framework.to.StatusTO;

public class VMWareBareMetalDAOImpl extends HibernateDaoSupport implements VMWareBareMetalDAO {
	
	@Override
	public List<PlatformTypeTO> getDistributionListforFamilyType(String selectedFamilyType) throws CMMException {
	
		DetachedCriteria criteria = DetachedCriteria.forClass(PlatformTypeTO.class, "platformType");
		int a = selectedFamilyType.indexOf("_");
		String value = selectedFamilyType.substring(0, a);
		String val = value + "%";
		criteria.add(Restrictions.eq("type", "distribution"));
		criteria.add(Restrictions.like("value", val));
		return (List<PlatformTypeTO>) getHibernateTemplate().findByCriteria(criteria);
	}
	
	@Override
	public List<PlatformTypeTO> getAllPlatformTypes() throws CMMException {
	
		try {
			return (List<PlatformTypeTO>) getHibernateTemplate().find("from PlatformTypeTO");
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.VMWareDaoImpl:getAllPlatformTypes", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.VMWareDaoImpl:getAllPlatformTypes", he);
		}
	}
	
	@Override
	public List<PlatformTypeTO> getVersionListforDistribution(String selectedDistribution) throws CMMException {
	
		DetachedCriteria criteria = DetachedCriteria.forClass(PlatformTypeTO.class, "platformType");
		int a = selectedDistribution.indexOf("_");
		String value = selectedDistribution.substring(0, a);
		String val = value + "%";
		criteria.add(Restrictions.eq("type", "version"));
		criteria.add(Restrictions.like("value", val));
		return (List<PlatformTypeTO>) getHibernateTemplate().findByCriteria(criteria);
	}
	
	@Override
	public List<PlatformTypeTO> getPackListforVersion(String selectedVersion) throws CMMException {
	
		DetachedCriteria criteria = DetachedCriteria.forClass(PlatformTypeTO.class, "platformType");
		int a = selectedVersion.indexOf("_");
		String value = selectedVersion.substring(0, a);
		String val = value + "%";
		criteria.add(Restrictions.eq("type", "pack"));
		criteria.add(Restrictions.like("value", val));
		return (List<PlatformTypeTO>) getHibernateTemplate().findByCriteria(criteria);
	}
	
	@Override
	public Boolean addTemplate(MachineTemplateBareMetalTO machineTemplateBareMetalTO, MachineTemplateTO machineTemplateTO, PlatformTemplateBareMetalTO platformTemplateBareMetalTO, PlatformTemplateTO platformTemplateTO) throws CMMException {
	
		try {
			String type_name = CMMConstants.Presentation.MACHINE_TYPE;
			String type = (String) getHibernateTemplate().find("select typeAbbr from MachineTypeTO where type=?", type_name).get(0);
			platformTemplateTO.setType(type);
			platformTemplateTO.setStatus(CMMConstants.Framework.PlatformTemplateStatus.PLATFORM_TEMPLATE_AVAILABLE);
			Long platform_id = (Long) getHibernateTemplate().save(platformTemplateTO);
			platformTemplateBareMetalTO.setPlatformTemplate(platformTemplateTO);
			getHibernateTemplate().save(platformTemplateBareMetalTO);
			machineTemplateTO.setStatus(CMMConstants.Framework.PlatformTemplateStatus.PLATFORM_TEMPLATE_AVAILABLE);
			machineTemplateTO.setPlatformTemplateId(platform_id);
			machineTemplateTO.setType(type);
			getHibernateTemplate().save(machineTemplateTO);
			machineTemplateBareMetalTO.setMachineTemplateTO(machineTemplateTO);
			getHibernateTemplate().save(machineTemplateBareMetalTO);
			return true;
		} catch (ConstraintViolationException ce) {
			logger.error(ce);
			throw new CMMException("Template Name already exists.", ce);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. BareMetalDAOImpl:addTemplate", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. BareMetalDAOImpl:addTemplate", he);
		}
	}
	
	@Override
	public List<PlatformTemplateTO> searchVMWareBareMetal(PlatformTemplateTO platformTemplateTO, MachineTemplateBareMetalTO machineTemplateBareMetalTO) {
	
		String type_name = CMMConstants.Presentation.MACHINE_TYPE;
		String type = (String) getHibernateTemplate().find("select typeAbbr from MachineTypeTO where type=?", type_name).get(0);
		DetachedCriteria criteria = DetachedCriteria.forClass(PlatformTemplateTO.class, "platformTemplate");
		List<PlatformTemplateTO> templateList = new ArrayList<PlatformTemplateTO>();
		if (!"".equalsIgnoreCase(platformTemplateTO.getName())) {
			criteria.add(Restrictions.like("name", "%" + platformTemplateTO.getName() + "%"));
		}
		if (!"".equalsIgnoreCase(platformTemplateTO.getFamily())) {
			criteria.add(Restrictions.like("family", platformTemplateTO.getFamily()));
		}
		criteria.add(Restrictions.like("type", type));
		templateList = (List<PlatformTemplateTO>) getHibernateTemplate().findByCriteria(criteria);
		return templateList;
	}
	
	@Override
	public PlatformTemplateTO getPlatformDetails(PlatformTemplateTO platformTemplateTO) throws CMMException {
	
		PlatformTemplateTO platformTemplateTOResult = new PlatformTemplateTO();
		PlatformTemplateBareMetalTO pto = new PlatformTemplateBareMetalTO();
		MachineTemplateTO mto = new MachineTemplateTO();
		MachineTemplateBareMetalTO mbto = new MachineTemplateBareMetalTO();
		try {
			platformTemplateTOResult = (PlatformTemplateTO) getHibernateTemplate().find("from PlatformTemplateTO where id=?", platformTemplateTO.getId()).get(0);
			pto = (PlatformTemplateBareMetalTO) getHibernateTemplate().find("from PlatformTemplateBareMetalTO pbm where pbm.platformTemplate.id=?", platformTemplateTOResult.getId()).get(0);
			platformTemplateTOResult.setPlatformTemplateBareMetalTO(pto);
			mto = (MachineTemplateTO) getHibernateTemplate().find("from MachineTemplateTO where platformTemplateId=?", platformTemplateTO.getId()).get(0);
			platformTemplateTOResult.setMachineTemplateTO(mto);
			mbto = (MachineTemplateBareMetalTO) getHibernateTemplate().find("from MachineTemplateBareMetalTO m where m.machineTemplateTO.id=?", mto.getId()).get(0);
			platformTemplateTOResult.setMachineTemplateBareMetalTO(mbto);
		} catch (ConstraintViolationException ce) {
			logger.error(ce);
			throw new CMMException("Template Name already exists.", ce);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. BareMetalDAOImpl:addTemplate", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. BareMetalDAOImpl:addTemplate", he);
		}
		return platformTemplateTOResult;
	}
	
	@Override
	public Boolean editTemplateSubmit(MachineTemplateBareMetalTO machineTemplateBareMetalTO, MachineTemplateTO machineTemplateTO, PlatformTemplateBareMetalTO platformTemplateBareMetalTO, PlatformTemplateTO platformTemplateTO) throws CMMException {
	
		try {
			PlatformTemplateTO pt = (PlatformTemplateTO) getHibernateTemplate().find("from PlatformTemplateTO where id=?", platformTemplateTO.getId()).get(0);
			platformTemplateTO.setType(pt.getType());
			platformTemplateTO.setStatus(pt.getStatus());
			platformTemplateTO.setStatusTO(pt.getStatusTO());
			getHibernateTemplate().update(platformTemplateTO);
			platformTemplateBareMetalTO.setPlatformTemplate(platformTemplateTO);
			Long ptId = (Long) getHibernateTemplate().find("select pbm.id from PlatformTemplateBareMetalTO pbm where pbm.platformTemplate.id=?", platformTemplateTO.getId()).get(0);
			platformTemplateBareMetalTO.setId(ptId);
			getHibernateTemplate().update(platformTemplateBareMetalTO);
			Long mid = (Long) getHibernateTemplate().find("select m.id from MachineTemplateTO m where m.platformTemplateId=?", platformTemplateTO.getId()).get(0);
			machineTemplateTO.setId(mid);
			machineTemplateTO.setPlatformTemplateId(platformTemplateTO.getId());
			machineTemplateTO.setStatus(pt.getStatus());
			machineTemplateTO.setType(pt.getType());
			getHibernateTemplate().update(machineTemplateTO);
			MachineTemplateBareMetalTO mbid = (MachineTemplateBareMetalTO) getHibernateTemplate().find("from MachineTemplateBareMetalTO mb where mb.machineTemplateTO.id=?", machineTemplateTO.getId()).get(0);
			machineTemplateBareMetalTO.setMachineTemplateTO(mbid.getMachineTemplateTO());
			machineTemplateBareMetalTO.setId(mbid.getId());
			getHibernateTemplate().update(machineTemplateBareMetalTO);
		} catch (ConstraintViolationException ce) {
			logger.error(ce);
			throw new CMMException("Template Name already exists.", ce);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. BareMetalDAOImpl:editTemplate", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. BareMetalDAOImpl:editTemplate", he);
		} catch (Exception e) {
			logger.error(e);
			throw new CMMException("Problem encountered. BareMetalDAOImpl:editTemplate", e);
		}
		return true;
	}
	
	@Override
	public Boolean checkName(String name) throws CMMException {
	
		Boolean flag = false;
		try {
			List<PlatformTemplateTO> platformTemplateTO = (List<PlatformTemplateTO>) getHibernateTemplate().find("from PlatformTemplateTO where name=?", name);
			if (!platformTemplateTO.isEmpty()) {
				flag = true;
			} else {
				flag = false;
			}
		} catch (ConstraintViolationException ce) {
			logger.error(ce);
			throw new CMMException("Template Name already exists.", ce);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. BareMetalDAOImpl:editTemplate", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. BareMetalDAOImpl:editTemplate", he);
		} catch (Exception e) {
			logger.error(e);
			throw new CMMException("Problem encountered. BareMetalDAOImpl:editTemplate", e);
		}
		return flag;
	}
	
	@Override
	public Boolean checkNameEdit(PlatformTemplateTO platformTemplateTO) throws CMMException {
	
		Boolean flag = false;
		try {
			List<PlatformTemplateTO> platformTemplateTOCheck = (List<PlatformTemplateTO>) getHibernateTemplate().find("from PlatformTemplateTO where name= ? and id<> ?", platformTemplateTO.getName(), platformTemplateTO.getId());
			if (!platformTemplateTOCheck.isEmpty()) {
				flag = true;
			} else {
				flag = false;
			}
		} catch (ConstraintViolationException ce) {
			logger.error(ce);
			throw new CMMException("Template Name already exists.", ce);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. BareMetalDAOImpl:editTemplate", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. BareMetalDAOImpl:editTemplate", he);
		} catch (Exception e) {
			logger.error(e);
			throw new CMMException("Problem encountered. BareMetalDAOImpl:editTemplate", e);
		}
		return flag;
	}
	
	@Override
	public String getHDSize(String name) throws CMMException {
	
		String hdSize = null;
		try {
			Long platform_id = (Long) getHibernateTemplate().find("select id from PlatformTemplateTO where name = ?", name).get(0);
			Long machine_id = (Long) getHibernateTemplate().find("select m.id from MachineTemplateTO m where m.platformTemplateId=?", platform_id).get(0);
			Long mbto = (Long) getHibernateTemplate().find("select m.hardDiskSize from MachineTemplateBareMetalTO m where m.machineTemplateTO.id=?", machine_id).get(0);
			hdSize = mbto.toString();
		} catch (ConstraintViolationException ce) {
			logger.error(ce);
			throw new CMMException("Template Name already exists.", ce);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. BareMetalDAOImpl:editTemplate", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. BareMetalDAOImpl:editTemplate", he);
		} catch (Exception e) {
			logger.error(e);
			throw new CMMException("Problem encountered. BareMetalDAOImpl:editTemplate", e);
		}
		return hdSize;
	}
	
	@Override
	public List<StatusTO> getStatusList() throws CMMException {
	
		try {
			return (List<StatusTO>) getHibernateTemplate().find("from StatusTO where entityId=?", CMMConstants.Framework.Entity.TEMPLATE);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. VMWareDaoImpl:getStatusList", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. VMWareDaoImpl:getStatusList", he);
		}
	}
}
