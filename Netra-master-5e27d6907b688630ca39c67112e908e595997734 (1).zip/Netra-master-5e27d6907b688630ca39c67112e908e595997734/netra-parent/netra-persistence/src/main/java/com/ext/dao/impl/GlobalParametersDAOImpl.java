package com.ext.dao.impl;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.GlobalParametersDAO;
import com.framework.exception.CMMException;
import com.framework.to.GlobalParametersTO;

public class GlobalParametersDAOImpl extends HibernateDaoSupport implements GlobalParametersDAO {
	
	@Override
	public String getGlobalParameterByName(String parameterName) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			return (String) session.createCriteria(GlobalParametersTO.class).add(Restrictions.eq("parameterName", parameterName)).setProjection(Projections.property("parameterValue")).uniqueResult();
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. GlobalParametersDAOImpl: getGlobalParameterByName", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. GlobalParametersDAOImpl: getGlobalParameterByName", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public String getApplicationParameterConfigFileLocation(String fileLocation) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			return (String) session.createCriteria(GlobalParametersTO.class).add(Restrictions.eq("parameterName", fileLocation)).setProjection(Projections.property("parameterValue")).uniqueResult();
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. GlobalParametersDAOImpl: getApplicationParameterConfigFileLocation", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. GlobalParametersDAOImpl: getApplicationParameterConfigFileLocation", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
}
