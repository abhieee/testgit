/**
 *
 */
package com.ext.nolio.dao.impl;

import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.hibernate.exception.ConstraintViolationException;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.nolio.dao.NolioProcessDao;
import com.framework.common.CMMConstants;
import com.framework.exception.CMMException;
import com.framework.nolio.to.NolioProcess;
import com.framework.nolio.to.NolioProcessParametersTO;
import com.framework.nolio.to.NolioProcessSoftwareMapping;
import com.framework.to.NetraNolioProcessParameterMappingTO;
import com.framework.to.NetraParametersTO;
import com.framework.to.SoftwareTO;
import com.framework.to.SoftwareconfigTO;

/**
 * @author 460650
 */
public class NolioProcessDaoImpl extends HibernateDaoSupport implements NolioProcessDao {
	
	private static final Logger Log = Logger.getLogger(NolioProcessDaoImpl.class);
	
	@Override
	public NolioProcess addNolioProcess(NolioProcess nolioProcess) throws CMMException {
	
		NolioProcess createdNolioProcess = null;
		try {
			long nolioProcessId = (Long) getHibernateTemplate().save(nolioProcess);
			createdNolioProcess = getNolioProcessInfoByProcessId(nolioProcessId);
			if (createdNolioProcess == null) {
				Log.debug("No nolio process records found for processId::" + nolioProcessId);
				throw new CMMException("No Nolio process found for processId:: " + nolioProcessId);
			}
		} catch (DataIntegrityViolationException | ConstraintViolationException div) {
			Log.error(div);
			throw new CMMException("Problem encountered.NolioProcessDaoImpl:addNolioProcess", div);
		} catch (DataAccessException | HibernateException dae) {
			Log.error(dae);
			throw new CMMException("Problem encountered.NolioProcessDaoImpl:addNolioProcess", dae);
		}
		return createdNolioProcess;
	}
	
	@Override
	public List<NolioProcess> searchNolioProcess(NolioProcess nolioProcess) throws CMMException {
	
		try {
			List<NolioProcess> nolioprocessList = new ArrayList<NolioProcess>();
			DetachedCriteria criteria = DetachedCriteria.forClass(NolioProcess.class);
			if (nolioProcess.getProcessId() > 0L) {
				criteria.add(Restrictions.eq("processId", nolioProcess.getProcessId()));
			}
			if (!"".equalsIgnoreCase(nolioProcess.getApplicationName().trim())) {
				criteria.add(Restrictions.like("applicationName", nolioProcess.getApplicationName()));
			}
			if (!"".equalsIgnoreCase(nolioProcess.getEnvironmentName().trim())) {
				criteria.add(Restrictions.like("environmentName", nolioProcess.getEnvironmentName()));
			}
			if (!"".equalsIgnoreCase(nolioProcess.getServerType().trim())) {
				criteria.add(Restrictions.like("serverType", nolioProcess.getServerType()));
			}
			if (!"".equalsIgnoreCase(nolioProcess.getProcessFullPath().trim())) {
				criteria.add(Restrictions.like("processFullPath", nolioProcess.getProcessFullPath()));
			}
			List<NolioProcess> temp = (List<NolioProcess>) getHibernateTemplate().findByCriteria(criteria);
			for (NolioProcess hd : temp) {
				nolioprocessList.add(hd);
			}
			return nolioprocessList;
		} catch (DataAccessException | HibernateException dae) {
			Log.error(dae);
			throw new CMMException("Problem encountered.NolioProcessDaoImpl:searchNolioProcess", dae);
		}
	}
	
	@Override
	public List<SoftwareTO> getSoftwareList() throws CMMException {
	
		try {
			List<SoftwareTO> temp = (List<SoftwareTO>) getHibernateTemplate().find("from SoftwareTO");
			if (temp == null) {
				throw new CMMException("No software list found.");
			}
			return temp;
		} catch (DataAccessException | HibernateException dae) {
			Log.error(dae);
			throw new CMMException("Problem encountered.NolioProcessDaoImpl:getSoftwareList", dae);
		}
	}
	
	@Override
	public NolioProcess getNolioProcessInfoByProcessId(long processId) throws CMMException {
	
		NolioProcess nolioProcess = null;
		try {
			nolioProcess = getHibernateTemplate().get(NolioProcess.class, processId);
			if (nolioProcess == null) {
				Log.debug("No nolio process records found for processId::" + processId);
				throw new CMMException("No Nolio process found for processId:: " + processId);
			}
		} catch (DataAccessException | HibernateException e) {
			Log.error("Problem encountered.NolioProcessDaoImpl:getNolioProcessInfoByProcessId" + processId);
			throw new CMMException("Problem encountered.NolioProcessDaoImpl:getNolioProcessInfoByProcessId", e);
		}
		return nolioProcess;
	}
	
	@Override
	public NolioProcess getNolioProcessInfoByProcessName(String processFullPath) throws CMMException {
	
		NolioProcess nolioProcess = null;
		Session session = null;
		try {
			session = getSession();
			nolioProcess = (NolioProcess) session.createCriteria(NolioProcess.class).add(Restrictions.eq("processFullPath", processFullPath)).add(Restrictions.eq("status", CMMConstants.External.Nolio.NOLIO_PROCESS_ACTIVE)).uniqueResult();
			if (nolioProcess == null) {
				Log.debug("No nolio process records found for processName::" + processFullPath);
				throw new CMMException("No Nolio process found for processName:: " + processFullPath);
			}
		} catch (DataAccessException | HibernateException e) {
			Log.error("Problem encountered.NolioProcessDaoImpl:getNolioProcessInfoByProcessName" + processFullPath);
			throw new CMMException("Problem encountered.NolioProcessDaoImpl:getNolioProcessInfoByProcessName", e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return nolioProcess;
	}
	
	@Override
	public NolioProcess getNolioProcessDetails(NolioProcess nolioProcess) throws CMMException {
	
		try {
			return (NolioProcess) getHibernateTemplate().find("from NolioProcessTO where processId=?", nolioProcess.getProcessId()).get(0);
		} catch (DataAccessException | HibernateException dae) {
			Log.error(dae);
			throw new CMMException("Problem encountered.NolioProcessDaoImpl:getNolioProcessDetails", dae);
		}
	}
	
	@Override
	public void editNolioProcessDetails(NolioProcess nolioProcess) throws CMMException {
	
		try {
			NolioProcess nolioprocess = (NolioProcess) getHibernateTemplate().find("from NolioProcessTO where processId=?", nolioProcess.getProcessId()).get(0);
			nolioprocess.setApplicationName(nolioProcess.getApplicationName());
			nolioprocess.setEnvironmentName(nolioProcess.getEnvironmentName());
			nolioprocess.setServerType(nolioProcess.getServerType());
			nolioprocess.setProcessFullPath(nolioProcess.getProcessFullPath());
			nolioprocess.setProcessTag(nolioProcess.getProcessTag());
			getHibernateTemplate().update(nolioprocess);
		} catch (ConstraintViolationException ce) {
			Log.error(ce);
			throw new CMMException("Problem encountered.NolioProcessDaoImpl:editNolioProcessDetails", ce);
		} catch (DataAccessException | HibernateException dae) {
			Log.error(dae);
			throw new CMMException("Problem encountered.NolioProcessDaoImpl:editNolioProcessDetails", dae);
		}
	}
	
	@Override
	public List<Long> getNolioProcessForOS(long osType) throws CMMException {
	
		List<Long> nolioProcessList = new ArrayList<Long>();
		try {
			nolioProcessList = (List<Long>) getHibernateTemplate().find("select processId from NolioProcess where platformMasterTO.platformId=?", osType);
			if (nolioProcessList == null) {
				Log.debug("No nolio process records found for osType::" + osType);
				throw new CMMException("No Nolio process found for osType:: " + osType);
			}
		} catch (DataAccessException | HibernateException e) {
			Log.error("Error in accessing data for osType :NolioProcessDaoImpl:getNolioProcessForOS" + osType);
			throw new CMMException("Error in accessing data for osType :NolioProcessDaoImpl:getNolioProcessForOS", e);
		}
		return nolioProcessList;
	}
	
	@Override
	public List<NolioProcess> getAllNolioProcess() throws CMMException {
	
		List<NolioProcess> process = null;
		Session session = null;
		try {
			session = getSession();
			process = session.createCriteria(NolioProcess.class).add(Restrictions.eq("status", CMMConstants.External.Nolio.NOLIO_PROCESS_ACTIVE)).list();
		} catch (ConstraintViolationException ce) {
			Log.error(ce);
			throw new CMMException("Problem encountered. NolioProcessDaoImpl:getAllNolioProcess", ce);
		} catch (DataAccessException | HibernateException dae) {
			Log.error(dae);
			throw new CMMException("Problem encountered.NolioProcessDaoImpl:getAllNolioProcess", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return process;
	}
	
	@Override
	public boolean defineNolioProcessForSoftware(NolioProcessSoftwareMapping mapping) throws CMMException {
	
		boolean flag = false;
		Long softwareConfigId = null;
		Session session = null;
		Session session1 = null;
		try {
			if (mapping.getSoftwareConfigId() != null) {
				DetachedCriteria criteria1 = DetachedCriteria.forClass(NolioProcessSoftwareMapping.class);
				criteria1.createAlias("softwareConfigTO", "sConfig", CriteriaSpecification.INNER_JOIN);
				criteria1.add(Restrictions.eq("sConfig.deviceId", mapping.getSoftwareId()));
				List<NolioProcessSoftwareMapping> nolioProcessList = (List<NolioProcessSoftwareMapping>) getHibernateTemplate().findByCriteria(criteria1);
				for (NolioProcessSoftwareMapping tempList : nolioProcessList) {
					Long softwareProcessMappingId = tempList.getSoftwareProcessMappingId();
					Transaction tx1 = null;
					session1 = getSession();
					tx1 = session1.beginTransaction();
					String hql = "Delete from NolioProcessSoftwareMapping where softwareProcessMappingId = :softwareProcessMappingId";
					String hql1 = "Delete from CAActivityProcessOrderTO where nolioProcessSoftwareMapping.softwareProcessMappingId = :softwareProcessMappingId";
					Query query1 = session1.createQuery(hql1);
					query1.setParameter("softwareProcessMappingId", softwareProcessMappingId);
					query1.executeUpdate();
					Query query = session1.createQuery(hql);
					query.setParameter("softwareProcessMappingId", softwareProcessMappingId);
					query.executeUpdate();
					tx1.commit();
				}
				softwareConfigId = mapping.getSoftwareConfigId();
			} else {
				softwareConfigId = (Long) getHibernateTemplate().find("select MAX(id) from SoftwareconfigTO where deviceId=?", mapping.getSoftwareId()).get(0);
			}
			SoftwareconfigTO scTO = (SoftwareconfigTO) getHibernateTemplate().find("from SoftwareconfigTO where id=? ", softwareConfigId).get(0);
			Transaction tx = null;
			session = getSession();
			tx = session.beginTransaction();
			String hql = "from NolioProcess where processId in (:NprocessId)";
			Query q = session.createQuery(hql);
			q.setParameterList("NprocessId", mapping.getProcessList());
			List<Object[]> obj = q.list();
			tx.commit();
			NolioProcessSoftwareMapping temp = new NolioProcessSoftwareMapping();
			for (Object process : obj) {
				temp.setSoftwareConfigTO(scTO);
				temp.setNolioProcess((NolioProcess) process);
				getHibernateTemplate().save(temp);
			}
			flag = true;
			return flag;
		} catch (ConstraintViolationException ce) {
			Log.error(ce);
			throw new CMMException("Problem encountered.NolioProcessDaoImpl:defineNolioProcessForSoftware", ce);
		} catch (DataAccessException | HibernateException dae) {
			Log.error(dae);
			throw new CMMException("Problem encountered.NolioProcessDaoImpl:defineNolioProcessForSoftware", dae);
		} finally {
			if (session != null) {
				session.close();
			}
			if (session1 != null) {
				session1.close();
			}
		}
	}
	
	@Override
	public List<NolioProcessParametersTO> getNolioProcessParametersList(Long processId) throws CMMException {
	
		try {
			return (List<NolioProcessParametersTO>) getHibernateTemplate().find("from NolioProcessParametersTO where nolioProcess.processId=? ", processId);
		} catch (DataAccessException | HibernateException dae) {
			Log.error(dae);
			throw new CMMException("Problem encountered. NolioProcessDAOImpl : getNolioProcessParametersList", dae);
		}
	}
	
	@Override
	public List<NetraParametersTO> getNetraParametersList() throws CMMException {
	
		try {
			List<NetraParametersTO> temp = (List<NetraParametersTO>) getHibernateTemplate().find("from NetraParametersTO");
			if (temp == null) {
				throw new CMMException("No netraparameters list found.");
			}
			return temp;
		} catch (DataAccessException | HibernateException dae) {
			Log.error(dae);
			throw new CMMException("Problem encountered.NolioProcessDaoImpl:getNetraParametersList", dae);
		}
	}
	
	@Override
	public void addNetraNolioProcessParameterMapping(List<NolioProcessParametersTO> nolioProcessParametersTOList) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			for (NolioProcessParametersTO nolioProcessParametersTO : nolioProcessParametersTOList) {
				String hql = "update com.framework.nolio.to.NolioProcessParametersTO set netraParameterName = :netraParameterName,netraParameterMapping = :netraParameterMapping ,selectedParameterScope = :selectedParameterScope,parameterValue =:parameterValue  where nolioProcess.processId = :processId and parameterPathName= :parameterPathName";
				String hql1 = "update com.framework.nolio.to.NolioProcessParametersTO set netraParameterName= :netraParameterName ,netraParameterMapping = :netraParameterMapping ,selectedParameterScope = :selectedParameterScope,parameterValue =:parameterValue   where nolioProcess.processId = :processId and parameterPathName= :parameterPathName";
				String netraParameterId = nolioProcessParametersTO.getNetraParameterName();
				if (!"--select--".equalsIgnoreCase(netraParameterId) && !"".equalsIgnoreCase(netraParameterId) && !"-1".equalsIgnoreCase(netraParameterId)) {
					String queryString = "from NetraParametersTO where id=?";
					NetraParametersTO temp1 = (NetraParametersTO) getHibernateTemplate().find(queryString, Long.parseLong(netraParameterId)).get(0);
					Query query = session.createQuery(hql);
					query.setParameter("netraParameterName", temp1.getLabel());
					query.setParameter("netraParameterMapping", "Y");
					query.setParameter("processId", nolioProcessParametersTO.getProcessId());
					query.setParameter("parameterPathName", nolioProcessParametersTO.getParameterPathName());
					query.setParameter("parameterValue", nolioProcessParametersTO.getParameterValue());
					query.setParameter("selectedParameterScope", nolioProcessParametersTO.getSelectedParameterScope());
					query.executeUpdate();
				} else {
					Query query = session.createQuery(hql1);
					query.setParameter("netraParameterName", null);
					query.setParameter("netraParameterMapping", "N");
					query.setParameter("processId", nolioProcessParametersTO.getProcessId());
					query.setParameter("parameterPathName", nolioProcessParametersTO.getParameterPathName());
					query.setParameter("parameterValue", nolioProcessParametersTO.getParameterValue());
					query.setParameter("selectedParameterScope", nolioProcessParametersTO.getSelectedParameterScope());
					query.executeUpdate();
				}
			}
		} catch (DataAccessException | HibernateException dae) {
			Log.error(dae);
			throw new CMMException("Problem encountered.NolioProcessDaoImpl:addNetraNolioProcessParameterMapping", dae);
		}
	}
	
	@Override
	public List<NolioProcessParametersTO> checkForProcessIdInParameterMapping(Long selectedNolioProcessId) throws CMMException {
	
		return (List<NolioProcessParametersTO>) getHibernateTemplate().find("from NetraNolioProcessParameterMappingTO where selectedNolioProcessId=?", selectedNolioProcessId);
	}
	
	@Override
	public void editNetraNolioProcessParameterMapping(List<NetraNolioProcessParameterMappingTO> netraNolioProcessParameterMappingTOList) throws CMMException {
	
		for (NetraNolioProcessParameterMappingTO netraNolioProcessParameterMappingTO : netraNolioProcessParameterMappingTOList) {
			getHibernateTemplate().update(netraNolioProcessParameterMappingTO);
		}
	}
	
	@Override
	public List<NetraNolioProcessParameterMappingTO> getNetraNolioProcessParameterMappingTOList(Long processId) throws CMMException {
	
		return (List<NetraNolioProcessParameterMappingTO>) getHibernateTemplate().find("from NetraNolioProcessParameterMappingTO where selectedNolioProcessId=? ", processId);
	}
	
	@Override
	public Long getNetraParameterId(String netraParam) throws CMMException {
	
		Long processId;
		try {
			processId = (Long) getHibernateTemplate().find("select n.id from NetraParametersTO n where label=? ", netraParam).get(0);
		} catch (DataAccessException | HibernateException dae) {
			Log.error(dae);
			throw new CMMException("Problem encountered. NolioProcessDAOImpl : getNolioProcessParametersList", dae);
		}
		return processId;
	}
}
