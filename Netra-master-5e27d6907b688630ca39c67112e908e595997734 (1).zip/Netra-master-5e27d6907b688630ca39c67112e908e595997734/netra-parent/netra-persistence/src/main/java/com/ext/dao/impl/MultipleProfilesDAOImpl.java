package com.ext.dao.impl;

import java.util.ArrayList;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.hibernate.exception.ConstraintViolationException;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.MultipleProfilesDAO;
import com.framework.common.CMMConstants;
import com.framework.exception.CMMException;
import com.framework.to.ApplicationProfileTO;
import com.framework.to.MultipleProfileDetailsTO;
import com.framework.to.MultipleProfilesTO;
import com.framework.to.StatusTO;

public class MultipleProfilesDAOImpl extends HibernateDaoSupport implements MultipleProfilesDAO {
	
	@Override
	public void addMultipleProfile(MultipleProfilesTO multipleProfilesTO) throws CMMException {
	
		try {
			getHibernateTemplate().save(multipleProfilesTO);
			for (MultipleProfileDetailsTO temp : multipleProfilesTO.getProfDetails()) {
				MultipleProfileDetailsTO multipleProfileDetails = new MultipleProfileDetailsTO();
				multipleProfileDetails.setSelectedApplication(temp.getSelectedApplication());
				multipleProfileDetails.setSelectedProfiles(temp.getSelectedProfiles());
				multipleProfileDetails.setSelectedMultipleProfile(multipleProfilesTO.getId());
				getHibernateTemplate().save(multipleProfileDetails);
			}
		} catch (DataIntegrityViolationException div) {
			logger.error(div);
			throw new CMMException("Problem encountered.", div);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.", dae);
		} catch (ConstraintViolationException e) {
			logger.error(e);
			throw new CMMException("User Name already exists.", e);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.", he);
		}
	}
	
	@Override
	public List<MultipleProfilesTO> searchMultipleProfiles(MultipleProfilesTO multipleprofilesTO) throws CMMException {
	
		try {
			List<MultipleProfilesTO> multipleprofilesList = new ArrayList<MultipleProfilesTO>();
			DetachedCriteria criteria = DetachedCriteria.forClass(MultipleProfilesTO.class);
			if (!"".equalsIgnoreCase(multipleprofilesTO.getName().trim())) {
				criteria.add(Restrictions.like("name", "%" + multipleprofilesTO.getName() + "%"));
			}
			if (multipleprofilesTO.getSelectedStatus() > 0L) {
				criteria.add(Restrictions.eq("statusTO.id", multipleprofilesTO.getSelectedStatus()));
			}
			List<MultipleProfilesTO> temp = (List<MultipleProfilesTO>) getHibernateTemplate().findByCriteria(criteria);
			for (MultipleProfilesTO hd : temp) {
				multipleprofilesList.add(hd);
			}
			return multipleprofilesList;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.Please contact the administartor.", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.Please contact the administartor.", he);
		}
	}
	
	@Override
	public void editMultipleProfiles(MultipleProfilesTO multipleprofilesTO) throws CMMException {
	
		try {
			List<MultipleProfileDetailsTO> mList = new ArrayList<MultipleProfileDetailsTO>();
			multipleprofilesTO.setStatus(multipleprofilesTO.getSelectedStatus());
			getHibernateTemplate().update(multipleprofilesTO);
			mList = (List<MultipleProfileDetailsTO>) getHibernateTemplate().find("from MultipleProfileDetailsTO where selectedMultipleProfile=?", multipleprofilesTO.getId());
			getHibernateTemplate().deleteAll(mList);
			for (MultipleProfileDetailsTO temp : multipleprofilesTO.getProfDetails()) {
				MultipleProfileDetailsTO multipleProfileDetails = new MultipleProfileDetailsTO();
				multipleProfileDetails.setSelectedApplication(temp.getSelectedApplication());
				multipleProfileDetails.setSelectedProfiles(temp.getSelectedProfiles());
				multipleProfileDetails.setSelectedMultipleProfile(multipleprofilesTO.getId());
				getHibernateTemplate().save(multipleProfileDetails);
			}
		} catch (ConstraintViolationException ce) {
			logger.error(ce);
			throw new CMMException(" Name already exists.", ce);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.", he);
		}
	}
	
	@Override
	public MultipleProfilesTO getMultipleProfilesDetails(MultipleProfilesTO multipleprofilesTO) throws CMMException {
	
		try {
			MultipleProfilesTO busTO = (MultipleProfilesTO) getHibernateTemplate().find(" select DISTINCT mpt from MultipleProfilesTO mpt   where Id=?", multipleprofilesTO.getId()).get(0);
			busTO.setSelectedStatus(busTO.getStatus());
			return busTO;
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered.", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.", he);
		}
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public List<StatusTO> getStatusList() throws CMMException {
	
		try {
			return (List<StatusTO>) getHibernateTemplate().find("from StatusTO where entityId=?", CMMConstants.Framework.Entity.PROFILES);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.", he);
		}
	}
	
	@Override
	public List<ApplicationProfileTO> getAllProfiles(Long appId) throws CMMException {
	
		List<ApplicationProfileTO> profTO = new ArrayList<ApplicationProfileTO>();
		try {
			profTO = (List<ApplicationProfileTO>) getHibernateTemplate().find("from ApplicationProfileTO where applicationId=?", appId);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.", he);
		}
		return profTO;
	}
}
