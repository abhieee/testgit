package com.ext.dao.impl;

import java.sql.Connection;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.DateFormatSymbols;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.hibernate.Hibernate;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.classic.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Property;
import org.hibernate.criterion.Restrictions;
import org.hibernate.exception.ConstraintViolationException;
import org.hibernate.transform.Transformers;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.ReportingDAO;
import com.ext.util.DAOConstants;
import com.framework.common.CMMConstants;
import com.framework.common.CMMConstants.Framework.Entity;
import com.framework.exception.CMMException;
import com.framework.report.AppDetailsReportVO;
import com.framework.report.AppRelDetailsVO;
import com.framework.report.ApplicationDetailsReportVO;
import com.framework.report.EnvLinkedResvDetails;
import com.framework.report.EnvLinkedResvMonthDetails;
import com.framework.report.EnvironmentChangeLogReportVO;
import com.framework.report.EnvironmentDetailsReportVO;
import com.framework.report.EnvironmentReservationDetailsReportVO;
import com.framework.report.EnvironmentSnapShotReportVO;
import com.framework.report.HardwareEnvironmentDetailsReportVO;
import com.framework.report.Hardware_summary;
import com.framework.report.ReportRequestVO;
import com.framework.report.SoftwareEnvironmentDetailsReportVO;
import com.framework.report.Software_summary;
import com.framework.report.UntaggedServerDetails;
import com.framework.report.UserStatisticsReportVO;
import com.framework.report.YearlyReservationVO;
import com.framework.to.ReservationTO;
import com.framework.to.UserGroupTO;

public class ReportingDAOImpl extends HibernateDaoSupport implements ReportingDAO {
	
	@Override
	public List<EnvironmentChangeLogReportVO> getEnvironmentChangeLogReportData(ReportRequestVO reportRequestVO) throws CMMException {
	
		List<EnvironmentChangeLogReportVO> environmentChangeLogReportVOdata = new ArrayList<EnvironmentChangeLogReportVO>(0);
		Session session = null;
		try {
			session = (Session) getSession();
			String query = CMMConstants.Presentation.Reporting.QUERY_ENVIRONMENT_CHANGE_LOG_REPORT_VO_DATA;
			query = query + " where app_client.clientId IN( " + reportRequestVO.getSelectedBusinessUnitNew() + ")";
			if ((reportRequestVO.getSelectedProjectNew() != null) && (reportRequestVO.getSelectedProjectNew().size() > 0)) {
				query = query + " and proj.id IN( " + reportRequestVO.getSelectedProjectNew() + ")";
				if ((reportRequestVO.getSelectedApplicationNew() != null) && (reportRequestVO.getSelectedApplicationNew().size() > 0)) {
					query = query + " and app.id IN( " + reportRequestVO.getSelectedApplicationNew() + ")";
					if ((reportRequestVO.getSelectedEnvironmentNew() != null) && (reportRequestVO.getSelectedEnvironmentNew().size() > 0)) {
						query = query + " and e.id IN( " + reportRequestVO.getSelectedEnvironmentNew() + ")";
					}
				}
			}
			List resultWithAliasedBean = session.createQuery(query).setResultTransformer(Transformers.aliasToBean(EnvironmentChangeLogReportVO.class)).list();
			if (!resultWithAliasedBean.isEmpty()) {
				environmentChangeLogReportVOdata = resultWithAliasedBean;
				int size = environmentChangeLogReportVOdata.size();
				for (int i = 0; i < size; i++) {
					String envName = environmentChangeLogReportVOdata.get(i).getEnv_name();
					String swName = environmentChangeLogReportVOdata.get(i).getSw_name();
					String query1 = "select sof_conf_det.version as version from EnvironmentTO as e left join e.environmentDetails as env_det left join env_det.softwareConfig as sof_conf_det  left join sof_conf_det.software as soft_det where e.environmentName=? and soft_det.name =?";
					List<Object> list = (List<Object>) getHibernateTemplate().find(query1, envName, swName);
					if (list.isEmpty() == false) {
						String version = (String) list.get(0);
						String softwareName = swName + "_" + version;
						environmentChangeLogReportVOdata.get(i).setSw_name(softwareName);
					}
				}
				if (environmentChangeLogReportVOdata.isEmpty()) {
					EnvironmentChangeLogReportVO environmentChangeLogReportVO = new EnvironmentChangeLogReportVO();
					List<EnvironmentChangeLogReportVO> environmentChangeLogReportVOdata1 = new ArrayList<EnvironmentChangeLogReportVO>(0);
					environmentChangeLogReportVOdata1.add(environmentChangeLogReportVO);
					String buNameQuery = "select name from ClientTO where id IN(?)";
					String projNameQuery = "select name from ProjectsTO where id IN(?)";
					String envNameQuery = "select environmentName from EnvironmentTO where id=?";
					if ((reportRequestVO.getSelectedBusinessUnitNew().size() > 0) && (reportRequestVO.getSelectedBusinessUnitNew() != null)) {
						String buName = (String) getHibernateTemplate().find(buNameQuery, reportRequestVO.getSelectedBusinessUnitNew()).get(0);
						environmentChangeLogReportVOdata1.get(0).setBu_name(buName);
					}
					if ((reportRequestVO.getSelectedProjectNew().size() > 0) && (reportRequestVO.getSelectedProjectNew() != null)) {
						String projName = (String) getHibernateTemplate().find(projNameQuery, reportRequestVO.getSelectedProjectNew()).get(0);
						environmentChangeLogReportVOdata1.get(0).setProj_name(projName);
					}
					if ((reportRequestVO.getSelectedEnvironmentNew().size() > 0) && (reportRequestVO.getSelectedEnvironmentNew() != null)) {
						String envName = (String) getHibernateTemplate().find(envNameQuery, reportRequestVO.getSelectedEnvironmentNew()).get(0);
						environmentChangeLogReportVOdata1.get(0).setEnv_name(envName);
					}
					environmentChangeLogReportVOdata = environmentChangeLogReportVOdata1;
				}
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("ReportingDAOImpl:getEnvironmentChangeLogReportData", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return environmentChangeLogReportVOdata;
	}
	
	@Override
	public List<EnvironmentSnapShotReportVO> getEnvironmentSnapShotReportData(ReportRequestVO reportRequestVO) throws CMMException {
	
		List<EnvironmentSnapShotReportVO> environmentSnapShotReportVOdata = new ArrayList<EnvironmentSnapShotReportVO>(0);
		Session session = null;
		try {
			session = (Session) getSession();
			String query = CMMConstants.Presentation.Reporting.QUERY_ENVIRONMENT_SNAPSHOT_REPORT_VO_DATA;
			if ((reportRequestVO.getSelectedBusinessUnitNew() != null) && (reportRequestVO.getSelectedBusinessUnitNew().size() > 0)) {
				query = query + " where app_client.clientId IN( " + reportRequestVO.getSelectedBusinessUnitNew() + ")";
				if ((reportRequestVO.getSelectedProjectNew() != null) && (reportRequestVO.getSelectedProjectNew().size() > 0)) {
					query = query + " and proj.id IN( " + reportRequestVO.getSelectedProjectNew() + ")";
					if ((reportRequestVO.getSelectedApplicationNew() != null) && (reportRequestVO.getSelectedApplicationNew().size() > 0)) {
						query = query + " and app.id IN( " + reportRequestVO.getSelectedApplicationNew() + ")";
						if ((reportRequestVO.getSelectedEnvironmentNew() != null) && (reportRequestVO.getSelectedEnvironmentNew().size() > 0)) {
							query = query + " and e.id= " + reportRequestVO.getSelectedEnvironmentNew();
						}
					}
				}
			}
			List resultWithAliasedBean = session.createQuery(query).setResultTransformer(Transformers.aliasToBean(EnvironmentSnapShotReportVO.class)).list();
			if (!resultWithAliasedBean.isEmpty()) {
				environmentSnapShotReportVOdata = resultWithAliasedBean;
				int size = environmentSnapShotReportVOdata.size();
				for (int i = 0; i < size; i++) {
					String envName = environmentSnapShotReportVOdata.get(i).getEnv_name();
					String swName = environmentSnapShotReportVOdata.get(i).getSw_name();
					String query1 = "select sof_conf_det.version as version from EnvironmentTO as e left join e.environmentDetails as env_det left join env_det.softwareConfig as sof_conf_det  left join sof_conf_det.software as soft_det where e.environmentName=? and soft_det.name =?";
					List<Object> list = (List<Object>) getHibernateTemplate().find(query1, envName, swName);
					if (list.isEmpty() == false) {
						String version = (String) list.get(0);
						String softwareName = swName + "_" + version;
						environmentSnapShotReportVOdata.get(i).setSw_name(softwareName);
					}
				}
				if (environmentSnapShotReportVOdata.isEmpty()) {
					EnvironmentSnapShotReportVO environmentSnapShotReportVO = new EnvironmentSnapShotReportVO();
					List<EnvironmentSnapShotReportVO> environmentSnapShotReportVOdata1 = new ArrayList<EnvironmentSnapShotReportVO>(0);
					environmentSnapShotReportVOdata1.add(environmentSnapShotReportVO);
					String buNameQuery = "select name from ClientTO where id=?";
					String projNameQuery = "select name from ProjectsTO where id=?";
					String envNameQuery = "select environmentName from EnvironmentTO where id=?";
					if ((reportRequestVO.getSelectedBusinessUnitNew().size() > 0) && (reportRequestVO.getSelectedBusinessUnitNew() != null)) {
						String buName = (String) getHibernateTemplate().find(buNameQuery, reportRequestVO.getSelectedBusinessUnitNew()).get(0);
						environmentSnapShotReportVOdata1.get(0).setBu_name(buName);
					}
					if ((reportRequestVO.getSelectedProjectNew().size() > 0) && (reportRequestVO.getSelectedProjectNew() != null)) {
						String projName = (String) getHibernateTemplate().find(projNameQuery, reportRequestVO.getSelectedProjectNew()).get(0);
						environmentSnapShotReportVOdata1.get(0).setProj_name(projName);
					}
					if ((reportRequestVO.getSelectedEnvironmentNew().size() > 0) && (reportRequestVO.getSelectedEnvironmentNew() != null)) {
						String envName = (String) getHibernateTemplate().find(envNameQuery, reportRequestVO.getSelectedEnvironmentNew()).get(0);
						environmentSnapShotReportVOdata1.get(0).setEnv_name(envName);
					}
					environmentSnapShotReportVOdata = environmentSnapShotReportVOdata1;
				}
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("ReportingDAOImpl:getEnvironmentSnapShotReportData", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return environmentSnapShotReportVOdata;
	}
	
	@Override
	public List<ApplicationDetailsReportVO> getApplicationDetailsReportData(ReportRequestVO reportRequestVO, List<UserGroupTO> userGroupIds) throws CMMException {
	
		List<ApplicationDetailsReportVO> applicationDetailsReportVOdataModified = new ArrayList<ApplicationDetailsReportVO>(0);
		Session session = null;
		try {
			session = (Session) getSession();
			String query = CMMConstants.Presentation.Reporting.QUERY_APPLICATION_DETAILS_REPORT;
			List<Long> grpIds = new ArrayList<Long>();
			for (UserGroupTO groupTO : userGroupIds) {
				grpIds.add(groupTO.getId());
			}
			if (grpIds.isEmpty()) {
				grpIds.add(-1L);
			}
			if ((reportRequestVO.getSelectedBusinessUnitNew() != null) && !reportRequestVO.getSelectedBusinessUnitNew().isEmpty()) {
				query = query + " and a.businessUnitTO.clientId IN( :bu)";
			}
			if ((reportRequestVO.getSelectedProjectNew() != null) && !reportRequestVO.getSelectedProjectNew().isEmpty()) {
				query = query + " and a.selectedProject IN( :proj)";
			}
			if ((reportRequestVO.getSelectedApplicationNew() != null) && !reportRequestVO.getSelectedApplicationNew().isEmpty()) {
				query = query + " and a.id IN( :app)";
			}
			query = query + " and  app_user_grp.id in (:grpId) and  (appPhase.stat = 'Y' OR appPhase.stat IS NULL)";
			Query q = session.createQuery(query);
			if ((reportRequestVO.getSelectedBusinessUnitNew() != null) && !reportRequestVO.getSelectedBusinessUnitNew().isEmpty()) {
				q.setParameterList("bu", reportRequestVO.getSelectedBusinessUnitNew());
			}
			if ((reportRequestVO.getSelectedProjectNew() != null) && !reportRequestVO.getSelectedProjectNew().isEmpty()) {
				q.setParameterList("proj", reportRequestVO.getSelectedProjectNew());
			}
			if ((reportRequestVO.getSelectedApplicationNew() != null) && !reportRequestVO.getSelectedApplicationNew().isEmpty()) {
				q.setParameterList("app", reportRequestVO.getSelectedApplicationNew());
			}
			if ((grpIds != null) && !grpIds.isEmpty()) {
				q.setParameterList("grpId", grpIds);
			}
			List resultWithAliasedBean = q.setResultTransformer(Transformers.aliasToBean(ApplicationDetailsReportVO.class)).list();
			List<ApplicationDetailsReportVO> applicationDetailsReportVOdata = resultWithAliasedBean;
			HashMap<String, AppDetailsReportVO> appDetailsMap = new HashMap<String, AppDetailsReportVO>();
			if (!applicationDetailsReportVOdata.isEmpty()) {
				for (int i = 0; i < applicationDetailsReportVOdata.size(); i++) {
					if (appDetailsMap.containsKey(applicationDetailsReportVOdata.get(i).getApp_name())) {
						String key = applicationDetailsReportVOdata.get(i).getApp_name();
						appDetailsMap.get(key).getTstPhase().add(applicationDetailsReportVOdata.get(i).getTesting_phase());
						appDetailsMap.get(key).getContactDetails().add(applicationDetailsReportVOdata.get(i).getContact_det());
						appDetailsMap.get(key).getEnvName().add(applicationDetailsReportVOdata.get(i).getEnv_name());
					} else {
						AppDetailsReportVO lAppDetailsReportVO = new AppDetailsReportVO();
						lAppDetailsReportVO.setAppName(applicationDetailsReportVOdata.get(i).getApp_name());
						lAppDetailsReportVO.setAppSupport(applicationDetailsReportVOdata.get(i).getApp_support());
						lAppDetailsReportVO.getContactDetails().add(applicationDetailsReportVOdata.get(i).getContact_det());
						lAppDetailsReportVO.setDesc(applicationDetailsReportVOdata.get(i).getDescp());
						lAppDetailsReportVO.getEnvName().add(applicationDetailsReportVOdata.get(i).getEnv_name());
						lAppDetailsReportVO.setProjName(applicationDetailsReportVOdata.get(i).getProj_name());
						lAppDetailsReportVO.getTstPhase().add(applicationDetailsReportVOdata.get(i).getTesting_phase());
						appDetailsMap.put(applicationDetailsReportVOdata.get(i).getApp_name(), lAppDetailsReportVO);
					}
				}
				Iterator it = appDetailsMap.entrySet().iterator();
				while (it.hasNext()) {
					Map.Entry pair = (Map.Entry) it.next();
					String appName = (String) pair.getKey();
					AppDetailsReportVO lAppDetailsReportVO = (AppDetailsReportVO) pair.getValue();
					Set<String> envName = lAppDetailsReportVO.getEnvName();
					String envNameFinal = "";
					for (String env : envName) {
						envNameFinal = envNameFinal + "," + env;
					}
					Set<String> contactDetail = lAppDetailsReportVO.getContactDetails();
					String contactDetailFinal = "";
					for (String contact : contactDetail) {
						contactDetailFinal = contactDetailFinal + "," + contact;
					}
					Set<String> tstPhase = lAppDetailsReportVO.getTstPhase();
					String testingPhase = "";
					for (String phase : tstPhase) {
						if (phase != null) {
							testingPhase = testingPhase + "," + phase;
						} else {
							testingPhase = testingPhase + ",-";
						}
					}
					ApplicationDetailsReportVO objFinal = new ApplicationDetailsReportVO(lAppDetailsReportVO.getAppSupport(), envNameFinal.substring(1), lAppDetailsReportVO.getDesc(), appName, lAppDetailsReportVO.getProjName(), contactDetailFinal.substring(1), testingPhase.substring(1));
					applicationDetailsReportVOdataModified.add(objFinal);
				}
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("ReportingDAOImpl:getApplicationDetailsReportData", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return applicationDetailsReportVOdataModified;
	}
	
	@Override
	public List<UserStatisticsReportVO> getUserStatisticsReportData(ReportRequestVO reportRequestVO) throws CMMException {
	
		List<UserStatisticsReportVO> userStatisticsReportVOdata = new ArrayList<>(0);
		Session session = null;
		try {
			String formattedFromDate = null;
			String formattedToDate = null;
			DateFormat localFormatter = new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy");
			String dateFromStr = null;
			String dateToStr = null;
			Date dateFrom = null;
			Date dateTo = null;
			Calendar cal = Calendar.getInstance();
			DateFormat formatter1 = new SimpleDateFormat("yyyy-MM-dd");
			session = (Session) getSession();
			String query = CMMConstants.Presentation.Reporting.QUERY_USER_STATISTICS_REPORT_VO_DATA + " where ";
			if ((reportRequestVO.getSelectedBusinessUnitNew() != null) && !reportRequestVO.getSelectedBusinessUnitNew().isEmpty()) {
				query = query + " u.client_id IN( :bu) and";
				if ((reportRequestVO.getSelectedProjectNew() != null) && !reportRequestVO.getSelectedProjectNew().isEmpty()) {
					query = query + " a.project_id IN( :proj) and";
				}
			}
			if ((reportRequestVO.getParameters().get("startdateDate") != null) && (reportRequestVO.getParameters().get("enddateDate") != null)) {
				dateFromStr = localFormatter.format(reportRequestVO.getParameters().get("startdateDate"));
				dateToStr = localFormatter.format(reportRequestVO.getParameters().get("enddateDate"));
				try {
					dateFrom = localFormatter.parse(dateFromStr);
					cal.setTime(dateFrom);
					formattedFromDate = cal.get(Calendar.YEAR) + "-" + (cal.get(Calendar.MONTH) + 1) + "-" + cal.get(Calendar.DATE);
					dateFrom = formatter1.parse(formattedFromDate);
					dateTo = localFormatter.parse(dateToStr);
					cal.setTime(dateTo);
					formattedToDate = cal.get(Calendar.YEAR) + "-" + (cal.get(Calendar.MONTH) + 1) + "-" + cal.get(Calendar.DATE);
					dateTo = formatter1.parse(formattedToDate);
				} catch (ParseException e) {
					throw new CMMException("Error parsing date ", e);
				}
				query = query + " u.created_date between :datefrom and :dateto";
			}
			SQLQuery q = session.createSQLQuery(query);
			if ((reportRequestVO.getSelectedBusinessUnitNew() != null) && !reportRequestVO.getSelectedBusinessUnitNew().isEmpty()) {
				q.setParameterList("bu", reportRequestVO.getSelectedBusinessUnitNew());
			}
			if ((reportRequestVO.getSelectedProjectNew() != null) && !reportRequestVO.getSelectedProjectNew().isEmpty()) {
				q.setParameterList("proj", reportRequestVO.getSelectedProjectNew());
			}
			if ((reportRequestVO.getParameters().get("startdateDate") != null) && (reportRequestVO.getParameters().get("enddateDate") != null)) {
				q.setDate("datefrom", dateFrom);
				q.setDate("dateto", dateTo);
			}
			List resultWithAliasedBean = q.addScalar("created_date").addScalar("id", Hibernate.INTEGER).addScalar("name", Hibernate.STRING).addScalar("fullname", Hibernate.STRING).addScalar("status_desc", Hibernate.STRING).addScalar("role", Hibernate.STRING).setResultTransformer(Transformers.aliasToBean(UserStatisticsReportVO.class)).list();
			userStatisticsReportVOdata = resultWithAliasedBean;
			q.list();
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("ReportingDAOImpl:getUserStatisticsReportData", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return userStatisticsReportVOdata;
	}
	
	/* Saumya,Start */
	@Override
	public List<HardwareEnvironmentDetailsReportVO> getHardwareEnvironmentDetailsReport() throws CMMException {
	
		List<HardwareEnvironmentDetailsReportVO> hardwareEnvironmentDetailsReportVO = new ArrayList<HardwareEnvironmentDetailsReportVO>();
		Session session = null;
		List<Hardware_summary> hardwareSummaryData = new ArrayList<Hardware_summary>();
		List<UntaggedServerDetails> untaggedServerList = new ArrayList<UntaggedServerDetails>();
		try {
			session = (Session) getSession();
			String query = CMMConstants.Presentation.Reporting.HARDWARE_ENVIRONMENT_DETAILS_REPORT;
			List resultWithAliasedBean = session.createQuery(query).setResultTransformer(Transformers.aliasToBean(HardwareEnvironmentDetailsReportVO.class)).list();
			if (!resultWithAliasedBean.isEmpty()) {
				hardwareEnvironmentDetailsReportVO = resultWithAliasedBean;
				hardwareSummaryData = getHardwareSummaryData();
				untaggedServerList = getUntaggedServerList();
				for (int i = 0; i < hardwareEnvironmentDetailsReportVO.size(); i++) {
					HardwareEnvironmentDetailsReportVO temp = hardwareEnvironmentDetailsReportVO.get(i);
					temp.setHw_summ(hardwareSummaryData);
					temp.setUntag_server_list(untaggedServerList);
				}
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("ReportingDAOImpl:getHardwareEnvironmentDetailsReport", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return hardwareEnvironmentDetailsReportVO;
	}
	
	@Override
	public List<Hardware_summary> getHardwareSummaryData() throws CMMException {
	
		Session session = null;
		List<Hardware_summary> hardwareSummaryData = new ArrayList<Hardware_summary>();
		try {
			session = (Session) getSession();
			String query = CMMConstants.Presentation.Reporting.HARDWARE_SUMMARY_QUERY;
			List resultWithAliasedBean = session.createSQLQuery(query).addScalar("count_server", Hibernate.INTEGER).addScalar("hw_status", Hibernate.STRING).setResultTransformer(Transformers.aliasToBean(Hardware_summary.class)).list();
			if (!resultWithAliasedBean.isEmpty()) {
				hardwareSummaryData = resultWithAliasedBean;
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("ReportingDAOImpl:getHardwareSummaryData", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return hardwareSummaryData;
	}
	
	@Override
	public List<UntaggedServerDetails> getUntaggedServerList() throws CMMException {
	
		Session session = null;
		List<UntaggedServerDetails> untaggedServerList = new ArrayList<UntaggedServerDetails>();
		try {
			session = (Session) getSession();
			String query = CMMConstants.Presentation.Reporting.UNTAGGED_SERVER_DETAILS;
			List resultWithAliasedBean = session.createSQLQuery(query).addScalar("ip", Hibernate.STRING).addScalar("hostName", Hibernate.STRING).setResultTransformer(Transformers.aliasToBean(UntaggedServerDetails.class)).list();
			if (!resultWithAliasedBean.isEmpty()) {
				untaggedServerList = resultWithAliasedBean;
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("ReportingDAOImpl:getUntaggedServerList", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return untaggedServerList;
	}
	
	@Override
	public List<YearlyReservationVO> getYearlyReservation(String yearVal) throws CMMException {
	
		List<YearlyReservationVO> yearlyResvData = new ArrayList<YearlyReservationVO>(0);
		Session session = null;
		try {
			session = (Session) getSession();
			String query = CMMConstants.Presentation.Reporting.YEARLY_RESERVATION;
			List resultWithAliasedBean = session.createSQLQuery(query).addScalar("environment_Name", Hibernate.STRING).addScalar("res", Hibernate.STRING).addScalar("starttime", Hibernate.TIMESTAMP).addScalar("res_month", Hibernate.STRING).addScalar("res_week", Hibernate.INTEGER).addScalar("res_mode", Hibernate.STRING).addScalar("type_name", Hibernate.STRING).setParameter("year", yearVal).setResultTransformer(Transformers.aliasToBean(YearlyReservationVO.class)).list();
			yearlyResvData = resultWithAliasedBean;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("ReportingDAOImpl:getYearlyReservation", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return yearlyResvData;
	}
	
	/* Saumya,End */
	public int getLeapDays(boolean isLeapYear) {
	
		int totalDays;
		if (isLeapYear) {
			totalDays = 29;
		} else {
			totalDays = 28;
		}
		return totalDays;
	}
	
	public List<EnvLinkedResvDetails> getListOfWeekendsForCurrentYear(String year) {
	
		List<EnvLinkedResvDetails> envLinkedResvDetailsYearly = new ArrayList<EnvLinkedResvDetails>(0);
		Session session = null;
		try {
			session = (Session) getSession();
			Calendar cal = Calendar.getInstance();
			int currentYear = Integer.parseInt(year);
			int dayOfWeek;
			boolean isLeapYear = true;
			if (((currentYear % 400) == 0) || (((currentYear % 4) == 0) && ((currentYear % 100) != 0))) {
				isLeapYear = true;
			} else {
				isLeapYear = false;
			}
			cal.set(Calendar.YEAR, currentYear);
			cal.set(Calendar.WEEK_OF_YEAR, 1);
			cal.set(Calendar.DAY_OF_WEEK, 1);
			cal.set(Calendar.MONTH, 0);
			cal.set(Calendar.DAY_OF_MONTH, 1);
			Calendar firstDayOfYear = cal;
			String month = firstDayOfYear.getDisplayName(Calendar.MONTH, Calendar.LONG, Locale.getDefault());
			int monthNum = firstDayOfYear.get(Calendar.MONTH);
			for (int i = 0; i < 12; i++) {
				Calendar firstDayOfMonth = cal;
				dayOfWeek = firstDayOfMonth.get(Calendar.DAY_OF_WEEK);
				switch (monthNum) {
					case 0:
						break;
					case 1:
						getLeapDays(isLeapYear);
						break;
					case 2:
						break;
					case 3:
						break;
					case 4:
						break;
					case 5:
						break;
					case 6:
						break;
					case 7:
						break;
					case 8:
						break;
					case 9:
						break;
					case 10:
						break;
					case 11:
						break;
					default:
						break;
				}
				Calendar weekendDate = firstDayOfMonth;
				switch (dayOfWeek) {
					case 1:
						weekendDate.add(Calendar.DAY_OF_MONTH, 6);
						break;
					case 2:
						weekendDate.add(Calendar.DAY_OF_MONTH, 5);
						break;
					case 3:
						weekendDate.add(Calendar.DAY_OF_MONTH, 4);
						break;
					case 4:
						weekendDate.add(Calendar.DAY_OF_MONTH, 3);
						break;
					case 5:
						weekendDate.add(Calendar.DAY_OF_MONTH, 2);
						break;
					case 6:
						weekendDate.add(Calendar.DAY_OF_MONTH, 1);
						break;
					case 7:
						weekendDate.add(Calendar.DAY_OF_MONTH, 0);
						break;
					default:
						weekendDate.add(Calendar.DAY_OF_MONTH, 0);
						break;
				}
				String monthTemp = month;
				while (month.equalsIgnoreCase(monthTemp)) {
					EnvLinkedResvDetails obj1 = new EnvLinkedResvDetails();
					obj1.setMonth_name(month);
					obj1.setWeekend_date(weekendDate.getTime());
					Calendar previousWeekend = weekendDate;
					previousWeekend.add(Calendar.DAY_OF_MONTH, -7);
					obj1.setPrevious_weekend_date(previousWeekend.getTime());
					obj1.setDay("Saturday");
					envLinkedResvDetailsYearly.add(obj1);
					weekendDate.add(Calendar.DAY_OF_MONTH, 14);
					monthTemp = weekendDate.getDisplayName(Calendar.MONTH, Calendar.LONG, Locale.getDefault());
				}
				month = weekendDate.getDisplayName(Calendar.MONTH, Calendar.LONG, Locale.getDefault());
				monthNum = firstDayOfMonth.get(Calendar.MONTH);
				cal.set(currentYear, monthNum, 1);
			}
		} catch (DataAccessException dae) {
			logger.error("ReportingDAOImpl:getListOfWeekendsForCurrentYear", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return envLinkedResvDetailsYearly;
	}
	
	@Override
	public List<EnvironmentReservationDetailsReportVO> getEnvironmentReservationDetailsReportData(ReportRequestVO reportRequestVO) throws CMMException {
	
		List<EnvironmentReservationDetailsReportVO> environmentReservationDetailsReportVOdata = new ArrayList<EnvironmentReservationDetailsReportVO>(0);
		try {
			String durationType = reportRequestVO.getDurationType();
			if ("Monthly".equalsIgnoreCase(durationType)) {
				environmentReservationDetailsReportVOdata = getEnvironmentResvMonthlyReport(reportRequestVO);
			} else if ("Weekly".equalsIgnoreCase(durationType)) {
				environmentReservationDetailsReportVOdata = getEnvironmentResvWeeklyReport(reportRequestVO);
			} else if ("Yearly".equalsIgnoreCase(durationType)) {
				environmentReservationDetailsReportVOdata = getEnvironmentResvYearlyReport(reportRequestVO);
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("ReportingDAOImpl:getEnvironmentReservationDetailsReportData", dae);
		}
		return environmentReservationDetailsReportVOdata;
	}
	
	public List<EnvironmentReservationDetailsReportVO> getEnvironmentResvYearlyReport(ReportRequestVO reportRequestVO) throws CMMException {
	
		List<EnvironmentReservationDetailsReportVO> environmentResvYearlyData = new ArrayList<EnvironmentReservationDetailsReportVO>(0);
		Session session = null;
		Connection conn = null;
		try {
			session = (Session) getSession();
			conn = session.connection();
			String query = CMMConstants.Presentation.Reporting.QUERY_ENVIRONMENT_RESV_SUMMARY_ANNUAL_REPORT;
			query = query + " where r.status.id= " + CMMConstants.Framework.Entity.RESERVATION_STATUS_APPROVED;
			if ((reportRequestVO.getSelectedBusinessUnitNew() != null) && !reportRequestVO.getSelectedBusinessUnitNew().isEmpty()) {
				query = query + " and app_client.clientId IN( :bu)";
			}
			if ((reportRequestVO.getSelectedProjectNew() != null) && !reportRequestVO.getSelectedProjectNew().isEmpty()) {
				query = query + " and proj.id IN( :proj)";
				if ((reportRequestVO.getSelectedApplicationNew() != null) && !reportRequestVO.getSelectedApplicationNew().isEmpty()) {
					query = query + " and app.id IN( :app)";
					if ((reportRequestVO.getSelectedEnvironmentNew() != null) && !reportRequestVO.getSelectedEnvironmentNew().isEmpty()) {
						query = query + " and e.id IN( :env)";
					}
				}
			}
			Query q = session.createQuery(query);
			if ((reportRequestVO.getSelectedBusinessUnitNew() != null) && !reportRequestVO.getSelectedBusinessUnitNew().isEmpty()) {
				q.setParameterList("bu", reportRequestVO.getSelectedBusinessUnitNew());
			}
			if ((reportRequestVO.getSelectedProjectNew() != null) && !reportRequestVO.getSelectedProjectNew().isEmpty()) {
				q.setParameterList("proj", reportRequestVO.getSelectedProjectNew());
			}
			if ((reportRequestVO.getSelectedApplicationNew() != null) && !reportRequestVO.getSelectedApplicationNew().isEmpty()) {
				q.setParameterList("app", reportRequestVO.getSelectedApplicationNew());
			}
			if ((reportRequestVO.getSelectedEnvironmentNew() != null) && !reportRequestVO.getSelectedEnvironmentNew().isEmpty()) {
				q.setParameterList("env", reportRequestVO.getSelectedEnvironmentNew());
			}
			List resultWithAliasedBean = q.setResultTransformer(Transformers.aliasToBean(EnvironmentReservationDetailsReportVO.class)).list();
			environmentResvYearlyData = resultWithAliasedBean;
			if (!environmentResvYearlyData.isEmpty()) {
				for (int j = 0; j < environmentResvYearlyData.size(); j++) {
					List<ReservationTO> resvShared = new ArrayList<ReservationTO>();
					List<ReservationTO> resvDisruptive = new ArrayList<ReservationTO>();
					List<ReservationTO> resvLocked = new ArrayList<ReservationTO>();
					Long envId = environmentResvYearlyData.get(j).getEnv_id();
					List<EnvLinkedResvDetails> envLinkedResvDetailsYearly = new ArrayList<EnvLinkedResvDetails>(0);
					envLinkedResvDetailsYearly = getListOfWeekendsForCurrentYear(reportRequestVO.getParameters().get("year").toString());
					String minResvDateList = "select min(startTime) from ReservationTO r where r.environments.id =?";
					List<Object> list = (List<Object>) getHibernateTemplate().find(minResvDateList, envId);
					if (list.get(0) != null) {
						Date minResvDate = (Date) list.get(0);
						for (int k = 0; k < envLinkedResvDetailsYearly.size(); k++) {
							if (envLinkedResvDetailsYearly.get(k).getWeekend_date().compareTo(minResvDate) >= 0) {
								envLinkedResvDetailsYearly.get(k).getWeekend_date().setHours(0);
								envLinkedResvDetailsYearly.get(k).getWeekend_date().setMinutes(0);
								envLinkedResvDetailsYearly.get(k).getWeekend_date().setSeconds(0);
								Calendar cal = Calendar.getInstance();
								cal.setTime(envLinkedResvDetailsYearly.get(k).getWeekend_date());
								cal.add(Calendar.DAY_OF_YEAR, -6);
								Date weekStartDate = cal.getTime();
								Date weekEndDate = new Date(envLinkedResvDetailsYearly.get(k).getWeekend_date().getTime() + TimeUnit.HOURS.toMillis(23) + TimeUnit.MINUTES.toMillis(59) + +TimeUnit.SECONDS.toMillis(59));
								DetachedCriteria criteria = DetachedCriteria.forClass(ReservationTO.class, "res");
								criteria.add(Restrictions.eq("res.environments.id", envId));
								criteria.add(Restrictions.disjunction().add(Restrictions.conjunction().add(Property.forName("res.endTime").ge(weekStartDate)).add(Property.forName("res.endTime").le(weekEndDate))).add(Restrictions.conjunction().add(Property.forName("res.startTime").le(weekEndDate)).add(Property.forName("res.endTime").ge(weekStartDate))));
								criteria.add(Restrictions.eq("res.disruptive", "S"));
								criteria.add(Restrictions.eq("res.status.id", Entity.RESERVATION_STATUS_APPROVED));
								resvShared = (List<ReservationTO>) getHibernateTemplate().findByCriteria(criteria);
								int sharedCount = resvShared.size();
								envLinkedResvDetailsYearly.get(k).setShared_resv_count(sharedCount);
								DetachedCriteria criteria1 = DetachedCriteria.forClass(ReservationTO.class, "res");
								criteria1.add(Restrictions.eq("res.environments.id", envId));
								criteria1.add(Restrictions.disjunction().add(Restrictions.conjunction().add(Property.forName("res.endTime").ge(weekStartDate)).add(Property.forName("res.endTime").le(weekEndDate))).add(Restrictions.conjunction().add(Property.forName("res.startTime").le(weekEndDate)).add(Property.forName("res.endTime").ge(weekStartDate))));
								criteria1.add(Restrictions.eq("res.disruptive", "D"));
								criteria1.add(Restrictions.eq("res.status.id", Entity.RESERVATION_STATUS_APPROVED));
								resvDisruptive = (List<ReservationTO>) getHibernateTemplate().findByCriteria(criteria1);
								int disruptiveCount = resvDisruptive.size();
								envLinkedResvDetailsYearly.get(k).setDisruptive_resv_count(disruptiveCount);
								DetachedCriteria criteria2 = DetachedCriteria.forClass(ReservationTO.class, "res");
								criteria2.add(Restrictions.eq("res.environments.id", envId));
								criteria2.add(Restrictions.disjunction().add(Restrictions.conjunction().add(Property.forName("res.endTime").ge(weekStartDate)).add(Property.forName("res.endTime").le(weekEndDate))).add(Restrictions.conjunction().add(Property.forName("res.startTime").le(weekEndDate)).add(Property.forName("res.endTime").ge(weekStartDate))));
								criteria2.add(Restrictions.eq("res.disruptive", "L"));
								criteria2.add(Restrictions.eq("res.status.id", Entity.RESERVATION_STATUS_APPROVED));
								resvLocked = (List<ReservationTO>) getHibernateTemplate().findByCriteria(criteria2);
								int lockedCount = resvLocked.size();
								envLinkedResvDetailsYearly.get(k).setLocked_resv_count(lockedCount);
							}
						}
					}
					environmentResvYearlyData.get(j).setWeekendList(envLinkedResvDetailsYearly);
				}
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("ReportingDAOImpl:getEnvironmentResvYearlyReport", dae);
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					logger.error("Error in getEnvironmentResvYearlyReport" + e);
				}
			}
			if (session != null) {
				session.close();
			}
		}
		return environmentResvYearlyData;
	}
	
	public List<EnvironmentReservationDetailsReportVO> getEnvironmentResvMonthlyReport(ReportRequestVO reportRequestVO) throws CMMException {
	
		List<EnvironmentReservationDetailsReportVO> environmentResvMonthlyData = new ArrayList<EnvironmentReservationDetailsReportVO>();
		int numberOfDays;
		String monthNum = reportRequestVO.getParameters().get("month").toString();
		String month = monthNum;
		String yearStr = reportRequestVO.getParameters().get("year").toString();
		int year = Integer.parseInt(yearStr);
		Session session = null;
		Connection conn = null;
		try {
			session = (Session) getSession();
			conn = session.connection();
			String query = CMMConstants.Presentation.Reporting.QUERY_ENVIRONMENT_RESV_SUMMARY_ANNUAL_REPORT;
			query = query + " where r.status.id= " + CMMConstants.Framework.Entity.RESERVATION_STATUS_APPROVED;
			if ((reportRequestVO.getSelectedBusinessUnitNew() != null) && !reportRequestVO.getSelectedBusinessUnitNew().isEmpty()) {
				query = query + " and app_client.clientId IN( :bu)";
			}
			if ((reportRequestVO.getSelectedProjectNew() != null) && !reportRequestVO.getSelectedProjectNew().isEmpty()) {
				query = query + " and proj.id IN( :proj)";
			}
			if ((reportRequestVO.getSelectedApplicationNew() != null) && !reportRequestVO.getSelectedApplicationNew().isEmpty()) {
				query = query + " and app.id IN( :app)";
			}
			if ((reportRequestVO.getSelectedEnvironmentNew() != null) && !reportRequestVO.getSelectedEnvironmentNew().isEmpty()) {
				query = query + " and e.id IN( :env)";
			}
			Query q = session.createQuery(query);
			if ((reportRequestVO.getSelectedBusinessUnitNew() != null) && !reportRequestVO.getSelectedBusinessUnitNew().isEmpty()) {
				q.setParameterList("bu", reportRequestVO.getSelectedBusinessUnitNew());
			}
			if ((reportRequestVO.getSelectedProjectNew() != null) && !reportRequestVO.getSelectedProjectNew().isEmpty()) {
				q.setParameterList("proj", reportRequestVO.getSelectedProjectNew());
			}
			if ((reportRequestVO.getSelectedApplicationNew() != null) && !reportRequestVO.getSelectedApplicationNew().isEmpty()) {
				q.setParameterList("app", reportRequestVO.getSelectedApplicationNew());
			}
			if ((reportRequestVO.getSelectedEnvironmentNew() != null) && !reportRequestVO.getSelectedEnvironmentNew().isEmpty()) {
				q.setParameterList("env", reportRequestVO.getSelectedEnvironmentNew());
			}
			List resultWithAliasedBean = q.setResultTransformer(Transformers.aliasToBean(EnvironmentReservationDetailsReportVO.class)).list();
			environmentResvMonthlyData = resultWithAliasedBean;
			if ("september".equalsIgnoreCase(month) || "april".equalsIgnoreCase(month) || "june".equalsIgnoreCase(month) || "november".equalsIgnoreCase(month)) {
				numberOfDays = 30;
			} else if ("february".equalsIgnoreCase(month)) {
				boolean isLeapYear = true;
				if (((year % 400) == 0) || (((year % 4) == 0) && ((year % 100) != 0))) {
					isLeapYear = true;
				} else {
					isLeapYear = false;
				}
				if (isLeapYear) {
					numberOfDays = 29;
				} else {
					numberOfDays = 28;
				}
			} else {
				numberOfDays = 31;
			}
			ArrayList<Long> listOfEnvProcessed = new ArrayList<Long>();
			for (int k = 0; k < environmentResvMonthlyData.size(); k++) {
				Long envId = environmentResvMonthlyData.get(k).getEnv_id();
				Date minResvDate = null;
				String minResvDateList = "select min(startTime) from ReservationTO r where r.environments.id =?";
				List<Object> list = (List<Object>) getHibernateTemplate().find(minResvDateList, envId);
				if (list.get(0) != null) {
					minResvDate = (Date) list.get(0);
					Calendar cal = Calendar.getInstance();
					cal.setTime(minResvDate);
				}
				Date date1 = new SimpleDateFormat("MMM").parse(month);
				Calendar cal = Calendar.getInstance();
				cal.setTime(date1);
				int selectedMonthNumber = cal.get(Calendar.MONTH);
				Calendar c = Calendar.getInstance();
				c.set(Calendar.MONTH, selectedMonthNumber);
				c.set(Calendar.DAY_OF_MONTH, 1);
				c.set(Calendar.YEAR, year);
				List<ReservationTO> resvShared = new ArrayList<ReservationTO>();
				List<ReservationTO> resvDisruptive = new ArrayList<ReservationTO>();
				List<ReservationTO> resvLocked = new ArrayList<ReservationTO>();
				List<EnvLinkedResvMonthDetails> listEnvResvMonthlyData = new ArrayList<EnvLinkedResvMonthDetails>(numberOfDays);
				for (int j = 0; j < numberOfDays; j++) {
					EnvLinkedResvMonthDetails obj = new EnvLinkedResvMonthDetails();
					listEnvResvMonthlyData.add(obj);
				}
				for (int i = 0; i < listEnvResvMonthlyData.size(); i++) {
					int sharedCount = 0;
					int disruptiveCount = 0;
					int lockedCount = 0;
					listEnvResvMonthlyData.get(i).setYear(String.valueOf(year));
					listEnvResvMonthlyData.get(i).setMonth(month);
					Integer date = i + 1;
					Calendar cald = Calendar.getInstance();
					cald.set(Calendar.MONTH, selectedMonthNumber);
					cald.set(Calendar.DAY_OF_MONTH, date);
					cald.set(Calendar.YEAR, year);
					Date monthDate = cald.getTime();
					listEnvResvMonthlyData.get(i).setMonthDate(monthDate);
					monthDate.setHours(0);
					monthDate.setMinutes(0);
					monthDate.setSeconds(0);
					Date newDate = null;
					newDate = new Date(monthDate.getTime() + TimeUnit.HOURS.toMillis(23) + TimeUnit.MINUTES.toMillis(59) + +TimeUnit.SECONDS.toMillis(59));
					DetachedCriteria criteria = DetachedCriteria.forClass(ReservationTO.class, "res");
					criteria.add(Restrictions.eq("res.environments.id", envId));
					criteria.add(Restrictions.conjunction().add(Property.forName("res.startTime").le(newDate)).add(Property.forName("res.endTime").gt(monthDate)));
					criteria.add(Restrictions.eq("res.disruptive", "S"));
					criteria.add(Restrictions.eq("res.status.id", Entity.RESERVATION_STATUS_APPROVED));
					resvShared = (List<ReservationTO>) getHibernateTemplate().findByCriteria(criteria);
					sharedCount = resvShared.size();
					listEnvResvMonthlyData.get(i).setSharedResvCount(sharedCount);
					DetachedCriteria criteria1 = DetachedCriteria.forClass(ReservationTO.class, "res");
					criteria1.add(Restrictions.eq("res.environments.id", envId));
					criteria1.add(Restrictions.conjunction().add(Property.forName("res.startTime").le(newDate)).add(Property.forName("res.endTime").gt(monthDate)));
					criteria1.add(Restrictions.eq("res.disruptive", "D"));
					criteria1.add(Restrictions.eq("res.status.id", Entity.RESERVATION_STATUS_APPROVED));
					resvDisruptive = (List<ReservationTO>) getHibernateTemplate().findByCriteria(criteria1);
					disruptiveCount = resvDisruptive.size();
					listEnvResvMonthlyData.get(i).setDisruptiveResvCount(disruptiveCount);
					DetachedCriteria criteria2 = DetachedCriteria.forClass(ReservationTO.class, "res");
					criteria2.add(Restrictions.eq("res.environments.id", envId));
					criteria2.add(Restrictions.conjunction().add(Property.forName("res.startTime").le(newDate)).add(Property.forName("res.endTime").gt(monthDate)));
					criteria2.add(Restrictions.eq("res.disruptive", "L"));
					criteria2.add(Restrictions.eq("res.status.id", Entity.RESERVATION_STATUS_APPROVED));
					resvLocked = (List<ReservationTO>) getHibernateTemplate().findByCriteria(criteria2);
					lockedCount = resvLocked.size();
					listEnvResvMonthlyData.get(i).setLockedResvCount(lockedCount);
				}
				environmentResvMonthlyData.get(k).setEnvResvMonthData(listEnvResvMonthlyData);
				listOfEnvProcessed.add(envId);
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("ReportingDAOImpl:getEnvironmentResvMonthlyReport", dae);
		} catch (ParseException e) {
			logger.error("Error in getEnvironmentResvMonthlyReport" + e);
			throw new CMMException("ReportingDAOImpl:getEnvironmentResvMonthlyReport", e);
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					logger.error("Error in getEnvironmentResvYearlyReport" + e);
				}
			}
			if (session != null) {
				session.close();
			}
		}
		return environmentResvMonthlyData;
	}
	
	public List<EnvironmentReservationDetailsReportVO> getEnvironmentResvWeeklyReport(ReportRequestVO reportRequestVO) throws CMMException {
	
		List<EnvironmentReservationDetailsReportVO> environmentResvMonthlyData = new ArrayList<EnvironmentReservationDetailsReportVO>();
		Session session = null;
		Connection conn = null;
		try {
			Date startDate = (Date) reportRequestVO.getParameters().get("startdateDate");
			Calendar caln = Calendar.getInstance();
			caln.setTime(startDate);
			caln.add(Calendar.DATE, 7);
			int monthInt = caln.get(Calendar.MONTH);
			String month = new DateFormatSymbols().getMonths()[monthInt];
			int year = caln.get(Calendar.YEAR);
			session = (Session) getSession();
			conn = session.connection();
			String query = CMMConstants.Presentation.Reporting.QUERY_ENVIRONMENT_RESV_SUMMARY_ANNUAL_REPORT;
			query = query + " where r.status.id= " + CMMConstants.Framework.Entity.RESERVATION_STATUS_APPROVED;
			if ((reportRequestVO.getSelectedBusinessUnitNew() != null) && !reportRequestVO.getSelectedBusinessUnitNew().isEmpty()) {
				query = query + " and app_client.clientId IN( :bu)";
			}
			if ((reportRequestVO.getSelectedProjectNew() != null) && !reportRequestVO.getSelectedProjectNew().isEmpty()) {
				query = query + " and proj.id IN( :proj)";
			}
			if ((reportRequestVO.getSelectedApplicationNew() != null) && !reportRequestVO.getSelectedApplicationNew().isEmpty()) {
				query = query + " and app.id IN( :app)";
			}
			if ((reportRequestVO.getSelectedEnvironmentNew() != null) && !reportRequestVO.getSelectedEnvironmentNew().isEmpty()) {
				query = query + " and e.id IN( :env)";
			}
			Query q = session.createQuery(query);
			if ((reportRequestVO.getSelectedBusinessUnitNew() != null) && !reportRequestVO.getSelectedBusinessUnitNew().isEmpty()) {
				q.setParameterList("bu", reportRequestVO.getSelectedBusinessUnitNew());
			}
			if ((reportRequestVO.getSelectedProjectNew() != null) && !reportRequestVO.getSelectedProjectNew().isEmpty()) {
				q.setParameterList("proj", reportRequestVO.getSelectedProjectNew());
			}
			if ((reportRequestVO.getSelectedApplicationNew() != null) && !reportRequestVO.getSelectedApplicationNew().isEmpty()) {
				q.setParameterList("app", reportRequestVO.getSelectedApplicationNew());
			}
			if ((reportRequestVO.getSelectedEnvironmentNew() != null) && !reportRequestVO.getSelectedEnvironmentNew().isEmpty()) {
				q.setParameterList("env", reportRequestVO.getSelectedEnvironmentNew());
			}
			List resultWithAliasedBean = q.setResultTransformer(Transformers.aliasToBean(EnvironmentReservationDetailsReportVO.class)).list();
			environmentResvMonthlyData = resultWithAliasedBean;
			for (int k = 0; k < environmentResvMonthlyData.size(); k++) {
				Long envId = environmentResvMonthlyData.get(k).getEnv_id();
				Date date1 = new SimpleDateFormat("MMM").parse(month);
				Calendar cal = Calendar.getInstance();
				cal.setTime(date1);
				int selectedMonthNumber = cal.get(Calendar.MONTH);
				Calendar c = Calendar.getInstance();
				c.set(Calendar.MONTH, selectedMonthNumber);
				c.set(Calendar.DAY_OF_MONTH, 1);
				c.set(Calendar.YEAR, year);
				List<ReservationTO> resvShared = new ArrayList<ReservationTO>();
				List<ReservationTO> resvDisruptive = new ArrayList<ReservationTO>();
				List<ReservationTO> resvLocked = new ArrayList<ReservationTO>();
				List<EnvLinkedResvMonthDetails> listEnvResvMonthlyData = new ArrayList<EnvLinkedResvMonthDetails>(7);
				for (int j = 0; j < 7; j++) {
					EnvLinkedResvMonthDetails obj = new EnvLinkedResvMonthDetails();
					listEnvResvMonthlyData.add(obj);
				}
				Date weekDate = startDate;
				for (int i = 0; i < listEnvResvMonthlyData.size(); i++) {
					int sharedCount = 0;
					int disruptiveCount = 0;
					int lockedCount = 0;
					listEnvResvMonthlyData.get(i).setYear(String.valueOf(year));
					String currentMonth = new DateFormatSymbols().getMonths()[weekDate.getMonth()];
					listEnvResvMonthlyData.get(i).setMonth(currentMonth);
					Date newDate = null;
					newDate = new Date(weekDate.getTime() + TimeUnit.HOURS.toMillis(23) + TimeUnit.MINUTES.toMillis(59) + +TimeUnit.SECONDS.toMillis(59));
					listEnvResvMonthlyData.get(i).setMonthDate(weekDate);
					DetachedCriteria criteria = DetachedCriteria.forClass(ReservationTO.class, "res");
					criteria.add(Restrictions.eq("res.environments.id", envId));
					criteria.add(Restrictions.conjunction().add(Property.forName("res.startTime").le(newDate)).add(Property.forName("res.endTime").gt(weekDate)));
					criteria.add(Restrictions.eq("res.disruptive", "S"));
					criteria.add(Restrictions.eq("res.status.id", Entity.RESERVATION_STATUS_APPROVED));
					resvShared = (List<ReservationTO>) getHibernateTemplate().findByCriteria(criteria);
					sharedCount = resvShared.size();
					listEnvResvMonthlyData.get(i).setSharedResvCount(sharedCount);
					DetachedCriteria criteria1 = DetachedCriteria.forClass(ReservationTO.class, "res");
					criteria1.add(Restrictions.eq("res.environments.id", envId));
					criteria1.add(Restrictions.conjunction().add(Property.forName("res.startTime").le(newDate)).add(Property.forName("res.endTime").gt(weekDate)));
					criteria1.add(Restrictions.eq("res.disruptive", "D"));
					criteria1.add(Restrictions.eq("res.status.id", Entity.RESERVATION_STATUS_APPROVED));
					resvDisruptive = (List<ReservationTO>) getHibernateTemplate().findByCriteria(criteria1);
					disruptiveCount = resvDisruptive.size();
					listEnvResvMonthlyData.get(i).setDisruptiveResvCount(disruptiveCount);
					DetachedCriteria criteria2 = DetachedCriteria.forClass(ReservationTO.class, "res");
					criteria2.add(Restrictions.eq("res.environments.id", envId));
					criteria2.add(Restrictions.conjunction().add(Property.forName("res.startTime").le(newDate)).add(Property.forName("res.endTime").gt(weekDate)));
					criteria2.add(Restrictions.eq("res.disruptive", "L"));
					criteria2.add(Restrictions.eq("res.status.id", Entity.RESERVATION_STATUS_APPROVED));
					resvLocked = (List<ReservationTO>) getHibernateTemplate().findByCriteria(criteria2);
					lockedCount = resvLocked.size();
					listEnvResvMonthlyData.get(i).setLockedResvCount(lockedCount);
					Calendar calendar = Calendar.getInstance();
					calendar.setTime(weekDate);
					calendar.add(Calendar.DATE, 1);
					weekDate = calendar.getTime();
				}
				environmentResvMonthlyData.get(k).setEnvResvMonthData(listEnvResvMonthlyData);
			}
		} catch (ParseException e) {
			logger.error("Error in getEnvironmentResvWeeklyReport" + e);
			throw new CMMException("ReportingDAOImpl:getEnvironmentResvWeeklyReport", e);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("ReportingDAOImpl:getEnvironmentResvWeeklyReport", dae);
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					logger.error("Error in getEnvironmentResvWeeklyReport" + e);
				}
			}
			if (session != null) {
				session.close();
			}
		}
		return environmentResvMonthlyData;
	}
	
	@Override
	public List<SoftwareEnvironmentDetailsReportVO> getSoftwareEnvironmentDetailsReport() throws CMMException {
	
		List<SoftwareEnvironmentDetailsReportVO> softwareEnvironmentDetailsReportVO = new ArrayList<SoftwareEnvironmentDetailsReportVO>();
		Session session = null;
		List<Software_summary> softwareSummaryData = new ArrayList<Software_summary>();
		try {
			session = (Session) getSession();
			String query = CMMConstants.Presentation.Reporting.SOFTWARE_ENVIRONMENT_DETAILS_REPORT;
			List resultWithAliasedBean = session.createQuery(query).setResultTransformer(Transformers.aliasToBean(SoftwareEnvironmentDetailsReportVO.class)).list();
			if (!resultWithAliasedBean.isEmpty()) {
				softwareEnvironmentDetailsReportVO = resultWithAliasedBean;
				softwareSummaryData = getSoftwareSummaryData();
				for (int i = 0; i < softwareEnvironmentDetailsReportVO.size(); i++) {
					SoftwareEnvironmentDetailsReportVO temp = softwareEnvironmentDetailsReportVO.get(i);
					temp.setSoftware_summary(softwareSummaryData);
				}
			}
		} catch (ConstraintViolationException ce) {
			logger.error("Problem encountered. ReportingDAOImpl : getSoftwareEnvironmentDetailsReport", ce);
			throw new CMMException(DAOConstants.ERROR_MESSAGE, ce);
		} catch (DataAccessException dae) {
			logger.error("Problem encountered. ReportingDAOImpl : getSoftwareEnvironmentDetailsReport", dae);
			throw new CMMException(DAOConstants.ERROR_MESSAGE, dae);
		} catch (HibernateException he) {
			logger.error("Problem encountered. ReportingDAOImpl : getSoftwareEnvironmentDetailsReport", he);
			throw new CMMException(DAOConstants.ERROR_MESSAGE, he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return softwareEnvironmentDetailsReportVO;
	}
	
	@Override
	public List<Software_summary> getSoftwareSummaryData() throws CMMException {
	
		Session session = null;
		List<Software_summary> softwareSummaryData = new ArrayList<Software_summary>();
		try {
			session = (Session) getSession();
			String query = CMMConstants.Presentation.Reporting.SOFTWARE_SUMMARY_QUERY;
			List resultWithAliasedBean = session.createSQLQuery(query).addScalar("software_count", Hibernate.INTEGER).addScalar("status", Hibernate.STRING).setResultTransformer(Transformers.aliasToBean(Software_summary.class)).list();
			if (!resultWithAliasedBean.isEmpty()) {
				softwareSummaryData = resultWithAliasedBean;
			}
		} catch (ConstraintViolationException ce) {
			logger.error("Problem encountered. ReportingDAOImpl : getSoftwareSummaryData", ce);
			throw new CMMException(DAOConstants.ERROR_MESSAGE, ce);
		} catch (DataAccessException dae) {
			logger.error("Problem encountered. ReportingDAOImpl : getSoftwareSummaryData", dae);
			throw new CMMException(DAOConstants.ERROR_MESSAGE, dae);
		} catch (HibernateException he) {
			logger.error("Problem encountered. ReportingDAOImpl : getSoftwareSummaryData", he);
			throw new CMMException(DAOConstants.ERROR_MESSAGE, he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return softwareSummaryData;
	}
	
	@Override
	public List<EnvironmentDetailsReportVO> getEnvironmentDetailsReport(ReportRequestVO reportRequestVO) throws CMMException {
	
		List<EnvironmentDetailsReportVO> environmentDetailsReportVO = new ArrayList<EnvironmentDetailsReportVO>();
		Session session = null;
		try {
			session = (Session) getSession();
			String query = CMMConstants.Presentation.Reporting.ENVIRONMENT_CHANGE_LOG_DETAILS;
			if ((reportRequestVO.getSelectedBusinessUnitNew() != null) && !reportRequestVO.getSelectedBusinessUnitNew().isEmpty()) {
				query = query + " and c.id IN( :bu)";
				if ((reportRequestVO.getSelectedProjectNew() != null) && !reportRequestVO.getSelectedProjectNew().isEmpty()) {
					query = query + " and p.id IN( :proj)";
					if ((reportRequestVO.getSelectedApplicationNew() != null) && !reportRequestVO.getSelectedApplicationNew().isEmpty()) {
						query = query + " and a.id IN( :app)";
						if ((reportRequestVO.getSelectedEnvironmentNew() != null) && !reportRequestVO.getSelectedEnvironmentNew().isEmpty()) {
							query = query + " and e.id IN( :env) ";
						}
					}
				}
			}
			Query q = session.createQuery(query);
			if ((reportRequestVO.getSelectedBusinessUnitNew() != null) && !reportRequestVO.getSelectedBusinessUnitNew().isEmpty()) {
				q.setParameterList("bu", reportRequestVO.getSelectedBusinessUnitNew());
			}
			if ((reportRequestVO.getSelectedProjectNew() != null) && !reportRequestVO.getSelectedProjectNew().isEmpty()) {
				q.setParameterList("proj", reportRequestVO.getSelectedProjectNew());
			}
			if ((reportRequestVO.getSelectedApplicationNew() != null) && !reportRequestVO.getSelectedApplicationNew().isEmpty()) {
				q.setParameterList("app", reportRequestVO.getSelectedApplicationNew());
			}
			if ((reportRequestVO.getSelectedEnvironmentNew() != null) && !reportRequestVO.getSelectedEnvironmentNew().isEmpty()) {
				q.setParameterList("env", reportRequestVO.getSelectedEnvironmentNew());
			}
			List resultWithAliasedBean = q.setResultTransformer(Transformers.aliasToBean(EnvironmentDetailsReportVO.class)).list();
			if (!resultWithAliasedBean.isEmpty()) {
				environmentDetailsReportVO = resultWithAliasedBean;
			}
		} catch (ConstraintViolationException ce) {
			logger.error("Problem encountered. ReportingDAOImpl : getEnvironmentDetailsReport", ce);
			throw new CMMException(DAOConstants.ERROR_MESSAGE, ce);
		} catch (DataAccessException dae) {
			logger.error("Problem encountered. ReportingDAOImpl : getEnvironmentDetailsReport", dae);
			throw new CMMException(DAOConstants.ERROR_MESSAGE, dae);
		} catch (HibernateException he) {
			logger.error("Problem encountered. ReportingDAOImpl : getEnvironmentDetailsReport", he);
			throw new CMMException(DAOConstants.ERROR_MESSAGE, he);
		} catch (Exception he) {
			logger.error("Problem encountered. ReportingDAOImpl : getEnvironmentDetailsReport", he);
			throw new CMMException(DAOConstants.ERROR_MESSAGE, he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return environmentDetailsReportVO;
	}
	
	@Override
	public Map<String, String> getTestExecReportFilterNames(String bULst, String projLst, String appLst) throws CMMException {
	
		HashMap<String, String> filterMap = new HashMap<String, String>();
		Session session = null;
		try {
			String buName = "";
			String projectName = "";
			String appName = "";
			session = (Session) getSession();
			if ((bULst != null) && !"".equals(bULst)) {
				String query = "select c.name from ClientTO c where c.id IN(" + bULst + ")";
				Query q = session.createQuery(query);
				List buLst = q.list();
				for (Object bu : buLst) {
					buName = buName + "," + (String) bu;
				}
				buName = buName.substring(1);
			}
			if ((projLst != null) && !"".equals(projLst)) {
				String query = "select p.name from ProjectsTO p where p.id IN(" + projLst + ")";
				Query q1 = session.createQuery(query);
				List prjLst = q1.list();
				for (Object pr : prjLst) {
					projectName = projectName + "," + (String) pr;
				}
				projectName = projectName.substring(1);
			}
			if ((appLst != null) && !"".equals(appLst)) {
				String query = "select a.appName from ApplicationTO a where a.id IN(" + appLst + ")";
				Query q2 = session.createQuery(query);
				List applicLst = q2.list();
				for (Object app : applicLst) {
					appName = appName + "," + (String) app;
				}
				appName = appName.substring(1);
			}
			filterMap.put("bU", buName);
			filterMap.put("project", projectName);
			filterMap.put("app", appName);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("ReportingDAOImpl:getTestExecReportFilterNames", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return filterMap;
	}
	
	@Override
	public AppRelDetailsVO getReleaseDetailsFromRequest(Long relID) throws CMMException {
	
		Session session = null;
		AppRelDetailsVO lAppRelDetailsVO = new AppRelDetailsVO();
		List<AppRelDetailsVO> lAppRelDetailsVOLst = new ArrayList<AppRelDetailsVO>();
		try {
			session = (Session) getSession();
			String query = CMMConstants.Presentation.Reporting.QUERY_REL_DETAIL_FROM_REQUEST;
			Query q = session.createQuery(query);
			q.setParameter(0, relID);
			lAppRelDetailsVOLst = q.setResultTransformer(Transformers.aliasToBean(AppRelDetailsVO.class)).list();
			if (!lAppRelDetailsVOLst.isEmpty()) {
				lAppRelDetailsVO = lAppRelDetailsVOLst.get(0);
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : getReleaseDetailsFromRequest", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : getReleaseDetailsFromRequest", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return lAppRelDetailsVO;
	}
}
