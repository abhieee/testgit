package com.ext.dao.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.exception.ConstraintViolationException;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.TaskManagementDAO;
import com.framework.common.CMMConstants;
import com.framework.exception.CMMException;
import com.framework.nolio.to.NolioProcess;
import com.framework.puppetMaster.to.PuppetProcess;
import com.framework.to.CAReleaseActivityTO;
import com.framework.to.ManifestTypeTO;
import com.framework.to.NolioTaskMappingTO;
import com.framework.to.PuppetTaskMappingTO;
import com.framework.to.RepositoryTO;
import com.framework.to.ScriptParameterMapTO;
import com.framework.to.ScriptTaskMappingTO;
import com.framework.to.TaskManagementTO;
import com.framework.to.UdeployTaskMappingTO;
import com.framework.udeploy.to.UdeployProcess;
import com.framework.utility.DateUtils;

public class TaskManagementDAOImpl extends HibernateDaoSupport implements TaskManagementDAO {
	
	@Override
	public TaskManagementTO addTask(TaskManagementTO taskTO) throws CMMException {
	
		try {
			TaskManagementTO t = new TaskManagementTO();
			t.setTaskname(taskTO.getTaskname());
			t.setCreatedDate(DateUtils.getStartTime(new Date()));
			t.setSelectedActivity(taskTO.getSelectedActivity());
			t.setSelectedManifest(taskTO.getSelectedManifest());
			t.setCreatedById(taskTO.getCreatedById());
			t.setDescription(taskTO.getDescription());
			taskTO.setCreatedDate(DateUtils.getStartTime(new Date()));
			ManifestTypeTO manifest = (ManifestTypeTO) getHibernateTemplate().find("from ManifestTypeTO where id=?", taskTO.getSelectedManifest()).get(0);
			CAReleaseActivityTO activity = new CAReleaseActivityTO();
			if (t.getSelectedActivity() == -1L) {
				activity.setActivityName(taskTO.getNewActivityName());
				getHibernateTemplate().save(activity);
			} else {
				activity = (CAReleaseActivityTO) getHibernateTemplate().find("from CAReleaseActivityTO where activityId=?", taskTO.getSelectedActivity()).get(0);
				t.setcAReleaseActivityTO(activity);
			}
			t.setcAReleaseActivityTO(activity);
			t.setManifestTypeTO(manifest);
			if (taskTO.getSelectedManifest() == CMMConstants.Framework.AutomationTool.NOLIO_ID) {
				Set<NolioTaskMappingTO> noliomaplist = new HashSet<NolioTaskMappingTO>();
				for (int i = 0; i < taskTO.getSelectedProcess().size(); i++) {
					NolioTaskMappingTO noliomap = new NolioTaskMappingTO();
					noliomap.setProcessOrder(i);
					NolioProcess nolioprocess = new NolioProcess();
					nolioprocess.setProcessId(taskTO.getSelectedProcess().get(i));
					noliomap.setNolioProcess(nolioprocess);
					noliomap.setTaskManagementTO(t);
					noliomaplist.add(noliomap);
				}
				t.getNolioTaskMapping().addAll(noliomaplist);
			}
			if (taskTO.getSelectedManifest() == CMMConstants.Framework.AutomationTool.UDEPLOY_ID) {
				Set<UdeployTaskMappingTO> udeploymaplist = new HashSet<UdeployTaskMappingTO>();
				for (int i = 0; i < taskTO.getSelectedProcess().size(); i++) {
					UdeployTaskMappingTO udeploymap = new UdeployTaskMappingTO();
					udeploymap.setProcessOrder(i);
					UdeployProcess udeployProcess = new UdeployProcess();
					udeployProcess.setProcessId(taskTO.getSelectedProcess().get(i));
					udeploymap.setUdeployProcess(udeployProcess);
					udeploymap.setTaskManagementTO(t);
					udeploymaplist.add(udeploymap);
				}
				t.getUdeployTaskMapping().addAll(udeploymaplist);
			}
			if (taskTO.getSelectedManifest() == CMMConstants.Framework.AutomationTool.PUPPET_ID) {
				Set<PuppetTaskMappingTO> puppetmaplist = new HashSet<PuppetTaskMappingTO>();
				for (int i = 0; i < taskTO.getSelectedProcess().size(); i++) {
					PuppetTaskMappingTO puppetmap = new PuppetTaskMappingTO();
					puppetmap.setProcessOrder(i);
					PuppetProcess puppetprocess = new PuppetProcess();
					puppetprocess.setProcessId(taskTO.getSelectedProcess().get(i));
					puppetmap.setPuppetProcess(puppetprocess);
					puppetmap.setTaskManagementTO(t);
					puppetmaplist.add(puppetmap);
				}
				t.getPuppetTaskMapping().addAll(puppetmaplist);
			}
			if (taskTO.getSelectedManifest() == CMMConstants.Framework.AutomationTool.SCRIPT_ID) {
				Set<ScriptTaskMappingTO> scriptmaplist = new HashSet<ScriptTaskMappingTO>();
				ScriptTaskMappingTO scriptmap = new ScriptTaskMappingTO();
				scriptmap.setUploadFlag(taskTO.getUploadScript());
				scriptmap.setFilePath(taskTO.getFilePath());
				scriptmap.setTargetLocation(taskTO.getTargetLocation());
				RepositoryTO repo = new RepositoryTO();
				repo.setId(taskTO.getRepoId());
				scriptmap.setRepository(repo);
				if ("No".equalsIgnoreCase(taskTO.getUploadScript())) {
					scriptmap.setFilesName(taskTO.getScriptname());
					t.setScriptname(taskTO.getScriptname());
				} else {
					scriptmap.setUploadSource(taskTO.getUploadSource());
					scriptmap.setFilesName(taskTO.getScriptname());
				}
				scriptmap.setTaskManagementTO(t);
				Set<ScriptParameterMapTO> scriptParameterMapList = new HashSet<ScriptParameterMapTO>();
				if (!taskTO.getScriptParameterMap().isEmpty() && !"".equalsIgnoreCase(taskTO.getScriptParameterMap().get(0).getParameterName())) {
					for (ScriptParameterMapTO params : taskTO.getScriptParameterMap()) {
						ScriptParameterMapTO paramList = new ScriptParameterMapTO();
						paramList.setParameterName(params.getParameterName());
						if (!("-1".equalsIgnoreCase(params.getSelectedParameterValues()) || "".equalsIgnoreCase(params.getSelectedParameterValues()) || (params.getSelectedParameterValues() == null))) {
							paramList.setNetraParameterMapping("Y");
							paramList.setSelectedParameterValues(params.getSelectedParameterValues());
						} else {
							paramList.setNetraParameterMapping("N");
						}
						if (!("-1".equalsIgnoreCase(params.getSelectedParameterScopes()) || "".equalsIgnoreCase(params.getSelectedParameterScopes()) || (params.getSelectedParameterScopes() == null))) {
							paramList.setSelectedParameterScopes(params.getSelectedParameterScopes());
						} else {
							paramList.setSelectedParameterScopes(null);
						}
						paramList.setDefaultParameterValues(params.getDefaultParameterValues());
						paramList.setMappedScript(scriptmap);
						scriptParameterMapList.add(paramList);
					}
				}
				scriptmap.setScriptParameterMap(scriptParameterMapList);
				repo.setScriptTaskMappingTO(scriptmaplist);
				scriptmaplist.add(scriptmap);
				t.setScriptTaskMappingTO(scriptmaplist);
			}
			getHibernateTemplate().save(t);
			return t;
		} catch (DataIntegrityViolationException div) {
			logger.error(div);
			throw new CMMException("Problem encountered.TaskManagementDAOImpl:addTask", div);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.TaskManagementDAOImpl:addTask", dae);
		} catch (ConstraintViolationException e) {
			logger.error(e);
			throw new CMMException("Problem encountered.TaskManagementDAOImpl:addTask", e);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.TaskManagementDAOImpl:addTask", he);
		}
	}
	
	@Override
	public List<TaskManagementTO> searchTask(TaskManagementTO taskTO) throws CMMException {
	
		Session session = getSession();
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(TaskManagementTO.class, "tasksTO");
			List<Long> manifest = new ArrayList<Long>();
			for (ManifestTypeTO m : taskTO.getAllmanifest()) {
				manifest.add(m.getId());
			}
			if (!"".equalsIgnoreCase(taskTO.getTaskname().trim())) {
				criteria.add(Restrictions.like("taskname", "%" + taskTO.getTaskname() + "%"));
			}
			if (taskTO.getSelectedActivity() != 0) {
				criteria.add(Restrictions.like("cAReleaseActivityTO.activityId", taskTO.getSelectedActivity()));
			}
			criteria.add(Restrictions.in("manifestTypeTO.id", manifest));
			if (taskTO.getSearchCount() == 0) {
				return (List<TaskManagementTO>) getHibernateTemplate().findByCriteria(criteria);
			}
			criteria.getExecutableCriteria(session).setFirstResult(taskTO.getFirstResult());
			criteria.getExecutableCriteria(session).setMaxResults(taskTO.getTableSize());
			return (List<TaskManagementTO>) getHibernateTemplate().findByCriteria(criteria);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.TaskManagementDAOImpl:searchTask", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.TaskManagementDAOImpl:searchTask", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public boolean checkName(TaskManagementTO taskTO) throws CMMException {
	
		boolean flag = false;
		try {
			if (taskTO.getId() == 0L) {
				List<TaskManagementTO> task = (List<TaskManagementTO>) getHibernateTemplate().find("from TaskManagementTO where taskname=?", taskTO.getTaskname());
				if (!task.isEmpty()) {
					flag = true;
				} else {
					flag = false;
				}
			} else {
				List<TaskManagementTO> task = (List<TaskManagementTO>) getHibernateTemplate().find("from TaskManagementTO where taskname=? and id <> ?", taskTO.getTaskname(), taskTO.getId());
				if (!task.isEmpty()) {
					flag = true;
				} else {
					flag = false;
				}
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.TaskManagementDAOImpl:checkName.", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.TaskManagementDAOImpl:checkName.", he);
		}
		return flag;
	}
	
	@Override
	public List<TaskManagementTO> fetchTaskList(Long automationToolId) throws CMMException {
	
		try {
			Long automationToolSSH = CMMConstants.Framework.AutomationTool.SCRIPT_ID;
			List<TaskManagementTO> taskList = new ArrayList<TaskManagementTO>(0);
			List<TaskManagementTO> allTaskList = (List<TaskManagementTO>) getHibernateTemplate().find("from TaskManagementTO");
			for (TaskManagementTO task : allTaskList) {
				if ((task.getManifestTypeTO().getId() == automationToolId) || (task.getManifestTypeTO().getId() == automationToolSSH)) {
					taskList.add(task);
				}
			}
			return taskList;
		} catch (DataIntegrityViolationException div) {
			logger.error(div);
			throw new CMMException("Problem encountered.TaskManagementDAOImpl:fetchTaskList", div);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.TaskManagementDAOImpl:fetchTaskList", dae);
		} catch (ConstraintViolationException e) {
			logger.error(e);
			throw new CMMException("Problem encountered.TaskManagementDAOImpl:fetchTaskList", e);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.TaskManagementDAOImpl:fetchTaskList", he);
		}
	}
	
	@Override
	public List<TaskManagementTO> fetchTasksAndNolioProcesses(Long activityId, Long mappedSoftwareId, Long automationToolId) throws CMMException {
	
		try {
			List<TaskManagementTO> tasksContaingProcessesList = new ArrayList<TaskManagementTO>(0);
			List<Object[]> taskList = (List<Object[]>) getHibernateTemplate().find("from SoftwareTaskMappingTO s, TaskManagementTO t where s.taskId=t.id and s.softwareConfigId=? and t.cAReleaseActivityTO.id=? and t.manifestTypeTO.id=? order by s.taskOrder asc and t.nolioTaskMapping.processOrder asc", mappedSoftwareId, activityId, automationToolId);
			for (Object[] taskObj : taskList) {
				TaskManagementTO taskMgmtTo = (TaskManagementTO) taskObj[1];
				tasksContaingProcessesList.add(taskMgmtTo);
			}
			return tasksContaingProcessesList;
		} catch (DataIntegrityViolationException div) {
			logger.error(div);
			throw new CMMException("Problem encountered.TaskManagementDAOImpl:fetchTaskList", div);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.TaskManagementDAOImpl:fetchTaskList", dae);
		} catch (ConstraintViolationException e) {
			logger.error(e);
			throw new CMMException("Problem encountered.TaskManagementDAOImpl:fetchTaskList", e);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.TaskManagementDAOImpl:fetchTaskList", he);
		}
	}
	
	@Override
	public List<TaskManagementTO> fetchNolioProcessesAndScriptsForTasks(Long activityId, Long mappedSoftwareId, Long automationToolId) throws CMMException {
	
		try {
			Long automationToolSSH = CMMConstants.Framework.AutomationTool.SCRIPT_ID;
			List<TaskManagementTO> tasksContaingProcessesList = new ArrayList<TaskManagementTO>(0);
			List<Object[]> taskList = (List<Object[]>) getHibernateTemplate().find("from SoftwareTaskMappingTO s, TaskManagementTO t where s.taskId=t.id and s.softwareConfigId=? and t.cAReleaseActivityTO.id=?   order by s.taskOrder asc and order by t.nolioTaskMapping.processOrder asc", mappedSoftwareId, activityId);
			for (Object[] taskObj : taskList) {
				TaskManagementTO taskMgmtTo = (TaskManagementTO) taskObj[1];
				if ((taskMgmtTo.getManifestTypeTO().getId() == automationToolId) || (taskMgmtTo.getManifestTypeTO().getId() == automationToolSSH)) {
					tasksContaingProcessesList.add(taskMgmtTo);
				}
			}
			for (TaskManagementTO taskObj : tasksContaingProcessesList) {
				Set<NolioTaskMappingTO> scriptTaskMappingTO = new HashSet<NolioTaskMappingTO>();
				List<NolioTaskMappingTO> processes = (List<NolioTaskMappingTO>) getHibernateTemplate().find("from NolioTaskMappingTO s where s.taskManagementTO.id=? order by s.processOrder asc", taskObj.getId());
				for (NolioTaskMappingTO noliotaskObj : processes) {
					scriptTaskMappingTO.add(noliotaskObj);
				}
				taskObj.setNolioTaskMapping(scriptTaskMappingTO);
			}
			return tasksContaingProcessesList;
		} catch (DataIntegrityViolationException div) {
			logger.error(div);
			throw new CMMException("Problem encountered.TaskManagementDAOImpl:fetchTaskList", div);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.TaskManagementDAOImpl:fetchTaskList", dae);
		} catch (ConstraintViolationException e) {
			logger.error(e);
			throw new CMMException("Problem encountered.TaskManagementDAOImpl:fetchTaskList", e);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.TaskManagementDAOImpl:fetchTaskList", he);
		}
	}
	
	@Override
	public List<TaskManagementTO> fetchUdeployProcessesAndScriptsForTasks(Long activityId, Long mappedSoftwareId, Long automationToolId) throws CMMException {
	
		System.out.println("activityId " + activityId);
		System.out.println("mappedSoftwareId " + mappedSoftwareId);
		System.out.println("automationToolId " + automationToolId);
		try {
			List<TaskManagementTO> tasksContaingProcessesList = new ArrayList<TaskManagementTO>(0);
			List<Object[]> taskList = (List<Object[]>) getHibernateTemplate().find("from SoftwareTaskMappingTO s, TaskManagementTO t where s.taskId=t.id and s.softwareConfigId=? and t.cAReleaseActivityTO.id=?   order by s.taskOrder asc and order by t.udeployTaskMapping.processOrder asc", mappedSoftwareId, activityId);
			for (Object[] taskObj : taskList) {
				TaskManagementTO taskMgmtTo = (TaskManagementTO) taskObj[1];
				if ((taskMgmtTo.getManifestTypeTO().getId() == automationToolId)) {
					tasksContaingProcessesList.add(taskMgmtTo);
				}
			}
			for (TaskManagementTO taskObj : tasksContaingProcessesList) {
				Set<UdeployTaskMappingTO> scriptTaskMappingTO = new HashSet<UdeployTaskMappingTO>();
				List<UdeployTaskMappingTO> processes = (List<UdeployTaskMappingTO>) getHibernateTemplate().find("from UdeployTaskMappingTO s where s.taskManagementTO.id=? order by s.processOrder asc", taskObj.getId());
				for (UdeployTaskMappingTO udeploytaskObj : processes) {
					scriptTaskMappingTO.add(udeploytaskObj);
				}
				taskObj.setUdeployTaskMapping(scriptTaskMappingTO);
			}
			return tasksContaingProcessesList;
		} catch (DataIntegrityViolationException div) {
			logger.error(div);
			throw new CMMException("Problem encountered.TaskManagementDAOImpl:fetchTaskList", div);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.TaskManagementDAOImpl:fetchTaskList", dae);
		} catch (ConstraintViolationException e) {
			logger.error(e);
			throw new CMMException("Problem encountered.TaskManagementDAOImpl:fetchTaskList", e);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.TaskManagementDAOImpl:fetchTaskList", he);
		}
	}
	
	@Override
	public List<TaskManagementTO> fetchPuppetProcessesAndScriptsForTasks(Long activityId, Long mappedSoftwareId, Long automationToolId) throws CMMException {
	
		try {
			Long automationToolSSH = CMMConstants.Framework.AutomationTool.SCRIPT_ID;
			List<TaskManagementTO> tasksContaingProcessesList = new ArrayList<TaskManagementTO>(0);
			List<Object[]> taskList = (List<Object[]>) getHibernateTemplate().find("from SoftwareTaskMappingTO s, TaskManagementTO t where s.taskId=t.id and s.softwareConfigId=? and t.cAReleaseActivityTO.id=?   order by s.taskOrder asc and order by t.puppetTaskMapping.processOrder asc", mappedSoftwareId, activityId);
			for (Object[] taskObj : taskList) {
				TaskManagementTO taskMgmtTo = (TaskManagementTO) taskObj[1];
				if ((taskMgmtTo.getManifestTypeTO().getId() == automationToolId) || (taskMgmtTo.getManifestTypeTO().getId() == automationToolSSH)) {
					tasksContaingProcessesList.add(taskMgmtTo);
				}
			}
			for (TaskManagementTO taskObj : tasksContaingProcessesList) {
				Set<PuppetTaskMappingTO> scriptTaskMappingTO = new HashSet<PuppetTaskMappingTO>();
				List<PuppetTaskMappingTO> processes = (List<PuppetTaskMappingTO>) getHibernateTemplate().find("from PuppetTaskMappingTO s where s.taskManagementTO.id=? order by s.processOrder asc", taskObj.getId());
				for (PuppetTaskMappingTO noliotaskObj : processes) {
					scriptTaskMappingTO.add(noliotaskObj);
				}
				taskObj.setPuppetTaskMapping(scriptTaskMappingTO);
			}
			return tasksContaingProcessesList;
		} catch (DataIntegrityViolationException div) {
			logger.error(div);
			throw new CMMException("Problem encountered.TaskManagementDAOImpl:fetchPuppetProcessesAndScriptsForTasks", div);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.TaskManagementDAOImpl:fetchPuppetProcessesAndScriptsForTasks", dae);
		} catch (ConstraintViolationException e) {
			logger.error(e);
			throw new CMMException("Problem encountered.TaskManagementDAOImpl:fetchTaskList", e);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.TaskManagementDAOImpl:fetchTaskList", he);
		}
	}
	
	@Override
	public TaskManagementTO getTaskDetails(TaskManagementTO taskTO) throws CMMException {
	
		try {
			TaskManagementTO task = (TaskManagementTO) getHibernateTemplate().find("from TaskManagementTO where id=?", taskTO.getId()).get(0);
			task.setSelectedActivity(task.getcAReleaseActivityTO().getActivityId());
			task.setSelectedManifest(task.getManifestTypeTO().getId());
			if (task.getSelectedManifest() == CMMConstants.Framework.AutomationTool.NOLIO_ID) {
				List<NolioTaskMappingTO> nolioTaskMappingTO = new ArrayList<NolioTaskMappingTO>();
				nolioTaskMappingTO = (List<NolioTaskMappingTO>) getHibernateTemplate().findByCriteria(DetachedCriteria.forClass(NolioTaskMappingTO.class).add(Restrictions.eq("taskManagementTO.id", task.getId())).addOrder(Order.asc("processOrder")));
				task.getNolioTaskMapping().addAll(nolioTaskMappingTO);
				List<Long> selectedNolioProcess = new ArrayList<Long>();
				for (NolioTaskMappingTO n : nolioTaskMappingTO) {
					selectedNolioProcess.add(n.getNolioProcess().getProcessId());
				}
				task.setSelectedProcess(selectedNolioProcess);
			}
			if (task.getSelectedManifest() == CMMConstants.Framework.AutomationTool.UDEPLOY_ID) {
				List<UdeployTaskMappingTO> udeployTaskMappingTO = new ArrayList<UdeployTaskMappingTO>();
				udeployTaskMappingTO = (List<UdeployTaskMappingTO>) getHibernateTemplate().findByCriteria(DetachedCriteria.forClass(UdeployTaskMappingTO.class).add(Restrictions.eq("taskManagementTO.id", task.getId())).addOrder(Order.asc("processOrder")));
				task.getUdeployTaskMapping().addAll(udeployTaskMappingTO);
				List<Long> selectedUdeployProcess = new ArrayList<Long>();
				for (UdeployTaskMappingTO u : udeployTaskMappingTO) {
					selectedUdeployProcess.add(u.getUdeployProcess().getProcessId());
				}
				task.setSelectedProcess(selectedUdeployProcess);
			}
			if (task.getSelectedManifest() == CMMConstants.Framework.AutomationTool.PUPPET_ID) {
				List<PuppetTaskMappingTO> puppetTaskMappingTO = new ArrayList<PuppetTaskMappingTO>();
				puppetTaskMappingTO = (List<PuppetTaskMappingTO>) getHibernateTemplate().findByCriteria(DetachedCriteria.forClass(PuppetTaskMappingTO.class).add(Restrictions.eq("taskManagementTO.id", task.getId())).addOrder(Order.asc("processOrder")));
				task.getPuppetTaskMapping().addAll(puppetTaskMappingTO);
				List<Long> selectedPuppetProcess = new ArrayList<Long>();
				for (PuppetTaskMappingTO p : puppetTaskMappingTO) {
					selectedPuppetProcess.add(p.getPuppetProcess().getProcessId());
				}
				task.setSelectedProcess(selectedPuppetProcess);
			}
			task.setSelectedManifest(task.getManifestTypeTO().getId());
			if (task.getSelectedManifest() == CMMConstants.Framework.AutomationTool.SCRIPT_ID) {
				List<ScriptTaskMappingTO> scriptTaskMappingTOExisting = (List<ScriptTaskMappingTO>) getHibernateTemplate().find("from ScriptTaskMappingTO where taskManagementTO.id =? ", task.getId());
				List<ScriptParameterMapTO> taskparamList = new ArrayList<ScriptParameterMapTO>();
				for (ScriptTaskMappingTO s : scriptTaskMappingTOExisting) {
					for (ScriptParameterMapTO params : s.getScriptParameterMap()) {
						ScriptParameterMapTO paramList = new ScriptParameterMapTO();
						paramList.setParameterName(params.getParameterName());
						paramList.setDefaultParameterValues(params.getDefaultParameterValues());
						if (!("-1".equalsIgnoreCase(params.getSelectedParameterValues()) || "".equalsIgnoreCase(params.getSelectedParameterValues()) || (params.getSelectedParameterValues() == null))) {
							paramList.setSelectedParameterValues(params.getSelectedParameterValues());
						} else {
							paramList.setSelectedParameterValues("-1");
						}
						if (!("-1".equalsIgnoreCase(params.getSelectedParameterScopes()) || "".equalsIgnoreCase(params.getSelectedParameterScopes()) || (params.getSelectedParameterScopes() == null))) {
							paramList.setSelectedParameterScopes(params.getSelectedParameterScopes());
						} else {
							paramList.setSelectedParameterScopes("-1");
						}
						taskparamList.add(paramList);
					}
				}
				task.setScriptParameterMap(taskparamList);
			}
			return task;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.TaskManagementDAOImpl:getTaskDetails", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.TaskManagementDAOImpl:getTaskDetails", he);
		}
	}
	
	@Override
	public TaskManagementTO editTask(TaskManagementTO taskTO) throws CMMException {
	
		try {
			TaskManagementTO t = new TaskManagementTO();
			TaskManagementTO taskDetails = (TaskManagementTO) getHibernateTemplate().find("from TaskManagementTO where id=?", taskTO.getId()).get(0);
			t.setId(taskTO.getId());
			t.setTaskname(taskTO.getTaskname());
			t.setSelectedActivity(taskTO.getSelectedActivity());
			t.setSelectedManifest(taskTO.getSelectedManifest());
			t.setModifiedbyId(taskTO.getModifiedbyId());
			t.setDescription(taskTO.getDescription());
			t.setCreatedById(taskDetails.getCreatedById());
			t.setCreatedDate(taskDetails.getCreatedDate());
			taskTO.setModifiedDate(DateUtils.getStartTime(new Date()));
			ManifestTypeTO manifest = (ManifestTypeTO) getHibernateTemplate().find("from ManifestTypeTO where id=?", taskTO.getSelectedManifest()).get(0);
			CAReleaseActivityTO activity = new CAReleaseActivityTO();
			if (t.getSelectedActivity() == -1L) {
				activity.setActivityName(taskTO.getNewActivityName());
				getHibernateTemplate().save(activity);
			} else {
				activity = (CAReleaseActivityTO) getHibernateTemplate().find("from CAReleaseActivityTO where activityId=?", taskTO.getSelectedActivity()).get(0);
				t.setcAReleaseActivityTO(activity);
			}
			t.setcAReleaseActivityTO(activity);
			t.setManifestTypeTO(manifest);
			if (taskDetails.getManifestTypeTO().getId() != taskTO.getSelectedManifest()) {
				deletePrevManifestMappingForTask(taskDetails);
			} else {
				deletePrevManifestMappingForTask(t);
			}
			if (taskTO.getSelectedManifest() == CMMConstants.Framework.AutomationTool.NOLIO_ID) {
				Set<NolioTaskMappingTO> noliomaplist = new HashSet<NolioTaskMappingTO>();
				for (int i = 0; i < taskTO.getSelectedProcess().size(); i++) {
					NolioTaskMappingTO noliomap = new NolioTaskMappingTO();
					noliomap.setProcessOrder(i);
					NolioProcess nolioprocess = new NolioProcess();
					nolioprocess.setProcessId(taskTO.getSelectedProcess().get(i));
					noliomap.setNolioProcess(nolioprocess);
					noliomap.setTaskManagementTO(t);
					noliomaplist.add(noliomap);
				}
				t.getNolioTaskMapping().addAll(noliomaplist);
			}
			if (taskTO.getSelectedManifest() == CMMConstants.Framework.AutomationTool.UDEPLOY_ID) {
				Set<UdeployTaskMappingTO> udeploymaplist = new HashSet<UdeployTaskMappingTO>();
				for (int i = 0; i < taskTO.getSelectedProcess().size(); i++) {
					UdeployTaskMappingTO udeploymap = new UdeployTaskMappingTO();
					udeploymap.setProcessOrder(i);
					UdeployProcess udeployProcess = new UdeployProcess();
					udeployProcess.setProcessId(taskTO.getSelectedProcess().get(i));
					udeploymap.setUdeployProcess(udeployProcess);
					udeploymap.setTaskManagementTO(t);
					udeploymaplist.add(udeploymap);
				}
				t.getUdeployTaskMapping().addAll(udeploymaplist);
			}
			if (taskTO.getSelectedManifest() == CMMConstants.Framework.AutomationTool.PUPPET_ID) {
				Set<PuppetTaskMappingTO> puppetmaplist = new HashSet<PuppetTaskMappingTO>();
				if (taskTO.getSelectedProcess() != null) {
					for (int i = 0; i < taskTO.getSelectedProcess().size(); i++) {
						PuppetTaskMappingTO puppetmap = new PuppetTaskMappingTO();
						puppetmap.setProcessOrder(i);
						PuppetProcess puppetprocess = new PuppetProcess();
						puppetprocess.setProcessId(taskTO.getSelectedProcess().get(i));
						puppetmap.setPuppetProcess(puppetprocess);
						puppetmap.setTaskManagementTO(t);
						puppetmaplist.add(puppetmap);
					}
				}
				t.getPuppetTaskMapping().addAll(puppetmaplist);
			}
			if (taskTO.getSelectedManifest() == CMMConstants.Framework.AutomationTool.SCRIPT_ID) {
				Set<ScriptTaskMappingTO> scriptmaplist = new HashSet<ScriptTaskMappingTO>();
				ScriptTaskMappingTO scriptmap = new ScriptTaskMappingTO();
				scriptmap.setUploadFlag(taskTO.getUploadScript());
				scriptmap.setFilePath(taskTO.getFilePath());
				scriptmap.setTargetLocation(taskTO.getTargetLocation());
				RepositoryTO repo = new RepositoryTO();
				repo.setId(taskTO.getRepoId());
				scriptmap.setRepository(repo);
				if ("No".equalsIgnoreCase(taskTO.getUploadScript())) {
					scriptmap.setFilesName(taskTO.getScriptname());
					t.setScriptname(taskTO.getScriptname());
				} else {
					scriptmap.setUploadSource(taskTO.getUploadSource());
					scriptmap.setFilesName(taskTO.getScriptname());
				}
				scriptmap.setTaskManagementTO(t);
				Set<ScriptParameterMapTO> scriptParameterMapList = new HashSet<ScriptParameterMapTO>();
				if (!taskTO.getScriptParameterMap().isEmpty() && !"".equalsIgnoreCase(taskTO.getScriptParameterMap().get(0).getParameterName())) {
					for (ScriptParameterMapTO params : taskTO.getScriptParameterMap()) {
						ScriptParameterMapTO paramList = new ScriptParameterMapTO();
						paramList.setParameterName(params.getParameterName());
						if (!("-1".equalsIgnoreCase(params.getSelectedParameterValues()) || "".equalsIgnoreCase(params.getSelectedParameterValues()))) {
							paramList.setNetraParameterMapping("Y");
							paramList.setSelectedParameterValues(params.getSelectedParameterValues());
						} else {
							paramList.setNetraParameterMapping("N");
						}
						if (!("-1".equalsIgnoreCase(params.getSelectedParameterScopes()) || "".equalsIgnoreCase(params.getSelectedParameterScopes()))) {
							paramList.setSelectedParameterScopes(params.getSelectedParameterScopes());
						} else {
							paramList.setSelectedParameterScopes(null);
						}
						paramList.setDefaultParameterValues(params.getDefaultParameterValues());
						paramList.setMappedScript(scriptmap);
						scriptParameterMapList.add(paramList);
					}
				}
				scriptmap.setScriptParameterMap(scriptParameterMapList);
				repo.setScriptTaskMappingTO(scriptmaplist);
				scriptmaplist.add(scriptmap);
				t.setScriptTaskMappingTO(scriptmaplist);
			}
			getHibernateTemplate().update(t);
			return t;
		} catch (DataIntegrityViolationException div) {
			logger.error(div);
			throw new CMMException("Problem encountered.TaskManagementDAOImpl:addTask", div);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.TaskManagementDAOImpl:addTask", dae);
		} catch (ConstraintViolationException e) {
			logger.error(e);
			throw new CMMException("Problem encountered.TaskManagementDAOImpl:addTask", e);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.TaskManagementDAOImpl:addTask", he);
		}
	}
	
	private void deletePrevManifestMappingForTask(TaskManagementTO taskDetails) {
	
		if (taskDetails.getManifestTypeTO().getId() == CMMConstants.Framework.AutomationTool.SCRIPT_ID) {
			List<ScriptTaskMappingTO> scriptTaskMappingTOExisting = (List<ScriptTaskMappingTO>) getHibernateTemplate().find("from ScriptTaskMappingTO where taskManagementTO.id =? ", taskDetails.getId());
			if (scriptTaskMappingTOExisting != null) {
				for (int i = 0; i < scriptTaskMappingTOExisting.size(); i++) {
					ScriptTaskMappingTO s = scriptTaskMappingTOExisting.get(i);
					List<ScriptParameterMapTO> scriptTaskMappingParamTOExisting = (List<ScriptParameterMapTO>) getHibernateTemplate().find("from ScriptParameterMapTO where mappedScript.scriptId =? ", s.getScriptId());
					if (scriptTaskMappingTOExisting != null) {
						getHibernateTemplate().deleteAll(scriptTaskMappingParamTOExisting);
					}
					getHibernateTemplate().delete(s);
				}
			}
		} else if (taskDetails.getManifestTypeTO().getId() == CMMConstants.Framework.AutomationTool.UDEPLOY_ID) {
			List<UdeployTaskMappingTO> udeployTaskMappingTOExisting = (List<UdeployTaskMappingTO>) getHibernateTemplate().find("from UdeployTaskMappingTO where taskManagementTO.id =? ", taskDetails.getId());
			if (udeployTaskMappingTOExisting != null) {
				for (int i = 0; i < udeployTaskMappingTOExisting.size(); i++) {
					UdeployTaskMappingTO u = udeployTaskMappingTOExisting.get(i);
					getHibernateTemplate().delete(u);
				}
			}
		} else if (taskDetails.getManifestTypeTO().getId() == CMMConstants.Framework.AutomationTool.PUPPET_ID) {
			List<PuppetTaskMappingTO> puppetTaskMappingTOExisting = (List<PuppetTaskMappingTO>) getHibernateTemplate().find("from PuppetTaskMappingTO where taskManagementTO.id =? ", taskDetails.getId());
			if (puppetTaskMappingTOExisting != null) {
				for (int i = 0; i < puppetTaskMappingTOExisting.size(); i++) {
					PuppetTaskMappingTO p = puppetTaskMappingTOExisting.get(i);
					getHibernateTemplate().delete(p);
				}
			}
		} else if (taskDetails.getManifestTypeTO().getId() == CMMConstants.Framework.AutomationTool.NOLIO_ID) {
			List<NolioTaskMappingTO> nolioTaskMappingTOExisting = (List<NolioTaskMappingTO>) getHibernateTemplate().find("from NolioTaskMappingTO where taskManagementTO.id =? ", taskDetails.getId());
			if (nolioTaskMappingTOExisting != null) {
				for (int i = 0; i < nolioTaskMappingTOExisting.size(); i++) {
					NolioTaskMappingTO n = nolioTaskMappingTOExisting.get(i);
					getHibernateTemplate().delete(n);
				}
			}
		}
	}
	
	@Override
	public Map<String, String> fetchTaskParameterMap(Long taskId) throws CMMException {
	
		Map<String, String> taskParameterMap = new HashMap<String, String>();
		List<TaskManagementTO> taskList = (List<TaskManagementTO>) getHibernateTemplate().find("from TaskManagementTO where id=?", taskId);
		TaskManagementTO task = new TaskManagementTO();
		if (!taskList.isEmpty()) {
			task = taskList.get(0);
		}
		for (ScriptTaskMappingTO scriptTask : task.getScriptTaskMappingTO()) {
			for (ScriptParameterMapTO scriptParameterMap : scriptTask.getScriptParameterMap()) {}
		}
		return taskParameterMap;
	}
	
	@Override
	public boolean checkNewActivityName(TaskManagementTO taskTO) throws CMMException {
	
		boolean flag = false;
		try {
			List<CAReleaseActivityTO> actName = (List<CAReleaseActivityTO>) getHibernateTemplate().find("from CAReleaseActivityTO where activityName=? ", taskTO.getNewActivityName());
			if (!actName.isEmpty()) {
				flag = true;
			} else {
				flag = false;
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.TaskManagementDAOImpl:checkNewActivityName.", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.TaskManagementDAOImpl:checkNewActivityName.", he);
		}
		return flag;
	}
	
	@Override
	public List<RepositoryTO> getSharedLocations() throws CMMException {
	
		try {
			String query = String.format("select r from RepositoryTO r where r.repoTO.repoid=%d", CMMConstants.Framework.RepositoryList.SHAREDLOCATION_ID);
			return (List<RepositoryTO>) getHibernateTemplate().find(query);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.TaskManagementDAOImpl:checkNewActivityName.", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.TaskManagementDAOImpl:checkNewActivityName.", he);
		}
	}
}
