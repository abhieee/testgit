package com.ext.dao.impl;

import java.util.ArrayList;
import java.util.List;
import org.hibernate.HibernateException;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.SVNPathForSonarDAO;
import com.framework.exception.CMMException;
import com.framework.to.SonarDetailTO;
import com.framework.to.SonarReportsDetailTO;

public class SVNPathForSonarDAOImpl extends HibernateDaoSupport implements SVNPathForSonarDAO {
	
	@Override
	public List<SonarDetailTO> sVNPathForSonarDAO(Long applicationReleaseId) throws CMMException {
	
		List<SonarDetailTO> svnList = new ArrayList<SonarDetailTO>(0);
		try {
			svnList = (List<SonarDetailTO>) getHibernateTemplate().find("Select distinct svnPathLocation from SonarDetailTO where applicationReleaseId =?", applicationReleaseId);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. SVNPathForSonarDAOImpl : SVNPathForSonarDAO", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. SVNPathForSonarDAOImpl : SVNPathForSonarDAO", he);
		}
		return svnList;
	}
	
	@Override
	public List<SonarDetailTO> getSonarDetailsForRelease(Long applicationReleaseId) throws CMMException {
	
		List<SonarDetailTO> sonarDetailsList = new ArrayList<SonarDetailTO>(0);
		try {
			sonarDetailsList = (List<SonarDetailTO>) getHibernateTemplate().find("from SonarDetailTO where applicationReleaseId =?", applicationReleaseId);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. SVNPathForSonarDAOImpl : SVNPathForSonarDAO", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. SVNPathForSonarDAOImpl : SVNPathForSonarDAO", he);
		}
		return sonarDetailsList;
	}
	
	@Override
	public void sonarReportDetailsDAO(String folderName, Long applicationReleaseId) throws CMMException {
	
		List<Long> applicationId = new ArrayList<Long>(0);
		long applId;
		try {
			applicationId = (List<Long>) getHibernateTemplate().find("Select distinct applicationId from ServiceRequestTO where applicationReleaseId =?", applicationReleaseId);
			applId = applicationId.get(0);
			SonarReportsDetailTO sonar = new SonarReportsDetailTO();
			sonar.setApplicationId(applId);
			sonar.setApplicationReleaseId(applicationReleaseId);
			sonar.setFolderName(folderName);
			getHibernateTemplate().save(sonar);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. SVNPathForSonarDAOImpl : SonarReportDetailsDAO", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. SVNPathForSonarDAOImpl : SonarReportDetailsDAO", he);
		}
	}
}
