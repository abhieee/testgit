package com.ext.dao.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Property;
import org.hibernate.criterion.Restrictions;
import org.hibernate.exception.ConstraintViolationException;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.util.StringUtils;
import com.ext.dao.ApplicationDAO;
import com.ext.dao.EnvironmentDAO;
import com.framework.common.CMMConstants;
import com.framework.common.CMMConstants.Framework.Entity;
import com.framework.exception.CMMException;
import com.framework.to.AddPolicyTO;
import com.framework.to.ApplicationMonitoringTO;
import com.framework.to.ApplicationProfileTO;
import com.framework.to.ApplicationReleaseSourcecodeTO;
import com.framework.to.ApplicationReleaseTO;
import com.framework.to.ApplicationTO;
import com.framework.to.BusinessUnitTO;
import com.framework.to.EnvTypeTO;
import com.framework.to.EnvironmentApplicationTO;
import com.framework.to.EnvironmentDetailsTO;
import com.framework.to.EnvironmentTO;
import com.framework.to.ParameterTO;
import com.framework.to.ProjectsTO;
import com.framework.to.ProvisionedMachineTO;
import com.framework.to.ReleaseDashBoradTo;
import com.framework.to.ReservationTO;
import com.framework.to.ServiceRequestTO;
import com.framework.to.SoftwareTO;
import com.framework.to.StatusTO;
import com.framework.to.UserBusinessUnitTO;
import com.framework.to.UserDefinedEnvParamsTO;
import com.framework.to.UserTO;
import com.framework.to.ZabbixSoftwareMappingTO;
import com.framework.to.ZabbixTriggerFunctionTO;
import com.framework.utility.DateUtils;

/**
 * @author TCS
 */
public class EnvironmentDAOImpl extends HibernateDaoSupport implements EnvironmentDAO {
	
	private static final Logger LOG = Logger.getLogger(EnvironmentDAOImpl.class);
	@Autowired
	ApplicationDAO applicationDAO;
	@Autowired
	ApplicationDAOImpl applicationDAOImpl;
	int width = 0;
	int height = 0;
	private String dbName;
	
	public String getDbName() {
	
		return dbName;
	}
	
	public void setDbName(String dbName) {
	
		this.dbName = dbName;
	}
	
	@Override
	public void addEnvironment(EnvironmentTO environmentTO) throws CMMException {
	
		try {
			EnvironmentTO addEnv = new EnvironmentTO();
			addEnv.setEnvironmentName(environmentTO.getEnvironmentName());
			addEnv.setStatus(environmentTO.getStatus());
			addEnv.setApplicationId(environmentTO.getApplicationId());
			addEnv.setCreatedById(environmentTO.getCreatedById());
			addEnv.setCreatedByDate(environmentTO.getCreatedByDate());
			for (EnvironmentDetailsTO details : environmentTO.getEnvironmentDetails()) {
				for (Long id : details.getSoftwareId()) {
					EnvironmentDetailsTO temp = new EnvironmentDetailsTO();
					temp.setHardwareId(details.getHardwareId());
					temp.setPlatformId(details.getPlatformId());
					temp.setMappedSoftwareId(id);
					temp.setEnvironment(addEnv);
					addEnv.getEnvironmentDetails().add(temp);
				}
			}
			getHibernateTemplate().save(addEnv);
			String[] parameters = new String[4];
			parameters[0] = "environment_id";
			parameters[1] = "workflow_id";
			parameters[2] = "user_id";
			parameters[3] = "success";
			Object[] values = new Object[4];
			values[0] = addEnv.getId();
			values[1] = 1L;
			values[2] = environmentTO.getCreatedById();
			values[3] = false;
			getHibernateTemplate().findByNamedQueryAndNamedParam("initiateWorkflowEnvironment", parameters, values).get(0);
		} catch (ConstraintViolationException e) {
			LOG.error(e);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:addEnvironment", e);
		} catch (DataAccessException | HibernateException e) {
			LOG.error("Error in addEnvironment method", e);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:addEnvironment.", e);
		}
	}
	
	@Override
	public EnvironmentTO getEnvironmentDetails(Long id) throws CMMException {
	
		try {
			EnvironmentTO env = new EnvironmentTO();
			List<EnvironmentTO> envList = (List<EnvironmentTO>) getHibernateTemplate().find("from EnvironmentTO where id=?", id);
			if (!envList.isEmpty()) {
				env = envList.get(0);
				if ((env.getEnvTypeId() != null) && (env.getEnvTypeId() > 0)) {
					String type = (String) getHibernateTemplate().find("select typeValue from EnvTypeTO where id=?", env.getEnvTypeId()).get(0);
					env.setEnvTypeName(type);
				} else {
					env.setEnvTypeName("NA");
				}
			}
			return env;
		} catch (DataAccessException e) {
			LOG.error(e);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:getEnvironmentDetails", e);
		} catch (HibernateException e) {
			LOG.error("Error in getEnvironmentDetails method", e);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:getEnvironmentDetails", e);
		}
	}
	
	@Override
	public EnvironmentTO editEnvironment(EnvironmentTO environmentTO) throws CMMException {
	
		EnvironmentTO editEnvNew = new EnvironmentTO();
		ApplicationReleaseTO applicationReleaseTO = new ApplicationReleaseTO();
		Session session = null;
		try {
			session = getSession();
			editEnvNew = (EnvironmentTO) getHibernateTemplate().find("from EnvironmentTO a where a.id=?", environmentTO.getId()).get(0);
			if (StringUtils.hasText(environmentTO.getEnvironmentName())) {
				editEnvNew.setEnvironmentName(environmentTO.getEnvironmentName());
			}
			if (environmentTO.getStatus() != null) {
				editEnvNew.setStatus(environmentTO.getStatus());
			} else {
				editEnvNew.setStatus(environmentTO.getStatusTO().getId());
			}
			editEnvNew.setModifiedbyId(environmentTO.getModifiedbyId());
			editEnvNew.setModifiedbyDate(environmentTO.getModifiedbyDate());
			getHibernateTemplate().update(editEnvNew);
			List<Long> addedApplication = new ArrayList<Long>();
			addedApplication = environmentTO.getApplicationNameSelected();
			if ((addedApplication != null) && !addedApplication.isEmpty()) {
				applicationReleaseTO = editEnvNew.getEnvironmentApplicationTO().iterator().next().getApplicationReleaseTO();
				for (EnvironmentApplicationTO temp : editEnvNew.getEnvironmentApplicationTO()) {
					String hql = "DELETE from EnvironmentApplicationTO  where id=:environment_id ";
					Query query = session.createQuery(hql);
					query.setParameter("environment_id", temp.getId());
					query.executeUpdate();
				}
			}
			if ((addedApplication != null) && !addedApplication.isEmpty()) {
				for (Long temp : addedApplication) {
					EnvironmentApplicationTO tempAppTO = new EnvironmentApplicationTO();
					tempAppTO.setApplicationTO(getHibernateTemplate().load(ApplicationTO.class, temp));
					tempAppTO.setEnvironmentTO(editEnvNew);
					tempAppTO.setApplicationReleaseTO(applicationReleaseTO);
					getHibernateTemplate().save(tempAppTO);
				}
			}
			return editEnvNew;
		} catch (DataIntegrityViolationException e) {
			logger.error(e);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:editEnvironment.", e);
		} catch (DataAccessException | HibernateException e) {
			logger.error(e);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:editEnvironment.", e);
		}
	}
	
	@Override
	public List<EnvironmentDetailsTO> fetchSubEnvironmentsDetail(Long id) throws CMMException {
	
		try {
			List<Long> subEnvsId = (List<Long>) getHibernateTemplate().find("select subEnvronmentId from SubEnvironmentMappingTO where environmentId=?", id);
			List<EnvironmentDetailsTO> envDetails = new ArrayList<EnvironmentDetailsTO>();
			List<Object[]> objList = (List<Object[]>) getHibernateTemplate().findByNamedParam("from EnvironmentDetailsTO e inner join e.environment b  where b.id in (:subEnvsId)", "subEnvsId", subEnvsId);
			for (Object[] list : objList) {
				envDetails.add((EnvironmentDetailsTO) list[0]);
			}
			return envDetails;
		} catch (DataAccessException | HibernateException e) {
			LOG.error(e);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:fetchSubEnvironmentsDetail.", e);
		}
	}
	
	@Override
	public String fetchOwnerName(Long id) throws CMMException {
	
		try {
			return (String) getHibernateTemplate().find("select name from UserTO where id = ?", id).get(0);
		} catch (DataAccessException | HibernateException e) {
			LOG.error(e);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:fetchOwnerName.", e);
		}
	}
	
	@Override
	public List<EnvironmentDetailsTO> fetchEnvironment(Long id) throws CMMException {
	
		try {
			List<EnvironmentDetailsTO> temp = new ArrayList<EnvironmentDetailsTO>();
			List<Object[]> objList = (List<Object[]>) getHibernateTemplate().find("from EnvironmentDetailsTO e inner join e.environment b  where b.id=?", id);
			for (Object[] list : objList) {
				temp.add((EnvironmentDetailsTO) list[0]);
			}
			return temp;
		} catch (DataAccessException | HibernateException e) {
			LOG.error(e);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:fetchEnvironment.", e);
		}
	}
	
	@Override
	public List<StatusTO> fetchEnvironmentStatusList() throws CMMException {
	
		try {
			return (List<StatusTO>) getHibernateTemplate().find("from StatusTO where entityId =?", 2L);
		} catch (DataAccessException e) {
			LOG.error(e);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:fetchEnvironmentStatusList", e);
		} catch (HibernateException e) {
			LOG.error(e);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:fetchEnvironmentStatusList.", e);
		}
	}
	
	@Override
	public Long getRequestedEnvCount(Long clientId, List<Long> clientIdlist, long status, EnvironmentTO environmentTO, UserTO userTo) throws CMMException {
	
		Long available = 0L;
		Session session = null;
		Query q = null;
		try {
			session = getSession();
			StringBuilder query = new StringBuilder();
			if (environmentTO.getClientId() == 0) {
				query.append("select distinct e.id from environments e , environment_application m , status s  where m.environment_id =e.id and e.STATUS=s.id and e.STATUS in(:Status)");
			} else if ((environmentTO.getClientId() != 0) && (environmentTO.getRoleId() == 1)) {
				query.append("select distinct e.id from environments e , environment_application m , status s , user_business_unit u where m.environment_id =e.id and e.STATUS=s.id and e.STATUS in (:Status)   and m.application_id in ( select a.id from applications a where a.client_id in(:clientIdList))");
			} else {
				query.append("select distinct e.id from environments e , environment_application m , status s, user_group_details ugd, user_groups ug,applications a where m.environment_id =e.id and m.application_id = a.id and ug.id=a.user_grp_id and ug.id = ugd.group_id and ugd.user_id=:userTo_Id and e.STATUS = s.id and e.STATUS in (:Status)");
			}
			List<Long> statusList = new ArrayList<Long>();
			statusList.add(CMMConstants.Framework.Entity.ENVIRONMENT_STATUS_UNDERIMPLEMENTATION);
			statusList.add(CMMConstants.Framework.Entity.ENVIRONMENT_REQUEST_PENDING);
			q = session.createSQLQuery(query.toString());
			if (environmentTO.getClientId() == 0) {
				q.setParameterList("Status", statusList);
			} else if ((environmentTO.getClientId() != 0) && (environmentTO.getRoleId() == 1)) {
				q.setParameterList("clientIdList", clientIdlist);
				q.setParameterList("Status", statusList);
			} else {
				q.setParameterList("Status", statusList);
				q.setParameter("userTo_Id", userTo.getId());
			}
			if (!q.list().isEmpty()) {
				available = (long) q.list().size();
			} else {
				available = 0L;
			}
			return available;
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:getRequestedEnvCount.", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<ApplicationTO> getAllApplicationsDrivenByEnv(Long environmentId) throws CMMException {
	
		List<ApplicationTO> applications = new ArrayList<ApplicationTO>(0);
		List<Object> applicationsObj = new ArrayList<Object>(0);
		try {
			applicationsObj = (List<Object>) getHibernateTemplate().find("from ApplicationTO a, EnvironmentApplicationTO e, EnvironmentTO ev where a.id=e.applicationTO.id AND e.environmentTO.id=ev.id AND e.environmentTO.id=?", environmentId);
			for (int i = 0; i < applicationsObj.size(); i++) {
				Object arr1[] = (Object[]) applicationsObj.get(i);
				for (Object obj : arr1) {
					if (obj instanceof ApplicationTO) {
						ApplicationTO t = (ApplicationTO) obj;
						applications.add(t);
					}
				}
			}
		} catch (Exception e) {
			LOG.error("getAllApplicationsDrivenByEnv" + e);
			throw new CMMException("EnvironmentDAOImpl:getAllApplicationsDrivenByEnv", e);
		}
		return applications;
	}
	
	@Override
	public List<EnvironmentTO> getAllEnvs() throws CMMException {
	
		try {
			return (List<EnvironmentTO>) getHibernateTemplate().find("from EnvironmentTO");
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:getAllEnvs", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:getAllEnvs.", he);
		}
	}
	
	@Override
	public List<EnvironmentTO> getAllEnvsMonitoring() throws CMMException {
	
		List<EnvironmentTO> envList = new ArrayList<EnvironmentTO>(0);
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(EnvironmentApplicationTO.class, "EnvironmentApplicationTO");
			criteria.add(Restrictions.isNotNull("releaseId"));
			List<EnvironmentApplicationTO> envAppList = (List<EnvironmentApplicationTO>) getHibernateTemplate().findByCriteria(criteria);
			for (EnvironmentApplicationTO envApp : envAppList) {
				EnvironmentTO env = new EnvironmentTO();
				env.setId(envApp.getEnvironmentTO().getId());
				env.setEnvironmentName(envApp.getEnvironmentTO().getEnvironmentName());
				envList.add(env);
			}
			return envList;
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getEnvironmentListForApplications", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ServiceRequestDAOImpl: getEnvironmentListForApplications", he);
		}
	}
	
	@Override
	public Long getAvailableEnvCount(Long clientId, List<Long> clientIdlist, EnvironmentTO environmentTO, UserTO userTo) throws CMMException {
	
		Long available = 0L;
		Session session = null;
		Query q = null;
		try {
			session = getSession();
			Date currentDate = DateUtils.getStartTime(new Date());
			StringBuilder query = new StringBuilder();
			if (environmentTO.getClientId() == 0) {
				query.append("select distinct e.id from environments e , environment_application m , status s where m.environment_id =e.id and e.STATUS=s.id and e.STATUS=(:availableStatus)");
			} else if ((environmentTO.getClientId() != 0) && (environmentTO.getRoleId() == 1)) {
				query.append("select distinct e.id,e.ENVIRONMENT_NAME,s.STATUS_DESC from environments e , environment_application m , status s where m.environment_id =e.id and e.STATUS=s.id and e.STATUS=(:availableStatus) and m.application_id in ( select a.id from applications a where a.client_id in(:clientIdList))");
			} else {
				query.append("select distinct e.id from environments e , environment_application m , status s, user_group_details ugd, user_groups ug,applications a where m.environment_id =e.id and m.application_id = a.id and ug.id=a.user_grp_id and ug.id = ugd.group_id and ugd.user_id =:userId and e.STATUS = s.id and e.STATUS=(:availableStatus)");
			}
			query.append(" and e.id not in (select distinct r.environment_id from reservation r where r.status=(:reservedStatus) and r.endTime>(:endTime))");
			q = session.createSQLQuery(query.toString());
			if (environmentTO.getClientId() == 0) {
				q.setParameter("availableStatus", CMMConstants.Framework.Entity.ENVIRONMENT_STATUS_AVAILABLE);
			} else if ((environmentTO.getClientId() != 0) && (environmentTO.getRoleId() == 1)) {
				q.setParameterList("clientIdList", clientIdlist);
				q.setParameter("availableStatus", CMMConstants.Framework.Entity.ENVIRONMENT_STATUS_AVAILABLE);
			} else {
				q.setParameter("userId", userTo.getId());
				q.setParameter("availableStatus", CMMConstants.Framework.Entity.ENVIRONMENT_STATUS_AVAILABLE);
			}
			q.setParameter("reservedStatus", Entity.RESERVATION_STATUS_APPROVED);
			q.setParameter("endTime", currentDate);
			q.list();
			if (!q.list().isEmpty()) {
				available = (long) q.list().size();
			} else {
				available = 0L;
			}
			return available;
		} catch (DataAccessException | HibernateException dae) {
			LOG.error("Problem encountered. EnvironmentDAOImpl : getAvailableEnvCount", dae);
			throw new CMMException("Problem encountered. EnvironmentDAOImpl : getAvailableEnvCount", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	public List<ApplicationProfileTO> searchAppProfile(ApplicationProfileTO applicationProfileTO) throws CMMException {
	
		try {
			StringBuilder query = new StringBuilder("select DISTINCT p from  ApplicationProfileTO p , ApplicationProfileMappingTO m where m.profileId =p.id");
			if (StringUtils.hasText(applicationProfileTO.getName())) {
				query.append(" and p.name like '%?%'");
			}
			if (applicationProfileTO.getSelectedApplication() > 0L) {
				query.append(" and m.applicationTO.id = ?");
			}
			if (applicationProfileTO.getSelectedStatus() > 0L) {
				query.append(" and p.statusTO.id = ?");
			}
			return (List<ApplicationProfileTO>) getHibernateTemplate().find(query.toString(), applicationProfileTO.getName(), applicationProfileTO.getSelectedApplication(), applicationProfileTO.getSelectedStatus());
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : searchAppProfile", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : searchAppProfile", he);
		}
	}
	
	@Override
	public List<EnvironmentTO> searchEnv(EnvironmentTO environmentTO, UserTO userTo) throws CMMException {
	
		Session session = null;
		List<EnvironmentTO> envList = new ArrayList<EnvironmentTO>();
		StringBuilder query = new StringBuilder();
		try {
			session = getSession();
			Query q = null;
			List<Long> clientIdlist = new ArrayList<Long>(0);
			for (UserBusinessUnitTO bu : userTo.getUserBusinessUnit()) {
				clientIdlist.add(bu.getClientId());
			}
			long invalidStatus = CMMConstants.Framework.Entity.ENVIRONMENT_STATUS_INVALID;
			if (environmentTO.getClientId() == 0) {
				query.append("select distinct e.id,e.ENVIRONMENT_NAME,s.STATUS_DESC from environments e , environment_application m , status s  where m.environment_id =e.id and e.STATUS=s.id and e.STATUS!=:envInvalidStatus");
			} else if ((environmentTO.getClientId() != 0) && (environmentTO.getRoleId() == 1)) {
				query.append("select distinct e.id,e.ENVIRONMENT_NAME,s.STATUS_DESC from environments e , environment_application m , status s , user_business_unit u where m.environment_id=e.id and e.STATUS=s.id and e.STATUS!=:envInvalidStatus  and m.application_id in ( select a.id from applications a where a.client_id in(:clientIdList))");
			} else {
				query.append("select distinct e.id,e.ENVIRONMENT_NAME,s.STATUS_DESC from environments e , environment_application m , status s, user_group_details ugd, user_groups ug,applications a where m.environment_id =e.id and m.application_id = a.id and ug.id=a.user_grp_id and ug.id = ugd.group_id and ugd.user_id =:userId and e.STATUS = s.id and e.STATUS !=:envInvalidStatus ");
			}
			if (StringUtils.hasText(environmentTO.getEnvironmentName())) {
				query.append(" and e.ENVIRONMENT_NAME like (:environmentName)");
			}
			if (environmentTO.getSelectedApplication() > 0L) {
				query.append(" and m.application_id =:envApplicationId ");
			}
			if (environmentTO.getStatus() > 0L) {
				query.append(" and e.STATUS =:status");
			}
			q = session.createSQLQuery(query.toString());
			if (environmentTO.getClientId() == 0) {
				q.setParameter("envInvalidStatus", invalidStatus);
			} else if ((environmentTO.getClientId() != 0) && (environmentTO.getRoleId() == 1)) {
				if (!clientIdlist.isEmpty()) {
					q.setParameterList("clientIdList", clientIdlist);
				}
				q.setParameter("envInvalidStatus", invalidStatus);
			} else {
				q.setParameter("envInvalidStatus", invalidStatus);
				q.setParameter("userId", userTo.getId());
			}
			if (StringUtils.hasText(environmentTO.getEnvironmentName())) {
				q.setParameter("environmentName", "%".concat(environmentTO.getEnvironmentName().concat("%")));
			}
			if (environmentTO.getSelectedApplication() > 0L) {
				q.setParameter("envApplicationId", environmentTO.getSelectedApplication());
			}
			if (environmentTO.getStatus() > 0L) {
				q.setParameter("status", environmentTO.getStatus());
			}
			List<Object[]> objList = q.list();
			for (Object[] temp : objList) {
				EnvironmentTO envObj = new EnvironmentTO();
				envObj.setId(((Number) temp[0]).longValue());
				envObj.setEnvironmentName((String) temp[1]);
				envObj.setEnvStatus((String) temp[2]);
				envList.add(envObj);
			}
			return envList;
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:searchEnv.", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public Long getReservedEnvCount(Long clientId, List<Long> clientIdlist, EnvironmentTO environmentTO, UserTO userTO) throws CMMException {
	
		Long reserved = 0L;
		Session session = null;
		StringBuilder query = new StringBuilder();
		try {
			session = getSession();
			Date currentDate = DateUtils.getStartTime(new Date());
			if (environmentTO.getClientId() == 0) {
				query.append("select distinct e.id from environments e , environment_application m , status s where m.environment_id =e.id and e.STATUS=s.id and e.STATUS=(:availableStatus)");
			} else if ((environmentTO.getClientId() != 0) && (environmentTO.getRoleId() == 1)) {
				query.append("select distinct e.id from environments e , environment_application m , status s , user_business_unit u where m.environment_id =e.id and e.STATUS=s.id and e.STATUS=(:availableStatus) and m.application_id in (select a.id from applications a where a.client_id in(:clientIdList))");
			} else {
				query.append("select distinct e.id from environments e , environment_application m , status s, user_group_details ugd, user_groups ug,applications a where m.environment_id =e.id and m.application_id = a.id and ug.id=a.user_grp_id and ug.id = ugd.group_id and ugd.user_id =:userId and e.STATUS = s.id and e.STATUS=(:availableStatus)");
			}
			query.append("and e.id in (select distinct r.environment_id from reservation r where r.status=(:reservedStatus) and r.endTime>(:endTime))");
			Query q = session.createSQLQuery(query.toString());
			if (environmentTO.getClientId() == 0) {
				q.setParameter("availableStatus", CMMConstants.Framework.Entity.ENVIRONMENT_STATUS_AVAILABLE);
			} else if ((environmentTO.getClientId() != 0) && (environmentTO.getRoleId() == 1)) {
				q.setParameterList("clientIdList", clientIdlist);
				q.setParameter("availableStatus", CMMConstants.Framework.Entity.ENVIRONMENT_STATUS_AVAILABLE);
			} else {
				q.setParameter("availableStatus", CMMConstants.Framework.Entity.ENVIRONMENT_STATUS_AVAILABLE);
				q.setParameter("userId", userTO.getId());
			}
			q.setParameter("reservedStatus", Entity.RESERVATION_STATUS_APPROVED);
			q.setParameter("endTime", currentDate);
			q.list();
			reserved = (long) q.list().size();
			return reserved;
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:getReservedEnvCount.", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public Map<String, Long> getNotReservedFrom4WeeksCount(UserTO user, List<Long> groups) throws CMMException {
	
		try {
			HashMap<String, Long> count = new HashMap<String, Long>();
			Date currentDate = DateUtils.getStartTime(new Date());
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(currentDate);
			calendar.add(Calendar.DAY_OF_YEAR, -30);
			Date modifiedDate = calendar.getTime();
			Calendar calendar1 = Calendar.getInstance();
			calendar1.setTime(currentDate);
			calendar1.add(Calendar.DAY_OF_YEAR, 30);
			Long available;
			Long unreserved;
			Long total;
			if (user.getClientId() == 0L) {
				String query = "SELECT  count ( distinct e.id) FROM EnvironmentTO e ,ReservationTO r, EnvironmentApplicationTO ea where (r.environments.id = e.id and r.startTime>=? and r.endTime<= ? ) and e.id=ea.environmentTO.id and r.status.id=81 and e.status in( 21,23) and e.createdByDate<=?";
				List<Long> objList = (List<Long>) getHibernateTemplate().find(query, modifiedDate, currentDate, currentDate);
				if (!objList.isEmpty()) {
					available = objList.get(0);
				} else {
					available = 0L;
				}
				String queryTotal = "SELECT  count ( distinct e.id) FROM EnvironmentTO e, EnvironmentApplicationTO ea  where   e.status in( 21,23) and e.id=ea.environmentTO.id and e.createdByDate<=?";
				List<Long> objListTotal = (List<Long>) getHibernateTemplate().find(queryTotal, currentDate);
				if (!objListTotal.isEmpty()) {
					total = objListTotal.get(0);
				} else {
					total = 0L;
				}
				unreserved = total - available;
			} else if (user.getRoleId() == 1L) {
				List<Long> objList = (List<Long>) getHibernateTemplate().findByNamedParam("SELECT  count ( distinct e.id) FROM EnvironmentTO e ,ReservationTO r,  ApplicationTO a, EnvironmentApplicationTO ea where (r.environments.id = e.id and r.startTime>= (:sdate) and r.endTime<= (:edate) ) and e.id=ea.environmentTO.id and a.id=ea.applicationTO.id and e.createdByDate<=(:edate) and a.clientId in (:clients) and  r.status.id=81 and e.status in( 21,23) ", new String[] { "sdate", "edate", "clients" }, new Object[] { modifiedDate, currentDate, user.getClientList() });
				if (!objList.isEmpty()) {
					available = objList.get(0);
				} else {
					available = 0L;
				}
				List<Long> objListTotal = (List<Long>) getHibernateTemplate().findByNamedParam("SELECT  count ( distinct e.id) FROM EnvironmentTO e, ApplicationTO a, EnvironmentApplicationTO ea  where e.id=ea.environmentTO.id and a.id=ea.applicationTO.id and a.clientId in (:clients) and e.status in( 21,23) and e.createdByDate<= (:edate)", new String[] { "clients", "edate" }, new Object[] { user.getClientList(), currentDate });
				if (!objListTotal.isEmpty()) {
					total = objListTotal.get(0);
				} else {
					total = 0L;
				}
				unreserved = total - available;
			} else {
				List<Long> objList = (List<Long>) getHibernateTemplate().findByNamedParam("SELECT  count ( distinct e.id) FROM EnvironmentTO e ,ReservationTO r, ApplicationTO a, UserGroupTO u, EnvironmentApplicationTO ea, UserGroupDetailsTO ug where (r.environments.id = e.id and r.startTime>= (:sdate) and r.endTime<= (:edate) ) and e.id=ea.environmentTO.id and u.id=ug.userGroups.id and ug.userGroups.id=a.userGroups.id and ug.userGroups.id in(:usergroups) and a.id=ea.applicationTO.id and e.createdByDate<=(:edate) and a.clientId in (:clients) and  r.status.id=81 and e.status in( 21,23) ", new String[] { "sdate", "edate", "clients", "usergroups" }, new Object[] { modifiedDate, currentDate, user.getClientList(), groups });
				if (!objList.isEmpty()) {
					available = objList.get(0);
				} else {
					available = 0L;
				}
				List<Long> objListTotal = (List<Long>) getHibernateTemplate().findByNamedParam("SELECT  count ( distinct e.id) FROM EnvironmentTO e, ApplicationTO a, UserGroupTO u, EnvironmentApplicationTO ea, UserGroupDetailsTO ug  where e.id=ea.environmentTO.id and u.id=ug.userGroups.id and ug.userGroups.id=a.userGroups.id and ug.userGroups.id in(:usergroups) and a.id=ea.applicationTO.id and a.clientId in (:clients) and e.status in( 21,23) and e.createdByDate<= (:edate)", new String[] { "clients", "edate", "usergroups" }, new Object[] { user.getClientList(), currentDate, groups });
				if (!objListTotal.isEmpty()) {
					total = objListTotal.get(0);
				} else {
					total = 0L;
				}
				unreserved = total - available;
			}
			count.put("Reserved", available);
			count.put("Unreserved", unreserved);
			count.put("Total", total);
			return count;
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:getNotReservedFrom4WeeksCount", dae);
		}
	}
	
	@Override
	public Map<String, Long> getNotReservedFromPrevCount(Date modifiedDate, Date modifiedDate1, UserTO user, List<Long> groups) throws CMMException {
	
		try {
			Map<String, Long> count = new HashMap<String, Long>();
			Long available;
			Long unreserved;
			Long total;
			if (user.getClientId() == 0L) {
				String query = "SELECT  count ( distinct e.id) FROM EnvironmentTO e ,ReservationTO r, EnvironmentApplicationTO ea where (r.environments.id = e.id and r.startTime>=? and r.endTime<= ? ) and e.id=ea.environmentTO.id and r.status.id=81 and e.status in( 21,23) and e.createdByDate<=?";
				List<Long> objList = (List<Long>) getHibernateTemplate().find(query, modifiedDate, modifiedDate1, modifiedDate1);
				if (!objList.isEmpty()) {
					available = objList.get(0);
				} else {
					available = 0L;
				}
				String queryTotal = "SELECT  count ( distinct e.id) FROM EnvironmentTO e, EnvironmentApplicationTO ea  where   e.status in( 21,23) and e.id=ea.environmentTO.id and e.createdByDate<=?";
				List<Long> objListTotal = (List<Long>) getHibernateTemplate().find(queryTotal, modifiedDate1);
				if (!objListTotal.isEmpty()) {
					total = objListTotal.get(0);
				} else {
					total = 0L;
				}
				unreserved = total - available;
			} else if (user.getRoleId() == 1L) {
				List<Long> objList = (List<Long>) getHibernateTemplate().findByNamedParam("SELECT  count ( distinct e.id) FROM EnvironmentTO e ,ReservationTO r, ApplicationTO a, EnvironmentApplicationTO ea where (r.environments.id = e.id and r.startTime>= (:sdate) and r.endTime<= (:edate) ) and e.id=ea.environmentTO.id and a.id=ea.applicationTO.id and e.createdByDate<=(:edate) and a.clientId in (:clients) and  r.status.id=81 and e.status in( 21,23) ", new String[] { "sdate", "edate", "clients" }, new Object[] { modifiedDate, modifiedDate1, user.getClientList() });
				if (!objList.isEmpty()) {
					available = objList.get(0);
				} else {
					available = 0L;
				}
				List<Long> objListTotal = (List<Long>) getHibernateTemplate().findByNamedParam("SELECT  count ( distinct e.id) FROM EnvironmentTO e, ApplicationTO a, EnvironmentApplicationTO ea  where e.id=ea.environmentTO.id and a.id=ea.applicationTO.id and a.clientId in (:clients) and e.status in( 21,23) and e.createdByDate<= (:edate)", new String[] { "edate", "clients" }, new Object[] { modifiedDate1, user.getClientList() });
				if (!objListTotal.isEmpty()) {
					total = objListTotal.get(0);
				} else {
					total = 0L;
				}
				unreserved = total - available;
			} else {
				List<Long> objList = (List<Long>) getHibernateTemplate().findByNamedParam("SELECT  count ( distinct e.id) FROM EnvironmentTO e ,ReservationTO r, ApplicationTO a, EnvironmentApplicationTO ea, UserGroupDetailsTO ug, UserGroupTO u where (r.environments.id = e.id and r.startTime>= (:sdate) and r.endTime<= (:edate) ) and e.id=ea.environmentTO.id and u.id=ug.userGroups.id and ug.userGroups.id=a.userGroups.id and ug.userGroups.id in(:usergroups) and a.id=ea.applicationTO.id and e.createdByDate<=(:edate) and a.clientId in (:clients) and  r.status.id=81 and e.status in( 21,23) ", new String[] { "sdate", "edate", "clients", "usergroups" }, new Object[] { modifiedDate, modifiedDate1, user.getClientList(), groups });
				if (!objList.isEmpty()) {
					available = objList.get(0);
				} else {
					available = 0L;
				}
				List<Long> objListTotal = (List<Long>) getHibernateTemplate().findByNamedParam("SELECT  count ( distinct e.id) FROM EnvironmentTO e, ApplicationTO a, EnvironmentApplicationTO ea, UserGroupTO u, UserGroupDetailsTO ug  where e.id=ea.environmentTO.id and a.id=ea.applicationTO.id and u.id=ug.userGroups.id and ug.userGroups.id=a.userGroups.id and ug.userGroups.id in(:usergroups) and a.clientId in (:clients)  and e.status in( 21,23) and e.createdByDate<= (:edate)", new String[] { "edate", "clients", "usergroups" }, new Object[] { modifiedDate1, user.getClientList(), groups });
				if (!objListTotal.isEmpty()) {
					total = objListTotal.get(0);
				} else {
					total = 0L;
				}
				unreserved = total - available;
			}
			count.put("Reserved", available);
			count.put("Unreserved", unreserved);
			count.put("Total", total);
			return count;
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:getNotReservedFromPrevCount", dae);
		}
	}
	
	@Override
	public List<EnvironmentTO> getEnvironmentReservationDetails(Long id1, Long id2, UserTO user) throws CMMException {
	
		List<EnvironmentTO> environments = new ArrayList<>(0);
		try {
			if (user.getClientId() == 0L) {
				if (id1 == 0L) {
					String query = "SELECT distinct e FROM EnvironmentTO e ,ReservationTO r, EnvironmentApplicationTO ea where (r.environments.id = e.id and r.startTime>=? and r.endTime<= ? ) and e.id=ea.environmentTO.id and r.status.id=81 and e.status in( 21,23) and e.createdByDate<=?";
					environments = (List<EnvironmentTO>) getHibernateTemplate().find(query, user.getFromDate(), user.getToDate(), user.getToDate());
				}
				if (id1 == 1L) {
					List<Long> envIds = (List<Long>) getHibernateTemplate().find("SELECT distinct e.id FROM EnvironmentTO e ,ReservationTO r, EnvironmentApplicationTO ea where (r.environments.id = e.id and r.startTime>=? and r.endTime<= ? ) and e.id=ea.environmentTO.id and r.status.id=81 and e.status in( 21,23) and e.createdByDate<=?", user.getFromDate(), user.getToDate(), user.getToDate());
					if (!envIds.isEmpty()) {
						environments = (List<EnvironmentTO>) getHibernateTemplate().findByNamedParam("SELECT distinct e from EnvironmentTO e, EnvironmentApplicationTO ea where e.id=ea.environmentTO.id and e.status in( 21,23) and e.createdByDate<= (:date) and e.id not in(:env)", new String[] { "date", "env" }, new Object[] { user.getToDate(), envIds });
					} else {
						environments = (List<EnvironmentTO>) getHibernateTemplate().findByNamedParam("SELECT distinct e from EnvironmentTO e, EnvironmentApplicationTO ea where e.id=ea.environmentTO.id and e.status in( 21,23) and e.createdByDate<= (:date) ", new String[] { "date" }, new Object[] { user.getToDate() });
					}
				}
			} else if (user.getRoleId() == 1L) {
				if (id1 == 0L) {
					environments = (List<EnvironmentTO>) getHibernateTemplate().findByNamedParam("SELECT  distinct e FROM EnvironmentTO e ,ReservationTO r, ApplicationTO a, EnvironmentApplicationTO ea where (r.environments.id = e.id and r.startTime>= (:sdate) and r.endTime<= (:edate) ) and e.id=ea.environmentTO.id and a.id=ea.applicationTO.id and e.createdByDate<=(:edate) and a.clientId in (:clients) and  r.status.id=81 and e.status in( 21,23) ", new String[] { "sdate", "edate", "clients" }, new Object[] { user.getFromDate(), user.getToDate(), user.getClientList() });
				}
				if (id1 == 1L) {
					List<Long> envIds = (List<Long>) getHibernateTemplate().findByNamedParam("SELECT  distinct e.id FROM EnvironmentTO e ,ReservationTO r, ApplicationTO a, EnvironmentApplicationTO ea where (r.environments.id = e.id and r.startTime>= (:sdate) and r.endTime<= (:edate) ) and e.id=ea.environmentTO.id and a.id=ea.applicationTO.id and e.createdByDate<=(:edate) and a.clientId in (:clients) and  r.status.id=81 and e.status in( 21,23) ", new String[] { "sdate", "edate", "clients" }, new Object[] { user.getFromDate(), user.getToDate(), user.getClientList() });
					if (!envIds.isEmpty()) {
						environments = (List<EnvironmentTO>) getHibernateTemplate().findByNamedParam("SELECT  distinct e FROM EnvironmentTO e , ApplicationTO a, EnvironmentApplicationTO ea where e.id=ea.environmentTO.id and a.id=ea.applicationTO.id and e.createdByDate<=(:edate) and a.clientId in (:clients)  and e.id not in (:env)  and e.status in( 21,23)", new String[] { "edate", "clients", "env" }, new Object[] { user.getToDate(), user.getClientList(), envIds });
					} else {
						environments = (List<EnvironmentTO>) getHibernateTemplate().findByNamedParam("SELECT  distinct e FROM EnvironmentTO e , ApplicationTO a, EnvironmentApplicationTO ea where e.id=ea.environmentTO.id and a.id=ea.applicationTO.id and e.createdByDate<=(:edate) and a.clientId in (:clients) and e.status in( 21,23)", new String[] { "edate", "clients" }, new Object[] { user.getToDate(), user.getClientList() });
					}
				}
			} else {
				if (id1 == 0L) {
					environments = (List<EnvironmentTO>) getHibernateTemplate().findByNamedParam("SELECT  distinct e FROM EnvironmentTO e ,ReservationTO r, ApplicationTO a, EnvironmentApplicationTO ea, UserGroupDetailsTO ug, UserGroupTO u where (r.environments.id = e.id and r.startTime>= (:sdate) and r.endTime<= (:edate) ) and e.id=ea.environmentTO.id and u.id=ug.userGroups.id and ug.userGroups.id=a.userGroups.id and ug.userGroups.id in(:usergroups) and a.id=ea.applicationTO.id and e.createdByDate<=(:edate) and a.clientId in (:clients) and  r.status.id=81 and e.status in( 21,23) ", new String[] { "sdate", "edate", "clients", "usergroups" }, new Object[] { user.getFromDate(), user.getToDate(), user.getClientList(), user.getUserList() });
				}
				if (id1 == 1L) {
					List<Long> envIds = (List<Long>) getHibernateTemplate().findByNamedParam("SELECT  distinct e.id FROM EnvironmentTO e ,ReservationTO r, ApplicationTO a, EnvironmentApplicationTO ea, UserGroupDetailsTO ug, UserGroupTO u where (r.environments.id = e.id and r.startTime>= (:sdate) and r.endTime<= (:edate) ) and e.id=ea.environmentTO.id and u.id=ug.userGroups.id and ug.userGroups.id=a.userGroups.id and ug.userGroups.id in(:usergroups) and a.id=ea.applicationTO.id and e.createdByDate<=(:edate) and a.clientId in (:clients) and  r.status.id=81 and e.status in( 21,23) ", new String[] { "sdate", "edate", "clients", "usergroups" }, new Object[] { user.getFromDate(), user.getToDate(), user.getClientList(), user.getUserList() });
					if (!envIds.isEmpty()) {
						environments = (List<EnvironmentTO>) getHibernateTemplate().findByNamedParam("SELECT  distinct e FROM EnvironmentTO e, ApplicationTO a, EnvironmentApplicationTO ea, UserGroupDetailsTO ug, UserGroupTO u where e.id=ea.environmentTO.id and u.id=ug.userGroups.id and ug.userGroups.id=a.userGroups.id and ug.userGroups.id in(:usergroups) and a.id=ea.applicationTO.id and e.createdByDate<=(:edate) and a.clientId in (:clients) and e.status in( 21,23) and e.id not in (:env)", new String[] { "edate", "clients", "usergroups", "env" }, new Object[] { user.getToDate(), user.getClientList(), user.getUserList(), envIds });
					} else {
						environments = (List<EnvironmentTO>) getHibernateTemplate().findByNamedParam("SELECT  distinct e FROM EnvironmentTO e, ApplicationTO a, EnvironmentApplicationTO ea, UserGroupDetailsTO ug, UserGroupTO u where e.id=ea.environmentTO.id and u.id=ug.userGroups.id and ug.userGroups.id=a.userGroups.id and ug.userGroups.id in(:usergroups) and a.id=ea.applicationTO.id and e.createdByDate<=(:edate) and a.clientId in (:clients) and e.status in( 21,23) ", new String[] { "edate", "clients", "usergroups" }, new Object[] { user.getToDate(), user.getClientList(), user.getUserList() });
					}
				}
			}
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl: getEnvironmentReservationDetails", dae);
		}
		return environments;
	}
	
	@Override
	public List<EnvironmentTO> searchAvailableEnvForHome(EnvironmentTO environmentTO, UserTO userTo, List<Long> clientIdlist) throws CMMException {
	
		Session session = null;
		Query q = null;
		StringBuilder query = new StringBuilder();
		try {
			List<EnvironmentTO> envList = new ArrayList<EnvironmentTO>(0);
			session = getSession();
			Date currentDate = DateUtils.getStartTime(new Date());
			if (environmentTO.getClientId() == 0) {
				query.append("select distinct e.id from environments e , environment_application m , status s where m.environment_id =e.id and e.STATUS=s.id and e.STATUS=(:availableStatus)");
			} else if ((environmentTO.getClientId() != 0) && (userTo.getRoleId() == 1)) {
				query.append("select distinct e.id  from environments e , environment_application m , status s where m.environment_id =e.id and e.STATUS=s.id and e.STATUS=(:availableStatus)  and m.application_id in ( select a.id from applications a where a.client_id in(:clientIdList))");
			} else {
				query.append("select distinct e.id from environments e , environment_application m , status s, user_group_details ugd, user_groups ug,applications a where m.environment_id =e.id and m.application_id = a.id and ug.id=a.user_grp_id and ug.id = ugd.group_id and ugd.user_id =:userId and e.STATUS = s.id and e.STATUS=(:availableStatus)");
			}
			query.append("and e.id not in (select distinct r.environment_id from reservation r where r.status=(:reservedStatus) and r.endTime>(:endTime))");
			q = session.createSQLQuery(query.toString());
			if (environmentTO.getClientId() == 0) {
				q.setParameter("availableStatus", CMMConstants.Framework.Entity.ENVIRONMENT_STATUS_AVAILABLE);
			} else if ((environmentTO.getClientId() != 0) && (userTo.getRoleId() == 1)) {
				q.setParameter("availableStatus", CMMConstants.Framework.Entity.ENVIRONMENT_STATUS_AVAILABLE);
				q.setParameterList("clientIdList", clientIdlist);
			} else {
				q.setParameter("userId", userTo.getId());
				q.setParameter("availableStatus", CMMConstants.Framework.Entity.ENVIRONMENT_STATUS_AVAILABLE);
			}
			q.setParameter("reservedStatus", Entity.RESERVATION_STATUS_APPROVED);
			q.setParameter("endTime", currentDate);
			List<Object[]> objList = q.list();
			String query1 = "select distinct e.environment_name,e.id from environments e where e.id in( :eid)";
			q = session.createSQLQuery(query1);
			q.setParameterList("eid", objList);
			Iterator itrDatasetList = q.list().iterator();
			while (itrDatasetList.hasNext()) {
				EnvironmentTO objEnv = new EnvironmentTO();
				Object arrDataList[] = (Object[]) itrDatasetList.next();
				objEnv.setId(Long.parseLong(arrDataList[1].toString()));
				objEnv.setEnvironmentName(arrDataList[0].toString());
				envList.add(objEnv);
			}
			return envList;
		} catch (DataAccessException | HibernateException e) {
			LOG.error(e);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:searchAvailableEnvForHome.", e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<EnvironmentTO> searchReservedEnvForHome(EnvironmentTO environmentTO, UserTO userTo, List<Long> clientIdlist) throws CMMException {
	
		Session session = null;
		try {
			List<EnvironmentTO> envList = new ArrayList<EnvironmentTO>();
			StringBuilder query = new StringBuilder();
			session = getSession();
			Date currentDate = DateUtils.getStartTime(new Date());
			if (environmentTO.getClientId() == 0) {
				query.append("select distinct e.id from environments e , environment_application m , status s where m.environment_id =e.id and e.STATUS=s.id and e.STATUS=(:availableStatus)");
			} else if ((environmentTO.getClientId() != 0) && (userTo.getRoleId() == 1)) {
				query.append("select distinct e.id  from environments e , environment_application m , status s where m.environment_id =e.id and e.STATUS=s.id and e.STATUS=(:availableStatus) and m.application_id in ( select a.id from applications a where a.client_id in(:clientIdList))");
			} else {
				query.append("select distinct e.id from environments e , environment_application m , status s, user_group_details ugd, user_groups ug,applications a where m.environment_id =e.id and m.application_id = a.id and ug.id=a.user_grp_id and ug.id = ugd.group_id and ugd.user_id =:userId and e.STATUS = s.id and e.STATUS=(:availableStatus)");
			}
			query.append("and e.id in (select distinct r.environment_id from reservation r where r.status=(:reservedStatus) and r.endTime>(:endTime))");
			Query q = session.createSQLQuery(query.toString());
			if (environmentTO.getClientId() == 0) {
				q.setParameter("availableStatus", CMMConstants.Framework.Entity.ENVIRONMENT_STATUS_AVAILABLE);
			} else if ((environmentTO.getClientId() != 0) && (userTo.getRoleId() == 1)) {
				q.setParameterList("clientIdList", clientIdlist);
				q.setParameter("availableStatus", CMMConstants.Framework.Entity.ENVIRONMENT_STATUS_AVAILABLE);
			} else {
				q.setParameter("availableStatus", CMMConstants.Framework.Entity.ENVIRONMENT_STATUS_AVAILABLE);
				q.setParameter("userId", userTo.getId());
			}
			q.setParameter("reservedStatus", Entity.RESERVATION_STATUS_APPROVED);
			q.setParameter("endTime", currentDate);
			List<Object[]> objList = q.list();
			String query1 = "select distinct e.environment_name,e.id from environments e where e.id in( :eid)";
			q = session.createSQLQuery(query1);
			q.setParameterList("eid", objList);
			Iterator itrDatasetList = q.list().iterator();
			while (itrDatasetList.hasNext()) {
				EnvironmentTO objEnv = new EnvironmentTO();
				Object arrDataList[] = (Object[]) itrDatasetList.next();
				objEnv.setId(Long.parseLong(arrDataList[1].toString()));
				objEnv.setEnvironmentName(arrDataList[0].toString());
				envList.add(objEnv);
			}
			return envList;
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:searchReservedEnvForHome", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<EnvironmentTO> searchRequestedEnvForHome(EnvironmentTO environmentTO, UserTO userTo, List<Long> clientIdlist) throws CMMException {
	
		Query q = null;
		Session session = null;
		List<EnvironmentTO> envList = new ArrayList<EnvironmentTO>();
		try {
			session = getSession();
			String query = null;
			if (environmentTO.getClientId() == 0) {
				query = "select distinct e.id from environments e , environment_application m , status s  where m.environment_id =e.id and e.STATUS=s.id and e.STATUS in(:Status)";
			} else if ((environmentTO.getClientId() != 0) && (userTo.getRoleId() == 1)) {
				query = "select distinct e.id from environments e , environment_application m , status s  where m.environment_id =e.id and e.STATUS=s.id and e.STATUS in (:Status) and m.application_id in ( select a.id from applications a where a.client_id in(:clientIdList))";
			} else {
				query = "select distinct e.id from environments e , environment_application m , status s, user_group_details ugd, user_groups ug,applications a where m.environment_id =e.id and m.application_id = a.id and ug.id=a.user_grp_id and ug.id = ugd.group_id and ugd.user_id =:userId and e.STATUS = s.id and e.STATUS in (:Status)";
			}
			List<Long> statusList = new ArrayList<Long>();
			statusList.add(CMMConstants.Framework.Entity.ENVIRONMENT_STATUS_UNDERIMPLEMENTATION);
			statusList.add(CMMConstants.Framework.Entity.ENVIRONMENT_REQUEST_PENDING);
			q = session.createSQLQuery(query);
			if (environmentTO.getClientId() == 0) {
				q.setParameterList("Status", statusList);
			} else if ((environmentTO.getClientId() != 0) && (userTo.getRoleId() == 1)) {
				q.setParameterList("clientIdList", clientIdlist);
				q.setParameterList("Status", statusList);
			} else {
				q.setParameter("userId", userTo.getId());
				q.setParameterList("Status", statusList);
			}
			List<Object[]> objList = q.list();
			String query1 = "select distinct e.environment_name,e.id from environments e where e.id in(:eid)";
			q = session.createSQLQuery(query1);
			q.setParameterList("eid", objList);
			Iterator itrDatasetList = q.list().iterator();
			while (itrDatasetList.hasNext()) {
				EnvironmentTO objEnv = new EnvironmentTO();
				Object arrDataList[] = (Object[]) itrDatasetList.next();
				objEnv.setId(Long.parseLong(arrDataList[1].toString()));
				objEnv.setEnvironmentName(arrDataList[0].toString());
				envList.add(objEnv);
			}
			return envList;
		} catch (DataAccessException | HibernateException e) {
			LOG.error(e);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:searchRequestedEnvForHome.", e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<EnvironmentTO> searchRequestedEnvForHome(Long clientId, EnvironmentTO environmentTO) throws CMMException {
	
		Session session = null;
		List<EnvironmentTO> envList = new ArrayList<EnvironmentTO>();
		try {
			session = getSession();
			String hql = "select e.id, e.environmentName  from EnvironmentTO e where e.id in (select ea.environmentTO.id from EnvironmentApplicationTO ea where ea.applicationTO.id in (select a.id from ApplicationTO a where a.businessUnitTO.id  =:clientId))";
			Query q = session.createQuery(hql);
			q.setParameter("clientId", clientId);
			Iterator itrDatasetList = q.list().iterator();
			while (itrDatasetList.hasNext()) {
				EnvironmentTO objEnvironmentTO = new EnvironmentTO();
				Object arrDataList[] = (Object[]) itrDatasetList.next();
				objEnvironmentTO.setId(Long.parseLong(arrDataList[0].toString()));
				objEnvironmentTO.setEnvironmentName(arrDataList[1].toString());
				envList.add(objEnvironmentTO);
			}
			return envList;
		} catch (DataAccessException | HibernateException e) {
			LOG.error(e);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:searchRequestedEnvForHome.", e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<EnvironmentTO> searchEnvNotReservedFrom4WeeksForHome(EnvironmentTO environmentTO) throws CMMException {
	
		Date currentDate = DateUtils.getStartTime(new Date());
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(currentDate);
		calendar.add(Calendar.DAY_OF_YEAR, -28);
		Date modifiedDate = calendar.getTime();
		Calendar calendar1 = Calendar.getInstance();
		calendar1.setTime(currentDate);
		calendar1.add(Calendar.DAY_OF_YEAR, 28);
		Date endDate = calendar1.getTime();
		try {
			List<EnvironmentTO> envList = new ArrayList<EnvironmentTO>();
			String query = "select e.id,e.environmentName,e.status,s.statusDesc FROM EnvironmentTO e ,ReservationTO r,StatusTO s where ((r.environments.id<> e.id  and e.modifiedbyDate<? ) OR (r.environments.id = e.id and r.endTime<?)) and  (r.status.id<> 82 and e.status= 21) and r.status.id = s.id group by e.id ,e.environmentName,e.status,s.statusDesc";
			List<Object[]> object = (List<Object[]>) getHibernateTemplate().find(query, modifiedDate, endDate);
			for (Object[] obj : object) {
				List<EnvironmentApplicationTO> temp = (List<EnvironmentApplicationTO>) getHibernateTemplate().find("from EnvironmentApplicationTO e where environmentTO.id=?", obj[0]);
				for (EnvironmentApplicationTO t : temp) {
					EnvironmentTO env = new EnvironmentTO();
					ApplicationTO appname;
					appname = t.getApplicationTO();
					ProjectsTO project = (ProjectsTO) getHibernateTemplate().find("from ProjectsTO p where p.id=?", appname.getProjectTO().getId()).get(0);
					BusinessUnitTO businessUnit = (BusinessUnitTO) getHibernateTemplate().find("from BusinessUnitTO b where b.clientId=?", appname.getBusinessUnitTO().getClientId()).get(0);
					env.setBusinessUnit(businessUnit.getName());
					env.setProject(project.getName());
					env.setEnvStatus(obj[3].toString());
					env.setApplicationName(appname.getAppName());
					env.setEnvironmentName((String) obj[1]);
					envList.add(env);
				}
			}
			return envList;
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:searchEnvNotReservedFrom4WeeksForHome", dae);
		}
	}
	
	@Override
	public List<Object[]> getEnvironmentSnapshot(EnvironmentTO environmentTO) throws CMMException {
	
		List<Object[]> object = null;
		Session session = null;
		try {
			session = getSession();
			String dbName = getDbName();
			String query1 = "select top 1 e.id,e.environment_name,e.application_id,ap.application_name, e.release_id,max(ed.HARDWARE_ID), h.name,ed.software_id, (SELECT  snames = Stuff((SELECT ',' + sname from (SELECT distinct sw.name as sname FROM software sw inner join environment_details ed on sw.id = ed.software_id inner join environments e on e.id = ed.environment_id and e.id = ?) temp FOR xml path('')), 1, 1, '')) sname, ev.server_tmplt_id,ev.vm_name, ar.release_name,ar.source_path,r.id res_id,r.starttime,r.endtime,s.status_desc, art.test_tool,art.test_script_path,arb.build_tool,arb.build_script_path, ard.database_scripts_path,database_scripts,ard.ctime from environments e left outer join environment_details ed on e.id = ed.environment_id left outer join environment_vm_details ev on e.id = ev.environment_id left outer join reservation r on e.id = r.environment_id and e.application_id = r.application_id left outer join status s on r.status=s.id left outer join applications ap on e.application_id = ap.id left outer join hardwares h on h.id = ed.hardware_id left outer join application_release ar on ar.application_id = e.application_id and ar.id = e.release_id left outer join application_release_source_code ars on ars.application_release_id = ar.id and ars.application_release_id = e.release_id left outer join application_release_build arb on arb.application_release_id = e.release_id left outer join application_release_test art on art.application_release_id = e.release_id left outer join application_release_db ard on ard.application_release_id = e.release_id and ard.software_config_id = ed.software_id where e.id=? group by e.id,e.environment_name,e.application_id,ap.application_name,e.release_id, ed.hardware_id, h.name,ed.software_id,ev.server_tmplt_id,ev.vm_name, ar.release_name,ar.source_path,r.id,r.starttime,r.endtime,s.status_desc, art.test_tool,art.test_script_path,arb.build_tool,arb.build_script_path, ard.database_scripts_path,database_scripts,ard.ctime";
			String query2 = "select e.id,e.environment_name,e.application_id,ap.application_name, e.release_id,ed.hardware_id, h.name,ed.software_id,GROUP_CONCAT(distinct sw.name SEPARATOR ','),ev.server_tmplt_id,ev.vm_name, ar.release_name,ar.source_path,r.id res_id,r.starttime,r.endtime,s.status_desc,art.test_tool,art.test_script_path,arb.build_tool,arb.build_script_path,ard.database_scripts_path,database_scripts,ard.ctime from environments e left outer join environment_details ed on e.id = ed.environment_id left outer join environment_vm_details ev on e.id = ev.environment_id left outer join reservation r on e.id = r.environment_id and e.application_id = r.application_id left outer join status s on r.status=s.id left outer join applications ap on e.application_id = ap.id left outer join hardwares h on h.id = ed.hardware_id left outer join software sw on sw.id = ed.software_id left outer join application_release ar on ar.application_id = e.application_id and ar.id = e.release_id left outer join application_release_source_code ars on ars.application_release_id = ar.id and ars.application_release_id = e.release_id left outer join application_release_build arb on arb.application_release_id = e.release_id left outer join application_release_test art on art.application_release_id = e.release_id left outer join application_release_db ard on ard.application_release_id = e.release_id and ard.software_config_id = ed.software_id where e.id=? group by ed.hardware_id";
			if ("SQLSERVER".equalsIgnoreCase(dbName)) {
				SQLQuery sqlQuery = session.createSQLQuery(query1);
				sqlQuery.setParameter(0, environmentTO.getId());
				sqlQuery.setParameter(1, environmentTO.getId());
				object = sqlQuery.list();
			}
			if ("MYSQL".equalsIgnoreCase(dbName)) {
				SQLQuery sqlQuery = session.createSQLQuery(query2);
				sqlQuery.setParameter(0, environmentTO.getId());
				object = sqlQuery.list();
			}
			return object;
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:getEnvironmentSnapshot", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public Long checkURLMonitoring(String releaseId, String environmentId) throws CMMException {
	
		try {
			Long rel = Long.parseLong(releaseId);
			Long env = Long.parseLong(environmentId);
			Long statusCode = 0L;
			String ip = "";
			String contextName = "";
			Long provisionId;
			String hostname = "";
			List<ApplicationReleaseSourcecodeTO> list = (List<ApplicationReleaseSourcecodeTO>) getHibernateTemplate().find("select a from ApplicationReleaseSourcecodeTO a where a.applicationReleaseId=?", rel);
			if (!list.isEmpty()) {
				if (list.get(0).getContextPath() != null) {
					contextName = list.get(0).getContextPath();
				}
			}
			List<EnvironmentDetailsTO> list1 = (List<EnvironmentDetailsTO>) getHibernateTemplate().find("select e from EnvironmentDetailsTO e where e.provisionedMachine.id is not null and e.environment.id=?", env);
			if (!list1.isEmpty()) {
				if (list1.get(0).getProvisionedMachine().getId() != null) {
					provisionId = list1.get(0).getProvisionedMachine().getId();
					List<ProvisionedMachineTO> list2 = (List<ProvisionedMachineTO>) getHibernateTemplate().find("select p from ProvisionedMachineTO p where p.id=?", provisionId);
					if (!list2.isEmpty()) {
						ip = list2.get(0).getIp();
						hostname = list2.get(0).getHostName();
					}
				}
			}
			if ((ip != null) && (hostname != null)) {
				getHibernateTemplate().find("from BoaMasterTo");
				if ("".equals(contextName)) {
					LOG.info("Context name is blank");
				} else {
					statusCode = applicationDAOImpl.checkingURLForMonitoring("http://" + ip + ":8080/" + contextName);
				}
			}
			return statusCode;
		} catch (DataAccessException | HibernateException e) {
			LOG.error(e);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:checkURLMonitoring", e);
		}
	}
	
	@Override
	public String getHostName(String id) throws CMMException {
	
		try {
			Long provisionId;
			String hostname = "";
			Long envId = Long.parseLong(id);
			List<EnvironmentDetailsTO> list1 = (List<EnvironmentDetailsTO>) getHibernateTemplate().find("select e from EnvironmentDetailsTO e where e.provisionedMachine.id is not null and e.environment.id=?", envId);
			if (!list1.isEmpty()) {
				if (list1.get(0).getProvisionedMachine().getId() != null) {
					provisionId = list1.get(0).getProvisionedMachine().getId();
					List<ProvisionedMachineTO> list2 = (List<ProvisionedMachineTO>) getHibernateTemplate().find("select p from ProvisionedMachineTO p where p.hostName is not null and p.id=?", provisionId);
					if (!list2.isEmpty()) {
						hostname = list2.get(0).getHostName();
					}
				}
			}
			return hostname;
		} catch (DataAccessException | HibernateException e) {
			LOG.error(e);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:checkURLMonitoring", e);
		}
	}
	
	@Override
	public String getContextName(Long id) throws CMMException {
	
		String name = "";
		if (id > 0) {
			name = (String) getHibernateTemplate().find("select a.contextPath from ApplicationReleaseSourcecodeTO a, EnvironmentApplicationTO e where e.releaseId=a.applicationReleaseId and e.environmentTO.id=?", id).get(0);
		}
		return name;
	}
	
	public List<EnvironmentTO> getSubEnvironment1(long environmentId) throws CMMException {
	
		try {
			List<EnvironmentTO> environmentSubList = (List<EnvironmentTO>) getHibernateTemplate().find("from EnvironmentTO where parentEnv=? and envType=?", environmentId, "S");
			if ((environmentSubList == null) || environmentSubList.isEmpty()) {
				throw new CMMException();
			}
			return environmentSubList;
		} catch (DataAccessException | HibernateException e) {
			LOG.error(e);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:getSubEnvironment1.", e);
		}
	}
	
	@Override
	public List<EnvironmentTO> getSubEnvironment(long environmentId) throws CMMException {
	
		try {
			List<Long> subEnvIdList = (List<Long>) getHibernateTemplate().find("select sem.subEnvronmentId from SubEnvironmentMappingTO sem where sem.environmentId=?", environmentId);
			if ((subEnvIdList == null) || subEnvIdList.isEmpty()) {
				LOG.debug("No sub environment found for environment:: " + environmentId);
				throw new CMMException("No sub environment");
			}
			Object[] params = new Object[] { "N", subEnvIdList };
			String[] paramName = new String[] { "reservationCheckFlag", "envIdList" };
			return (List<EnvironmentTO>) getHibernateTemplate().findByNamedParam("from EnvironmentTO envTO where envTO.reservationCheck=(:reservationCheckFlag) and envTO.id in (:envIdList)", paramName, params);
		} catch (DataAccessException | HibernateException e) {
			LOG.error(e);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:getSubEnvironment.", e);
		}
	}
	
	@Override
	public void updateEnvironmentReleaseID(long releaseId, long environmentId, long applicationId) throws CMMException {
	
		try {
			EnvironmentApplicationTO environmentApplicationTO = fetchEnvironmentApplicationDetails(environmentId, applicationId);
			if (releaseId < 0) {
				environmentApplicationTO.setReleaseId(null);
			} else {
				environmentApplicationTO.setReleaseId(releaseId);
			}
			environmentApplicationTO.setTimeStamp(String.valueOf(new DateTime()).substring(0, String.valueOf(new DateTime()).indexOf(".")));
			getHibernateTemplate().update(environmentApplicationTO);
		} catch (Exception he) {
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:updateEnvironmentReleaseID", he);
		}
	}
	
	@Override
	public void updateEnvStatusAsAvailable(long environmentId) throws CMMException {
	
		EnvironmentTO environmentTO = fetchEnvironment(environmentId);
		environmentTO.setStatus(CMMConstants.Framework.Entity.ENVIRONMENT_STATUS_AVAILABLE);
		try {
			getHibernateTemplate().update(environmentTO);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:updateEnvStatusAsAvailable.", he);
		}
	}
	
	@Override
	public void updateEnvStatusAsUnAvailable(long environmentId) throws CMMException {
	
		EnvironmentTO environmentTO = fetchEnvironment(environmentId);
		environmentTO.setStatus(CMMConstants.Framework.Entity.ENVIRONMENT_STATUS_UNAVAILABLE);
		try {
			getHibernateTemplate().update(environmentTO);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:updateEnvStatusAsUnAvailable.", he);
		}
	}
	
	@Override
	public void updateEnvironmentStatusToUnderImplementation(Long envid) throws CMMException {
	
		long environmentId = envid;
		EnvironmentTO environmentTO = fetchEnvironment(environmentId);
		environmentTO.setStatus(CMMConstants.Framework.Entity.ENVIRONMENT_STATUS_UNDERIMPLEMENTATION);
		try {
			getHibernateTemplate().update(environmentTO);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.EnvironmentDAOImpl: updateEnvironmentStatusToUnderImplementation.", he);
		}
	}
	
	public EnvironmentTO fetchEnvironment(long environmentId) throws CMMException {
	
		try {
			List<EnvironmentTO> environmentList = (List<EnvironmentTO>) getHibernateTemplate().find("from EnvironmentTO where id=?", environmentId);
			if ((environmentList == null) || environmentList.isEmpty()) {
				throw new CMMException("There is no environment data for environmentId:" + environmentId);
			}
			return environmentList.get(0);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:fetchEnvironment", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:fetchEnvironment.", he);
		}
	}
	
	@Override
	public List<EnvironmentApplicationTO> getEnvAppReleaseMap(long environmentId) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			return session.createCriteria(EnvironmentApplicationTO.class).add(Restrictions.eq("environmentTO.id", environmentId)).list();
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:getEnvAppReleaseMap.", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:getEnvAppReleaseMap.", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public EnvironmentApplicationTO fetchEnvironmentApplicationDetails(long environmentId, long applicationId) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			List<EnvironmentApplicationTO> envAppList = session.createCriteria(EnvironmentApplicationTO.class).add(Restrictions.eq("environmentTO.id", environmentId)).add(Restrictions.eq("applicationTO.id", applicationId)).list();
			if ((envAppList == null) || envAppList.isEmpty()) {
				throw new CMMException("No records found in environment application table for applicationId: " + applicationId);
			}
			return envAppList.get(0);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:getSubEnvironment.", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:getSubEnvironment.", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	private ReleaseDashBoradTo createDatasetWorkFlow(ReleaseDashBoradTo releaseDashBoradTo, UserTO userTo) throws CMMException {
	
		height = 0;
		Query q = null;
		Session session = null;
		try {
			session = getSession();
			StringBuilder query = new StringBuilder("SELECT st.status_desc, ser.service_name,count(s.status_id),st.id,ser.service_id,st.status_desc  FROM service_request s, status st ,services ser  where s.status_id=st.id and ser.service_id=s.service_id");
			if (!((userTo.getClientList().size() == 1) && (userTo.getClientList().get(0) == 0))) {
				query.append(" and s.created_by in (:userIdList)  and (s.application_id in (Select id from applications a where a.client_id in (:clientList)) or s.environment_id in (Select environment_id from environment_application where application_id in (Select id from applications a where a.client_id in (:clientList))) )");
			}
			query.append(" group by s.status_id,s.service_id,st.status_desc,ser.service_name,st.id,ser.service_id order by ser.service_name");
			q = session.createSQLQuery(query.toString());
			if ((userTo.getClientList().size() == 1) && (userTo.getClientList().get(0) == 0)) {
				releaseDashBoradTo.setServiceList(q.list());
			} else {
				q.setParameter("userIdList", userTo.getId());
				q.setParameterList("clientList", userTo.getClientList());
				releaseDashBoradTo.setServiceList(q.list());
			}
			return releaseDashBoradTo;
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Error in fetching WorkFlow Detail:", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public ReleaseDashBoradTo fetchChart(ReleaseDashBoradTo releaseDashboardOld, UserTO userTo) {
	
		ReleaseDashBoradTo releaseDashboardNew = null;
		try {
			releaseDashboardNew = createDataset(releaseDashboardOld, userTo);
			releaseDashboardNew = createDatasetWorkFlow(releaseDashboardNew, userTo);
		} catch (Exception e) {
			LOG.error("Failed to fetch chart", e);
		}
		return releaseDashboardNew;
	}
	
	@Override
	public ApplicationMonitoringTO fetchChartForMonitoring(ApplicationMonitoringTO appto, UserTO userto) throws CMMException {
	
		return createDataSetApp(appto, userto);
	}
	
	@Override
	public List getEnvIdsForHost(List<String> hosts, UserTO userTo) throws CMMException {
	
		width = 0;
		height = 0;
		Session session = null;
		Query q = null;
		List list1;
		try {
			session = getSession();
			String query = "select distinct e.id from environments e, environment_details ed, provisioned_machine p where e.id=ed.environment_id and ed.provisioned_machine_tmplt_id=p.id and p.hostname in (:hostname)";
			q = session.createSQLQuery(query);
			q.setParameterList("hostname", hosts);
			list1 = q.list();
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("getEnvIdsForHost->>Error in fetching Environment Detail:", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return list1;
	}
	
	private ReleaseDashBoradTo createDataset(ReleaseDashBoradTo releaseDashBoradTo, UserTO userTo) throws CMMException {
	
		width = 0;
		height = 0;
		Session session = null;
		Query q = null;
		try {
			session = getSession();
			StringBuilder query = new StringBuilder("SELECT tp.phasename ,ar.release_name,app.application_name,ap.phs_id,ea.buildTime ,tp.colorCode,ea.application_release_id,ea.application_id FROM  applications app ,environments evn , testing_phase tp,applctn_rls_phs ap, environment_application ea LEFT OUTER JOIN application_release ar on ea.application_release_id=ar.id where app.id=ea.application_id and evn.status = '21' and tp.id=ap.phs_id and ap.applctn_id=app.id");
			if ((userTo.getClientList().size() == 1) && (userTo.getClientList().get(0) == 0)) {
				LOG.info("Size of ClientList is one or zero");
			} else {
				query.append(" and app.client_id in (:clientsList)");
			}
			query.append("  and ea.environment_id=evn.id and ea.testing_phase_id = tp.id ");
			query.append(" order by app.application_name,ap.phs_id");
			q = session.createSQLQuery(query.toString());
			if ((userTo.getClientList().size() == 1) && (userTo.getClientList().get(0) == 0)) {
				LOG.info("Size of ClientList is one or zero");
			} else {
				q.setParameterList("clientsList", userTo.getClientList());
			}
			releaseDashBoradTo.setReleaseList(q.list());
		} catch (DataAccessException dae) {
			throw new CMMException("Error in fetching Environment Detail:", dae);
		} catch (HibernateException he) {
			throw new CMMException("Error in fetching Environment Detail:", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return releaseDashBoradTo;
	}
	
	public ApplicationMonitoringTO createDataSetApp(ApplicationMonitoringTO appto, UserTO userTo) throws CMMException {
	
		width = 0;
		height = 0;
		Session session = null;
		Query q = null;
		try {
			session = getSession();
			String query = "SELECT tp.phasename ,ar.release_name,app.application_name,ap.phs_id,ea.buildTime ,tp.colorCode,ea.application_release_id,ea.application_id, evn.id, evn.environment_name FROM  applications app ,environments evn , testing_phase tp,applctn_rls_phs ap, service_request s, environment_application ea LEFT OUTER JOIN application_release ar on ea.application_release_id=ar.id where app.id=ea.application_id and evn.status = '21' and tp.id=ap.phs_id and ap.applctn_id=app.id and s.Environment_id=evn.id and s.service_id=1 and ea.application_release_id=ar.id is not null";
			if ((userTo.getClientList().size() == 1) && (userTo.getClientList().get(0) == 0)) {
				LOG.info("Size of ClientList is one or zero");
			} else {
				query = query + " and app.client_id in (:clientsList)";
			}
			query = query + "  and ea.environment_id=evn.id ";
			query += " order by app.application_name,ap.phs_id";
			q = session.createSQLQuery(query);
			if ((userTo.getClientList().size() == 1) && (userTo.getClientList().get(0) == 0)) {
				LOG.info("Size of ClientList is one or zero");
			} else {
				q.setParameterList("clientsList", userTo.getClientList());
			}
			appto.setPhaseList(q.list());
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Error in createDataSetApp:", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return appto;
	}
	
	@Override
	public List<ProvisionedMachineTO> getUserDefinedMachines(UserTO userTo) throws CMMException {
	
		width = 0;
		height = 0;
		Session session = null;
		Query q = null;
		List<ProvisionedMachineTO> machines = new ArrayList<ProvisionedMachineTO>(0);
		try {
			session = getSession();
			String query;
			if (userTo.getClientId() == 0) {
				query = "select distinct e.id,e.ENVIRONMENT_NAME,p.hostname,p.ip,p.name from environments e , environment_application m,environment_details ed, provisioned_machine p where m.environment_id =e.id and e.STATUS=21 and e.profile_Id is not null and e.id=ed.environment_id and ed.provisioned_machine_tmplt_id=p.id and p.ip is not null and p.hostname is not null";
			} else if ((userTo.getClientId() != 0) && (userTo.getRoleId() == 1)) {
				query = "select distinct e.id,e.ENVIRONMENT_NAME,p.hostname,p.ip,p.name from environments e , environment_application m , user_business_unit u ,environment_details ed, provisioned_machine p where m.environment_id =e.id and e.STATUS=21 and e.profile_Id is not null and m.application_id in ( select a.id from applications a where a.client_id in(:clientIdList)) and e.id=ed.environment_id and ed.provisioned_machine_tmplt_id=p.id and p.ip is not null and p.hostname is not null";
			} else {
				query = "select distinct e.id,e.ENVIRONMENT_NAME,p.hostname,p.ip,p.name from environments e , environment_application m ,user_group_details ugd, user_groups ug,applications a,environment_details ed, provisioned_machine p where m.environment_id =e.id and m.application_id = a.id and ug.id=a.user_grp_id and ug.id = ugd.group_id and ugd.user_id = :userId and e.STATUS =21 and e.profile_Id is not null and e.id=ed.environment_id and ed.provisioned_machine_tmplt_id=p.id and p.ip is not null and p.hostname is not null";
			}
			q = session.createSQLQuery(query);
			if (userTo.getClientId() == 0) {
				LOG.info(" ClientList is  zero");
			} else if ((userTo.getClientId() != 0) && (userTo.getRoleId() == 1)) {
				q.setParameterList("clientIdList", userTo.getClientList());
			} else {
				q.setParameter("userId", userTo.getId());
			}
			List<Object[]> obj = q.list();
			for (Object[] temp : obj) {
				ProvisionedMachineTO phyTO = new ProvisionedMachineTO();
				phyTO.setName(temp[2].toString());
				phyTO.setIp(temp[3].toString());
				phyTO.setEnvId(Long.parseLong(temp[0].toString()));
				phyTO.setEnvironmentName(temp[1].toString());
				phyTO.setServerName(temp[4].toString());
				machines.add(phyTO);
			}
			return machines;
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Error in getUserDefinedMachines:", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public long getProfileIdForEnvironment(long environmentId) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			return (Long) session.createCriteria(EnvironmentTO.class).add(Restrictions.eq("id", environmentId)).setProjection(Projections.property("profileId")).uniqueResult();
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Error in fetching profileId for rollback environmentId:" + environmentId, dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List getSoftwareListForEnv(long environmentId) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			return session.createCriteria(EnvironmentDetailsTO.class).add(Restrictions.eq("environment.id", environmentId)).setProjection(Projections.property("mappedSoftwareId")).list();
		} catch (DataAccessException dae) {
			throw new CMMException("Error in fetching Software List for environmentId:" + environmentId, dae);
		} catch (HibernateException he) {
			throw new CMMException("Can not fetch data from database for environmentId:" + environmentId, he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public String getEnvironmentName(long environmentId) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			String environmentName = (String) session.createCriteria(EnvironmentTO.class).add(Restrictions.eq("id", environmentId)).setProjection(Projections.property("environmentName")).uniqueResult();
			if (environmentName == null) {
				throw new CMMException("No records found in environments table for environmentId: " + environmentId);
			}
			return environmentName;
		} catch (DataAccessException dae) {
			throw new CMMException("Error in fetching Environment Name for environmentId:" + environmentId, dae);
		} catch (HibernateException he) {
			throw new CMMException("Can not fetch data from database for environmentId:" + environmentId, he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<ApplicationTO> getAllApplications(List<Long> clientIdlist, Long profileId) throws CMMException {
	
		logger.info("Inside getAllApplications of EnvironmentnDaoImpl");
		Session session = getSession();
		int flag = 0;
		String hql;
		List<ApplicationTO> applications = new ArrayList<ApplicationTO>();
		try {
			List<Long> objList = (List<Long>) getHibernateTemplate().find("select applicationId from ApplicationProfileMappingTO  where profileId=?", profileId);
			if (objList.isEmpty()) {
				return applications;
			}
			for (Long bU : clientIdlist) {
				if (bU == 0) {
					flag = 0;
					break;
				} else {
					flag = 1;
				}
			}
			if (flag == 1) {
				hql = "select id,appName from ApplicationTO  where id in (:userId) AND CLIENT_ID in (:clientIdList)";
			} else {
				hql = "select id,appName from ApplicationTO  where id in (:userId)";
			}
			Query q = session.createQuery(hql);
			q.setParameterList("userId", objList);
			if (flag == 1) {
				q.setParameterList("clientIdList", clientIdlist);
			}
			List<Object[]> obj = q.list();
			for (Object[] temp : obj) {
				ApplicationTO appTO = new ApplicationTO();
				appTO.setId((Long) temp[0]);
				appTO.setAppName((String) temp[1]);
				applications.add(appTO);
			}
			return applications;
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. EnvironmentnDaoImpl : getAllApplications.", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public String getprofileName(Long profileId) {
	
		Object objList = getHibernateTemplate().find("select name from ApplicationProfileTO where id=?", profileId).get(0);
		return objList.toString();
	}
	
	@Override
	public void updateSoftwareInstallationStatus(EnvironmentDetailsTO envDetailsTO) throws CMMException {
	
		try {
			envDetailsTO.setInstallationStatus("Y");
			getHibernateTemplate().update(envDetailsTO);
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. EnvironmentnDaoImpl : updateSoftwareInstallationStatus.", dae);
		}
	}
	
	@Override
	public void updateSoftInstallStatusByEnvDetId(Long environmentDetailsId) throws CMMException {
	
		EnvironmentDetailsTO envDetailsTO = fetchEnvironmentDetailsById(environmentDetailsId);
		try {
			envDetailsTO.setInstallationStatus("Y");
			getHibernateTemplate().update(envDetailsTO);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. EnvironmentnDaoImpl : updateSoftInstallStatusByEnvDetId.", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. EnvironmentnDaoImpl : updateSoftInstallStatusByEnvDetId.", he);
		}
	}
	
	/**
	 * This method fetches EnvironmentDetails object by ID.
	 *
	 * @param environmentDetailsId
	 *                PK of EnvironmentDetailsTO
	 * @return EnvironmentDetailsTO
	 * @throws CMMException
	 *                 custom Exception
	 */
	private EnvironmentDetailsTO fetchEnvironmentDetailsById(Long environmentDetailsId) throws CMMException {
	
		try {
			List<EnvironmentDetailsTO> environmentDetailsList = (List<EnvironmentDetailsTO>) getHibernateTemplate().find("from EnvironmentDetailsTO where id=?", environmentDetailsId);
			if ((environmentDetailsList == null) || environmentDetailsList.isEmpty()) {
				throw new CMMException("There is no environment data for environmentId:" + environmentDetailsId);
			}
			return environmentDetailsList.get(0);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:fetchEnvironment", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:fetchEnvironment.", he);
		}
	}
	
	/* This method is used to show details on release dashboard popup */
	@Override
	public List getDashboardDetails(String appName, String phase, String release, UserTO userTo) throws CMMException {
	
		Session session = null;
		Query q = null;
		List ids = new ArrayList();
		try {
			Long appId = Long.parseLong(appName);
			session = getSession();
			StringBuilder query = new StringBuilder("SELECT tp.phasename ,ar.id,ar.release_name,app.application_name,ea.application_Id,ea.environment_id FROM  applications app ,environments evn , testing_phase tp, environment_application ea LEFT OUTER JOIN application_release ar on ea.application_release_id=ar.id where app.id=ea.application_id and evn.status = '21' ");
			query.append(" and app.id= :applicationId ");
			query.append(" and tp.id = :phase ");
			if (release != null) {
				query.append("and ar.id=:releaseId");
			}
			if (userTo.getClientId() != 0) {
				query.append(" and app.client_id in(:clientlist)");
			}
			query.append("  and ea.environment_id=evn.id and ea.testing_phase_id = tp.id ");
			query.append(" order by app.application_name,tp.id");
			q = session.createSQLQuery(query.toString());
			q.setParameter("applicationId", appId);
			q.setParameter("phase", phase);
			if (release != null) {
				q.setParameter("releaseId", release);
			}
			if (userTo.getClientId() != 0) {
				q.setParameterList("clientlist", userTo.getClientList());
			}
			ids.addAll(q.list());
			ids.iterator();
		} catch (Exception e) {
			logger.error("getDashboardDetails" + e);
			throw new CMMException("EnvironmentDAOImpl:getDashboardDetails", e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return ids;
	}
	
	@Override
	public AddPolicyTO getPolicyDetail(long envId) throws CMMException {
	
		Session session = null;
		try {
			List<Long> appIds = new ArrayList<Long>(0);
			List<Long> projectIds = new ArrayList<Long>(0);
			List<Long> clientIds = new ArrayList<Long>(0);
			List<ApplicationTO> applications = getAllApplicationsDrivenByEnv(envId);
			for (ApplicationTO application : applications) {
				appIds.add(application.getId());
				projectIds.add(application.getProjectTO().getId());
				clientIds.add(application.getBusinessUnitTO().getClientId());
			}
			List<Long> policies = new ArrayList<Long>(0);
			Long policy;
			AddPolicyTO policyObj = new AddPolicyTO();
			if (applications.size() > 0L) {
				session = getSession();
				StringBuilder query1 = new StringBuilder(String.format("SELECT distinct t0.* FROM(SELECT distinct policy_detail_id FROM  Policy_Mapping  where  application_Id = %d", appIds.get(0)));
				query1.append(") t0");
				StringBuilder query2 = new StringBuilder(" WHERE ");
				boolean flag = false;
				String query;
				for (int i = 1; i < appIds.size(); i++) {
					flag = true;
					query1.append(String.format(",(SELECT distinct  policy_detail_id FROM  Policy_Mapping  where  application_Id = %d", appIds.get(i)));
					query1.append(String.format(") t%d", i));
					if (i == (appIds.size() - 1)) {
						query2.append(String.format("t0.policy_detail_id = t%d", i));
						query2.append(".policy_detail_id");
					} else {
						query2.append(String.format("t0.policy_detail_id = t%d", i));
						query2.append(".policy_detail_id AND ");
					}
				}
				if (flag) {
					query = query1.append(query2).toString();
				} else {
					query = query1.toString();
				}
				SQLQuery mappedProfileIDQuery = getSession().createSQLQuery(query);
				policies = mappedProfileIDQuery.list();
				if (policies.size() < 1L) {
					StringBuilder queryProject1 = new StringBuilder(String.format("SELECT distinct t0.* FROM(SELECT distinct policy_detail_id FROM  Policy_Mapping  where application_id is NULL and  project_Id = %d", projectIds.get(0)));
					queryProject1.append(") t0");
					StringBuilder queryProject2 = new StringBuilder(" WHERE ");
					String queryProject;
					for (int i = 1; i < projectIds.size(); i++) {
						queryProject1.append(String.format(",(SELECT distinct policy_detail_id FROM  Policy_Mapping  where application_id is NULL and   project_Id = %d", projectIds.get(i)));
						queryProject1.append(String.format(") t%d", i));
						if (i == (projectIds.size() - 1)) {
							queryProject2.append(String.format("t0.policy_detail_id = t%d", i));
							queryProject2.append(".policy_detail_id");
						} else {
							queryProject2.append(String.format("t0.policy_detail_id = t%d", i));
							queryProject2.append(".policy_detail_id AND ");
						}
					}
					if (flag) {
						queryProject = queryProject1.append(queryProject2).toString();
					} else {
						queryProject = queryProject1.toString();
					}
					SQLQuery mappedProjectQuery = getSession().createSQLQuery(queryProject);
					policies = mappedProjectQuery.list();
					if (policies.size() < 1L) {
						StringBuilder queryClient1 = new StringBuilder(String.format("SELECT distinct t0.* FROM(SELECT distinct policy_detail_id FROM  Policy_Mapping  where application_id is NULL and  project_id is NULL and  BU =%d", clientIds.get(0)));
						queryClient1.append(") t0");
						StringBuilder queryClient2 = new StringBuilder(" WHERE ");
						String queryClient;
						for (int i = 1; i < clientIds.size(); i++) {
							queryClient1.append(String.format(",(SELECT distinct policy_detail_id FROM  Policy_Mapping  where application_id is NULL and  project_id is NULL and  BU =%d", clientIds.get(i)));
							queryClient1.append(String.format(") t%d", i));
							if (i == (clientIds.size() - 1)) {
								queryClient2.append(String.format("t0.policy_detail_id = t%d", i));
								queryClient2.append(".policy_detail_id");
							} else {
								queryClient2.append(String.format("t0.policy_detail_id = t%d", i));
								queryClient2.append(".policy_detail_id AND ");
							}
						}
						if (flag == false) {
							queryClient = queryClient1.toString();
						} else {
							queryClient = queryClient1.append(queryClient2).toString();
						}
						SQLQuery mappedClientQuery = getSession().createSQLQuery(queryClient);
						policies = mappedClientQuery.list();
					}
				}
				if (policies.size() > 0L) {
					policy = Long.parseLong(String.valueOf(policies.get(0)));
					List<AddPolicyTO> addPolicyToList = (List<AddPolicyTO>) getHibernateTemplate().find("from AddPolicyTO where id=? and status=?", policy, CMMConstants.Framework.Status.ACTIVE);
					if (addPolicyToList.size() > 0L) {
						policyObj = addPolicyToList.get(0);
					}
				}
			}
			return policyObj;
		} catch (Exception e) {
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:getPolicyDetail", e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public boolean checkEnvironmentName(String editedName, Long environmentId) throws CMMException {
	
		try {
			boolean flag = true;
			List<EnvironmentTO> environmentList = (List<EnvironmentTO>) getHibernateTemplate().find("from EnvironmentTO e where e.environmentName=? and  e.id <> ?", editedName, environmentId);
			if (!environmentList.isEmpty()) {
				flag = false;
			}
			return flag;
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. EnvironmentDAOImpl : checkEnvironmentName", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. EnvironmentDAOImpl : checkEnvironmentName", he);
		}
	}
	
	public List<String> getApplicationNameForIM(Long id) throws CMMException {
	
		List<String> applicationNames = new ArrayList<String>();
		try {
			List<Long> applicationIds = (List<Long>) getHibernateTemplate().find("select e.applicationTO.id  from EnvironmentApplicationTO e where e.environmentTO.id=?", id);
			if (!applicationIds.isEmpty()) {
				List<String> appNames = new ArrayList<String>();
				for (int i = 0; i < applicationIds.size(); i++) {
					Long appId = applicationIds.get(i);
					appNames.addAll((List<String>) getHibernateTemplate().find("select appName from ApplicationTO where id=?", appId));
				}
				applicationNames.addAll(appNames);
			}
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. EnvironmentDAOImpl : getApplicationNameForIM", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. EnvironmentDAOImpl : getApplicationNameForIM", he);
		}
		return applicationNames;
	}
	
	/** method for displaying service dashboard popup details */
	@Override
	public List getServiceDashboardDetails(String serviceId, String statusId, String status, UserTO userTo) throws CMMException {
	
		Session session = null;
		Query q = null;
		List ids = new ArrayList();
		List<Long> userIdList = new ArrayList<Long>();
		try {
			session = getSession();
			Long.parseLong(serviceId);
			Long.parseLong(statusId);
			session = getSession();
			StringBuilder query = new StringBuilder("select distinct(s.request_id),ser.service_name,st.status_desc,u.name,s.created_date,s.created_by,e.environment_name,a.application_name from service_request s,users u,status st,services ser,environments e,applications a where ser.service_id=s.service_id and s.status_id=st.id and s.application_id=a.id and s.environment_id=e.id and s.created_by=u.id and s.service_id=:service_id and s.status_id=:statusID");
			if (!((userTo.getClientList().size() == 1) && (userTo.getClientList().get(0) == 0))) {
				userIdList.add(userTo.getId());
				query.append(" and (s.application_id in (Select id from applications a where a.client_id in(:clients)) ) and s.created_by in (:userIdList)");
			}
			q = session.createSQLQuery(query.toString());
			q.setParameter("service_id", serviceId);
			q.setParameter("statusID", statusId);
			if (!((userTo.getClientList().size() == 1) && (userTo.getClientList().get(0) == 0))) {
				q.setParameterList("userIdList", userIdList);
				q.setParameterList("clients", userTo.getClientList());
			}
			ids = q.list();
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Error in fetching service dashboard  Detail:", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return ids;
	}
	
	@Override
	public List getServiceDashboardDetailsPending(String serviceId, String statusId, String status, UserTO userTo) throws CMMException {
	
		Session session = null;
		Query q = null;
		List ids = new ArrayList();
		List<Long> userIdList = new ArrayList<Long>();
		try {
			session = getSession();
			Long.parseLong(serviceId);
			Long.parseLong(statusId);
			session = getSession();
			StringBuilder query = new StringBuilder("select distinct(s.request_id),ser.service_name,s.created_date,u1.name ,e.environment_name from services ser, service_request s , wf_current wf,users u1,environments e where ser.service_id=s.service_id and s.request_id=wf.request_id and wf.environment_id=e.id and u1.id=s.created_by and s.service_id=:serviceId and s.status_id=:statusID");
			if ((userTo.getClientList().size() == 1) && (userTo.getClientList().get(0) == 0)) {
				LOG.info("Size of ClientList is one or zero");
			} else {
				userIdList.add(userTo.getId());
				query.append(" and s.created_by in (:userIdList)");
			}
			q = session.createSQLQuery(query.toString());
			q.setParameter("serviceId", serviceId);
			q.setParameter("statusID", statusId);
			if ((userTo.getClientList().size() == 1) && (userTo.getClientList().get(0) == 0)) {
				LOG.info("Size of ClientList is one or zero");
			} else {
				q.setParameterList("userIdList", userIdList);
			}
			ids = q.list();
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Error in fetching service dashboard  Detail:", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return ids;
	}
	
	@Override
	public List getServiceDashboardDetailsPendingApplicationBasis(String serviceId, String statusId, String status, UserTO userTo) throws CMMException {
	
		Session session = null;
		Query q = null;
		List ids = new ArrayList();
		List<Long> userIdList = new ArrayList<Long>();
		try {
			session = getSession();
			Long.parseLong(serviceId);
			Long.parseLong(statusId);
			session = getSession();
			String query = "select s.request_id,ser.service_name,s.created_date,u1.name ,a.application_name from services ser, service_request s , wf_current wf,users u1,applications a where ser.service_id=s.service_id and s.request_id=wf.request_id and wf.application_id=a.id and  u1.id=s.created_by and s.service_id=:serviceId and s.status_id=:statusID";
			if ((userTo.getClientList().size() == 1) && (userTo.getClientList().get(0) == 0)) {
				LOG.info("Size of ClientList is one or zero");
			} else {
				userIdList.add(userTo.getId());
				query = query + "  and s.created_by in (:userIdList)";
			}
			q = session.createSQLQuery(query);
			q.setParameter("serviceId", serviceId);
			q.setParameter("statusID", statusId);
			if ((userTo.getClientList().size() == 1) && (userTo.getClientList().get(0) == 0)) {
				LOG.info("Size of ClientList is one or zero");
			} else {
				q.setParameterList("userIdList", userIdList);
			}
			ids = q.list();
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Error in fetching service dashboard  Detail:", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return ids;
	}
	
	@Override
	public List getServiceDashboardDetailsPendingEnvironmentBasis(String serviceId, String statusId, String status, UserTO userTo) throws CMMException {
	
		Session session = null;
		Query q = null;
		List ids = new ArrayList();
		List<Long> userIdList = new ArrayList<Long>();
		try {
			session = getSession();
			Long.parseLong(serviceId);
			Long.parseLong(statusId);
			session = getSession();
			String query = "select distinct(s.request_id),ser.service_name,s.created_date,u1.name ,e.environment_name from services ser, service_request s , wf_current wf,users u1,environments e where ser.service_id=s.service_id and s.environment_id=e.id and  u1.id=s.created_by and s.service_id=:serviceId and s.status_id=:statusID";
			if ((userTo.getClientList().size() == 1) && (userTo.getClientList().get(0) == 0)) {
				LOG.info("Size of ClientList is one or zero");
			} else {
				userIdList.add(userTo.getId());
				query = query + " and s.created_by in (:userIdList)";
			}
			q = session.createSQLQuery(query);
			q.setParameter("serviceId", serviceId);
			q.setParameter("statusID", statusId);
			if ((userTo.getClientList().size() == 1) && (userTo.getClientList().get(0) == 0)) {
				LOG.info("Size of ClientList is one or zero");
			} else {
				q.setParameterList("userIdList", userIdList);
			}
			ids = q.list();
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Error in fetching service dashboard  Detail:", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return ids;
	}
	
	@Override
	public List getServiceDashboardDetailsForAgentDeploment(String serviceId, String statusId, String status, UserTO userTo) throws CMMException {
	
		Session session = null;
		Query q = null;
		List ids = new ArrayList();
		List<Long> userIdList = new ArrayList<Long>();
		try {
			session = getSession();
			Long.parseLong(serviceId);
			Long.parseLong(statusId);
			session = getSession();
			StringBuilder query = new StringBuilder("select distinct(s.request_id),ser.service_name,st.status_desc,u.name,s.created_date,s.created_by from service_request s,users u,status st,services ser where ser.service_id=s.service_id and s.status_id=st.id and s.created_by=u.id and s.service_id=:service_id  and s.status_id=:status_id");
			if (!((userTo.getClientList().size() == 1) && (userTo.getClientList().get(0) == 0))) {
				userIdList.add(userTo.getId());
				query.append(" and s.created_by in (:userIdList)");
			}
			q = session.createSQLQuery(query.toString());
			if (!((userTo.getClientList().size() == 1) && (userTo.getClientList().get(0) == 0))) {
				q.setParameterList("userIdList", userIdList);
			}
			q.setParameter("service_id", serviceId);
			q.setParameter("status_id", statusId);
			ids = q.list();
		} catch (DataAccessException dae) {
			throw new CMMException("Error in fetching service dashboard  Detail:", dae);
		} catch (HibernateException he) {
			throw new CMMException("Error in fetching service dashboard Detail:", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return ids;
	}
	
	@Override
	public List getServiceDashboardDetailsForApplicationBasis(String serviceId, String statusId, String status, UserTO userTo) throws CMMException {
	
		Session session = null;
		Query q = null;
		List ids = new ArrayList();
		List<Long> userIdList = new ArrayList<Long>();
		try {
			session = getSession();
			Long.parseLong(serviceId);
			Long.parseLong(statusId);
			session = getSession();
			StringBuilder query = new StringBuilder("select distinct(s.request_id),ser.service_name,st.status_desc,u.name,s.created_date,s.created_by,a.application_name from service_request s,users u,status st,services ser,applications a where ser.service_id=s.service_id and a.id=s.application_id and s.status_id=st.id and s.created_by=u.id and s.service_id=:serviceId and s.status_id=:statusID");
			if (!((userTo.getClientList().size() == 1) && (userTo.getClientList().get(0) == 0))) {
				userIdList.add(userTo.getId());
				query.append("  and s.application_id in (Select id from applications a where a.client_id in(:clients)) and s.created_by in (:userIdList)");
			}
			q = session.createSQLQuery(query.toString());
			q.setParameter("serviceId", serviceId);
			q.setParameter("statusID", statusId);
			if (!((userTo.getClientList().size() == 1) && (userTo.getClientList().get(0) == 0))) {
				q.setParameterList("userIdList", userIdList);
				q.setParameterList("clients", userTo.getClientList());
			}
			ids = q.list();
		} catch (DataAccessException dae) {
			throw new CMMException("Error in fetching service dashboard  Detail:", dae);
		} catch (HibernateException he) {
			throw new CMMException("Error in fetching service dashboard Detail:", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return ids;
	}
	
	@Override
	public List getServiceDashboardDetailsForEnvironmentBasis(String serviceId, String statusId, String status, UserTO userTo) throws CMMException {
	
		Session session = null;
		Query q = null;
		List ids = new ArrayList();
		List<Long> userIdList = new ArrayList<Long>();
		try {
			session = getSession();
			Long.parseLong(serviceId);
			Long.parseLong(statusId);
			session = getSession();
			StringBuilder query = new StringBuilder("select distinct(s.request_id),ser.service_name,st.status_desc,u.name,s.created_date,s.created_by,e.environment_name from service_request s,users u,status st,services ser,environments e where ser.service_id=s.service_id and s.status_id=st.id and s.environment_id=e.id and s.created_by=u.id and s.service_id=:serviceId and s.status_id=:statusID");
			if (!((userTo.getClientList().size() == 1) && (userTo.getClientList().get(0) == 0))) {
				userIdList.add(userTo.getId());
				query.append(" and (s.environment_id in (Select a.environment_id  from environment_application a where a.application_id in(Select id from applications where client_id in  (:clients)) )) and s.created_by in (:userIdList)");
			}
			q = session.createSQLQuery(query.toString());
			q.setParameter("serviceId", serviceId);
			q.setParameter("statusID", statusId);
			if (!((userTo.getClientList().size() == 1) && (userTo.getClientList().get(0) == 0))) {
				q.setParameterList("userIdList", userIdList);
				q.setParameterList("clients", userTo.getClientList());
			}
			ids = q.list();
		} catch (DataAccessException dae) {
			throw new CMMException("Error in fetching service dashboard  Detail:", dae);
		} catch (HibernateException he) {
			throw new CMMException("Error in fetching service dashboard Detail:", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return ids;
	}
	
	@Override
	public String getCurrentOwner(Long requestId) throws CMMException {
	
		Session session = null;
		Query q = null;
		String ownername = null;
		try {
			session = getSession();
			String query = "select u.fullname from users u , wf_current wf where wf.currentownerid=u.id and wf.request_id=:request_id";
			q = session.createSQLQuery(query);
			q.setParameter("request_id", requestId);
			if (!q.list().isEmpty()) {
				ownername = (String) q.list().get(0);
			} else {
				ownername = "--";
			}
		} catch (DataAccessException dae) {
			throw new CMMException("Error in fetching Ownername:EnvironmentDAOImpl", dae);
		} catch (HibernateException he) {
			throw new CMMException("Error in fetching Ownername:EnvironmentDAOImpl", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return ownername;
	}
	
	public List<ApplicationTO> getApplicationNamesForEnv(Long id) {
	
		List<ApplicationTO> appNames = new ArrayList<ApplicationTO>();
		List<EnvironmentApplicationTO> apps = null;
		try {
			apps = (List<EnvironmentApplicationTO>) getHibernateTemplate().find("from EnvironmentApplicationTO where environmentTO.id = ?", id);
			for (EnvironmentApplicationTO ap : apps) {
				ApplicationTO appTO = new ApplicationTO();
				Object[] appDetails = (Object[]) getHibernateTemplate().find("select a.appName,c.id, c.name, d.name from ApplicationTO a  inner join a.businessUnitTO c inner join a.projectTO d where a.id=?", ap.getApplicationTO().getId()).get(0);
				String appname = (String) appDetails[0];
				appTO.setAppName(appname);
				String businessunit = (String) appDetails[2];
				appTO.setBusinessUnitName(businessunit);
				String project = (String) appDetails[3];
				appTO.setProjectName(project);
				appNames.add(appTO);
			}
		} catch (DataAccessException dae) {
			logger.error("Problem encountered.EnvironmentDAOImpl:getApplicationNamesForEnv", dae);
		} catch (HibernateException he) {
			logger.error("Problem encountered.EnvironmentDAOImpl:getApplicationNamesForEnv", he);
		}
		return appNames;
	}
	
	@Override
	public Long getRequestedEnvCount(Long clientId, List<Long> clientIdlist, long status, EnvironmentTO environmentTO) throws CMMException {
	
		Long available = 0L;
		Session session = null;
		Query q = null;
		try {
			session = getSession();
			StringBuilder query = new StringBuilder("SELECT 1 FROM environment_application ea ,environments e  where e.status in (23,25) and ea.environment_id = e.id ");
			if (environmentTO.getEnvironmentValue() != null) {
				query.append(" and ea.id in (:environmentValues)");
			}
			if (!(clientId == 0)) {
				query.append(" and ea.application_id in (select a.id from applications a where a.client_id in(:clientid)) ");
			}
			q = session.createSQLQuery(query.toString());
			if (environmentTO.getEnvironmentValue() != null) {
				q.setParameter("environmentValues", environmentTO.getEnvironmentValue());
			}
			if (!(clientId == 0)) {
				q.setParameterList("clientid", clientIdlist);
			}
			if (!q.list().isEmpty()) {
				available = (long) q.list().size();
			} else {
				available = 0L;
			}
			return available;
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:getAvailableEnvCount.", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public Long getAvailableEnvCount(Long clientId, List<Long> clientIdlist, EnvironmentTO environmentTO) throws CMMException {
	
		Long available = 0L;
		Session session = null;
		Query q = null;
		try {
			session = getSession();
			Date currentDate = DateUtils.getStartTime(new Date());
			StringBuilder query = new StringBuilder("select  count(e.id) FROM Environments e ,Reservation r where (( r.id <> e.id ) OR ( r.id = e.id and r.endTime < :endTime ) OR ( r.id = e.id and r.startTime >:startTime )) and  r.status <> 82 and e.status= 21 ");
			if (environmentTO.getEnvironmentValue() != null) {
				query.append(" and r.id in (:environmentValues)");
			}
			if (environmentTO.getApplicationValue() != null) {
				query.append(" and r.id in (:environmentAppValues)");
			}
			if (!(clientId == 0)) {
				query.append(" and r.application_id in (select a.id from applications a where a.client_id in(:clientid)) ");
			}
			query.append(" group by e.id");
			q = session.createSQLQuery(query.toString());
			if (environmentTO.getEnvironmentValue() != null) {
				q.setParameter("environmentValues", environmentTO.getEnvironmentValue());
			}
			if (environmentTO.getApplicationValue() != null) {
				q.setParameter("environmentAppValues", environmentTO.getApplicationValue());
			}
			q.setParameter("endTime", currentDate);
			q.setParameter("startTime", currentDate);
			if (!(clientId == 0)) {
				q.setParameterList("clientid", clientIdlist);
			}
			if (!q.list().isEmpty()) {
				available = (long) q.list().size();
			} else {
				available = 0L;
			}
			return available;
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:getAvailableEnvCount.", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<EnvironmentTO> searchAvailableEnvForHome(EnvironmentTO environmentTO) throws CMMException {
	
		try {
			List<EnvironmentTO> envList = new ArrayList<EnvironmentTO>(0);
			StringBuilder query = new StringBuilder("Select ea from EnvironmentTO as e,EnvironmentApplicationTO as ea where e.status in(21) and ea.environmentTO.id = e.id");
			if (!(environmentTO.getClientId() == 0)) {
				query.append(" and  ea.applicationTO.id in (select a.id from ApplicationTO a where a.businessUnitTO.id=?)");
			}
			List<EnvironmentApplicationTO> temp = (List<EnvironmentApplicationTO>) getHibernateTemplate().find(query.toString(), environmentTO.getClientId());
			for (EnvironmentApplicationTO db : temp) {
				ApplicationTO appname;
				EnvironmentTO envto;
				envto = (EnvironmentTO) getHibernateTemplate().find("from EnvironmentTO a where a.id=?", db.getEnvironmentTO().getId()).get(0);
				appname = (ApplicationTO) getHibernateTemplate().find("from ApplicationTO a where a.id=?", db.getApplicationTO().getId()).get(0);
				ProjectsTO project = (ProjectsTO) getHibernateTemplate().find("from ProjectsTO p where p.id=?", appname.getProjectTO().getId()).get(0);
				BusinessUnitTO businessUnit = (BusinessUnitTO) getHibernateTemplate().find("from BusinessUnitTO b where b.clientId=?", appname.getBusinessUnitTO().getClientId()).get(0);
				envto.setBusinessUnit(businessUnit.getName());
				envto.setProject(project.getName());
				envto.setApplicationName(appname.getAppName());
				envList.add(envto);
			}
			return envList;
		} catch (DataAccessException | HibernateException e) {
			LOG.error(e);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:searchAvailableEnvForHome.", e);
		}
	}
	
	@Override
	public List<EnvironmentTO> searchReservedEnvForHome(EnvironmentTO environmentTO) throws CMMException {
	
		try {
			List<EnvironmentTO> envList = new ArrayList<EnvironmentTO>();
			DetachedCriteria criteria = DetachedCriteria.forClass(ReservationTO.class, "reservation");
			Date currentDate = DateUtils.getStartTime(new Date());
			criteria.add(Restrictions.ne("status.id", Entity.RESERVATION_STATUS_INACTIVE));
			criteria.add(Restrictions.disjunction().add(Restrictions.conjunction().add(Property.forName("startTime").le(currentDate)).add(Property.forName("endTime").ge(currentDate))));
			List<ReservationTO> res = (List<ReservationTO>) getHibernateTemplate().findByCriteria(criteria);
			List<EnvironmentApplicationTO> ea = new ArrayList<EnvironmentApplicationTO>();
			for (ReservationTO r : res) {
				StringBuilder query = new StringBuilder("Select ea from EnvironmentTO as e,EnvironmentApplicationTO as ea where ea.environmentTO.id = e.id and e.id=?");
				if (!(environmentTO.getClientId() == 0)) {
					query.append(" and  ea.applicationTO.id in (select a.id from ApplicationTO a where a.businessUnitTO.id=? )");
				}
				List<EnvironmentApplicationTO> temp = (List<EnvironmentApplicationTO>) getHibernateTemplate().find(query.toString(), r.getEnvironments().getId(), environmentTO.getClientId());
				ea.addAll(temp);
			}
			for (EnvironmentApplicationTO db : ea) {
				ApplicationTO appname;
				EnvironmentTO envto;
				envto = (EnvironmentTO) getHibernateTemplate().find("from EnvironmentTO a where a.id=?", db.getEnvironmentTO().getId()).get(0);
				appname = (ApplicationTO) getHibernateTemplate().find("from ApplicationTO a where a.id=?", db.getApplicationTO().getId()).get(0);
				ProjectsTO project = (ProjectsTO) getHibernateTemplate().find("from ProjectsTO p where p.id=?", appname.getProjectTO().getId()).get(0);
				BusinessUnitTO businessUnit = (BusinessUnitTO) getHibernateTemplate().find("from BusinessUnitTO b where b.clientId=?", appname.getBusinessUnitTO().getClientId()).get(0);
				envto.setBusinessUnit(businessUnit.getName());
				envto.setProject(project.getName());
				envto.setApplicationName(appname.getAppName());
				envList.add(envto);
			}
			return envList;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:searchReservedEnvForHome", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:searchReservedEnvForHome", he);
		}
	}
	
	@Override
	public List<EnvironmentTO> searchRequestedEnvForHome(EnvironmentTO environmentTO) throws CMMException {
	
		Query q = null;
		Session session = null;
		List<EnvironmentTO> envList = new ArrayList<EnvironmentTO>();
		try {
			session = getSession();
			StringBuilder query = new StringBuilder("select e.environment_name,p.name,c.client_name,a.application_name from environments e,environment_application ea,applications a,projects p,client c where e.id=ea.environment_id and ea.application_id=a.id and a.project_id=p.id and a.client_id=c.client_id and e.status in(23,25) ");
			if (!(environmentTO.getClientId() == 0)) {
				query.append("and ea.application_id in(Select app.id from applications app where a.client_id in(:envClientId))");
			}
			q = session.createSQLQuery(query.toString());
			if (!(environmentTO.getClientId() == 0)) {
				q.setParameter("envClientId", environmentTO.getClientId());
			}
			Iterator itrDatasetList = q.list().iterator();
			while (itrDatasetList.hasNext()) {
				EnvironmentTO objEnv = new EnvironmentTO();
				Object arrDataList[] = (Object[]) itrDatasetList.next();
				objEnv.setEnvironmentName(arrDataList[0].toString());
				objEnv.setProject(arrDataList[1].toString());
				objEnv.setApplicationName(arrDataList[3].toString());
				objEnv.setBusinessUnit(arrDataList[2].toString());
				envList.add(objEnv);
			}
			return envList;
		} catch (DataAccessException | HibernateException e) {
			LOG.error(e);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:searchRequestedEnvForHome.", e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	public List<EnvironmentTO> searchEnv(EnvironmentTO environmentTO, Long userId) throws CMMException {
	
		Session session = null;
		List<EnvironmentTO> envList = new ArrayList<EnvironmentTO>();
		StringBuilder query = new StringBuilder();
		Query q = null;
		try {
			session = getSession();
			long invalidStatus = CMMConstants.Framework.Entity.ENVIRONMENT_STATUS_INVALID;
			if (environmentTO.getClientId() == 0) {
				query.append("select distinct e.id,e.ENVIRONMENT_NAME,s.STATUS_DESC from environments e , environment_application m , status s where m.environment_id =e.id and e.STATUS=s.id and e.STATUS!=:invalidEnvStatus");
			} else if ((environmentTO.getClientId() != 0) && (environmentTO.getRoleId() == 1)) {
				query.append("select distinct e.id,e.ENVIRONMENT_NAME,s.STATUS_DESC from environments e , environment_application m , status s , user_business_unit u where m.environment_id =e.id and e.STATUS=s.id and e.STATUS!=:invalidEnvStatus and u.client_id in(:envClientId)");
			} else {
				query.append("select distinct e.id,e.ENVIRONMENT_NAME,s.STATUS_DESC from environments e , environment_application m , status s, user_group_details ugd, user_groups ug,applications a where m.environment_id =e.id and m.application_id = a.id and ug.id=a.user_grp_id and ug.id = ugd.group_id and ugd.user_id =:userID and e.STATUS = s.id and e.STATUS !=:invalidEnvStatus");
			}
			if (StringUtils.hasText(environmentTO.getEnvironmentName())) {
				query.append(" and e.ENVIRONMENT_NAME like (:envName)");
			}
			if (environmentTO.getSelectedApplication() > 0L) {
				query.append(" and m.application_id =:applicationId");
			}
			if (environmentTO.getStatus() > 0L) {
				query.append(" and e.STATUS =:envStatus");
			}
			if (environmentTO.getSearchCount() == 0) {
				q = session.createSQLQuery(query.toString());
			} else {
				query.append(" limit :envFirstResult , :envTableSize");
				q = session.createSQLQuery(query.toString());
				q.setParameter("envFirstResult", environmentTO.getFirstResult());
				q.setParameter("envTableSize", environmentTO.getTableSize());
			}
			if (StringUtils.hasText(environmentTO.getEnvironmentName())) {
				q.setParameter("envName", "%".concat(environmentTO.getEnvironmentName()).concat("%"));
			}
			if (environmentTO.getSelectedApplication() > 0L) {
				q.setParameter("applicationId", environmentTO.getSelectedApplication());
			}
			if (environmentTO.getStatus() > 0L) {
				q.setParameter("envStatus", environmentTO.getStatus());
			}
			if (environmentTO.getClientId() == 0) {
				q.setParameter("invalidEnvStatus", invalidStatus);
			} else if ((environmentTO.getClientId() != 0) && (environmentTO.getRoleId() == 1)) {
				q.setParameter("invalidEnvStatus", invalidStatus);
				q.setParameter("envClientId", environmentTO.getClientId());
			} else {
				q.setParameter("invalidEnvStatus", invalidStatus);
				q.setParameter("userID", userId);
			}
			List<Object[]> objList = q.list();
			for (Object[] temp : objList) {
				EnvironmentTO envObj = new EnvironmentTO();
				envObj.setId(((Integer) temp[0]).longValue());
				envObj.setEnvironmentName((String) temp[1]);
				envObj.setEnvStatus((String) temp[2]);
				envList.add(envObj);
			}
			return envList;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:searchEnv.", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:searchEnv.", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public Long getReservedEnvCount(Long clientId, List<Long> clientIdlist, EnvironmentTO environmentTO) throws CMMException {
	
		Long reserved = 0L;
		Session session = null;
		Query q = null;
		try {
			session = getSession();
			Date currentDate = DateUtils.getStartTime(new Date());
			StringBuilder query = new StringBuilder("select  count(e.id) FROM Environments e ,Reservation r where r.environment_id = e.id  and r.endTime > :endTime  and  r.status = 81 and e.status= 21 ");
			if (environmentTO.getEnvironmentValue() != null) {
				query.append(" and r.id in (:envValue)");
			}
			if (environmentTO.getApplicationValue() != null) {
				query.append(" and r.id in (:envAppValue)");
			}
			if (!(clientId == 0)) {
				query.append(" and r.application_id in (select a.id from applications a where a.client_id in(:clientid))");
			}
			query.append(" group by e.id");
			q = session.createSQLQuery(query.toString());
			if (environmentTO.getEnvironmentValue() != null) {
				q.setParameter("envValue", environmentTO.getEnvironmentValue());
			}
			if (environmentTO.getApplicationValue() != null) {
				q.setParameter("envAppValue", environmentTO.getApplicationValue());
			}
			q.setParameter("endTime", currentDate);
			if (!(clientId == 0)) {
				q.setParameterList("clientid", clientIdlist);
			}
			if (!q.list().isEmpty()) {
				reserved = (long) q.list().size();
			} else {
				reserved = 0L;
			}
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Problem encountered. EnvironmentDAOImpl : getReservedEnvCount", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return reserved;
	}
	
	@Override
	public Long fetchEnvironmentIDByName(String environmentName) throws CMMException {
	
		List<EnvironmentTO> environmentList = null;
		try {
			environmentList = (List<EnvironmentTO>) getHibernateTemplate().find("from EnvironmentTO where environmentName=?", environmentName);
			if (environmentList.isEmpty()) {
				throw new CMMException("No environment found for environment name " + environmentName);
			} else if (environmentList.size() > 1) {
				throw new CMMException("No Unique environment found for environment name" + environmentName);
			}
			return environmentList.get(0).getId();
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Problem encountered. EnvironmentDAOImpl : fetchEnvironmentIDByName", dae);
		}
	}
	
	@Override
	public List<ZabbixTriggerFunctionTO> getAllZabbixFunctions() throws CMMException {
	
		List<ZabbixTriggerFunctionTO> functions = new ArrayList<ZabbixTriggerFunctionTO>(0);
		try {
			functions = (List<ZabbixTriggerFunctionTO>) getHibernateTemplate().find("from ZabbixTriggerFunctionTO");
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. EnvironmentDAOImpl : getAllZabbixFunctions", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. EnvironmentDAOImpl : getAllZabbixFunctions", he);
		}
		return functions;
	}
	
	@Override
	public List<ProvisionedMachineTO> getEnvListFordashboard(List<String> hosts, UserTO userTo) throws CMMException {
	
		Session session = null;
		String query = null;
		try {
			session = getSession();
			List<ProvisionedMachineTO> provisionedMachineList = new ArrayList<ProvisionedMachineTO>(0);
			if (userTo.getClientId() == 0) {
				query = "select distinct e.id,e.ENVIRONMENT_NAME,p.hostname,p.ip from environments e , environment_application m,environment_details ed, provisioned_machine p where m.environment_id =e.id and e.STATUS=21  and e.id=ed.environment_id and ed.provisioned_machine_tmplt_id=p.id and p.hostname in (:hostname)";
			} else if ((userTo.getClientId() != 0) && (userTo.getRoleId() == 1)) {
				query = "select distinct e.id,e.ENVIRONMENT_NAME,p.hostname,p.ip from environments e , environment_application m , user_business_unit u ,environment_details ed, provisioned_machine p where m.environment_id =e.id and e.STATUS=21 and m.application_id in ( select a.id from applications a where a.client_id in(:clientIdList)) and e.id=ed.environment_id and ed.provisioned_machine_tmplt_id=p.id and p.hostname in (:hostname)";
			} else {
				query = "select distinct e.id,e.ENVIRONMENT_NAME,p.hostname,p.ip from environments e , environment_application m ,user_group_details ugd, user_groups ug,applications a,environment_details ed, provisioned_machine p where m.environment_id =e.id and m.application_id = a.id and ug.id=a.user_grp_id and ug.id = ugd.group_id and ugd.user_id =:userID and e.STATUS =21 and e.id=ed.environment_id and ed.provisioned_machine_tmplt_id=p.id and p.hostname in (:hostname)";
			}
			Query q = session.createSQLQuery(query);
			if (userTo.getClientId() == 0) {
				q.setParameterList("hostname", hosts);
			} else if ((userTo.getClientId() != 0) && (userTo.getRoleId() == 1)) {
				q.setParameterList("clientIdList", userTo.getClientList());
				q.setParameterList("hostname", hosts);
			} else {
				q.setParameterList("hostname", hosts);
				q.setParameter("userID", userTo.getId());
			}
			List<Object[]> objList = q.list();
			for (Object[] temp : objList) {
				ProvisionedMachineTO provision = new ProvisionedMachineTO();
				provision.setEnvironmentName(temp[1].toString());
				provision.setHostName(temp[2].toString());
				provision.setIp(temp[3].toString());
				provisionedMachineList.add(provision);
			}
			return provisionedMachineList;
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:searchEnv.", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public String getIp(String name) throws CMMException {
	
		String ip = null;
		try {
			List<String> list = (List<String>) getHibernateTemplate().find("select p.ip from ProvisionedMachineTO p where p.hostName=?", name);
			if ((list != null) && !list.isEmpty()) {
				ip = list.get(0);
			}
			return ip;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl: getIp.", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl: getIp.", he);
		}
	}
	
	@Override
	public List<SoftwareTO> getsoftwareMappingForZabbix(Long environmentId, String resourceType) throws CMMException {
	
		Session session = null;
		String query = null;
		try {
			List<SoftwareTO> softwares = new ArrayList<SoftwareTO>();
			session = getSession();
			query = "select s.type,sc.id,s.id, p.hostname, p.ip from environment_details ed,software s,softwareconfig sc, provisioned_machine p where p.id=ed.provisioned_machine_tmplt_id and ed.environment_id =:envId and s.id=sc.deviceid  and ed.software_id =sc.id and s.type=:resourceType";
			Query q = session.createSQLQuery(query);
			q.setParameter("envId", environmentId);
			q.setParameter("resourceType", resourceType);
			List<Object[]> objList = q.list();
			for (Object[] temp : objList) {
				SoftwareTO software = new SoftwareTO();
				software.setType(temp[0].toString());
				software.setSoftwareconfigsId(Long.parseLong(temp[1].toString()));
				software.setId(Long.parseLong(temp[2].toString()));
				software.setHostname(temp[3].toString());
				software.setIp(temp[4].toString());
				String query1 = "select z.template_id from zabbix_software_mapping z,softwareconfig sc where z.software_config_id=sc.id and sc.id=:softwareConfigId";
				Query q1 = session.createSQLQuery(query1);
				q1.setParameter("softwareConfigId", software.getSoftwareconfigsId());
				List<ZabbixSoftwareMappingTO> zabbixList = q1.list();
				software.setZabbixTemplatesList(zabbixList);
				softwares.add(software);
			}
			return softwares;
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:getsoftwareMappingForZabbix.", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public void updateMonitoringAgentStatus(Long envId) throws CMMException {
	
		long environmentId = envId;
		EnvironmentTO environmentTO = fetchEnvironment(environmentId);
		environmentTO.setMonitoringRequired(CMMConstants.Framework.ServiceFlag.MONITORING_INSTALLED_SUCCESS);
		try {
			getHibernateTemplate().update(environmentTO);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. EnvironmentnDaoImpl : updateMonitoringAgentStatus.", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. EnvironmentnDaoImpl : updateMonitoringAgentStatus.", he);
		}
	}
	
	@Override
	public void updateEnvStatusAsDecommissioned(long environmentId) throws CMMException {
	
		EnvironmentTO environmentTO = fetchEnvironment(environmentId);
		environmentTO.setStatus(CMMConstants.Framework.Entity.ENVIRONMENT_STATUS_DECOMMISSIONED);
		try {
			getHibernateTemplate().update(environmentTO);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:updateEnvStatusAsUnAvailable.", he);
		}
	}
	
	@Override
	public List<EnvironmentApplicationTO> fetchEnvForAppAndRel(Long applicationId, Long releaseId) throws CMMException {
	
		List<EnvironmentApplicationTO> environmentApplicationList = null;
		try {
			String hql = String.format("from EnvironmentApplicationTO where applicationTO.id=%d and releaseId=%d and environmentTO.status=%d", applicationId, releaseId, CMMConstants.Framework.Entity.ENVIRONMENT_AVAILABLE);
			environmentApplicationList = (List<EnvironmentApplicationTO>) getHibernateTemplate().find(hql);
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Problem encountered. EnvironmentDAOImpl : fetchEnvForAppAndRel", dae);
		}
		return environmentApplicationList;
	}
	
	@Override
	public EnvironmentTO getEnvDetails(String hostname) throws CMMException {
	
		EnvironmentTO env = new EnvironmentTO();
		try {
			env = (EnvironmentTO) getHibernateTemplate().find("select env from EnvironmentDetailsTO e, EnvironmentTO env, ProvisionedMachineTO p where env.id=e.environment.id and e.provisionedMachine.id=p.id and p.hostName=?", hostname).get(0);
			if (env != null) {
				if ((env.getEnvTypeId() != null) && (env.getEnvTypeId() > 0)) {
					List<EnvTypeTO> type = (List<EnvTypeTO>) getHibernateTemplate().find("select e from EnvTypeTO e where e.id=?", env.getEnvTypeId());
					if (!type.isEmpty()) {
						env.setEnvTypeName(type.get(0).getTypeValue());
					}
				} else {
					env.setEnvTypeName("NA");
				}
				String profile = (String) getHibernateTemplate().find("select name from ApplicationProfileTO where id=?", env.getApplicationProfileTO().getId()).get(0);
				String username = (String) getHibernateTemplate().find("select name from UserTO where id=?", env.getCreatedById()).get(0);
				env.setProfileName(profile);
				env.setName(username);
			}
			return env;
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Problem encountered. EnvironmentDAOImpl : getEnvDetails", dae);
		}
	}
	
	@Override
	public List<ParameterTO> fetchParamsById(List<Long> paramIdList) throws CMMException {
	
		Session session = null;
		List<ParameterTO> parameterTOList = new ArrayList<ParameterTO>(0);
		try {
			session = getSession();
			StringBuilder query = new StringBuilder();
			query.append("from ParameterTO where id in(:idList)");
			parameterTOList = (List<ParameterTO>) getHibernateTemplate().findByNamedParam(query.toString(), "idList", paramIdList);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:fetchParamsById.", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl:fetchParamsById.", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return parameterTOList;
	}
	
	@Override
	public List<ServiceRequestTO> fetchCodeAnalysisDetails(UserTO userTo, List<Long> userGroupIds) throws CMMException {
	
		Session session = null;
		Query q = null;
		List<ServiceRequestTO> codeAnalysisList = new ArrayList<ServiceRequestTO>(0);
		try {
			session = getSession();
			String query = "select distinct s.request_id, s.application_id, a.application_name, s.application_release_id, r.release_name from service_request s, applications a, application_release r where a.id=s.application_id and r.id=s.application_release_id and s.service_id=19 and s.action_flag='C'";
			if (userTo.getClientId() != 0L) {
				query = query + " and s.CREATED_BY=" + userTo.getId();
			}
			query = query + " order by s.request_id desc";
			q = session.createSQLQuery(query);
			List<Object[]> obj = q.list();
			for (Object[] s : obj) {
				ServiceRequestTO list = new ServiceRequestTO();
				list.setRequestId(Long.parseLong(s[0].toString()));
				list.setApplicationId(Long.parseLong(s[1].toString()));
				list.setApplicationName(s[2].toString());
				list.setApplicationReleaseId(Long.parseLong(s[3].toString()));
				list.setReleaseName(s[4].toString());
				codeAnalysisList.add(list);
			}
			return codeAnalysisList;
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl: fetchCodeAnalysisDetails.", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public Map<String, Long> getCountForUnderUnTaggedServer(UserTO user, List<Long> groupIds) throws CMMException {
	
		Long countUnTagged = 0L;
		Long countTagged = 0L;
		Map<String, Long> mapTagging = new HashMap<>();
		List<Long> machineIds = new ArrayList<>(0);
		List<Long> count1 = new ArrayList<>(0);
		try {
			machineIds = (List<Long>) getHibernateTemplate().find("Select distinct p.id from EnvironmentTO e, ProvisionedMachineTO p, EnvironmentDetailsTO ed where ed.environment.id=e.id and p.id=ed.provisionedMachine.id and ed.provisionedMachine.id is not null and p.provisionedStatus='AVAILABLE'");
			if (!machineIds.isEmpty()) {
				count1 = (List<Long>) getHibernateTemplate().findByNamedParam("select distinct p.id from ProvisionedMachineTO p where p.id not in(:hosts) and p.provisionedStatus='AVAILABLE'", "hosts", machineIds);
			}
			if (!machineIds.isEmpty()) {
				countTagged = (long) machineIds.size();
			}
			if (!count1.isEmpty()) {
				countUnTagged = (long) count1.size();
			}
			mapTagging.put("untaggedHosts", countUnTagged);
			mapTagging.put("taggedHosts", countTagged);
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl: getCountForUnderUnTaggedServer.", dae);
		}
		return mapTagging;
	}
	
	@Override
	public Map<String, Long> getServerAgeCount(UserTO user, List<Long> groupIds) throws CMMException {
	
		Map<String, Long> mapTagging = new HashMap<>();
		Long lessThanOneCount = 0L;
		Long LessThanTwoCount = 0L;
		Long LessThanThreeCount = 0L;
		Long LessThanFourCount = 0L;
		Long LessThanFiveCount = 0L;
		Long greaterThanFiveCount = 0L;
		List<Long> count1 = new ArrayList<>(0);
		List<Long> count2 = new ArrayList<>(0);
		List<Long> count3 = new ArrayList<>(0);
		List<Long> count4 = new ArrayList<>(0);
		List<Long> count5 = new ArrayList<>(0);
		List<Long> count6 = new ArrayList<>(0);
		List<Long> countServer1 = new ArrayList<>(0);
		List<Long> countServer2 = new ArrayList<>(0);
		List<Long> countServer3 = new ArrayList<>(0);
		List<Long> countServer4 = new ArrayList<>(0);
		List<Long> countServer5 = new ArrayList<>(0);
		List<Long> countServer6 = new ArrayList<>(0);
		Date date = new Date();
		String currentDate = new SimpleDateFormat("yyyy-MM-dd").format(date);
		String[] ymd = currentDate.split("-");
		int year = Integer.parseInt(ymd[0]);
		int month = Integer.parseInt(ymd[1]);
		int day = Integer.parseInt(ymd[2]);
		String oneYearDate = Integer.toString(year - 1) + "-" + Integer.toString(month) + "-" + Integer.toString(day);
		String twoYearDate = Integer.toString(year - 2) + "-" + Integer.toString(month) + "-" + Integer.toString(day);
		String threeYearDate = Integer.toString(year - 3) + "-" + Integer.toString(month) + "-" + Integer.toString(day);
		String fourYearDate = Integer.toString(year - 4) + "-" + Integer.toString(month) + "-" + Integer.toString(day);
		String fiveYearDate = Integer.toString(year - 5) + "-" + Integer.toString(month) + "-" + Integer.toString(day);
		try {
			if (user.getClientId() == 0L) {
				count1 = (List<Long>) getHibernateTemplate().find("select distinct p.id from ProvisionedMachineTO p where p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and p.createdOn <='" + currentDate + "' and p.createdOn > '" + oneYearDate + "'");
				count2 = (List<Long>) getHibernateTemplate().find("select distinct p.id from ProvisionedMachineTO p where p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and p.createdOn<='" + oneYearDate + "' and p.createdOn> '" + twoYearDate + "'");
				count3 = (List<Long>) getHibernateTemplate().find("select distinct p.id from ProvisionedMachineTO p where p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and p.createdOn<='" + twoYearDate + "' and p.createdOn>'" + threeYearDate + "'");
				count4 = (List<Long>) getHibernateTemplate().find("select distinct p.id from ProvisionedMachineTO p where p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and p.createdOn<='" + threeYearDate + "' and p.createdOn>'" + fourYearDate + "'");
				count5 = (List<Long>) getHibernateTemplate().find("select distinct p.id from ProvisionedMachineTO p where p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and p.createdOn<='" + fourYearDate + "' and p.createdOn>'" + fiveYearDate + "'");
				count6 = (List<Long>) getHibernateTemplate().find("select distinct p.id from ProvisionedMachineTO p where p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and p.createdOn<='" + fiveYearDate + "'");
			}
			if (user.getRoleId() == 1) {
				count1 = (List<Long>) getHibernateTemplate().findByNamedParam("select distinct p.id from EnvironmentTO e, ProvisionedMachineTO p, EnvironmentDetailsTO ed, ApplicationTO a, EnvironmentApplicationTO ea where ed.environment.id=e.id and p.id=ed.provisionedMachine.id and a.id=ea.applicationTO.id and e.id=ea.environmentTO.id and a.clientId in (:clients) and p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and ed.provisionedMachine.id is not null and p.createdOn <= '" + currentDate + "' and p.createdOn > '" + oneYearDate + "'", "clients", user.getClientList());
				count2 = (List<Long>) getHibernateTemplate().findByNamedParam("select distinct p.id from EnvironmentTO e, ProvisionedMachineTO p, EnvironmentDetailsTO ed, ApplicationTO a, EnvironmentApplicationTO ea where ed.environment.id=e.id and p.id=ed.provisionedMachine.id and a.id=ea.applicationTO.id and e.id=ea.environmentTO.id and a.clientId in (:clients) and p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and ed.provisionedMachine.id is not null and p.createdOn <= '" + oneYearDate + "' and p.createdOn > '" + twoYearDate + "'", "clients", user.getClientList());
				count3 = (List<Long>) getHibernateTemplate().findByNamedParam("select distinct p.id from EnvironmentTO e, ProvisionedMachineTO p, EnvironmentDetailsTO ed, ApplicationTO a, EnvironmentApplicationTO ea where ed.environment.id=e.id and p.id=ed.provisionedMachine.id and a.id=ea.applicationTO.id and e.id=ea.environmentTO.id and a.clientId in (:clients) and p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and ed.provisionedMachine.id is not null and p.createdOn <= '" + twoYearDate + "' and p.createdOn > '" + threeYearDate + "'", "clients", user.getClientList());
				count4 = (List<Long>) getHibernateTemplate().findByNamedParam("select distinct p.id from EnvironmentTO e, ProvisionedMachineTO p, EnvironmentDetailsTO ed, ApplicationTO a, EnvironmentApplicationTO ea where ed.environment.id=e.id and p.id=ed.provisionedMachine.id and a.id=ea.applicationTO.id and e.id=ea.environmentTO.id and a.clientId in (:clients) and p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and ed.provisionedMachine.id is not null and p.createdOn <= '" + threeYearDate + "' and p.createdOn > '" + fourYearDate + "'", "clients", user.getClientList());
				count5 = (List<Long>) getHibernateTemplate().findByNamedParam("select distinct p.id from EnvironmentTO e, ProvisionedMachineTO p, EnvironmentDetailsTO ed, ApplicationTO a, EnvironmentApplicationTO ea where ed.environment.id=e.id and p.id=ed.provisionedMachine.id and a.id=ea.applicationTO.id and e.id=ea.environmentTO.id and a.clientId in (:clients) and p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and ed.provisionedMachine.id is not null and p.createdOn <= '" + fourYearDate + "' and p.createdOn > '" + fiveYearDate + "'", "clients", user.getClientList());
				count6 = (List<Long>) getHibernateTemplate().findByNamedParam("select distinct p.id from EnvironmentTO e, ProvisionedMachineTO p, EnvironmentDetailsTO ed, ApplicationTO a, EnvironmentApplicationTO ea where ed.environment.id=e.id and p.id=ed.provisionedMachine.id and a.id=ea.applicationTO.id and e.id=ea.environmentTO.id and a.clientId in (:clients) and p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and ed.provisionedMachine.id is not null and p.createdOn <= '" + fiveYearDate + "'", "clients", user.getClientList());
				countServer1 = (List<Long>) getHibernateTemplate().find("select distinct p.id from ProvisionedMachineTO p where p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and createdOn <= '" + currentDate + "' and p.createdOn > '" + oneYearDate + "' and p.createdBy=" + user.getId());
				countServer2 = (List<Long>) getHibernateTemplate().find("select distinct p.id from ProvisionedMachineTO p where p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and p.createdOn<= '" + oneYearDate + "' and p.createdOn> '" + twoYearDate + "' and p.createdBy=" + user.getId());
				countServer3 = (List<Long>) getHibernateTemplate().find("select distinct p.id from ProvisionedMachineTO p where p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and p.createdOn<= '" + twoYearDate + "' and p.createdOn>'" + threeYearDate + "' and p.createdBy=" + user.getId());
				countServer4 = (List<Long>) getHibernateTemplate().find("select distinct p.id from ProvisionedMachineTO p where p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and p.createdOn<= '" + threeYearDate + "' and p.createdOn>'" + fourYearDate + "' and p.createdBy=" + user.getId());
				countServer5 = (List<Long>) getHibernateTemplate().find("select distinct p.id from ProvisionedMachineTO p where p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and p.createdOn<= '" + fourYearDate + "' and p.createdOn>'" + fiveYearDate + "' and p.createdBy=" + user.getId());
				countServer6 = (List<Long>) getHibernateTemplate().find("select distinct p.id from ProvisionedMachineTO p where p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and p.createdOn<='" + fiveYearDate + "'and createdBy=" + user.getId());
				count1.addAll(countServer1);
				count2.addAll(countServer2);
				count3.addAll(countServer3);
				count4.addAll(countServer4);
				count5.addAll(countServer5);
				count6.addAll(countServer6);
			}
			if (user.getRoleId() > 1) {
				count1 = (List<Long>) getHibernateTemplate().findByNamedParam("select distinct p.id from EnvironmentTO e, ProvisionedMachineTO p, EnvironmentDetailsTO ed, ApplicationTO a, EnvironmentApplicationTO ea, UserGroupDetailsTO ug, UserGroupTO u where ed.environment.id=e.id and p.id=ed.provisionedMachine.id and a.id=ea.applicationTO.id and e.id=ea.environmentTO.id and u.id=ug.userGroups.id and ug.userGroups.id=a.userGroups.id and ug.userGroups.id in(:usergroups) and p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and ed.provisionedMachine.id is not null and p.createdOn <= '" + currentDate + "' and p.createdOn > '" + oneYearDate + "'", "usergroups", groupIds);
				count2 = (List<Long>) getHibernateTemplate().findByNamedParam("select distinct p.id from EnvironmentTO e, ProvisionedMachineTO p, EnvironmentDetailsTO ed, ApplicationTO a, EnvironmentApplicationTO ea, UserGroupDetailsTO ug, UserGroupTO u where ed.environment.id=e.id and p.id=ed.provisionedMachine.id and a.id=ea.applicationTO.id and e.id=ea.environmentTO.id and u.id=ug.userGroups.id and ug.userGroups.id=a.userGroups.id and ug.userGroups.id in(:usergroups) and p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and ed.provisionedMachine.id is not null and p.createdOn <='" + oneYearDate + "' and p.createdOn > '" + twoYearDate + "'", "usergroups", groupIds);
				count3 = (List<Long>) getHibernateTemplate().findByNamedParam("select distinct p.id from EnvironmentTO e, ProvisionedMachineTO p, EnvironmentDetailsTO ed, ApplicationTO a, EnvironmentApplicationTO ea, UserGroupDetailsTO ug, UserGroupTO u where ed.environment.id=e.id and p.id=ed.provisionedMachine.id and a.id=ea.applicationTO.id and e.id=ea.environmentTO.id and u.id=ug.userGroups.id and ug.userGroups.id=a.userGroups.id and ug.userGroups.id in(:usergroups) and p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and ed.provisionedMachine.id is not null and p.createdOn <= '" + twoYearDate + "' and p.createdOn > '" + threeYearDate + "'", "usergroups", groupIds);
				count4 = (List<Long>) getHibernateTemplate().findByNamedParam("select distinct p.id from EnvironmentTO e, ProvisionedMachineTO p, EnvironmentDetailsTO ed, ApplicationTO a, EnvironmentApplicationTO ea, UserGroupDetailsTO ug, UserGroupTO u where ed.environment.id=e.id and p.id=ed.provisionedMachine.id and a.id=ea.applicationTO.id and e.id=ea.environmentTO.id and u.id=ug.userGroups.id and ug.userGroups.id=a.userGroups.id and ug.userGroups.id in(:usergroups) and p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and ed.provisionedMachine.id is not null and p.createdOn <= '" + threeYearDate + "' and p.createdOn > '" + fourYearDate + "'", "usergroups", groupIds);
				count5 = (List<Long>) getHibernateTemplate().findByNamedParam("select distinct p.id from EnvironmentTO e, ProvisionedMachineTO p, EnvironmentDetailsTO ed, ApplicationTO a, EnvironmentApplicationTO ea, UserGroupDetailsTO ug, UserGroupTO u where ed.environment.id=e.id and p.id=ed.provisionedMachine.id and a.id=ea.applicationTO.id and e.id=ea.environmentTO.id and u.id=ug.userGroups.id and ug.userGroups.id=a.userGroups.id and ug.userGroups.id in(:usergroups) and p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and ed.provisionedMachine.id is not null and p.createdOn <= '" + fourYearDate + "' and p.createdOn > '" + fiveYearDate + "'", "usergroups", groupIds);
				count6 = (List<Long>) getHibernateTemplate().findByNamedParam("select distinct p.id from EnvironmentTO e, ProvisionedMachineTO p, EnvironmentDetailsTO ed, ApplicationTO a, EnvironmentApplicationTO ea, UserGroupDetailsTO ug, UserGroupTO u where ed.environment.id=e.id and p.id=ed.provisionedMachine.id and a.id=ea.applicationTO.id and e.id=ea.environmentTO.id and u.id=ug.userGroups.id and ug.userGroups.id=a.userGroups.id and ug.userGroups.id in(:usergroups) and p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and ed.provisionedMachine.id is not null and p.createdOn <= '" + fiveYearDate + "'", "usergroups", groupIds);
				countServer1 = (List<Long>) getHibernateTemplate().find("select distinct p.id from ProvisionedMachineTO p where p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and p.createdOn <= '" + currentDate + "' and p.createdOn > '" + oneYearDate + "' and p.createdBy=" + user.getId());
				countServer2 = (List<Long>) getHibernateTemplate().find("select distinct p.id from ProvisionedMachineTO p where p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and p.createdOn<='" + oneYearDate + "' and p.createdOn > '" + twoYearDate + "' and p.createdBy=" + user.getId());
				countServer3 = (List<Long>) getHibernateTemplate().find("select distinct p.id from ProvisionedMachineTO p where p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and p.createdOn<='" + twoYearDate + "' and p.createdOn >'" + threeYearDate + "' and p.createdBy=" + user.getId());
				countServer4 = (List<Long>) getHibernateTemplate().find("select distinct p.id from ProvisionedMachineTO p where p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and p.createdOn<='" + threeYearDate + "' and p.createdOn >'" + fourYearDate + "' and p.createdBy=" + user.getId());
				countServer5 = (List<Long>) getHibernateTemplate().find("select distinct p.id from ProvisionedMachineTO p where p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and p.createdOn<='" + fourYearDate + "' and p.createdOn >'" + fiveYearDate + "' and p.createdBy=" + user.getId());
				countServer6 = (List<Long>) getHibernateTemplate().find("select distinct p.id from ProvisionedMachineTO p where p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and p.createdOn<='" + fiveYearDate + "'and createdBy=" + user.getId());
				count1.addAll(countServer1);
				count2.addAll(countServer2);
				count3.addAll(countServer3);
				count4.addAll(countServer4);
				count5.addAll(countServer5);
				count6.addAll(countServer6);
			}
			if (!count1.isEmpty()) {
				lessThanOneCount = (long) count1.size();
			}
			if (!count2.isEmpty()) {
				LessThanTwoCount = (long) count2.size();
			}
			if (!count3.isEmpty()) {
				LessThanThreeCount = (long) count3.size();
			}
			if (!count4.isEmpty()) {
				LessThanFourCount = (long) count4.size();
			}
			if (!count5.isEmpty()) {
				LessThanFiveCount = (long) count5.size();
			}
			if (!count6.isEmpty()) {
				greaterThanFiveCount = (long) count6.size();
			}
			mapTagging.put("one", lessThanOneCount);
			mapTagging.put("two", LessThanTwoCount);
			mapTagging.put("three", LessThanThreeCount);
			mapTagging.put("four", LessThanFourCount);
			mapTagging.put("five", LessThanFiveCount);
			mapTagging.put("six", greaterThanFiveCount);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl: getServerAgeCount.", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl: getServerAgeCount.", he);
		} catch (Exception e) {
			LOG.error(e);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl: getServerAgeCount.", e);
		}
		return mapTagging;
	}
	
	@Override
	public List<ProvisionedMachineTO> serverAgePopupDetails(UserTO user, List<Long> groupIds, Long period) throws CMMException {
	
		List<ProvisionedMachineTO> machines = new ArrayList<>(0);
		List<ProvisionedMachineTO> machines1 = new ArrayList<>(0);
		try {
			Date date = new Date();
			String currentDate = new SimpleDateFormat("yyyy-MM-dd").format(date);
			String[] ymd = currentDate.split("-");
			int year = Integer.parseInt(ymd[0]);
			int month = Integer.parseInt(ymd[1]);
			int day = Integer.parseInt(ymd[2]);
			String oneYearDate = Integer.toString(year - 1) + "-" + Integer.toString(month) + "-" + Integer.toString(day);
			String twoYearDate = Integer.toString(year - 2) + "-" + Integer.toString(month) + "-" + Integer.toString(day);
			String threeYearDate = Integer.toString(year - 3) + "-" + Integer.toString(month) + "-" + Integer.toString(day);
			String fourYearDate = Integer.toString(year - 4) + "-" + Integer.toString(month) + "-" + Integer.toString(day);
			String fiveYearDate = Integer.toString(year - 5) + "-" + Integer.toString(month) + "-" + Integer.toString(day);
			if (user.getClientId() == 0L) {
				if (period == 0L) {
					machines = (List<ProvisionedMachineTO>) getHibernateTemplate().find("select distinct p from ProvisionedMachineTO p where p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and p.createdOn <='" + currentDate + "' and p.createdOn > '" + oneYearDate + "'");
				}
				if (period == 1L) {
					machines = (List<ProvisionedMachineTO>) getHibernateTemplate().find("select distinct p from ProvisionedMachineTO p where p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and p.createdOn<='" + oneYearDate + "' and p.createdOn> '" + twoYearDate + "'");
				}
				if (period == 2L) {
					machines = (List<ProvisionedMachineTO>) getHibernateTemplate().find("select distinct p from ProvisionedMachineTO p where p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and p.createdOn<='" + twoYearDate + "' and p.createdOn>'" + threeYearDate + "'");
				}
				if (period == 3L) {
					machines = (List<ProvisionedMachineTO>) getHibernateTemplate().find("select distinct p from ProvisionedMachineTO p where p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and p.createdOn<='" + threeYearDate + "' and p.createdOn>'" + fourYearDate + "'");
				}
				if (period == 4L) {
					machines = (List<ProvisionedMachineTO>) getHibernateTemplate().find("select distinct p from ProvisionedMachineTO p where p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and p.createdOn<='" + fourYearDate + "' and p.createdOn>'" + fiveYearDate + "'");
				}
				if (period == 5L) {
					machines = (List<ProvisionedMachineTO>) getHibernateTemplate().find("select distinct p from ProvisionedMachineTO p where p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and p.createdOn<='" + fiveYearDate + "'");
				}
			}
			if (user.getRoleId() == 1) {
				if (period == 0L) {
					machines = (List<ProvisionedMachineTO>) getHibernateTemplate().findByNamedParam("select distinct p from EnvironmentTO e, ProvisionedMachineTO p, EnvironmentDetailsTO ed, ApplicationTO a, EnvironmentApplicationTO ea where ed.environment.id=e.id and p.id=ed.provisionedMachine.id and a.id=ea.applicationTO.id and e.id=ea.environmentTO.id and a.clientId in (:clients) and p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and ed.provisionedMachine.id is not null and p.createdOn <= '" + currentDate + "' and p.createdOn > '" + oneYearDate + "'", "clients", user.getClientList());
					machines1 = (List<ProvisionedMachineTO>) getHibernateTemplate().find("select distinct p from ProvisionedMachineTO p where p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and createdOn <= '" + currentDate + "' and p.createdOn > '" + oneYearDate + "' and p.createdBy=" + user.getId());
				}
				if (period == 1L) {
					machines = (List<ProvisionedMachineTO>) getHibernateTemplate().findByNamedParam("select distinct p from EnvironmentTO e, ProvisionedMachineTO p, EnvironmentDetailsTO ed, ApplicationTO a, EnvironmentApplicationTO ea where ed.environment.id=e.id and p.id=ed.provisionedMachine.id and a.id=ea.applicationTO.id and e.id=ea.environmentTO.id and a.clientId in (:clients) and p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and ed.provisionedMachine.id is not null and p.createdOn <= '" + oneYearDate + "' and p.createdOn > '" + twoYearDate + "'", "clients", user.getClientList());
					machines1 = (List<ProvisionedMachineTO>) getHibernateTemplate().find("select distinct p from ProvisionedMachineTO p where p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and p.createdOn<= '" + oneYearDate + "' and p.createdOn> '" + twoYearDate + "' and p.createdBy=" + user.getId());
				}
				if (period == 2L) {
					machines = (List<ProvisionedMachineTO>) getHibernateTemplate().findByNamedParam("select distinct p from EnvironmentTO e, ProvisionedMachineTO p, EnvironmentDetailsTO ed, ApplicationTO a, EnvironmentApplicationTO ea where ed.environment.id=e.id and p.id=ed.provisionedMachine.id and a.id=ea.applicationTO.id and e.id=ea.environmentTO.id and a.clientId in (:clients) and p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and ed.provisionedMachine.id is not null and p.createdOn <= '" + twoYearDate + "' and p.createdOn > '" + threeYearDate + "'", "clients", user.getClientList());
					machines1 = (List<ProvisionedMachineTO>) getHibernateTemplate().find("select distinct p from ProvisionedMachineTO p where p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and p.createdOn<= '" + twoYearDate + "' and p.createdOn>'" + threeYearDate + "' and p.createdBy=" + user.getId());
				}
				if (period == 3L) {
					machines = (List<ProvisionedMachineTO>) getHibernateTemplate().findByNamedParam("select distinct p from EnvironmentTO e, ProvisionedMachineTO p, EnvironmentDetailsTO ed, ApplicationTO a, EnvironmentApplicationTO ea where ed.environment.id=e.id and p.id=ed.provisionedMachine.id and a.id=ea.applicationTO.id and e.id=ea.environmentTO.id and a.clientId in (:clients) and p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and ed.provisionedMachine.id is not null and p.createdOn <= '" + threeYearDate + "' and p.createdOn > '" + fourYearDate + "'", "clients", user.getClientList());
					machines1 = (List<ProvisionedMachineTO>) getHibernateTemplate().find("select distinct p from ProvisionedMachineTO p where p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and p.createdOn<= '" + threeYearDate + "' and p.createdOn>'" + fourYearDate + "' and p.createdBy=" + user.getId());
				}
				if (period == 4L) {
					machines = (List<ProvisionedMachineTO>) getHibernateTemplate().findByNamedParam("select distinct p from EnvironmentTO e, ProvisionedMachineTO p, EnvironmentDetailsTO ed, ApplicationTO a, EnvironmentApplicationTO ea where ed.environment.id=e.id and p.id=ed.provisionedMachine.id and a.id=ea.applicationTO.id and e.id=ea.environmentTO.id and a.clientId in (:clients) and p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and ed.provisionedMachine.id is not null and p.createdOn <= '" + fourYearDate + "' and p.createdOn > '" + fiveYearDate + "'", "clients", user.getClientList());
					machines1 = (List<ProvisionedMachineTO>) getHibernateTemplate().find("select distinct p from ProvisionedMachineTO p where p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and p.createdOn<= '" + fourYearDate + "' and p.createdOn>'" + fiveYearDate + "' and p.createdBy=" + user.getId());
				}
				if (period == 5L) {
					machines = (List<ProvisionedMachineTO>) getHibernateTemplate().findByNamedParam("select distinct p from EnvironmentTO e, ProvisionedMachineTO p, EnvironmentDetailsTO ed, ApplicationTO a, EnvironmentApplicationTO ea where ed.environment.id=e.id and p.id=ed.provisionedMachine.id and a.id=ea.applicationTO.id and e.id=ea.environmentTO.id and a.clientId in (:clients) and p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and ed.provisionedMachine.id is not null and p.createdOn <= '" + fiveYearDate + "'", "clients", user.getClientList());
					machines1 = (List<ProvisionedMachineTO>) getHibernateTemplate().find("select distinct p from ProvisionedMachineTO p where p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and p.createdOn<= '" + fiveYearDate + "'and createdBy=" + user.getId());
				}
				machines.addAll(machines1);
			}
			if (user.getRoleId() > 1) {
				if (period == 0L) {
					machines = (List<ProvisionedMachineTO>) getHibernateTemplate().findByNamedParam("select distinct p from EnvironmentTO e, ProvisionedMachineTO p, EnvironmentDetailsTO ed, ApplicationTO a, EnvironmentApplicationTO ea, UserGroupDetailsTO ug, UserGroupTO u where ed.environment.id=e.id and p.id=ed.provisionedMachine.id and a.id=ea.applicationTO.id and e.id=ea.environmentTO.id and u.id=ug.userGroups.id and ug.userGroups.id=a.userGroups.id and ug.userGroups.id in(:usergroups) and p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and ed.provisionedMachine.id is not null and p.createdOn <= '" + currentDate + "' and p.createdOn > '" + oneYearDate + "'", "usergroups", groupIds);
					machines1 = (List<ProvisionedMachineTO>) getHibernateTemplate().find("select distinct p from ProvisionedMachineTO p where p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and p.createdOn <= '" + currentDate + "' and p.createdOn > '" + oneYearDate + "' and p.createdBy=" + user.getId());
				}
				if (period == 1L) {
					machines = (List<ProvisionedMachineTO>) getHibernateTemplate().findByNamedParam("select distinct p from EnvironmentTO e, ProvisionedMachineTO p, EnvironmentDetailsTO ed, ApplicationTO a, EnvironmentApplicationTO ea, UserGroupDetailsTO ug, UserGroupTO u where ed.environment.id=e.id and p.id=ed.provisionedMachine.id and a.id=ea.applicationTO.id and e.id=ea.environmentTO.id and u.id=ug.userGroups.id and ug.userGroups.id=a.userGroups.id and ug.userGroups.id in(:usergroups) and p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and ed.provisionedMachine.id is not null and p.createdOn <='" + oneYearDate + "' and p.createdOn > '" + twoYearDate + "'", "usergroups", groupIds);
					machines1 = (List<ProvisionedMachineTO>) getHibernateTemplate().find("select distinct p from ProvisionedMachineTO p where p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and p.createdOn<='" + oneYearDate + "' and p.createdOn > '" + twoYearDate + "' and p.createdBy=" + user.getId());
				}
				if (period == 2L) {
					machines = (List<ProvisionedMachineTO>) getHibernateTemplate().findByNamedParam("select distinct p from EnvironmentTO e, ProvisionedMachineTO p, EnvironmentDetailsTO ed, ApplicationTO a, EnvironmentApplicationTO ea, UserGroupDetailsTO ug, UserGroupTO u where ed.environment.id=e.id and p.id=ed.provisionedMachine.id and a.id=ea.applicationTO.id and e.id=ea.environmentTO.id and u.id=ug.userGroups.id and ug.userGroups.id=a.userGroups.id and ug.userGroups.id in(:usergroups) and p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and ed.provisionedMachine.id is not null and p.createdOn <= '" + twoYearDate + "' and p.createdOn > '" + threeYearDate + "'", "usergroups", groupIds);
					machines1 = (List<ProvisionedMachineTO>) getHibernateTemplate().find("select distinct p from ProvisionedMachineTO p where p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and p.createdOn<='" + twoYearDate + "' and p.createdOn >'" + threeYearDate + "' and p.createdBy=" + user.getId());
				}
				if (period == 3L) {
					machines = (List<ProvisionedMachineTO>) getHibernateTemplate().findByNamedParam("select distinct p from EnvironmentTO e, ProvisionedMachineTO p, EnvironmentDetailsTO ed, ApplicationTO a, EnvironmentApplicationTO ea, UserGroupDetailsTO ug, UserGroupTO u where ed.environment.id=e.id and p.id=ed.provisionedMachine.id and a.id=ea.applicationTO.id and e.id=ea.environmentTO.id and u.id=ug.userGroups.id and ug.userGroups.id=a.userGroups.id and ug.userGroups.id in(:usergroups) and p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and ed.provisionedMachine.id is not null and p.createdOn <= '" + threeYearDate + "' and p.createdOn > '" + fourYearDate + "'", "usergroups", groupIds);
					machines1 = (List<ProvisionedMachineTO>) getHibernateTemplate().find("select distinct p from ProvisionedMachineTO p where p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and p.createdOn<='" + threeYearDate + "' and p.createdOn >'" + fourYearDate + "' and p.createdBy=" + user.getId());
				}
				if (period == 4L) {
					machines = (List<ProvisionedMachineTO>) getHibernateTemplate().findByNamedParam("select distinct p from EnvironmentTO e, ProvisionedMachineTO p, EnvironmentDetailsTO ed, ApplicationTO a, EnvironmentApplicationTO ea, UserGroupDetailsTO ug, UserGroupTO u where ed.environment.id=e.id and p.id=ed.provisionedMachine.id and a.id=ea.applicationTO.id and e.id=ea.environmentTO.id and u.id=ug.userGroups.id and ug.userGroups.id=a.userGroups.id and ug.userGroups.id in(:usergroups) and p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and ed.provisionedMachine.id is not null and p.createdOn <= '" + fourYearDate + "' and p.createdOn > '" + fiveYearDate + "'", "usergroups", groupIds);
					machines1 = (List<ProvisionedMachineTO>) getHibernateTemplate().find("select distinct p from ProvisionedMachineTO p where p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and p.createdOn<='" + fourYearDate + "' and p.createdOn >'" + fiveYearDate + "' and p.createdBy=" + user.getId());
				}
				if (period == 5L) {
					machines = (List<ProvisionedMachineTO>) getHibernateTemplate().findByNamedParam("select distinct p from EnvironmentTO e, ProvisionedMachineTO p, EnvironmentDetailsTO ed, ApplicationTO a, EnvironmentApplicationTO ea, UserGroupDetailsTO ug, UserGroupTO u where ed.environment.id=e.id and p.id=ed.provisionedMachine.id and a.id=ea.applicationTO.id and e.id=ea.environmentTO.id and u.id=ug.userGroups.id and ug.userGroups.id=a.userGroups.id and ug.userGroups.id in(:usergroups) and p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and ed.provisionedMachine.id is not null and p.createdOn <= '" + fiveYearDate + "'", "usergroups", groupIds);
					machines1 = (List<ProvisionedMachineTO>) getHibernateTemplate().find("select distinct p from ProvisionedMachineTO p where p.provisionedStatus='AVAILABLE' and p.ip is not null and p.hostName is not null and p.createdOn<='" + fiveYearDate + "'and createdBy=" + user.getId());
				}
				machines.addAll(machines1);
			}
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl: serverAgePopupDetails.", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl: serverAgePopupDetails.", he);
		} catch (Exception e) {
			LOG.error(e);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl: serverAgePopupDetails.", e);
		}
		return machines;
	}
	
	@Override
	public List<ProvisionedMachineTO> getUnTaggedServerDetails() throws CMMException {
	
		List<ProvisionedMachineTO> untaggedServers = new ArrayList<>(0);
		try {
			untaggedServers = (List<ProvisionedMachineTO>) getHibernateTemplate().find("select distinct p from ProvisionedMachineTO p where p.id not in(Select distinct p.id from EnvironmentTO e, ProvisionedMachineTO p, EnvironmentDetailsTO ed where ed.environment.id=e.id and p.id=ed.provisionedMachine.id and ed.provisionedMachine.id is not null and p.serverStatus='ACT') and p.provisionedStatus='AVAILABLE'");
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl: getUnTaggedServerDetails.", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl: getUnTaggedServerDetails.", he);
		} catch (Exception e) {
			LOG.error(e);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl: getUnTaggedServerDetails.", e);
		}
		return untaggedServers;
	}
	
	@Override
	public List<ProvisionedMachineTO> geTaggedServerDetails() throws CMMException {
	
		List<ProvisionedMachineTO> taggedServers = new ArrayList<>(0);
		try {
			taggedServers = (List<ProvisionedMachineTO>) getHibernateTemplate().find("Select distinct p from EnvironmentTO e, ProvisionedMachineTO p, EnvironmentDetailsTO ed where ed.environment.id=e.id and p.id=ed.provisionedMachine.id and ed.provisionedMachine.id is not null and p.provisionedStatus='AVAILABLE'");
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl: getUnTaggedServerDetails.", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl: getUnTaggedServerDetails.", he);
		} catch (Exception e) {
			LOG.error(e);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl: getUnTaggedServerDetails.", e);
		}
		return taggedServers;
	}
	
	@Override
	public List<String> getTaggedEnvironmentNames(String hostName) throws CMMException {
	
		List<String> envNames = new ArrayList<>(0);
		try {
			envNames = (List<String>) getHibernateTemplate().find("select distinct e.environmentName from EnvironmentTO e, EnvironmentDetailsTO ed, ProvisionedMachineTO p where e.id=ed.environment.id and p.id=ed.provisionedMachine.id and p.name=?", hostName);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl: getTaggedEnvironmentNames.", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl: getTaggedEnvironmentNames.", he);
		} catch (Exception e) {
			LOG.error(e);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl: getTaggedEnvironmentNames.", e);
		}
		return envNames;
	}
	
	@Override
	public List<ProvisionedMachineTO> getHostsWithIssues(List<String> hostNames) throws CMMException {
	
		List<ProvisionedMachineTO> machines = new ArrayList<>(0);
		try {
			if (!hostNames.isEmpty()) {
				machines = (List<ProvisionedMachineTO>) getHibernateTemplate().findByNamedParam("select distinct p from ProvisionedMachineTO p where p.hostName in (:hosts)", "hosts", hostNames);
			}
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl: getHostsWithIssues.", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl: getHostsWithIssues.", he);
		} catch (Exception e) {
			LOG.error(e);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl: getHostsWithIssues.", e);
		}
		return machines;
	}
	
	@Override
	public Long getReservationCountForEnv(String environmentName, Date startDate, Date endDate) throws CMMException {
	
		Long reservationCount = 0L;
		String query = "SELECT  count ( distinct r.id) FROM EnvironmentTO e ,ReservationTO r, EnvironmentApplicationTO ea where (r.environments.id = e.id and r.startTime>=? and r.endTime<= ? ) and e.id=ea.environmentTO.id and r.status.id=81 and e.status in( 21,23) and e.createdByDate<=? and e.environmentName=?";
		List<Long> env = (List<Long>) getHibernateTemplate().find(query, startDate, endDate, endDate, environmentName);
		if (!env.isEmpty()) {
			reservationCount = (long) env.get(0);
		}
		return reservationCount;
	}
	
	@Override
	public boolean updateEnvAppTestPhase(Long envId, Long applicationId, Long testingPhaseId) throws CMMException {
	
		Session session = getSession();
		try {
			String hql = "update EnvironmentApplicationTO e set e.testingPhaseTO.id=:testingPhaseId where e.applicationTO.id=:applicationId and e.environmentTO.id= :envId";
			Query q = session.createQuery(hql);
			q.setParameter("testingPhaseId", testingPhaseId);
			q.setParameter("applicationId", applicationId);
			q.setParameter("envId", envId);
			Long result = (long) q.executeUpdate();
			if (result == 1L) {
				return true;
			}
			return false;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl: getHostsWithIssues.", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl: getHostsWithIssues.", he);
		} catch (Exception e) {
			LOG.error(e);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl: getHostsWithIssues.", e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public ProvisionedMachineTO getHostname(String envId) throws CMMException {
	
		try {
			Long id = Long.parseLong(envId);
			ProvisionedMachineTO p = new ProvisionedMachineTO();
			List<ProvisionedMachineTO> envList = (List<ProvisionedMachineTO>) getHibernateTemplate().find("select p from EnvironmentTO e, EnvironmentDetailsTO ed, ProvisionedMachineTO p where e.id=ed.environment.id and p.id=ed.provisionedMachine.id and e.id=?", id);
			if (!envList.isEmpty() && (envList.get(0).getHostName() != null)) {
				p = envList.get(0);
			}
			return p;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl: getHostname.", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl: getHostname.", he);
		} catch (Exception e) {
			LOG.error(e);
			throw new CMMException("Problem encountered.EnvironmentDAOImpl: getHostname.", e);
		}
	}
	
	@Override
	public List<UserDefinedEnvParamsTO> userDefinedNolioParams(Long environmentId) throws CMMException {
	
		List<UserDefinedEnvParamsTO> userDefinedParamsList = new ArrayList<UserDefinedEnvParamsTO>(0);
		try {
			userDefinedParamsList = (List<UserDefinedEnvParamsTO>) getHibernateTemplate().find("from UserDefinedEnvParamsTO where environmentId = ? and nolioProcessParameterId is NOT NULL", environmentId);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : loadUserDefinedReleaseParams", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : loadUserDefinedReleaseParams", he);
		} catch (Exception ex) {
			logger.error(ex);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : loadUserDefinedReleaseParams", ex);
		}
		return userDefinedParamsList;
	}
	
	@Override
	public List<UserDefinedEnvParamsTO> fetchUserDefinedEnvParamsForScript(Long environmentId) throws CMMException {
	
		try {
			List<UserDefinedEnvParamsTO> userDefinedRelParamsList = (List<UserDefinedEnvParamsTO>) getHibernateTemplate().find("from UserDefinedEnvParamsTO where envId=? and scriptParameterId is NOT NULL", environmentId);
			return userDefinedRelParamsList;
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : loadUserDefinedReleaseParams", dae);
		}
	}
}
