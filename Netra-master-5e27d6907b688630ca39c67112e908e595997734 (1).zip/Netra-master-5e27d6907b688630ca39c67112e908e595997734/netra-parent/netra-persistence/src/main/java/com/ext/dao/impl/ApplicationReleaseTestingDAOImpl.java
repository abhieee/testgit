/**
 *
 */
package com.ext.dao.impl;

import java.util.List;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.ApplicationReleaseTestingDAO;
import com.framework.common.CMMConstants;
import com.framework.exception.CMMException;
import com.framework.to.ApplicationReleaseTestTO;

/**
 * @author 460650
 */
public class ApplicationReleaseTestingDAOImpl extends HibernateDaoSupport implements ApplicationReleaseTestingDAO {
	
	private static final Logger LOGGER = Logger.getLogger(ApplicationReleaseTestingDAOImpl.class);
	
	@Override
	public List<ApplicationReleaseTestTO> getAppReleaseTestDetailsByReleaseId(Long releaseId, long environmentPhaseId) throws CMMException {
	
		Session session = getSession();
		List<ApplicationReleaseTestTO> applicationReleaseTestTOList;
		try {
			Criteria criteria = session.createCriteria(ApplicationReleaseTestTO.class);
			criteria.add(Restrictions.eq("applicationReleaseId", releaseId));
			Criterion allPhaseCriteria = Restrictions.eq("selectedTestingPhase", CMMConstants.Framework.DROPDOWN_SELECTED_VALUE_ALL);
			Criterion selectedPhaseCriteria = Restrictions.eq("selectedTestingPhase", environmentPhaseId);
			Disjunction disjunction = Restrictions.disjunction();
			disjunction.add(selectedPhaseCriteria);
			disjunction.add(allPhaseCriteria);
			criteria.add(disjunction).addOrder(Order.asc("id"));
			applicationReleaseTestTOList = criteria.list();
		} catch (DataAccessException dae) {
			LOGGER.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseTestingDAOImpl : getAppReleaseTestDetailsByReleaseId ", dae);
		} catch (HibernateException e) {
			LOGGER.error(e);
			throw new CMMException("Problem encountered. ApplicationReleaseTestingDAOImpl : getAppReleaseTestDetailsByReleaseId ", e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return applicationReleaseTestTOList;
	}
}