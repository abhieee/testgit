package com.ext.dao.impl;

import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.util.StringUtils;
import com.ext.dao.PlatformDAO;
import com.framework.exception.CMMException;
import com.framework.to.PlatformTO;
import com.framework.to.PlatformTypeTO;
import com.framework.to.ProvisionedMachineTO;

/**
 * @author TCS
 */
public class PlatformDAOImpl extends HibernateDaoSupport implements PlatformDAO {
	
	private static final Logger LOGGER = Logger.getLogger(PlatformDAOImpl.class);
	
	/**
	 * Method used to search the existing platform in the system.
	 *
	 * @return List<PlatformTO> - The list of the platform
	 * @input parameters - platformTO this will contain the details of the search criteria like name,ram,disk space,processor etc details.
	 */
	@Override
	public List<PlatformTO> searchPlatform(PlatformTO platformTO) throws CMMException {
	
		try {
			List<PlatformTO> platformList = new ArrayList<PlatformTO>();
			DetachedCriteria criteria = DetachedCriteria.forClass(PlatformTO.class);
			if (StringUtils.hasText(platformTO.getName())) {
				criteria.add(Restrictions.like("name", "%" + platformTO.getName() + "%"));
			}
			if (StringUtils.hasText(platformTO.getDiskSpace())) {
				criteria.add(Restrictions.like("diskSpace", "%" + platformTO.getDiskSpace() + "%"));
			}
			if (StringUtils.hasText(platformTO.getProcessor())) {
				criteria.add(Restrictions.like("processor", "%" + platformTO.getProcessor() + "%"));
			}
			if (StringUtils.hasText(platformTO.getRam())) {
				criteria.add(Restrictions.like("processor", "%" + platformTO.getRam() + "%"));
			}
			if (StringUtils.hasText(platformTO.getType())) {
				criteria.add(Restrictions.like("type", "%" + platformTO.getType() + "%"));
			}
			if (platformTO.getSelectedStatus() > 0L) {
				criteria.add(Restrictions.eq("statusTO.id", platformTO.getSelectedStatus()));
			}
			List<PlatformTO> temp = (List<PlatformTO>) getHibernateTemplate().findByCriteria(criteria);
			for (PlatformTO hd : temp) {
				platformList.add(hd);
			}
			return platformList;
		} catch (DataAccessException dae) {
			LOGGER.error(dae);
			throw new CMMException("Problem encountered.PlatformDAOImpl:searchPlatform", dae);
		} catch (HibernateException he) {
			LOGGER.error(he);
			throw new CMMException("Problem encountered.PlatformDAOImpl:searchPlatform", he);
		}
	}
	
	/**
	 * Method used to search the get all platform list in the system.
	 */
	@Override
	public List<PlatformTO> getAllPlatforms() throws CMMException {
	
		try {
			return (List<PlatformTO>) getHibernateTemplate().find("from PlatformTO");
		} catch (DataAccessException dae) {
			LOGGER.error(dae);
			throw new CMMException("Problem encountered.PlatformDAOImpl:getAllPlatforms.", dae);
		} catch (HibernateException he) {
			LOGGER.error(he);
			throw new CMMException("Problem encountered.PlatformDAOImpl:getAllPlatforms.", he);
		}
	}
	
	/**
	 * Method used to add platform in the system.
	 */
	@Override
	public boolean addplatform(PlatformTO platformTO) throws CMMException {
	
		try {
			platformTO.setSelectedStatus(91L);
			getHibernateTemplate().save(platformTO);
		} catch (DataAccessException dae) {
			LOGGER.error(dae);
			throw new CMMException("Problem encountered.PlatformDAOImpl:addplatform", dae);
		} catch (HibernateException he) {
			LOGGER.error(he);
			throw new CMMException("Problem encountered.PlatformDAOImpl:addplatform", he);
		}
		return true;
	}
	
	/**
	 * Method used to get platform details of the selected platform (on the search platform screen) in the system.
	 */
	@Override
	public PlatformTO getPlatformDetails(PlatformTO platformTO) throws CMMException {
	
		try {
			return (PlatformTO) getHibernateTemplate().find("from PlatformTO where id=?", platformTO.getId()).get(0);
		} catch (DataAccessException dae) {
			LOGGER.error(dae);
			throw new CMMException("Problem encountered.PlatformDAOImpl:getPlatformDetails", dae);
		} catch (HibernateException he) {
			LOGGER.error(he);
			throw new CMMException("Problem encountered.PlatformDAOImpl:getPlatformDetails", he);
		}
	}
	
	/**
	 * Method used to edit platform in the system.
	 */
	@Override
	public boolean editPlatform(PlatformTO platformTO) throws CMMException {
	
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(PlatformTO.class, "platform");
			criteria.add(Restrictions.eq("platform.id", platformTO.getId()));
			PlatformTO platformTOTemp = (PlatformTO) getHibernateTemplate().findByCriteria(criteria).get(0);
			platformTOTemp.setModifiedbyId(platformTO.getModifiedbyId());
			platformTOTemp.setModifiedDate(platformTO.getModifiedDate());
			platformTOTemp.setName(platformTO.getName());
			platformTOTemp.setRam(platformTO.getRam());
			platformTOTemp.setDiskSpace(platformTO.getDiskSpace());
			platformTOTemp.setSelectedStatus(platformTO.getSelectedStatus());
			platformTOTemp.setType(platformTO.getType());
			platformTOTemp.setProcessor(platformTO.getProcessor());
			getHibernateTemplate().update(platformTOTemp);
			return true;
		} catch (DataAccessException dae) {
			LOGGER.error(dae);
			throw new CMMException("Problem encountered.PlatformDAOImpl:editPlatform.", dae);
		} catch (HibernateException he) {
			LOGGER.error(he);
			throw new CMMException("Problem encountered.PlatformDAOImpl:editPlatform", he);
		}
	}
	
	@Override
	public String getProvisonedPlatformName(Long existingMachineId) {
	
		ProvisionedMachineTO machine = getHibernateTemplate().get(ProvisionedMachineTO.class, existingMachineId);
		return machine.getName();
	}
	
	@Override
	public String getVmwareGuestId(String architecture) throws CMMException {
	
		PlatformTypeTO platform = new PlatformTypeTO();
		try {
			List<PlatformTypeTO> platformList = (List<PlatformTypeTO>) getHibernateTemplate().find("from PlatformTypeTO where value=?", architecture);
			if (!platformList.isEmpty()) {
				platform = platformList.get(0);
			}
		} catch (DataAccessException dae) {
			LOGGER.error(dae);
			throw new CMMException("Problem encountered.PlatformDAOImpl:getVmwareGuestId", dae);
		} catch (HibernateException he) {
			LOGGER.error(he);
			throw new CMMException("Problem encountered.PlatformDAOImpl:getVmwareGuestId", he);
		}
		return platform.getVmwareGuestId();
	}
}
