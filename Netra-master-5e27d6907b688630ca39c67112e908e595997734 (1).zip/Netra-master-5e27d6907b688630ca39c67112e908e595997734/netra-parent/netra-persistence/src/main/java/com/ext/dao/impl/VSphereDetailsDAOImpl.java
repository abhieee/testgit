/**
 *
 */
package com.ext.dao.impl;

import java.util.List;
import org.hibernate.HibernateException;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.VSphereDetailsDAO;
import com.framework.common.CMMConstants;
import com.framework.exception.CMMException;
import com.framework.to.DataStoreTO;
import com.framework.to.VSphereDetailsTO;

/**
 * @author 460650
 */
public class VSphereDetailsDAOImpl extends HibernateDaoSupport implements VSphereDetailsDAO {
	
	@Override
	public VSphereDetailsTO getVSphereDetails() throws CMMException {
	
		try {
			List<VSphereDetailsTO> vShpereList = (List<VSphereDetailsTO>) getHibernateTemplate().find("from VSphereDetailsTO");
			if ((vShpereList == null) || vShpereList.isEmpty()) {
				throw new CMMException("No records present in DB for VSphere");
			}
			return vShpereList.get(0);
		} catch (DataAccessException | HibernateException e) {
			logger.error("Problem in fetching VSphere Details" + e.getMessage());
			throw new CMMException("Problem encountered.VSphereDetailsDAOImpl:getVSphereDetails", e);
		}
	}
	
	@Override
	public VSphereDetailsTO getVSphereDetailsById(Long dataCentre) throws CMMException {
	
		try {
			VSphereDetailsTO details = new VSphereDetailsTO();
			List<VSphereDetailsTO> detailsList = (List<VSphereDetailsTO>) getHibernateTemplate().find("from VSphereDetailsTO where id=?", dataCentre);
			if (detailsList.isEmpty()) {
				throw new CMMException("No records present in DB for VSphere");
			} else {
				details = detailsList.get(0);
			}
			return details;
		} catch (DataAccessException | HibernateException e) {
			logger.error("Error in fetching VSphere Details" + e.getMessage());
			throw new CMMException("Problem encountered.VSphereDetailsDAOImpl:getVSphereDetails", e);
		}
	}
	
	@Override
	public void addDataStoresToDB(List<DataStoreTO> dataStoreList, Long dataCenterId) throws CMMException {
	
		try {
			for (DataStoreTO datastore : dataStoreList) {
				DataStoreTO datastoreTO = new DataStoreTO();
				datastoreTO.setDataCentreId(dataCenterId);
				datastoreTO.setName(datastore.getName());
				datastoreTO.setStatus(CMMConstants.Framework.Status.ACTIVE);
				getHibernateTemplate().save(datastoreTO);
			}
		} catch (DataIntegrityViolationException div) {
			logger.error(div);
			throw new CMMException("Problem encountered. VSphereDetailsDAOImpl:addDataStoresToDB", div);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. VSphereDetailsDAOImpl:addDataStoresToDB", dae);
		}
	}
	
	@Override
	public List<DataStoreTO> getDataStoreListFromDB(Long dataCentre) throws CMMException {
	
		try {
			return (List<DataStoreTO>) getHibernateTemplate().find("from DataStoreTO");
		} catch (DataAccessException e) {
			logger.error("Error in fetching dataStoreList" + e.getMessage());
			throw new CMMException("Problem encountered.VSphereDetailsDAOImpl:getDataStoreListFromDB", e);
		} catch (HibernateException e) {
			logger.error("Error in fetching VSphere Details" + e.getMessage());
			throw new CMMException("Problem encountered.VSphereDetailsDAOImpl:getDataStoreListFromDB", e);
		}
	}
}
