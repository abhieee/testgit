/**
 *
 */
package com.ext.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.sql.DataSource;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import com.ext.dao.ZabbixDAO;
import com.framework.exception.CMMException;
import com.framework.to.ItemDetails;

/**
 * @author 460650
 */
public class ZabbixDAOImpl implements ZabbixDAO {
	
	@Autowired
	@Qualifier("zabbixdataSource")
	private DataSource zabbixdataSource;
	private static final Logger LOG = Logger.getLogger(ZabbixDAOImpl.class);
	
	@Override
	public List<ItemDetails> getHostDetails(String itemName, long timeFrom, long timeTill) throws CMMException {
	
		Connection dbConnection = null;
		Connection historyuintConnection = null;
		PreparedStatement preparedStatement = null;
		PreparedStatement historyUintPrepStmt = null;
		ResultSet rsHistoryUint = null;
		ResultSet rs = null;
		List<ItemDetails> itemDetailList = new ArrayList<ItemDetails>();
		StringBuilder selectSQL = new StringBuilder("select h2.host,i.hostid,min(h.value) as Min_Val,max(h.value) as Max_Val, i.units from history h inner join items i on i.itemid = h.itemid inner join hosts h2 on i.hostid = h2.hostid where i.name = ? ");
		if ((timeFrom > 0) && (timeTill > 0)) {
			selectSQL.append("and (h.clock > ? and h.clock <= ?) ");
		}
		selectSQL.append("and h.value!=0 group by i.hostid");
		try {
			dbConnection = zabbixdataSource.getConnection();
			preparedStatement = dbConnection.prepareStatement(selectSQL.toString());
			preparedStatement.setString(1, itemName);
			if ((timeFrom > 0) && (timeTill > 0)) {
				preparedStatement.setLong(2, timeFrom);
				preparedStatement.setLong(3, timeTill);
			}
			rs = preparedStatement.executeQuery();
			while (rs.next()) {
				ItemDetails itemDetails = new ItemDetails();
				String host = rs.getString("host");
				double minVal = rs.getDouble("Min_Val");
				double maxVal = rs.getDouble("Max_Val");
				String units = rs.getString("units");
				itemDetails.setHostName(host);
				itemDetails.setMaxValue(Double.toString(Math.round(maxVal * 100.0) / 100.0));
				itemDetails.setMinValue(Double.toString(Math.round(minVal * 100.0) / 100.0));
				itemDetails.setUnits(units);
				itemDetailList.add(itemDetails);
			}
			if (itemDetailList.isEmpty() || (itemDetailList == null)) {
				StringBuilder historyUintSQL = new StringBuilder("select h2.host,i.hostid,min(h.value) as Min_Val,max(h.value) as Max_Val, i.units from history_uint h inner join items i on i.itemid = h.itemid inner join hosts h2 on i.hostid = h2.hostid where i.name = ? ");
				if ((timeFrom > 0) && (timeTill > 0)) {
					historyUintSQL.append("and (h.clock > ? and h.clock <= ?) ");
				}
				historyUintSQL.append("and h.value!=0 group by i.hostid");
				historyuintConnection = zabbixdataSource.getConnection();
				historyUintPrepStmt = historyuintConnection.prepareStatement(historyUintSQL.toString());
				historyUintPrepStmt.setString(1, itemName);
				if ((timeFrom > 0) && (timeTill > 0)) {
					historyUintPrepStmt.setLong(2, timeFrom);
					historyUintPrepStmt.setLong(3, timeTill);
				}
				rsHistoryUint = historyUintPrepStmt.executeQuery();
				while (rsHistoryUint.next()) {
					ItemDetails itemDetails = new ItemDetails();
					String host = rsHistoryUint.getString("host");
					long minVal = rsHistoryUint.getLong("Min_Val");
					long maxVal = rsHistoryUint.getLong("Max_Val");
					String units = rsHistoryUint.getString("units");
					itemDetails.setHostName(host);
					itemDetails.setMaxValue(Long.toString(maxVal));
					itemDetails.setMinValue(Long.toString(minVal));
					itemDetails.setUnits(units);
					itemDetailList.add(itemDetails);
				}
			}
			if (historyuintConnection != null) {
				historyuintConnection.close();
			}
			if (historyUintPrepStmt != null) {
				historyUintPrepStmt.close();
			}
		} catch (SQLException e) {
			throw new CMMException("Error in executing scripts", e);
		} finally {
			if (preparedStatement != null) {
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					LOG.error("Error in executing scripts", e);
				}
			}
			if (historyUintPrepStmt != null) {
				try {
					historyUintPrepStmt.close();
				} catch (SQLException e) {
					LOG.error("Error in executing scripts", e);
				}
			}
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					LOG.error("Error in executing scripts", e);
				}
			}
			if (rsHistoryUint != null) {
				try {
					rsHistoryUint.close();
				} catch (SQLException e) {
					LOG.error("Error in executing scripts", e);
				}
			}
			if (dbConnection != null) {
				try {
					dbConnection.close();
				} catch (SQLException e) {
					LOG.error("Error in executing scripts", e);
				}
			}
			if (historyuintConnection != null) {
				try {
					historyuintConnection.close();
				} catch (SQLException e) {
					LOG.error("Error in executing scripts", e);
				}
			}
		}
		return itemDetailList;
	}
}
