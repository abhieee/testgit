/**
 *
 */
package com.ext.nolio.dao.impl;

import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.hibernate.exception.ConstraintViolationException;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.nolio.dao.CAReleaseActivityDao;
import com.framework.common.CMMConstants;
import com.framework.exception.CMMException;
import com.framework.to.ActivitySoftwareMappingTO;
import com.framework.to.CAReleaseActivityTO;
import com.framework.to.ManifestTypeTO;
import com.framework.to.SoftwareTO;
import com.framework.to.SoftwareTaskMappingTO;
import com.framework.to.SoftwareconfigTO;
import com.framework.to.ZabbixSoftwareMappingTO;

/**
 * @author 460650
 */
public class CAReleaseActivityDaoImpl extends HibernateDaoSupport implements CAReleaseActivityDao {
	
	private static final Logger LOGGER = Logger.getLogger(CAReleaseActivityDaoImpl.class);
	
	@Override
	public List<CAReleaseActivityTO> getAllActivity() throws CMMException {
	
		try {
			List<CAReleaseActivityTO> caReleaseActivityList = (List<CAReleaseActivityTO>) getHibernateTemplate().find("from CAReleaseActivityTO");
			if (caReleaseActivityList == null) {
				LOGGER.debug("No acitvity found in database");
				throw new CMMException("No activity list found.");
			}
			return caReleaseActivityList;
		} catch (DataAccessException dae) {
			LOGGER.error(dae);
			throw new CMMException("Problem encountered. CAReleaseActivityDaoImpl : getAllActivity", dae);
		} catch (HibernateException he) {
			LOGGER.error(he);
			throw new CMMException("Problem encountered. CAReleaseActivityDaoImpl : getAllActivity", he);
		}
	}
	
	@Override
	public List<CAReleaseActivityTO> getAllRemainingActivities() throws CMMException {
	
		try {
			List<CAReleaseActivityTO> caReleaseActivityList = (List<CAReleaseActivityTO>) getHibernateTemplate().find("from CAReleaseActivityTO");
			if (caReleaseActivityList == null) {
				LOGGER.debug("No acitvity found in database");
				throw new CMMException("No activity list found.");
			}
			return caReleaseActivityList;
		} catch (DataAccessException dae) {
			LOGGER.error(dae);
			throw new CMMException("Problem encountered. CAReleaseActivityDaoImpl : getAllRemainingActivities", dae);
		} catch (HibernateException he) {
			LOGGER.error(he);
			throw new CMMException("Problem encountered. CAReleaseActivityDaoImpl : getAllRemainingActivities", he);
		}
	}
	
	@Override
	public boolean defineActivitiesForSoftware(ActivitySoftwareMappingTO mapping) throws CMMException {
	
		boolean flag = false;
		Long softwareConfigId = null;
		Session session = null;
		try {
			if (mapping.getSoftwareconfigTO().getId() != null) {
				DetachedCriteria criteria1 = DetachedCriteria.forClass(ActivitySoftwareMappingTO.class);
				criteria1.createAlias("softwareconfigTO", "sConfig", CriteriaSpecification.INNER_JOIN);
				criteria1.add(Restrictions.eq("sConfig.id", mapping.getSoftwareconfigTO().getId()));
				List<ActivitySoftwareMappingTO> AcitivityList = (List<ActivitySoftwareMappingTO>) getHibernateTemplate().findByCriteria(criteria1);
				for (ActivitySoftwareMappingTO temp : AcitivityList) {
					Transaction tx1 = null;
					session = getSession();
					tx1 = session.beginTransaction();
					String hql1 = "Delete from CaActivityExecOrderTO where activitySoftwareMappingTOP.activitySoftwareMapId = :activitySoftwareMapId";
					Query query1 = session.createQuery(hql1);
					query1.setParameter("activitySoftwareMapId", temp.getActivitySoftwareMapId());
					query1.executeUpdate();
					String hql2 = "Delete from ActivitySoftwareMappingTO where activitySoftwareMapId = :activitySoftwareMapId";
					Query query2 = session.createQuery(hql2);
					query2.setParameter("activitySoftwareMapId", temp.getActivitySoftwareMapId());
					query2.executeUpdate();
					tx1.commit();
				}
				softwareConfigId = mapping.getSoftwareconfigTO().getId();
			} else {
				softwareConfigId = (Long) getHibernateTemplate().find("select MAX(id) from SoftwareconfigTO where deviceId=?", mapping.getSoftwareconfigTO().getDeviceId()).get(0);
			}
			SoftwareconfigTO STO = (SoftwareconfigTO) getHibernateTemplate().find("from SoftwareconfigTO where id=? ", softwareConfigId).get(0);
			Transaction tx = null;
			session = getSession();
			tx = session.beginTransaction();
			String hql = "from CAReleaseActivityTO where activityId in (:CAActivityId)";
			Query q = session.createQuery(hql);
			q.setParameterList("CAActivityId", mapping.getDefinedActivities());
			List<Object[]> obj = q.list();
			tx.commit();
			ActivitySoftwareMappingTO temp = new ActivitySoftwareMappingTO();
			for (Object activity : obj) {
				CAReleaseActivityTO CARAObj = (CAReleaseActivityTO) activity;
				temp.setSoftwareconfigTO(STO);
				temp.setCaReleaseActivityTO(CARAObj);
				temp.setActivityId(CARAObj.getActivityId());
				getHibernateTemplate().save(temp);
			}
			flag = true;
		} catch (ConstraintViolationException ce) {
			LOGGER.error(ce);
			throw new CMMException("problem encountered. CAReleaseActivityDaoImpl : defineActivitiesForSoftware", ce);
		} catch (DataAccessException | HibernateException dae) {
			LOGGER.error(dae);
			throw new CMMException("Problem encountered. CAReleaseActivityDaoImpl : defineActivitiesForSoftware", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return flag;
	}
	
	@Override
	public List<CAReleaseActivityTO> getSoftwareActivitites(Long softwareConfigId) throws CMMException {
	
		List<CAReleaseActivityTO> cAReleaseActivityTOList = new ArrayList<CAReleaseActivityTO>();
		try {
			List<ActivitySoftwareMappingTO> activitySoftwareMappingTO = (List<ActivitySoftwareMappingTO>) getHibernateTemplate().find("from ActivitySoftwareMappingTO where softwareconfigTO.id =?", softwareConfigId);
			if (activitySoftwareMappingTO == null) {
				LOGGER.debug("No acitvity found in database");
				throw new CMMException("No activity list found.");
			}
			for (ActivitySoftwareMappingTO temp : activitySoftwareMappingTO) {
				CAReleaseActivityTO cAReleaseActivityTO = temp.getCaReleaseActivityTO();
				cAReleaseActivityTOList.add(cAReleaseActivityTO);
			}
			return cAReleaseActivityTOList;
		} catch (DataAccessException dae) {
			LOGGER.error(dae);
			throw new CMMException("Problem encountered. CAReleaseActivityDaoImpl : getSoftwareActivitites", dae);
		} catch (HibernateException he) {
			LOGGER.error(he);
			throw new CMMException("Problem encountered. CAReleaseActivityDaoImpl : getSoftwareActivitites", he);
		}
	}
	
	@Override
	public long fetchMappedActivitySoftwareId(long activityId, long softwareId) throws CMMException {
	
		try {
			List<ActivitySoftwareMappingTO> activitySoftwareMapList = (List<ActivitySoftwareMappingTO>) getHibernateTemplate().find("from ActivitySoftwareMappingTO where caReleaseActivityTO.activityId=? and softwareconfigTO.id=?", activityId, softwareId);
			if ((activitySoftwareMapList == null) || activitySoftwareMapList.isEmpty()) {
				throw new CMMException("No records found for activityId: " + activityId);
			}
			return activitySoftwareMapList.get(0).getActivitySoftwareMapId();
		} catch (DataAccessException dae) {
			LOGGER.error(dae);
			throw new CMMException("Problem encountered. CAReleaseActivityDaoImpl : fetchMappedActivitySoftwareId", dae);
		} catch (HibernateException e) {
			LOGGER.error(e);
			throw new CMMException("Problem encountered. CAReleaseActivityDaoImpl : fetchMappedActivitySoftwareId", e);
		}
	}
	
	@Override
	public SoftwareconfigTO addSoftwareMapDetails(SoftwareTO softwareTO) throws CMMException {
	
		SoftwareconfigTO temp = null;
		Session session = null;
		try {
			List<SoftwareconfigTO> list = (List<SoftwareconfigTO>) getHibernateTemplate().find("from SoftwareconfigTO where deviceId=? and version=?", softwareTO.getId(), softwareTO.getVersion());
			if ((list != null) && !list.isEmpty()) {
				temp = list.get(0);
				/** Deleting existing data */
				if ((temp.getTargetFlag() != null) && "W".equals(temp.getTargetFlag())) {
					if ((temp.getInstallerLocationWindows() != null) && (temp.getTargetLocationWindows() != null)) {
						temp.setInstallerLocationWindows("");
						temp.setTargetLocationWindows("");
					}
				}
				if ((temp.getTargetFlag() != null) && "L".equals(temp.getTargetFlag())) {
					if ((temp.getInstallerLocationLinux() != null) && (temp.getTargetLocationLinux() != null)) {
						temp.setInstallerLocationLinux("");
						temp.setTargetLocationLinux("");
					}
				}
				if ((temp.getTargetFlag() != null) && "B".equals(temp.getTargetFlag())) {
					if ((temp.getInstallerLocationLinux() != null) && (temp.getTargetLocationLinux() != null) && (temp.getInstallerLocationWindows() != null) && (temp.getTargetLocationWindows() != null)) {
						temp.setInstallerLocationLinux("");
						temp.setTargetLocationLinux("");
						temp.setInstallerLocationWindows("");
						temp.setTargetLocationWindows("");
					}
				}
				getHibernateTemplate().saveOrUpdate(temp);
				/** Deleting existing data */
				List<SoftwareTaskMappingTO> SoftwareTaskMappingToList = (List<SoftwareTaskMappingTO>) getHibernateTemplate().find("from SoftwareTaskMappingTO where softwareConfigId=?", temp.getId());
				if (SoftwareTaskMappingToList != null) {
					for (SoftwareTaskMappingTO SoftwareTaskMap : SoftwareTaskMappingToList) {
						getHibernateTemplate().delete(SoftwareTaskMap);
					}
				}
				Long taskOrder = 0L;
				for (Long taskId : softwareTO.getTasks()) {
					SoftwareTaskMappingTO sofTaskMap = new SoftwareTaskMappingTO();
					sofTaskMap.setSoftwareConfigId(temp.getId());
					sofTaskMap.setTaskId(taskId);
					sofTaskMap.setTaskOrder(taskOrder);
					getHibernateTemplate().save(sofTaskMap);
					taskOrder++;
				}
			}
			temp.setTargetFlag(softwareTO.getTargetFlag());
			temp.setInstallerLocationLinux(softwareTO.getInstallerLocationLinux());
			temp.setInstallerLocationWindows(softwareTO.getInstallerLocationWindows());
			temp.setTargetLocationLinux(softwareTO.getTargetLocationLinux());
			temp.setTargetLocationWindows(softwareTO.getTargetLocationWindows());
			getHibernateTemplate().saveOrUpdate(temp);
			List<ZabbixSoftwareMappingTO> zabbixSoftwareMappingToP = (List<ZabbixSoftwareMappingTO>) getHibernateTemplate().find("from ZabbixSoftwareMappingTO where softwareConfigId =? ", temp.getId());
			if (zabbixSoftwareMappingToP != null) {
				for (int i = 0; i < zabbixSoftwareMappingToP.size(); i++) {
					ZabbixSoftwareMappingTO zabbixSoftwareMapTO = zabbixSoftwareMappingToP.get(i);
					getHibernateTemplate().delete(zabbixSoftwareMapTO);
				}
			}
			for (Long tempObj : softwareTO.getSelectedTemplates()) {
				ZabbixSoftwareMappingTO zabbixSoftwareMappingTO = new ZabbixSoftwareMappingTO();
				zabbixSoftwareMappingTO.setTemplateid(tempObj);
				zabbixSoftwareMappingTO.setSoftwareConfigId(temp.getId());
				for (ZabbixSoftwareMappingTO tempTemplate : softwareTO.getZabbixTemplatesList()) {
					if (tempTemplate.getTemplateid().equals(tempObj)) {
						zabbixSoftwareMappingTO.setName(tempTemplate.getName());
					}
				}
				getHibernateTemplate().save(zabbixSoftwareMappingTO);
			}
		} catch (ConstraintViolationException ce) {
			LOGGER.error(ce);
			throw new CMMException("problem encountered. CAReleaseActivityDaoImpl : addSoftwareMapDetails", ce);
		} catch (DataAccessException | HibernateException dae) {
			LOGGER.error(dae);
			throw new CMMException("Problem encountered. CAReleaseActivityDaoImpl : addSoftwareMapDetails", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return temp;
	}
	
	@Override
	public List<ManifestTypeTO> getAllManifestType(String automationTools) throws CMMException {
	
		try {
			List<ManifestTypeTO> manifestFilter = new ArrayList<ManifestTypeTO>();
			List<ManifestTypeTO> manifestType = (List<ManifestTypeTO>) getHibernateTemplate().find("from ManifestTypeTO");
			for (ManifestTypeTO m : manifestType) {
				if (CMMConstants.Framework.AutomationTool.NOLIO.equalsIgnoreCase(automationTools) && m.getName().equalsIgnoreCase(CMMConstants.Framework.GlobalParameters.NOLIO_TOOL_NAME_AS_CARA)) {
					manifestFilter.add(m);
				} else if (CMMConstants.Framework.AutomationTool.Udeploy.equalsIgnoreCase(automationTools) && m.getName().equalsIgnoreCase(CMMConstants.Framework.AutomationTool.Udeploy)) {
					manifestFilter.add(m);
				} else if (CMMConstants.Framework.AutomationTool.PUPPET.equalsIgnoreCase(automationTools) && m.getName().equalsIgnoreCase(CMMConstants.Framework.AutomationTool.PUPPET)) {
					manifestFilter.add(m);
				}
				if (m.getName().equalsIgnoreCase(CMMConstants.Framework.GlobalParameters.Scripts)) {
					manifestFilter.add(m);
				}
			}
			if (manifestType == null) {
				LOGGER.debug("No manifest found in database");
				throw new CMMException("No manifest list found.");
			}
			return manifestFilter;
		} catch (DataAccessException | HibernateException dae) {
			LOGGER.error(dae);
			throw new CMMException("Problem encountered. CAReleaseActivityDaoImpl : getAllManifestType", dae);
		}
	}
}
