package com.ext.dao.impl;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Property;
import org.hibernate.criterion.Restrictions;
import org.hibernate.engine.SessionFactoryImplementor;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.ext.dao.ReservationDAO;
import com.framework.common.CMMConstants;
import com.framework.common.CMMConstants.Framework.Entity;
import com.framework.common.CMMConstants.Framework.ReservationStatus;
import com.framework.exception.CMMException;
import com.framework.to.ApplicationCalendarTO;
import com.framework.to.ApplicationTO;
import com.framework.to.EnvironmentCalendarTO;
import com.framework.to.EnvironmentTO;
import com.framework.to.GlobalParametersTO;
import com.framework.to.HardwareTO;
import com.framework.to.ProjectsTO;
import com.framework.to.ReleasePlanningPhasesTO;
import com.framework.to.ReleasePlanningTO;
import com.framework.to.ReservationMailTO;
import com.framework.to.ReservationTO;
import com.framework.to.StatusTO;
import com.framework.to.TestingPhaseTO;
import com.framework.to.TestingTypeTO;
import com.framework.to.UserBusinessUnitTO;
import com.framework.to.UserGroupTO;
import com.framework.to.UserTO;
import com.framework.to.WorkflowCurrentTO;
import com.framework.to.WorkflowHistoryTO;
import com.framework.utility.DateUtils;

public class ReservationDAOImpl extends HibernateDaoSupport implements ReservationDAO {
	
	private static final Logger LOG = Logger.getLogger(ReservationDAOImpl.class);
	private Date startTimeReference;
	private Date endTimeReference;
	
	@Override
	public void deleteReservations(ReservationTO reservationTO, Long statusValue) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			Query sqlQuery = null;
			Query sqlQueryUpdate = null;
			WorkflowCurrentTO workFlowCurrent = new WorkflowCurrentTO();
			List<Long> reservationId = reservationTO.getSelectedReservations();
			for (Long id : reservationId) {
				StatusTO status = new StatusTO();
				ReservationTO resObj = (ReservationTO) getHibernateTemplate().find("from ReservationTO where id =?", id).get(0);
				if (resObj.getParentId() == null) {
					List<WorkflowCurrentTO> workFlowCurrentList = (List<WorkflowCurrentTO>) getHibernateTemplate().find("from WorkflowCurrentTO where entity_id =?", id);
					if (!workFlowCurrentList.isEmpty()) {
						workFlowCurrent = workFlowCurrentList.get(0);
					}
					String query5 = "INSERT INTO wf_history ( wf_id , client_id , project_id , level_order , status_changed_to , status_changed_by_role , status_changed_by_name , status_changed_id , status_change_date , createdby , createdate ,message_to_user, application_id , wf_current_id , environment_id , entity_id )  VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
					sqlQuery = session.createSQLQuery(query5);
					sqlQuery.setParameter(0, 3L);
					sqlQuery.setParameter(1, workFlowCurrent.getClientId());
					sqlQuery.setParameter(2, workFlowCurrent.getProjectId());
					sqlQuery.setParameter(3, workFlowCurrent.getLevelOrder());
					sqlQuery.setParameter(4, 6L);
					sqlQuery.setParameter(5, reservationTO.getCancelUserRoleId());
					sqlQuery.setParameter(6, reservationTO.getCancelUserName());
					sqlQuery.setParameter(7, reservationTO.getCancelUserId());
					sqlQuery.setParameter(8, DateUtils.getStartTime(new Date()));
					sqlQuery.setParameter(9, reservationTO.getCancelUserId());
					sqlQuery.setParameter(10, workFlowCurrent.getRequestDate());
					sqlQuery.setParameter(11, "Cancelled by user");
					sqlQuery.setParameter(12, workFlowCurrent.getApplicationId());
					sqlQuery.setParameter(13, workFlowCurrent.getReqId());
					sqlQuery.setParameter(14, workFlowCurrent.getEnvironmentId());
					sqlQuery.setParameter(15, id);
					String query6 = "UPDATE wf_current SET wf_status_id=? WHERE entity_id=?";
					sqlQueryUpdate = session.createSQLQuery(query6);
					sqlQueryUpdate.setParameter(0, 6L);
					sqlQueryUpdate.setParameter(1, id);
				}
				if ((resObj.getStatus().getId() == 84L) && "S".equalsIgnoreCase(resObj.getDisruptive())) {
					if (resObj.getIsconflicting() == 0) {
						status.setId(statusValue);
						resObj.setStatus(status);
						resObj.setCancelUserId(reservationTO.getCancelUserId());
						resObj.setComments(reservationTO.getComments());
						if (resObj.getParentId() == null) {
							if (statusValue == 82L) {
								sqlQuery.executeUpdate();
								sqlQueryUpdate.executeUpdate();
							}
						}
						getHibernateTemplate().update(resObj);
					} else {
						status.setId(statusValue);
						resObj.setStatus(status);
						resObj.setCancelUserId(reservationTO.getCancelUserId());
						resObj.setComments(reservationTO.getComments());
						resObj.setIsconflicting(0L);
						getHibernateTemplate().update(resObj);
						if (resObj.getParentId() == null) {
							if (statusValue == 82L) {
								sqlQuery.executeUpdate();
								sqlQueryUpdate.executeUpdate();
							}
						}
						String query1 = "select r from ReservationTO as r where r.environments.id =?  and ((r.startTime <= ? and r.endTime >= ? and r.endTime <= ?) or (r.endTime >= ? and r.startTime >= ? and r.startTime <= ?) or (r.startTime <= ? and r.endTime >= ?) or (r.startTime >= ? and r.startTime <= ? and r.endTime >= ? and r.endTime <= ?)) and (r.startTime != ? and r.endTime != ?) and r.status.id=? and r.disruptive in ('D' , 'L') and isconflicting=1L ";
						List<ReservationTO> disruptiveApprovedList1 = (List<ReservationTO>) getHibernateTemplate().find(query1, resObj.getEnvironments().getId(), resObj.getStartTime(), resObj.getStartTime(), resObj.getEndTime(), resObj.getEndTime(), resObj.getStartTime(), resObj.getEndTime(), resObj.getStartTime(), resObj.getEndTime(), resObj.getStartTime(), resObj.getEndTime(), resObj.getStartTime(), resObj.getEndTime(), resObj.getEndTime(), resObj.getStartTime(), CMMConstants.Framework.Entity.RESERVATION_STATUS_APPROVED);
						for (ReservationTO res : disruptiveApprovedList1) {
							String query2 = "select r from ReservationTO as r where r.environments.id =?  and ((r.startTime <= ? and r.endTime >= ? and r.endTime <= ?) or (r.endTime >= ? and r.startTime >= ? and r.startTime <= ?) or (r.startTime <= ? and r.endTime >= ?) or (r.startTime >= ? and r.startTime <= ? and r.endTime >= ? and r.endTime <= ?)) and (r.startTime != ? and r.endTime != ?) and id !=? ";
							List<ReservationTO> reservation2 = (List<ReservationTO>) getHibernateTemplate().find(query2, res.getEnvironments().getId(), res.getStartTime(), res.getStartTime(), res.getEndTime(), res.getEndTime(), res.getStartTime(), res.getEndTime(), res.getStartTime(), res.getEndTime(), res.getStartTime(), res.getEndTime(), res.getStartTime(), res.getEndTime(), res.getEndTime(), res.getStartTime(), resObj.getId());
							Long countSharedPending = 0L;
							Long countDisruptivePending = 0L;
							for (ReservationTO reservationToObj : reservation2) {
								if ("S".equalsIgnoreCase(reservationToObj.getDisruptive()) && (reservationToObj.getStatus().getId() == 84L)) {
									countSharedPending++;
								}
								if (!"S".equalsIgnoreCase(reservationToObj.getDisruptive()) && (reservationToObj.getStatus().getId() == 84L)) {
									countDisruptivePending++;
								}
							}
							if ((countSharedPending > 0) || (countDisruptivePending > 0)) {} else {
								res.setIsconflicting(0L);
								getHibernateTemplate().update(res);
							}
						}
					}
				}
				if ((resObj.getStatus().getId() == 81L) && "S".equalsIgnoreCase(resObj.getDisruptive())) {
					if (resObj.getIsconflicting() == 0) {
						status.setId(statusValue);
						resObj.setStatus(status);
						resObj.setCancelUserId(reservationTO.getCancelUserId());
						resObj.setComments(reservationTO.getComments());
						getHibernateTemplate().update(resObj);
						if (resObj.getParentId() == null) {
							if (statusValue == 82L) {
								sqlQuery.executeUpdate();
								sqlQueryUpdate.executeUpdate();
							}
						}
					} else {
						status.setId(statusValue);
						resObj.setStatus(status);
						resObj.setCancelUserId(reservationTO.getCancelUserId());
						resObj.setComments(reservationTO.getComments());
						resObj.setIsconflicting(0L);
						getHibernateTemplate().update(resObj);
						if (resObj.getParentId() == null) {
							if (statusValue == 82L) {
								sqlQuery.executeUpdate();
								sqlQueryUpdate.executeUpdate();
							}
						}
						String query1 = "select r from ReservationTO as r where r.environments.id =?  and ((r.startTime <= ? and r.endTime >= ? and r.endTime <= ?) or (r.endTime >= ? and r.startTime >= ? and r.startTime <= ?) or (r.startTime <= ? and r.endTime >= ?) or (r.startTime >= ? and r.startTime <= ? and r.endTime >= ? and r.endTime <= ?)) and (r.startTime != ? and r.endTime != ?) and r.status.id=? and r.disruptive in ('D' , 'L') and r.isconflicting=1 ";
						List<ReservationTO> disruptivePendingConflictList = (List<ReservationTO>) getHibernateTemplate().find(query1, resObj.getEnvironments().getId(), resObj.getStartTime(), resObj.getStartTime(), resObj.getEndTime(), resObj.getEndTime(), resObj.getStartTime(), resObj.getEndTime(), resObj.getStartTime(), resObj.getEndTime(), resObj.getStartTime(), resObj.getEndTime(), resObj.getStartTime(), resObj.getEndTime(), resObj.getEndTime(), resObj.getStartTime(), CMMConstants.Framework.Entity.RESERVATION_STATUS_PENDING);
						for (ReservationTO res : disruptivePendingConflictList) {
							String query2 = "select r from ReservationTO as r where r.environments.id =?  and ((r.startTime <= ? and r.endTime >= ? and r.endTime <= ?) or (r.endTime >= ? and r.startTime >= ? and r.startTime <= ?) or (r.startTime <= ? and r.endTime >= ?) or (r.startTime >= ? and r.startTime <= ? and r.endTime >= ? and r.endTime <= ?)) and (r.startTime != ? and r.endTime != ?) and r.status.id=?  and id !=? and r.isconflicting=1 ";
							List<ReservationTO> approvedConflictList = (List<ReservationTO>) getHibernateTemplate().find(query2, res.getEnvironments().getId(), res.getStartTime(), res.getStartTime(), res.getEndTime(), res.getEndTime(), res.getStartTime(), res.getEndTime(), res.getStartTime(), res.getEndTime(), res.getStartTime(), res.getEndTime(), res.getStartTime(), res.getEndTime(), res.getEndTime(), res.getStartTime(), CMMConstants.Framework.Entity.RESERVATION_STATUS_APPROVED, resObj.getId());
							Long countSharedApproved = 0L;
							Long countDisruptiveApproved = 0L;
							List<ReservationTO> sharedApprovedList = new ArrayList<ReservationTO>(0);
							List<ReservationTO> disruptiveApprovedList = new ArrayList<ReservationTO>(0);
							for (ReservationTO reservationToObj : approvedConflictList) {
								if ("S".equalsIgnoreCase(reservationToObj.getDisruptive()) && (reservationToObj.getStatus().getId() == 81L)) {
									sharedApprovedList.add(reservationToObj);
									countSharedApproved++;
								}
								if (!"S".equalsIgnoreCase(reservationToObj.getDisruptive()) && (reservationToObj.getStatus().getId() == 81L)) {
									disruptiveApprovedList.add(reservationToObj);
									countDisruptiveApproved++;
								}
							}
							if ((countSharedApproved > 0) || (countDisruptiveApproved > 0)) {} else {
								res.setIsconflicting(0L);
								getHibernateTemplate().update(res);
							}
						}
					}
				}
				if (((resObj.getStatus().getId() == 84L) && "D".equalsIgnoreCase(resObj.getDisruptive())) || ((resObj.getStatus().getId() == 84L) && "L".equalsIgnoreCase(resObj.getDisruptive()))) {
					if (resObj.getIsconflicting() == 0) {
						status.setId(statusValue);
						resObj.setStatus(status);
						resObj.setCancelUserId(reservationTO.getCancelUserId());
						resObj.setComments(reservationTO.getComments());
						getHibernateTemplate().update(resObj);
						if (resObj.getParentId() == null) {
							if (statusValue == 82L) {
								sqlQuery.executeUpdate();
								sqlQueryUpdate.executeUpdate();
							}
						}
					} else {
						status.setId(statusValue);
						resObj.setStatus(status);
						resObj.setCancelUserId(reservationTO.getCancelUserId());
						resObj.setComments(reservationTO.getComments());
						resObj.setIsconflicting(0L);
						getHibernateTemplate().update(resObj);
						if (resObj.getParentId() == null) {
							if (statusValue == 82L) {
								sqlQuery.executeUpdate();
								sqlQueryUpdate.executeUpdate();
							}
						}
						String query1 = "select r from ReservationTO as r where r.environments.id =?  and ((r.startTime <= ? and r.endTime >= ? and r.endTime <= ?) or (r.endTime >= ? and r.startTime >= ? and r.startTime <= ?) or (r.startTime <= ? and r.endTime >= ?) or (r.startTime >= ? and r.startTime <= ? and r.endTime >= ? and r.endTime <= ?)) and (r.startTime != ? and r.endTime != ?) and r.status.id=? and id !=? and r.isconflicting=1 ";
						List<ReservationTO> approvedConflictList = (List<ReservationTO>) getHibernateTemplate().find(query1, resObj.getEnvironments().getId(), resObj.getStartTime(), resObj.getStartTime(), resObj.getEndTime(), resObj.getEndTime(), resObj.getStartTime(), resObj.getEndTime(), resObj.getStartTime(), resObj.getEndTime(), resObj.getStartTime(), resObj.getEndTime(), resObj.getStartTime(), resObj.getEndTime(), resObj.getEndTime(), resObj.getStartTime(), CMMConstants.Framework.Entity.RESERVATION_STATUS_APPROVED, resObj.getId());
						for (ReservationTO res : approvedConflictList) {
							String query2 = "select r from ReservationTO as r where r.environments.id =?  and ((r.startTime <= ? and r.endTime >= ? and r.endTime <= ?) or (r.endTime >= ? and r.startTime >= ? and r.startTime <= ?) or (r.startTime <= ? and r.endTime >= ?) or (r.startTime >= ? and r.startTime <= ? and r.endTime >= ? and r.endTime <= ?)) and (r.startTime != ? and r.endTime != ?) and r.id !=? and r.isconflicting=1";
							List<ReservationTO> reservation2 = (List<ReservationTO>) getHibernateTemplate().find(query2, res.getEnvironments().getId(), res.getStartTime(), res.getStartTime(), res.getEndTime(), res.getEndTime(), res.getStartTime(), res.getEndTime(), res.getStartTime(), res.getEndTime(), res.getStartTime(), res.getEndTime(), res.getStartTime(), res.getEndTime(), res.getEndTime(), res.getStartTime(), resObj.getId());
							Long countSharedPending = 0L;
							Long countDisruptivePending = 0L;
							for (ReservationTO reservationToObj : reservation2) {
								if ("S".equalsIgnoreCase(reservationToObj.getDisruptive()) && (reservationToObj.getStatus().getId() == 84L)) {
									countSharedPending++;
								}
								if (!"S".equalsIgnoreCase(reservationToObj.getDisruptive()) && (reservationToObj.getStatus().getId() == 84L)) {
									countDisruptivePending++;
								}
							}
							if ("S".equalsIgnoreCase(res.getDisruptive())) {
								if (countDisruptivePending > 0) {} else {
									res.setIsconflicting(0L);
									getHibernateTemplate().update(res);
								}
							}
							if (!"S".equalsIgnoreCase(res.getDisruptive())) {
								if ((countSharedPending > 0) || (countDisruptivePending > 0)) {} else {
									res.setIsconflicting(0L);
									getHibernateTemplate().update(res);
								}
							}
						}
					}
				}
				if (((resObj.getStatus().getId() == 81L) && "D".equalsIgnoreCase(resObj.getDisruptive())) || ((resObj.getStatus().getId() == 81L) && "L".equalsIgnoreCase(resObj.getDisruptive()))) {
					if (resObj.getIsconflicting() == 0) {
						status.setId(statusValue);
						resObj.setStatus(status);
						resObj.setCancelUserId(reservationTO.getCancelUserId());
						resObj.setComments(reservationTO.getComments());
						getHibernateTemplate().update(resObj);
						if (resObj.getParentId() == null) {
							if (statusValue == 82L) {
								sqlQuery.executeUpdate();
								sqlQueryUpdate.executeUpdate();
							}
						}
					} else {
						status.setId(statusValue);
						resObj.setStatus(status);
						resObj.setCancelUserId(reservationTO.getCancelUserId());
						resObj.setComments(reservationTO.getComments());
						resObj.setIsconflicting(0L);
						getHibernateTemplate().update(resObj);
						if (resObj.getParentId() == null) {
							if (statusValue == 82L) {
								sqlQuery.executeUpdate();
								sqlQueryUpdate.executeUpdate();
							}
						}
						String query1 = "select r from ReservationTO as r where r.environments.id =?  and ((r.startTime <= ? and r.endTime >= ? and r.endTime <= ?) or (r.endTime >= ? and r.startTime >= ? and r.startTime <= ?) or (r.startTime <= ? and r.endTime >= ?) or (r.startTime >= ? and r.startTime <= ? and r.endTime >= ? and r.endTime <= ?)) and (r.startTime != ? and r.endTime != ?) and r.status.id=? and r.id !=? and r.isconflicting=1 ";
						List<ReservationTO> pendingConflictingList = (List<ReservationTO>) getHibernateTemplate().find(query1, resObj.getEnvironments().getId(), resObj.getStartTime(), resObj.getStartTime(), resObj.getEndTime(), resObj.getEndTime(), resObj.getStartTime(), resObj.getEndTime(), resObj.getStartTime(), resObj.getEndTime(), resObj.getStartTime(), resObj.getEndTime(), resObj.getStartTime(), resObj.getEndTime(), resObj.getEndTime(), resObj.getStartTime(), CMMConstants.Framework.Entity.RESERVATION_STATUS_PENDING, resObj.getId());
						for (ReservationTO res : pendingConflictingList) {
							String query2 = "select r from ReservationTO as r where r.environments.id =?  and ((r.startTime <= ? and r.endTime >= ? and r.endTime <= ?) or (r.endTime >= ? and r.startTime >= ? and r.startTime <= ?) or (r.startTime <= ? and r.endTime >= ?) or (r.startTime >= ? and r.startTime <= ? and r.endTime >= ? and r.endTime <= ?)) and (r.startTime != ? and r.endTime != ?) and r.status.id=? and id !=? and r.isconflicting=1 ";
							List<ReservationTO> approvedConflictList = (List<ReservationTO>) getHibernateTemplate().find(query2, res.getEnvironments().getId(), res.getStartTime(), res.getStartTime(), res.getEndTime(), res.getEndTime(), res.getStartTime(), res.getEndTime(), res.getStartTime(), res.getEndTime(), res.getStartTime(), res.getEndTime(), res.getStartTime(), res.getEndTime(), res.getEndTime(), res.getStartTime(), CMMConstants.Framework.Entity.RESERVATION_STATUS_APPROVED, resObj.getId());
							Long countSharedApproved = 0L;
							Long countDisruptiveApproved = 0L;
							List<ReservationTO> sharedApprovedList = new ArrayList<ReservationTO>(0);
							List<ReservationTO> disruptiveApprovedList = new ArrayList<ReservationTO>(0);
							for (ReservationTO reservationToObj : approvedConflictList) {
								if ("S".equalsIgnoreCase(reservationToObj.getDisruptive()) && (reservationToObj.getStatus().getId() == 81L)) {
									sharedApprovedList.add(reservationToObj);
									countSharedApproved++;
								}
								if (!"S".equalsIgnoreCase(reservationToObj.getDisruptive()) && (reservationToObj.getStatus().getId() == 81L)) {
									disruptiveApprovedList.add(reservationToObj);
									countDisruptiveApproved++;
								}
							}
							if ("S".equalsIgnoreCase(res.getDisruptive())) {
								if (countDisruptiveApproved > 0) {} else {
									res.setIsconflicting(0L);
									getHibernateTemplate().update(res);
								}
							}
							if (!"S".equalsIgnoreCase(res.getDisruptive())) {
								if ((countDisruptiveApproved > 0) || (countSharedApproved > 0)) {} else {
									res.setIsconflicting(0L);
									getHibernateTemplate().update(res);
								}
							}
						}
					}
				}
			}
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : deleteReservations", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : deleteReservations.", he);
		}
	}
	
	@Override
	public boolean makereservation(ReservationTO reservation) throws CMMException {
	
		Session session = null;
		boolean flag = false;
		java.sql.CallableStatement cs = null;
		try {
			Long conf = isConflicting(reservation);
			if (conf != 0) {
				ReservationTO reser = (ReservationTO) getHibernateTemplate().find("from ReservationTO where id=?", conf).get(0);
				if ("S".equalsIgnoreCase(reservation.getDisruptive()) && "S".equalsIgnoreCase(reser.getDisruptive())) {
					reser.setIsconflicting(0L);
				} else {
					reser.setIsconflicting(1L);
				}
				getHibernateTemplate().update(reser);
				flag = true;
			}
			UserTO user = (UserTO) getHibernateTemplate().find("from UserTO where id=?", reservation.getUserId()).get(0);
			Set<ReservationTO> set1 = new HashSet<ReservationTO>(0);
			set1.add(reservation);
			user.setReservationses(set1);
			ApplicationTO application = (ApplicationTO) getHibernateTemplate().find("from ApplicationTO where id=?", reservation.getApplicationId()).get(0);
			EnvironmentTO parent = (EnvironmentTO) getHibernateTemplate().find("from EnvironmentTO where id=?", reservation.getEnvironmentId()).get(0);
			StatusTO status = (StatusTO) getHibernateTemplate().find("from StatusTO where id=?", reservation.getStatus().getId()).get(0);
			reservation.setStatus(status);
			reservation.setUsers(user);
			reservation.setApplications(application);
			reservation.setEnvironments(parent);
			getHibernateTemplate().save(reservation);
			try {
				if (reservation.getChildFlow() != 1L) {
					if (reservation.getStatus().getId() == 84L) {
						String[] parameters = new String[5];
						parameters[0] = "environment_id";
						parameters[1] = "workflow_id";
						parameters[2] = "user_id";
						parameters[3] = "reservation_id";
						parameters[4] = "success";
						Object[] values = new Object[5];
						values[0] = reservation.getEnvironmentId();
						values[1] = 3L;
						values[2] = reservation.getUserId();
						values[3] = reservation.getId();
						values[4] = (boolean) false;
						Connection conn = null;
						session = getSession();
						SessionFactoryImplementor sfi = (SessionFactoryImplementor) session.getSessionFactory();
						org.hibernate.connection.ConnectionProvider cp = sfi.getConnectionProvider();
						conn = cp.getConnection();
						cs = conn.prepareCall("{call initiate_workflow_reservation(?,?,?,?,?)}");
						cs.setLong(1, reservation.getEnvironmentId());
						cs.setLong(2, 3L);
						cs.setLong(3, reservation.getUserId());
						cs.setLong(4, reservation.getId());
						cs.registerOutParameter(5, java.sql.Types.INTEGER);
						cs.execute();
						int success = cs.getInt(5);
						if (success == 0) {
							throw new CMMException("Reservation request created but the workflow for approval cannot be generated.Please contact the administrator.");
						}
						if (success == -2) {
							throw new CMMException("Reservation request can not be created because none of the owner are active");
						}
						if (cs != null) {
							cs.close();
						}
						if (conn != null) {
							conn.close();
						}
						if (cp != null) {
							cp.close();
						}
						if (sfi != null) {
							sfi.close();
						}
					}
				}
			} finally {
				if (cs != null) {
					cs.close();
				}
			}
			return flag;
		} catch (DataIntegrityViolationException div) {
			LOG.error(div);
			throw new CMMException("Problem encountered. ReservationDAOImpl : makereservation", div);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : makereservation", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : makereservation", he);
		} catch (IllegalStateException e) {
			LOG.error(e);
			throw new CMMException("Problem encountered. ReservationDAOImpl : makereservation", e);
		} catch (SQLException e) {
			LOG.error(e);
			throw new CMMException("Problem encountered. ReservationDAOImpl : makereservation", e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public Long getActiveReservationCount(Long clientId, List<Long> clientIdlist, ReservationTO reservationTO) throws CMMException {
	
		Query q = null;
		Session session = null;
		try {
			session = getSession();
			Date currentDate = DateUtils.getStartTime(new Date());
			Date searchDate = DateUtils.addDays(currentDate, 1);
			String hql = "SELECT r.id FROM ReservationTO r ";
			hql = hql + " where r.status.id  in( :statusId)";
			hql = hql + " and r.startTime < :startDate ";
			hql = hql + " and  r.endTime >= :endDate ";
			if (reservationTO.getEnvironmentValue() != null) {
				hql = hql + " and r.environments.id in (" + reservationTO.getEnvironmentValue() + ")";
			}
			if (!((reservationTO.getUserId() == 1) || (reservationTO.getUsers().getRoleId() == 1))) {
				hql = hql + " and r.userId in (" + reservationTO.getUserId() + ")";
			}
			if (reservationTO.getApplicationValue() != null) {
				hql = hql + "  and r.applications.id in (" + reservationTO.getApplicationValue() + ")";
			}
			if (!(clientId == 0)) {
				hql = hql + " and r.applications.id in (select a.id from ApplicationTO a where a.businessUnitTO.id in(:clientid)) ";
			}
			q = session.createQuery(hql);
			q.setParameter("statusId", Entity.RESERVATION_STATUS_APPROVED);
			q.setParameter("startDate", searchDate);
			q.setParameter("endDate", currentDate);
			if (!(clientId == 0)) {
				q.setParameterList("clientid", clientIdlist);
			}
			return (long) q.list().size();
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getActiveReservationCount", dae);
		} catch (Exception he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getActiveReservationCount", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<ReservationTO> getActiveReservations(UserTO userTo, List<Long> clientIdlist) throws CMMException {
	
		DetachedCriteria criteria = DetachedCriteria.forClass(ReservationTO.class, "reservation");
		try {
			if (userTo.getClientId() != 0) {
				if (userTo.getRoleId() != 1) {
					criteria.add(Restrictions.eq("reservation.users.id", userTo.getId()));
				} else {
					DetachedCriteria criteria1 = DetachedCriteria.forClass(UserBusinessUnitTO.class, "userbusinessUnit");
					criteria1.add(Restrictions.in("clientId", clientIdlist));
					List<UserBusinessUnitTO> userbuList = (List<UserBusinessUnitTO>) getHibernateTemplate().findByCriteria(criteria1);
					List<Long> userIdList = new ArrayList<Long>();
					for (UserBusinessUnitTO u : userbuList) {
						userIdList.add(u.getUser().getId());
					}
					DetachedCriteria criteria2 = DetachedCriteria.forClass(ApplicationTO.class, "application");
					criteria2.add(Restrictions.in("application.businessUnitTO.id", clientIdlist));
					List<ApplicationTO> applicationList = (List<ApplicationTO>) getHibernateTemplate().findByCriteria(criteria2);
					List<Long> appList = new ArrayList<Long>();
					for (ApplicationTO u : applicationList) {
						appList.add(u.getId());
					}
					criteria.add(Restrictions.in("reservation.users.id", userIdList));
					criteria.add(Restrictions.in("reservation.applications.id", appList));
				}
			}
			Date currentDate = DateUtils.getStartTime(new Date());
			Date searchDate = DateUtils.addDays(currentDate, 1);
			DateUtils.addDays(searchDate, 1);
			criteria.add(Restrictions.eq("status.id", Entity.RESERVATION_STATUS_APPROVED));
			criteria.add(Restrictions.conjunction().add(Property.forName("startTime").lt(searchDate)).add(Property.forName("endTime").ge(currentDate)));
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getActiveReservations", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getActiveReservations", he);
		}
		List<ReservationTO> activeList = (List<ReservationTO>) getHibernateTemplate().findByCriteria(criteria);
		for (ReservationTO r : activeList) {
			if (r.getReleasePlan() != null) {
				String releaseName = (String) getHibernateTemplate().find("select name from ReleasePlanningTO where id=?", r.getReleasePlan()).get(0);
				r.setReleasePlanName(releaseName);
			} else {
				r.setReleasePlanName("NA");
			}
			if (r.getTestingPhase() != null) {
				String phaseName = (String) getHibernateTemplate().find("select name from TestingPhaseTO where id=?", r.getTestingPhase()).get(0);
				r.setTestingPhaseName(phaseName);
			} else {
				r.setTestingPhaseName("NA");
			}
		}
		return activeList;
	}
	
	/**
	 * This function is called on the page load to get the count of expired reservations
	 *
	 * @param userId
	 * @return
	 * @throws CMMException
	 */
	@Override
	public Long getExpiredReservationCount(Long clientId, List<Long> clientIdlist, ReservationTO reservationTO) throws CMMException {
	
		Query q = null;
		Session session = null;
		try {
			session = getSession();
			Date currentDate = DateUtils.getStartTime(new Date());
			DateUtils.addDays(currentDate, 1);
			String hql = "SELECT r.id FROM ReservationTO r ";
			hql = hql + " where r.status.id = :statusId";
			hql = hql + " and  r.endTime < :startDate ";
			if (reservationTO.getEnvironmentValue() != null) {
				hql = hql + " and r.environments.id in (" + reservationTO.getEnvironmentValue() + ")";
			}
			if (!((reservationTO.getUserId() == 1) || (reservationTO.getUsers().getRoleId() == 1))) {
				hql = hql + " and r.userId in (" + reservationTO.getUserId() + ")";
			}
			if (reservationTO.getApplicationValue() != null) {
				hql = hql + " and r.applications.id in (" + reservationTO.getApplicationValue() + ")";
			}
			if (!(clientId == 0)) {
				hql = hql + " and r.applications.id in (select a.id from ApplicationTO a where a.businessUnitTO.id in(:clientid)) ";
			}
			q = session.createQuery(hql);
			q.setParameter("statusId", Entity.RESERVATION_STATUS_APPROVED);
			q.setParameter("startDate", currentDate);
			if (!(clientId == 0)) {
				q.setParameterList("clientid", clientIdlist);
			}
			return (long) q.list().size();
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getExpiredReservationCount", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getExpiredReservationCount", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<ReservationTO> getExpiredReservations(UserTO userTo, List<Long> clientIdlist) throws CMMException {
	
		DetachedCriteria criteria = DetachedCriteria.forClass(ReservationTO.class, "reservation");
		try {
			if (userTo.getClientId() != 0) {
				if (userTo.getRoleId() != 1) {
					criteria.add(Restrictions.eq("reservation.users.id", userTo.getId()));
				} else {
					DetachedCriteria criteria1 = DetachedCriteria.forClass(UserBusinessUnitTO.class, "userbusinessUnit");
					criteria1.add(Restrictions.in("clientId", clientIdlist));
					List<UserBusinessUnitTO> userbuList = (List<UserBusinessUnitTO>) getHibernateTemplate().findByCriteria(criteria1);
					List<Long> userIdList = new ArrayList<Long>();
					for (UserBusinessUnitTO u : userbuList) {
						userIdList.add(u.getUser().getId());
					}
					DetachedCriteria criteria2 = DetachedCriteria.forClass(ApplicationTO.class, "application");
					criteria2.add(Restrictions.in("application.businessUnitTO.id", clientIdlist));
					List<ApplicationTO> applicationList = (List<ApplicationTO>) getHibernateTemplate().findByCriteria(criteria2);
					List<Long> appList = new ArrayList<Long>();
					for (ApplicationTO u : applicationList) {
						appList.add(u.getId());
					}
					criteria.add(Restrictions.in("reservation.users.id", userIdList));
					criteria.add(Restrictions.in("reservation.applications.id", appList));
				}
			}
			Date currentDate = DateUtils.getStartTime(new Date());
			criteria.add(Restrictions.lt("endTime", currentDate));
			criteria.add(Restrictions.eq("status.id", Entity.RESERVATION_STATUS_APPROVED));
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getExpiredReservations", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getExpiredReservations", he);
		}
		List<ReservationTO> expiredList = (List<ReservationTO>) getHibernateTemplate().findByCriteria(criteria);
		for (ReservationTO r : expiredList) {
			if (r.getReleasePlan() != null) {
				String releaseName = (String) getHibernateTemplate().find("select name from ReleasePlanningTO where id=?", r.getReleasePlan()).get(0);
				r.setReleasePlanName(releaseName);
			} else {
				r.setReleasePlanName("NA");
			}
			if (r.getTestingPhase() != null) {
				String phaseName = (String) getHibernateTemplate().find("select name from TestingPhaseTO where id=?", r.getTestingPhase()).get(0);
				r.setTestingPhaseName(phaseName);
			} else {
				r.setTestingPhaseName("NA");
			}
		}
		return expiredList;
	}
	
	@Override
	public Long getFutureReservationCount(Long clientId, List<Long> clientIdlist, ReservationTO reservationTO) throws CMMException {
	
		Query q = null;
		Session session = null;
		try {
			session = getSession();
			Date currentDate = DateUtils.getStartTime(new Date());
			Date searchDate = DateUtils.addDays(currentDate, 1);
			String hql = "SELECT r.id FROM ReservationTO r ";
			hql = hql + " where r.status.id = :statusId";
			hql = hql + " and  r.startTime >= :startDate ";
			if (reservationTO.getEnvironmentValue() != null) {
				hql = hql + " and r.environments.id in (" + reservationTO.getEnvironmentValue() + ")";
			}
			if (!((reservationTO.getUserId() == 1) || (reservationTO.getUsers().getRoleId() == 1))) {
				hql = hql + " and r.userId in (" + reservationTO.getUserId() + ")";
			}
			if (reservationTO.getApplicationValue() != null) {
				hql = hql + " and r.applications.id in (" + reservationTO.getApplicationValue() + ")";
			}
			if (!(clientId == 0)) {
				hql = hql + " and r.applications.id in (select a.id from ApplicationTO a where a.businessUnitTO.id in(:clientid)) ";
			}
			q = session.createQuery(hql);
			q.setParameter("statusId", Entity.RESERVATION_STATUS_APPROVED);
			q.setParameter("startDate", searchDate);
			if (!(clientId == 0)) {
				q.setParameterList("clientid", clientIdlist);
			}
			return (long) q.list().size();
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getFutureReservationCount", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getFutureReservationCount", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<ReservationTO> getFutureReservations(UserTO userTo, List<Long> clientIdlist) throws CMMException {
	
		DetachedCriteria criteria = DetachedCriteria.forClass(ReservationTO.class, "reservation");
		try {
			if (userTo.getClientId() != 0) {
				if (userTo.getRoleId() != 1) {
					criteria.add(Restrictions.eq("reservation.users.id", userTo.getId()));
				} else {
					DetachedCriteria criteria1 = DetachedCriteria.forClass(UserBusinessUnitTO.class, "userbusinessUnit");
					criteria1.add(Restrictions.in("clientId", clientIdlist));
					List<UserBusinessUnitTO> userbuList = (List<UserBusinessUnitTO>) getHibernateTemplate().findByCriteria(criteria1);
					List<Long> userIdList = new ArrayList<Long>();
					for (UserBusinessUnitTO u : userbuList) {
						userIdList.add(u.getUser().getId());
					}
					DetachedCriteria criteria2 = DetachedCriteria.forClass(ApplicationTO.class, "application");
					criteria2.add(Restrictions.in("application.businessUnitTO.id", clientIdlist));
					List<ApplicationTO> applicationList = (List<ApplicationTO>) getHibernateTemplate().findByCriteria(criteria2);
					List<Long> appList = new ArrayList<Long>();
					for (ApplicationTO u : applicationList) {
						appList.add(u.getId());
					}
					criteria.add(Restrictions.in("reservation.users.id", userIdList));
					criteria.add(Restrictions.in("reservation.applications.id", appList));
				}
			}
			Date currentDate = DateUtils.getStartTime(new Date());
			Date searchDate = DateUtils.addDays(currentDate, 1);
			criteria.add(Restrictions.ge("startTime", searchDate));
			criteria.add(Restrictions.eq("status.id", Entity.RESERVATION_STATUS_APPROVED));
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getFutureReservations", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getFutureReservations", he);
		}
		List<ReservationTO> futureList = (List<ReservationTO>) getHibernateTemplate().findByCriteria(criteria);
		for (ReservationTO r : futureList) {
			if (r.getReleasePlan() != null) {
				String releaseName = (String) getHibernateTemplate().find("select name from ReleasePlanningTO where id=?", r.getReleasePlan()).get(0);
				r.setReleasePlanName(releaseName);
			} else {
				r.setReleasePlanName("NA");
			}
			if (r.getTestingPhase() != null) {
				String phaseName = (String) getHibernateTemplate().find("select name from TestingPhaseTO where id=?", r.getTestingPhase()).get(0);
				r.setTestingPhaseName(phaseName);
			} else {
				r.setTestingPhaseName("NA");
			}
		}
		return futureList;
	}
	
	@Override
	public List<EnvironmentTO> getReservationSummaryDetails(ReservationTO reservation, Date firstDate, Date lastDate, Long testingPhaseId) throws CMMException {
	
		try {
			if (testingPhaseId == null) {
				if (reservation.getParentId() != null) {
					String hql1 = "SELECT e FROM EnvironmentCalendarTO e, EnvironmentApplicationTO ea where ea.environmentTO.id= e.id and ea.applicationTO.id=? and e.status= 22L";
					List<EnvironmentCalendarTO> environment1 = (List<EnvironmentCalendarTO>) getHibernateTemplate().find(hql1, reservation.getParentId());
					String hql2 = "SELECT e FROM EnvironmentCalendarTO e, EnvironmentApplicationTO ea where ea.environmentTO.id= e.id and ea.applicationTO.id=? and e.status= 21L";
					List<EnvironmentCalendarTO> environment2 = (List<EnvironmentCalendarTO>) getHibernateTemplate().find(hql2, reservation.getParentId());
					String hql3 = "SELECT e FROM EnvironmentCalendarTO e, EnvironmentApplicationTO ea where ea.environmentTO.id= e.id and ea.applicationTO.id=? and e.status NOT IN (22L,21L)";
					List<EnvironmentCalendarTO> environment3 = (List<EnvironmentCalendarTO>) getHibernateTemplate().find(hql3, reservation.getParentId());
					List<EnvironmentCalendarTO> environmentFinal = new ArrayList<EnvironmentCalendarTO>();
					environmentFinal.addAll(environment1);
					environmentFinal.addAll(environment2);
					environmentFinal.addAll(environment3);
					List<EnvironmentTO> environment = new ArrayList<EnvironmentTO>();
					for (EnvironmentCalendarTO environmentCalendarTemp : environmentFinal) {
						EnvironmentTO environmentTemp = new EnvironmentTO();
						environmentTemp.setId(environmentCalendarTemp.getId());
						environmentTemp.setEnvironmentName(environmentCalendarTemp.getEnvironmentName());
						environmentTemp.setStatus(environmentCalendarTemp.getStatus());
						environmentTemp.setReservationses(environmentCalendarTemp.getReservationses());
						environment.add(environmentTemp);
					}
					return environment;
				} else {
					String hql1 = "SELECT e FROM EnvironmentCalendarTO e where e.status=22L";
					List<EnvironmentCalendarTO> environment1 = (List<EnvironmentCalendarTO>) getHibernateTemplate().find(hql1);
					String hql2 = "SELECT e FROM EnvironmentCalendarTO e where e.status = 21L";
					List<EnvironmentCalendarTO> environment2 = (List<EnvironmentCalendarTO>) getHibernateTemplate().find(hql2);
					String hql3 = "SELECT e FROM EnvironmentCalendarTO e where e.status  not in(25L,23L,26L,21L,22L)";
					List<EnvironmentCalendarTO> environment3 = (List<EnvironmentCalendarTO>) getHibernateTemplate().find(hql3);
					List<EnvironmentCalendarTO> environmentFinal = new ArrayList<EnvironmentCalendarTO>();
					environmentFinal.addAll(environment1);
					environmentFinal.addAll(environment2);
					environmentFinal.addAll(environment3);
					List<EnvironmentTO> environment = new ArrayList<EnvironmentTO>();
					for (EnvironmentCalendarTO environmentCalendarTemp : environmentFinal) {
						EnvironmentTO environmentTemp = new EnvironmentTO();
						environmentTemp.setId(environmentCalendarTemp.getId());
						environmentTemp.setEnvironmentName(environmentCalendarTemp.getEnvironmentName());
						environmentTemp.setStatus(environmentCalendarTemp.getStatus());
						environmentTemp.setReservationses(environmentCalendarTemp.getReservationses());
						environment.add(environmentTemp);
					}
					return environment;
				}
			} else if (reservation.getParentId() != null) {
				String hql1 = "SELECT e FROM EnvironmentCalendarTO e, EnvironmentApplicationTO ea where ea.environmentTO.id= e.id and ea.applicationTO.id=? and e.status= 22L and ea.testingPhaseTO.id=?";
				List<EnvironmentCalendarTO> environment1 = (List<EnvironmentCalendarTO>) getHibernateTemplate().find(hql1, reservation.getParentId(), testingPhaseId);
				String hql2 = "SELECT e FROM EnvironmentCalendarTO e, EnvironmentApplicationTO ea where ea.environmentTO.id= e.id and ea.applicationTO.id=? and e.status= 21L and ea.testingPhaseTO.id=?";
				List<EnvironmentCalendarTO> environment2 = (List<EnvironmentCalendarTO>) getHibernateTemplate().find(hql2, reservation.getParentId(), testingPhaseId);
				String hql3 = "SELECT e FROM EnvironmentCalendarTO e, EnvironmentApplicationTO ea where ea.environmentTO.id= e.id and ea.applicationTO.id=? and e.status NOT IN (22L,21L) and ea.testingPhaseTO.id=?";
				List<EnvironmentCalendarTO> environment3 = (List<EnvironmentCalendarTO>) getHibernateTemplate().find(hql3, reservation.getParentId(), testingPhaseId);
				List<EnvironmentCalendarTO> environmentFinal = new ArrayList<EnvironmentCalendarTO>();
				environmentFinal.addAll(environment1);
				environmentFinal.addAll(environment2);
				environmentFinal.addAll(environment3);
				List<EnvironmentTO> environment = new ArrayList<EnvironmentTO>();
				for (EnvironmentCalendarTO environmentCalendarTemp : environmentFinal) {
					EnvironmentTO environmentTemp = new EnvironmentTO();
					environmentTemp.setId(environmentCalendarTemp.getId());
					environmentTemp.setEnvironmentName(environmentCalendarTemp.getEnvironmentName());
					environmentTemp.setStatus(environmentCalendarTemp.getStatus());
					environmentTemp.setReservationses(environmentCalendarTemp.getReservationses());
					environment.add(environmentTemp);
				}
				return environment;
			} else {
				String hql1 = "SELECT e FROM EnvironmentCalendarTO e where e.status=22L";
				List<EnvironmentCalendarTO> environment1 = (List<EnvironmentCalendarTO>) getHibernateTemplate().find(hql1);
				String hql2 = "SELECT e FROM EnvironmentCalendarTO e where e.status = 21L";
				List<EnvironmentCalendarTO> environment2 = (List<EnvironmentCalendarTO>) getHibernateTemplate().find(hql2);
				String hql3 = "SELECT e FROM EnvironmentCalendarTO e where e.status  not in(25L,23L,26L,21L,22L)";
				List<EnvironmentCalendarTO> environment3 = (List<EnvironmentCalendarTO>) getHibernateTemplate().find(hql3);
				List<EnvironmentCalendarTO> environmentFinal = new ArrayList<EnvironmentCalendarTO>();
				environmentFinal.addAll(environment1);
				environmentFinal.addAll(environment2);
				environmentFinal.addAll(environment3);
				List<EnvironmentTO> environment = new ArrayList<EnvironmentTO>();
				for (EnvironmentCalendarTO environmentCalendarTemp : environmentFinal) {
					EnvironmentTO environmentTemp = new EnvironmentTO();
					environmentTemp.setId(environmentCalendarTemp.getId());
					environmentTemp.setEnvironmentName(environmentCalendarTemp.getEnvironmentName());
					environmentTemp.setStatus(environmentCalendarTemp.getStatus());
					environmentTemp.setReservationses(environmentCalendarTemp.getReservationses());
					environment.add(environmentTemp);
				}
				return environment;
			}
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getReservationSummaryDetails", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getReservationSummaryDetails", he);
		} catch (Exception e) {
			LOG.error(e);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getReservationSummaryDetails", e);
		}
	}
	
	@Override
	public List<ReservationTO> getHourlyReservationSummaryDetails(Long environmentId, Date selectedDate, Date selectedDateLast) throws CMMException {
	
		LOG.info("Inside getReservationsForEnvironment of ReservationDaoImpl");
		try {
			String query = "select r from ReservationTO as r where r.environments.id = ? and r.startTime < ? and r.endTime > ?";
			List<ReservationTO> obj = (List<ReservationTO>) getHibernateTemplate().find(query, environmentId, selectedDateLast, selectedDate);
			List<ReservationTO> reservationHourly = new ArrayList<ReservationTO>();
			for (ReservationTO res : obj) {
				reservationHourly.add(res);
			}
			return reservationHourly;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.", he);
		}
	}
	
	/* app view change */
	@Override
	public List<ReservationTO> getHourlyReservationSummaryDetailsApp(Long applicationId, Date selectedDate, Date selectedDateLast) throws CMMException {
	
		logger.info("Inside getReservationsForApplication of ReservationDaoImpl");
		try {
			String query = "select r from ReservationTO as r where r.applications.id = ? and r.startTime < ? and r.endTime > ?";
			List<ReservationTO> obj = (List<ReservationTO>) getHibernateTemplate().find(query, applicationId, selectedDateLast, selectedDate);
			List<ReservationTO> reservationHourly = new ArrayList<ReservationTO>();
			for (ReservationTO res : obj) {
				reservationHourly.add(res);
			}
			return reservationHourly;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.", he);
		}
	}
	
	/* app view change end */
	@Override
	public List<EnvironmentTO> getReservationsSummaryForUser(Long userId, Long clientId) throws CMMException {
	
		Date currentDate = DateUtils.getStartTime(new Date());
		DetachedCriteria criteria = DetachedCriteria.forClass(EnvironmentTO.class);
		try {
			criteria.createAlias("reservationses", "res", CriteriaSpecification.LEFT_JOIN);
			criteria.createAlias("res.users", "auth", CriteriaSpecification.INNER_JOIN);
			if (clientId != 0L) {
				criteria.add(Restrictions.eq("auth.id", userId));
			}
			criteria.add(Restrictions.disjunction().add(Property.forName("res.status.id").eq(Entity.RESERVATION_STATUS_APPROVED)).add(Property.forName("res.status.id").eq(Entity.RESERVATION_STATUS_PENDING)));
			criteria.add(Restrictions.disjunction().add(Property.forName("res.startTime").gt(currentDate)).add(Restrictions.conjunction().add(Property.forName("res.startTime").ge(currentDate)).add(Property.forName("res.endTime").ge(currentDate))).add(Restrictions.conjunction().add(Property.forName("res.startTime").le(currentDate)).add(Property.forName("res.endTime").ge(currentDate))));
			criteria.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getReservationsSummaryForUser", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getReservationsSummaryForUser", he);
		}
		return (List<EnvironmentTO>) getHibernateTemplate().findByCriteria(criteria);
	}
	
	@Override
	public boolean checkReservationAvailability(ReservationTO reservationTO) throws CMMException {
	
		boolean checkAvailability = false;
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(ReservationTO.class, "res");
			criteria.add(Restrictions.eq("res.environments.id", reservationTO.getEnvironmentId()));
			criteria.add(Restrictions.ne("res.status.id", Entity.RESERVATION_STATUS_INACTIVE));
			criteria.add(Restrictions.disjunction().add(Restrictions.conjunction().add(Property.forName("res.startTime").ge(reservationTO.getStartTime())).add(Property.forName("res.endTime").le(reservationTO.getStartTime()))).add(Restrictions.conjunction().add(Property.forName("res.startTime").le(reservationTO.getEndTime())).add(Property.forName("res.endTime").ge(reservationTO.getEndTime()))).add(Restrictions.conjunction().add(Property.forName("res.startTime").ge(reservationTO.getStartTime())).add(Property.forName("res.endTime").le(reservationTO.getEndTime()))));
			List<ReservationTO> reservation = (List<ReservationTO>) getHibernateTemplate().findByCriteria(criteria);
			if (reservation.isEmpty()) {
				checkAvailability = true;
			}
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : checkReservationAvailability", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : checkReservationAvailability", he);
		}
		return checkAvailability;
	}
	
	@Override
	public ReservationTO reservationDetail(Long resId) throws CMMException {
	
		try {
			return (ReservationTO) getHibernateTemplate().find("from ReservationTO where id=?", resId).get(0);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : reservationDetail", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : reservationDetail", he);
		}
	}
	
	@Override
	public String getStatusDesc(Long id) throws CMMException {
	
		try {
			StatusTO st = (StatusTO) getHibernateTemplate().find("from StatusTO s where s.id=?", id).get(0);
			return st.getStatusDesc();
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getStatusDesc", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getStatusDesc", he);
		}
	}
	
	@Override
	public List<EnvironmentTO> getAllReservationSummaryDetails(List<Long> appIdList, List<Long> clientId, List<Long> projectId, Date firstDate, Date lastDate, Long testingPhaseId) throws CMMException {
	
		Session session = null;
		List<EnvironmentCalendarTO> environmentFinal = null;
		try {
			if ((testingPhaseId == null) || (testingPhaseId == -1L)) {
				Transaction tx = null;
				session = getSession();
				tx = session.beginTransaction();
				String hql = "SELECT e FROM EnvironmentCalendarTO e, ApplicationTO a , ProjectsTO p , BusinessUnitTO b, EnvironmentApplicationTO ea,ServiceRequestTO r where ea.environmentTO.id= e.id and ea.applicationTO.id=a.id and  p.clientId = b.clientId  and  a.projectTO.id = p.id and e.status  not in(25L,23L,26L) and r.environmentId=e.id and ((r.startTime <=(:startTime)  and r.endTime >= (:startTime) and r.endTime <= (:endTime)) or (r.endTime >= (:endTime) and r.startTime >= (:startTime) and r.startTime <= (:endTime)) or (r.startTime <= (:startTime) and r.endTime >= (:endTime)) or (r.startTime >=(:startTime) and r.startTime <= (:endTime) and r.endTime >= (:startTime) and r.endTime <= (:endTime)))";
				if (!projectId.isEmpty()) {
					hql = hql + " and p.id in (:pId) ";
				}
				if (!clientId.isEmpty()) {
					hql = hql + " and b.clientId in (:buId) ";
				}
				if (!appIdList.isEmpty()) {
					hql = hql + "  and a.id in (:appId) ";
				}
				Query q = session.createQuery(hql);
				if (!projectId.isEmpty()) {
					q.setParameterList("pId", projectId);
				}
				if (!clientId.isEmpty()) {
					q.setParameterList("buId", clientId);
				}
				if (!appIdList.isEmpty()) {
					q.setParameterList("appId", appIdList);
				}
				q.setParameter("startTime", firstDate);
				q.setParameter("endTime", lastDate);
				environmentFinal = q.list();
				tx.commit();
			} else {
				Transaction tx = null;
				session = getSession();
				tx = session.beginTransaction();
				String hql = "SELECT e FROM EnvironmentCalendarTO e, ApplicationTO a , ProjectsTO p , BusinessUnitTO b, EnvironmentApplicationTO ea,ServiceRequestTO r where ea.environmentTO.id= e.id and ea.applicationTO.id=a.id and  p.clientId = b.clientId  and  a.projectTO.id = p.id and e.status  not in(25L,23L,26L) and r.environmentId=e.id and ((r.startTime <=(:startTime)  and r.endTime >= (:startTime) and r.endTime <= (:endTime)) or (r.endTime >= (:endTime) and r.startTime >= (:startTime) and r.startTime <= (:endTime)) or (r.startTime <= (:startTime) and r.endTime >= (:endTime)) or (r.startTime >=(:startTime) and r.startTime <= (:endTime) and r.endTime >= (:startTime) and r.endTime <= (:endTime)))";
				if (!projectId.isEmpty()) {
					hql = hql + " and p.id in (:pId) ";
				}
				if (!clientId.isEmpty()) {
					hql = hql + " and b.clientId in (:buId) ";
				}
				if (!appIdList.isEmpty()) {
					hql = hql + "  and a.id in (:appId) ";
				}
				hql = hql + " and ea.testingPhaseTO.id = :phaseId ";
				Query q = session.createQuery(hql);
				q.setLong("phaseId", testingPhaseId);
				if (!projectId.isEmpty()) {
					q.setParameterList("pId", projectId);
				}
				if (!clientId.isEmpty()) {
					q.setParameterList("buId", clientId);
				}
				if (!appIdList.isEmpty()) {
					q.setParameterList("appId", appIdList);
				}
				q.setParameter("startTime", firstDate);
				q.setParameter("endTime", lastDate);
				environmentFinal = q.list();
				tx.commit();
			}
			List<EnvironmentTO> environment = new ArrayList<EnvironmentTO>();
			for (EnvironmentCalendarTO environmentCalendarTemp : environmentFinal) {
				EnvironmentTO environmentTemp = new EnvironmentTO();
				environmentTemp.setId(environmentCalendarTemp.getId());
				environmentTemp.setEnvironmentName(environmentCalendarTemp.getEnvironmentName());
				environmentTemp.setStatus(environmentCalendarTemp.getStatus());
				environmentTemp.setReservationses(environmentCalendarTemp.getReservationses());
				environment.add(environmentTemp);
			}
			return environment;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getAllReservationSummaryDetails", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getAllReservationSummaryDetails", he);
		} catch (Exception e) {
			LOG.error(e);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getAllReservationSummaryDetails", e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	/* app view start */
	@Override
	public List<ApplicationTO> getAllReservationSummaryDetailsApp(List<Long> envIdList, List<Long> appIdList1, List<Long> clientId, List<Long> projectId, Date firstDate, Date lastDate, Long testingPhaseId, List<UserGroupTO> userGroupIds, Long userClientId) throws CMMException {
	
		Session session = null;
		List<ApplicationCalendarTO> applicationFinal = new ArrayList<ApplicationCalendarTO>();
		List<Long> grpIds = new ArrayList<Long>();
		try {
			if (userClientId == 0L) {
				if (testingPhaseId == null) {
					Transaction tx = null;
					session = getSession();
					tx = session.beginTransaction();
					String hql = "select a FROM ApplicationCalendarTO a where a.id in (select a.id from ApplicationCalendarTO a , EnvironmentApplicationTO ea   where  a.businessUnitTO.id in (:clientId)  and a.projectTO.id in(:projectId) and a.status=:status and ea.environmentTO.id in(:envId) and  ea.applicationTO.id = a.id)";
					if (!appIdList1.isEmpty()) {
						hql = hql + " and a.id in (:appId) ";
					}
					Query q = session.createQuery(hql);
					q.setParameterList("projectId", projectId);
					q.setParameterList("clientId", clientId);
					q.setParameter("status", CMMConstants.Framework.Entity.APPLICATION_AVAILABLE);
					if (!envIdList.isEmpty()) {
						q.setParameterList("envId", envIdList);
					}
					if (!appIdList1.isEmpty()) {
						q.setParameterList("appId", appIdList1);
					}
					applicationFinal = q.list();
					tx.commit();
				} else {
					Transaction tx = null;
					session = getSession();
					tx = session.beginTransaction();
					String hql = "select a FROM ApplicationCalendarTO a where a.id in (select ea.applicationTO.id from EnvironmentCalendarTO e , ApplicationCalendarTO a, EnvironmentApplicationTO ea   where  a.businessUnitTO.id in (:clientId)  and a.projectTO.id in(:projectId) and a.status=:status and ea.environmentTO.id in(:envId) and  ea.applicationTO.id = a.id and ea.environmentTO.id=e.id and ea.testingPhaseTO.id in (:phaseId))";
					if (!appIdList1.isEmpty()) {
						hql = hql + " and a.id in (:appId) ";
					}
					Query q = session.createQuery(hql);
					q.setParameterList("projectId", projectId);
					q.setParameterList("clientId", clientId);
					q.setLong("phaseId", testingPhaseId);
					q.setParameter("status", CMMConstants.Framework.Entity.APPLICATION_AVAILABLE);
					if (!envIdList.isEmpty()) {
						q.setParameterList("envId", envIdList);
					}
					if (!appIdList1.isEmpty()) {
						q.setParameterList("appId", appIdList1);
					}
					applicationFinal = q.list();
					tx.commit();
				}
			} else {
				for (UserGroupTO groupTO : userGroupIds) {
					grpIds.add(groupTO.getId());
				}
				if (grpIds.isEmpty()) {
					grpIds.add(-1L);
				}
				if (testingPhaseId == null) {
					Transaction tx = null;
					session = getSession();
					tx = session.beginTransaction();
					String hql = "select a FROM ApplicationCalendarTO a inner join a.userGroups u where u.id in (:grpId) and a.id in (select a.id from ApplicationCalendarTO a , EnvironmentApplicationTO ea   where  a.businessUnitTO.id in (:clientId)  and a.projectTO.id in(:projectId) and a.status=:status and ea.environmentTO.id in(:envId) and  ea.applicationTO.id = a.id)";
					if (!appIdList1.isEmpty()) {
						hql = hql + " and a.id in (:appId) ";
					}
					Query q = session.createQuery(hql);
					q.setParameterList("projectId", projectId);
					q.setParameterList("grpId", grpIds);
					q.setParameterList("clientId", clientId);
					q.setParameter("status", CMMConstants.Framework.Entity.APPLICATION_AVAILABLE);
					if (!envIdList.isEmpty()) {
						q.setParameterList("envId", envIdList);
					}
					if (!appIdList1.isEmpty()) {
						q.setParameterList("appId", appIdList1);
					}
					applicationFinal = q.list();
					tx.commit();
				} else {
					Transaction tx = null;
					session = getSession();
					tx = session.beginTransaction();
					String hql = "select a FROM ApplicationCalendarTO a inner join a.userGroups u where u.id in (:grpId) and a.id in (select ea.applicationTO.id from EnvironmentCalendarTO e , ApplicationCalendarTO a, EnvironmentApplicationTO ea   where  a.businessUnitTO.id in (:clientId)  and a.projectTO.id in(:projectId) and a.status=:status and ea.environmentTO.id in(:envId) and  ea.applicationTO.id = a.id and ea.environmentTO.id=e.id and ea.testingPhaseTO.id in (:phaseId))";
					if (!appIdList1.isEmpty()) {
						hql = hql + " and a.id in (:appId) ";
					}
					Query q = session.createQuery(hql);
					q.setParameterList("projectId", projectId);
					q.setParameterList("grpId", grpIds);
					q.setParameterList("clientId", clientId);
					q.setLong("phaseId", testingPhaseId);
					q.setParameter("status", CMMConstants.Framework.Entity.APPLICATION_AVAILABLE);
					if (!envIdList.isEmpty()) {
						q.setParameterList("envId", envIdList);
					}
					if (!appIdList1.isEmpty()) {
						q.setParameterList("appId", appIdList1);
					}
					applicationFinal = q.list();
					tx.commit();
				}
			}
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getAllReservationSummaryDetails_App", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getAllReservationSummaryDetails_App", he);
		} catch (Exception e) {
			LOG.error(e);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getAllReservationSummaryDetails_App", e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		List<ApplicationTO> application = new ArrayList<ApplicationTO>();
		for (ApplicationCalendarTO ApplicationCalendarTemp : applicationFinal) {
			ApplicationTO applicationTemp = new ApplicationTO();
			applicationTemp.setId(ApplicationCalendarTemp.getId());
			applicationTemp.setAppName(ApplicationCalendarTemp.getAppName());
			applicationTemp.setStatus(ApplicationCalendarTemp.getStatus());
			applicationTemp.setReservationses(ApplicationCalendarTemp.getReservationses());
			application.add(applicationTemp);
		}
		return application;
	}
	
	/* app view end */
	@Override
	public List<Object[]> getActiveReservationCountOfAllUsers() throws CMMException {
	
		StringBuilder query = new StringBuilder("SELECT count(*) FROM ReservationTO r ");
		query.append("where (r.startTime<=current_date and r.endTime>=current_date) ");
		query.append("and status.id<>" + Entity.RESERVATION_STATUS_INACTIVE);
		try {
			return (List<Object[]>) getHibernateTemplate().find(query.toString());
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getActiveReservationCountOfAllUsers", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getActiveReservationCountOfAllUsers", he);
		}
	}
	
	@Override
	public List<Object[]> getExpiredReservationCountOfAllUsers() throws CMMException {
	
		StringBuilder query = new StringBuilder("SELECT count(*) FROM ReservationTO r ");
		query.append("where r.endTime<current_date  and status.id<>" + Entity.RESERVATION_STATUS_INACTIVE);
		try {
			return (List<Object[]>) getHibernateTemplate().find(query.toString());
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getExpiredReservationCountOfAllUsers", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getExpiredReservationCountOfAllUsers", he);
		}
	}
	
	@Override
	public List<Object[]> getFutureReservationCountOfAllUsers() throws CMMException {
	
		Date currentDate = DateUtils.getStartTime(new Date());
		Date searchDate = DateUtils.addDays(currentDate, 1);
		StringBuilder query = new StringBuilder("SELECT count(*) FROM ReservationTO r ");
		query.append("where r.startTime>?  and status.id<>" + Entity.RESERVATION_STATUS_INACTIVE);
		try {
			return (List<Object[]>) getHibernateTemplate().find(query.toString(), searchDate);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getFutureReservationCountOfAllUsers", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getFutureReservationCountOfAllUsers", he);
		}
	}
	
	@Override
	public List<Object[]> getAvailableCountForAllHardware() throws CMMException {
	
		StringBuilder query = new StringBuilder("SELECT h.id,h.name,count(*) FROM HardwareTO h ");
		query.append("where h.status=? group by h.status");
		try {
			return (List<Object[]>) getHibernateTemplate().find(query.toString(), 71L);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getAvailableCountForAllHardware", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getAvailableCountForAllHardware", he);
		}
	}
	
	@Override
	public List<Object[]> getUnavailableCountForAllHardware() throws CMMException {
	
		StringBuilder query = new StringBuilder("SELECT h.id,h.name,count(*) FROM HardwareTO h ");
		query.append("where h.status=? group by h.id");
		try {
			return (List<Object[]>) getHibernateTemplate().find(query.toString(), 72L);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getUnavailableCountForAllHardware", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getUnavailableCountForAllHardware", he);
		}
	}
	
	@Override
	public List<Object[]> getAllocatedCountForAllHardware() throws CMMException {
	
		StringBuilder query = new StringBuilder("SELECT h.id,h.name,count(*) FROM HardwareTO h ");
		query.append("where h.status=? group by h.id");
		try {
			return (List<Object[]>) getHibernateTemplate().find(query.toString(), 73L);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getAllocatedCountForAllHardware", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getAllocatedCountForAllHardware", he);
		}
	}
	
	@Override
	public Long getAvailableCount(long status) throws CMMException {
	
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(HardwareTO.class, "hardwares");
			criteria.add(Restrictions.eq("status", status));
			return (long) getHibernateTemplate().findByCriteria(criteria).size();
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getAvailableCount", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getAvailableCount", he);
		}
	}
	
	@Override
	public Long getAllocatedCount(long status) throws CMMException {
	
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(HardwareTO.class, "hardwares");
			criteria.add(Restrictions.eq("status", status));
			return (long) getHibernateTemplate().findByCriteria(criteria).size();
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getAllocatedCount.", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getAllocatedCount.", he);
		}
	}
	
	@Override
	public Long getUnavailableCount(long status) throws CMMException {
	
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(HardwareTO.class, "hardwares");
			criteria.add(Restrictions.eq("status", status));
			return (long) getHibernateTemplate().findByCriteria(criteria).size();
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : deleteReservations.", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : deleteReservations", he);
		}
	}
	
	@Override
	public List<ReservationTO> getReservationsByUser(ReservationTO reservationTO, Long clientId) throws CMMException {
	
		DetachedCriteria criteria = DetachedCriteria.forClass(ReservationTO.class, "res");
		try {
			criteria.add(Restrictions.ne("res.status.id", Entity.RESERVATION_STATUS_INACTIVE));
			criteria.add(Restrictions.disjunction().add(Property.forName("res.startTime").gt(reservationTO.getStartTime())).add(Restrictions.conjunction().add(Property.forName("res.startTime").ge(reservationTO.getStartTime())).add(Property.forName("res.endTime").ge(reservationTO.getEndTime()))).add(Restrictions.conjunction().add(Property.forName("res.startTime").le(reservationTO.getStartTime())).add(Property.forName("res.endTime").ge(reservationTO.getEndTime()))));
			criteria.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : deleteReservations", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : deleteReservations", he);
		}
		return (List<ReservationTO>) getHibernateTemplate().findByCriteria(criteria);
	}
	
	@Override
	public List<ReservationTO> getReservationsExpiringIn1Day() throws CMMException {
	
		try {
			Date currentDate = DateUtils.getStartTime(new Date());
			Date searchDate = DateUtils.addDays(currentDate, 1);
			DetachedCriteria criteria = DetachedCriteria.forClass(ReservationTO.class, "reservation");
			criteria.add(Restrictions.ne("status.id", Entity.RESERVATION_STATUS_INACTIVE));
			criteria.add(Restrictions.disjunction().add(Restrictions.conjunction().add(Property.forName("startTime").le(currentDate)).add(Property.forName("endTime").eq(searchDate))));
			return (List<ReservationTO>) getHibernateTemplate().findByCriteria(criteria);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getReservationsExpiringIn1Day", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getReservationsExpiringIn1Day", he);
		}
	}
	
	@Override
	public List<ReservationTO> getReservationStatistics(ReservationTO reservationTO) throws CMMException {
	
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(ReservationTO.class, "reservation");
			criteria.createAlias("StatusTO", "status", CriteriaSpecification.INNER_JOIN);
			criteria.add(Restrictions.eq("reservation.applications.id", reservationTO.getApplicationId()));
			criteria.add(Restrictions.eq("reservation.environments.id", reservationTO.getEnvironmentId()));
			criteria.add(Restrictions.le("startTime", reservationTO.getStartTime()));
			criteria.add(Restrictions.ge("endTime", reservationTO.getEndTime()));
			return (List<ReservationTO>) getHibernateTemplate().findByCriteria(criteria);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getReservationStatistics.", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getReservationStatistics", he);
		}
	}
	
	@Override
	public List<ReservationTO> getReservationsExpiringIn15Days() throws CMMException {
	
		try {
			Date currentDate = DateUtils.getStartTime(new Date());
			Date searchDate = DateUtils.addDays(currentDate, 15);
			DetachedCriteria criteria = DetachedCriteria.forClass(ReservationTO.class, "reservation");
			criteria.add(Restrictions.ne("status.id", Entity.RESERVATION_STATUS_INACTIVE));
			criteria.add(Restrictions.disjunction().add(Restrictions.conjunction().add(Property.forName("startTime").le(currentDate)).add(Property.forName("endTime").eq(searchDate))));
			return (List<ReservationTO>) getHibernateTemplate().findByCriteria(criteria);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getReservationsExpiringIn15Days.", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getReservationsExpiringIn15Days.", he);
		}
	}
	
	@Override
	public List<TestingTypeTO> getAllTestingType() throws CMMException {
	
		try {
			return (List<TestingTypeTO>) getHibernateTemplate().find("from TestingTypeTO");
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getAllTestingType.", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getAllTestingType.", he);
		}
	}
	
	@Override
	public void updateReservationForConflict(ReservationTO reservationTO) throws CMMException {
	
		try {
			List<ReservationTO> updateList = reservationTO.getConflictingReservationList();
			updateList.addAll(reservationTO.getConflictingReservationListApproved());
			List<Long> rejectionIds = reservationTO.getSelectedResvIdToReject();
			for (int i = 0; i < updateList.size(); i++) {
				ReservationTO reservationListComponent = updateList.get(i);
				String hql =String.format("from ReservationTO where id=%d",reservationListComponent.getId());
				ReservationTO reservationNew = (ReservationTO) getHibernateTemplate().find(hql).get(0);
				reservationListComponent.setEnvironmentId(reservationNew.getEnvironments().getId());
				reservationListComponent.setStatus(reservationNew.getStatus());
				reservationListComponent.setIsconflicting(reservationNew.getIsconflicting());
				startTimeReference = reservationNew.getStartTime();
				endTimeReference = reservationNew.getEndTime();
				List<ReservationTO> pastConflict = checkConflictRemovalFromPastRequest(reservationListComponent);
				if (!rejectionIds.contains(reservationListComponent.getId())) {
					reservationNew.setStartTime(DateUtils.parsejQueryDateTime(reservationListComponent.getStartTimeString()));
					reservationNew.setEndTime(DateUtils.parsejQueryDateTime(reservationListComponent.getEndTimeString()));
					if ("Disruptive".equalsIgnoreCase(reservationListComponent.getDisruptive())) {
						reservationNew.setDisruptive("D");
					} else if ("Shared".equalsIgnoreCase(reservationListComponent.getDisruptive())) {
						reservationNew.setDisruptive("S");
					}
					List<ReservationTO> futureConflict = checkConflictForFutureRequest(reservationListComponent);
					if (reservationListComponent.getStatus().getId() == Entity.RESERVATION_STATUS_APPROVED) {
						if (!futureConflict.isEmpty()) {
							reservationNew.setIsconflicting(1L);
						} else {
							reservationNew.setIsconflicting(0L);
						}
						getHibernateTemplate().update(reservationNew);
						for (ReservationTO reservationToObj : futureConflict) {
							reservationToObj.setIsconflicting(1L);
							getHibernateTemplate().update(reservationToObj);
						}
					} else {
						List<ReservationTO> resvInConflictAfterApproval = checkResvInConflictAfterApproval(reservationListComponent);
						if (!resvInConflictAfterApproval.isEmpty()) {
							reservationNew.setIsconflicting(1L);
							for (ReservationTO rt : resvInConflictAfterApproval) {
								rt.setIsconflicting(1L);
								getHibernateTemplate().update(rt);
							}
						} else {
							reservationNew.setIsconflicting(0L);
						}
						reservationNew.getStatus().setId(Entity.RESERVATION_STATUS_APPROVED);
						getHibernateTemplate().update(reservationNew);
					}
				} else {
					reservationNew.setIsconflicting(0L);
					reservationListComponent.getStatus().setId(Entity.RESERVATION_STATUS_REJECTED);
					String hql1 =String.format("from WorkflowCurrentTO where entity_id=%d",reservationListComponent.getId());
					WorkflowCurrentTO wf_current_obj = (WorkflowCurrentTO) getHibernateTemplate().find(hql).get(0);
					String hql2 =String.format("from WorkflowHistoryTO where wf_current_id=%d",wf_current_obj.getReqId());
					List<WorkflowHistoryTO> wf_history_obj = (List<WorkflowHistoryTO>) getHibernateTemplate().find(hql2);
					for (WorkflowHistoryTO wf_history_objTemp : wf_history_obj) {
						wf_history_objTemp.setComments("Rejected Due to Edit Conflict");
						getHibernateTemplate().update(wf_history_objTemp);
					}
					getHibernateTemplate().update(reservationNew);
				}
				for (ReservationTO reservationToObj : pastConflict) {
					reservationToObj.setIsconflicting(0L);
					getHibernateTemplate().update(reservationToObj);
				}
			}
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : updateReservation.", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : updateReservation.", he);
		} catch (Exception e) {
			LOG.error(e);
			throw new CMMException("Problem encountered. ReservationDAOImpl : updateReservation.", e);
		}
	}
	
	@Override
	public Long updateReservation(ReservationTO reservationNew, ReservationTO reservationOld) throws CMMException {
	
		long message = 0L;
		try {
			message = reserveEnvironment(reservationNew);
			updateReservationDetails(reservationNew);
			if (reservationOld.getDisruptive().equalsIgnoreCase(CMMConstants.Framework.ReservationStatus.RESERVATION_SHARED)) {
				List<ReservationTO> pendingList = getPending(reservationOld);
				List<ReservationTO> appList = new ArrayList<ReservationTO>();
				if (!pendingList.isEmpty()) {
					for (ReservationTO pending : pendingList) {
						appList = getApproved(pending, reservationOld.getId());
						if (!!appList.isEmpty()) {
							setConflictingFlag(pending);
						}
					}
				}
			} else if (reservationOld.getDisruptive().equalsIgnoreCase(CMMConstants.Framework.ReservationStatus.RESERVATION_LOCKED) || reservationOld.getDisruptive().equalsIgnoreCase(CMMConstants.Framework.ReservationStatus.RESERVATION_DISRUPTIVE)) {
				List<ReservationTO> pendingList = getPending(reservationOld);
				List<ReservationTO> approvedLocked = new ArrayList<ReservationTO>();
				List<ReservationTO> approvedList = new ArrayList<ReservationTO>();
				for (ReservationTO pending : pendingList) {
					if (pending.getDisruptive().equalsIgnoreCase(CMMConstants.Framework.ReservationStatus.RESERVATION_SHARED)) {
						approvedLocked = getApproved(pending, reservationOld.getId());
						if (approvedLocked.isEmpty()) {
							setConflictingFlag(pending);
						}
					} else {
						approvedList = getApproved(pending, reservationOld.getId());
						if (approvedList.isEmpty()) {
							setConflictingFlag(pending);
						}
					}
				}
			}
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : updateReservation.", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : updateReservation.", he);
		}
		return message;
	}
	
	@Override
	public boolean checkNoConflictDurationAvailability(ReservationTO reservationTO) throws CMMException {
	
		boolean validateFlag = false;
		try {
			String query = "select r.environments.id from ReservationTO r where r.id=?";
			Long environmentId = (Long) getHibernateTemplate().find(query.toString(), reservationTO.getId()).get(0);
			reservationTO.setEnvironmentId(environmentId);
			if (reservationTO.getDisruptive().equalsIgnoreCase(ReservationStatus.SHARED)) {
				if (checkSharedCount(reservationTO)) {
					DetachedCriteria criteria = DetachedCriteria.forClass(ReservationTO.class, "res");
					criteria.add(Restrictions.eq("res.environments.id", environmentId));
					for (int i = 0; i < reservationTO.getResIdsToCompare().size(); i++) {
						criteria.add(Restrictions.ne("res.id", reservationTO.getResIdsToCompare().get(i)));
					}
					criteria.add(Restrictions.ne("res.disruptive", ReservationStatus.RESERVATION_SHARED));
					criteria.add(Restrictions.eq("res.status.id", Entity.RESERVATION_STATUS_APPROVED));
					criteria.add(Restrictions.disjunction().add(Restrictions.conjunction().add(Property.forName("res.startTime").ge(reservationTO.getStartTime())).add(Property.forName("res.endTime").le(reservationTO.getEndTime()))).add(Restrictions.conjunction().add(Property.forName("res.startTime").le(reservationTO.getStartTime())).add(Property.forName("res.endTime").ge(reservationTO.getEndTime()))).add(Restrictions.conjunction().add(Property.forName("res.startTime").le(reservationTO.getStartTime())).add(Property.forName("res.endTime").gt(reservationTO.getStartTime()))).add(Restrictions.conjunction().add(Property.forName("res.startTime").lt(reservationTO.getEndTime())).add(Property.forName("res.endTime").ge(reservationTO.getEndTime()))));
					List<ReservationTO> reservation = (List<ReservationTO>) getHibernateTemplate().findByCriteria(criteria);
					if (reservation.isEmpty()) {
						validateFlag = true;
					}
				}
			} else {
				DetachedCriteria criteria = DetachedCriteria.forClass(ReservationTO.class, "res");
				criteria.add(Restrictions.eq("res.environments.id", environmentId));
				for (int i = 0; i < reservationTO.getResIdsToCompare().size(); i++) {
					criteria.add(Restrictions.ne("res.id", reservationTO.getResIdsToCompare().get(i)));
				}
				criteria.add(Restrictions.eq("res.status.id", Entity.RESERVATION_STATUS_APPROVED));
				criteria.add(Restrictions.disjunction().add(Restrictions.conjunction().add(Property.forName("res.startTime").ge(reservationTO.getStartTime())).add(Property.forName("res.endTime").le(reservationTO.getEndTime()))).add(Restrictions.conjunction().add(Property.forName("res.startTime").le(reservationTO.getStartTime())).add(Property.forName("res.endTime").ge(reservationTO.getEndTime()))).add(Restrictions.conjunction().add(Property.forName("res.startTime").le(reservationTO.getStartTime())).add(Property.forName("res.endTime").gt(reservationTO.getStartTime()))).add(Restrictions.conjunction().add(Property.forName("res.startTime").lt(reservationTO.getEndTime())).add(Property.forName("res.endTime").ge(reservationTO.getEndTime()))));
				List<ReservationTO> reservation = (List<ReservationTO>) getHibernateTemplate().findByCriteria(criteria);
				if (reservation.isEmpty()) {
					validateFlag = true;
				}
			}
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : checkReservationAvailability", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : checkReservationAvailability", he);
		}
		return validateFlag;
	}
	
	@Override
	public boolean checkNoConflictDurationAvailabilityForApproved(ReservationTO reservationTO) throws CMMException {
	
		boolean validateFlag = false;
		try {
			String query = "select r.environments.id from ReservationTO r where r.id=?";
			Long environmentId = (Long) getHibernateTemplate().find(query.toString(), reservationTO.getId()).get(0);
			reservationTO.setEnvironmentId(environmentId);
			if (reservationTO.getDisruptive().equalsIgnoreCase(ReservationStatus.RESERVATION_SHARED)) {
				if (checkSharedCount(reservationTO)) {
					DetachedCriteria criteria = DetachedCriteria.forClass(ReservationTO.class, "res");
					criteria.add(Restrictions.eq("res.environments.id", environmentId));
					criteria.add(Restrictions.disjunction().add(Restrictions.eq("res.status.id", Entity.RESERVATION_STATUS_APPROVED)).add(Restrictions.eq("res.status.id", Entity.RESERVATION_STATUS_PENDING)));
					criteria.add(Restrictions.disjunction().add(Restrictions.conjunction().add(Property.forName("res.startTime").ge(reservationTO.getStartTime())).add(Property.forName("res.endTime").le(reservationTO.getEndTime()))).add(Restrictions.conjunction().add(Property.forName("res.startTime").le(reservationTO.getStartTime())).add(Property.forName("res.endTime").ge(reservationTO.getEndTime()))).add(Restrictions.conjunction().add(Property.forName("res.startTime").le(reservationTO.getStartTime())).add(Property.forName("res.endTime").gt(reservationTO.getStartTime()))).add(Restrictions.conjunction().add(Property.forName("res.startTime").lt(reservationTO.getEndTime())).add(Property.forName("res.endTime").ge(reservationTO.getEndTime()))));
					List<ReservationTO> reservation = (List<ReservationTO>) getHibernateTemplate().findByCriteria(criteria);
					if (reservation.isEmpty()) {
						validateFlag = true;
					}
				}
			} else {
				DetachedCriteria criteria = DetachedCriteria.forClass(ReservationTO.class, "res");
				criteria.add(Restrictions.eq("res.environments.id", environmentId));
				criteria.add(Restrictions.disjunction().add(Restrictions.eq("res.status.id", Entity.RESERVATION_STATUS_APPROVED)).add(Restrictions.conjunction().add(Restrictions.eq("res.status.id", Entity.RESERVATION_STATUS_PENDING)).add(Restrictions.eq("res.id", reservationTO.getId()))));
				criteria.add(Restrictions.disjunction().add(Restrictions.conjunction().add(Property.forName("res.startTime").ge(reservationTO.getStartTime())).add(Property.forName("res.endTime").le(reservationTO.getEndTime()))).add(Restrictions.conjunction().add(Property.forName("res.startTime").le(reservationTO.getStartTime())).add(Property.forName("res.endTime").ge(reservationTO.getEndTime()))).add(Restrictions.conjunction().add(Property.forName("res.startTime").le(reservationTO.getStartTime())).add(Property.forName("res.endTime").gt(reservationTO.getStartTime()))).add(Restrictions.conjunction().add(Property.forName("res.startTime").lt(reservationTO.getEndTime())).add(Property.forName("res.endTime").ge(reservationTO.getEndTime()))));
				List<ReservationTO> reservation = (List<ReservationTO>) getHibernateTemplate().findByCriteria(criteria);
				if (reservation.isEmpty()) {
					validateFlag = true;
				}
			}
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : checkReservationAvailability", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : checkReservationAvailability", he);
		}
		return validateFlag;
	}
	
	public boolean checkSharedCount(ReservationTO reservationTO) throws CMMException {
	
		boolean validateSharedCount = true;
		boolean checkExist = false;
		checkExist = checkexistConflicts(reservationTO);
		if (checkExist) {
			validateSharedCount = false;
		}
		return validateSharedCount;
	}
	
	public List<ReservationTO> checkConflictRemovalFromPastRequest(ReservationTO reservationTO) throws CMMException {
	
		if (reservationTO.getStatus().getId() == Entity.RESERVATION_STATUS_APPROVED) {
			DetachedCriteria criteria = DetachedCriteria.forClass(ReservationTO.class, "res");
			criteria.add(Restrictions.eq("res.environments.id", reservationTO.getEnvironmentId()));
			criteria.add(Restrictions.eq("res.status.id", Entity.RESERVATION_STATUS_PENDING));
			criteria.add(Restrictions.disjunction().add(Restrictions.conjunction().add(Property.forName("res.startTime").ge(startTimeReference)).add(Property.forName("res.endTime").le(endTimeReference))).add(Restrictions.conjunction().add(Property.forName("res.startTime").le(startTimeReference)).add(Property.forName("res.endTime").ge(endTimeReference))).add(Restrictions.conjunction().add(Property.forName("res.startTime").le(startTimeReference)).add(Property.forName("res.endTime").gt(startTimeReference))).add(Restrictions.conjunction().add(Property.forName("res.startTime").lt(endTimeReference)).add(Property.forName("res.endTime").ge(endTimeReference))));
			List<ReservationTO> reservation = (List<ReservationTO>) getHibernateTemplate().findByCriteria(criteria);
			List<ReservationTO> reservationPendingToConflict = new ArrayList<ReservationTO>();
			for (ReservationTO reservationToObj : reservation) {
				DetachedCriteria criteriaPending = DetachedCriteria.forClass(ReservationTO.class, "res");
				criteriaPending.add(Restrictions.eq("res.environments.id", reservationToObj.getEnvironments().getId()));
				criteriaPending.add(Restrictions.eq("res.status.id", Entity.RESERVATION_STATUS_APPROVED));
				criteriaPending.add(Restrictions.disjunction().add(Restrictions.conjunction().add(Property.forName("res.startTime").ge(reservationToObj.getStartTime())).add(Property.forName("res.endTime").le(reservationToObj.getEndTime()))).add(Restrictions.conjunction().add(Property.forName("res.startTime").le(reservationToObj.getStartTime())).add(Property.forName("res.endTime").ge(reservationToObj.getEndTime()))).add(Restrictions.conjunction().add(Property.forName("res.startTime").le(reservationToObj.getStartTime())).add(Property.forName("res.endTime").gt(reservationToObj.getStartTime()))).add(Restrictions.conjunction().add(Property.forName("res.startTime").lt(reservationToObj.getEndTime())).add(Property.forName("res.endTime").ge(reservationToObj.getEndTime()))));
				List<ReservationTO> reservationPending = (List<ReservationTO>) getHibernateTemplate().findByCriteria(criteriaPending);
				if (reservationPending.size() == 1) {
					reservationPendingToConflict.add(reservationToObj);
				}
			}
			return reservationPendingToConflict;
		} else {
			DetachedCriteria criteria = DetachedCriteria.forClass(ReservationTO.class, "res");
			criteria.add(Restrictions.eq("res.environments.id", reservationTO.getEnvironmentId()));
			criteria.add(Restrictions.eq("res.status.id", Entity.RESERVATION_STATUS_APPROVED));
			criteria.add(Restrictions.disjunction().add(Restrictions.conjunction().add(Property.forName("res.startTime").ge(startTimeReference)).add(Property.forName("res.endTime").le(endTimeReference))).add(Restrictions.conjunction().add(Property.forName("res.startTime").le(startTimeReference)).add(Property.forName("res.endTime").ge(endTimeReference))).add(Restrictions.conjunction().add(Property.forName("res.startTime").le(startTimeReference)).add(Property.forName("res.endTime").gt(startTimeReference))).add(Restrictions.conjunction().add(Property.forName("res.startTime").lt(endTimeReference)).add(Property.forName("res.endTime").ge(endTimeReference))));
			List<ReservationTO> reservation = (List<ReservationTO>) getHibernateTemplate().findByCriteria(criteria);
			List<ReservationTO> reservationApprovedToConflict = new ArrayList<ReservationTO>();
			for (ReservationTO reservationToObj : reservation) {
				DetachedCriteria criteriaPending = DetachedCriteria.forClass(ReservationTO.class, "res");
				criteriaPending.add(Restrictions.eq("res.environments.id", reservationToObj.getEnvironments().getId()));
				criteriaPending.add(Restrictions.eq("res.status.id", Entity.RESERVATION_STATUS_PENDING));
				criteriaPending.add(Restrictions.disjunction().add(Restrictions.conjunction().add(Property.forName("res.startTime").ge(reservationToObj.getStartTime())).add(Property.forName("res.endTime").le(reservationToObj.getEndTime()))).add(Restrictions.conjunction().add(Property.forName("res.startTime").le(reservationToObj.getStartTime())).add(Property.forName("res.endTime").ge(reservationToObj.getEndTime()))).add(Restrictions.conjunction().add(Property.forName("res.startTime").le(reservationToObj.getStartTime())).add(Property.forName("res.endTime").gt(reservationToObj.getStartTime()))).add(Restrictions.conjunction().add(Property.forName("res.startTime").lt(reservationToObj.getEndTime())).add(Property.forName("res.endTime").ge(reservationToObj.getEndTime()))));
				List<ReservationTO> reservationPending = (List<ReservationTO>) getHibernateTemplate().findByCriteria(criteriaPending);
				if (reservationPending.size() == 1) {
					reservationApprovedToConflict.add(reservationToObj);
				}
			}
			return reservationApprovedToConflict;
		}
	}
	
	public List<ReservationTO> checkConflictForFutureRequest(ReservationTO reservationTO) throws CMMException {
	
		Date startTimeReferenceFuture = DateUtils.parsejQueryDateTime(reservationTO.getStartTimeString());
		Date endTimeReferenceFuture = DateUtils.parsejQueryDateTime(reservationTO.getEndTimeString());
		List<ReservationTO> reservation = new ArrayList<ReservationTO>();
		if (reservationTO.getStatus().getId() == Entity.RESERVATION_STATUS_APPROVED) {
			DetachedCriteria criteria = DetachedCriteria.forClass(ReservationTO.class, "res");
			criteria.add(Restrictions.eq("res.environments.id", reservationTO.getEnvironmentId()));
			criteria.add(Restrictions.eq("res.status.id", Entity.RESERVATION_STATUS_PENDING));
			criteria.add(Restrictions.disjunction().add(Restrictions.conjunction().add(Property.forName("res.startTime").ge(startTimeReferenceFuture)).add(Property.forName("res.endTime").le(endTimeReferenceFuture))).add(Restrictions.conjunction().add(Property.forName("res.startTime").le(startTimeReferenceFuture)).add(Property.forName("res.endTime").ge(endTimeReferenceFuture))).add(Restrictions.conjunction().add(Property.forName("res.startTime").le(startTimeReferenceFuture)).add(Property.forName("res.endTime").gt(startTimeReferenceFuture))).add(Restrictions.conjunction().add(Property.forName("res.startTime").lt(endTimeReferenceFuture)).add(Property.forName("res.endTime").ge(endTimeReferenceFuture))));
			reservation = (List<ReservationTO>) getHibernateTemplate().findByCriteria(criteria);
		}
		return reservation;
	}
	
	/**
	 * Searches all the reservations and returns in form of a List.
	 *
	 * @param reservationTO
	 *                The selected data on UI according to which the search is to be done.
	 * @return List of Reservations in form of a List.
	 */
	@Override
	public List<ReservationTO> searchReservation(ReservationTO reservationTO) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			Long userId = reservationTO.getUserId();
			long roleId = reservationTO.getRoleId();
			String adminCheck = "";
			if (roleId > 1) {
				adminCheck = adminCheck + "and r.userId=" + userId;
			}
			DateFormat format1 = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
			String dateFromStr = null;
			String dateToStr = null;
			Date dateFrom = null;
			Date dateTo = null;
			Calendar cal = Calendar.getInstance();
			String formatedFromDate = null;
			String formatedToDate = null;
			DateFormat formatter1 = new SimpleDateFormat("yyyy-MM-dd");
			if (!reservationTO.getStartTimeString().isEmpty()) {
				dateFromStr = reservationTO.getStartTimeString();
				try {
					dateFrom = format1.parse(dateFromStr);
					cal.setTime(dateFrom);
					formatedFromDate = cal.get(Calendar.YEAR) + "-" + (cal.get(Calendar.MONTH) + 1) + "-" + cal.get(Calendar.DATE);
					dateFrom = formatter1.parse(formatedFromDate);
				} catch (ParseException e) {
					throw new CMMException("Error parsing date ", e);
				}
			}
			if (!reservationTO.getEndTimeString().isEmpty()) {
				dateToStr = reservationTO.getEndTimeString();
				try {
					dateTo = format1.parse(dateToStr);
					cal.setTime(dateTo);
					formatedToDate = cal.get(Calendar.YEAR) + "-" + (cal.get(Calendar.MONTH) + 1) + "-" + cal.get(Calendar.DATE);
					dateTo = formatter1.parse(formatedToDate);
				} catch (ParseException e) {
					throw new CMMException("Error parsing date ", e);
				}
			}
			List<ReservationTO> reservations = new ArrayList<ReservationTO>();
			LOG.info("In Search Reservation screen");
			if (reservationTO.getClientId() != 0) {
				String query = "select r, app.projectTO.id,app.projectTO.name ,app.businessUnitTO.clientId, app.businessUnitTO.name, s.statusDesc,app.appName,env.environmentName  from ReservationTO as r , ApplicationTO as app , StatusTO as s, EnvironmentTO as env where r.applications.id =app.id  and r.status.id = s.id and r.environments.id =env.id and r.applications.businessUnitTO.clientId in (:clientList)" + adminCheck;
				if (reservationTO.getId() != null) {
					query = query + " and r.id = " + reservationTO.getId();
				}
				if ((reservationTO.getSelectedStatus() != -1) && (reservationTO.getSelectedStatus() != 0)) {
					query = query + " and r.status.id = " + reservationTO.getSelectedStatus();
				}
				if ((reservationTO.getSelectedBusinessUnit() != null) && (reservationTO.getSelectedBusinessUnit() != -1)) {
					query = query + " and app.businessUnitTO.clientId= " + reservationTO.getSelectedBusinessUnit();
				}
				if (reservationTO.getSelectedProject() != null) {
					query = query + " and app.projectTO.id = " + reservationTO.getSelectedProject();
				}
				if ((reservationTO.getSelectedApplication() != null) && (reservationTO.getSelectedApplication() != -1)) {
					query = query + " and r.applications.id = " + reservationTO.getSelectedApplication();
				}
				if ((reservationTO.getSelectedEnvironment() != null) && (reservationTO.getSelectedEnvironment() != -1)) {
					query = query + " and r.environments.id = " + reservationTO.getSelectedEnvironment();
				}
				if (!reservationTO.getStartTimeString().isEmpty() && !reservationTO.getEndTimeString().isEmpty()) {
					query = query + " and r.startTime >=:datefrom and r.endTime <=:dateto";
				} else if (!reservationTO.getStartTimeString().isEmpty() && reservationTO.getEndTimeString().isEmpty()) {
					query = query + " and r.startTime >=:datefrom";
				} else if (reservationTO.getStartTimeString().isEmpty() && !reservationTO.getEndTimeString().isEmpty()) {
					query = query + " and r.endTime <=:dateto";
				}
				Query q = session.createQuery(query);
				q.setParameterList("clientList", reservationTO.getClientIdList());
				if (!reservationTO.getStartTimeString().isEmpty() && !reservationTO.getEndTimeString().isEmpty()) {
					q.setDate("datefrom", dateFrom);
					q.setDate("dateto", dateTo);
				}
				if (!reservationTO.getStartTimeString().isEmpty() && reservationTO.getEndTimeString().isEmpty()) {
					q.setDate("datefrom", dateFrom);
				}
				if (reservationTO.getStartTimeString().isEmpty() && !reservationTO.getEndTimeString().isEmpty()) {
					q.setDate("dateto", dateTo);
				}
				List<Object[]> object = q.list();
				for (int i = 0; i < object.size(); i++) {
					Object[] dbreser = object.get(i);
					ReservationTO reserTO = (ReservationTO) dbreser[0];
					reserTO.setProjectId((Long) dbreser[1]);
					reserTO.setProjectName(dbreser[2].toString());
					reserTO.setClientId((Long) dbreser[3]);
					reserTO.setClientName(dbreser[4].toString());
					reserTO.setStatusDesc(dbreser[5].toString());
					reserTO.setApplicationName(dbreser[6].toString());
					reserTO.setEnvironmentName(dbreser[7].toString());
					Long createdby = reserTO.getUserId();
					StringBuilder userQuery = new StringBuilder("select u.name from UserTO u where u.id=?");
					String createdByUser = (String) getHibernateTemplate().find(userQuery.toString(), createdby).get(0);
					reserTO.setCreatedByUser(createdByUser);
					reservations.add(reserTO);
				}
			} else {
				String query = "select r, app.projectTO.id,app.projectTO.name ,app.businessUnitTO.clientId, app.businessUnitTO.name, s.statusDesc,app.appName,env.environmentName  from ReservationTO as r , ApplicationTO as app , StatusTO as s, EnvironmentTO as env where r.applications.id =app.id  and r.status.id = s.id and r.environments.id =env.id " + adminCheck;
				if ((reservationTO.getSelectedStatus() != -1) && (reservationTO.getSelectedStatus() != 0)) {
					query = query + " and r.status.id = " + reservationTO.getSelectedStatus();
				}
				if (reservationTO.getId() != null) {
					query = query + " and r.id = " + reservationTO.getId();
				}
				if ((reservationTO.getSelectedBusinessUnit() != null) && (reservationTO.getSelectedBusinessUnit() != -1)) {
					query = query + " and app.businessUnitTO.clientId= " + reservationTO.getSelectedBusinessUnit();
				}
				if (reservationTO.getSelectedProject() != null) {
					query = query + " and app.projectTO.id = " + reservationTO.getSelectedProject();
				}
				if ((reservationTO.getSelectedApplication() != null) && (reservationTO.getSelectedApplication() != -1)) {
					query = query + " and r.applications.id = " + reservationTO.getSelectedApplication();
				}
				if ((reservationTO.getSelectedEnvironment() != null) && (reservationTO.getSelectedEnvironment() != -1)) {
					query = query + " and r.environments.id = " + reservationTO.getSelectedEnvironment();
				}
				if (!reservationTO.getStartTimeString().isEmpty() && !reservationTO.getEndTimeString().isEmpty()) {
					query = query + " and r.startTime >=:datefrom and r.endTime <=:dateto";
				} else if (!reservationTO.getStartTimeString().isEmpty() && reservationTO.getEndTimeString().isEmpty()) {
					query = query + " and r.startTime >=:datefrom";
				} else if (reservationTO.getStartTimeString().isEmpty() && !reservationTO.getEndTimeString().isEmpty()) {
					query = query + " and r.endTime <=:dateto";
				}
				Query q = session.createQuery(query);
				if (reservationTO.getSearchCount() != 0) {
					q.setFirstResult(reservationTO.getFirstResult());
					q.setMaxResults(reservationTO.getTableSize());
				}
				if (!reservationTO.getStartTimeString().isEmpty() && !reservationTO.getEndTimeString().isEmpty()) {
					q.setDate("datefrom", dateFrom);
					q.setDate("dateto", dateTo);
				}
				if (!reservationTO.getStartTimeString().isEmpty() && reservationTO.getEndTimeString().isEmpty()) {
					q.setDate("datefrom", dateFrom);
				}
				if (reservationTO.getStartTimeString().isEmpty() && !reservationTO.getEndTimeString().isEmpty()) {
					q.setDate("dateto", dateTo);
				}
				List<Object[]> object = q.list();
				for (int i = 0; i < object.size(); i++) {
					Object[] dbreser = object.get(i);
					ReservationTO reserTO = (ReservationTO) dbreser[0];
					reserTO.setProjectId((Long) dbreser[1]);
					reserTO.setProjectName(dbreser[2].toString());
					reserTO.setClientId((Long) dbreser[3]);
					reserTO.setClientName(dbreser[4].toString());
					reserTO.setStatusDesc(dbreser[5].toString());
					reserTO.setApplicationName(dbreser[6].toString());
					reserTO.setEnvironmentName(dbreser[7].toString());
					Long createdby = reserTO.getUserId();
					StringBuilder userQuery = new StringBuilder("select u.name from UserTO u where u.id=?");
					String createdByUser = (String) getHibernateTemplate().find(userQuery.toString(), createdby).get(0);
					reserTO.setCreatedByUser(createdByUser);
					reservations.add(reserTO);
				}
			}
			return reservations;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : searchReservation.", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : searchReservation.", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public ReservationTO searchReservationForConflict(Long reservationsId) throws CMMException {
	
		ReservationTO reservationTO = new ReservationTO();
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(ReservationTO.class, "reservation");
			criteria.add(Restrictions.eq("id", reservationsId));
			List<ReservationTO> success = (List<ReservationTO>) getHibernateTemplate().findByCriteria(criteria);
			if (success.isEmpty()) {
				reservationTO = null;
			} else {
				Object[] obj;
				if ((success.get(0).getReleasePlan() != null) && (success.get(0).getTestingPhase() != null)) {
					obj = (Object[]) getHibernateTemplate().find("select r, app.projectTO.id,app.projectTO.name ,app.businessUnitTO.clientId, app.businessUnitTO.name, s.statusDesc, rp.name, tp.name  from ReservationTO as r , ApplicationTO as app , StatusTO as s, ReleasePlanningTO as rp, TestingPhaseTO as tp where r.applications.id =app.id  and r.status.id = s.id and rp.id=r.releasePlanTO.id and tp.id=r.testingPhaseTO.id and  r.id =" + reservationsId).get(0);
					reservationTO = (ReservationTO) obj[0];
					reservationTO.setProjectId((Long) obj[1]);
					reservationTO.setProjectName(obj[2].toString());
					reservationTO.setClientId((Long) obj[3]);
					reservationTO.setClientName(obj[4].toString());
					reservationTO.setStatusDesc(obj[5].toString());
					if (obj[6] != null) {
						reservationTO.setReleasePlanName(obj[6].toString());
					}
					if (obj[7] != null) {
						reservationTO.setTestingPhaseName(obj[7].toString());
					}
				} else {
					obj = (Object[]) getHibernateTemplate().find("select r, app.projectTO.id,app.projectTO.name ,app.businessUnitTO.clientId, app.businessUnitTO.name, s.statusDesc  from ReservationTO as r , ApplicationTO as app , StatusTO as s where r.applications.id =app.id  and r.status.id = s.id and  r.id =" + reservationsId).get(0);
					reservationTO = (ReservationTO) obj[0];
					reservationTO.setProjectId((Long) obj[1]);
					reservationTO.setProjectName(obj[2].toString());
					reservationTO.setClientId((Long) obj[3]);
					reservationTO.setClientName(obj[4].toString());
					reservationTO.setStatusDesc(obj[5].toString());
					reservationTO.setTestingPhaseName("NA");
					reservationTO.setReleasePlanName("NA");
				}
			}
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : searchReservationForConflict.", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : searchReservationForConflict.", he);
		} catch (Exception e) {
			LOG.error(e);
			throw new CMMException("Problem encountered. ReservationDAOImpl : searchReservationForConflict.", e);
		}
		return reservationTO;
	}
	
	@Override
	public List<TestingPhaseTO> getAllTestingCycle() throws CMMException {
	
		try {
			return (List<TestingPhaseTO>) getHibernateTemplate().find("from TestingPhaseTO");
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getAllTestingCycle", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getAllTestingCycle.", he);
		}
	}
	
	public Long isConflicting(ReservationTO reservation) throws CMMException {
	
		Long reservationId = 0L;
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(ReservationTO.class, "reservation");
			criteria.add(Restrictions.eq("reservation.environments.id", reservation.getEnvironmentId()));
			criteria.add(Restrictions.le("startTime", reservation.getStartTime()));
			criteria.add(Restrictions.ge("endTime", reservation.getEndTime()));
			criteria.add(Restrictions.eq("status.id", CMMConstants.Framework.Entity.RESERVATION_STATUS_APPROVED));
			List<ReservationTO> reservationTO = (List<ReservationTO>) getHibernateTemplate().findByCriteria(criteria);
			if (!reservationTO.isEmpty()) {
				ReservationTO res = reservationTO.get(0);
				reservationId = res.getId();
			}
			return reservationId;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : isConflicting.", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : isConflicting.", he);
		}
	}
	
	@Override
	public Long searchConflicting(ReservationTO reservation) throws CMMException {
	
		Long reservationId = 0L;
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(ReservationTO.class, "reservation");
			criteria.add(Restrictions.eq("reservation.environments.id", reservation.getEnvironmentId()));
			criteria.add(Restrictions.le("startTime", reservation.getStartTime()));
			criteria.add(Restrictions.ge("endTime", reservation.getEndTime()));
			criteria.add(Restrictions.eq("status.id", CMMConstants.Framework.Entity.RESERVATION_STATUS_PENDING));
			criteria.add(Restrictions.eq("disruptive", CMMConstants.Framework.ReservationStatus.RESERVATION_DISRUPTIVE));
			List<ReservationTO> reservationTO = (List<ReservationTO>) getHibernateTemplate().findByCriteria(criteria);
			if (!reservationTO.isEmpty()) {
				ReservationTO res = reservationTO.get(0);
				reservationId = res.getId();
			}
			return reservationId;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : searchConflicting.", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : searchConflicting.", he);
		}
	}
	
	@Override
	public List<ReservationTO> getReservationsForEnvironment(Long envId) throws CMMException {
	
		LOG.info("Inside getReservationsForEnvironment of ReservationDaoImpl");
		try {
			List<Object[]> obj = (List<Object[]>) getHibernateTemplate().find("select r, a.name, s.statusDesc,r.users.name from ReservationTO as r , StatusTO as s, AllocationMasterTO as a  where  r.status.id = s.id  and r.disruptive =a.id and  r.environments.id =? and r.status.id <> ?", envId, Entity.RESERVATION_STATUS_INACTIVE);
			List<ReservationTO> reservations = new ArrayList<ReservationTO>();
			for (Object a[] : obj) {
				ReservationTO res = (ReservationTO) a[0];
				res.setDisruptive(a[1].toString());
				res.setUserName(a[3].toString());
				res.setStatusDesc(a[2].toString());
				reservations.add(res);
			}
			return reservations;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getReservationsForEnvironment.", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getReservationsForEnvironment.", he);
		}
	}
	
	@Override
	public int getCountofSharedReservation(ReservationTO reservation) throws CMMException {
	
		try {
			String query1 = "select r from ReservationTO as r where r.environments.id =?  and ((r.startTime <= ? and r.endTime >= ? and r.endTime <= ?) or (r.endTime >= ? and r.startTime >= ? and r.startTime <= ?) or (r.startTime <= ? and r.endTime >= ?) or (r.startTime >= ? and r.startTime <= ? and r.endTime >= ? and r.endTime <= ?)) and r.status.id IN (81, 84) and r.disruptive = ? ";
			List<ReservationTO> reservationTOs = (List<ReservationTO>) getHibernateTemplate().find(query1, reservation.getEnvironmentId(), reservation.getStartTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getEndTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getStartTime(), reservation.getEndTime(), CMMConstants.Framework.ReservationStatus.RESERVATION_SHARED);
			return reservationTOs.size();
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getCountofSharedReservation.", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getCountofSharedReservation.", he);
		}
	}
	
	@Override
	public List<ReservationTO> getConflictReservation(Long resvId) throws CMMException {
	
		try {
			ReservationTO dbReservationDtls = (ReservationTO) getHibernateTemplate().find("from ReservationTO r where r.id=?", resvId).get(0);
			if ("D".equalsIgnoreCase(dbReservationDtls.getDisruptive())) {
				dbReservationDtls.setDisruptive("Disruptive");
			} else if ("S".equalsIgnoreCase(dbReservationDtls.getDisruptive())) {
				dbReservationDtls.setDisruptive("Shared");
			} else if ("A".equalsIgnoreCase(dbReservationDtls.getDisruptive())) {
				dbReservationDtls.setDisruptive("Normal");
			} else {
				dbReservationDtls.setDisruptive("Locked");
			}
			if (dbReservationDtls.getStatus().getId() == 81) {
				dbReservationDtls.setStatusDesc("Reserved");
			} else if (dbReservationDtls.getStatus().getId() == 82) {
				dbReservationDtls.setStatusDesc("Cancelled");
			} else if (dbReservationDtls.getStatus().getId() == 83) {
				dbReservationDtls.setStatusDesc("Conflicting");
			} else {
				dbReservationDtls.setStatusDesc("Pending Approval");
			}
			String userName = (String) getHibernateTemplate().find("select name from UserTO where id=?", dbReservationDtls.getUserId()).get(0);
			dbReservationDtls.setUserName(userName);
			List<ReservationTO> tempReservation = new ArrayList<ReservationTO>(0);
			String query1 = "select r.id,r.startTime,r.endTime,r.userId,am.name , s.statusDesc,r.testingType, r.status from ReservationTO r,StatusTO s,AllocationMasterTO am  where s.id = r.status.id and r.environments.id=? and ((r.startTime >= ? and r.endTime <= ?) or (r.startTime <= ? and r.endTime >= ?) or (r.startTime <= ? and r.endTime > ?) or (r.startTime < ? and  r.endTime >= ?)) and r.disruptive =am.id and r.status.id=? and r.isconflicting=1L";
			List<Object[]> conflictidList = (List<Object[]>) getHibernateTemplate().find(query1, dbReservationDtls.getEnvironments().getId(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getStartTime(), dbReservationDtls.getEndTime(), dbReservationDtls.getEndTime(), CMMConstants.Framework.Entity.RESERVATION_STATUS_APPROVED);
			tempReservation.add(dbReservationDtls);
			for (Object[] temp : conflictidList) {
				ReservationTO reservations = new ReservationTO();
				reservations.setId(Long.parseLong(temp[0].toString()));
				reservations.setStartTime((Date) temp[1]);
				reservations.setEndTime((Date) temp[2]);
				reservations.setUserId(Long.parseLong(temp[3].toString()));
				String name = (String) getHibernateTemplate().find("select name from UserTO where id=?", reservations.getUserId()).get(0);
				reservations.setUserName(name);
				reservations.setDisruptive(temp[4].toString());
				reservations.setStatusDesc(temp[5].toString());
				reservations.setTestingType(Long.parseLong(temp[6].toString()));
				reservations.setStatus((StatusTO) temp[7]);
				reservations.setConflictsId(resvId.toString());
				tempReservation.add(reservations);
			}
			return tempReservation;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : checkWorkFlowDefined", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : checkWorkFlowDefined", he);
		}
	}
	
	@Override
	public ReservationTO getReservationDetails(Long resvId) throws CMMException {
	
		try {
			String query1 = "select c.name,p.name,r from ReservationTO r, ApplicationTO a, ClientTO c, ProjectsTO p where r.applications.id = a.id and a.businessUnitTO.id = c.id and a.projectTO = p.id and r.id=?";
			Object[] resvDetailsObj = (Object[]) getHibernateTemplate().find(query1, resvId).get(0);
			ReservationTO resvDetails = (ReservationTO) resvDetailsObj[2];
			resvDetails.setClientName((String) resvDetailsObj[0]);
			resvDetails.setProjectName((String) resvDetailsObj[1]);
			return resvDetails;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : checkWorkFlowDefined", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.WorkFlowDAOImpl : checkWorkFlowDefined", he);
		} catch (Exception e) {
			LOG.error(e);
			throw new CMMException("Problem encountered. ReservationDAOImpl : searchReservationForConflict.", e);
		}
	}
	
	@Override
	public boolean getLockedStatusForTheDuration(ReservationTO reservation) throws CMMException {
	
		try {
			String query = "select r from ReservationTO as r where r.environments.id =? and r.status.id=? and r.disruptive=? and ((r.startTime < ? and r.endTime > ?) or (r.startTime < ? and r.endTime > ?)) and r.status not IN (" + CMMConstants.Framework.Entity.RESERVATION_STATUS_INACTIVE + "," + CMMConstants.Framework.Entity.RESERVATION_STATUS_REJECTED + ")";
			List<ReservationTO> lockedReservationTO = (List<ReservationTO>) getHibernateTemplate().find(query, reservation.getEnvironmentId(), CMMConstants.Framework.Entity.RESERVATION_STATUS_APPROVED, CMMConstants.Framework.ReservationStatus.RESERVATION_LOCKED, reservation.getStartTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getEndTime());
			boolean lockStatus = false;
			if (!lockedReservationTO.isEmpty()) {
				lockStatus = true;
			}
			return lockStatus;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getCountofSharedReservation.", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getCountofSharedReservation.", he);
		}
	}
	
	@Override
	public List<ReservationTO> getRelease(ReservationTO reservationTO) throws CMMException {
	
		try {
			List<ReservationTO> reservations = new ArrayList<ReservationTO>();
			LOG.info("In Search Reservation screen");
			String query = "select r, app.projectTO.id,app.projectTO.name ,app.businessUnitTO.clientId, app.businessUnitTO.name, s.statusDesc,app.appName,env.environmentName from ReservationTO as r , ApplicationTO as app , StatusTO as s, EnvironmentTO as env where r.applications.id =app.id  and r.status.id = s.id and r.environments.id =env.id  ";
			List<Object[]> object = (List<Object[]>) getHibernateTemplate().find(query);
			for (int i = 0; i < object.size(); i++) {
				Object[] dbreser = object.get(i);
				ReservationTO reserTO = (ReservationTO) dbreser[0];
				reserTO.setProjectId((Long) dbreser[1]);
				reserTO.setProjectName(dbreser[2].toString());
				reserTO.setClientId((Long) dbreser[3]);
				reserTO.setClientName(dbreser[4].toString());
				reserTO.setStatusDesc(dbreser[5].toString());
				reserTO.setApplicationName(dbreser[6].toString());
				reserTO.setEnvironmentName(dbreser[7].toString());
				reservations.add(reserTO);
			}
			return reservations;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encoutered. ReservationDAOImpl : getRelease.", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getRelease.", he);
		}
	}
	
	@Override
	public Long reserveEnvironment(ReservationTO reservation) throws CMMException {
	
		Long messageFlag = 0L;
		int SHARED_MAX_COUNT = getSharedMaxCount();
		String query;
		List<ReservationTO> reservationCheckList;
		List<ReservationTO> reservationList = new ArrayList<ReservationTO>();
		if (reservation.isUpdateFlag()) {
			query = "select r from ReservationTO as r, ApplicationTO a where a.id=r.applications.id and r.environments.id =? and r.applications.id =? and ((r.startTime <= ? and r.endTime >= ? and r.endTime <= ?) or (r.endTime >= ? and r.startTime >= ? and r.startTime <= ?) or (r.startTime <= ? and r.endTime >= ?) or (r.startTime >= ? and r.startTime <= ? and r.endTime >= ? and r.endTime <= ?)) and (r.startTime != ? and r.endTime != ?) and r.users.id=? and r.status.id in (?,?,?) and r.id not in(?) ";
			reservationCheckList = (List<ReservationTO>) getHibernateTemplate().find(query, reservation.getEnvironmentId(), reservation.getApplicationId(), reservation.getStartTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getEndTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getEndTime(), reservation.getStartTime(), reservation.getUserId(), CMMConstants.Framework.Entity.RESERVATION_STATUS_APPROVED, CMMConstants.Framework.Entity.RESERVATION_STATUS_PENDING, CMMConstants.Framework.Entity.RESERVATION_STATUS_CONFLICTING, reservation.getId());
			if (reservationCheckList.isEmpty()) {
				String query1 = "select r from ReservationTO as r where r.environments.id =?  and ((r.startTime <= ? and r.endTime >= ? and r.endTime <= ?) or (r.endTime >= ? and r.startTime >= ? and r.startTime <= ?) or (r.startTime <= ? and r.endTime >= ?) or (r.startTime >= ? and r.startTime <= ? and r.endTime >= ? and r.endTime <= ?)) and (r.startTime != ? and r.endTime != ?) and r.status.id IN (81, 84) and r.id<> ?  ";
				reservationList = (List<ReservationTO>) getHibernateTemplate().find(query1, reservation.getEnvironmentId(), reservation.getStartTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getEndTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getEndTime(), reservation.getStartTime(), reservation.getId());
				reservationList.size();
				Long countSharedApproved = 0L;
				Long countSharedPending = 0L;
				Long countDisruptiveApproved = 0L;
				Long countDisruptivePending = 0L;
				List<ReservationTO> sharedApprovedList = new ArrayList<ReservationTO>(0);
				List<ReservationTO> disruptiveApprovedList = new ArrayList<ReservationTO>(0);
				for (ReservationTO reservationToObj : reservationList) {
					if ("S".equalsIgnoreCase(reservationToObj.getDisruptive()) && (reservationToObj.getStatus().getId() == 81L)) {
						sharedApprovedList.add(reservationToObj);
						countSharedApproved++;
					}
					if ("S".equalsIgnoreCase(reservationToObj.getDisruptive()) && (reservationToObj.getStatus().getId() == 84L)) {
						countSharedPending++;
					}
					if (!"S".equalsIgnoreCase(reservationToObj.getDisruptive()) && (reservationToObj.getStatus().getId() == 81L)) {
						disruptiveApprovedList.add(reservationToObj);
						countDisruptiveApproved++;
					}
					if (!"S".equalsIgnoreCase(reservationToObj.getDisruptive()) && (reservationToObj.getStatus().getId() == 84L)) {
						countDisruptivePending++;
					}
				}
				if ("S".equalsIgnoreCase(reservation.getDisruptive())) {
					if (((countSharedApproved + countSharedPending) < SHARED_MAX_COUNT) && (countDisruptiveApproved == 0L)) {
						reservation.setIsconflicting(0L);
						if (!reservation.isUpdateFlag()) {
							if ((reservation.getIsRepetetive() != 1L) || (reservation.isMakeReservation() == false)) {
								makereservation(reservation);
							}
						}
						messageFlag = 1L;
						return messageFlag;
					} else if ((countSharedApproved + countSharedPending) == SHARED_MAX_COUNT) {
						messageFlag = 0L;
						String sharedMaxCount = "Request cannot be submitted as " + SHARED_MAX_COUNT + " reservations are already in shared mode";
						throw new CMMException(sharedMaxCount);
					} else if (countDisruptiveApproved > 0L) {
						for (ReservationTO reserObj : disruptiveApprovedList) {
							reserObj.setIsconflicting(1L);
							getHibernateTemplate().update(reserObj);
						}
						reservation.setIsconflicting(1L);
						if (!reservation.isUpdateFlag()) {
							if ((reservation.getIsRepetetive() != 1L) || (reservation.isMakeReservation() == false)) {
								makereservation(reservation);
							}
						}
						messageFlag = 2L;
						return messageFlag;
					}
				} else if ((countSharedApproved > 0L) || (countDisruptiveApproved > 0L)) {
					for (ReservationTO reserObj : disruptiveApprovedList) {
						reserObj.setIsconflicting(1L);
						getHibernateTemplate().update(reserObj);
					}
					for (ReservationTO reserObj : sharedApprovedList) {
						reserObj.setIsconflicting(1L);
						getHibernateTemplate().update(reserObj);
					}
					reservation.setIsconflicting(1L);
					if (!reservation.isUpdateFlag()) {
						if ((reservation.getIsRepetetive() != 1L) || (reservation.isMakeReservation() == false)) {
							makereservation(reservation);
						}
					}
					messageFlag = 2L;
					return messageFlag;
				} else {
					reservation.setIsconflicting(0L);
					if (!reservation.isUpdateFlag()) {
						if ((reservation.getIsRepetetive() != 1L) || (reservation.isMakeReservation() == false)) {
							makereservation(reservation);
						}
					}
					messageFlag = 1L;
					return messageFlag;
				}
			}
		} else {
			query = "select r from ReservationTO as r, ApplicationTO a where a.id=r.applications.id and r.environments.id =? and r.applications.id =? and ((r.startTime <= ? and r.endTime >= ? and r.endTime <= ?) or (r.endTime >= ? and r.startTime >= ? and r.startTime <= ?) or (r.startTime <= ? and r.endTime >= ?) or (r.startTime >= ? and r.startTime <= ? and r.endTime >= ? and r.endTime <= ?)) and (r.startTime != ? and r.endTime != ?) and r.users.id=? and r.status.id in (?,?,?)  ";
			reservationCheckList = (List<ReservationTO>) getHibernateTemplate().find(query, reservation.getEnvironmentId(), reservation.getApplicationId(), reservation.getStartTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getEndTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getEndTime(), reservation.getStartTime(), reservation.getUserId(), CMMConstants.Framework.Entity.RESERVATION_STATUS_APPROVED, CMMConstants.Framework.Entity.RESERVATION_STATUS_PENDING, CMMConstants.Framework.Entity.RESERVATION_STATUS_CONFLICTING);
			if (reservationCheckList.isEmpty()) {
				String query1 = "select r from ReservationTO as r where r.environments.id =?  and ((r.startTime <= ? and r.endTime >= ? and r.endTime <= ?) or (r.endTime >= ? and r.startTime >= ? and r.startTime <= ?) or (r.startTime <= ? and r.endTime >= ?) or (r.startTime >= ? and r.startTime <= ? and r.endTime >= ? and r.endTime <= ?)) and (r.startTime != ? and r.endTime != ?) and r.status.id IN (81, 84)  ";
				reservationList = (List<ReservationTO>) getHibernateTemplate().find(query1, reservation.getEnvironmentId(), reservation.getStartTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getEndTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getEndTime(), reservation.getStartTime());
				reservationList.size();
				Long countSharedApproved = 0L;
				Long countSharedPending = 0L;
				Long countDisruptiveApproved = 0L;
				Long countDisruptivePending = 0L;
				List<ReservationTO> sharedApprovedList = new ArrayList<ReservationTO>(0);
				List<ReservationTO> disruptiveApprovedList = new ArrayList<ReservationTO>(0);
				for (ReservationTO reservationToObj : reservationList) {
					if ("S".equalsIgnoreCase(reservationToObj.getDisruptive()) && (reservationToObj.getStatus().getId() == 81L)) {
						sharedApprovedList.add(reservationToObj);
						countSharedApproved++;
					}
					if ("S".equalsIgnoreCase(reservationToObj.getDisruptive()) && (reservationToObj.getStatus().getId() == 84L)) {
						countSharedPending++;
					}
					if (!"S".equalsIgnoreCase(reservationToObj.getDisruptive()) && (reservationToObj.getStatus().getId() == 81L)) {
						disruptiveApprovedList.add(reservationToObj);
						countDisruptiveApproved++;
					}
					if (!"S".equalsIgnoreCase(reservationToObj.getDisruptive()) && (reservationToObj.getStatus().getId() == 84L)) {
						countDisruptivePending++;
					}
				}
				if ("S".equalsIgnoreCase(reservation.getDisruptive())) {
					if (((countSharedApproved + countSharedPending) < SHARED_MAX_COUNT) && (countDisruptiveApproved == 0L)) {
						reservation.setIsconflicting(0L);
						if (!reservation.isUpdateFlag()) {
							if ((reservation.getIsRepetetive() != 1L) || (reservation.isMakeReservation() == false)) {
								makereservation(reservation);
							}
						}
						messageFlag = 1L;
						return messageFlag;
					} else if ((countSharedApproved + countSharedPending) == SHARED_MAX_COUNT) {
						messageFlag = 0L;
						String sharedMaxCount = "Request cannot be submitted as " + SHARED_MAX_COUNT + " reservations are already in shared mode";
						throw new CMMException(sharedMaxCount);
					} else if (countDisruptiveApproved > 0L) {
						for (ReservationTO reserObj : disruptiveApprovedList) {
							reserObj.setIsconflicting(1L);
							getHibernateTemplate().update(reserObj);
						}
						reservation.setIsconflicting(1L);
						if (!reservation.isUpdateFlag()) {
							if ((reservation.getIsRepetetive() != 1L) || (reservation.isMakeReservation() == false)) {
								makereservation(reservation);
							}
						}
						messageFlag = 2L;
						return messageFlag;
					}
				} else if ((countSharedApproved > 0L) || (countDisruptiveApproved > 0L)) {
					for (ReservationTO reserObj : disruptiveApprovedList) {
						reserObj.setIsconflicting(1L);
						getHibernateTemplate().update(reserObj);
					}
					for (ReservationTO reserObj : sharedApprovedList) {
						reserObj.setIsconflicting(1L);
						getHibernateTemplate().update(reserObj);
					}
					reservation.setIsconflicting(1L);
					if (!reservation.isUpdateFlag()) {
						if ((reservation.getIsRepetetive() != 1L) || (reservation.isMakeReservation() == false)) {
							makereservation(reservation);
						}
					}
					messageFlag = 2L;
					return messageFlag;
				} else {
					reservation.setIsconflicting(0L);
					if (!reservation.isUpdateFlag()) {
						if ((reservation.getIsRepetetive() != 1L) || (reservation.isMakeReservation() == false)) {
							makereservation(reservation);
						}
					}
					messageFlag = 1L;
					return messageFlag;
				}
			}
		}
		return messageFlag;
	}
	
	public int getSharedMaxCount() throws CMMException {
	
		try {

			List<GlobalParametersTO> globalParametersList = (List<GlobalParametersTO>) getHibernateTemplate().find("from GlobalParametersTO where parameterName=? ",CMMConstants.Framework.ReservationStatus.RESERVATION_MAX_COUNT);
			int count = 0;
			if (!globalParametersList.isEmpty()) {
				GlobalParametersTO globalParameter = globalParametersList.get(0);
				count = Integer.parseInt(globalParameter.getParameterValue());
			}
			return count;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getRelease.", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getRelease.", he);
		}
	}
	
	@Override
	public List<EnvironmentTO> getAllEnvironmentsDrivenByEnv(Long selectedProject, Long clientId, Long userId) throws CMMException {
	
		List<EnvironmentTO> environmentList = new ArrayList<EnvironmentTO>(0);
		try {
			EnvironmentTO environment = null;
			String query1 = "SELECT e.environmentName,e.id FROM  EnvironmentTO e,ApplicationTO a, EnvironmentApplicationTO ea  where a.selectedProject =? and a.id = ea.applicationTO.id  and ea.environmentTO.id =e.id  and a.businessUnitTO.clientId=? and e.status=? group by e.id , e.environmentName";
			List<Object[]> objList = (List<Object[]>) getHibernateTemplate().find(query1, selectedProject, clientId, CMMConstants.Framework.Entity.ENVIRONMENT_AVAILABLE);
			for (Object[] env : objList) {
				environment = new EnvironmentTO();
				environment.setName((String) env[0]);
				environment.setId((Long) env[1]);
				environmentList.add(environment);
			}
			return environmentList;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getAllEnvironmentsDrivenByEnv.", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getAllEnvironmentsDrivenByEnv.", he);
		}
	}
	
	@Override
	public List<ApplicationTO> getAllApplicationsDrivenByEnv(Long environmentId, Long clientId, Long projectId, List<UserGroupTO> userGroupIds, Long userClientId) throws CMMException {
	
		Session session = null;
		List<ApplicationTO> applicationList = new ArrayList<ApplicationTO>(0);
		try {
			ApplicationTO application = null;
			List<Long> grpIds = new ArrayList<Long>();
			Transaction tx = null;
			session = getSession();
			tx = session.beginTransaction();
			Query q = null;
			if (userClientId == 0L) {
				String hql = "select a.id , a.appName  FROM ApplicationTO a where a.id in (select a.id from ApplicationTO a , EnvironmentApplicationTO ea   where  a.businessUnitTO.id=:clientId  and a.projectTO.id=:projectId and a.status=:status and ea.environmentTO.id =:environmentId and  ea.applicationTO.id = a.id)";
				q = session.createQuery(hql);
				q.setParameter("environmentId", environmentId);
				q.setParameter("projectId", projectId);
				q.setParameter("clientId", clientId);
				q.setParameter("status", CMMConstants.Framework.Entity.APPLICATION_AVAILABLE);
			} else {
				for (UserGroupTO groupTO : userGroupIds) {
					grpIds.add(groupTO.getId());
				}
				if (grpIds.isEmpty()) {
					grpIds.add(-1L);
				}
				String hql = "select a.id , a.appName FROM ApplicationTO a , EnvironmentApplicationTO ea where a.id in (select a.id from ApplicationTO a inner join a.userGroups u where u.id in (:grpId) and a.businessUnitTO.id=:clientId  and a.projectTO.id=:projectId and a.status=:status) and ea.environmentTO.id =:environmentId and ea.applicationTO.id = a.id)";
				q = session.createQuery(hql);
				q.setParameter("projectId", projectId);
				q.setParameter("environmentId", environmentId);
				q.setParameterList("grpId", grpIds);
				q.setParameter("clientId", clientId);
				q.setParameter("status", CMMConstants.Framework.Entity.APPLICATION_AVAILABLE);
			}
			List<Object[]> objList = q.list();
			tx.commit();
			for (Object[] app : objList) {
				application = new ApplicationTO();
				application.setId((Long) app[0]);
				application.setName(app[1].toString());
				applicationList.add(application);
			}
			return applicationList;
		} catch (DataAccessException dae) {
			logger.error("Error in accessing data from database ", dae);
			throw new CMMException("Can not access database. ReservationDAOImpl : getAllApplicationsDrivenByEnv.", dae);
		} catch (HibernateException he) {
			logger.error("Error in fetching data from database ", he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getAllApplicationsDrivenByEnv.", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	public void updateReservationDetails(ReservationTO reservationTO) throws CMMException {
	
		Session session = null;
		try {
			Long conf = isConflicting(reservationTO);
			if (conf != 0) {
				String hql =String.format("from ReservationTO where id=%d",conf);
				ReservationTO reser = (ReservationTO) getHibernateTemplate().find(hql).get(0);
				reser.setIsconflicting(1L);
				getHibernateTemplate().update(reser);
			}
			String hql1 =String.format("from ReservationTO where id=%d",reservationTO.getId());
			ReservationTO reservationNew = (ReservationTO) getHibernateTemplate().find(hql1).get(0);
			reservationNew.setEnvironmentId(reservationTO.getEnvironmentId());
			reservationNew.setStartTime(reservationTO.getStartTime());
			reservationNew.setEndTime(reservationTO.getEndTime());
			reservationNew.setReleaseDate(reservationTO.getReleaseDate());
			reservationNew.setTestingCycle(reservationTO.getTestingCycle());
			reservationNew.setTestingType(reservationTO.getTestingType());
			reservationNew.setDisruptive(reservationTO.getDisruptive());
			reservationNew.setIsconflicting(reservationTO.getIsconflicting());
			String hql2 =String.format("from StatusTO where id=%d",reservationTO.getStatus().getId());
			StatusTO status = (StatusTO) getHibernateTemplate().find(hql2).get(0);
			reservationNew.setStatus(status);
			getHibernateTemplate().update(reservationNew);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : updateReservationDetails.", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : updateReservationDetails.", he);
		} catch (Exception e) {
			logger.error(e);
			throw new CMMException("Problem encountered. ReservationDAOImpl : updateReservationDetails.", e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public Long getWorkflowLevelID(Long res) {
	
		Long work_flow_id = 0L;
		String hql1 =String.format("from WorkflowCurrentTO where entity_id=%d ",res);
		List<WorkflowCurrentTO> work_id = (List<WorkflowCurrentTO>) getHibernateTemplate().find(hql1);
		for (WorkflowCurrentTO work : work_id) {
			work_flow_id = work.getReqId();
		}
		return work_flow_id;
	}
	
	public List<ReservationTO> getApproved(ReservationTO reservation, Long id) throws CMMException {
	
		try {
			List<ReservationTO> appList = new ArrayList<ReservationTO>();
			if (reservation.getDisruptive().equalsIgnoreCase(CMMConstants.Framework.ReservationStatus.RESERVATION_SHARED)) {
				String query = "select r from ReservationTO as r where r.environments.id =?  and ((r.startTime <= ? and r.endTime >= ? and r.endTime <= ?) or (r.endTime >= ? and r.startTime >= ? and r.startTime <= ?) or (r.startTime <= ? and r.endTime >= ?) or (r.startTime >= ? and r.startTime <= ? and r.endTime >= ? and r.endTime <= ?)) and (r.startTime != ? and r.endTime != ?) and disruptive IN('D','L') and  r.status.id =81 and  r.id !=?";
				appList = (List<ReservationTO>) getHibernateTemplate().find(query, reservation.getEnvironments().getId(), reservation.getStartTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getEndTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getEndTime(), reservation.getStartTime(), id);
			} else {
				String query = "select r from ReservationTO as r where r.environments.id =?  and ((r.startTime <= ? and r.endTime >= ? and r.endTime <= ?) or (r.endTime >= ? and r.startTime >= ? and r.startTime <= ?) or (r.startTime <= ? and r.endTime >= ?) or (r.startTime >= ? and r.startTime <= ? and r.endTime >= ? and r.endTime <= ?)) and (r.startTime != ? and r.endTime != ?) and r.status.id =81 and  r.id !=?";
				appList = (List<ReservationTO>) getHibernateTemplate().find(query, reservation.getEnvironments().getId(), reservation.getStartTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getEndTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getEndTime(), reservation.getStartTime(), id);
			}
			return appList;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getApprovedList", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getApprovedList.", he);
		}
	}
	
	private void setConflictingFlag(ReservationTO pending) {
	
		ReservationTO reservationNew = (ReservationTO) getHibernateTemplate().find("from ReservationTO where id=?", pending.getId()).get(0);
		reservationNew.setIsconflicting(0L);
		getHibernateTemplate().update(reservationNew);
	}
	
	public List<ReservationTO> getPending(ReservationTO reservation) throws CMMException {
	
		try {
			List<ReservationTO> reser = new ArrayList<ReservationTO>();
			if (reservation.getDisruptive().equalsIgnoreCase(CMMConstants.Framework.ReservationStatus.RESERVATION_SHARED)) {
				String query = "select r from ReservationTO as r where r.environments.id =?  and ((r.startTime <= ? and r.endTime >= ? and r.endTime <= ?) or (r.endTime >= ? and r.startTime >= ? and r.startTime <= ?) or (r.startTime <= ? and r.endTime >= ?) or (r.startTime >= ? and r.startTime <= ? and r.endTime >= ? and r.endTime <= ?)) and (r.startTime != ? and r.endTime != ?) and r.status.id =84 and disruptive IN('D','L') and isConflicting=1 and r.id !=?";
				reser = (List<ReservationTO>) getHibernateTemplate().find(query, reservation.getEnvironments().getId(), reservation.getStartTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getEndTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getEndTime(), reservation.getStartTime(), reservation.getId());
			} else if (reservation.getDisruptive().equalsIgnoreCase(CMMConstants.Framework.ReservationStatus.RESERVATION_LOCKED) || reservation.getDisruptive().equalsIgnoreCase(CMMConstants.Framework.ReservationStatus.RESERVATION_DISRUPTIVE)) {
				String query = "select r from ReservationTO as r where r.environments.id =?  and ((r.startTime <= ? and r.endTime >= ? and r.endTime <= ?) or (r.endTime >= ? and r.startTime >= ? and r.startTime <= ?) or (r.startTime <= ? and r.endTime >= ?) or (r.startTime >= ? and r.startTime <= ? and r.endTime >= ? and r.endTime <= ?)) and (r.startTime != ? and r.endTime != ?) and r.status.id =84 and isConflicting=1 and r.id !=?";
				reser = (List<ReservationTO>) getHibernateTemplate().find(query, reservation.getEnvironments().getId(), reservation.getStartTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getEndTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getEndTime(), reservation.getStartTime(), reservation.getId());
			}
			return reser;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getPendingList", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getPendingList.", he);
		}
	}
	
	@Override
	public List<ReservationTO> getPendingReservations(UserTO userTo, List<Long> clientIdlist) throws CMMException {
	
		DetachedCriteria criteria = DetachedCriteria.forClass(ReservationTO.class, "reservation");
		try {
			if (userTo.getClientId() != 0) {
				if (userTo.getRoleId() != 1) {
					criteria.add(Restrictions.eq("reservation.users.id", userTo.getId()));
				} else {
					DetachedCriteria criteria1 = DetachedCriteria.forClass(UserBusinessUnitTO.class, "userbusinessUnit");
					criteria1.add(Restrictions.in("clientId", clientIdlist));
					List<UserBusinessUnitTO> userbuList = (List<UserBusinessUnitTO>) getHibernateTemplate().findByCriteria(criteria1);
					List<Long> userIdList = new ArrayList<Long>();
					for (UserBusinessUnitTO u : userbuList) {
						userIdList.add(u.getUser().getId());
					}
					DetachedCriteria criteria2 = DetachedCriteria.forClass(ApplicationTO.class, "application");
					criteria2.add(Restrictions.in("application.businessUnitTO.id", clientIdlist));
					List<ApplicationTO> applicationList = (List<ApplicationTO>) getHibernateTemplate().findByCriteria(criteria2);
					List<Long> appList = new ArrayList<Long>();
					for (ApplicationTO u : applicationList) {
						appList.add(u.getId());
					}
					criteria.add(Restrictions.in("reservation.users.id", userIdList));
					criteria.add(Restrictions.in("reservation.applications.id", appList));
				}
			}
			Date currentDate = DateUtils.getStartTime(new Date());
			DateUtils.addDays(currentDate, 1);
			criteria.add(Restrictions.gt("endTime", currentDate));
			criteria.add(Restrictions.eq("status.id", Entity.RESERVATION_STATUS_PENDING));
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getPendingReservations", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getPendingReservations", he);
		}
		List<ReservationTO> pendingList = (List<ReservationTO>) getHibernateTemplate().findByCriteria(criteria);
		for (ReservationTO r : pendingList) {
			if (r.getReleasePlan() != null) {
				String releaseName = (String) getHibernateTemplate().find("select name from ReleasePlanningTO where id=?", r.getReleasePlan()).get(0);
				r.setReleasePlanName(releaseName);
			} else {
				r.setReleasePlanName("NA");
			}
			if (r.getTestingPhase() != null) {
				String phaseName = (String) getHibernateTemplate().find("select name from TestingPhaseTO where id=?", r.getTestingPhase()).get(0);
				r.setTestingPhaseName(phaseName);
			} else {
				r.setTestingPhaseName("NA");
			}
		}
		return pendingList;
	}
	
	@Override
	public List<ReservationTO> getRejectedReservations(UserTO userTo, List<Long> clientIdlist) throws CMMException {
	
		DetachedCriteria criteria = DetachedCriteria.forClass(ReservationTO.class, "reservation");
		DetachedCriteria criteriaRejected = DetachedCriteria.forClass(ReservationTO.class, "reservation");
		List<ReservationTO> reservationListPending = new ArrayList<ReservationTO>();
		List<ReservationTO> reservationListRejected = new ArrayList<ReservationTO>();
		List<ReservationTO> reservationList = new ArrayList<ReservationTO>();
		List<Long> statusList = new ArrayList<Long>();
		try {
			if (userTo.getClientId() != 0) {
				if (userTo.getRoleId() != 1) {
					criteria.add(Restrictions.eq("reservation.users.id", userTo.getId()));
					criteriaRejected.add(Restrictions.eq("reservation.users.id", userTo.getId()));
				} else {
					DetachedCriteria criteria1 = DetachedCriteria.forClass(UserBusinessUnitTO.class, "userbusinessUnit");
					criteria1.add(Restrictions.in("clientId", clientIdlist));
					List<UserBusinessUnitTO> userbuList = (List<UserBusinessUnitTO>) getHibernateTemplate().findByCriteria(criteria1);
					List<Long> userIdList = new ArrayList<Long>();
					for (UserBusinessUnitTO u : userbuList) {
						userIdList.add(u.getUser().getId());
					}
					DetachedCriteria criteria2 = DetachedCriteria.forClass(ApplicationTO.class, "application");
					criteria2.add(Restrictions.in("application.businessUnitTO.id", clientIdlist));
					List<ApplicationTO> applicationList = (List<ApplicationTO>) getHibernateTemplate().findByCriteria(criteria2);
					List<Long> appList = new ArrayList<Long>();
					for (ApplicationTO u : applicationList) {
						appList.add(u.getId());
					}
					criteria.add(Restrictions.in("reservation.users.id", userIdList));
					criteria.add(Restrictions.in("reservation.applications.id", appList));
					criteriaRejected.add(Restrictions.in("reservation.users.id", userIdList));
					criteriaRejected.add(Restrictions.in("reservation.applications.id", appList));
				}
			}
			Date currentDate = DateUtils.getStartTime(new Date());
			DateUtils.addDays(currentDate, 1);
			criteria.add(Restrictions.le("endTime", currentDate));
			statusList.add(Entity.RESERVATION_STATUS_PENDING);
			statusList.add(Entity.RESERVATION_STATUS_CONFLICTING);
			criteria.add(Restrictions.in("status.id", statusList));
			reservationListPending = (List<ReservationTO>) getHibernateTemplate().findByCriteria(criteria);
			criteriaRejected.add(Restrictions.eq("status.id", Entity.RESERVATION_STATUS_REJECTED));
			reservationListRejected = (List<ReservationTO>) getHibernateTemplate().findByCriteria(criteriaRejected);
			reservationList.addAll(reservationListPending);
			reservationList.addAll(reservationListRejected);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getRejectedReservations", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getRejectedReservations", he);
		}
		List<ReservationTO> rejectedList = reservationList;
		for (ReservationTO r : rejectedList) {
			if (r.getReleasePlan() != null) {
				String releaseName = (String) getHibernateTemplate().find("select name from ReleasePlanningTO where id=?", r.getReleasePlan()).get(0);
				r.setReleasePlanName(releaseName);
			} else {
				r.setReleasePlanName("NA");
			}
			if (r.getTestingPhase() != null) {
				String phaseName = (String) getHibernateTemplate().find("select name from TestingPhaseTO where id=?", r.getTestingPhase()).get(0);
				r.setTestingPhaseName(phaseName);
			} else {
				r.setTestingPhaseName("NA");
			}
		}
		return rejectedList;
	}
	
	@Override
	public Long getPendingReservationCount(long clientId, List<Long> clientIdlist, ReservationTO reservationTO) throws CMMException {
	
		Query q = null;
		Session session = null;
		try {
			session = getSession();
			Date currentDate = DateUtils.getStartTime(new Date());
			DateUtils.addDays(currentDate, 1);
			String hql = "SELECT r.id FROM ReservationTO r ";
			hql = hql + " where r.status.id = :statusId";
			hql = hql + " and  r.endTime > :startDate ";
			if (reservationTO.getEnvironmentValue() != null) {
				hql = hql + " and r.environments.id in (" + reservationTO.getEnvironmentValue() + ")";
			}
			if (!((reservationTO.getUserId() == 1) || (reservationTO.getUsers().getRoleId() == 1))) {
				hql = hql + " and r.userId in (" + reservationTO.getUserId() + ")";
			}
			if (reservationTO.getApplicationValue() != null) {
				hql = hql + " and r.applications.id in (" + reservationTO.getApplicationValue() + ")";
			}
			if (!(clientId == 0)) {
				hql = hql + " and r.applications.id in (select a.id from ApplicationTO a where a.businessUnitTO.id in(:clientid)) ";
			}
			q = session.createQuery(hql);
			q.setParameter("statusId", Entity.RESERVATION_STATUS_PENDING);
			q.setParameter("startDate", currentDate);
			if (!(clientId == 0)) {
				q.setParameterList("clientid", clientIdlist);
			}
			return (long) q.list().size();
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getPendingReservationCount", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getPendingReservationCount", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public Long getRejectedReservationCount(long clientId, List<Long> clientIdlist, ReservationTO reservationTO) throws CMMException {
	
		Query q = null;
		Session session = null;
		try {
			session = getSession();
			Date currentDate = DateUtils.getStartTime(new Date());
			DateUtils.addDays(currentDate, 1);
			String hql = "SELECT r.id FROM ReservationTO r ";
			hql = hql + " where (r.status.id in ( :statusId) or (r.status.id in( :statusPendingId)";
			hql = hql + " and  r.endTime <= :startDate)) ";
			if (reservationTO.getEnvironmentValue() != null) {
				hql = hql + " and r.environments.id in (" + reservationTO.getEnvironmentValue() + ")";
			}
			if (!((reservationTO.getUserId() == 1) || (reservationTO.getUsers().getRoleId() == 1))) {
				hql = hql + " and r.userId in (" + reservationTO.getUserId() + ")";
			}
			if (reservationTO.getApplicationValue() != null) {
				hql = hql + " and r.applications.id in (" + reservationTO.getApplicationValue() + ")";
			}
			if (!(clientId == 0)) {
				hql = hql + " and r.applications.id in (select a.id from ApplicationTO a where a.businessUnitTO.id in(:clientid)) ";
			}
			q = session.createQuery(hql);
			List<Long> statusPendingId = new ArrayList<Long>();
			statusPendingId.add(Entity.RESERVATION_STATUS_PENDING);
			statusPendingId.add(Entity.RESERVATION_STATUS_CONFLICTING);
			q.setParameter("statusId", Entity.RESERVATION_STATUS_REJECTED);
			q.setParameterList("statusPendingId", statusPendingId);
			q.setParameter("startDate", currentDate);
			if (!(clientId == 0)) {
				q.setParameterList("clientid", clientIdlist);
			}
			return (long) q.list().size();
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getRejectedReservationCount", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getRejectedReservationCount", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public Long getCancelledReservationCount(long clientId, List<Long> clientIdlist, ReservationTO reservationTO) throws CMMException {
	
		Query q = null;
		Session session = null;
		try {
			session = getSession();
			Date currentDate = DateUtils.getStartTime(new Date());
			DateUtils.addDays(currentDate, 1);
			String hql = "SELECT r.id FROM ReservationTO r ";
			hql = hql + " where r.status.id  in( :statusId)";
			if (!((reservationTO.getUserId() == 1) || (reservationTO.getUsers().getRoleId() == 1))) {
				hql = hql + " and r.userId in (" + reservationTO.getUserId() + ")";
			}
			if (!(clientId == 0)) {
				hql = hql + " and r.applications.id in (select a.id from ApplicationTO a where a.businessUnitTO.id in(:clientid)) ";
			}
			q = session.createQuery(hql);
			q.setParameter("statusId", Entity.RESERVATION_STATUS_INACTIVE);
			if (!(clientId == 0)) {
				q.setParameterList("clientid", clientIdlist);
			}
			return (long) q.list().size();
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getCancelledReservationCount", dae);
		} catch (Exception he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getCancelledReservationCount", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<ReservationTO> getCancelledReservation(UserTO userTo, List<Long> clientIdlist) throws CMMException {
	
		DetachedCriteria criteria = DetachedCriteria.forClass(ReservationTO.class, "reservation");
		try {
			if (userTo.getClientId() != 0) {
				if (userTo.getRoleId() != 1) {
					criteria.add(Restrictions.eq("reservation.users.id", userTo.getId()));
				} else {
					DetachedCriteria criteria1 = DetachedCriteria.forClass(UserBusinessUnitTO.class, "userbusinessUnit");
					criteria1.add(Restrictions.in("clientId", clientIdlist));
					List<UserBusinessUnitTO> userbuList = (List<UserBusinessUnitTO>) getHibernateTemplate().findByCriteria(criteria1);
					List<Long> userIdList = new ArrayList<Long>();
					for (UserBusinessUnitTO u : userbuList) {
						userIdList.add(u.getUser().getId());
					}
					DetachedCriteria criteria2 = DetachedCriteria.forClass(ApplicationTO.class, "application");
					criteria2.add(Restrictions.in("application.businessUnitTO.id", clientIdlist));
					List<ApplicationTO> applicationList = (List<ApplicationTO>) getHibernateTemplate().findByCriteria(criteria2);
					List<Long> appList = new ArrayList<Long>();
					for (ApplicationTO u : applicationList) {
						appList.add(u.getId());
					}
					criteria.add(Restrictions.in("reservation.users.id", userIdList));
					criteria.add(Restrictions.in("reservation.applications.id", appList));
				}
			}
			Date currentDate = DateUtils.getStartTime(new Date());
			DateUtils.addDays(currentDate, 1);
			criteria.add(Restrictions.eq("status.id", Entity.RESERVATION_STATUS_INACTIVE));
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getCancelledReservation", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getCancelledReservation", he);
		}
		List<ReservationTO> cancelledList = (List<ReservationTO>) getHibernateTemplate().findByCriteria(criteria);
		for (ReservationTO r : cancelledList) {
			if (r.getReleasePlan() != null) {
				String hql1 =String.format("select name from ReleasePlanningTO where id=%d",r.getReleasePlan());
				String releaseName = (String) getHibernateTemplate().find(hql1).get(0);
				r.setReleasePlanName(releaseName);
			} else {
				r.setReleasePlanName("NA");
			}
			if (r.getTestingPhase() != null) {
				String hql=String.format("select name from TestingPhaseTO where id=%d",r.getTestingPhase());
				String phaseName = (String) getHibernateTemplate().find(hql).get(0);
				r.setTestingPhaseName(phaseName);
			} else {
				r.setTestingPhaseName("NA");
			}
		}
		return cancelledList;
	}
	
	@Override
	public List<StatusTO> getStatusList() throws CMMException {
	
		try {
			return (List<StatusTO>) getHibernateTemplate().find("from StatusTO where entityId=?", CMMConstants.Framework.Entity.RESERVATION);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getStatusList", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getStatusList", he);
		}
	}
	
	@Override
	public String getReservationToDate(Long resId) throws CMMException {
	
		try {
			Timestamp tp = (Timestamp) getHibernateTemplate().find("select endTime from ReservationTO where id=?", resId).get(0);
			DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
			return df.format(tp);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.ReservationDAOImpl : getReservationToDate", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.ReservationDAOImpl : getReservationToDate", he);
		}
	}
	
	@Override
	public Long repetetiveReservation(ReservationTO reservation, List<ReservationTO> represerv) throws CMMException {
	
		Long countConf = 0L;
		Long parentflag = 0L;
		List<ReservationTO> messageReserve = new ArrayList<ReservationTO>();
		ReservationTO ParentReserv = new ReservationTO();//Parent reservation
		try {
			reservation.setMakeReservation(true);
			Long msgflg = reserveEnvironment(reservation);
			int length = represerv.size();
			if (msgflg != 0L) {
				ParentReserv.setMessageFlg(msgflg);
				ParentReserv.setStartTime(reservation.getStartTime());
				ParentReserv.setEndTime(reservation.getEndTime());
				ParentReserv.setIsconflicting(reservation.getIsconflicting());
				if (reservation.getIsconflicting() == 1L) {
					countConf++;
				}
				s: for (ReservationTO reserv : represerv) {
					ReservationTO re = new ReservationTO();
					reservation.setStartTime(reserv.getListStartDate());
					reservation.setEndTime(reserv.getListEndDate());
					Long msgflg1 = reserveEnvironment(reservation);
					if (msgflg1 == 0L) {
						parentflag = 0L;
						break s;
					} else {
						re.setMessageFlg(msgflg1);
						re.setStartTime(reservation.getStartTime());
						re.setEndTime(reservation.getEndTime());
						re.setIsconflicting(reservation.getIsconflicting());
						if (reservation.getIsconflicting() == 1L) {
							countConf++;
						}
						messageReserve.add(re);
					}
				}//for
				reservation.setCountConf(countConf);
				if (messageReserve.size() == length) {
					reservation.setStartTime(ParentReserv.getStartTime());
					reservation.setEndTime(ParentReserv.getEndTime());
					reservation.setIsconflicting(ParentReserv.getIsconflicting());
					reservation.setMessageFlg(ParentReserv.getMessageFlg());
					makereservation(reservation);
					reservation.setChildFlow(1L);
					Long resId = reservation.getId();
					for (ReservationTO reservationRep : messageReserve) {
						reservationRep.getMessageFlg();
						reservation.setIsRepetetive(0L);
						reservation.setStartTime(reservationRep.getStartTime());
						reservation.setEndTime(reservationRep.getEndTime());
						reservation.setParentId(resId);
						reservation.setIsconflicting(reservationRep.getIsconflicting());
						reservation.setMessageFlg(reservationRep.getMessageFlg());
						makereservation(reservation);
						parentflag++;
					}//for
				}//if
			}//if
			return parentflag;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getUserRoles", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getUserRoles", he);
		}
	}
	
	public List<ReservationTO> checkResvInConflictAfterApproval(ReservationTO reservationTO) throws CMMException {
	
		Date startTimeReferenceFuture = DateUtils.parsejQueryDateTime(reservationTO.getStartTimeString());
		Date endTimeReferenceFuture = DateUtils.parsejQueryDateTime(reservationTO.getEndTimeString());
		String mode = reservationTO.getDisruptive();
		List<ReservationTO> reservation = new ArrayList<ReservationTO>();
		DetachedCriteria criteria = DetachedCriteria.forClass(ReservationTO.class, "res");
		criteria.add(Restrictions.eq("res.environments.id", reservationTO.getEnvironmentId()));
		criteria.add(Restrictions.eq("res.status.id", Entity.RESERVATION_STATUS_PENDING));
		criteria.add(Restrictions.disjunction().add(Restrictions.conjunction().add(Property.forName("res.startTime").ge(startTimeReferenceFuture)).add(Property.forName("res.endTime").le(endTimeReferenceFuture))).add(Restrictions.conjunction().add(Property.forName("res.startTime").le(startTimeReferenceFuture)).add(Property.forName("res.endTime").ge(endTimeReferenceFuture))).add(Restrictions.conjunction().add(Property.forName("res.startTime").le(startTimeReferenceFuture)).add(Property.forName("res.endTime").gt(startTimeReferenceFuture))).add(Restrictions.conjunction().add(Property.forName("res.startTime").lt(endTimeReferenceFuture)).add(Property.forName("res.endTime").ge(endTimeReferenceFuture))));
		criteria.add(Restrictions.ne("res.id", reservationTO.getId()));
		if (mode.equals(CMMConstants.Framework.ReservationStatus.SHARED)) {
			criteria.add(Restrictions.ne("res.disruptive", CMMConstants.Framework.ReservationStatus.RESERVATION_SHARED));
		}
		reservation = (List<ReservationTO>) getHibernateTemplate().findByCriteria(criteria);
		return reservation;
	}
	
	@Override
	public Long getuserId(Long id) throws CMMException {
	
		try {
			ReservationTO res = (ReservationTO) getHibernateTemplate().find("from ReservationTO where id=?", id).get(0);
			return res.getUserId();
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getuserId.", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getuserId.", he);
		}
	}
	
	@Override
	public boolean getLockedStatusForTheDurationForUpdate(ReservationTO reservation) throws CMMException {
	
		try {
			String query = "select r from ReservationTO as r where r.environments.id =?  and ((r.startTime <= ? and r.endTime >= ? and r.endTime <= ?) or (r.endTime >= ? and r.startTime >= ? and r.startTime <= ?) or (r.startTime <= ? and r.endTime >= ?) or (r.startTime >= ? and r.startTime <= ? and r.endTime >= ? and r.endTime <= ?)) and r.status.id=? and r.disruptive=?";
			List<ReservationTO> lockedReservationTO = (List<ReservationTO>) getHibernateTemplate().find(query, reservation.getEnvironmentId(), reservation.getStartTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getEndTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getStartTime(), reservation.getEndTime(), reservation.getStartTime(), reservation.getEndTime(), CMMConstants.Framework.Entity.RESERVATION_STATUS_APPROVED, CMMConstants.Framework.ReservationStatus.RESERVATION_LOCKED);
			boolean lockStatus = false;
			if (!lockedReservationTO.isEmpty()) {
				if (lockedReservationTO.size() == 1) {
					if (lockedReservationTO.get(0).getId().equals(reservation.getId())) {
						lockStatus = false;
					} else {
						lockStatus = true;
					}
				} else {
					lockStatus = true;
				}
			}
			return lockStatus;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getCountofSharedReservation.", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ReservationDAOImpl : getCountofSharedReservation.", he);
		}
	}
	
	@Override
	public List<ReservationTO> getChildReservationByParentID(Long id) throws CMMException {
	
		try {
			List<ReservationTO> childList = new ArrayList<ReservationTO>();
			String query1 = "select c.name,p.name,r from ReservationTO r, ApplicationTO a, ClientTO c, ProjectsTO p where r.applications.id = a.id and a.businessUnitTO.id = c.id and a.projectTO = p.id and r.parentId=?";
			List<Object[]> resvDetailsObj = (List<Object[]>) getHibernateTemplate().find(query1, id);
			for (Object[] o : resvDetailsObj) {
				ReservationTO resvDetails = (ReservationTO) o[2];
				resvDetails.setClientName((String) o[0]);
				resvDetails.setProjectName((String) o[1]);
				childList.add(resvDetails);
			}
			return childList;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.ReservationDAOImpl : getChildReservationByParentID", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.ReservationDAOImpl : getChildReservationByParentID", he);
		}
	}
	
	@Override
	public ReservationMailTO getMailContent(Long status) throws CMMException {
	
		try {
			return (ReservationMailTO) getHibernateTemplate().find("from ReservationMailTO where status=?", status).get(0);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.ReservationDAOImpl : getMailContent", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.ReservationDAOImpl : getMailContent", he);
		}
	}
	
	@Override
	public String getBUNameForApplication(Long id) throws CMMException {
	
		String clientName = null;
		try {
			String query = "select b.name from ApplicationTO a inner join a.businessUnitTO b  where a.id=?";
			clientName = (String) getHibernateTemplate().find(query, id).get(0);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.ReservationDAOImpl : getBUNameForApplication", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.ReservationDAOImpl : getBUNameForApplication", he);
		}
		return clientName;
	}
	
	public boolean checkexistConflicts(ReservationTO reservationTO) throws CMMException {
	
		int counter = 0;
		boolean checkExist = false;
		boolean chkRejection = false;
		List<ReservationTO> reservation1 = new ArrayList<ReservationTO>();
		List<ReservationTO> reservation2 = new ArrayList<ReservationTO>();
		Date actualStartDate = reservationTO.getStartTime();
		Date actualEndDate = reservationTO.getEndTime();
		if (reservationTO.getStatusDesc().equals(CMMConstants.Framework.TopologyStatus.RESERVED)) {
			for (int i = 0; i < reservationTO.getAllIdsList().size(); i++) {
				if (!reservationTO.getId().equals(reservationTO.getAllIdsList().get(i).getId())) {
					if (reservationTO.getAllIdsList().get(i).getStatusDesc().equals(CMMConstants.Framework.TopologyStatus.RESERVED)) {
						reservationTO.getAllIdsListApproved().add(reservationTO.getAllIdsList().get(i));
					}
				}
			}
		} else {
			reservationTO.setAllIdsListApproved(reservationTO.getAllIdsList());
		}
		for (int i = 0; i < reservationTO.getAllIdsListApproved().size(); i++) {
			for (int j = 0; j < reservationTO.getSelectedReservationIDsRejection().size(); j++) {
				if (reservationTO.getAllIdsListApproved().get(i).getId().equals(reservationTO.getSelectedReservationIDsRejection().get(j))) {
					chkRejection = true;
				} else {
					chkRejection = false;
				}
			}
			if (!chkRejection) {
				Date refStartDate = DateUtils.parsejQueryDateTime(reservationTO.getAllIdsListApproved().get(i).getStartTimeString());
				Date refEndDate = DateUtils.parsejQueryDateTime(reservationTO.getAllIdsListApproved().get(i).getEndTimeString());
				if (!reservationTO.getId().equals(reservationTO.getAllIdsListApproved().get(i).getId())) {
					if (((refStartDate.after(actualStartDate) || refStartDate.equals(actualStartDate)) && (refEndDate.before(actualEndDate) || refEndDate.equals(actualEndDate))) || ((refStartDate.before(actualStartDate) || refStartDate.equals(actualStartDate)) && (refEndDate.after(actualEndDate) || refEndDate.equals(actualEndDate))) || ((refStartDate.before(actualStartDate) || refStartDate.equals(actualStartDate)) && refEndDate.after(actualStartDate)) || (refStartDate.before(actualEndDate) && (refEndDate.after(actualEndDate) || refEndDate.equals(actualEndDate)))) {
						if ("Shared".equals(reservationTO.getAllIdsListApproved().get(i).getDisruptive())) {
							reservation1.add(reservationTO.getAllIdsListApproved().get(i));
						}
					}
				}
			}//rejection if
		}//outerfor
		if (reservation1.size() >= getSharedMaxCount()) {
			reservation2 = reservation1;
			l: for (int i = 0; i < reservation1.size(); i++) {
				Date actualStartDate1 = DateUtils.parsejQueryDateTime(reservation1.get(i).getStartTimeString());
				Date actualEndDate1 = DateUtils.parsejQueryDateTime(reservation1.get(i).getEndTimeString());
				for (int j = 0; j < reservation2.size(); j++) {
					Date refStartDate1 = DateUtils.parsejQueryDateTime(reservation2.get(j).getStartTimeString());
					Date refEndDate1 = DateUtils.parsejQueryDateTime(reservation2.get(j).getEndTimeString());
					if (!reservation1.get(i).getId().equals(reservation2.get(j).getId())) {
						if (((refStartDate1.after(actualStartDate1) || refStartDate1.equals(actualStartDate1)) && (refEndDate1.before(actualEndDate1) || refEndDate1.equals(actualEndDate1))) || ((refStartDate1.before(actualStartDate1) || refStartDate1.equals(actualStartDate1)) && (refEndDate1.after(actualEndDate1) || refEndDate1.equals(actualEndDate1))) || ((refStartDate1.before(actualStartDate1) || refStartDate1.equals(actualStartDate1)) && refEndDate1.after(actualStartDate1)) || (refStartDate1.before(actualEndDate1) && (refEndDate1.after(actualEndDate1) || refEndDate1.equals(actualEndDate1)))) {
							counter++;
							if (counter > 0) {
								break l;
							}
						}
					}
				}
			}
			if (counter > 0) {
				checkExist = true;
			}
		}
		return checkExist;
	}
	
	@Override
	public boolean isEnvironmentEndDateBeforeReservationEndDate(Long envId, Date reservationEndDate) throws CMMException {
	
		Object environmentEndDate = null;
		Date environmentEndDate2 = null;
		List<String> endDate;
		try {
			String query = "select r.endTime from ServiceRequestTO r where r.serviceId=1 and r.environmentId=?";
			endDate = (List<String>) getHibernateTemplate().find(query, envId);
			if (!endDate.isEmpty()) {
				environmentEndDate = endDate.get(0);
			} else {
				String queryTemp = "select distinct s.environmentId from SubEnvironmentMappingTO s where s.subEnvronmentId=?";
				List<Long> id = (List<Long>) getHibernateTemplate().find(queryTemp, envId);
				Long envId1 = id.get(0);
				String query1 = "select r.endTime from ServiceRequestTO r where r.serviceId=12 and r.environmentId=?";
				endDate = (List<String>) getHibernateTemplate().find(query1, envId1);
				if (!endDate.isEmpty()) {
					environmentEndDate = endDate.get(0);
				}
			}
			if (environmentEndDate instanceof Date) {
				environmentEndDate2 = (Date) environmentEndDate;
			}
			if ((environmentEndDate2 != null) && environmentEndDate2.before(reservationEndDate)) {
				return true;
			} else {
				return false;
			}
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.ReservationDAOImpl : getBUNameForApplication", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.ReservationDAOImpl : getBUNameForApplication", he);
		}
	}
	
	@Override
	public List<ReservationTO> getReservationForCancellation(UserTO user, ReservationTO reservationTO) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			List<ReservationTO> reservations = new ArrayList<ReservationTO>();
			LOG.info("In Search Reason for cancellation");
			String query = "select distinct r , app.projectTO.id,app.projectTO.name ,app.businessUnitTO.clientId, app.businessUnitTO.name," + "s.statusDesc,env.environmentName,app.appName " + " from ReservationTO as r , ProjectsTO as p , BusinessUnitTO as b , StatusTO as s, EnvironmentTO as env, ApplicationTO as app " + "where r.status.id = s.id and r.environments.id =env.id and r.applications.id=app.id and r.status.id in (" + CMMConstants.Framework.Entity.RESERVATION_STATUS_APPROVED + "," + CMMConstants.Framework.Entity.RESERVATION_STATUS_PENDING + ")";
			if (user.getClientId() != 0L) {
				query = query + " and  r.users.id=" + user.getId();
			}
			if (reservationTO.getId() != null) {
				query = query + " and r.id = " + reservationTO.getId();
			}
			if ((reservationTO.getSelectedStatus() != -1) && (reservationTO.getSelectedStatus() != 0)) {
				query = query + " and r.status.id = " + reservationTO.getSelectedStatus();
			}
			if ((reservationTO.getSelectedBusinessUnit() != null) && (reservationTO.getSelectedBusinessUnit() != -1)) {
				query = query + " and app.businessUnitTO.clientId= " + reservationTO.getSelectedBusinessUnit();
			}
			if (reservationTO.getSelectedProject() != null) {
				query = query + " and app.projectTO.id = " + reservationTO.getSelectedProject();
			}
			if ((reservationTO.getSelectedApplication() != null) && (reservationTO.getSelectedApplication() != -1)) {
				query = query + " and r.applications.id = " + reservationTO.getSelectedApplication();
			}
			if ((reservationTO.getSelectedEnvironment() != null) && (reservationTO.getSelectedEnvironment() != -1)) {
				query = query + " and r.environments.id = " + reservationTO.getSelectedEnvironment();
			}
			if ((reservationTO.getStartTimeString() != null) && (reservationTO.getEndTimeString() != null) && (reservationTO.getEndTimeString().length() > 0) && (reservationTO.getStartTimeString().length() > 0)) {
				query = query + " and r.startTime >= '" + reservationTO.getStartTimeString() + "' and r.endTime <= '" + reservationTO.getEndTimeString() + "'";
			} else if ((reservationTO.getStartTimeString() != null) && (reservationTO.getEndTimeString().length() <= 0)) {
				if (reservationTO.getStartTimeString().length() > 0) {
					query = query + " and r.startTime >= '" + reservationTO.getStartTimeString() + "'";
				}
			} else if ((reservationTO.getEndTimeString() != null) && reservationTO.getStartTimeString().isEmpty()) {
				query = query + " and r.endTime <= '" + reservationTO.getEndTimeString() + "'";
			}
			Query q = session.createQuery(query);
			List<Object[]> object = q.list();
			for (int i = 0; i < object.size(); i++) {
				Object[] dbreser = object.get(i);
				ReservationTO reserTO = (ReservationTO) dbreser[0];
				reserTO.setProjectId((Long) dbreser[1]);
				reserTO.setProjectName(dbreser[2].toString());
				reserTO.setClientId((Long) dbreser[3]);
				reserTO.setClientName(dbreser[4].toString());
				reserTO.setStatusDesc(dbreser[5].toString());
				reserTO.setEnvironmentName(dbreser[6].toString());
				reserTO.setApplicationName(dbreser[7].toString());
				reservations.add(reserTO);
			}
			if (reservationTO.getSearchCount() != 0) {
				q.setFirstResult(reservationTO.getFirstResult());
				q.setMaxResults(reservationTO.getTableSize());
			}
			return reservations;
		} catch (DataAccessException dae) {
			LOG.error("ReservationDAOImpl : getReservationForCancellation.", dae);
			throw new CMMException("ReservationDAOImpl : getReservationForCancellation.", dae);
		} catch (HibernateException he) {
			LOG.error("ReservationDAOImpl : getReservationForCancellation.", he);
			throw new CMMException("ReservationDAOImpl : getReservationForCancellation.", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public Long getWorkflow_levelID(Long res) throws CMMException {
	
		try {
			Long workflowId = 0L;
			List<WorkflowCurrentTO> workId = (List<WorkflowCurrentTO>) getHibernateTemplate().find("from WorkflowCurrentTO where entity_id=? ", res);
			for (WorkflowCurrentTO work : workId) {
				workflowId = work.getReqId();
			}
			return workflowId;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("ReservationDAOImpl : getWorkflow_levelID.", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("ReservationDAOImpl : getWorkflow_levelID.", he);
		} catch (Exception ex) {
			LOG.error("ReservationDAOImpl : getWorkflow_levelID", ex);
			throw new CMMException("ReservationDAOImpl : getWorkflow_levelID.", ex);
		}
	}
	
	@Override
	public ReservationTO getProjectNameForReservation(Long appId, Long resId) throws CMMException {
	
		try {
			Session session = null;
			session = getSession();
			List<ReservationTO> list = new ArrayList<ReservationTO>();
			String query = "select app.projectTO.name , app.businessUnitTO.name from ReservationTO as r , ApplicationTO as app where r.applications.id =app.id and r.applications.id =(:appId) and r.id=(:resId)";
			Query q = session.createQuery(query);
			q.setParameter("appId", appId);
			q.setParameter("resId", resId);
			List<Object[]> object = q.list();
			for (int i = 0; i < object.size(); i++) {
				ReservationTO reservationTO = new ReservationTO();
				Object[] dbreser = object.get(i);
				reservationTO.setProjectName((String) dbreser[0]);
				reservationTO.setClientName((String) dbreser[1]);
				list.add(reservationTO);
			}
			return list.get(0);
		} catch (DataAccessException dae) {
			LOG.error("ReservationDAOImpl : getProjectNameForReservation", dae);
			throw new CMMException("ReservationDAOImpl : getProjectNameForReservation", dae);
		} catch (HibernateException he) {
			LOG.error("ReservationDAOImpl : getProjectNameForReservation", he);
			throw new CMMException("ReservationDAOImpl : getProjectNameForReservation", he);
		} catch (Exception ex) {
			LOG.error("ReservationDAOImpl : getProjectNameForReservation", ex);
			throw new CMMException("ReservationDAOImpl : getProjectNameForReservation", ex);
		}
	}
	
	@Override
	public String getEnvironmentStartDate(Long envID) throws CMMException {
	
		String environmentStartDate = null;
		List<Timestamp> startDate;
		try {
			String query = "select r.startTime from ServiceRequestTO r where r.serviceId=1 and r.environmentId=?";
			startDate = (List<Timestamp>) getHibernateTemplate().find(query, envID);
			if (!startDate.isEmpty()) {
				environmentStartDate = String.valueOf(startDate.get(0));
			}
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.ReservationDAOImpl : getEnvironmentStartDate", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.ReservationDAOImpl : getEnvironmentStartDate", he);
		}
		return environmentStartDate;
	}
	
	@Override
	public String getEnvironmentEndDate(Long envID) throws CMMException {
	
		String environmentEndDate = null;
		List<Timestamp> endDate;
		try {
			String query = "select r.endTime from ServiceRequestTO r where r.serviceId=1 and r.environmentId=?";
			endDate = (List<Timestamp>) getHibernateTemplate().find(query, envID);
			if (!endDate.isEmpty()) {
				environmentEndDate = String.valueOf(endDate.get(0));
			}
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.ReservationDAOImpl : getEnvironmentEndDate", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.ReservationDAOImpl : getEnvironmentEndDate", he);
		}
		return environmentEndDate;
	}
	
	@Override
	public List<ReleasePlanningTO> fetchReleases(Long envId, Long applicationId) throws CMMException {
	
		List<ReleasePlanningTO> releases = new ArrayList<>(0);
		try {
			releases = (List<ReleasePlanningTO>) getHibernateTemplate().find("select rp from ApplicationReleaseTO r,EnvironmentApplicationTO ea, ReleasePlanningTO rp  where r.id=ea.applicationReleaseTO.id and ea.environmentTO.id = ? and ea.applicationTO.id=? and r.releasePlanningTO.id=rp.id ", envId, applicationId);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.ReservationDAOImpl : fetchReleases", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.ReservationDAOImpl : fetchReleases", he);
		} catch (Exception he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.ReservationDAOImpl : fetchReleases", he);
		}
		return releases;
	}
	
	@Override
	public List<TestingPhaseTO> fetchPhases(Long EnvironmentId) throws CMMException {
	
		List<TestingPhaseTO> phaseList = new ArrayList<>(0);
		try {
			phaseList = (List<TestingPhaseTO>) getHibernateTemplate().find("select t from TestingPhaseTO t, EnvironmentTO e, EnvironmentApplicationTO ea where e.id=ea.environmentTO.id and t.id=ea.testingPhaseTO.id and ea.environmentTO.id=?", EnvironmentId);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.ReservationDAOImpl : fetchPhases", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.ReservationDAOImpl : fetchPhases", he);
		} catch (Exception he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.ReservationDAOImpl : fetchPhases", he);
		}
		return phaseList;
	}
	
	@Override
	public ReleasePlanningTO fetchPlanDate(Long releaseId) throws CMMException {
	
		ReleasePlanningTO plan = new ReleasePlanningTO();
		try {
			List<ReleasePlanningTO> list = (List<ReleasePlanningTO>) getHibernateTemplate().find("select r from ReleasePlanningTO r where r.id=?", releaseId);
			if (!list.isEmpty()) {
				plan = list.get(0);
			}
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.ReservationDAOImpl : fetchPlanDate", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.ReservationDAOImpl : fetchPlanDate", he);
		} catch (Exception he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.ReservationDAOImpl : fetchPlanDate", he);
		}
		return plan;
	}
	
	@Override
	public List<EnvironmentTO> fetchEnvironments(Long applicationid, Long releasePlanId, Long phaseId) throws CMMException {
	
		List<Long> releaseProfileIds = new ArrayList<>(0);
		List<EnvironmentTO> environments = new ArrayList<>(0);
		try {
			releaseProfileIds = (List<Long>) getHibernateTemplate().find("select r.id from ApplicationReleaseTO r, ReleasePlanningTO rp, ReleasePlanningPhasesTO rpp where rp.id=r.releasePlanningTO.id and rp.id=rpp.releasePlanningTO.id and rp.id=? and rpp.testingPhaseTO.id=? and r.applicationId=?", releasePlanId, phaseId, applicationid);
			if (!releaseProfileIds.isEmpty()) {
				environments = (List<EnvironmentTO>) getHibernateTemplate().findByNamedParam("select e from EnvironmentTO e, EnvironmentApplicationTO ea where e.id=ea.environmentTO.id and ea.applicationReleaseTO.id in (:releaseList) and e.status=21 and ea.testingPhaseTO.id=" + phaseId, "releaseList", releaseProfileIds);
			}
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.ReservationDAOImpl : fetchEnvironments", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.ReservationDAOImpl : fetchEnvironments", he);
		} catch (Exception he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.ReservationDAOImpl : fetchEnvironments", he);
		}
		return environments;
	}
	
	@Override
	public List<ProjectsTO> getAllProjectsProjectView(List<Long> cliendIdList) throws CMMException {
	
		try {
			Session session = getSession();
			//Projects
			List<ProjectsTO> projectsTOs = new ArrayList<ProjectsTO>();
			if (cliendIdList.contains(0L)) {
				projectsTOs = (List<ProjectsTO>) getHibernateTemplate().find("select p from ProjectsTO p");
			} else {
				projectsTOs = (List<ProjectsTO>) getHibernateTemplate().findByNamedParam("from ProjectsTO where clientId=(:clientIdList)", "clientIdList", cliendIdList);
			}
			for (ProjectsTO projectsTO : projectsTOs) {
				List<ApplicationTO> applicationTOs = (List<ApplicationTO>) getHibernateTemplate().find("from ApplicationTO where selectedProject=?", projectsTO.getId());
				projectsTO.setApplicationList(applicationTOs);
				if (!applicationTOs.isEmpty()) {
					//Environments  for each application
					for (ApplicationTO applicationTO : applicationTOs) {
						String hql = "select e from EnvironmentTO e,EnvironmentApplicationTO ea where e.id=ea.environmentTO.id and ea.applicationTO.id = (:appID) and  e.status=(:status)";
						Query q = session.createQuery(hql);
						q.setParameter("appID", applicationTO.getId());
						q.setParameter("status", 21L);
						List<EnvironmentTO> envList = q.list();
						applicationTO.setEnvironmentTO(envList);
						if (!envList.isEmpty()) {
							//Release Plans for each Environment
							for (EnvironmentTO envListTemp : envList) {
								String hql1 = "select rp from ApplicationReleaseTO r,EnvironmentApplicationTO ea, ReleasePlanningTO rp  where r.id=ea.applicationReleaseTO.id and ea.environmentTO.id = (:envId) and ea.applicationTO.id=(:appId) and r.releasePlanningTO.id=rp.id ";
								Query q1 = session.createQuery(hql1);
								q1.setParameter("envId", envListTemp.getId());
								q1.setParameter("appId", applicationTO.getId());
								List<ReleasePlanningTO> releasePlan = q1.list();
								if (!releasePlan.isEmpty()) {
									envListTemp.setPlanningTO(releasePlan);
									//Phase for each env , app , release Plan
									for (ReleasePlanningTO releasePlanTemp : releasePlan) {
										String hql2 = "select rp from ReleasePlanningPhasesTO rp , ReleasePlanningTO r,EnvironmentApplicationTO ea where ea.environmentTO.id=(:envId) and ea.applicationTO.id=(:appId) and ea.testingPhaseTO.id=rp.testingPhaseTO.id and rp.releasePlanningTO.id=r.id and r.id=(:releasePlan) ";
										Query q2 = session.createQuery(hql2);
										q2.setParameter("envId", envListTemp.getId());
										q2.setParameter("appId", applicationTO.getId());
										q2.setParameter("releasePlan", releasePlanTemp.getId());
										List<ReleasePlanningPhasesTO> releasePlanPhases = q2.list();
										releasePlanTemp.setReleasePlanningPhasesTO(releasePlanPhases);
										//reservations for each environment,application,release plan,phase
										for (ReleasePlanningPhasesTO releasePlanPhaseTemp : releasePlanPhases) {
											List<ReservationTO> reservationTOs = (List<ReservationTO>) getHibernateTemplate().find("select res from ReservationTO res where res.environments.id=? and res.applications.id=? and res.releasePlanTO.id=? and res.testingPhaseTO.id=?", envListTemp.getId(), applicationTO.getId(), releasePlanTemp.getId(), releasePlanPhaseTemp.getTestingPhaseTO().getId());
											Set<ReservationTO> reservationTOs2 = new HashSet<ReservationTO>(reservationTOs);
											releasePlanPhaseTemp.setReservationTO(reservationTOs2);
										}
									}
								} else {
									ReleasePlanningTO releasePlanTemp = new ReleasePlanningTO();
									releasePlanTemp.setName("NA");
									List<ReleasePlanningTO> releasePlanList = new ArrayList<ReleasePlanningTO>();
									releasePlanList.add(releasePlanTemp);
									envListTemp.setPlanningTO(releasePlanList);
									ReleasePlanningPhasesTO phasesTO = new ReleasePlanningPhasesTO();
									phasesTO.setTestingPhaseTO(new TestingPhaseTO());
									phasesTO.getTestingPhaseTO().setName("NA");
									List<ReleasePlanningPhasesTO> planningPhasesTOs = new ArrayList<ReleasePlanningPhasesTO>();
									planningPhasesTOs.add(phasesTO);
									List<ReservationTO> reservationTOs = (List<ReservationTO>) getHibernateTemplate().find("select res from ReservationTO res where res.environments.id=? and res.applications.id=? ", envListTemp.getId(), applicationTO.getId());
									Set<ReservationTO> reservationTOs2 = new HashSet<ReservationTO>(reservationTOs);
									planningPhasesTOs.get(0).setReservationTO(reservationTOs2);
									releasePlanList.get(0).setReleasePlanningPhasesTO(planningPhasesTOs);
								}
							}
						}
					}
				}
			}
			return projectsTOs;
		} catch (Exception e) {
			throw new CMMException("Problem encountered.ReservationDAOImpl : getEnvironmentEndDate", e);
		}
	}
}
