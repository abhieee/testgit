package com.ext.dao.impl;

import java.util.ArrayList;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.TestingToolsDao;
import com.framework.common.CMMConstants;
import com.framework.exception.CMMException;
import com.framework.to.ProvisionedMachineTO;
import com.framework.to.TestingToolTO;
import com.framework.to.TestingToolsTO;

public class TestingToolsDaoImpl extends HibernateDaoSupport implements TestingToolsDao {
	
	@Override
	public List<TestingToolsTO> getAllTestingToolsConfigDetailsForApp(Long applicationId, Long projectId, Long buId, Long toolId) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			Criteria criteria = session.createCriteria(TestingToolsTO.class, "testToolsTO");
			if ((applicationId != null) && (applicationId > 0)) {
				criteria.add(Restrictions.eq("applicationId", applicationId));
			}
			if ((projectId != null) && (projectId > 0)) {
				criteria.add(Restrictions.eq("projectId", projectId));
			}
			if ((buId != null) && (buId > 0)) {
				criteria.add(Restrictions.eq("businessUnitId", buId));
			}
			if ((toolId != null) && (toolId > 0)) {
				criteria.add(Restrictions.eq("testingToolId", toolId));
			}
			List<TestingToolsTO> testToolsList = criteria.list();
			List<TestingToolsTO> testToolsConfigList = new ArrayList<TestingToolsTO>();
			for (TestingToolsTO testingToolsTO : testToolsList) {
				if ((testingToolsTO.getApplicationTO() != null) && (testingToolsTO.getApplicationTO().getAppName() != null)) {
					testingToolsTO.setApplicationName(testingToolsTO.getApplicationTO().getAppName());
				}
				if ((testingToolsTO.getProjectsTO() != null) && (testingToolsTO.getProjectsTO().getName() != null)) {
					testingToolsTO.setProjectName(testingToolsTO.getProjectsTO().getName());
				}
				if ((testingToolsTO.getClientTO() != null) && (testingToolsTO.getClientTO().getName() != null)) {
					testingToolsTO.setBuName(testingToolsTO.getClientTO().getName());
				}
				if ((testingToolsTO.getTestingToolTO() != null) && (testingToolsTO.getTestingToolTO().getName() != null)) {
					testingToolsTO.setTestingTool(testingToolsTO.getTestingToolTO().getName());
				}
				testToolsConfigList.add(testingToolsTO);
			}
			if ((testToolsList == null) || (testToolsList.size() < 0)) {
				throw new CMMException("No Testing Tools configuration found for application");
			}
			return testToolsConfigList;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.TestingToolsDaoImpl:getAllTestingToolsConfigDetailsForApp", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.TestingToolsDaoImpl:getAllTestingToolsConfigDetailsForApp", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<TestingToolsTO> getAllTestingToolsConfigDetailsForApp(Long applicationId, Long projectId, Long buId, Long toolId, Long searchCount, int firstResult, int tableSize, List<Long> clients, Long clientId) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			Criteria criteria = session.createCriteria(TestingToolsTO.class, "testToolsTO");
			if ((applicationId != null) && (applicationId > 0)) {
				criteria.add(Restrictions.eq("applicationId", applicationId));
			}
			if ((projectId != null) && (projectId > 0)) {
				criteria.add(Restrictions.eq("projectId", projectId));
			}
			if (buId == null) {
				if (clientId != 0L) {
					criteria.add(Restrictions.in("businessUnitId", clients));
				}
			}
			if ((buId != null) && (buId > 0)) {
				criteria.add(Restrictions.eq("businessUnitId", buId));
			}
			if ((toolId != null) && (toolId > 0)) {
				criteria.add(Restrictions.eq("testingToolId", toolId));
			}
			List<TestingToolsTO> testToolsList = new ArrayList<TestingToolsTO>();
			if (searchCount == 0) {
				testToolsList = criteria.list();
			} else {
				criteria.setFirstResult(firstResult);
				criteria.setMaxResults(tableSize);
				testToolsList = criteria.list();
			}
			List<TestingToolsTO> testToolsConfigList = new ArrayList<TestingToolsTO>();
			for (TestingToolsTO testingToolsTO : testToolsList) {
				if ((testingToolsTO.getApplicationTO() != null) && (testingToolsTO.getApplicationTO().getAppName() != null)) {
					testingToolsTO.setApplicationName(testingToolsTO.getApplicationTO().getAppName());
				}
				if ((testingToolsTO.getProjectsTO() != null) && (testingToolsTO.getProjectsTO().getName() != null)) {
					testingToolsTO.setProjectName(testingToolsTO.getProjectsTO().getName());
				}
				if ((testingToolsTO.getClientTO() != null) && (testingToolsTO.getClientTO().getName() != null)) {
					testingToolsTO.setBuName(testingToolsTO.getClientTO().getName());
				}
				if ((testingToolsTO.getTestingToolTO() != null) && (testingToolsTO.getTestingToolTO().getName() != null)) {
					testingToolsTO.setTestingTool(testingToolsTO.getTestingToolTO().getName());
				}
				testToolsConfigList.add(testingToolsTO);
			}
			if ((testToolsList == null) || (testToolsList.size() < 0)) {
				throw new CMMException("No Testing Tools configuration found for application");
			}
			return testToolsConfigList;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.TestingToolsDaoImpl:getAllTestingToolsConfigDetailsForApp", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.TestingToolsDaoImpl:getAllTestingToolsConfigDetailsForApp", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public boolean saveTestingToolConfigDetails(TestingToolsTO testingToolsTO) throws CMMException {
	
		Session session = null;
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(TestingToolsTO.class);
			if (testingToolsTO.getSelectedBUId() != null) {
				criteria.add(Restrictions.eq("businessUnitId", testingToolsTO.getSelectedBUId()));
			}
			if (testingToolsTO.getSelectedProjectId() != null) {
				criteria.add(Restrictions.eq("projectId", testingToolsTO.getSelectedProjectId()));
			} else {
				criteria.add(Restrictions.isNull("projectId"));
			}
			if (testingToolsTO.getSelectedApplicationId() != null) {
				criteria.add(Restrictions.eq("applicationId", testingToolsTO.getSelectedApplicationId()));
			} else {
				criteria.add(Restrictions.isNull("applicationId"));
			}
			if (testingToolsTO.getSelectedtestingToolName() != null) {
				criteria.add(Restrictions.eq("testingToolId", testingToolsTO.getSelectedtestingToolName()));
			}
			List<TestingToolsTO> tTList = (List<TestingToolsTO>) getHibernateTemplate().findByCriteria(criteria);
			if (!tTList.isEmpty()) {
				return false;
			}
			testingToolsTO.setBusinessUnitId(testingToolsTO.getSelectedBUId());
			testingToolsTO.setProjectId(testingToolsTO.getSelectedProjectId());
			testingToolsTO.setApplicationId(testingToolsTO.getSelectedApplicationId());
			testingToolsTO.setTestingToolId(testingToolsTO.getSelectedtestingToolName());
			Long testingToolConfigId = (Long) getHibernateTemplate().save(testingToolsTO);
			if ((testingToolConfigId == null) || (testingToolConfigId <= 0)) {
				throw new CMMException("Problem encountered.TestingToolsDaoImpl:saveTestingToolConfigDetails");
			}
			return true;
		} catch (DataIntegrityViolationException divE) {
			logger.error(divE);
			throw new CMMException("Problem encountered.TestingToolsDaoImpl:saveTestingToolConfigDetails", divE);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.TestingToolsDaoImpl:saveTestingToolConfigDetails", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public TestingToolsTO getConfigDetailsById(Long testingToolConfigId) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			List<TestingToolsTO> testingToolsConfigList = session.createCriteria(TestingToolsTO.class).add(Restrictions.eq("id", testingToolConfigId)).list();
			if ((testingToolsConfigList == null) || (testingToolsConfigList.size() < 0)) {
				throw new CMMException("No testing tools details found for application");
			}
			return testingToolsConfigList.get(0);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.TestingToolsDaoImpl:getConfigDetailsById", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.TestingToolsDaoImpl:getConfigDetailsById", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public boolean updateTestingToolsConfigDetails(TestingToolsTO testingToolsTO) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			TestingToolsTO testingListTO = getHibernateTemplate().get(TestingToolsTO.class, testingToolsTO.getId());
			testingListTO.setBusinessUnitId(testingToolsTO.getSelectedBUId());
			testingListTO.setProjectId(testingToolsTO.getSelectedProjectId());
			testingListTO.setApplicationId(testingToolsTO.getSelectedApplicationId());
			testingListTO.setScriptCopyLocation(testingToolsTO.getScriptCopyLocation());
			testingListTO.setUsername(testingToolsTO.getUsername());
			testingListTO.setPassword(testingToolsTO.getPassword());
			testingListTO.setMachineUsername(testingToolsTO.getMachineUsername());
			testingListTO.setMachinePassword(testingToolsTO.getMachinePassword());
			testingListTO.setType(testingToolsTO.getType());
			testingListTO.setIp(testingToolsTO.getIp());
			testingListTO.setParameterName(testingToolsTO.getParameterName());
			testingListTO.setUsername(testingToolsTO.getUsername());
			testingListTO.setPassword(testingToolsTO.getPassword());
			testingListTO.setDomain(testingToolsTO.getDomain());
			testingListTO.setServerURL(testingToolsTO.getServerURL());
			testingListTO.setTamAdapterFlag(testingToolsTO.getTamAdapterFlag());
			testingListTO.setTamAdapterName(testingToolsTO.getTamAdapterName());
			testingListTO.setAdapterWinCopyLoc(testingToolsTO.getAdapterWinCopyLoc());
			testingListTO.setAdapterLinuxCopyLoc(testingToolsTO.getAdapterLinuxCopyLoc());
			testingListTO.setExecutionServerName(testingToolsTO.getExecutionServerName());
			testingListTO.setProvMachineId(testingToolsTO.getProvMachineId());
			testingListTO.setSelJarLocation(testingToolsTO.getSelJarLocation());
			testingListTO.setSelPort(testingToolsTO.getSelPort());
			testingListTO.setResultLocation(testingToolsTO.getResultLocation());
			getHibernateTemplate().update(testingListTO);
			return true;
		} catch (DataIntegrityViolationException divE) {
			logger.error("Problem encountered.TestingToolsDaoImpl:updateTestingToolsConfigDetails", divE);
			return false;
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.TestingToolsDaoImpl:updateTestingToolsConfigDetails", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<TestingToolTO> getAllTestingToolName() throws CMMException {
	
		try {
			return (List<TestingToolTO>) getHibernateTemplate().find("from TestingToolTO");
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.TestingToolnDAOImpl : getAllTestingToolName", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.  TestingToolnDAOImpl : getAllTestingToolName", he);
		}
	}
	
	@Override
	public List<ProvisionedMachineTO> getAllProvisionedMachine() throws CMMException {
	
		try {
			return (List<ProvisionedMachineTO>) getHibernateTemplate().find("from ProvMachineTO where serverStatus = '" + CMMConstants.Framework.ProvisionedMachineStatus.PROVISIONED_MACHINE_ACTIVE + "'");
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.TestingToolnDAOImpl : getAllTestingToolName", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.  TestingToolnDAOImpl : getAllTestingToolName", he);
		}
	}
	
	@Override
	public String getToolNameById(Long toolId) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			return (String) session.createCriteria(TestingToolTO.class).add(Restrictions.eq("id", toolId)).setProjection(Projections.property("name")).uniqueResult();
		} catch (DataAccessException dae) {
			throw new CMMException("Error in fetching toolName for toolId " + toolId, dae);
		} catch (HibernateException he) {
			throw new CMMException("Can not fetch data from database for toolName", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
}
