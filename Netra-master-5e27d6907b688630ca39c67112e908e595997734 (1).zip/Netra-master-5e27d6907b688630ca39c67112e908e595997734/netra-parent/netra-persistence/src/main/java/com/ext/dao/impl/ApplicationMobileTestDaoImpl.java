/**
 * 
 */
package com.ext.dao.impl;

import java.util.List;
import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.exception.ConstraintViolationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.ApplicationMobileTestDao;
import com.ext.dao.ServiceRequestDAO;
import com.framework.exception.CMMException;
import com.framework.to.ApplicationMobileTestingTO;

/**
 * @author 460650
 */
public class ApplicationMobileTestDaoImpl extends HibernateDaoSupport implements ApplicationMobileTestDao {
	
	private static final Logger LOG = Logger.getLogger(ApplicationMobileTestDaoImpl.class);
	@Autowired
	private ServiceRequestDAO serviceRequestDAO;
	
	/**
	 * @see com.ext.dao.ApplicationMobileTestDao#fetchMobileTestDetails(long) {@inheritDoc}
	 */
	@Override
	public ApplicationMobileTestingTO fetchMobileTestDetails(long requestId) throws CMMException {
	
		try {
			List<ApplicationMobileTestingTO> applicationMobileTestingList = (List<ApplicationMobileTestingTO>) getHibernateTemplate().find("from ApplicationMobileTestingTO where requestId=?", requestId);
			if (applicationMobileTestingList.isEmpty()) {
				throw new CMMException("No mobile testing details found for requestId:: " + requestId);
			}
			return applicationMobileTestingList.get(0);
		} catch (DataAccessException | HibernateException dae) {
			LOG.error("Problem encountered. ApplicationMobileTestDaoImpl : fetchMobileTestDetails", dae);
			throw new CMMException("Error in fetching mobile test details for requestId:: " + requestId, dae);
		}
	}
	
	/**
	 * (non-Javadoc)
	 * 
	 * @see com.ext.dao.ApplicationMobileTestDao#saveMobileTestingDetails(com.framework.to.ApplicationMobileTestingTO) {@inheritDoc}
	 */
	@Override
	public void saveMobileTestingDetails(ApplicationMobileTestingTO applicationMobileTestingTO) throws CMMException {
	
		try {
			getHibernateTemplate().save(applicationMobileTestingTO);
		} catch (DataIntegrityViolationException | ConstraintViolationException div) {
			LOG.error(div);
			throw new CMMException("Problem encountered. ApplicationMobileTestDaoImpl: saveMobileTestingDetails", div);
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationMobileTestDaoImpl: saveMobileTestingDetails", dae);
		}
	}
	
	/**
	 * (non-Javadoc)
	 * 
	 * @see com.ext.dao.ApplicationMobileTestDao#saveMobileTestReport(long, java.lang.String){@inheritDoc}
	 */
	@Override
	public void saveMobileTestReport(long requestId, String perfectoReportName) throws CMMException {
	
		ApplicationMobileTestingTO applicationMobileTestingTO = fetchMobileTestDetails(requestId);
		try {
			applicationMobileTestingTO.setScriptReport(perfectoReportName);
			getHibernateTemplate().update(applicationMobileTestingTO);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationMobileTestDaoImpl : saveMobileTestReport.", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. ApplicationMobileTestDaoImpl : saveMobileTestReport.", he);
		}
	}
}
