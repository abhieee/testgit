package com.ext.dao.impl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.exception.ConstraintViolationException;
import org.hibernate.transform.DistinctRootEntityResultTransformer;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.util.StringUtils;
import com.ext.dao.ApplicationProfileDAO;
import com.ext.dao.ApplicationReleaseDAO;
import com.ext.dao.ServiceRequestDAO;
import com.framework.common.CMMConstants;
import com.framework.common.PasswordEncryptorUtil;
import com.framework.common.ResourceForDeployment;
import com.framework.exception.CMMException;
import com.framework.nolio.to.NolioProcessParametersTO;
import com.framework.to.ApplicationProfileDetailsTO;
import com.framework.to.ApplicationProfileMappingTO;
import com.framework.to.ApplicationProfileTO;
import com.framework.to.ApplicationReleaseBuildTO;
import com.framework.to.ApplicationReleaseDbTO;
import com.framework.to.ApplicationReleaseSharedDetailsTO;
import com.framework.to.ApplicationReleaseSharedMappingTO;
import com.framework.to.ApplicationReleaseSourcecodeTO;
import com.framework.to.ApplicationReleaseTO;
import com.framework.to.ApplicationReleaseTestTO;
import com.framework.to.ApplicationTO;
import com.framework.to.BuildToolDefinitionTO;
import com.framework.to.BuildToolTO;
import com.framework.to.DataMaskingToolTO;
import com.framework.to.EnvironmentApplicationTO;
import com.framework.to.EnvironmentDetailsTO;
import com.framework.to.EnvironmentTO;
import com.framework.to.HardwareTO;
import com.framework.to.PlatformTemplateTO;
import com.framework.to.RepoTO;
import com.framework.to.RepositoryMasterTO;
import com.framework.to.RepositoryTO;
import com.framework.to.ServiceRequestTO;
import com.framework.to.SoftwareTO;
import com.framework.to.SoftwareconfigTO;
import com.framework.to.SonarDetailTO;
import com.framework.to.StatusTO;
import com.framework.to.TestingToolTO;
import com.framework.to.UserDefinedRelParamsTO;
import com.framework.to.UserGroupDetailsTO;
import com.framework.to.UserGroupTO;
import com.framework.utility.DateUtils;

public class ApplicationReleaseDAOImpl extends HibernateDaoSupport implements ApplicationReleaseDAO {
	
	private static final Logger LOG = Logger.getLogger(ApplicationReleaseDAOImpl.class);
	ServiceRequestDAO serviceRequestDAO;
	@Autowired
	private PasswordEncryptorUtil passwordEncryptorUtil;
	ApplicationProfileDAO applicationProfileDAO;
	
	@Override
	public List<ApplicationReleaseTO> searchRelease(ApplicationReleaseTO applicationReleaseTO) throws CMMException {
	
		Session session = null;
		try {
			List<ApplicationReleaseTO> releaseList = new ArrayList<ApplicationReleaseTO>();
			List<ApplicationReleaseTO> releaseList1 = new ArrayList<ApplicationReleaseTO>();
			session = getSession();
			Criteria criteria = session.createCriteria(ApplicationReleaseTO.class, "applicationReleaseTO");
			if (!"".equalsIgnoreCase(applicationReleaseTO.getName().trim())) {
				criteria.add(Restrictions.like("name", "%" + applicationReleaseTO.getName() + "%"));
			}
			if (applicationReleaseTO.getSelectedApplication() > 0L) {
				criteria.add(Restrictions.eq("applicationTO.id", applicationReleaseTO.getSelectedApplication()));
			}
			if (applicationReleaseTO.getSelectedStatus() > 0L) {
				criteria.add(Restrictions.eq("statusTO.id", applicationReleaseTO.getSelectedStatus()));
			}
			if (applicationReleaseTO.getSelectedReleaseType() > 0L) {
				if (applicationReleaseTO.getSelectedReleaseType() == CMMConstants.Framework.Entity.APPLICATION_RELEASE_MAJOR) {
					applicationReleaseTO.setType("P");
				}
				if (applicationReleaseTO.getSelectedReleaseType() == CMMConstants.Framework.Entity.APPLICATION_RELEASE_MINOR) {
					applicationReleaseTO.setType("S");
				}
				criteria.add(Restrictions.eq("type", applicationReleaseTO.getType()));
			}
			criteria.setResultTransformer(DistinctRootEntityResultTransformer.INSTANCE);
			if (applicationReleaseTO.getSearchCount() == 0) {
				releaseList1 = criteria.list();
			} else {
				criteria.setFirstResult(applicationReleaseTO.getFirstResult());
				criteria.setMaxResults(applicationReleaseTO.getTableSize());
				releaseList1 = criteria.list();
			}
			for (ApplicationReleaseTO hd : releaseList1) {
				if (hd.getType() != null) {
					if (hd.getType().equals(CMMConstants.Framework.ApplicationRelease.SUB_APPLICATION_RELEASE)) {
						hd.setTypeDet("Minor");
					}
					if (hd.getType().equals(CMMConstants.Framework.ApplicationRelease.PARENT_APPLICATION_RELEASE)) {
						hd.setTypeDet("Major");
					}
				}
				releaseList.add(hd);
			}
			return releaseList;
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : searchRelease", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<StatusTO> getStatusList() throws CMMException {
	
		try {
			return (List<StatusTO>) getHibernateTemplate().find("from StatusTO where entityId=?", CMMConstants.Framework.Entity.APPLICATION_RELEASE);
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : getStatusList", dae);
		}
	}
	
	@Override
	public ApplicationProfileDetailsTO fetchAppProDetails(Long profileid, Long softwareid) throws CMMException {
	
		try {
			ApplicationProfileDetailsTO a = new ApplicationProfileDetailsTO();
			List<ApplicationProfileDetailsTO> list = (List<ApplicationProfileDetailsTO>) getHibernateTemplate().find("from ApplicationProfileDetailsTO where profileId=? and mappedSoftwareId=?", profileid, softwareid);
			if (!list.isEmpty()) {
				a = list.get(0);
			}
			return a;
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : fetchAppProDetails(Long, Long)", dae);
		}
	}
	
	@Override
	public List<ApplicationProfileDetailsTO> fetchAppProDetails(Long profileid, Long serverGroup, Long serverId) throws CMMException {
	
		try {
			return (List<ApplicationProfileDetailsTO>) getHibernateTemplate().find("from ApplicationProfileDetailsTO where profileId=? and serverGroup=? and hardwareId=?", profileid, serverGroup, serverId);
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : fetchAppProDetails(Long, Long, Long)", dae);
		}
	}
	
	@Override
	public List<ApplicationProfileDetailsTO> fetchApplicationProfileDetails(Long profileid, Long serverGroup) throws CMMException {
	
		try {
			return (List<ApplicationProfileDetailsTO>) getHibernateTemplate().find("from ApplicationProfileDetailsTO where profileId=? and serverGroup=?", profileid, serverGroup);
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : fetchAppProDetails(Long, Long)", dae);
		}
	}
	
	@Override
	public List<ApplicationProfileTO> getAllApplicationProfiles() throws CMMException {
	
		try {
			return (List<ApplicationProfileTO>) getHibernateTemplate().find("from ApplicationProfileTO");
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : getAllApplicationProfiles()", dae);
		}
	}
	
	@Override
	public List<ApplicationProfileTO> getAllApplicationProfiles(List<UserGroupTO> userGroupIds) throws CMMException {
	
		List<ApplicationProfileTO> profileList = new ArrayList<ApplicationProfileTO>();
		List<Long> grpIds = new ArrayList<Long>();
		Session session = getSession();
		try {
			for (UserGroupTO groupTO : userGroupIds) {
				grpIds.add(groupTO.getId());
			}
			Transaction tx = null;
			tx = session.beginTransaction();
			String hql = "select r.id,r.name from ApplicationReleaseTO r inner join ApplicationTO a inner join a.userGroups u where u.id in (:grpId)";
			Query q = session.createQuery(hql);
			q.setParameterList("grpId", grpIds);
			List<Object[]> obj = q.list();
			tx.commit();
			for (Object[] temp : obj) {
				ApplicationProfileTO profiles = new ApplicationProfileTO();
				profiles.setId((Long) temp[0]);
				profiles.setName(temp[1].toString());
				profileList.add(profiles);
			}
			return profileList;
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : getAllApplicationProfiles(List)", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	private RepositoryMasterTO saveRepositoryMasterDetails(ApplicationReleaseTO applicationReleaseTO) {
	
		RepositoryMasterTO repositoryMasterTO = new RepositoryMasterTO();
		List<RepositoryMasterTO> repositoryDetails = (List<RepositoryMasterTO>) getHibernateTemplate().find("from RepositoryMasterTO r where r.applicationRelease.id=?", applicationReleaseTO.getId());
		if (!repositoryDetails.isEmpty()) {
			repositoryMasterTO = repositoryDetails.get(0);
		}
		repositoryMasterTO.setType(applicationReleaseTO.getRepositoryMaster().getType());
		if (applicationReleaseTO.getRepositoryMaster().getType() == 3) {
			if (applicationReleaseTO.getRepoTypeSourcecode() != null) {
				List<RepositoryTO> repository = (List<RepositoryTO>) getHibernateTemplate().find("from RepositoryTO r where r.id=?", applicationReleaseTO.getRepoTypeSourcecode());
				if (!repository.isEmpty()) {
					repositoryMasterTO.setUsername(repository.get(0).getRepoUsername());
					repositoryMasterTO.setPassword(passwordEncryptorUtil.decryptPassword(repository.get(0).getRepoPassword()));
				}
			} else {
				return repositoryMasterTO;
			}
		} else {
			repositoryMasterTO.setUsername(applicationReleaseTO.getRepositoryMaster().getUsername());
			repositoryMasterTO.setPassword(applicationReleaseTO.getRepositoryMaster().getPassword());
		}
		repositoryMasterTO.setApplicationRelease(applicationReleaseTO);
		if (repositoryDetails.isEmpty()) {
			getHibernateTemplate().save(repositoryMasterTO);
		} else {
			getHibernateTemplate().update(repositoryMasterTO);
		}
		return repositoryMasterTO;
	}
	
	@Override
	public Long addRelease(ApplicationReleaseTO applicationReleaseTO) throws CMMException {
	
		try {
			Serializable save = getHibernateTemplate().save(applicationReleaseTO);
			Long releaseId = (Long) save;
			if (!applicationReleaseTO.getAppRelSourcecode().isEmpty()) {
				if ((applicationReleaseTO.getDeployFromNexus() != null) && applicationReleaseTO.getDeployFromNexus().equalsIgnoreCase(CMMConstants.DeployToNexusFlag.NOT_TO_TRIGGER_BUILD)) {
					RepositoryMasterTO repositoryMasterTO = saveRepositoryMasterDetails(applicationReleaseTO);
					ApplicationReleaseSharedDetailsTO applicationReleaseSharedDetailsTO = new ApplicationReleaseSharedDetailsTO();
					if (applicationReleaseTO.getSelectedResource().equalsIgnoreCase(ResourceForDeployment.SHARED_PATH.getPath())) {
						applicationReleaseSharedDetailsTO.setSharedIp(applicationReleaseTO.getApplicationReleaseSharedDetailsTO().getSharedIp());
						getHibernateTemplate().save(applicationReleaseSharedDetailsTO);
					}
					ApplicationReleaseSharedMappingTO applicationReleaseSharedMappingTO = new ApplicationReleaseSharedMappingTO();
					applicationReleaseSharedMappingTO.setRepositoryMaster(repositoryMasterTO);
					applicationReleaseSharedMappingTO.setSharedResourceId(applicationReleaseSharedDetailsTO.getId());
					getHibernateTemplate().save(applicationReleaseSharedMappingTO);
				}
			}
			if (!applicationReleaseTO.getAppRelSourcecode().isEmpty()) {
				for (ApplicationReleaseSourcecodeTO temp : applicationReleaseTO.getAppRelSourcecode()) {
					ApplicationReleaseSourcecodeTO applicationReleaseSourcecodeTO = new ApplicationReleaseSourcecodeTO();
					applicationReleaseSourcecodeTO.setServerGroupNumber(temp.getServerGroupNumber());
					applicationReleaseSourcecodeTO.setAppProDetailsId(temp.getAppProDetailsId());
					applicationReleaseSourcecodeTO.setSourceCodePath(temp.getSourceCodePath());
					applicationReleaseSourcecodeTO.setEarPath(temp.getEarPath());
					applicationReleaseSourcecodeTO.setScriptsPath(temp.getScriptsPath());
					applicationReleaseSourcecodeTO.setSoftwareConfigId(temp.getSoftwareConfigId());
					applicationReleaseSourcecodeTO.setApplicationReleaseId(applicationReleaseTO.getId());
					applicationReleaseSourcecodeTO.setContextPath(temp.getContextPath());
					applicationReleaseSourcecodeTO.setNetraNexusPath(temp.getNetraNexusPath());
					applicationReleaseSourcecodeTO.setSoftwareConfigId(temp.getSoftwareConfigId());
					applicationReleaseSourcecodeTO.setApplicationReleaseId(applicationReleaseTO.getId());
					applicationReleaseSourcecodeTO.setSelectedTestingPhase(temp.getSelectedTestingPhase());
					if (applicationReleaseTO.isMonitoringFlag()) {
						applicationReleaseSourcecodeTO.setMonitoringFlag("Y");
					} else {
						applicationReleaseSourcecodeTO.setMonitoringFlag("N");
					}
					if (applicationReleaseTO.getYesNoRadio() != null) {
						if ("buildYes".equalsIgnoreCase(applicationReleaseTO.getYesNoRadio())) {
							if (applicationReleaseTO.isOverwriteFlag()) {
								applicationReleaseSourcecodeTO.setOverWriteFlag("Y");
							} else {
								applicationReleaseSourcecodeTO.setOverWriteFlag("N");
							}
						}
						if ("radioNo".equalsIgnoreCase(applicationReleaseTO.getYesNoRadio())) {
							applicationReleaseSourcecodeTO.setOverWriteFlag(null);
						}
					}
					applicationReleaseSourcecodeTO.setSelectedRepository(applicationReleaseTO.getRepoTypeSourcecode());
					getHibernateTemplate().save(applicationReleaseSourcecodeTO);
				}
			}
			for (ApplicationReleaseBuildTO temp : applicationReleaseTO.getApplicationReleaseBuild()) {
				ApplicationReleaseBuildTO applicationReleaseBuildTO = new ApplicationReleaseBuildTO();
				BuildToolDefinitionTO buildToolDefinitionTO = new BuildToolDefinitionTO();
				applicationReleaseBuildTO.setSelectedTestingPhase(temp.getSelectedTestingPhase());
				if (temp.getBuildToolId() != null) {
					if (temp.getBuildToolId() == CMMConstants.External.Tools.ContinuousIntegrationServer.JENKINS) {
						buildToolDefinitionTO.setBuildToolId(temp.getBuildToolId());
						buildToolDefinitionTO.setBuildName(temp.getJobName());
						buildToolDefinitionTO.setJenkinsJobToken(temp.getJobToken());
						buildToolDefinitionTO.setParamaterizedBuild(temp.getParamaterizedBuild());
					} else if (temp.getBuildToolId() == CMMConstants.External.Tools.ContinuousIntegrationServer.TFS) {
						buildToolDefinitionTO.setBuildToolId(temp.getBuildToolId());
						buildToolDefinitionTO.setTfsCollection(temp.getCollectionName());
						buildToolDefinitionTO.setTfsProject(temp.getProjectName());
						buildToolDefinitionTO.setBuildName(temp.getBuildDefinition());
					} else if (temp.getBuildToolId() == CMMConstants.External.Tools.ContinuousIntegrationServer.TEAMCITY) {
						buildToolDefinitionTO.setBuildToolId(temp.getBuildToolId());
						buildToolDefinitionTO.setTfsProject(temp.getTeamCityProjectId());
						buildToolDefinitionTO.setBuildName(temp.getTeamCityBuildConfig());
						buildToolDefinitionTO.setParamaterizedBuild(temp.getParamaterizedBuild());
					}
					getHibernateTemplate().save(buildToolDefinitionTO);
					applicationReleaseBuildTO.setApplicationReleaseId(applicationReleaseTO.getId());
					applicationReleaseBuildTO.setBuildToolDefinitionId(buildToolDefinitionTO.getId());
					getHibernateTemplate().save(applicationReleaseBuildTO);
				} else if (temp.getBuildToolDefinitionTO().getBuildToolId() != null) {
					if (temp.getBuildToolDefinitionTO().getBuildToolId() == CMMConstants.External.Tools.ContinuousIntegrationServer.JENKINS) {
						buildToolDefinitionTO.setBuildToolId(temp.getBuildToolDefinitionTO().getBuildToolId());
						buildToolDefinitionTO.setBuildName(temp.getBuildToolDefinitionTO().getBuildName());
						buildToolDefinitionTO.setJenkinsJobToken(temp.getBuildToolDefinitionTO().getJenkinsJobToken());
						buildToolDefinitionTO.setParamaterizedBuild(temp.getBuildToolDefinitionTO().getParamaterizedBuild());
					} else if (temp.getBuildToolDefinitionTO().getBuildToolId() == CMMConstants.External.Tools.ContinuousIntegrationServer.TFS) {
						buildToolDefinitionTO.setBuildToolId(temp.getBuildToolDefinitionTO().getBuildToolId());
						buildToolDefinitionTO.setTfsCollection(temp.getBuildToolDefinitionTO().getTfsCollection());
						buildToolDefinitionTO.setTfsProject(temp.getBuildToolDefinitionTO().getTfsProject());
						buildToolDefinitionTO.setBuildName(temp.getBuildToolDefinitionTO().getBuildName());
					} else if (temp.getBuildToolDefinitionTO().getBuildToolId() == CMMConstants.External.Tools.ContinuousIntegrationServer.TEAMCITY) {
						buildToolDefinitionTO.setBuildToolId(temp.getBuildToolDefinitionTO().getBuildToolId());
						buildToolDefinitionTO.setTfsProject(temp.getBuildToolDefinitionTO().getTfsProject());
						buildToolDefinitionTO.setBuildName(temp.getBuildToolDefinitionTO().getBuildName());
						buildToolDefinitionTO.setParamaterizedBuild(temp.getBuildToolDefinitionTO().getParamaterizedBuild());
					}
					getHibernateTemplate().save(buildToolDefinitionTO);
					applicationReleaseBuildTO.setApplicationReleaseId(applicationReleaseTO.getId());
					applicationReleaseBuildTO.setBuildToolDefinitionId(buildToolDefinitionTO.getId());
					getHibernateTemplate().save(applicationReleaseBuildTO);
				}
			}
			for (ApplicationReleaseTestTO temp : applicationReleaseTO.getApplicationReleaseTest()) {
				List<TestingToolTO> testingToolTO = (List<TestingToolTO>) getHibernateTemplate().find("from TestingToolTO where name =? ", temp.getTestTool());
				TestingToolTO testingTool;
				ApplicationReleaseTestTO applicationReleaseTestTO = new ApplicationReleaseTestTO();
				if (CMMConstants.External.Tools.TestingTools.MASTERCRAFT_TAM_SERVER.equalsIgnoreCase(temp.getTestTool()) && (temp.getWorkSpace() != null)) {
					applicationReleaseTestTO.setWorkSpace(temp.getWorkSpace());
					applicationReleaseTestTO.setReleasePlan(temp.getReleasePlan());
					applicationReleaseTestTO.setPhase(temp.getPhase());
					applicationReleaseTestTO.setTestCycle(temp.getTestCycle());
					applicationReleaseTestTO.setTestSuite(temp.getTestSuite());
					applicationReleaseTestTO.setAutomationType(temp.getAutomationType());
					applicationReleaseTestTO.setConfigurationId(temp.getConfigurationId());
					applicationReleaseTestTO.setConfigurationName(temp.getConfigurationName());
					applicationReleaseTestTO.setConfigurationVersion(temp.getConfigurationVersion());
					temp.setTestTool(CMMConstants.External.Tools.TestingTools.MASTERCRAFT_TAM);
					Set<ApplicationReleaseTestTO> applicationReleaseTestSet = applicationReleaseTO.getApplicationReleaseTestSet();
					applicationReleaseTestSet.add(applicationReleaseTestTO);
					applicationReleaseTO.setApplicationReleaseTestSet(applicationReleaseTestSet);
				}
				applicationReleaseTestTO.setApplicationReleaseId(applicationReleaseTO.getId());
				applicationReleaseTestTO.setTestScriptPath(temp.getTestScriptPath());
				applicationReleaseTestTO.setApplicationReleaseId(applicationReleaseTO.getId());
				applicationReleaseTestTO.setTestScriptPath(temp.getTestScriptPath());
				applicationReleaseTestTO.setSelectedTestingPhase(temp.getSelectedTestingPhase());
				applicationReleaseTestTO.setTestTool(temp.getTestTool());
				applicationReleaseTestTO.setServerGroup(temp.getServerGroup());
				applicationReleaseTestTO.setJunitJenkinsJob(temp.getJunitJenkinsJob());
				applicationReleaseTestTO.setMavenizedProject(temp.getMavenizedProject());
				applicationReleaseTestTO.setJmeterDuration(temp.getJmeterDuration());
				applicationReleaseTestTO.setJmeterRampUp(temp.getJmeterRampUp());
				applicationReleaseTestTO.setJmeterUsers(temp.getJmeterUsers());
				applicationReleaseTestTO.setSeleniumUrl(temp.getSeleniumUrl());
				applicationReleaseTestTO.setId(temp.getId());
				if (!testingToolTO.isEmpty()) {
					testingTool = testingToolTO.get(0);
					applicationReleaseTestTO.setTestToolId(testingTool.getId());
				} else {
					applicationReleaseTestTO.setTestToolId(null);
				}
				String mvnProject = temp.getMavenizedProject();
				if ((mvnProject == null) || mvnProject.isEmpty()) {
					temp.setMavenizedProject("N");
				} else {
					temp.setMavenizedProject("Y");
				}
				applicationReleaseTestTO.setSelectedRepository(applicationReleaseTO.getRepoTypeTest());
				getHibernateTemplate().save(applicationReleaseTestTO);
			}
			for (ApplicationReleaseDbTO temp : applicationReleaseTO.getApplicationReleaseDb()) {
				ApplicationReleaseDbTO applicationReleaseDbTO = new ApplicationReleaseDbTO();
				applicationReleaseDbTO.setApplicationReleaseId(releaseId);
				applicationReleaseDbTO.setSoftwareConfigId(temp.getSoftwareConfigId());
				applicationReleaseDbTO.setDatabaseScriptsPath(temp.getDatabaseScriptsPath());
				applicationReleaseDbTO.setDatabaseScripts(temp.getDatabaseScripts());
				applicationReleaseDbTO.setDbUsername(temp.getDbUsername());
				applicationReleaseDbTO.setDbPassword(temp.getDbPassword());
				applicationReleaseDbTO.setSchemaName(temp.getSchemaName());
				applicationReleaseDbTO.setRollbackScriptPath(temp.getRollbackScriptPath());
				applicationReleaseDbTO.setRollbackOrder(temp.getRollbackOrder());
				applicationReleaseDbTO.setSelectedTestingPhase(temp.getSelectedTestingPhase());
				applicationReleaseDbTO.setRequestId(temp.getRequestId());
				applicationReleaseDbTO.setDataMaskingFlag(temp.getDataMaskingFlag());
				if ("Y".equalsIgnoreCase(temp.getDataMaskingFlag()) && (temp.getSelectedMaskingTool() == 0)) {
					applicationReleaseDbTO.setMaskingToolId(null);
				} else {
					applicationReleaseDbTO.setMaskingToolId(temp.getSelectedMaskingTool());
				}
				if ("Y".equalsIgnoreCase(temp.getDataMaskingFlag()) && (temp.getSelectedMaskingTool() == CMMConstants.External.Tools.DataMaskingTools.OPTIM_ID)) {
					applicationReleaseDbTO.setOptimExtractFilename(temp.getOptimExtractFilename());
					applicationReleaseDbTO.setOptimInsertRequestName(temp.getOptimInsertRequestName());
					applicationReleaseDbTO.setOptimExtractRequestName(temp.getOptimExtractRequestName());
				}
				applicationReleaseDbTO.setServerGroupNumber(temp.getServerGroupNumber());
				applicationReleaseDbTO.setAppProDetailsId(temp.getAppProDetailsId());
				applicationReleaseDbTO.setApplicationRelease(applicationReleaseTO);
				applicationReleaseDbTO.setSelectedRepository(applicationReleaseTO.getRepoTypeDatabase());
				getHibernateTemplate().save(applicationReleaseDbTO);
			}
			for (SonarDetailTO temp : applicationReleaseTO.getApplicationCodeReview()) {
				SonarDetailTO sonarDetailTO = new SonarDetailTO();
				sonarDetailTO.setApplicationReleaseId(releaseId);
				sonarDetailTO.setCheckoutLocation(null);
				sonarDetailTO.setSvnPathLocation(temp.getPathForCode());
				sonarDetailTO.setSelectedTestingPhase(temp.getSelectedTestingPhase());
				sonarDetailTO.setSelectedRepository(applicationReleaseTO.getRepoTypeCodeReview());
				getHibernateTemplate().save(sonarDetailTO);
			}
			List<UserDefinedRelParamsTO> userDefinedRelParamsTOList = new ArrayList<UserDefinedRelParamsTO>(0);
			if (!applicationReleaseTO.getParametersList().isEmpty()) {
				for (NolioProcessParametersTO nolioProcessParametersTO : applicationReleaseTO.getParametersList()) {
					UserDefinedRelParamsTO userDefinedRelParamsTO = new UserDefinedRelParamsTO();
					userDefinedRelParamsTO.setReleaseId(releaseId);
					userDefinedRelParamsTO.setNolioProcessParameterValue(nolioProcessParametersTO.getParameterValue());
					if (nolioProcessParametersTO.getParameterType().equalsIgnoreCase(CMMConstants.Framework.GlobalParameters.NOLIO_PARAMETER)) {
						userDefinedRelParamsTO.setNolioProcessParameterId(nolioProcessParametersTO.getParameterId());
						userDefinedRelParamsTO.setScriptParameterId(null);
					}
					if (nolioProcessParametersTO.getParameterType().equalsIgnoreCase(CMMConstants.Framework.GlobalParameters.SCRIPT_PARAMETER)) {
						userDefinedRelParamsTO.setScriptParameterId(nolioProcessParametersTO.getParameterId());
						userDefinedRelParamsTO.setNolioProcessParameterId(null);
					}
					userDefinedRelParamsTOList.add(userDefinedRelParamsTO);
					getHibernateTemplate().save(userDefinedRelParamsTO);
				}
			} else {
				List<NolioProcessParametersTO> userDefinedParametersList = new ArrayList<NolioProcessParametersTO>(0);
				List<ApplicationProfileDetailsTO> profDetails = applicationProfileDAO.fetchProfileDetails(applicationReleaseTO.getSelectedProfile());
				for (ApplicationProfileDetailsTO applicationProfileDetailsTO : profDetails) {
					if (applicationProfileDetailsTO.getSoftwareConfig() != null) {
						userDefinedParametersList.addAll(applicationProfileDAO.getUserDefinedReleaseParameters(applicationProfileDetailsTO.getSoftwareConfig().getId()));
					}
				}
				for (NolioProcessParametersTO nolioProcessParametersTO : userDefinedParametersList) {
					UserDefinedRelParamsTO userDefinedRelParamsTO = new UserDefinedRelParamsTO();
					userDefinedRelParamsTO.setReleaseId(releaseId);
					userDefinedRelParamsTO.setNolioProcessParameterId(nolioProcessParametersTO.getParameterId());
					userDefinedRelParamsTO.setNolioProcessParameterValue(nolioProcessParametersTO.getParameterValue());
					if (nolioProcessParametersTO.getParameterType().equalsIgnoreCase(CMMConstants.Framework.GlobalParameters.NOLIO_PARAMETER)) {
						userDefinedRelParamsTO.setNolioProcessParameterId(nolioProcessParametersTO.getParameterId());
						userDefinedRelParamsTO.setScriptParameterId(null);
					}
					if (nolioProcessParametersTO.getParameterType().equalsIgnoreCase(CMMConstants.Framework.GlobalParameters.SCRIPT_PARAMETER)) {
						userDefinedRelParamsTO.setScriptParameterId(nolioProcessParametersTO.getParameterId());
						userDefinedRelParamsTO.setNolioProcessParameterId(null);
					}
					userDefinedRelParamsTOList.add(userDefinedRelParamsTO);
					getHibernateTemplate().save(userDefinedRelParamsTO);
				}
			}
			return releaseId;
		} catch (ConstraintViolationException ce) {
			LOG.error(ce);
			throw new CMMException("Release Name already exists. ApplicationReleaseDAOImpl : addRelease", ce);
		} catch (DataIntegrityViolationException dive) {
			LOG.error(dive);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : addRelease", dive);
		} catch (DataAccessException | HibernateException div) {
			LOG.error(div);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : addRelease", div);
		}
	}
	
	@Override
	public ApplicationReleaseTO getReleaseDetails(ApplicationReleaseTO applicationReleaseTO) throws CMMException {
	
		try {
			ApplicationReleaseTO releaseTO = (ApplicationReleaseTO) getHibernateTemplate().find("from ApplicationReleaseTO where id=? ", applicationReleaseTO.getId()).get(0);
			releaseTO.setSelectedApplication(releaseTO.getApplicationId());
			releaseTO.setSelectedProfile(releaseTO.getApplicationProfileId());
			releaseTO.setSelectedStatus(releaseTO.getStatus());
			return releaseTO;
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Error in accessing ApplicationReleaseDAOImpl : getReleaseDetails", dae);
		}
	}
	
	@Override
	public HardwareTO fetchTemplateName(Long softwareconfigid, Long serverid) throws CMMException {
	
		try {
			SoftwareconfigTO sconfig = (SoftwareconfigTO) getHibernateTemplate().find("from SoftwareconfigTO where id=?", softwareconfigid).get(0);
			SoftwareTO s = (SoftwareTO) getHibernateTemplate().find("from SoftwareTO where id=?", sconfig.getDeviceId()).get(0);
			HardwareTO h = (HardwareTO) getHibernateTemplate().find("from HardwareTO where id=?", serverid).get(0);
			h.setSoftwareName(s.getName());
			return h;
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : fetchTemplateName", dae);
		}
	}
	
	@Override
	public void editRelease(ApplicationReleaseTO applicationReleaseTO) throws CMMException {
	
		try {
			ApplicationReleaseTO applicationReleaseTOnew = getReleaseDetails(applicationReleaseTO);
			List<Long> appRelDBList = new ArrayList<Long>();
			List<Long> finalDBDetailsList = new ArrayList<Long>();
			for (ApplicationReleaseDbTO details : applicationReleaseTOnew.getApplicationReleaseDbSet()) {
				appRelDBList.add(details.getId());
				//docker						
				if ((details.getSoftwareConfigTO()) != null) {
					finalDBDetailsList.add(details.getSoftwareConfigTO().getId());
				}
			}
			List<Long> appRelSCList = new ArrayList<Long>();
			List<Long> finalSCDetailsList = new ArrayList<Long>();
			for (ApplicationReleaseSourcecodeTO details : applicationReleaseTOnew.getAppRelSourcecodeSet()) {
				appRelSCList.add(details.getId());
				//docker		
				if ((details.getSoftwareConfigTO()) != null) {
					finalSCDetailsList.add(details.getSoftwareConfigTO().getId());
				}
			}
			List<Long> appRelBuildList = new ArrayList<Long>();
			for (ApplicationReleaseBuildTO details : applicationReleaseTOnew.getApplicationReleaseBuildSet()) {
				appRelBuildList.add(details.getId());
			}
			List<Long> appRelTestList = new ArrayList<Long>();
			for (ApplicationReleaseTestTO details : applicationReleaseTOnew.getApplicationReleaseTestSet()) {
				appRelTestList.add(details.getId());
			}
			List<Long> appRelSonarList = new ArrayList<Long>();
			for (SonarDetailTO details : applicationReleaseTOnew.getSonarDetailSet()) {
				appRelSonarList.add(details.getId());
			}
			applicationReleaseTOnew.setApplicationId(applicationReleaseTO.getSelectedApplication());
			applicationReleaseTOnew.setApplicationProfileId(applicationReleaseTO.getSelectedProfile());
			applicationReleaseTOnew.setStatus(applicationReleaseTO.getSelectedStatus());
			applicationReleaseTOnew.setDeployFromNexus(applicationReleaseTO.getDeployFromNexus());
			applicationReleaseTOnew.setName(applicationReleaseTO.getName());
			applicationReleaseTOnew.setDescription(applicationReleaseTO.getDescription());
			if (!applicationReleaseTO.getAppRelSourcecode().isEmpty()) {
				if ((applicationReleaseTO.getDeployFromNexus() != null) && applicationReleaseTO.getDeployFromNexus().equalsIgnoreCase(CMMConstants.DeployToNexusFlag.NOT_TO_TRIGGER_BUILD)) {
					RepositoryMasterTO repositoryMasterTO = saveRepositoryMasterDetails(applicationReleaseTO);
					List<ApplicationReleaseSharedMappingTO> applicationReleaseSharedMappingList = (List<ApplicationReleaseSharedMappingTO>) getHibernateTemplate().find("from ApplicationReleaseSharedMappingTO a where a.repositoryMaster.id=?", repositoryMasterTO.getId());
					ApplicationReleaseSharedMappingTO applicationReleaseSharedMappingTO = new ApplicationReleaseSharedMappingTO();
					ApplicationReleaseSharedDetailsTO applicationReleaseSharedDetailsTO = new ApplicationReleaseSharedDetailsTO();
					if (!applicationReleaseSharedMappingList.isEmpty()) {
						applicationReleaseSharedMappingTO = applicationReleaseSharedMappingList.get(0);
						if (applicationReleaseSharedMappingTO.getSharedResourceId() != null) {
							List<ApplicationReleaseSharedDetailsTO> applicationReleaseSharedDetailsList = (List<ApplicationReleaseSharedDetailsTO>) getHibernateTemplate().find("from ApplicationReleaseSharedDetailsTO a where a.id=?", applicationReleaseSharedMappingTO.getSharedResourceId());
							if (!applicationReleaseSharedDetailsList.isEmpty()) {
								applicationReleaseSharedDetailsTO = applicationReleaseSharedDetailsList.get(0);
								if (applicationReleaseTO.getSelectedResource().equalsIgnoreCase(ResourceForDeployment.SHARED_PATH.getPath())) {
									applicationReleaseSharedDetailsTO.setSharedIp(applicationReleaseTO.getApplicationReleaseSharedDetailsTO().getSharedIp());
									getHibernateTemplate().update(applicationReleaseSharedDetailsTO);
								}
							}
						} else {
							if (applicationReleaseTO.getSelectedResource().equalsIgnoreCase(ResourceForDeployment.SHARED_PATH.getPath())) {
								applicationReleaseSharedDetailsTO.setSharedIp(applicationReleaseTO.getApplicationReleaseSharedDetailsTO().getSharedIp());
								getHibernateTemplate().save(applicationReleaseSharedDetailsTO);
							}
							applicationReleaseSharedMappingTO.setRepositoryMaster(repositoryMasterTO);
							applicationReleaseSharedMappingTO.setSharedResourceId(applicationReleaseSharedDetailsTO.getId());
							getHibernateTemplate().update(applicationReleaseSharedMappingTO);
						}
					} else {
						if (applicationReleaseTO.getSelectedResource().equalsIgnoreCase(ResourceForDeployment.SHARED_PATH.getPath())) {
							applicationReleaseSharedDetailsTO.setSharedIp(applicationReleaseTO.getApplicationReleaseSharedDetailsTO().getSharedIp());
							getHibernateTemplate().save(applicationReleaseSharedDetailsTO);
						}
						applicationReleaseSharedMappingTO.setRepositoryMaster(repositoryMasterTO);
						applicationReleaseSharedMappingTO.setSharedResourceId(applicationReleaseSharedDetailsTO.getId());
						getHibernateTemplate().save(applicationReleaseSharedMappingTO);
					}
				}
			}
			applicationReleaseTOnew.getAppRelSourcecodeSet().clear();
			for (ApplicationReleaseSourcecodeTO temp : applicationReleaseTO.getAppRelSourcecode()) {
				if (temp != null) {
					ApplicationReleaseSourcecodeTO sc = new ApplicationReleaseSourcecodeTO();
					sc.setServerGroupNumber(temp.getServerGroupNumber());
					sc.setAppProDetailsId(temp.getAppProDetailsId());
					sc.setSoftwareConfigId(temp.getSoftwareConfigId());
					sc.setApplicationReleaseSc(applicationReleaseTOnew);
					sc.setSourceCodePath(temp.getSourceCodePath());
					sc.setEarPath(temp.getEarPath());
					sc.setScriptsPath(temp.getScriptsPath());
					sc.setContextPath(temp.getContextPath());
					sc.setNetraNexusPath(temp.getNetraNexusPath());
					sc.setApplicationReleaseId(sc.getApplicationReleaseSc().getId());
					sc.setSelectedTestingPhase(temp.getSelectedTestingPhase());
					sc.setSelectedRepository(applicationReleaseTO.getRepoTypeDatabase());
					if (applicationReleaseTO.getYesNoRadio() != null) {
						if ("buildYes".equalsIgnoreCase(applicationReleaseTO.getYesNoRadio())) {
							if (applicationReleaseTO.isOverwriteFlag()) {
								sc.setOverWriteFlag("Y");
							} else {
								sc.setOverWriteFlag("N");
							}
						}
						if ("radioNo".equalsIgnoreCase(applicationReleaseTO.getYesNoRadio())) {
							sc.setOverWriteFlag(null);
						}
					}
					sc.setApplicationRelease(applicationReleaseTOnew);
					applicationReleaseTOnew.getAppRelSourcecodeSet().add(sc);
				}
			}
			applicationReleaseTOnew.getApplicationReleaseDbSet().clear();
			for (ApplicationReleaseDbTO temp : applicationReleaseTO.getApplicationReleaseDb()) {
				if (temp != null) {
					ApplicationReleaseDbTO applicationReleaseDb = new ApplicationReleaseDbTO();
					applicationReleaseDb.setServerGroupNumber(temp.getServerGroupNumber());
					applicationReleaseDb.setAppProDetailsId(temp.getAppProDetailsId());
					applicationReleaseDb.setSoftwareConfigId(temp.getSoftwareConfigId());
					applicationReleaseDb.setDatabaseScriptsPath(temp.getDatabaseScriptsPath());
					applicationReleaseDb.setDatabaseScripts(temp.getDatabaseScripts());
					applicationReleaseDb.setSchemaName(temp.getSchemaName());
					applicationReleaseDb.setDbUsername(temp.getDbUsername());
					applicationReleaseDb.setDbPassword(temp.getDbPassword());
					applicationReleaseDb.setRollbackScriptPath(temp.getRollbackScriptPath());
					applicationReleaseDb.setRollbackOrder(temp.getRollbackOrder());
					applicationReleaseDb.setDataMaskingFlag(temp.getDataMaskingFlag());
					applicationReleaseDb.setSelectedTestingPhase(temp.getSelectedTestingPhase());
					applicationReleaseDb.setSelectedRepository(applicationReleaseTO.getRepoTypeDatabase());
					if ("Y".equalsIgnoreCase(temp.getDataMaskingFlag()) && (temp.getSelectedMaskingTool() == 0)) {
						applicationReleaseDb.setMaskingToolId(null);
					} else {
						applicationReleaseDb.setMaskingToolId(temp.getSelectedMaskingTool());
					}
					if ("Y".equalsIgnoreCase(temp.getDataMaskingFlag()) && (temp.getSelectedMaskingTool() == CMMConstants.External.Tools.DataMaskingTools.OPTIM_ID)) {
						applicationReleaseDb.setOptimExtractFilename(temp.getOptimExtractFilename());
						applicationReleaseDb.setOptimInsertRequestName(temp.getOptimInsertRequestName());
						applicationReleaseDb.setOptimExtractRequestName(temp.getOptimExtractRequestName());
					}
					applicationReleaseDb.setApplicationRelease(applicationReleaseTOnew);
					applicationReleaseTOnew.getApplicationReleaseDbSet().add(applicationReleaseDb);
				}
			}
			applicationReleaseTOnew.getApplicationReleaseBuildSet().clear();
			Long relId = applicationReleaseTO.getId();
			HashMap<String, Long> buildDefMap = getBuildDefinitionForRelease(relId);
			if ("Y".equalsIgnoreCase(applicationReleaseTO.getDeployFromNexus())) {
				for (ApplicationReleaseBuildTO temp : applicationReleaseTO.getApplicationReleaseBuild()) {
					if (buildDefMap.containsKey(temp.getJobName())) {
						temp.setBuildDefinition(String.valueOf(buildDefMap.get(temp.getJobName())));
					}
					ApplicationReleaseBuildTO applicationReleaseBuildTO = new ApplicationReleaseBuildTO();
					applicationReleaseBuildTO.setSelectedTestingPhase(temp.getSelectedTestingPhase());
					BuildToolDefinitionTO buildToolDefinitionTO = new BuildToolDefinitionTO();
					buildToolDefinitionTO.setBuildToolId(temp.getBuildToolId());
					if (temp.getBuildToolId() == CMMConstants.External.Tools.ContinuousIntegrationServer.JENKINS) {
						buildToolDefinitionTO.setBuildName(temp.getJobName());
						buildToolDefinitionTO.setParamaterizedBuild(temp.getParamaterizedBuild());
					} else {
						buildToolDefinitionTO.setBuildName(temp.getBuildDefinition());
					}
					buildToolDefinitionTO.setTfsCollection(temp.getCollectionName());
					buildToolDefinitionTO.setTfsProject(temp.getProjectName());
					buildToolDefinitionTO.setJenkinsJobToken(temp.getJobToken());
					if (applicationReleaseTO.getBuildDefinitionId() != null) {
						buildToolDefinitionTO.setId(applicationReleaseTO.getBuildDefinitionId());
						getHibernateTemplate().update(buildToolDefinitionTO);
					} else {
						getHibernateTemplate().save(buildToolDefinitionTO);
					}
					Long appRelBuildID = getAppRelBuildMapID(relId, buildToolDefinitionTO.getId());
					if (appRelBuildID != 0L) {
						applicationReleaseBuildTO.setId(appRelBuildID);
					}
					applicationReleaseBuildTO.setApplicationReleaseId(applicationReleaseTO.getId());
					applicationReleaseBuildTO.setBuildToolDefinitionId(buildToolDefinitionTO.getId());
					applicationReleaseTOnew.getApplicationReleaseBuildSet().add(applicationReleaseBuildTO);
				}
			}
			applicationReleaseTOnew.getApplicationReleaseTestSet().clear();
			for (ApplicationReleaseTestTO temp : applicationReleaseTO.getApplicationReleaseTest()) {
				List<TestingToolTO> testingToolTO = (List<TestingToolTO>) getHibernateTemplate().find("from TestingToolTO where name =? ", temp.getTestTool());
				TestingToolTO testingTool;
				if (CMMConstants.External.Tools.TestingTools.MASTERCRAFT_TAM_SERVER.equalsIgnoreCase(temp.getTestTool())) {
					temp.setTestTool(CMMConstants.External.Tools.TestingTools.MASTERCRAFT_TAM);
				}
				if (temp != null) {
					if (!testingToolTO.isEmpty()) {
						testingTool = testingToolTO.get(0);
						temp.setTestToolId(testingTool.getId());
					} else {
						temp.setTestToolId(null);
					}
					temp.setApplicationReleaseId(applicationReleaseTOnew.getId());
					temp.setSelectedRepository(applicationReleaseTO.getRepoTypeDatabase());
					if ((temp.getMavenizedProject() == null) || temp.getMavenizedProject().isEmpty() || "N".equalsIgnoreCase(temp.getMavenizedProject())) {
						temp.setMavenizedProject("N");
					} else {
						temp.setMavenizedProject("Y");
					}
					applicationReleaseTOnew.getApplicationReleaseTestSet().add(temp);
				}
			}
			applicationReleaseTOnew.getSonarDetailSet().clear();
			for (SonarDetailTO temp : applicationReleaseTO.getApplicationCodeReview()) {
				SonarDetailTO sonarDetail = new SonarDetailTO();
				if (temp != null) {
					sonarDetail.setSelectedTestingPhase(temp.getSelectedTestingPhase());
					sonarDetail.setSelectedRepository(applicationReleaseTO.getRepoTypeDatabase());
					sonarDetail.setApplicationReleaseId(applicationReleaseTOnew.getId());
					sonarDetail.setSvnPathLocation(temp.getPathForCode());
					applicationReleaseTOnew.getSonarDetailSet().add(sonarDetail);
				}
			}
			getHibernateTemplate().saveOrUpdate(applicationReleaseTOnew);
			deleteUserDefinedReleaseParameters(applicationReleaseTO.getId());
			if (!applicationReleaseTO.getParametersList().isEmpty()) {
				for (NolioProcessParametersTO nolioProcessParametersTO : applicationReleaseTO.getParametersList()) {
					UserDefinedRelParamsTO userDefinedRelParamsTO = new UserDefinedRelParamsTO();
					userDefinedRelParamsTO.setReleaseId(applicationReleaseTO.getId());
					userDefinedRelParamsTO.setNolioProcessParameterId(nolioProcessParametersTO.getParameterId());
					userDefinedRelParamsTO.setNolioProcessParameterValue(nolioProcessParametersTO.getParameterValue());
					if (nolioProcessParametersTO.getParameterType().equalsIgnoreCase(CMMConstants.Framework.GlobalParameters.NOLIO_PARAMETER)) {
						userDefinedRelParamsTO.setNolioProcessParameterId(nolioProcessParametersTO.getParameterId());
						userDefinedRelParamsTO.setScriptParameterId(null);
					}
					if (nolioProcessParametersTO.getParameterType().equalsIgnoreCase(CMMConstants.Framework.GlobalParameters.SCRIPT_PARAMETER)) {
						userDefinedRelParamsTO.setScriptParameterId(nolioProcessParametersTO.getParameterId());
						userDefinedRelParamsTO.setNolioProcessParameterId(null);
					}
					getHibernateTemplate().save(userDefinedRelParamsTO);
				}
			}
		} catch (ConstraintViolationException ce) {
			LOG.error(ce);
			throw new CMMException("Release Name already exists. ApplicationReleaseDAOImpl : editRelease", ce);
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : editRelease", dae);
		}
	}
	
	public void deleteUserDefinedReleaseParameters(Long releaseId) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			Query query = session.createQuery("delete UserDefinedRelParamsTO where releaseId = :releaseId");
			query.setParameter("releaseId", releaseId);
			query.executeUpdate();
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.ApplicationReleaseDAOImpl:deleteUserDefinedReleaseParameters", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	private HashMap<String, Long> getBuildDefinitionForRelease(Long relId) throws CMMException {
	
		HashMap<String, Long> buildDefMap = new HashMap<String, Long>();
		Session session = null;
		List<BuildToolDefinitionTO> buildToolDefinitionTOLst = new ArrayList<BuildToolDefinitionTO>();
		try {
			session = getSession();
			String query = CMMConstants.Presentation.Reporting.QUERY_BUILD_DEF_FOR_RELEASE + relId;
			Query q = session.createQuery(query);
			List resultWithAliasedBean = q.setResultTransformer(Transformers.aliasToBean(BuildToolDefinitionTO.class)).list();
			if (!resultWithAliasedBean.isEmpty()) {
				buildToolDefinitionTOLst = resultWithAliasedBean;
				for (BuildToolDefinitionTO item : buildToolDefinitionTOLst) {
					buildDefMap.put(item.getBuildName(), item.getId());
				}
			}
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : editRelease", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return buildDefMap;
	}
	
	private Long getAppRelBuildMapID(Long relId, Long buildDefId) throws CMMException {
	
		Long id = 0L;
		Session session = null;
		try {
			session = getSession();
			String query = CMMConstants.Presentation.Reporting.QUERY_BUILD_REL_MAP;
			Query q = session.createQuery(query);
			q.setParameter(0, relId);
			q.setParameter(1, buildDefId);
			List resultWithAliasedBean = q.list();
			if (!resultWithAliasedBean.isEmpty()) {
				id = (Long) resultWithAliasedBean.get(0);
			}
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : getAppRelBuildMapID", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return id;
	}
	
	@Override
	public ServiceRequestTO editReleaseDetailsForDbRefresh(ApplicationReleaseTO applicationReleaseTO) throws CMMException {
	
		ServiceRequestTO requestTO1 = new ServiceRequestTO();
		try {
			if (applicationReleaseTO.getId() != null) {
				getReleaseDetails(applicationReleaseTO);
			}
			requestTO1.setApplicationId(applicationReleaseTO.getSelectedApplication());
			requestTO1.setStatusId(142L);
			requestTO1.setServiceId(applicationReleaseTO.getServiceId());
			requestTO1.setActionFlag("Y");
			requestTO1.setEnvironmentId(applicationReleaseTO.getEnvironmentId());
			requestTO1.setCreatedById(applicationReleaseTO.getCreatedById());
			requestTO1.setCreatedByDate(DateUtils.getStartTime(new Date()));
			requestTO1.setModifiedbyId(applicationReleaseTO.getModifiedbyId());
			requestTO1.setModifiedbyDate(DateUtils.getStartTime(new Date()));
			requestTO1.setIsScheduled(applicationReleaseTO.getIsScheduled());
			requestTO1.setCronExp(applicationReleaseTO.getCronExp());
			requestTO1.setSelectedTestingPhase(applicationReleaseTO.getSelectedTestingPhase());
			requestTO1.setApplicationReleaseId(applicationReleaseTO.getSelectedExistingReleaseid());
			requestTO1.setRemark(applicationReleaseTO.getRemark());
			getHibernateTemplate().save(requestTO1);
			int success = -1;
			EnvironmentTO envTO = new EnvironmentTO();
			envTO.setId(applicationReleaseTO.getEnvironmentId());
			envTO.setCreatedById(applicationReleaseTO.getCreatedById());
			requestTO1.setClientId(applicationReleaseTO.getClientId());
			requestTO1.setWorkFlowId(applicationReleaseTO.getWorkFlowId());
			if (requestTO1.getClientId() != 0) {
				success = serviceRequestDAO.generateWorkflow(envTO, requestTO1);
				requestTO1.setSuccess(success);
				if (success == 1) {
					requestTO1.setStatusId(141L);
					getHibernateTemplate().update(requestTO1);
				}
			}
			requestTO1.setSuccess(success);
		} catch (ConstraintViolationException ce) {
			LOG.error(ce);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : editReleaseDetailsForDbRefresh", ce);
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : editReleaseDetailsForDbRefresh", dae);
		}
		return requestTO1;
	}
	
	@Override
	public ServiceRequestTO editReleaseDetails(ApplicationReleaseTO applicationReleaseTO) throws CMMException {
	
		ServiceRequestTO requestTO1 = new ServiceRequestTO();
		try {
			ApplicationReleaseTO applicationReleaseTOnew = getReleaseDetails(applicationReleaseTO);
			ApplicationReleaseTO appRelTO = new ApplicationReleaseTO();
			appRelTO.setApplicationId(applicationReleaseTOnew.getSelectedApplication());
			appRelTO.setApplicationProfileId(applicationReleaseTOnew.getSelectedProfile());
			appRelTO.setStatus(applicationReleaseTOnew.getSelectedStatus());
			appRelTO.setSourcePath(applicationReleaseTOnew.getSourcePath());
			appRelTO.setName(applicationReleaseTO.getName());
			appRelTO.setDescription(applicationReleaseTOnew.getDescription());
			appRelTO.setType("S");
			appRelTO.setParentReleaseId(applicationReleaseTO.getParentReleaseId());
			getHibernateTemplate().save(appRelTO);
			if (!applicationReleaseTO.getAppRelSourcecode().isEmpty()) {
				Long softidDB = applicationReleaseTO.getAppRelSourcecode().get(0).getSoftwareConfigId();
				applicationReleaseTOnew.getAppRelSourcecodeSet().clear();
				for (ApplicationReleaseSourcecodeTO temp : applicationReleaseTO.getAppRelSourcecode()) {
					if (temp != null) {
						ApplicationReleaseSourcecodeTO sc = new ApplicationReleaseSourcecodeTO();
						ApplicationProfileDetailsTO a = fetchAppProDetails(applicationReleaseTO.getSelectedProfile(), softidDB);
						sc.setServerId(a.getHardwareId());
						sc.setServerGroupNumber(a.getServerGroup());
						sc.setAppProDetailsId(a.getId());
						sc.setSoftwareConfigId(temp.getSoftwareConfigId());
						sc.setApplicationReleaseSc(applicationReleaseTOnew);
						sc.setSourceCodePath(temp.getSourceCodePath());
						sc.setEarPath(temp.getEarPath());
						sc.setApplicationReleaseId(appRelTO.getId());
						getHibernateTemplate().save(sc);
					}
				}
			}
			if (!applicationReleaseTO.getApplicationReleaseBuild().isEmpty()) {
				applicationReleaseTOnew.getApplicationReleaseBuildSet().clear();
				for (ApplicationReleaseBuildTO temp : applicationReleaseTO.getApplicationReleaseBuild()) {
					ApplicationReleaseBuildTO buildTO = new ApplicationReleaseBuildTO();
					buildTO.setApplicationReleaseId(appRelTO.getId());
					buildTO.setJobName(temp.getJobName());
					buildTO.setBuildToolId(temp.getBuildToolId());
					getHibernateTemplate().save(buildTO);
				}
			}
			if (!applicationReleaseTO.getApplicationReleaseTest().isEmpty()) {
				applicationReleaseTOnew.getApplicationReleaseTestSet().clear();
				for (ApplicationReleaseTestTO temp : applicationReleaseTO.getApplicationReleaseTest()) {
					ApplicationReleaseTestTO testTO = new ApplicationReleaseTestTO();
					testTO.setTestScriptPath(temp.getTestScriptPath());
					testTO.setTestTool(temp.getTestTool());
					testTO.setApplicationReleaseId(appRelTO.getId());
					getHibernateTemplate().save(testTO);
				}
			}
			requestTO1.setApplicationId(applicationReleaseTO.getApplicationId());
			if (applicationReleaseTO.getRoleId() <= 1) {
				requestTO1.setStatusId(142L);
			} else {
				requestTO1.setStatusId(141L);
			}
			requestTO1.setServiceId(applicationReleaseTO.getServiceId());
			requestTO1.setActionFlag("Y");
			requestTO1.setEnvironmentId(applicationReleaseTO.getEnvironmentId());
			requestTO1.setCreatedById(applicationReleaseTO.getCreatedById());
			requestTO1.setCreatedByDate(DateUtils.getStartTime(new Date()));
			requestTO1.setModifiedbyId(applicationReleaseTO.getModifiedbyId());
			requestTO1.setModifiedbyDate(DateUtils.getStartTime(new Date()));
			requestTO1.setApplicationReleaseId(appRelTO.getId());
			requestTO1.setRemark(applicationReleaseTO.getRemark());
			getHibernateTemplate().save(requestTO1);
			ApplicationReleaseTO relTO = (ApplicationReleaseTO) getHibernateTemplate().find("from ApplicationReleaseTO where id=?", appRelTO.getId()).get(0);
			relTO.setRequestId(requestTO1.getId());
			applicationReleaseTOnew.getApplicationReleaseDbSet().clear();
			for (ApplicationReleaseDbTO temp : applicationReleaseTO.getApplicationReleaseDb()) {
				if (temp != null) {
					ApplicationReleaseDbTO applicationReleaseDb = new ApplicationReleaseDbTO();
					ApplicationProfileDetailsTO a = fetchAppProDetails(applicationReleaseTO.getSelectedProfile(), temp.getSoftwareConfigId());
					applicationReleaseDb.setServerId(a.getHardwareId());
					applicationReleaseDb.setServerGroupNumber(a.getServerGroup());
					applicationReleaseDb.setAppProDetailsId(a.getId());
					applicationReleaseDb.setSoftwareConfigId(temp.getSoftwareConfigId());
					applicationReleaseDb.setDatabaseScriptsPath(temp.getDatabaseScriptsPath());
					applicationReleaseDb.setDatabaseScripts(temp.getDatabaseScripts());
					applicationReleaseDb.setSchemaName(temp.getSchemaName());
					applicationReleaseDb.setRollbackScriptPath(temp.getRollbackScriptPath());
					applicationReleaseDb.setRollbackOrder(temp.getRollbackOrder());
					applicationReleaseDb.setRequestId(requestTO1.getId());
					applicationReleaseDb.setApplicationRelease(relTO);
					relTO.getApplicationReleaseDbSet().add(applicationReleaseDb);
				}
			}
			getHibernateTemplate().update(relTO);
			int success = -1;
			EnvironmentTO envTO = new EnvironmentTO();
			envTO.setId(applicationReleaseTO.getEnvironmentId());
			envTO.setCreatedById(applicationReleaseTO.getCreatedById());
			requestTO1.setClientId(applicationReleaseTO.getClientId());
			requestTO1.setWorkFlowId(applicationReleaseTO.getWorkFlowId());
			if (requestTO1.getClientId() != 0) {
				success = serviceRequestDAO.generateWorkflow(envTO, requestTO1);
				requestTO1.setSuccess(success);
			}
			requestTO1.setSuccess(success);
		} catch (ConstraintViolationException ce) {
			LOG.error(ce);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : editReleaseDetails", ce);
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : editReleaseDetails", dae);
		}
		return requestTO1;
	}
	
	@Override
	public boolean checkName(ApplicationReleaseTO applicationReleaseTO) throws CMMException {
	
		boolean flag = false;
		try {
			List<ApplicationReleaseTO> unit = (List<ApplicationReleaseTO>) getHibernateTemplate().find("from ApplicationReleaseTO where name=?", applicationReleaseTO.getName());
			if (!unit.isEmpty()) {
				flag = true;
			} else {
				flag = false;
			}
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : checkName", dae);
		}
		return flag;
	}
	
	@Override
	public List<ApplicationProfileTO> getAllApplicationProfiles(Long applicationId) throws CMMException {
	
		List<ApplicationProfileTO> profTO = new ArrayList<ApplicationProfileTO>(0);
		try {
			List<ApplicationProfileMappingTO> mapTO = (List<ApplicationProfileMappingTO>) getHibernateTemplate().find("from ApplicationProfileMappingTO where applicationTO.id=?", applicationId);
			List<Long> appProfileId = new ArrayList<Long>();
			if (!mapTO.isEmpty()) {
				for (int i = 0; i < mapTO.size(); i++) {
					appProfileId.add(mapTO.get(i).getProfileId());
				}
				profTO = (List<ApplicationProfileTO>) getHibernateTemplate().findByNamedQueryAndNamedParam("fetchProfileName", "appProfileId", appProfileId);
			}
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : getAllApplicationProfiles", dae);
		}
		return profTO;
	}
	
	@Override
	public List<ApplicationProfileDetailsTO> fetchAppProDetails(Long selectedProfile) throws CMMException {
	
		try {
			return (List<ApplicationProfileDetailsTO>) getHibernateTemplate().find("from ApplicationProfileDetailsTO where profileId=?", selectedProfile);
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Error in fetching ApplicationReleaseDAOImpl : fetchAppProDetails(Long)", dae);
		}
	}
	
	@Override
	public List<EnvironmentDetailsTO> fetchEnvDetails(Long selectedEnv) throws CMMException {
	
		try {
			return (List<EnvironmentDetailsTO>) getHibernateTemplate().find("from EnvironmentDetailsTO where environment.id=?", selectedEnv);
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : fetchEnvDetails(Long)", dae);
		}
	}
	
	@Override
	public SoftwareconfigTO getSoftwareConfigDetails(long mappedSoftwareId) throws CMMException {
	
		try {
			List<SoftwareconfigTO> softwareconfigTOList = (List<SoftwareconfigTO>) getHibernateTemplate().find("from SoftwareconfigTO where id=?", mappedSoftwareId);
			if ((softwareconfigTOList == null) || softwareconfigTOList.isEmpty()) {
				LOG.debug("No record found in Softwareconfig table for requestId:: " + mappedSoftwareId);
				throw new CMMException(" ApplicationReleaseDAOImpl : getSoftwareConfigDetails No record found in Softwareconfig table for requestId:: " + mappedSoftwareId);
			}
			return softwareconfigTOList.get(0);
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : getSoftwareConfigDetails", dae);
		}
	}
	
	@Override
	public List<SoftwareconfigTO> getSoftwareListForProfile(Long selectedProfile, String existingSoftwareConfigIds) throws CMMException {
	
		Session session = getSession();
		try {
			String hql = "";
			if (existingSoftwareConfigIds.length() > 0) {
				existingSoftwareConfigIds = existingSoftwareConfigIds.substring(1);
				hql = "select sc from SoftwareconfigTO as sc, ApplicationProfileDetailsTO as apd where sc.id=apd.mappedSoftwareId and apd.profile=:selectedProfile and sc.id not in (:existingSoftwareConfigIds)";
			} else {
				hql = "select sc from SoftwareconfigTO as sc, ApplicationProfileDetailsTO as apd where sc.id=apd.mappedSoftwareId and apd.profile=:selectedProfile";
			}
			hql = hql + " and lower(sc.software.type) like '%database%'";
			Query q = session.createQuery(hql);
			q.setParameter("selectedProfile", selectedProfile);
			if (existingSoftwareConfigIds.length() > 0) {
				q.setParameter("existingSoftwareConfigIds", existingSoftwareConfigIds);
			}
			return q.list();
		} catch (Exception e) {
			LOG.error(e);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : getSoftwareListForProfile", e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<SoftwareconfigTO> getSoftwareListForProfileForAppServer(Long selectedProfile, String existingSoftwareConfigIds) throws CMMException {
	
		Session session = getSession();
		try {
			String hql = "";
			if (existingSoftwareConfigIds.length() > 0) {
				existingSoftwareConfigIds = existingSoftwareConfigIds.substring(1);
				hql = "select sc from SoftwareconfigTO as sc, ApplicationProfileDetailsTO as apd where sc.id=apd.mappedSoftwareId and apd.profile=:selectedProfile and sc.id not in (:existingSoftwareConfigIds)";
			} else {
				hql = "select sc from SoftwareconfigTO as sc, ApplicationProfileDetailsTO as apd where sc.id=apd.mappedSoftwareId and apd.profile=:selectedProfile";
			}
			hql = hql + " and lower(sc.software.type) like '%Application Server%'";
			Query q = session.createQuery(hql);
			q.setParameter("selectedProfile", selectedProfile);
			if (existingSoftwareConfigIds.length() > 0) {
				q.setParameter("existingSoftwareConfigIds", existingSoftwareConfigIds);
			}
			return q.list();
		} catch (Exception e) {
			LOG.error(e);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : getSoftwareListForProfileForAppServer", e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<ApplicationReleaseDbTO> fetchReleaseDetails(Long id) throws CMMException {
	
		try {
			List<ApplicationReleaseDbTO> temp = new ArrayList<ApplicationReleaseDbTO>();
			List<Object[]> objList = (List<Object[]>) getHibernateTemplate().find("from ApplicationReleaseDbTO e inner join e.applicationRelease b  where b.id=?", id);
			for (Object[] list : objList) {
				temp.add((ApplicationReleaseDbTO) list[0]);
			}
			return temp;
		} catch (DataAccessException | HibernateException e) {
			LOG.error(e);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : fetchReleaseDetails(Long)", e);
		}
	}
	
	@Override
	public List<ApplicationReleaseDbTO> fetchDBReleaseDetails(Long id) throws CMMException {
	
		try {
			return (List<ApplicationReleaseDbTO>) getHibernateTemplate().find("from ApplicationReleaseDbTO e where e.id=?", id);
		} catch (DataAccessException | HibernateException e) {
			LOG.error(e);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : fetchReleaseDetails(Long)", e);
		}
	}
	
	@Override
	public ApplicationReleaseTO getDetailsForRelease(Long id) throws CMMException {
	
		try {
			List<ApplicationReleaseTO> applicationReleaseList = (List<ApplicationReleaseTO>) getHibernateTemplate().find("from ApplicationReleaseTO where id=?", id);
			if ((applicationReleaseList == null) || applicationReleaseList.isEmpty()) {
				throw new CMMException("No application Release data found in DB.");
			}
			return applicationReleaseList.get(0);
		} catch (DataAccessException | HibernateException e) {
			LOG.error(e);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : getDetailsForRelease", e);
		}
	}
	
	@Override
	public SonarDetailTO getCodeAnalysisDetail(Long id) throws CMMException {
	
		try {
			List<SonarDetailTO> codeDetail = (List<SonarDetailTO>) getHibernateTemplate().find("from SonarDetailTO where application_release_id=?", id);
			if (!codeDetail.isEmpty()) {
				return codeDetail.get(0);
			} else {
				return null;
			}
		} catch (DataAccessException | HibernateException e) {
			LOG.error(e);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : getDetailsForRelease", e);
		}
	}
	
	@Override
	public ApplicationReleaseTO fetchReleaseDetails(ApplicationReleaseTO applicationReleaseTO) throws CMMException {
	
		try {
			ApplicationReleaseTO appRelease = new ApplicationReleaseTO();
			String hql = String.format("Select a from EnvironmentApplicationTO a where a.environmentTO.id =%d and a.applicationTO.id=%d", applicationReleaseTO.getEnvironmentId(), applicationReleaseTO.getApplicationId());
			List<EnvironmentApplicationTO> envAppTOList = (List<EnvironmentApplicationTO>) getHibernateTemplate().find(hql);
			if (!envAppTOList.isEmpty()) {
				EnvironmentApplicationTO envAppTO = envAppTOList.get(0);
				if (envAppTO.getApplicationReleaseTO() != null) {
					appRelease = (ApplicationReleaseTO) getHibernateTemplate().find("from ApplicationReleaseTO where id =?", envAppTO.getApplicationReleaseTO().getId()).get(0);
					if ((envAppTO.getTestingPhaseTO() != null) && (envAppTO.getTestingPhaseTO().getId() != null)) {
						appRelease.setCurrentTestingPhase(envAppTO.getTestingPhaseTO().getId());
					}
					return appRelease;
				}
			}
			if (applicationReleaseTO.getId() != null) {
				appRelease = (ApplicationReleaseTO) getHibernateTemplate().find("from ApplicationReleaseTO where id =?", applicationReleaseTO.getId()).get(0);
			}
			return appRelease;
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : fetchReleaseDetails(ApplicationReleaseTO)", dae);
		}
	}
	
	@Override
	public ApplicationReleaseTO fetchCurrentReleaseName(ApplicationReleaseTO applicationReleaseTO) throws CMMException {
	
		List<EnvironmentApplicationTO> envAppList = (List<EnvironmentApplicationTO>) getHibernateTemplate().find("from EnvironmentApplicationTO where applicationTO.id=? and environmentTO.id =?", applicationReleaseTO.getApplicationId(), applicationReleaseTO.getEnvironmentId());
		ApplicationReleaseTO apprel = new ApplicationReleaseTO();
		if (envAppList.size() > 0L) {
			apprel = envAppList.get(0).getApplicationReleaseTO();
		}
		return apprel;
	}
	
	@Override
	public ServiceRequestTO editDeployment(ApplicationReleaseTO applicationReleaseTO) throws CMMException {
	
		ServiceRequestTO requestTO1 = new ServiceRequestTO();
		if (applicationReleaseTO.getId() != null) {
			getReleaseDetails(applicationReleaseTO);
		}
		try {
			requestTO1.setApplicationId(applicationReleaseTO.getApplicationId());
			requestTO1.setStatusId(142L);
			requestTO1.setServiceId(applicationReleaseTO.getServiceId());
			requestTO1.setActionFlag("Y");
			requestTO1.setEnvironmentId(applicationReleaseTO.getEnvironmentId());
			requestTO1.setCreatedById(applicationReleaseTO.getCreatedById());
			requestTO1.setCreatedByDate(DateUtils.getStartTime(new Date()));
			requestTO1.setModifiedbyId(applicationReleaseTO.getModifiedbyId());
			requestTO1.setModifiedbyDate(DateUtils.getStartTime(new Date()));
			requestTO1.setApplicationReleaseId(applicationReleaseTO.getId());
			requestTO1.setSelectedTestingPhase(applicationReleaseTO.getSelectedTestingPhase());
			requestTO1.setRemark(applicationReleaseTO.getRemark());
			requestTO1.setCronExp(applicationReleaseTO.getCronExp());
			if (StringUtils.hasText(applicationReleaseTO.getCronExp())) {
				requestTO1.setIsScheduled("Y");
			} else {
				requestTO1.setIsScheduled("N");
			}
			getHibernateTemplate().save(requestTO1);
			int success = -1;
			EnvironmentTO envTO = new EnvironmentTO();
			envTO.setId(applicationReleaseTO.getEnvironmentId());
			envTO.setCreatedById(applicationReleaseTO.getCreatedById());
			requestTO1.setClientId(applicationReleaseTO.getClientId());
			if (applicationReleaseTO.getWorkFlowId() != null) {
				requestTO1.setWorkFlowId(applicationReleaseTO.getWorkFlowId());
			}
			if (requestTO1.getClientId() != 0) {
				success = serviceRequestDAO.generateWorkflow(envTO, requestTO1);
				requestTO1.setSuccess(success);
			}
			requestTO1.setSuccess(success);
		} catch (ConstraintViolationException ce) {
			LOG.error(ce);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : editDeployment", ce);
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : editDeployment", dae);
		}
		return requestTO1;
	}
	
	@Override
	public ServiceRequestTO submitTestingRequestSmokeTesting(ApplicationReleaseTO applicationReleaseTO) throws CMMException {
	
		ServiceRequestTO requestTO1 = new ServiceRequestTO();
		Session session = null;
		try {
			session = getSession();
			Long var = applicationReleaseTO.getId();
			ApplicationReleaseTO applicationReleaseTOnew = getReleaseDetails(applicationReleaseTO);
			ApplicationReleaseTO appRelTO = new ApplicationReleaseTO();
			appRelTO.setApplicationId(applicationReleaseTOnew.getSelectedApplication());
			appRelTO.setApplicationProfileId(applicationReleaseTOnew.getSelectedProfile());
			appRelTO.setStatus(applicationReleaseTOnew.getSelectedStatus());
			appRelTO.setSourcePath(applicationReleaseTOnew.getSourcePath());
			appRelTO.setName(applicationReleaseTOnew.getName());
			appRelTO.setDescription(applicationReleaseTOnew.getDescription());
			appRelTO.setType("S");
			appRelTO.setParentReleaseId(applicationReleaseTO.getParentReleaseId());
			applicationReleaseTOnew.getApplicationReleaseDbSet().clear();
			if (applicationReleaseTO.getCronExp() != null) {
				requestTO1.setCronExp(applicationReleaseTO.getCronExp());
				requestTO1.setIsScheduled("Y");
			}
			requestTO1.setApplicationId(applicationReleaseTO.getApplicationId());
			requestTO1.setStatusId(applicationReleaseTO.getStatusId());
			requestTO1.setServiceId(applicationReleaseTO.getServiceId());
			requestTO1.setActionFlag("Y");
			requestTO1.setEnvironmentId(applicationReleaseTO.getEnvironmentId());
			requestTO1.setCreatedById(applicationReleaseTO.getCreatedById());
			requestTO1.setCreatedByDate(new Date());
			requestTO1.setModifiedbyId(applicationReleaseTO.getModifiedbyId());
			requestTO1.setModifiedbyDate(new Date());
			requestTO1.setApplicationReleaseId(var);
			requestTO1.setRemark(applicationReleaseTO.getRemark());
			requestTO1.setSelectedTestingPhase(applicationReleaseTO.getSelectedTestingPhase());
			if (applicationReleaseTO.getProvMachineId() != -1) {
				requestTO1.setProvisionedMachineId(applicationReleaseTO.getProvMachineId());
				requestTO1.setToolConfigLocation(applicationReleaseTO.getToolConfigLoc());
				requestTO1.setSelPort(applicationReleaseTO.getSelPort());
				requestTO1.setResultLocation(applicationReleaseTO.getResultLocation());
				requestTO1.setScriptCopyLocation(applicationReleaseTO.getScriptCopyLocation());
			}
			getHibernateTemplate().save(requestTO1);
			applicationReleaseTOnew.getApplicationReleaseTestSet().clear();
			for (ApplicationReleaseTestTO temp : applicationReleaseTO.getApplicationReleaseTest()) {
				if (temp.isAccess()) {
					ApplicationReleaseTestTO testTO = new ApplicationReleaseTestTO();
					testTO.setServerGroup(temp.getServerGroup());
					testTO.setTestScriptPath(temp.getTestScriptPath());
					testTO.setTestTool(temp.getTestTool());
					testTO.setApplicationReleaseId(var);
					testTO.setRequestId(requestTO1.getId());
				} else {
					ApplicationReleaseTestTO testTO = new ApplicationReleaseTestTO();
					testTO.setTestScriptPath(temp.getTestScriptPath());
					testTO.setTestTool(temp.getTestTool());
					testTO.setApplicationReleaseId(appRelTO.getId());
				}
			}
			int success = -1;
			EnvironmentTO envTO = new EnvironmentTO();
			envTO.setId(applicationReleaseTO.getEnvironmentId());
			envTO.setCreatedById(applicationReleaseTO.getCreatedById());
			requestTO1.setClientId(applicationReleaseTO.getClientId());
			requestTO1.setWorkFlowId(applicationReleaseTO.getWorkFlowId());
			if (requestTO1.getClientId() != 0) {
				success = serviceRequestDAO.generateWorkflow(envTO, requestTO1);
				requestTO1.setSuccess(success);
			}
			if (success == -1) {
				Long reqStatus = CMMConstants.Framework.Entity.SERVICE_REQUEST_UNDER_IMPLEMENTATION;
				session.createQuery("update ServiceRequestTO r set r.statusId=? where r.id = ? ").setParameter(0, reqStatus).setParameter(1, requestTO1.getId()).executeUpdate();
				requestTO1.setSuccess(success);
				return requestTO1;
			}
			requestTO1.setSuccess(success);
		} catch (ConstraintViolationException ce) {
			LOG.error(ce);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : submitTestingRequestSmokeTesting", ce);
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : submitTestingRequestSmokeTesting", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return requestTO1;
	}
	
	@Override
	public ServiceRequestTO submitTestingRequest(ApplicationReleaseTO applicationReleaseTO) throws CMMException {
	
		Session session = null;
		ServiceRequestTO requestTO1 = new ServiceRequestTO();
		try {
			session = getSession();
			ApplicationReleaseTO applicationReleaseTOnew = getReleaseDetails(applicationReleaseTO);
			ApplicationReleaseTO appRelTO = new ApplicationReleaseTO();
			appRelTO.setApplicationId(applicationReleaseTOnew.getSelectedApplication());
			appRelTO.setApplicationProfileId(applicationReleaseTOnew.getSelectedProfile());
			appRelTO.setStatus(applicationReleaseTOnew.getSelectedStatus());
			appRelTO.setSourcePath(applicationReleaseTOnew.getSourcePath());
			appRelTO.setName(applicationReleaseTOnew.getName());
			appRelTO.setDescription(applicationReleaseTOnew.getDescription());
			appRelTO.setType("S");
			appRelTO.setParentReleaseId(applicationReleaseTO.getParentReleaseId());
			applicationReleaseTOnew.getApplicationReleaseDbSet().clear();
			if (!applicationReleaseTO.getApplicationReleaseDb().isEmpty()) {
				for (ApplicationReleaseDbTO temp : applicationReleaseTO.getApplicationReleaseDb()) {
					if (temp != null) {
						ApplicationReleaseDbTO applicationReleaseDb = new ApplicationReleaseDbTO();
						ApplicationProfileDetailsTO appProfDetails = new ApplicationProfileDetailsTO();
						appProfDetails = fetchAppProDetails(applicationReleaseTO.getSelectedProfile(), temp.getSoftwareConfigId());
						applicationReleaseDb.setServerId(appProfDetails.getHardwareId());
						applicationReleaseDb.setServerGroupNumber(appProfDetails.getServerGroup());
						applicationReleaseDb.setAppProDetailsId(appProfDetails.getId());
						applicationReleaseDb.setSoftwareConfigId(temp.getSoftwareConfigId());
						applicationReleaseDb.setDatabaseScriptsPath(temp.getDatabaseScriptsPath());
						applicationReleaseDb.setDatabaseScripts(temp.getDatabaseScripts());
						applicationReleaseDb.setSchemaName(temp.getSchemaName());
						applicationReleaseDb.setRollbackScriptPath(temp.getRollbackScriptPath());
						applicationReleaseDb.setRollbackOrder(temp.getRollbackOrder());
						applicationReleaseDb.setApplicationRelease(appRelTO);
						appRelTO.getApplicationReleaseDbSet().add(applicationReleaseDb);
					}
				}
				getHibernateTemplate().save(appRelTO);
			}
			if (!applicationReleaseTO.getAppRelSourcecode().isEmpty()) {
				Long softidDB = applicationReleaseTO.getAppRelSourcecode().get(0).getSoftwareConfigId();
				applicationReleaseTOnew.getAppRelSourcecodeSet().clear();
				for (ApplicationReleaseSourcecodeTO temp : applicationReleaseTO.getAppRelSourcecode()) {
					if (temp != null) {
						ApplicationReleaseSourcecodeTO sc = new ApplicationReleaseSourcecodeTO();
						ApplicationProfileDetailsTO a = new ApplicationProfileDetailsTO();
						a = fetchAppProDetails(applicationReleaseTO.getSelectedProfile(), softidDB);
						sc.setServerId(a.getHardwareId());
						sc.setServerGroupNumber(a.getServerGroup());
						sc.setAppProDetailsId(a.getId());
						sc.setSoftwareConfigId(temp.getSoftwareConfigId());
						sc.setApplicationReleaseSc(applicationReleaseTOnew);
						sc.setSourceCodePath(temp.getSourceCodePath());
						sc.setEarPath(temp.getEarPath());
						sc.setApplicationReleaseId(appRelTO.getId());
						getHibernateTemplate().save(sc);
					}
				}
			}
			if (!applicationReleaseTO.getApplicationReleaseBuild().isEmpty()) {
				applicationReleaseTOnew.getApplicationReleaseBuildSet().clear();
				for (ApplicationReleaseBuildTO temp : applicationReleaseTO.getApplicationReleaseBuild()) {
					ApplicationReleaseBuildTO buildTO = new ApplicationReleaseBuildTO();
					buildTO.setApplicationReleaseId(appRelTO.getId());
					buildTO.setJobName(temp.getJobName());
					buildTO.setBuildToolId(temp.getBuildToolId());
					getHibernateTemplate().save(buildTO);
				}
			}
			requestTO1.setApplicationId(applicationReleaseTO.getApplicationId());
			requestTO1.setStatusId(142L);
			requestTO1.setServiceId(applicationReleaseTO.getServiceId());
			requestTO1.setActionFlag("Y");
			requestTO1.setEnvironmentId(applicationReleaseTO.getEnvironmentId());
			requestTO1.setCreatedById(applicationReleaseTO.getCreatedById());
			requestTO1.setCreatedByDate(DateUtils.getStartTime(new Date()));
			requestTO1.setModifiedbyId(applicationReleaseTO.getModifiedbyId());
			requestTO1.setModifiedbyDate(DateUtils.getStartTime(new Date()));
			requestTO1.setApplicationReleaseId(appRelTO.getId());
			requestTO1.setRemark(applicationReleaseTO.getRemark());
			getHibernateTemplate().save(requestTO1);
			ApplicationReleaseTO relTO = new ApplicationReleaseTO();
			relTO = (ApplicationReleaseTO) getHibernateTemplate().find("from ApplicationReleaseTO where id=?", appRelTO.getId()).get(0);
			relTO.setRequestId(requestTO1.getId());
			getHibernateTemplate().update(relTO);
			applicationReleaseTOnew.getApplicationReleaseTestSet().clear();
			for (ApplicationReleaseTestTO temp : applicationReleaseTO.getApplicationReleaseTest()) {
				if (temp.isAccess()) {
					ApplicationReleaseTestTO testTO = new ApplicationReleaseTestTO();
					testTO.setTestScriptPath(temp.getTestScriptPath());
					testTO.setTestTool(temp.getTestTool());
					testTO.setApplicationReleaseId(appRelTO.getId());
					testTO.setRequestId(requestTO1.getId());
					getHibernateTemplate().save(testTO);
				} else {
					ApplicationReleaseTestTO testTO = new ApplicationReleaseTestTO();
					testTO.setTestScriptPath(temp.getTestScriptPath());
					testTO.setTestTool(temp.getTestTool());
					testTO.setApplicationReleaseId(appRelTO.getId());
					getHibernateTemplate().save(testTO);
				}
			}
			int success = -1;
			EnvironmentTO envTO = new EnvironmentTO();
			envTO.setId(applicationReleaseTO.getEnvironmentId());
			envTO.setCreatedById(applicationReleaseTO.getCreatedById());
			requestTO1.setClientId(applicationReleaseTO.getClientId());
			requestTO1.setWorkFlowId(applicationReleaseTO.getWorkFlowId());
			if (requestTO1.getClientId() != 0) {
				success = serviceRequestDAO.generateWorkflow(envTO, requestTO1);
				requestTO1.setSuccess(success);
			}
			if (success == -1) {
				Long envStatus = CMMConstants.Framework.Entity.ENVIRONMENT_STATUS_UNDERIMPLEMENTATION;
				Long reqStatus = CMMConstants.Framework.Entity.SERVICE_REQUEST_UNDER_IMPLEMENTATION;
				session.createQuery("update EnvironmentTO e set e.status=? where e.id = ? ").setParameter(0, envStatus).setParameter(1, envTO.getId()).executeUpdate();
				session.createQuery("update ServiceRequestTO r set r.statusId=? where r.id = ? ").setParameter(0, reqStatus).setParameter(1, requestTO1.getId()).executeUpdate();
				requestTO1.setSuccess(success);
				return requestTO1;
			}
			requestTO1.setSuccess(success);
		} catch (ConstraintViolationException ce) {
			LOG.error(ce);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : submitTestingRequest", ce);
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : submitTestingRequest", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return requestTO1;
	}
	
	@Override
	public List<ApplicationReleaseTO> getAllReleaseIds(long startReleaseId, long currentReleaseId, long applicationId) throws CMMException {
	
		Session session = getSession();
		try {
			List<ApplicationReleaseTO> releaseIdList = session.createCriteria(ApplicationReleaseTO.class).add(Restrictions.between("id", startReleaseId, currentReleaseId)).add(Restrictions.eq("applicationId", applicationId)).add(Restrictions.eq("statusTO.id", 121L)).addOrder(Order.asc("id")).list();
			if ((releaseIdList == null) || releaseIdList.isEmpty()) {
				throw new CMMException("No records found for release between " + startReleaseId + " and " + currentReleaseId);
			}
			return releaseIdList;
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Error in fetching requestId for release between " + currentReleaseId + " and " + currentReleaseId, dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<ApplicationReleaseTO> getReleaseIdInDecreasingOrder(long startReleaseId, long currentReleaseId, long applicationId) throws CMMException {
	
		Session session = getSession();
		try {
			List<ApplicationReleaseTO> releaseIdList = session.createCriteria(ApplicationReleaseTO.class).add(Restrictions.between("id", startReleaseId + 1, currentReleaseId)).add(Restrictions.eq("applicationId", applicationId)).add(Restrictions.eq("statusTO.id", 121L)).addOrder(Order.desc("id")).list();
			if ((releaseIdList == null) || releaseIdList.isEmpty()) {
				throw new CMMException("No records found for release between " + startReleaseId + " and " + currentReleaseId);
			}
			return releaseIdList;
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Error in fetching requestId for release between " + currentReleaseId + " and " + currentReleaseId, dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<ApplicationReleaseTO> fetchAllReleasesForApplication(long currentReleaseId, long applicationId) throws CMMException {
	
		Session session = getSession();
		try {
			List<ApplicationReleaseTO> releaseIdList = session.createCriteria(ApplicationReleaseTO.class).add(Restrictions.eq("applicationId", applicationId)).add(Restrictions.le("id", currentReleaseId)).add(Restrictions.eq("statusTO.id", 121L)).addOrder(Order.asc("id")).list();
			if ((releaseIdList == null) || releaseIdList.isEmpty()) {
				throw new CMMException("No records found for releases between " + currentReleaseId + " and " + applicationId);
			}
			return releaseIdList;
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Error in fetching releases for " + currentReleaseId + " and applicationId " + applicationId, dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<BuildToolTO> fetchBuildTools() throws CMMException {
	
		try {
			return (List<BuildToolTO>) getHibernateTemplate().find("from BuildToolTO");
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Error in fetching BuildToolTO ", dae);
		}
	}
	
	@Override
	public Long getReleaseIdFromRequestId(long requestId) throws CMMException {
	
		Session session = getSession();
		try {
			Long releaseId = (Long) session.createCriteria(ApplicationReleaseTO.class).add(Restrictions.eq("RequestId", requestId)).setProjection(Projections.property("id")).uniqueResult();
			if (releaseId == null) {
				throw new CMMException("No releaseId found for requestId" + requestId);
			}
			return releaseId;
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Error in fetching releaseId for " + requestId, dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<TestingToolTO> fetchTestingTool() throws CMMException {
	
		try {
			return (List<TestingToolTO>) getHibernateTemplate().find("from TestingToolTO");
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Error in fetching TestingToolTO ", dae);
		}
	}
	
	@Override
	public List<ApplicationTO> getApplicationListForProfile(Long selectedProfile, Long userId) throws CMMException {
	
		List<ApplicationTO> applicationList = new ArrayList<ApplicationTO>(0);
		List<ApplicationTO> appList = new ArrayList<ApplicationTO>(0);
		try {
			List<UserGroupDetailsTO> userGroupList = (List<UserGroupDetailsTO>) getHibernateTemplate().find("from UserGroupDetailsTO where users.id = ?", userId);
			for (UserGroupDetailsTO userGroup : userGroupList) {
				if (userGroup.getUserGroups() != null) {
					appList = (List<ApplicationTO>) getHibernateTemplate().find("from ApplicationTO where selectedUserGroup = ?", userGroup.getUserGroups().getId());
				}
			}
			List<ApplicationProfileMappingTO> applicationMapList = (List<ApplicationProfileMappingTO>) getHibernateTemplate().find("from ApplicationProfileMappingTO where profileId = ?", selectedProfile);
			for (ApplicationProfileMappingTO application : applicationMapList) {
				if (userId > 1L) {
					for (ApplicationTO app : appList) {
						if (app.getId().longValue() == application.getApplicationTO().getId().longValue()) {
							applicationList.add(application.getApplicationTO());
							break;
						}
					}
				} else {
					applicationList.add(application.getApplicationTO());
				}
			}
			return applicationList;
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Error in fetching TestingToolTO ", dae);
		}
	}
	
	@Override
	public PlatformTemplateTO getPlatformTempleteDetails(Long platformTempleteId) throws CMMException {
	
		try {
			String hql = String.format("Select a from PlatformTemplateTO a where a.id=%d", platformTempleteId);
			List<PlatformTemplateTO> platformTemplateTOList = (List<PlatformTemplateTO>) getHibernateTemplate().find(hql);
			PlatformTemplateTO platformTemplateTO = new PlatformTemplateTO();
			if (!platformTemplateTOList.isEmpty()) {
				platformTemplateTO = platformTemplateTOList.get(0);
			}
			return platformTemplateTO;
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered.ApplicationProfilesDAOImpl: getPlatformDetails", dae);
		}
	}
	
	@Override
	public List<RepositoryTO> fetchRepoDetails(Long applicationId) throws CMMException {
	
		List<RepositoryTO> repoList = new ArrayList<RepositoryTO>(0);
		try {
			if ((applicationId != null) && (applicationId > 0)) {
				List<ApplicationTO> applicationList = (List<ApplicationTO>) getHibernateTemplate().find("select clientId from ApplicationTO where id=?", applicationId);
				if (!applicationList.isEmpty()) {
					repoList = (List<RepositoryTO>) getHibernateTemplate().find("select distinct repositoryTO from RepositoryDetailsTO r where r.clientTO.id=?", applicationList.get(0));
				}
			}
			return repoList;
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.ApplicationProfilesDAOImpl: fetchRepoDetails", dae);
		}
	}
	
	@Override
	public ApplicationReleaseTO fetchSelectedExistingReleaseDetails(ApplicationReleaseTO applicationReleaseTO) throws CMMException {
	
		try {
			ApplicationReleaseTO appRelease = new ApplicationReleaseTO();
			String hql = String.format("select a from ApplicationReleaseTO a where a.id =%d", applicationReleaseTO.getSelectedExistingRelease());
			List<ApplicationReleaseTO> appReleaseList = (List<ApplicationReleaseTO>) getHibernateTemplate().find(hql);
			if (appReleaseList.size() > 0L) {
				appRelease = appReleaseList.get(0);
			}
			return appRelease;
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : fetchReleaseDetails(ApplicationReleaseTO)", dae);
		}
	}
	
	@Override
	public ApplicationReleaseTO checkReleaseIfExists(Long environmentId, Long selectedApplication) throws CMMException {
	
		ApplicationReleaseTO appRelease = new ApplicationReleaseTO();
		List<EnvironmentApplicationTO> envAppTOList = (List<EnvironmentApplicationTO>) getHibernateTemplate().find("from EnvironmentApplicationTO where environmentTO.id =? and applicationTO.id=?", environmentId, selectedApplication);
		if ((envAppTOList.size() > 0L) && (envAppTOList.get(0).getApplicationReleaseTO() == null)) {
			appRelease.setReleaseExistFlag(true);
		}
		return appRelease;
	}
	
	@Override
	public boolean checkVersionName(String versionName) throws CMMException {
	
		List<ApplicationReleaseTO> applicationRelease = null;
		try {
			applicationRelease = (List<ApplicationReleaseTO>) getHibernateTemplate().find("from ApplicationReleaseTO where name=?", versionName);
			return !applicationRelease.isEmpty();
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : checkVersionName", dae);
		}
	}
	
	@Override
	public List<ApplicationReleaseTO> fetchAllReleasesForApplication(Long applicationId) throws CMMException {
	
		try {
			return (List<ApplicationReleaseTO>) getHibernateTemplate().find("from ApplicationReleaseTO a where a.applicationId=? and a.statusTO.id <>?", applicationId, CMMConstants.Framework.Entity.APPLICATION_RELEASE_INACTIVE);
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getBusinessUnitNames", dae);
		}
	}
	
	@Override
	public List<String> getrepositDetails(Long id) throws CMMException {
	
		LinkedList<String> arrayList = new LinkedList<String>();
		try {
			List<RepositoryMasterTO> repoMasterTO = (List<RepositoryMasterTO>) getHibernateTemplate().find("from RepositoryMasterTO where applicationRelease.id =?", id);
			if (!repoMasterTO.isEmpty() && (repoMasterTO.get(0).getType() == 1L)) {
				List<Object[]> objlist = (List<Object[]>) getHibernateTemplate().find("from RepositoryMasterTO a , ApplicationReleaseSharedDetailsTO b , ApplicationReleaseSharedMappingTO c  where  a.id= c.repositoryMaster.id and b.id=c.sharedResourceId and a.applicationRelease.id =? ", id);
				RepositoryMasterTO r = new RepositoryMasterTO();
				ApplicationReleaseSharedDetailsTO s = new ApplicationReleaseSharedDetailsTO();
				for (Object[] obj : objlist) {
					r = (RepositoryMasterTO) obj[0];
					s = (ApplicationReleaseSharedDetailsTO) obj[1];
					arrayList.add("1");
					arrayList.add(r.getUsername());
					arrayList.add(r.getPassword());
					arrayList.add(s.getSharedIp());
				}
			} else if (!repoMasterTO.isEmpty() && (repoMasterTO.get(0).getType() == 2L)) {
				List<Object[]> objlist = (List<Object[]>) getHibernateTemplate().find("from RepositoryMasterTO a , ApplicationReleaseSharedMappingTO c  where  a.id= c.repositoryMaster.id  and a.applicationRelease.id =? ", id);
				RepositoryMasterTO r = new RepositoryMasterTO();
				for (Object[] obj : objlist) {
					r = (RepositoryMasterTO) obj[0];
					arrayList.add("2");
					arrayList.add(r.getUsername());
					arrayList.add(r.getPassword());
				}
			} else if (!repoMasterTO.isEmpty() && (repoMasterTO.get(0).getType() == 3L)) {
				arrayList.add("3");
			}
		} catch (Exception e) {
			LOG.error(e);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : getrepositDetails", e);
		}
		return arrayList;
	}
	
	@Override
	public Long fetchApplicationReleaseIdByName(String applicationRelease, Long applicationId) throws CMMException {
	
		List<ApplicationReleaseTO> applicationReleaseList = null;
		try {
			applicationReleaseList = (List<ApplicationReleaseTO>) getHibernateTemplate().find("from ApplicationReleaseTO where name=? and applicationTO.id=?", applicationRelease, applicationId);
			if (applicationReleaseList.isEmpty()) {
				throw new CMMException("No application release found for applicationRelease " + applicationRelease);
			} else if (applicationReleaseList.size() > 1) {
				throw new CMMException("No Unique application release found for applicationRelease" + applicationRelease);
			}
			return applicationReleaseList.get(0).getId();
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : fetchApplicationReleaseIdByName", dae);
		}
	}
	
	@Override
	public List<DataMaskingToolTO> getAllMaskingTools() throws CMMException {
	
		try {
			return (List<DataMaskingToolTO>) getHibernateTemplate().find("from DataMaskingToolTO");
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : getAllMaskingTools", dae);
		}
	}
	
	@Override
	public String getReleaseName(Long id) throws CMMException {
	
		try {
			ApplicationReleaseTO releaseTO = (ApplicationReleaseTO) getHibernateTemplate().find("from ApplicationReleaseTO where id=?", id).get(0);
			if (releaseTO == null) {
				throw new CMMException("No release name found for releaseId::" + id);
			}
			return releaseTO.getName();
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : getReleaseDetails", dae);
		}
	}
	
	@Override
	public ApplicationReleaseTO fetchRollbackReleaseDetails(ApplicationReleaseTO applicationReleaseTO) throws CMMException {
	
		try {
			ApplicationReleaseTO appRelease = new ApplicationReleaseTO();
			if (applicationReleaseTO.getId() != null) {
				appRelease = (ApplicationReleaseTO) getHibernateTemplate().find("from ApplicationReleaseTO where id =?", applicationReleaseTO.getId()).get(0);
			}
			return appRelease;
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : fetchRollbackReleaseDetails(ApplicationReleaseTO)", dae);
		}
	}
	
	@Override
	public void updateBuildLocation(BuildToolDefinitionTO buildToolDefinitionTO) throws CMMException {
	
		try {
			getHibernateTemplate().update(buildToolDefinitionTO);
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : updateBuildLocation(buildToolDefinitionTO)", dae);
		}
	}
	
	@Override
	public List<UserDefinedRelParamsTO> loadUserDefinedReleaseParams(Long releaseId) throws CMMException {
	
		try {
			return (List<UserDefinedRelParamsTO>) getHibernateTemplate().find("from UserDefinedRelParamsTO where releaseId=? and nolioProcessParameterId is NOT NULL", releaseId);
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : loadUserDefinedReleaseParams", dae);
		}
	}
	
	@Override
	public List<UserDefinedRelParamsTO> loadUserDefinedReleaseParamsForScript(Long releaseId) throws CMMException {
	
		try {
			return (List<UserDefinedRelParamsTO>) getHibernateTemplate().find("from UserDefinedRelParamsTO where releaseId=? and scriptParameterId is NOT NULL", releaseId);
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : loadUserDefinedReleaseParams", dae);
		}
	}
	
	public ServiceRequestDAO getServiceRequestDAO() {
	
		return serviceRequestDAO;
	}
	
	public void setServiceRequestDAO(ServiceRequestDAO serviceRequestDAO) {
	
		this.serviceRequestDAO = serviceRequestDAO;
	}
	
	public ApplicationProfileDAO getApplicationProfileDAO() {
	
		return applicationProfileDAO;
	}
	
	public void setApplicationProfileDAO(ApplicationProfileDAO applicationProfileDAO) {
	
		this.applicationProfileDAO = applicationProfileDAO;
	}
	
	@Override
	public String getRepoType(Long repoID) throws CMMException {
	
		Long repoTypeId = 0L;
		String repoType = null;
		try {
			String hql = String.format("from RepositoryTO where id=%d", repoID);
			List<RepositoryTO> repositoryTO = (List<RepositoryTO>) getHibernateTemplate().find(hql);
			if (!repositoryTO.isEmpty()) {
				repoTypeId = repositoryTO.get(0).getRepoType();
			}
			String hql1 = String.format("from RepoTO where id=%d", repoTypeId);
			List<RepoTO> repoTO = (List<RepoTO>) getHibernateTemplate().find(hql1);
			if (!repoTO.isEmpty()) {
				repoType = repoTO.get(0).getRepoName();
			}
			return repoType;
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : getRepoType", dae);
		}
	}
}