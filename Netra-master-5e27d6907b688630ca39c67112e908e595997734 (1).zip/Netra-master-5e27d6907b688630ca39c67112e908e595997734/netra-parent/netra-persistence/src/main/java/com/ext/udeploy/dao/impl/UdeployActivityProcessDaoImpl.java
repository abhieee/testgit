/**
 *
 */
package com.ext.udeploy.dao.impl;

import java.util.ArrayList;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.exception.ConstraintViolationException;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.udeploy.dao.UdeployActivityProcessDao;
import com.framework.exception.CMMException;
import com.framework.udeploy.to.UdeployActivityExecOrderTO;
import com.framework.udeploy.to.UdeployActivityProcessOrderTO;
import com.framework.udeploy.to.UdeployActivitySoftwareMappingTO;
import com.framework.udeploy.to.UdeployProcessSoftwareMapping;
import com.framework.udeploy.to.UdeployReleaseActivityTO;

/**
 * @author 460650
 */
public class UdeployActivityProcessDaoImpl extends HibernateDaoSupport implements UdeployActivityProcessDao {
	
	@Override
	public List<UdeployActivityProcessOrderTO> fetchUdeploySoftProcessMapByActivityID(long mapActivityId) throws CMMException {
	
		List<UdeployActivityProcessOrderTO> udeployActivityProcessList = new ArrayList<UdeployActivityProcessOrderTO>();
		try {
			udeployActivityProcessList = (List<UdeployActivityProcessOrderTO>) getHibernateTemplate().findByCriteria(DetachedCriteria.forClass(UdeployActivityProcessOrderTO.class).add(Restrictions.eq("udeployActivitySoftwareMappingTO.activitySoftwareMapId", mapActivityId)).addOrder(Order.asc("processOrder")));
			if (udeployActivityProcessList == null) {
				logger.debug("No record found for activityId::" + mapActivityId);
				throw new CMMException("No activity mapping found for given activityId::" + mapActivityId);
			}
		} catch (DataAccessException | HibernateException da) {
			logger.error("Error in UdeployActivityProcessDaoImpl: fetchUdeploySoftProcessMapByActivityID ", da);
			throw new CMMException("Problem encountered. UdeployActivityProcessDaoImpl : fetchUdeploySoftProcessMapByActivityID", da);
		}
		return udeployActivityProcessList;
	}
	
	@Override
	public void saveOrderedUdeployProcessForActivity(UdeployReleaseActivityTO udeployReleaseActivityTO) throws CMMException {
	
		try {
			List<Long> orderedProcessList = new ArrayList<Long>();
			List<Long> procList = udeployReleaseActivityTO.getUdeployProcessSoftwareMapOrderedList();
			for (Long l : procList) {
				UdeployProcessSoftwareMapping npSoftMap = getUdeployProcessSoftwareMapping(udeployReleaseActivityTO, l);
				orderedProcessList.add(npSoftMap.getSoftwareProcessMappingId());
			}
			UdeployActivitySoftwareMappingTO activitySoftwareMappingToP = getActivitySoftwareMapping(udeployReleaseActivityTO);
			List<UdeployActivityProcessOrderTO> udeployActivityProcessOrderTOprevious = (List<UdeployActivityProcessOrderTO>) getHibernateTemplate().find("from UdeployActivityProcessOrderTO where udeployActivitySoftwareMappingTO.activitySoftwareMapId =? ", activitySoftwareMappingToP.getActivitySoftwareMapId());
			if (udeployActivityProcessOrderTOprevious != null) {
				for (int i = 0; i < udeployActivityProcessOrderTOprevious.size(); i++) {
					UdeployActivityProcessOrderTO udeployActivityProcessOrderTO = udeployActivityProcessOrderTOprevious.get(i);
					getHibernateTemplate().delete(udeployActivityProcessOrderTO);
				}
			}
			for (int i = 0; i < orderedProcessList.size(); i++) {
				UdeployProcessSoftwareMapping udeployProcessSoftwareMapping = new UdeployProcessSoftwareMapping();
				udeployProcessSoftwareMapping.setSoftwareProcessMappingId(orderedProcessList.get(i));
				UdeployActivityProcessOrderTO udeployActivityProcessOrderTO = new UdeployActivityProcessOrderTO();
				udeployActivityProcessOrderTO.setUdeployProcessSoftwareMapping(udeployProcessSoftwareMapping);
				udeployActivityProcessOrderTO.setUdeployActivitySoftwareMappingTO(activitySoftwareMappingToP);
				udeployActivityProcessOrderTO.setProcessOrder(i);
				getHibernateTemplate().saveOrUpdate(udeployActivityProcessOrderTO);
				logger.debug("Udeploy processes saved successfully for ActivityId:: " + udeployReleaseActivityTO.getSelectedActivityId());
			}
		} catch (DataIntegrityViolationException | HibernateException div) {
			logger.error(div);
			throw new CMMException("Problem encountered. UdeployActivityProcessDaoImpl : saveOrderedUdeployProcessForActivity", div);
		}
	}
	
	@Override
	public void saveOrderedActivities(UdeployReleaseActivityTO udeployReleaseActivityTO) throws CMMException {
	
		Session session = null;
		try {
			UdeployActivitySoftwareMappingTO udeployActivitySoftwareMappingToP = getActivitySoftwareMapping(udeployReleaseActivityTO);
			List<UdeployActivityExecOrderTO> udeployActivityExecOrderTOprevious = new ArrayList<UdeployActivityExecOrderTO>();
			udeployActivityExecOrderTOprevious = (List<UdeployActivityExecOrderTO>) getHibernateTemplate().find("from UdeployActivityExecOrderTO where udeployActivitySoftwareMappingTOP.activitySoftwareMapId =? ", udeployActivitySoftwareMappingToP.getActivitySoftwareMapId());
			if (udeployActivityExecOrderTOprevious != null) {
				for (int i = 0; i < udeployActivityExecOrderTOprevious.size(); i++) {
					UdeployActivityExecOrderTO udeployActivityExecOrderTO = udeployActivityExecOrderTOprevious.get(i);
					getHibernateTemplate().delete(udeployActivityExecOrderTO);
				}
			}
			Transaction tx = null;
			session = getSession();
			tx = session.beginTransaction();
			String hql = "from  UdeployActivitySoftwareMappingTO where softwareconfigTO.id = ? and udeployReleaseActivityTO.activityId = ? )";
			Query q = session.createQuery(hql);
			q.setParameter(0, udeployReleaseActivityTO.getSoftwareId());
			q.setParameter(1, udeployReleaseActivityTO.getSelectedActivityId());
			List<Object[]> obj = q.list();
			tx.commit();
			UdeployActivityExecOrderTO udeployActivityExecOrderTO = new UdeployActivityExecOrderTO();
			for (int i = 0; i < obj.size(); i++) {
				Object activitySoftware = obj.get(i);
				udeployActivityExecOrderTO.setUdeployActivitySoftwareMappingTO((UdeployActivitySoftwareMappingTO) activitySoftware);
				udeployActivityExecOrderTO.setUdeployActivitySoftwareMappingTOP(udeployActivitySoftwareMappingToP);
				udeployActivityExecOrderTO.setExeOrder(i);
				getHibernateTemplate().save(udeployActivityExecOrderTO);
				logger.debug("Activities saved successfully for ActivityId:: " + udeployReleaseActivityTO.getSelectedActivityId());
			}
		} catch (DataIntegrityViolationException | HibernateException div) {
			logger.error(div);
			throw new CMMException("Problem encountered. UdeployActivityProcessDaoImpl : saveOrderedActivities", div);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	public UdeployActivitySoftwareMappingTO getActivitySoftwareMapping(UdeployReleaseActivityTO udeployReleaseActivityTO) throws CMMException {
	
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(UdeployActivitySoftwareMappingTO.class);
			criteria.createAlias("softwareconfigTO", "soft", CriteriaSpecification.LEFT_JOIN);
			criteria.createAlias("udeployReleaseActivityTO", "acti", CriteriaSpecification.LEFT_JOIN);
			criteria.add(Restrictions.eq("soft.id", udeployReleaseActivityTO.getSoftwareId()));
			criteria.add(Restrictions.eq("acti.activityId", udeployReleaseActivityTO.getSelectedActivityId()));
			return (UdeployActivitySoftwareMappingTO) getHibernateTemplate().findByCriteria(criteria).get(0);
		} catch (DataAccessException | HibernateException div) {
			logger.error("Error in UdeployActivityProcessDaoImpl: getActivitySoftwareMapping ", div);
			throw new CMMException("Problem encountered. UdeployActivityProcessDaoImpl : getActivitySoftwareMapping", div);
		}
	}
	
	@Override
	public List<UdeployActivityProcessOrderTO> fetchUdeployProcessOrder(UdeployReleaseActivityTO udeployReleaseActivityTO) throws CMMException {
	
		try {
			List<Long> udeployActivitySoftwareMappingTO = (List<Long>) getHibernateTemplate().find("select activitySoftwareMapId from UdeployActivitySoftwareMappingTO  where softwareconfigTO.id = ? ", Long.parseLong(udeployReleaseActivityTO.getSelectedVersion()));
			List<Long> udeployProcessSoftwareMapping = (List<Long>) getHibernateTemplate().find("select softwareProcessMappingId from UdeployProcessSoftwareMapping where softwareConfigTO.id = ? ", Long.parseLong(udeployReleaseActivityTO.getSelectedVersion()));
			if (!udeployActivitySoftwareMappingTO.isEmpty() && !udeployProcessSoftwareMapping.isEmpty()) {
				String paramNames[] = { "mapIds", "udeployIds" };
				Object[] values = { udeployActivitySoftwareMappingTO, udeployProcessSoftwareMapping };
				return (List<UdeployActivityProcessOrderTO>) getHibernateTemplate().findByNamedParam(" from UdeployActivityProcessOrderTO where udeployActivitySoftwareMappingTO.activitySoftwareMapId in(:mapIds) and udeployProcessSoftwareMapping.softwareProcessMappingId in (:udeployIds) Order by udeployActivitySoftwareMappingTO.activitySoftwareMapId,processOrder ", paramNames, values);
			} else {
				return null;
			}
		} catch (ConstraintViolationException ce) {
			logger.error(ce);
			throw new CMMException("Problem encountered. UdeployActivityProcessDaoImpl : fetchUdeployProcessOrder", ce);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. UdeployActivityProcessDaoImpl : fetchUdeployProcessOrder", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. UdeployActivityProcessDaoImpl : fetchUdeployProcessOrder", he);
		} catch (Exception e) {
			logger.error(e);
			throw new CMMException("Problem encountered. UdeployActivityProcessDaoImpl : fetchUdeployProcessOrder", e);
		}
	}
	
	@Override
	public List<UdeployActivityExecOrderTO> fetchOrderedActivities(UdeployReleaseActivityTO udeployReleaseActivityTO) throws CMMException {
	
		try {
			UdeployActivitySoftwareMappingTO activitySoftwareMappingTO = (UdeployActivitySoftwareMappingTO) getHibernateTemplate().find("from UdeployActivitySoftwareMappingTO where softwareconfigTO.id = ? and udeployReleaseActivityTO.activityId =?", udeployReleaseActivityTO.getSelectedVersion(), udeployReleaseActivityTO.getSelectedActivityId()).get(0);
			return (List<UdeployActivityExecOrderTO>) getHibernateTemplate().find("from  UdeployActivityExecOrderTO where udeployActivitySoftwareMappingTOP.activitySoftwareMapId = ?  order by exeOrder ", activitySoftwareMappingTO.getActivitySoftwareMapId());
		} catch (DataAccessException | HibernateException ce) {
			logger.error("Error in UdeployActivityProcessDaoImpl: fetchOrderedActivities ", ce);
			throw new CMMException("Problem encountered. UdeployActivityProcessDaoImpl : fetchOrderedActivities", ce);
		}
	}
	
	public UdeployProcessSoftwareMapping getUdeployProcessSoftwareMapping(UdeployReleaseActivityTO udeployReleaseActivityTO, Long processId) throws CMMException {
	
		try {
			UdeployProcessSoftwareMapping udeployProcessSoftwareMapping = new UdeployProcessSoftwareMapping();
			DetachedCriteria criteria = DetachedCriteria.forClass(UdeployProcessSoftwareMapping.class);
			criteria.createAlias("softwareConfigTO", "soft", CriteriaSpecification.LEFT_JOIN);
			criteria.createAlias("udeployProcess", "udep", CriteriaSpecification.LEFT_JOIN);
			criteria.add(Restrictions.eq("soft.id", udeployReleaseActivityTO.getSoftwareId()));
			criteria.add(Restrictions.eq("udep.processId", processId));
			udeployProcessSoftwareMapping = (UdeployProcessSoftwareMapping) getHibernateTemplate().findByCriteria(criteria).get(0);
			return udeployProcessSoftwareMapping;
		} catch (DataAccessException | HibernateException div) {
			logger.error("Error in UdeployActivityProcessDaoImpl: getUdeployProcessSoftwareMapping ", div);
			throw new CMMException("Problem encountered. UdeployActivityProcessDaoImpl : getUdeployProcessSoftwareMapping", div);
		}
	}
}
