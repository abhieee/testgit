package com.ext.dao.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.ApplicationReleaseBuildDAO;
import com.framework.exception.CMMException;
import com.framework.to.ApplicationReleaseBuildTO;

/**
 * @author 460650
 */
public class ApplicationReleaseBuildDAOImpl extends HibernateDaoSupport implements ApplicationReleaseBuildDAO {
	
	/*
	 * (non-Javadoc)
	 * @see com.ext.dao.ApplicationReleaseBuildDAO#fetchAppReleaseBuildByRequestId(long)
	 */
	private static final Logger LOG = Logger.getLogger(ApplicationReleaseBuildDAOImpl.class);
	
	@Override
	public List<ApplicationReleaseBuildTO> fetchAppReleaseBuildByRequestId(long requestId) throws CMMException {
	
		List<ApplicationReleaseBuildTO> applicationReleaseBuildList;
		try {
			applicationReleaseBuildList = (List<ApplicationReleaseBuildTO>) getHibernateTemplate().find("from ApplicationReleaseBuildTO where RequestId=?", requestId);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseBuildDAOImpl: fetchAppReleaseBuildByRequestId ", dae);
		} catch (HibernateException e) {
			logger.error(e);
			throw new CMMException("Problem encountered. ApplicationReleaseBuildDAOImpl: fetchAppReleaseBuildByRequestId ", e);
		}
		return applicationReleaseBuildList;
	}
	
	@Override
	public List<ApplicationReleaseBuildTO> fetchAppReleaseBuildByRequestAndPhaseId(long requestId, long phaseId) throws CMMException {
	
		List<ApplicationReleaseBuildTO> applicationReleaseBuildList;
		try {
			applicationReleaseBuildList = (List<ApplicationReleaseBuildTO>) getHibernateTemplate().find("from ApplicationReleaseBuildTO where RequestId=? and selectedTestingPhase=?", requestId, phaseId);
			if (applicationReleaseBuildList.isEmpty()) {
				applicationReleaseBuildList = (List<ApplicationReleaseBuildTO>) getHibernateTemplate().find("from ApplicationReleaseBuildTO where RequestId=? and selectedTestingPhase=?", requestId, 0L);
			}
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseBuildDAOImpl: fetchAppReleaseBuildByRequestAndPhaseId ", dae);
		}
		return applicationReleaseBuildList;
	}
	
	/*
	 * (non-Javadoc)
	 * @see com.ext.dao.ApplicationReleaseBuildDAO#fetchAppReleaseBuildByReleaseId(long)
	 */
	@Override
	public List<ApplicationReleaseBuildTO> fetchAppReleaseBuildByReleaseId(long applicationReleaseId) throws CMMException {
	
		List<ApplicationReleaseBuildTO> applicationReleaseBuildList;
		try {
			applicationReleaseBuildList = (List<ApplicationReleaseBuildTO>) getHibernateTemplate().find("from ApplicationReleaseBuildTO where applicationReleaseId=?", applicationReleaseId);
		} catch (DataAccessException | HibernateException dae) {
			logger.error("Error in fetching fetch application release build details by releaseId", dae);
			throw new CMMException("Problem encountered. ApplicationReleaseBuildDAOImpl: fetchAppReleaseBuildByReleaseId", dae);
		}
		return applicationReleaseBuildList;
	}
	
	@Override
	public List<ApplicationReleaseBuildTO> fetchAppReleaseBuildByReleaseAndPhaseId(long applicationReleaseId, long phaseId) throws CMMException {
	
		List<ApplicationReleaseBuildTO> applicationReleaseBuildList;
		try {
			applicationReleaseBuildList = (List<ApplicationReleaseBuildTO>) getHibernateTemplate().find("from ApplicationReleaseBuildTO where applicationReleaseId=? and selectedTestingPhase=?", applicationReleaseId, phaseId);
			if (applicationReleaseBuildList.isEmpty()) {
				applicationReleaseBuildList = (List<ApplicationReleaseBuildTO>) getHibernateTemplate().find("from ApplicationReleaseBuildTO where applicationReleaseId=? and selectedTestingPhase=?", applicationReleaseId, 0L);
			}
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseBuildDAOImpl: fetchAppReleaseBuildByReleaseAndPhaseId", dae);
		}
		return applicationReleaseBuildList;
	}
	
	@Override
	public Set<String> fetchApplicationBuildJobs(long applicationId, long ciToolId) throws CMMException {
	
		try {
			List<Long> applicationReleaseIdList = (List<Long>) getHibernateTemplate().find("select id from ApplicationReleaseTO where applicationTO.id=?", applicationId);
			if (applicationReleaseIdList.isEmpty()) {
				throw new CMMException("No application release details found for applicationId:: " + applicationId);
			}
			List<ApplicationReleaseBuildTO> applicationReleaseBuildList = (List<ApplicationReleaseBuildTO>) getHibernateTemplate().findByNamedParam("from  ApplicationReleaseBuildTO arb where applicationReleaseId in (:ids)", "ids", applicationReleaseIdList);
			if (applicationReleaseBuildList.isEmpty()) {
				throw new CMMException("No application release build details found for applicationId:: " + applicationId);
			}
			Set<String> buildNameSet = new HashSet<String>();
			for (ApplicationReleaseBuildTO applicationReleaseBuildTO : applicationReleaseBuildList) {
				if ((applicationReleaseBuildTO != null) && (applicationReleaseBuildTO.getBuildToolDefinitionTO() != null) && (applicationReleaseBuildTO.getBuildToolDefinitionTO().getBuildName() != null) && (applicationReleaseBuildTO.getBuildToolDefinitionTO().getBuildToolId() == ciToolId)) {
					buildNameSet.add(applicationReleaseBuildTO.getBuildToolDefinitionTO().getBuildName());
				}
			}
			return buildNameSet;
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseBuildDAOImpl: fetchApplicationBuildJobs", dae);
		}
	}
	
	@Override
	public Set<String> fetchApplicationBuildJobsForCIReport(List<Long> applicationId, long ciToolId) throws CMMException {
	
		try {
			List<Long> applicationReleaseIdList = new ArrayList<Long>();
			for (Long appId : applicationId) {
				applicationReleaseIdList.addAll((List<Long>) getHibernateTemplate().find("select id from ApplicationReleaseTO where applicationTO.id =?", appId));
			}
			if (applicationReleaseIdList.isEmpty()) {
				throw new CMMException("No application release details found for applicationId:: " + applicationId);
			}
			List<ApplicationReleaseBuildTO> applicationReleaseBuildList = (List<ApplicationReleaseBuildTO>) getHibernateTemplate().findByNamedParam("from  ApplicationReleaseBuildTO arb where applicationReleaseId in (:ids)", "ids", applicationReleaseIdList);
			if (applicationReleaseBuildList.isEmpty()) {
				throw new CMMException("No application release build details found for applicationId:: " + applicationId);
			}
			Set<String> buildNameSet = new HashSet<String>();
			for (ApplicationReleaseBuildTO applicationReleaseBuildTO : applicationReleaseBuildList) {
				if ((applicationReleaseBuildTO != null) && (applicationReleaseBuildTO.getBuildToolDefinitionTO() != null) && (applicationReleaseBuildTO.getBuildToolDefinitionTO().getBuildName() != null) && (applicationReleaseBuildTO.getBuildToolDefinitionTO().getBuildToolId() == ciToolId)) {
					buildNameSet.add(applicationReleaseBuildTO.getBuildToolDefinitionTO().getBuildName());
				}
			}
			return buildNameSet;
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseBuildDAOImpl: fetchApplicationBuildJobs", dae);
		}
	}
}
