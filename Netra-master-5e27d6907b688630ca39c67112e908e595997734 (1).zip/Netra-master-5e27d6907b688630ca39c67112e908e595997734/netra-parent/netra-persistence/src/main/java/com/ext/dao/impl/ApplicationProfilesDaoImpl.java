package com.ext.dao.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.ApplicationProfilesDao;
import com.ext.util.DAOConstants;
import com.framework.common.CMMConstants;
import com.framework.exception.CMMException;
import com.framework.nolio.to.CAActivityProcessOrderTO;
import com.framework.nolio.to.NolioProcessParametersTO;
import com.framework.nolio.to.NolioProcessSoftwareMapping;
import com.framework.to.ActivitySoftwareMappingTO;
import com.framework.to.ApplicationProfileConfigTO;
import com.framework.to.ApplicationProfileDetailsAWSTO;
import com.framework.to.ApplicationProfileDetailsTO;
import com.framework.to.ApplicationProfileDockerTO;
import com.framework.to.ApplicationProfileMappingTO;
import com.framework.to.ApplicationProfileSoftwareParamertsTO;
import com.framework.to.ApplicationProfileTO;
import com.framework.to.ApplicationProfilesServerSetTO;
import com.framework.to.ApplicationProfilesServerSoftwareSetTO;
import com.framework.to.ApplicationReleasePhaseTO;
import com.framework.to.ApplicationTO;
import com.framework.to.EnvironmentApplicationTO;
import com.framework.to.MachineTO;
import com.framework.to.MachineTemplateTO;
import com.framework.to.MachineTypeTO;
import com.framework.to.PlatformTemplateTO;
import com.framework.to.ProvisionedMachineTO;
import com.framework.to.ProvisionedPlatformTO;
import com.framework.to.TemplateVMWareTO;
import com.framework.to.TemplatesAwsTO;
import com.framework.to.UserGroupTO;

public class ApplicationProfilesDaoImpl extends HibernateDaoSupport implements ApplicationProfilesDao {
	
	private static final Logger LOG = Logger.getLogger(ApplicationProfilesDaoImpl.class);
	
	@Override
	public List<MachineTypeTO> getMachineTypeList() throws CMMException {
	
		try {
			return (List<MachineTypeTO>) getHibernateTemplate().find("from MachineTypeTO order by type");
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ApplicationProfilesDaoImpl : getMachineTypeList", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ApplicationProfilesDaoImpl : getMachineTypeList", he);
		}
	}
	
	public Map<String, MachineTypeTO> getMachineTypeMap() throws CMMException {
	
		try {
			Map<String, MachineTypeTO> machineTypeMap = new HashMap<String, MachineTypeTO>();
			List<MachineTypeTO> machineTypeList = getMachineTypeList();
			for (MachineTypeTO machineType : machineTypeList) {
				machineTypeMap.put(machineType.getTypeAbbr(), machineType);
			}
			return machineTypeMap;
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ApplicationProfilesDaoImpl : getMachineTypeMap", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ApplicationProfilesDaoImpl : getMachineTypeMap", he);
		}
	}
	
	@Override
	public List<TemplatesAwsTO> getAWSEC2Images(Long awsAccountId) throws CMMException {
	
		try {
			return (List<TemplatesAwsTO>) getHibernateTemplate().find("from TemplatesAwsTO where state='available' and awsAccountId=? order by template.name", awsAccountId);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ApplicationProfilesDaoImpl : getAWSEC2Images", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ApplicationProfilesDaoImpl : getAWSEC2Images", he);
		}
	}
	
	@Override
	public List<TemplateVMWareTO> getVMwareImages() throws CMMException {
	
		try {
			return (List<TemplateVMWareTO>) getHibernateTemplate().find("from TemplateVMWareTO order by template.name");
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ApplicationProfilesDaoImpl : getVMwareImages", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ApplicationProfilesDaoImpl : getVMwareImages", he);
		}
	}
	
	@Override
	public List<NolioProcessParametersTO> getSoftwareProperties(Long softwareConfigId) throws CMMException {
	
		List<NolioProcessParametersTO> nolioProcessParametersTOs = new ArrayList<NolioProcessParametersTO>();
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(ActivitySoftwareMappingTO.class, "activitysoftware");
			criteria.add(Restrictions.eq("activitysoftware.softwareconfigTO.id", softwareConfigId));
			criteria.add(Restrictions.eq("activitysoftware.caReleaseActivityTO.activityId", 1L));
			List<ActivitySoftwareMappingTO> activitySoftwareMappingTO = (List<ActivitySoftwareMappingTO>) getHibernateTemplate().findByCriteria(criteria);
			if ((activitySoftwareMappingTO != null) && !activitySoftwareMappingTO.isEmpty()) {
				DetachedCriteria criteria1 = DetachedCriteria.forClass(CAActivityProcessOrderTO.class, "activityProcessOrderTO");
				criteria1.add(Restrictions.eq("activityProcessOrderTO.activitySoftwareMappingTO.activitySoftwareMapId", activitySoftwareMappingTO.get(0).getActivitySoftwareMapId()));
				List<CAActivityProcessOrderTO> activityProcessOrderTO = (List<CAActivityProcessOrderTO>) getHibernateTemplate().findByCriteria(criteria1);
				if ((activityProcessOrderTO != null) && !activityProcessOrderTO.isEmpty()) {
					for (CAActivityProcessOrderTO temp : activityProcessOrderTO) {
						DetachedCriteria criteria2 = DetachedCriteria.forClass(NolioProcessSoftwareMapping.class, "nolioProcessSoftwareMapping");
						criteria2.add(Restrictions.eq("nolioProcessSoftwareMapping.softwareProcessMappingId", temp.getNolioProcessSoftwareMapping().getSoftwareProcessMappingId()));
						List<NolioProcessSoftwareMapping> nolioProcessSoftwareMapping = (List<NolioProcessSoftwareMapping>) getHibernateTemplate().findByCriteria(criteria2);
						for (NolioProcessParametersTO nolioProcessParametersTO : nolioProcessSoftwareMapping.get(0).getNolioProcess().getNolioProcessParameters()) {
							String mapped = nolioProcessParametersTO.getNetraParameterMapping();
							if ("N".equalsIgnoreCase(mapped)) {
								nolioProcessParametersTOs.add(nolioProcessParametersTO);
							}
						}
					}
				}
			}
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered.SoftwareDAOImpl:getSoftwareProperties", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.SoftwareDAOImpl:getSoftwareProperties", he);
		}
		return nolioProcessParametersTOs;
	}
	
	@Override
	public List<ApplicationTO> getSelectedApplications(Long[] selectedApp) throws CMMException {
	
		try {
			List<ApplicationTO> selectedAppList = new ArrayList<ApplicationTO>(0);
			for (Long element : selectedApp) {
				ApplicationTO appObj = (ApplicationTO) getHibernateTemplate().find("from ApplicationTO where id=?", element).get(0);
				selectedAppList.add(appObj);
			}
			return selectedAppList;
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ApplicationProfilesDaoImpl : getMachineTypeList", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ApplicationProfilesDaoImpl : getMachineTypeList", he);
		}
	}
	
	@Override
	public List<ApplicationTO> getAllApplicationsforProfile(Long clientId, List<UserGroupTO> userGroupIds) throws CMMException {
	
		List<ApplicationTO> applicationList = new ArrayList<ApplicationTO>();
		List<Long> userGpIds = new ArrayList<Long>(0);
		for (UserGroupTO user : userGroupIds) {
			userGpIds.add(user.getId());
		}
		Session session = null;
		Query query = null;
		try {
			session = getSession();
			if (clientId == 0) {
				query = session.createQuery("SELECT a.id,a.appName FROM ApplicationTO a WHERE a.status=:availableStatus ORDER BY a.appName");
				query.setLong("availableStatus", CMMConstants.Framework.Entity.APPLICATION_AVAILABLE);
			} else if (!userGroupIds.isEmpty()) {
				query = session.createQuery("SELECT a.id,a.appName , u.id FROM ApplicationTO a INNER JOIN a.userGroups u WHERE a.status=:availableStatus AND u.id IN (:userGroupIds) ORDER BY a.appName");
				query.setParameterList("userGroupIds", userGpIds);
				query.setLong("availableStatus", CMMConstants.Framework.Entity.APPLICATION_AVAILABLE);
			}
			if (query != null) {
				List<Object[]> queryResultList = query.list();
				for (Object[] result : queryResultList) {
					ApplicationTO application = new ApplicationTO();
					application.setId((Long) result[0]);
					application.setAppName(result[1].toString());
					applicationList.add(application);
				}
			}
			return applicationList;
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getAllApplications()", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getAllApplications()", he);
		} catch (Exception he) {
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getAllApplications()", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	/**
	 * The function sets the values of various application fields on the JSP page corresponding to that application.
	 *
	 * @param profileId
	 *                The Id for which the details are to be fetched.
	 * @return ApplicationProfileTO in which all the values are set.
	 */
	@Override
	public ApplicationProfileTO getApplicationProfile(Long applicationProfileId) throws CMMException {
	
		try {
			return (ApplicationProfileTO) getHibernateTemplate().find("from ApplicationProfileTO where id=?", applicationProfileId).get(0);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered.ApplicationProfilesDAOImpl: getProfileDetails", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.ApplicationProfilesDAOImpl: getProfileDetails.", he);
		}
	}
	
	@Override
	public ApplicationProfileTO getProfileDetails(Long profileId) throws CMMException {
	
		try {
			return (ApplicationProfileTO) getHibernateTemplate().find("from ApplicationProfileTO where id=?", profileId).get(0);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered.ApplicationProfilesDAOImpl: getProfileDetails", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.ApplicationProfilesDAOImpl: getProfileDetails.", he);
		}
	}
	
	/**
	 * Edit function provides the facility to edit the details of any application.This function converts the bean object into ApplicationTO.
	 *
	 * @param userId
	 *                The id of logged in user.
	 * @param applicationProfileTO
	 *                Details of application in form of TO.
	 * @return ApplicationProfileTO in which all the new values are set and to be displayed on the jsp.
	 */
	@Override
	public ApplicationProfileTO editApplicationProfile(ApplicationProfileTO applicationProfileTO, Long userId) throws CMMException {
	
		ApplicationProfileTO applicationProfile = getHibernateTemplate().get(ApplicationProfileTO.class, applicationProfileTO.getProfileId());
		Long profile_Id = applicationProfile.getId();
		List<ApplicationProfileDetailsTO> appPrfDetListForApplicationParameter = (List<ApplicationProfileDetailsTO>) getHibernateTemplate().find("from ApplicationProfileDetailsTO where profileId =? ", profile_Id);
		String newmachineType = applicationProfileTO.getMachineSet().get(0).getMachineType();
		String oldmachineType = CMMConstants.Framework.MachineTypes.MACHINE_TYPE_DOCKER;
		ApplicationProfileDockerTO applicationProfileDocker = new ApplicationProfileDockerTO();
		try {
			if (newmachineType.equalsIgnoreCase(oldmachineType)) {
				applicationProfileDocker = (ApplicationProfileDockerTO) getHibernateTemplate().find("from ApplicationProfileDockerTO where profileId=?", profile_Id).get(0);
			}
		} catch (Exception e) {
			oldmachineType = "noDock";
			LOG.error("Error in editApplicationProfile", e);
			throw new CMMException("ApplicationProfilesDaoImpl:editApplicationProfile", e);
		}
		ApplicationProfileTO applicationProfileTO1 = (ApplicationProfileTO) getHibernateTemplate().find("from ApplicationProfileTO where id=?", applicationProfileTO.getProfileId()).get(0);
		applicationProfileTO1.getProfileDetails().iterator().next().getSoftwareConfig();
		ArrayList<Long> arrExistingSoftware = new ArrayList<Long>();
		ArrayList<Long> arrExistingSoftware1 = new ArrayList<Long>();
		if (!newmachineType.contains(CMMConstants.Framework.MachineTypes.MACHINE_TYPE_DOCKER)) {
			for (ApplicationProfileDetailsTO details : applicationProfileTO.getProfileDetails()) {
				arrExistingSoftware.add(details.getId());
				arrExistingSoftware1.add(details.getSoftwareConfig().getId());
			}
		}
		Long serverRow = -1L;
		applicationProfile.setName(applicationProfileTO.getProfileName());
		applicationProfile.setStatus(applicationProfileTO.getSelectedStatus());
		if (applicationProfileTO.getMonitoringRequired() != null) {
			if ("true".equalsIgnoreCase(applicationProfileTO.getMonitoringRequired())) {
				applicationProfile.setMonitoringRequired("Y");
			} else {
				applicationProfile.setMonitoringRequired("N");
			}
		} else {
			applicationProfile.setMonitoringRequired("N");
		}
		applicationProfile.setModifiedbyId(userId);
		applicationProfile.setModifiedbyDate(new Date());
		applicationProfile.getProfileDetails().clear();
		List<Long> applicationProfileIds = new ArrayList<>(0);
		for (ApplicationProfileDetailsTO applicationProfileDetails : applicationProfile.getProfileDetails()) {
			applicationProfileIds.add(applicationProfileDetails.getId());
		}
		for (ApplicationProfilesServerSetTO server : applicationProfileTO.getMachineSet()) {
			serverRow++;
			if (server.getSoftwareConfigIds().isEmpty()) {
				ApplicationProfileDetailsTO applicationProfileDetails = new ApplicationProfileDetailsTO();
				applicationProfileDetails.setServerGroup(serverRow);
				applicationProfileDetails.setServerName(server.getFriendlyServerName());
				switch (server.getMachineType()) {
					case DAOConstants.MACHINE_TYPE_PHYSICAL:
						applicationProfileDetails.setExistingMachineId(server.getMachineTemplateId());
						applicationProfileDetails.setExistingPlatformId(server.getPlatformTemplateId());
						applicationProfileDetails.setExistingMachineFlag("Y");
						break;
					case DAOConstants.MACHINE_TYPE_VMWARE:
						applicationProfileDetails.setMachineTemplateId(server.getMachineTemplateId());
						applicationProfileDetails.setPlatformTemplateId(server.getPlatformTemplateId());
						applicationProfileDetails.setExistingMachineFlag("N");
						break;
					case DAOConstants.MACHINE_TYPE_EC2:
						applicationProfileDetails.setMachineTemplateId(server.getMachineTemplateId());
						applicationProfileDetails.setPlatformTemplateId(server.getTemplateId());
						applicationProfileDetails.setExistingMachineFlag("N");
						ApplicationProfileDetailsAWSTO awsDetails = new ApplicationProfileDetailsAWSTO();
						awsDetails.setServerGroup(serverRow);
						awsDetails.setKey(server.getKeyName());
						awsDetails.setAvalabilityZone(server.getPlacement());
						awsDetails.setApplicationProfile(applicationProfile);
						applicationProfile.getApplicationProfileDetailsAws().add(awsDetails);
						break;
					case DAOConstants.MACHINE_TYPE_VMWARE_BARE:
						applicationProfileDetails.setMachineTemplateId(server.getMachineTemplateId());
						applicationProfileDetails.setPlatformTemplateId(server.getPlatformTemplateId());
						applicationProfileDetails.setExistingMachineFlag("B");
						break;
					default:
						break;
				}
				applicationProfileDetails.setProfile(applicationProfile);
				applicationProfile.getProfileDetails().add(applicationProfileDetails);
			} else {
				boolean awsAdded = false;
				for (ApplicationProfilesServerSoftwareSetTO software : server.getSoftwareSet()) {
					ApplicationProfileDetailsTO applicationProfileDetails = new ApplicationProfileDetailsTO();
					for (int k = 0; k < arrExistingSoftware1.size(); k++) {
						if ((software.getSoftwareConfigId() != null) && software.getSoftwareConfigId().equals(arrExistingSoftware1.get(k))) {
							applicationProfileDetails.setId(arrExistingSoftware.get(k));
						}
					}
					applicationProfileDetails.setServerGroup(serverRow);
					applicationProfileDetails.setMappedSoftwareId(software.getSoftwareConfigId());
					applicationProfileDetails.setServerName(server.getFriendlyServerName());
					Set<ApplicationProfileSoftwareParamertsTO> parametersSet = new HashSet<ApplicationProfileSoftwareParamertsTO>();
					for (Map.Entry<Long, String> map : software.getParameters().entrySet()) {
						ApplicationProfileSoftwareParamertsTO param = new ApplicationProfileSoftwareParamertsTO();
						param.setPropertyId(map.getKey());
						param.setPropertyValue(map.getValue());
						param.setActivityId(1L);
						param.setApplicationProfileDetails(applicationProfileDetails);
						parametersSet.add(param);
					}
					if (software.getInstallRequired() != null) {
						if ("true".equalsIgnoreCase(software.getInstallRequired())) {
							applicationProfileDetails.setInstallRequired("Y");
						} else {
							applicationProfileDetails.setInstallRequired("N");
						}
					} else {
						applicationProfileDetails.setInstallRequired("N");
					}
					applicationProfileDetails.setApplicationProfileSoftwareParamertsTOs(parametersSet);
					switch (server.getMachineType()) {
						case DAOConstants.MACHINE_TYPE_PHYSICAL:
							applicationProfileDetails.setExistingMachineId(server.getMachineTemplateId());
							applicationProfileDetails.setExistingPlatformId(server.getPlatformTemplateId());
							applicationProfileDetails.setExistingMachineFlag("Y");
							break;
						case DAOConstants.MACHINE_TYPE_VMWARE:
							applicationProfileDetails.setMachineTemplateId(server.getMachineTemplateId());
							applicationProfileDetails.setPlatformTemplateId(server.getPlatformTemplateId());
							applicationProfileDetails.setExistingMachineFlag("N");
							break;
						case DAOConstants.MACHINE_TYPE_EC2:
							applicationProfileDetails.setMachineTemplateId(server.getMachineTemplateId());
							applicationProfileDetails.setPlatformTemplateId(server.getTemplateId());
							applicationProfileDetails.setExistingMachineFlag("N");
							if (!awsAdded) {
								ApplicationProfileDetailsAWSTO awsDetails = new ApplicationProfileDetailsAWSTO();
								awsDetails.setServerGroup(serverRow);
								awsDetails.setKey(server.getKeyName());
								awsDetails.setAvalabilityZone(server.getPlacement());
								awsDetails.setApplicationProfile(applicationProfile);
								applicationProfile.getApplicationProfileDetailsAws().add(awsDetails);
								awsAdded = true;
							}
							break;
						case DAOConstants.MACHINE_TYPE_VMWARE_BARE:
							applicationProfileDetails.setMachineTemplateId(server.getMachineTemplateId());
							applicationProfileDetails.setPlatformTemplateId(server.getPlatformTemplateId());
							applicationProfileDetails.setExistingMachineFlag("B");
							break;
						case DAOConstants.MACHINE_TYPE_DOCKER:
							applicationProfileDetails.setMappedSoftwareId(null);
							break;
						default:
							break;
					}
					applicationProfileDetails.setProfile(applicationProfile);
					applicationProfile.getProfileDetails().add(applicationProfileDetails);
				}
			}
		}
		applicationProfile.getApplicationProfileMapping().clear();
		getHibernateTemplate().update(applicationProfile);
		List<ApplicationProfileConfigTO> appPrfConfig = (List<ApplicationProfileConfigTO>) getHibernateTemplate().find("from ApplicationProfileConfigTO where appPrfId =? and applicationId is null", profile_Id);
		for (ApplicationProfileConfigTO appPrfConfigObj : appPrfConfig) {
			for (ApplicationProfileDetailsTO appPrfDet : appPrfDetListForApplicationParameter) {
				boolean appPrfDetPresentFlag = false;
				if (appPrfConfigObj.getAppPrfDetId().longValue() == appPrfDet.getId().longValue()) {
					appPrfDetPresentFlag = true;
				}
				if (appPrfDetPresentFlag) {
					Long serverNumber = appPrfDet.getServerGroup();
					Long prfId = appPrfDet.getProfileId();
					Long softConfigId = appPrfDet.getMappedSoftwareId();
					List<ApplicationProfileDetailsTO> appPrfDetList = (List<ApplicationProfileDetailsTO>) getHibernateTemplate().find("from ApplicationProfileDetailsTO where serverGroup =? and profileId=? and mappedSoftwareId=?", serverNumber, prfId, softConfigId);
					if (!appPrfDetList.isEmpty()) {
						appPrfConfigObj.setAppPrfDetId(appPrfDetList.get(0).getId());
						getHibernateTemplate().update(appPrfConfigObj);
					}
				}
			}
		}
		Long profileId = applicationProfile.getId();
		for (String applicationId : applicationProfileTO.getSelectedApplicationsList()) {
			ApplicationProfileMappingTO applicationProfileMapping = new ApplicationProfileMappingTO();
			applicationProfileMapping.setApplicationId(Long.parseLong(applicationId));
			applicationProfileMapping.setProfileId(profileId);
			getHibernateTemplate().save(applicationProfileMapping);
		}
		if (newmachineType.contains(CMMConstants.Framework.MachineTypes.MACHINE_TYPE_DOCKER)) {
			applicationProfileDocker.setRepository(applicationProfileTO.getMachineSet().get(0).getDockerImages().getRepository());
			applicationProfileDocker.setImageId(applicationProfileTO.getMachineSet().get(0).getDockerImages().getImageId());
			applicationProfileDocker.setProfileId(profileId);
			applicationProfileDocker.setServerIp(applicationProfileTO.getMachineSet().get(0).getDockerImages().getServerIp());
			applicationProfileDocker.setTags(applicationProfileTO.getMachineSet().get(0).getDockerImages().getTags());
			applicationProfileDocker.setVirtualSize(applicationProfileTO.getMachineSet().get(0).getDockerImages().getVirtualSize());
			if (oldmachineType.contains(CMMConstants.Framework.MachineTypes.MACHINE_TYPE_DOCKER)) {
				getHibernateTemplate().update(applicationProfileDocker);
			} else {
				getHibernateTemplate().save(applicationProfileDocker);
			}
		} else {
			getHibernateTemplate().delete(applicationProfileDocker);
		}
		return applicationProfile;
	}
	
	@Override
	public Long addApplicationProfile(String profileName, String[] selectedApplicationsList, List<ApplicationProfilesServerSetTO> machineSet, Long userId, String monitoringRequired) throws CMMException {
	
		Long serverRow = -1L;
		ApplicationProfileTO applicationProfile = new ApplicationProfileTO();
		applicationProfile.setName(profileName);
		if ("true".equalsIgnoreCase(monitoringRequired)) {
			applicationProfile.setMonitoringRequired("Y");
		} else {
			applicationProfile.setMonitoringRequired("N");
		}
		applicationProfile.setStatus(CMMConstants.Framework.Entity.APPLICATION_PROFILE_ACTIVE);
		applicationProfile.setCreatedById(userId);
		applicationProfile.setCreatedByDate(new Date());
		applicationProfile.setModifiedbyId(userId);
		applicationProfile.setModifiedbyDate(new Date());
		for (ApplicationProfilesServerSetTO server : machineSet) {
			serverRow++;
			if (server.getSoftwareConfigIds().isEmpty()) {
				ApplicationProfileDetailsTO applicationProfileDetails = new ApplicationProfileDetailsTO();
				applicationProfileDetails.setServerGroup(serverRow);
				applicationProfileDetails.setServerName(server.getFriendlyServerName());
				switch (server.getMachineType()) {
					case DAOConstants.MACHINE_TYPE_PHYSICAL:
						applicationProfileDetails.setExistingMachineId(server.getMachineTemplateId());
						applicationProfileDetails.setExistingPlatformId(server.getPlatformTemplateId());
						applicationProfileDetails.setExistingMachineFlag("Y");
						break;
					case DAOConstants.MACHINE_TYPE_VMWARE:
						applicationProfileDetails.setMachineTemplateId(server.getMachineTemplateId());
						applicationProfileDetails.setPlatformTemplateId(server.getPlatformTemplateId());
						applicationProfileDetails.setExistingMachineFlag("N");
						break;
					case DAOConstants.MACHINE_TYPE_EC2:
						applicationProfileDetails.setMachineTemplateId(server.getMachineTemplateId());
						applicationProfileDetails.setPlatformTemplateId(server.getTemplateId());
						applicationProfileDetails.setExistingMachineFlag("N");
						ApplicationProfileDetailsAWSTO awsDetails = new ApplicationProfileDetailsAWSTO();
						awsDetails.setServerGroup(serverRow);
						awsDetails.setKey(server.getKeyName());
						awsDetails.setAvalabilityZone(server.getPlacement());
						awsDetails.setApplicationProfile(applicationProfile);
						applicationProfile.getApplicationProfileDetailsAws().add(awsDetails);
						break;
					case DAOConstants.MACHINE_TYPE_VMWARE_BARE:
						applicationProfileDetails.setMachineTemplateId(server.getMachineTemplateId());
						applicationProfileDetails.setPlatformTemplateId(server.getPlatformTemplateId());
						applicationProfileDetails.setExistingMachineFlag("B");
						break;
					case DAOConstants.MACHINE_TYPE_OPENSTACK:
						applicationProfileDetails.setMachineTemplateId(server.getMachineTemplateId());
						applicationProfileDetails.setPlatformTemplateId(server.getPlatformTemplateId());
						applicationProfileDetails.setExistingMachineFlag("N");
						break;
					default:
						break;
				}
				applicationProfileDetails.setProfile(applicationProfile);
				applicationProfile.getProfileDetails().add(applicationProfileDetails);
			} else {
				boolean awsAdded = false;
				for (ApplicationProfilesServerSoftwareSetTO software : server.getSoftwareSet()) {
					ApplicationProfileDetailsTO applicationProfileDetails = new ApplicationProfileDetailsTO();
					applicationProfileDetails.setServerName(server.getFriendlyServerName());
					applicationProfileDetails.setServerGroup(serverRow);
					applicationProfileDetails.setMappedSoftwareId(software.getSoftwareConfigId());
					Set<ApplicationProfileSoftwareParamertsTO> parametersSet = new HashSet<ApplicationProfileSoftwareParamertsTO>();
					for (Map.Entry<Long, String> map : software.getParameters().entrySet()) {
						ApplicationProfileSoftwareParamertsTO param = new ApplicationProfileSoftwareParamertsTO();
						param.setPropertyId(map.getKey());
						param.setPropertyValue(map.getValue());
						param.setActivityId(1L);
						param.setApplicationProfileDetails(applicationProfileDetails);
						parametersSet.add(param);
					}
					if (software.getInstallRequired() != null) {
						if ("true".equalsIgnoreCase(software.getInstallRequired())) {
							applicationProfileDetails.setInstallRequired("Y");
						} else {
							applicationProfileDetails.setInstallRequired("N");
						}
					} else {
						applicationProfileDetails.setInstallRequired("N");
					}
					applicationProfileDetails.setApplicationProfileSoftwareParamertsTOs(parametersSet);
					switch (server.getMachineType()) {
						case DAOConstants.MACHINE_TYPE_PHYSICAL:
							applicationProfileDetails.setExistingMachineId(server.getMachineTemplateId());
							applicationProfileDetails.setExistingPlatformId(server.getPlatformTemplateId());
							applicationProfileDetails.setExistingMachineFlag("Y");
							break;
						case DAOConstants.MACHINE_TYPE_VMWARE:
							applicationProfileDetails.setMachineTemplateId(server.getMachineTemplateId());
							applicationProfileDetails.setPlatformTemplateId(server.getPlatformTemplateId());
							applicationProfileDetails.setExistingMachineFlag("N");
							break;
						case DAOConstants.MACHINE_TYPE_EC2:
							applicationProfileDetails.setMachineTemplateId(server.getMachineTemplateId());
							applicationProfileDetails.setPlatformTemplateId(server.getTemplateId());
							applicationProfileDetails.setExistingMachineFlag("N");
							if (!awsAdded) {
								ApplicationProfileDetailsAWSTO awsDetails = new ApplicationProfileDetailsAWSTO();
								awsDetails.setServerGroup(serverRow);
								awsDetails.setKey(server.getKeyName());
								awsDetails.setAvalabilityZone(server.getPlacement());
								awsDetails.setApplicationProfile(applicationProfile);
								applicationProfile.getApplicationProfileDetailsAws().add(awsDetails);
								awsAdded = true;
							}
							break;
						case DAOConstants.MACHINE_TYPE_VMWARE_BARE:
							applicationProfileDetails.setMachineTemplateId(server.getMachineTemplateId());
							applicationProfileDetails.setPlatformTemplateId(server.getPlatformTemplateId());
							applicationProfileDetails.setExistingMachineFlag("B");
							break;
						case DAOConstants.MACHINE_TYPE_OPENSTACK:
							applicationProfileDetails.setMachineTemplateId(server.getMachineTemplateId());
							applicationProfileDetails.setPlatformTemplateId(server.getPlatformTemplateId());
							applicationProfileDetails.setExistingMachineFlag("N");
							break;
						default:
							break;
					}
					applicationProfileDetails.setProfile(applicationProfile);
					applicationProfile.getProfileDetails().add(applicationProfileDetails);
				}
			}
		}
		getHibernateTemplate().save(applicationProfile);
		Long profileId = applicationProfile.getId();
		for (String applicationId : selectedApplicationsList) {
			ApplicationProfileMappingTO applicationProfileMapping = new ApplicationProfileMappingTO();
			applicationProfileMapping.setApplicationId(Long.parseLong(applicationId));
			applicationProfileMapping.setProfileId(profileId);
			getHibernateTemplate().save(applicationProfileMapping);
		}
		if (machineSet.get(0).getMachineType().contains(CMMConstants.Framework.MachineTypes.MACHINE_TYPE_DOCKER)) {
			ApplicationProfileDockerTO applicationProfileDocker = new ApplicationProfileDockerTO();
			applicationProfileDocker.setRepository(machineSet.get(0).getDockerImages().getRepository());
			applicationProfileDocker.setImageId(machineSet.get(0).getDockerImages().getImageId());
			applicationProfileDocker.setProfileId(profileId);
			applicationProfileDocker.setServerIp(machineSet.get(0).getDockerImages().getServerIp());
			applicationProfileDocker.setTags(machineSet.get(0).getDockerImages().getTags());
			applicationProfileDocker.setVirtualSize(machineSet.get(0).getDockerImages().getVirtualSize());
			getHibernateTemplate().save(applicationProfileDocker);
			ProvisionedPlatformTO provisionedPlatformTO = new ProvisionedPlatformTO();
			provisionedPlatformTO.setType(CMMConstants.Framework.MachineTypes.MACHINE_TYPE_DOCKER);
			provisionedPlatformTO.setPlatformTemplateName("Docker_" + profileId);
			Long provisionedPlatformid = (Long) getHibernateTemplate().save(provisionedPlatformTO);
			ProvisionedMachineTO provisionedMachineTO = new ProvisionedMachineTO();
			provisionedMachineTO.setProvisionedMachineType(machineSet.get(0).getMachineType());
			provisionedMachineTO.setVirtualMachineType(machineSet.get(0).getMachineType());
			provisionedMachineTO.setName("Docker_" + profileId);
			provisionedMachineTO.setMachineTypeId((long) 7);
			provisionedMachineTO.setProvisionedPlatformTemplateId(provisionedPlatformid);
			getHibernateTemplate().save(provisionedMachineTO);
		}
		return profileId;
	}
	
	@Override
	public MachineTO getMachineDetailsById(long machineId) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			return (MachineTO) session.createCriteria(MachineTO.class).add(Restrictions.eq("id", machineId)).uniqueResult();
		} catch (DataAccessException dae) {
			throw new CMMException("Error in fetching machine details for machineId:: " + machineId, dae);
		} catch (HibernateException he) {
			throw new CMMException("Can not fetch machine data from database for machineId:: " + machineId, he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public MachineTemplateTO getMachineDetails(Long macId) throws CMMException {
	
		try {
			MachineTemplateTO machineTemplateTO = new MachineTemplateTO();
			List<MachineTemplateTO> machineTemplateList = (List<MachineTemplateTO>) getHibernateTemplate().find("from MachineTemplateTO where id=?", macId);
			if (!machineTemplateList.isEmpty()) {
				machineTemplateTO = machineTemplateList.get(0);
			}
			return machineTemplateTO;
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered.ApplicationProfilesDAOImpl: getMachineDetails", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.ApplicationProfilesDAOImpl: getMachineDetails.", he);
		}
	}
	
	@Override
	public PlatformTemplateTO getPlatformDetails(Long platformId) throws CMMException {
	
		try {
			PlatformTemplateTO platformTemplateTO = new PlatformTemplateTO();
			List<PlatformTemplateTO> platformTemplateList = (List<PlatformTemplateTO>) getHibernateTemplate().find("from PlatformTemplateTO where id=?", platformId);
			if (!platformTemplateList.isEmpty()) {
				platformTemplateTO = platformTemplateList.get(0);
			}
			return platformTemplateTO;
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered.ApplicationProfilesDAOImpl: getPlatformDetails", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.ApplicationProfilesDAOImpl: getPlatformDetails.", he);
		}
	}
	
	@Override
	public ProvisionedMachineTO getExistingMachineDetails(Long existingMacId) throws CMMException {
	
		try {
			ProvisionedMachineTO provisionedMachine = new ProvisionedMachineTO();
			String hql = String.format("select a from ProvisionedMachineTO a where id=%d", existingMacId);
			List<ProvisionedMachineTO> provisionedMachineList = (List<ProvisionedMachineTO>) getHibernateTemplate().find(hql);
			if (!provisionedMachineList.isEmpty()) {
				provisionedMachine = provisionedMachineList.get(0);
			}
			return provisionedMachine;
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered.ApplicationProfilesDAOImpl: getExistingMachineDetails", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.ApplicationProfilesDAOImpl: getExistingMachineDetails.", he);
		}
	}
	
	@Override
	public ProvisionedPlatformTO getExistingPlatformDetails(Long existingPlatformId) throws CMMException {
	
		try {
			ProvisionedPlatformTO provisionedPlatform = new ProvisionedPlatformTO();
			String hql = String.format("from ProvisionedPlatformTO where id=%d", existingPlatformId);
			List<ProvisionedPlatformTO> provisionedPlatformList = (List<ProvisionedPlatformTO>) getHibernateTemplate().find(hql);
			if (!provisionedPlatformList.isEmpty()) {
				provisionedPlatform = provisionedPlatformList.get(0);
			}
			return provisionedPlatform;
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered.ApplicationProfilesDAOImpl: getExistingPlatformDetails", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.ApplicationProfilesDAOImpl: getExistingPlatformDetails.", he);
		}
	}
	
	@Override
	public List<ProvisionedMachineTO> fetchPhysicalMachinesDetails() throws CMMException {
	
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(ProvisionedMachineTO.class);
			criteria.add(Restrictions.eq("provisionedMachineType", CMMConstants.Framework.MachineTypes.MACHINE_TYPE_PHYSICAL));
			criteria.add(Restrictions.eq("serverStatus", "ACT"));
			return (List<ProvisionedMachineTO>) getHibernateTemplate().findByCriteria(criteria);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : fetchPhysicalMachinesDetails", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : fetchPhysicalMachinesDetails", he);
		}
	}
	
	@Override
	public List<ProvisionedMachineTO> fetchPhysicalMachinesDetailsByName(ProvisionedMachineTO provisionedMachineTO) throws CMMException {
	
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(ProvisionedMachineTO.class);
			criteria.add(Restrictions.eq("provisionedMachineType", CMMConstants.Framework.MachineTypes.MACHINE_TYPE_PHYSICAL));
			criteria.add(Restrictions.eq("serverStatus", "ACT"));
			if (!"".equalsIgnoreCase(provisionedMachineTO.getName()) && !(provisionedMachineTO.getName() == null)) {
				criteria.add(Restrictions.like("name", "%" + provisionedMachineTO.getName() + "%"));
			}
			return (List<ProvisionedMachineTO>) getHibernateTemplate().findByCriteria(criteria);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : fetchPhysicalMachinesDetails", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : fetchPhysicalMachinesDetails", he);
		}
	}
	
	@Override
	public boolean checkProfileName(String profileName) throws CMMException {
	
		try {
			List<ApplicationProfileTO> applicationProfileTOList = (List<ApplicationProfileTO>) getHibernateTemplate().find("from ApplicationProfileTO where name=?", profileName);
			return !applicationProfileTOList.isEmpty();
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : checkProfileName", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : checkProfileName", he);
		}
	}
	
	@Override
	public boolean checkProfileNameEdit(String profileName, Long id) throws CMMException {
	
		Boolean flag = false;
		try {
			List<ApplicationProfileTO> applicationProfileTOList = (List<ApplicationProfileTO>) getHibernateTemplate().find("from ApplicationProfileTO where name=? and id <> ?", profileName, id);
			if (!applicationProfileTOList.isEmpty()) {
				flag = true;
			} else {
				flag = false;
			}
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : checkProfileName", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : checkProfileName", he);
		}
		return flag;
	}
	
	@Override
	public List<String> getBUNameForSelectedApplicationProfile(String profileName) throws CMMException {
	
		List<String> businessUnitNameList = new ArrayList<String>();
		try {
			businessUnitNameList = (List<String>) getHibernateTemplate().find("select u.name from BusinessUnitTO u, ApplicationTO a, ApplicationProfileMappingTO apm, ApplicationProfileTO ap where a.businessUnitTO.clientId=u.clientId and a.id=apm.applicationId and ap.id=apm.profileId and ap.name=?", profileName);
			return businessUnitNameList;
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : getBUNameForSelectedApplicationProfile", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : getBUNameForSelectedApplicationProfile", he);
		}
	}
	
	@Override
	public boolean searchIfServerNameAlreadyExist(List<Long> applicationIds, String serverName) throws CMMException {
	
		String serverName1 = serverName.split("\t")[0];
		boolean flag = false;
		Session session = null;
		List<Long> profileIds = new ArrayList<Long>(0);
		try {
			session = getSession();
			String hql = "select distinct profileId from ApplicationProfileMappingTO where applicationId in (:applicationIds)";
			Query q = session.createQuery(hql);
			q.setParameterList("applicationIds", applicationIds);
			List<Object[]> objects = q.list();
			for (Object profileid : objects) {
				profileIds.add((Long) profileid);
			}
			if (!profileIds.isEmpty()) {
				String hql1 = "select id from ApplicationProfileDetailsTO where profileId in (:profileIds)  and serverName=: serverName1 ";
				Query q1 = session.createQuery(hql1);
				q1.setParameter("serverName1", serverName1);
				q1.setParameterList("profileIds", profileIds);
				List<Object[]> objects1 = q1.list();
				if (objects1.size() > 0) {
					flag = true;
				}
			} else {
				return flag;
			}
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ApplicationProfilesDAOImpl: searchIfServerNameAlreadyExist", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ApplicationProfilesDAOImpl: searchIfServerNameAlreadyExist", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return flag;
	}
	
	@Override
	public boolean searchIfServerNameAlreadyExistEdit(List<Long> applicationIds, String serverName, Long rownumber) throws CMMException {
	
		String serverName1 = serverName.split("\t")[0];
		boolean flag = false;
		Session session = null;
		List<Long> profileIds = new ArrayList<Long>(0);
		try {
			session = getSession();
			String hql = "select distinct profileId from ApplicationProfileMappingTO where applicationId in (:applicationIds)";
			Query q = session.createQuery(hql);
			q.setParameterList("applicationIds", applicationIds);
			List<Object[]> objects = q.list();
			for (Object profileid : objects) {
				profileIds.add((Long) profileid);
			}
			if (!profileIds.isEmpty()) {
				String hql1 = "select id from ApplicationProfileDetailsTO where profileId in (:profileIds) and serverName=: serverName1 and serverGroup<>:rownumber";
				Query q1 = session.createQuery(hql1);
				q1.setParameterList("profileIds", profileIds);
				q1.setLong("rownumber", rownumber);
				q1.setParameter("serverName1", serverName1);
				List<Object[]> objects1 = q1.list();
				if (!objects1.isEmpty()) {
					flag = true;
				}
			} else {
				return flag;
			}
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ApplicationProfilesDAOImpl: searchIfServerNameAlreadyExist", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ApplicationProfilesDAOImpl: searchIfServerNameAlreadyExist", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return flag;
	}
	
	@Override
	public Long getApplicationProfileIDByName(String applicationProfileName) throws CMMException {
	
		List<ApplicationProfileTO> applicationProfileList = null;
		try {
			applicationProfileList = (List<ApplicationProfileTO>) getHibernateTemplate().find("from ApplicationProfileTO where name=?", applicationProfileName);
			if (applicationProfileList.isEmpty()) {
				throw new CMMException("No application profile found for profile name " + applicationProfileName);
			} else if (applicationProfileList.size() > 1) {
				throw new CMMException("No Unique application profile found for profile name" + applicationProfileName);
			}
			return applicationProfileList.get(0).getId();
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ApplicationProfilesDaoImpl : getApplicationProfileIDByName", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ApplicationProfilesDaoImpl : getApplicationProfileIDByName", he);
		}
	}
	
	@Override
	public ApplicationProfileDockerTO getProfileDetailsDocker(Long profileId) throws CMMException {
	
		ApplicationProfileDockerTO applicationProfileDockerTO = new ApplicationProfileDockerTO();
		try {
			applicationProfileDockerTO = (ApplicationProfileDockerTO) getHibernateTemplate().find("from ApplicationProfileDockerTO where profileId=?", profileId).get(0);
			return applicationProfileDockerTO;
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ApplicationProfilesDaoImpl : getProfileDetailsDocker", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ApplicationProfilesDaoImpl : getProfileDetailsDocker", he);
		} catch (Exception e) {
			LOG.error("Problem encountered. ApplicationProfilesDaoImpl : getProfileDetailsDocker", e);
			return applicationProfileDockerTO;
		}
	}
	
	@Override
	public boolean checkAppProfileEnvMapping(Long appId, Long profileId, Long envId) throws CMMException {
	
		List<ApplicationProfileMappingTO> applicationProfileMappingList = null;
		List<EnvironmentApplicationTO> applicationEnvMappingList = null;
		try {
			applicationProfileMappingList = (List<ApplicationProfileMappingTO>) getHibernateTemplate().find("from ApplicationProfileMappingTO ap where ap.profileId=? and ap.applicationTO.id=?", profileId, appId);
			if (applicationProfileMappingList.isEmpty()) {
				throw new CMMException("Incorrect application and profile mapping");
			} else if (!applicationProfileMappingList.isEmpty()) {
				applicationEnvMappingList = (List<EnvironmentApplicationTO>) getHibernateTemplate().find("from EnvironmentApplicationTO ea where ea.applicationTO.id=? and ea.environmentTO.id=?", appId, envId);
				if (applicationEnvMappingList.isEmpty()) {
					throw new CMMException("Incorrect application, profile and environment mapping");
				}
			}
			return true;
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ApplicationProfilesDaoImpl : getApplicationProfileIDByName", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ApplicationProfilesDaoImpl : getApplicationProfileIDByName", he);
		}
	}
	
	@Override
	public List<ApplicationProfileMappingTO> getAppProfileMapping(Long appId) throws CMMException {
	
		List<ApplicationProfileMappingTO> applicationProfileMappingList = null;
		try {
			applicationProfileMappingList = (List<ApplicationProfileMappingTO>) getHibernateTemplate().find("from ApplicationProfileMappingTO ap where ap.applicationTO.id=?", appId);
			return applicationProfileMappingList;
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ApplicationProfilesDaoImpl : getApplicationProfileIDByName", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ApplicationProfilesDaoImpl : getApplicationProfileIDByName", he);
		}
	}
	
	@Override
	public List<ApplicationReleasePhaseTO> getAppRelPhaseMapping(Long appId) throws CMMException {
	
		List<ApplicationReleasePhaseTO> applicationRelPhaseList = null;
		try {
			applicationRelPhaseList = (List<ApplicationReleasePhaseTO>) getHibernateTemplate().find("from ApplicationReleasePhaseTO ap where ap.applicationId=?", appId);
			return applicationRelPhaseList;
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ApplicationProfilesDaoImpl : getApplicationProfileIDByName", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ApplicationProfilesDaoImpl : getApplicationProfileIDByName", he);
		}
	}
	
	@Override
	public Long fetchReleasePlan(Long selectedRelease) throws CMMException {
	
		Long selectedReleasePlan = 0L;
		try {
			selectedReleasePlan = (Long) getHibernateTemplate().find("select selectedReleasePlan from ApplicationReleaseTO where id=?", selectedRelease).get(0);
			return selectedReleasePlan;
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ApplicationProfilesDaoImpl : getApplicationProfileIDByName", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ApplicationProfilesDaoImpl : getApplicationProfileIDByName", he);
		}
	}
	
	@Override
	public Long fetchRepositoryDb(Long repoId) throws CMMException {
	
		Long selectedRepositoryDb = 0L;
		try {
			selectedRepositoryDb = (Long) getHibernateTemplate().find("select selectedRepository from ApplicationReleaseDbTO where applicationRelease.id=?", repoId).get(0);
			return selectedRepositoryDb;
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ApplicationProfilesDaoImpl : getApplicationProfileIDByName", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ApplicationProfilesDaoImpl : getApplicationProfileIDByName", he);
		}
	}
	
	@Override
	public Long fetchRepositoryForSourceCode(Long repoId) throws CMMException {
	
		Long selectedRepositorySource = 0L;
		try {
			selectedRepositorySource = (Long) getHibernateTemplate().find("select selectedRepository from ApplicationReleaseSourcecodeTO where applicationReleaseId=?", repoId).get(0);
			return selectedRepositorySource;
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ApplicationProfilesDaoImpl : getApplicationProfileIDByName", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ApplicationProfilesDaoImpl : getApplicationProfileIDByName", he);
		}
	}
}
