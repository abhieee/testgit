package com.ext.dao.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.hibernate.exception.ConstraintViolationException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.ApplicationProfileDAO;
import com.framework.common.CMMConstants;
import com.framework.exception.CMMException;
import com.framework.nolio.to.NolioProcessParametersTO;
import com.framework.to.ApplicationProfileDetailsTO;
import com.framework.to.ApplicationProfileDockerTO;
import com.framework.to.ApplicationProfileMappingTO;
import com.framework.to.ApplicationProfileSoftwareParamertsTO;
import com.framework.to.ApplicationProfileTO;
import com.framework.to.ApplicationTO;
import com.framework.to.EnvironmentTO;
import com.framework.to.NolioTaskMappingTO;
import com.framework.to.ScriptParameterMapTO;
import com.framework.to.ScriptTaskMappingTO;
import com.framework.to.SoftwareTO;
import com.framework.to.SoftwareTaskMappingTO;
import com.framework.to.StatusTO;
import com.framework.to.TaskManagementTO;
import com.framework.to.UserGroupTO;

public class ApplicationProfileDAOImpl extends HibernateDaoSupport implements ApplicationProfileDAO {
	
	@Value("${netra.automation.tool}")
	private String automationTool;
	
	@Override
	public List<StatusTO> fetchEnvironmentStatusList() throws CMMException {
	
		try {
			return (List<StatusTO>) getHibernateTemplate().find("from StatusTO where entityId =?", CMMConstants.Framework.Entity.ENVIRONMENT);
		} catch (DataAccessException e) {
			logger.error(e);
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : fetchEnvironmentStatusList", e);
		} catch (HibernateException e) {
			logger.error(e);
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : fetchEnvironmentStatusList", e);
		}
	}
	
	@Override
	public ApplicationProfileTO addProfile(ApplicationProfileTO applicationProfileTO) throws CMMException {
	
		try {
			ApplicationProfileTO addProf = new ApplicationProfileTO();
			addProf.setCreatedById(applicationProfileTO.getCreatedById());
			addProf.setCreatedByDate(applicationProfileTO.getCreatedByDate());
			addProf.setName(applicationProfileTO.getName());
			addProf.setStatus(applicationProfileTO.getStatus());
			if (!applicationProfileTO.getProfileDetails().isEmpty()) {
				for (ApplicationProfileDetailsTO details : applicationProfileTO.getProfileDetails()) {
					if (details.getSoftwareList().isEmpty()) {
						ApplicationProfileDetailsTO temp = new ApplicationProfileDetailsTO();
						temp.setHardwareId(details.getHardwareId());
						temp.setServerGroup(details.getServerGroup());
						temp.setProfile(addProf);
						addProf.getProfileDetails().add(temp);
					} else {
						for (SoftwareTO softTo : details.getSoftwareList()) {
							Long id = softTo.getSoftwareconfigsId();
							ApplicationProfileDetailsTO temp = new ApplicationProfileDetailsTO();
							temp.setHardwareId(details.getHardwareId());
							temp.setMappedSoftwareId(id);
							temp.setServerGroup(details.getServerGroup());
							List<NolioProcessParametersTO> parameters = details.getSoftwarePropertiesMapping().get(id);
							Set<ApplicationProfileSoftwareParamertsTO> set = new HashSet<ApplicationProfileSoftwareParamertsTO>();
							for (NolioProcessParametersTO temp1 : parameters) {
								ApplicationProfileSoftwareParamertsTO applicationProfileSoftwareParamertsTO = new ApplicationProfileSoftwareParamertsTO();
								applicationProfileSoftwareParamertsTO.setPropertyId(temp1.getParameterId());
								applicationProfileSoftwareParamertsTO.setPropertyValue(temp1.getParameterValue());
								applicationProfileSoftwareParamertsTO.setApplicationProfileDetails(temp);
								applicationProfileSoftwareParamertsTO.setActivityId(1L);
								set.add(applicationProfileSoftwareParamertsTO);
							}
							temp.setApplicationProfileSoftwareParamertsTOs(set);
							temp.setProfile(addProf);
							addProf.getProfileDetails().add(temp);
						}
					}
				}
			}
			getHibernateTemplate().save(addProf);
			for (Long app : applicationProfileTO.getDefinedApplications()) {
				ApplicationProfileMappingTO appProfMappingTO = new ApplicationProfileMappingTO();
				appProfMappingTO.setApplicationId(app);
				appProfMappingTO.setProfileId(addProf.getId());
				getHibernateTemplate().save(appProfMappingTO);
			}
			return addProf;
		} catch (ConstraintViolationException e) {
			logger.error(e);
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : addProfile", e);
		} catch (DataAccessException e) {
			logger.error(e);
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : addProfile", e);
		} catch (HibernateException e) {
			logger.error(e);
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : addProfile", e);
		}
	}
	
	@Override
	public List<ApplicationProfileTO> searchAppProfile(ApplicationProfileTO applicationProfileTO, List<Long> clientidList, List<UserGroupTO> userGrps) throws CMMException {
	
		Session session = null;
		session = getSession();
		boolean whereSet = false;
		String Query = "";
		String strInnerQuery = "";
		String s = "";
		String strInnerQueryUserGroup = "";
		String sug = "";
		if (clientidList != null) {
			for (Long clientId : clientidList) {
				strInnerQuery = strInnerQuery + "," + clientId.toString();
			}
		}
		if ((strInnerQuery != "") && !strInnerQuery.isEmpty()) {
			s = strInnerQuery.substring(1, strInnerQuery.length());
		}
		if (!userGrps.isEmpty()) {
			for (UserGroupTO ugto : userGrps) {
				strInnerQueryUserGroup = strInnerQueryUserGroup + "," + ugto.getId().toString();
			}
		} else {
			sug = "-1";
		}
		if ((strInnerQueryUserGroup != "") && !strInnerQueryUserGroup.isEmpty()) {
			sug = strInnerQueryUserGroup.substring(1, strInnerQueryUserGroup.length());
		}
		try {
			if (applicationProfileTO.getClientId() == 0) {
				Query = "select Distinct p from  ApplicationProfileTO p left join p.applicationProfileMapping m ";
				if ((applicationProfileTO.getName() != null) && !"".equalsIgnoreCase(applicationProfileTO.getName().trim())) {
					String appProfileName = applicationProfileTO.getName().replace("_", "/_");
					Query = Query + " where (p.name  like '%" + appProfileName + "%' escape '/' )";
					whereSet = true;
				}
				if ((applicationProfileTO.getSelectedApplication() != null) && (applicationProfileTO.getSelectedApplication() > 0L)) {
					if (whereSet) {
						Query = Query + " and m.applicationTO.id = " + applicationProfileTO.getSelectedApplication();
					} else {
						Query = Query + " where m.applicationTO.id = " + applicationProfileTO.getSelectedApplication();
						whereSet = true;
					}
				}
				if ((applicationProfileTO.getSelectedStatus() != null) && (applicationProfileTO.getSelectedStatus() > 0L)) {
					if (whereSet) {
						Query = Query + " and p.statusTO.id = " + applicationProfileTO.getSelectedStatus();
					} else {
						Query = Query + " where p.statusTO.id = " + applicationProfileTO.getSelectedStatus();
						whereSet = true;
					}
				}
			} else {
				Query = "select Distinct p from  ApplicationProfileTO p left join p.applicationProfileMapping m left join m.applicationTO a left join a.businessUnitTO b inner join a.userGroups u where b.clientId=a.businessUnitTO.clientId and b.clientId in (" + s + ") and u.id in (" + sug + ")";
				if ((applicationProfileTO.getName() != null) && !"".equalsIgnoreCase(applicationProfileTO.getName().trim())) {
					String appProfileName = applicationProfileTO.getName().replace("_", "/_");
					Query = Query + " and (p.name  like '%" + appProfileName + "%' escape '/' )";
				}
				if ((applicationProfileTO.getSelectedApplication() != null) && (applicationProfileTO.getSelectedApplication() > 0L)) {
					Query = Query + " and m.applicationTO.id = " + applicationProfileTO.getSelectedApplication();
				}
				if ((applicationProfileTO.getSelectedStatus() != null) && (applicationProfileTO.getSelectedStatus() > 0L)) {
					Query = Query + " and p.statusTO.id = " + applicationProfileTO.getSelectedStatus();
				}
			}
			Query q = session.createQuery(Query);
			if (applicationProfileTO.getSearchCount() == 0) {
				return (List<ApplicationProfileTO>) getHibernateTemplate().find(Query);
			}
			q.setFirstResult(applicationProfileTO.getFirstResult());
			q.setMaxResults(applicationProfileTO.getTableSize());
			List<Object[]> temp = q.list();
			List<ApplicationProfileTO> profList = new ArrayList<ApplicationProfileTO>();
			for (Object hd : temp) {
				profList.add((ApplicationProfileTO) hd);
			}
			return profList;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : searchAppProfile", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : searchAppProfile", he);
		}
	}
	
	@Override
	public List<StatusTO> getStatusList() throws CMMException {
	
		try {
			return (List<StatusTO>) getHibernateTemplate().find("from StatusTO where entityId=?", CMMConstants.Framework.Entity.APPLICATION_PROFILE);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : getStatusList", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : getStatusList", he);
		}
	}
	
	@Override
	public ApplicationProfileTO getDetailsForProfile(Long id) throws CMMException {
	
		try {
			return (ApplicationProfileTO) getHibernateTemplate().find("from ApplicationProfileTO where id=?", id).get(0);
		} catch (DataAccessException e) {
			logger.error(e);
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : getDetailsForProfile", e);
		} catch (HibernateException e) {
			logger.error(e);
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : getDetailsForProfile", e);
		}
	}
	
	/**
	 * this method fetches application profile details
	 *
	 * @param : id (profile id)
	 * @return: List<ApplicationProfileDetailsTO>
	 */
	@Override
	public List<ApplicationProfileDetailsTO> fetchProfileDetails(Long id) throws CMMException {
	
		try {
			List<ApplicationProfileDetailsTO> temp = new ArrayList<ApplicationProfileDetailsTO>(0);
			List<Object[]> objList = (List<Object[]>) getHibernateTemplate().find("from ApplicationProfileDetailsTO a inner join a.profile b  where b.id=?", id);
			for (Object[] list : objList) {
				temp.add((ApplicationProfileDetailsTO) list[0]);
			}
			return temp;
		} catch (DataAccessException e) {
			logger.error(e);
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : fetchProfileDetails", e);
		} catch (HibernateException e) {
			logger.error(e);
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : fetchProfileDetails", e);
		}
	}
	
	@Override
	public List<NolioProcessParametersTO> getUserDefinedReleaseParameters(Long softwareConfigId) throws CMMException {
	
		List<NolioProcessParametersTO> nolioProcessParametersTOs = new ArrayList<NolioProcessParametersTO>(0);
		List<TaskManagementTO> taskList = new ArrayList<TaskManagementTO>(0);
		List<TaskManagementTO> taskListForTool = new ArrayList<TaskManagementTO>(0);
		try {
			List<SoftwareTaskMappingTO> softwareTasks = (List<SoftwareTaskMappingTO>) getHibernateTemplate().find("from SoftwareTaskMappingTO where softwareConfigId=?", softwareConfigId);
			for (SoftwareTaskMappingTO taskObj : softwareTasks) {
				List<TaskManagementTO> tasks = (List<TaskManagementTO>) getHibernateTemplate().find("from TaskManagementTO where id=?", taskObj.getTaskId());
				if (!tasks.isEmpty()) {
					taskList.add(tasks.get(0));
				}
			}
			for (TaskManagementTO task : taskList) {
				if (CMMConstants.Framework.AutomationTool.NOLIO.equalsIgnoreCase(automationTool)) {
					if ((CMMConstants.Framework.AutomationTool.NOLIO_ID == task.getManifestTypeTO().getId()) || (CMMConstants.Framework.AutomationTool.SCRIPT_ID == task.getManifestTypeTO().getId())) {
						taskListForTool.add(task);
					}
				}
				if (CMMConstants.Framework.AutomationTool.SSH.equalsIgnoreCase(automationTool)) {
					if (CMMConstants.Framework.AutomationTool.SCRIPT_ID == task.getManifestTypeTO().getId()) {
						taskListForTool.add(task);
					}
				}
			}
			for (TaskManagementTO task : taskListForTool) {
				if (task.getManifestTypeTO().getId() == CMMConstants.Framework.AutomationTool.NOLIO_ID) {
					for (NolioTaskMappingTO nolioTask : task.getNolioTaskMapping()) {
						for (NolioProcessParametersTO nolioParam : nolioTask.getNolioProcess().getNolioProcessParameters()) {
							if (CMMConstants.Framework.NetraNolioParametersMapping.NETRA_PARAMETER_MAPPED_NO.equalsIgnoreCase(nolioParam.getNetraParameterMapping()) && CMMConstants.Framework.ParameterScope.RELEASE.equals(nolioParam.getSelectedParameterScope())) {
								nolioParam.setParameterType(CMMConstants.Framework.GlobalParameters.NOLIO_PARAMETER);
								nolioProcessParametersTOs.add(nolioParam);
							}
						}
					}
					for (ScriptTaskMappingTO scriptTask : task.getScriptTaskMappingTO()) {
						List<ScriptParameterMapTO> scriptParameterMapTOs = (List<ScriptParameterMapTO>) getHibernateTemplate().find("from ScriptParameterMapTO where scriptMapId=?", scriptTask.getScriptId());
						for (ScriptParameterMapTO scriptParam : scriptParameterMapTOs) {
							if (CMMConstants.Framework.NetraNolioParametersMapping.NETRA_PARAMETER_MAPPED_NO.equalsIgnoreCase(scriptParam.getNetraParameterMapping()) && CMMConstants.Framework.ParameterScope.RELEASE.equals(scriptParam.getSelectedParameterScopes())) {
								NolioProcessParametersTO scriptParameter = new NolioProcessParametersTO();
								scriptParameter.setParameterPathName(scriptParam.getParameterName());
								scriptParameter.setParameterValue(scriptParam.getDefaultParameterValues());
								scriptParameter.setParameterId(scriptParam.getScriptMapId());
								scriptParameter.setParameterType(CMMConstants.Framework.GlobalParameters.SCRIPT_PARAMETER);
								nolioProcessParametersTOs.add(scriptParameter);
							}
						}
					}
				}
				if (task.getManifestTypeTO().getId() == CMMConstants.Framework.AutomationTool.SCRIPT_ID) {
					for (ScriptTaskMappingTO scriptTask : task.getScriptTaskMappingTO()) {
						List<ScriptParameterMapTO> scriptParameterMapTOs = (List<ScriptParameterMapTO>) getHibernateTemplate().find("from ScriptParameterMapTO where mappedScript.scriptId=?", scriptTask.getScriptId());
						for (ScriptParameterMapTO scriptParam : scriptParameterMapTOs) {
							if (CMMConstants.Framework.NetraNolioParametersMapping.NETRA_PARAMETER_MAPPED_NO.equalsIgnoreCase(scriptParam.getNetraParameterMapping()) && CMMConstants.Framework.ParameterScope.RELEASE.equals(scriptParam.getSelectedParameterScopes())) {
								NolioProcessParametersTO scriptParameter = new NolioProcessParametersTO();
								scriptParameter.setParameterPathName(scriptParam.getParameterName());
								scriptParameter.setParameterValue(scriptParam.getDefaultParameterValues());
								scriptParameter.setParameterId(scriptParam.getScriptMapId());
								scriptParameter.setParameterType(CMMConstants.Framework.GlobalParameters.SCRIPT_PARAMETER);
								nolioProcessParametersTOs.add(scriptParameter);
							}
						}
					}
				}
			}
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered.ApplicationProfileDAOImpl:getUserDefinedReleaseParameters", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.ApplicationProfileDAOImpl:getUserDefinedReleaseParameters", he);
		} catch (Exception ex) {
			throw new CMMException("Problem encountered.ApplicationProfileDAOImpl:getUserDefinedReleaseParameters", ex);
		}
		return nolioProcessParametersTOs;
	}
	
	@Override
	public ApplicationProfileTO editProfile(ApplicationProfileTO applicationProfileTO) throws CMMException {
	
		try {
			ApplicationProfileTO editEnvNew = (ApplicationProfileTO) getHibernateTemplate().find("from ApplicationProfileTO a where a.id=?", applicationProfileTO.getId()).get(0);
			editEnvNew.setName(applicationProfileTO.getName());
			editEnvNew.setStatus(applicationProfileTO.getStatus());
			editEnvNew.setModifiedbyId(applicationProfileTO.getModifiedbyId());
			editEnvNew.setModifiedbyDate(applicationProfileTO.getModifiedbyDate());
			List<ApplicationProfileDetailsTO> appProdetList = new ArrayList<ApplicationProfileDetailsTO>(0);
			List<ApplicationProfileDetailsTO> appProdetList3 = new ArrayList<ApplicationProfileDetailsTO>(0);
			List<ApplicationProfileMappingTO> appProMapList = new ArrayList<ApplicationProfileMappingTO>(0);
			for (ApplicationProfileMappingTO appProMap : editEnvNew.getApplicationProfileMapping()) {
				appProMapList.add(appProMap);
			}
			for (ApplicationProfileDetailsTO appProObj : editEnvNew.getProfileDetails()) {
				appProdetList.add(appProObj);
			}
			editEnvNew.getProfileDetails().clear();
			List<ApplicationProfileSoftwareParamertsTO> appProSoftParaToList = new ArrayList<ApplicationProfileSoftwareParamertsTO>(0);
			List<ApplicationProfileSoftwareParamertsTO> appProSoftParaToList1 = new ArrayList<ApplicationProfileSoftwareParamertsTO>(0);
			List<ApplicationProfileSoftwareParamertsTO> appProSoftParaToList2 = new ArrayList<ApplicationProfileSoftwareParamertsTO>(0);
			List<ApplicationProfileSoftwareParamertsTO> appProSoftParaToListFinalForAdd = new ArrayList<ApplicationProfileSoftwareParamertsTO>(0);
			for (ApplicationProfileDetailsTO details : applicationProfileTO.getProfileDetails()) {
				if (details.getSoftwareList().isEmpty()) {
					ApplicationProfileDetailsTO temp = new ApplicationProfileDetailsTO();
					temp.setHardwareId(details.getHardwareId());
					temp.setServerGroup(details.getServerGroup());
					temp.setProfile(editEnvNew);
					editEnvNew.getProfileDetails().add(temp);
				} else {
					for (SoftwareTO softTo : details.getSoftwareList()) {
						ApplicationProfileDetailsTO temp = new ApplicationProfileDetailsTO();
						temp.setHardwareId(details.getHardwareId());
						temp.setMappedSoftwareId(softTo.getSoftwareconfigsId());
						temp.setServerGroup(details.getServerGroup());
						List<NolioProcessParametersTO> parameters = details.getSoftwarePropertiesMapping().get(softTo.getId());
						Set<ApplicationProfileSoftwareParamertsTO> set = new HashSet<ApplicationProfileSoftwareParamertsTO>();
						if (parameters != null) {
							for (NolioProcessParametersTO temp1 : parameters) {
								ApplicationProfileSoftwareParamertsTO applicationProfileSoftwareParamertsTO = new ApplicationProfileSoftwareParamertsTO();
								applicationProfileSoftwareParamertsTO.setPropertyId(temp1.getParameterId());
								applicationProfileSoftwareParamertsTO.setPropertyValue(temp1.getParameterValue());
								applicationProfileSoftwareParamertsTO.setApplicationProfileDetails(temp);
								set.add(applicationProfileSoftwareParamertsTO);
							}
						}
						temp.setApplicationProfileSoftwareParamertsTOs(set);
						temp.setProfile(editEnvNew);
						editEnvNew.getProfileDetails().add(temp);
					}
				}
			}
			for (ApplicationProfileDetailsTO appProObj : appProdetList) {
				for (ApplicationProfileSoftwareParamertsTO parameter : appProObj.getApplicationProfileSoftwareParamertsTOs()) {
					appProSoftParaToList.add(parameter);
				}
			}
			getHibernateTemplate().update(editEnvNew);
			List<ApplicationProfileMappingTO> profMapingList = new ArrayList<ApplicationProfileMappingTO>();
			profMapingList = (List<ApplicationProfileMappingTO>) getHibernateTemplate().find("from ApplicationProfileMappingTO where profileId =?", applicationProfileTO.getId());
			getHibernateTemplate().deleteAll(profMapingList);
			for (Long app : applicationProfileTO.getDefinedApplications()) {
				ApplicationProfileMappingTO appProfMappingTO = new ApplicationProfileMappingTO();
				appProfMappingTO.setApplicationId(app);
				appProfMappingTO.setProfileId(editEnvNew.getId());
				getHibernateTemplate().save(appProfMappingTO);
			}
			List<ApplicationProfileDetailsTO> appProdetList1 = appProdetList;
			List<ApplicationProfileDetailsTO> appProdetList2 = (List<ApplicationProfileDetailsTO>) getHibernateTemplate().find("from ApplicationProfileDetailsTO where profileId =?", applicationProfileTO.getId());
			for (ApplicationProfileDetailsTO appProDet1 : appProdetList1) {
				for (ApplicationProfileDetailsTO appProDet2 : appProdetList2) {
					if (appProDet1.getHardwareId().equals(appProDet2.getHardwareId()) && appProDet1.getMappedSoftwareId().equals(appProDet2.getMappedSoftwareId()) && appProDet1.getServerGroup().equals(appProDet2.getServerGroup())) {
						appProDet2.setOldAppProDetId(appProDet1.getId());
						appProdetList2.remove(appProDet2);
						appProdetList3.add(appProDet2);
					}
					break;
				}
			}
			for (ApplicationProfileSoftwareParamertsTO para : appProSoftParaToList) {
				for (ApplicationProfileDetailsTO appPro : appProdetList3) {
					if (para.getApplicationProfileDetails().getId().equals(appPro.getOldAppProDetId())) {
						ApplicationProfileDetailsTO appProObj = new ApplicationProfileDetailsTO();
						appProObj.setId(appPro.getId());
						para.setApplicationProfileDetails(appProObj);
						appProSoftParaToList1.add(para);
						break;
					}
				}
			}
			for (ApplicationProfileSoftwareParamertsTO appProSoft : appProSoftParaToList) {
				Long applicationId = null;
				Long profileId = null;
				Long appProMapId = appProSoft.getApplicationProfileMapId();
				for (ApplicationProfileMappingTO appProMap : appProMapList) {
					Long appProMapId1 = appProMap.getId();
					appProMapId.compareTo(appProMapId1);
					if (appProMapId.compareTo(appProMapId1) == 0) {
						applicationId = appProMap.getApplicationId();
						profileId = appProMap.getProfileId();
					}
				}
				ApplicationProfileMappingTO appProMapObj = (ApplicationProfileMappingTO) getHibernateTemplate().find("from ApplicationProfileMappingTO where profileId =? and applicationId=?", profileId, applicationId).get(0);
				appProSoft.setNewAppProMapId(appProMapObj.getId());
				appProSoftParaToList2.add(appProSoft);
			}
			for (ApplicationProfileSoftwareParamertsTO appProSof2 : appProSoftParaToList2) {
				for (ApplicationProfileSoftwareParamertsTO appProSof1 : appProSoftParaToList1) {
					if (appProSof2.getApplicationProfileMapId().equals(appProSof1.getApplicationProfileMapId())) {
						appProSof1.setApplicationProfileMapId(appProSof2.getNewAppProMapId());
						appProSoftParaToListFinalForAdd.add(appProSof1);
						break;
					}
				}
			}
			for (ApplicationProfileSoftwareParamertsTO para : appProSoftParaToListFinalForAdd) {
				getHibernateTemplate().save(para);
			}
			return editEnvNew;
		} catch (DataAccessException e) {
			logger.error(e);
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : editProfile", e);
		} catch (HibernateException e) {
			logger.error(e);
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : editProfile", e);
		} catch (Exception e) {
			logger.error(e);
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : editProfile", e);
		}
	}
	
	@Override
	public boolean defineApplicationsForProfile(ApplicationProfileMappingTO mapping) throws CMMException {
	
		boolean flag = false;
		Session session = null;
		Transaction tx = null;
		try {
			if (mapping.getApplicationTO() != null) {
				List<ApplicationProfileMappingTO> mList = (List<ApplicationProfileMappingTO>) getHibernateTemplate().find("from ApplicationProfileMappingTO where profileId=?", mapping.getProfileId());
				getHibernateTemplate().deleteAll(mList);
			}
			session = getSession();
			tx = session.beginTransaction();
			String hql = "from ApplicationTO where id in (:ApplicationId)";
			Query q = session.createQuery(hql);
			q.setParameterList("ApplicationId", mapping.getDefinedApplications());
			List<Object[]> obj = q.list();
			tx.commit();
			ApplicationProfileMappingTO appProfMappingTO = new ApplicationProfileMappingTO();
			for (Object app : obj) {
				appProfMappingTO.setApplicationTO((ApplicationTO) app);
				appProfMappingTO.setProfileId(mapping.getProfileId());
				getHibernateTemplate().save(appProfMappingTO);
			}
			flag = true;
			return flag;
		} catch (ConstraintViolationException ce) {
			logger.error(ce);
			throw new CMMException("problem encountered. ApplicationProfileDAOImpl : defineApplicationsForProfile", ce);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : defineApplicationsForProfile", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : defineApplicationsForProfile", he);
		} catch (Exception e) {
			logger.error(e);
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : defineApplicationsForProfile", e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<ApplicationTO> getSelectedApplicationsForProfile(Long profileId) throws CMMException {
	
		List<ApplicationTO> appList = new ArrayList<ApplicationTO>();
		try {
			List<ApplicationProfileMappingTO> applicationProfileMappingTO = (List<ApplicationProfileMappingTO>) getHibernateTemplate().find("from ApplicationProfileMappingTO where profileId =?", profileId);
			if (applicationProfileMappingTO == null) {
				logger.debug("No appplications found in database");
				throw new CMMException("No appplications found in database");
			}
			for (ApplicationProfileMappingTO temp : applicationProfileMappingTO) {
				ApplicationTO applicationTO = temp.getApplicationTO();
				appList.add(applicationTO);
			}
			return appList;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : getSelectedApplicationsForProfile", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : getSelectedApplicationsForProfile", he);
		}
	}
	
	@Override
	public List<ApplicationTO> getApplicationsForProfile(List<Long> dapp) throws CMMException {
	
		try {
			return (List<ApplicationTO>) getHibernateTemplate().findByNamedQueryAndNamedParam("fetchApplicationId", "appList", dapp);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : getApplicationsForProfile", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : getApplicationsForProfile", he);
		}
	}
	
	public List<ApplicationProfileTO> getProfilesForApplication1(List<Long> def) throws CMMException {
	
		List<Long> appProfileId = new ArrayList<Long>(0);
		try {
			List<Long> appIdList = def;
			if (appIdList != null) {
				if (appIdList.size() == 1) {
					List<ApplicationProfileMappingTO> mapTO = (List<ApplicationProfileMappingTO>) getHibernateTemplate().findByNamedQueryAndNamedParam("fetchProfile", "appIdList", appIdList);
					for (int i = 0; i < mapTO.size(); i++) {
						appProfileId.add(mapTO.get(i).getProfileId());
					}
				} else {
					StringBuilder query1 = new StringBuilder(String.format("SELECT t0.* FROM(SELECT profile_id FROM application_profile_mapping WHERE application_id =%d", appIdList.get(0)));
					query1.append(") AS t0");
					StringBuilder query2 = new StringBuilder(" WHERE ");
					for (int i = 1; i < appIdList.size(); i++) {
						query1.append(String.format(",(SELECT profile_id FROM application_profile_mapping WHERE application_id =%d", appIdList.get(i)));
						query1.append(String.format(") AS t%d", i));
						if (i == (appIdList.size() - 1)) {
							query2.append(String.format("t0.profile_id = t%d", i));
							query2.append(".profile_id");
						} else {
							query2.append(String.format("t0.profile_id = t%d", i));
							query2.append(".profile_id AND ");
						}
					}
					String query = query1.append(query2).toString();
					SQLQuery mappedProfileIDQuery = getSession().createSQLQuery(query);
					List<Object> profileIdList = mappedProfileIDQuery.list();
					for (Object profile : profileIdList) {
						Long profileId = Long.parseLong(profile.toString());
						appProfileId.add(profileId);
					}
				}
				return (List<ApplicationProfileTO>) getHibernateTemplate().findByNamedQueryAndNamedParam("fetchProfileName", "appProfileId", appProfileId);
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : getProfilesForApplication", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : getProfilesForApplication", he);
		}
		return new ArrayList<ApplicationProfileTO>(0);
	}
	
	@Override
	public List<ApplicationProfileTO> getProfilesForApplication(List<Long> def) throws CMMException {
	
		List<Long> appProfileId = new ArrayList<Long>(0);
		try {
			List<Long> appIdList = def;
			if (appIdList != null) {
				if (appIdList.size() == 1) {
					List<ApplicationProfileMappingTO> mapTO = (List<ApplicationProfileMappingTO>) getHibernateTemplate().findByNamedQueryAndNamedParam("fetchProfile", "appIdList", appIdList);
					for (int i = 0; i < mapTO.size(); i++) {
						appProfileId.add(mapTO.get(i).getProfileId());
					}
				} else {
					StringBuilder query1 = new StringBuilder(String.format("SELECT t0.* FROM(SELECT profile_id FROM application_profile_mapping WHERE application_id =%d", appIdList.get(0)));
					query1.append(") AS t0");
					StringBuilder query2 = new StringBuilder(" WHERE ");
					for (int i = 1; i < appIdList.size(); i++) {
						query1.append(String.format(",(SELECT profile_id FROM application_profile_mapping WHERE application_id =%d", appIdList.get(i)));
						query1.append(String.format(") AS t%d", i));
						if (i == (appIdList.size() - 1)) {
							query2.append(String.format("t0.profile_id = t%d", i));
							query2.append(".profile_id");
						} else {
							query2.append(String.format("t0.profile_id = t%d", i));
							query2.append(".profile_id AND ");
						}
					}
					String query = query1.append(query2).toString();
					SQLQuery mappedProfileIDQuery = getSession().createSQLQuery(query);
					List<Object> profileIdList = mappedProfileIDQuery.list();
					for (Object profile : profileIdList) {
						Long profileId = Long.parseLong(profile.toString());
						appProfileId.add(profileId);
					}
				}
				if (appProfileId.isEmpty()) {
					appProfileId.add(0L);
				}
				return (List<ApplicationProfileTO>) getHibernateTemplate().findByNamedQueryAndNamedParam("fetchProfileName", "appProfileId", appProfileId);
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : getProfilesForApplication", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : getProfilesForApplication", he);
		}
		return new ArrayList<ApplicationProfileTO>(0);
	}
	
	@Override
	public long fetchApplicationProfileDetailsForMachines(long profileId, long softwareConfigId, long serverGroupId) throws CMMException {
	
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(ApplicationProfileDetailsTO.class, "applicationProfileDetails");
			criteria.add(Restrictions.eq("profileId", profileId));
			criteria.add(Restrictions.eq("mappedSoftwareId", softwareConfigId));
			criteria.add(Restrictions.eq("serverGroup", serverGroupId));
			List<ApplicationProfileDetailsTO> applicationProfileDetailsTO = (List<ApplicationProfileDetailsTO>) getHibernateTemplate().findByCriteria(criteria);
			if (applicationProfileDetailsTO.isEmpty()) {
				throw new CMMException();
			}
			return applicationProfileDetailsTO.get(0).getId();
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.ApplicationProfileDAOImpl:fetchApplicationProfileDetailsForMachines.", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.ApplicationProfileDAOImpl:fetchApplicationProfileDetailsForMachines.", he);
		}
	}
	
	@Override
	public boolean checkName(ApplicationProfileTO applicationProfileTO) throws CMMException {
	
		boolean flag = false;
		try {
			List<ApplicationProfileTO> unit = new ArrayList<ApplicationProfileTO>(0);
			if (applicationProfileTO.getId() == null) {
				unit = (List<ApplicationProfileTO>) getHibernateTemplate().find("from ApplicationProfileTO where name=?", applicationProfileTO.getName());
			} else {
				unit = (List<ApplicationProfileTO>) getHibernateTemplate().find("from ApplicationProfileTO where name=? and id<>?", applicationProfileTO.getName(), applicationProfileTO.getId());
			}
			if (unit.isEmpty()) {
				flag = false;
			} else {
				flag = true;
			}
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered.ApplicationProfileDAOImpl:checkName.", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered.ApplicationProfileDAOImpl:checkName.", he);
		}
		return flag;
	}
	
	@Override
	public List<ApplicationProfileTO> searchAppProfileForAppPara(ApplicationProfileTO applicationProfileTO, List<Long> clientidList, List<UserGroupTO> userGroupIds) throws CMMException {
	
		String Query = "";
		String strInnerQuery = "";
		String strInnerQueryUserGroup = "";
		String sug = "";
		for (Long clientId : clientidList) {
			strInnerQuery = strInnerQuery + "," + clientId.toString();
		}
		String s = strInnerQuery.substring(1, strInnerQuery.length());
		if ((userGroupIds != null) && !userGroupIds.isEmpty()) {
			for (UserGroupTO ugto : userGroupIds) {
				strInnerQueryUserGroup = strInnerQueryUserGroup + "," + ugto.getId().toString();
			}
		} else {
			sug = "-1";
		}
		if ((strInnerQueryUserGroup != null) && (strInnerQueryUserGroup != "")) {
			sug = strInnerQueryUserGroup.substring(1, strInnerQueryUserGroup.length());
		}
		try {
			if (applicationProfileTO.getClientId() == 0) {
				Query = "select Distinct p from  ApplicationProfileTO p left join p.applicationProfileMapping m where p.status=101";
			} else {
				Query = "select Distinct p from  ApplicationProfileTO p left join p.applicationProfileMapping m left join m.applicationTO a left join a.businessUnitTO b inner join a.userGroups u where b.clientId=a.businessUnitTO.clientId and b.clientId in (" + s + ") and u.id in (" + sug + ") and  p.status=101";
			}
			return (List<ApplicationProfileTO>) getHibernateTemplate().find(Query);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : searchAppProfile", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. ApplicationProfileDAOImpl : searchAppProfile", he);
		}
	}
	
	@Override
	public List<String> getApplicationNames(Long id) {
	
		List<String> appNames = new ArrayList<String>();
		List<ApplicationProfileMappingTO> apps = null;
		try {
			apps = (List<ApplicationProfileMappingTO>) getHibernateTemplate().find("from ApplicationProfileMappingTO where profileId = ?", id);
			for (ApplicationProfileMappingTO ap : apps) {
				String app = (String) getHibernateTemplate().find("select appName from ApplicationTO where id = ?", ap.getApplicationTO().getId()).get(0);
				appNames.add(app);
			}
		} catch (DataAccessException dae) {
			logger.error("ApplicationProfileDAOImpl:getApplicationNames", dae);
		} catch (HibernateException he) {
			logger.error("ApplicationProfileDAOImpl:getApplicationNames", he);
		} catch (Exception e) {
			logger.error("ApplicationProfileDAOImpl:getApplicationNames", e);
		}
		return appNames;
	}
	
	@Override
	public ApplicationProfileDockerTO getProfileDockerDetails(Long envId) throws CMMException {
	
		ApplicationProfileDockerTO applicationProfileDockerTO = new ApplicationProfileDockerTO();
		EnvironmentTO environmentTO = new EnvironmentTO();
		try {
			environmentTO = (EnvironmentTO) getHibernateTemplate().find("from EnvironmentTO where id = ?", envId).get(0);
			Long profileId = environmentTO.getProfileId();
			applicationProfileDockerTO = (ApplicationProfileDockerTO) getHibernateTemplate().find("from ApplicationProfileDockerTO where profileId = ?", profileId).get(0);
			return applicationProfileDockerTO;
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ApplicationProfileDaoImpl : getProfileDockerDetails", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ApplicationProfileDaoImpl : getProfileDockerDetails", he);
		}
	}
	
	@Override
	public List<ApplicationProfileDockerTO> fetchProfileDockerDetails(Long profileId) throws CMMException {
	
		List<ApplicationProfileDockerTO> applicationProfileDockerTO = new ArrayList<ApplicationProfileDockerTO>();
		try {
			applicationProfileDockerTO = (List<ApplicationProfileDockerTO>) getHibernateTemplate().find("from ApplicationProfileDockerTO where profileId = ?", profileId);
			return applicationProfileDockerTO;
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ApplicationProfileDaoImpl : fetchProfileDockerDetails", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ApplicationProfileDaoImpl : fetchProfileDockerDetails", he);
		}
	}
	
	@Override
	public List<NolioProcessParametersTO> getUserDefinedEnvParameters(Long softwareConfigId) throws CMMException {
	
		List<NolioProcessParametersTO> nolioProcessParametersTOs = new ArrayList<NolioProcessParametersTO>();
		try {
			List<TaskManagementTO> taskList = new ArrayList<TaskManagementTO>(0);
			List<TaskManagementTO> taskListForTool = new ArrayList<TaskManagementTO>(0);
			List<SoftwareTaskMappingTO> softwareTasks = (List<SoftwareTaskMappingTO>) getHibernateTemplate().find("from SoftwareTaskMappingTO where softwareConfigId=?", softwareConfigId);
			for (SoftwareTaskMappingTO taskObj : softwareTasks) {
				List<TaskManagementTO> tasks = (List<TaskManagementTO>) getHibernateTemplate().find("from TaskManagementTO where id=?", taskObj.getTaskId());
				if (!tasks.isEmpty()) {
					taskList.add(tasks.get(0));
				}
			}
			for (TaskManagementTO task : taskList) {
				if (CMMConstants.Framework.AutomationTool.NOLIO.equalsIgnoreCase(automationTool)) {
					if ((CMMConstants.Framework.AutomationTool.NOLIO_ID == task.getManifestTypeTO().getId()) || (CMMConstants.Framework.AutomationTool.SCRIPT_ID == task.getManifestTypeTO().getId())) {
						taskListForTool.add(task);
					}
				}
				if (CMMConstants.Framework.AutomationTool.SSH.equalsIgnoreCase(automationTool)) {
					if (CMMConstants.Framework.AutomationTool.SCRIPT_ID == task.getManifestTypeTO().getId()) {
						taskListForTool.add(task);
					}
				}
			}
			for (TaskManagementTO task : taskListForTool) {
				if (task.getManifestTypeTO().getId() == CMMConstants.Framework.AutomationTool.NOLIO_ID) {
					for (NolioTaskMappingTO nolioTask : task.getNolioTaskMapping()) {
						for (NolioProcessParametersTO nolioParam : nolioTask.getNolioProcess().getNolioProcessParameters()) {
							if ((CMMConstants.Framework.NetraNolioParametersMapping.NETRA_PARAMETER_MAPPED_NO).equalsIgnoreCase(nolioParam.getNetraParameterMapping()) && CMMConstants.Framework.ParameterScope.ENVIRONMENT.equals(nolioParam.getSelectedParameterScope())) {
								nolioParam.setParameterType(CMMConstants.Framework.GlobalParameters.NOLIO_PARAMETER);
								nolioProcessParametersTOs.add(nolioParam);
							}
						}
					}
					for (ScriptTaskMappingTO scriptTask : task.getScriptTaskMappingTO()) {
						List<ScriptParameterMapTO> scriptParameterMapTOs = (List<ScriptParameterMapTO>) getHibernateTemplate().find("from ScriptParameterMapTO where scriptMapId=?", scriptTask.getScriptId());
						for (ScriptParameterMapTO scriptParam : scriptParameterMapTOs) {
							if ((CMMConstants.Framework.NetraNolioParametersMapping.NETRA_PARAMETER_MAPPED_NO).equalsIgnoreCase(scriptParam.getNetraParameterMapping()) && CMMConstants.Framework.ParameterScope.ENVIRONMENT.equals(scriptParam.getSelectedParameterScopes())) {
								NolioProcessParametersTO scriptParameter = new NolioProcessParametersTO();
								scriptParameter.setParameterPathName(scriptParam.getParameterName());
								scriptParameter.setParameterValue(scriptParam.getDefaultParameterValues());
								scriptParameter.setParameterId(scriptParam.getScriptMapId());
								scriptParameter.setParameterType(CMMConstants.Framework.GlobalParameters.SCRIPT_PARAMETER);
								nolioProcessParametersTOs.add(scriptParameter);
							}
						}
					}
				}
				if (task.getManifestTypeTO().getId() == CMMConstants.Framework.AutomationTool.SCRIPT_ID) {
					for (ScriptTaskMappingTO scriptTask : task.getScriptTaskMappingTO()) {
						List<ScriptParameterMapTO> scriptParameterMapTOs = (List<ScriptParameterMapTO>) getHibernateTemplate().find("from ScriptParameterMapTO where mappedScript.scriptId=?", scriptTask.getScriptId());
						for (ScriptParameterMapTO scriptParam : scriptParameterMapTOs) {
							if ((CMMConstants.Framework.NetraNolioParametersMapping.NETRA_PARAMETER_MAPPED_NO).equalsIgnoreCase(scriptParam.getNetraParameterMapping()) && CMMConstants.Framework.ParameterScope.ENVIRONMENT.equals(scriptParam.getSelectedParameterScopes())) {
								NolioProcessParametersTO scriptParameter = new NolioProcessParametersTO();
								scriptParameter.setParameterPathName(scriptParam.getParameterName());
								scriptParameter.setParameterValue(scriptParam.getDefaultParameterValues());
								scriptParameter.setParameterId(scriptParam.getScriptMapId());
								scriptParameter.setParameterType(CMMConstants.Framework.GlobalParameters.SCRIPT_PARAMETER);
								nolioProcessParametersTOs.add(scriptParameter);
							}
						}
					}
				}
			}
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered.ApplicationProfileDAOImpl:getUserDefinedEnvParameters", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered.ApplicationProfileDAOImpl:getUserDefinedEnvParameters", he);
		} catch (Exception ex) {
			throw new CMMException("Problem encountered.ApplicationProfileDAOImpl:getUserDefinedEnvParameters", ex);
		}
		return nolioProcessParametersTOs;
	}
}
