/**
 *
 */
package com.ext.nolio.dao.impl;

import java.util.List;
import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.hibernate.exception.ConstraintViolationException;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.nolio.dao.NolioSoftwareProcessMapDao;
import com.framework.exception.CMMException;
import com.framework.nolio.to.NolioProcessSoftwareMapping;

/**
 * @author 460650
 */
public class NolioSoftwareProcessMapDaoImpl extends HibernateDaoSupport implements NolioSoftwareProcessMapDao {
	
	private static final Logger LOGGER = Logger.getLogger(NolioSoftwareProcessMapDaoImpl.class);
	
	@Override
	public void saveNolioProcessSoftwareMapping(NolioProcessSoftwareMapping nolioProcessSoftwareMapping) throws CMMException {
	
		try {
			getHibernateTemplate().save(nolioProcessSoftwareMapping);
		} catch (DataIntegrityViolationException div) {
			LOGGER.error(div);
			throw new CMMException("Problem encountered. NolioSoftwareProcessMapDaoImpl: saveNolioProcessSoftwareMapping", div);
		} catch (DataAccessException dae) {
			LOGGER.error(dae);
			throw new CMMException("Problem encountered. NolioSoftwareProcessMapDaoImpl: saveNolioProcessSoftwareMapping", dae);
		} catch (ConstraintViolationException e) {
			LOGGER.error(e);
			throw new CMMException("Problem encountered. NolioSoftwareProcessMapDaoImpl: saveNolioProcessSoftwareMapping.", e);
		} catch (HibernateException he) {
			LOGGER.error(he);
			throw new CMMException("Problem encountered. NolioSoftwareProcessMapDaoImpl: saveNolioProcessSoftwareMapping", he);
		}
	}
	
	@Override
	public NolioProcessSoftwareMapping getNolioProcessSoftMapping(long softwareConfigId, long serviceId) throws CMMException {
	
		List<NolioProcessSoftwareMapping> nolioProcessmappingList = null;
		try {
			nolioProcessmappingList = (List<NolioProcessSoftwareMapping>) getHibernateTemplate().findByCriteria(DetachedCriteria.forClass(NolioProcessSoftwareMapping.class).add(Restrictions.eq("softwareConfigId", softwareConfigId)).add(Restrictions.eq("serviceTO.id", serviceId)));
			if (nolioProcessmappingList == null) {
				LOGGER.debug("No record found for softwareConfigId::" + softwareConfigId);
				throw new CMMException("No software-process mapping found for given software configId::" + softwareConfigId);
			}
		} catch (DataAccessException da) {
			LOGGER.error(da);
			throw new CMMException("Problem encountered. NolioSoftwareProcessMapDaoImpl: getNolioProcessSoftMapping", da);
		}
		return nolioProcessmappingList.get(0);
	}
	
	@Override
	public List<NolioProcessSoftwareMapping> getNolioSoftwareProcessMapping(long softwareConfigId) throws CMMException {
	
		List<NolioProcessSoftwareMapping> nolioProcessmappingList = null;
		try {
			nolioProcessmappingList = (List<NolioProcessSoftwareMapping>) getHibernateTemplate().find("from  NolioProcessSoftwareMapping where softwareConfigTO.id = ?", softwareConfigId);
			if (nolioProcessmappingList == null) {
				LOGGER.debug("No record found for softwareConfigId::" + softwareConfigId);
				throw new CMMException("No software-process mapping found for given software configId::" + softwareConfigId);
			}
		} catch (DataAccessException da) {
			LOGGER.error(da);
			throw new CMMException("Problem encountered. NolioSoftwareProcessMapDaoImpl: getNolioSoftwareProcessMapping", da);
		}
		return nolioProcessmappingList;
	}
}
