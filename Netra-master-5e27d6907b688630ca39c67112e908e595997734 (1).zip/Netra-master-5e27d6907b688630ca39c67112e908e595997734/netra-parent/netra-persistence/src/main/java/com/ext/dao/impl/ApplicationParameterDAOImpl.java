package com.ext.dao.impl;

import java.io.BufferedReader;
import java.io.Closeable;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.Serializable;
import java.sql.Blob;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.sql.rowset.serial.SerialBlob;
import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.hibernate.exception.ConstraintViolationException;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.ApplicationParameterDAO;
import com.ext.dao.SoftwareDAO;
import com.framework.exception.CMMException;
import com.framework.nolio.to.CAActivityProcessOrderTO;
import com.framework.nolio.to.NolioProcessParametersTO;
import com.framework.nolio.to.NolioProcessSoftwareMapping;
import com.framework.to.ActivitySoftwareMappingTO;
import com.framework.to.ApplicationParameterTO;
import com.framework.to.ApplicationProfileConfigParamTmpltMappingTO;
import com.framework.to.ApplicationProfileConfigParamsTO;
import com.framework.to.ApplicationProfileConfigTO;
import com.framework.to.ApplicationProfileDetailsTO;
import com.framework.to.ApplicationProfileMappingTO;
import com.framework.to.ApplicationProfileSoftwareParamertsTO;
import com.framework.to.EnvironmentApplicationTO;
import com.framework.to.EnvironmentDetailsTO;
import com.framework.to.EnvironmentTO;
import com.framework.to.ProvisionedMachineTO;
import com.framework.utility.DateUtils;

public class ApplicationParameterDAOImpl extends HibernateDaoSupport implements ApplicationParameterDAO {
	
	SoftwareDAO softwareDAO;
	private static final Logger LOG = Logger.getLogger(ApplicationParameterDAOImpl.class);
	
	@Override
	public List<ActivitySoftwareMappingTO> fetchActivitySoftMapDetail(Long selectedSoftwareConfig) throws CMMException {
	
		List<ActivitySoftwareMappingTO> apdTOForY = new ArrayList<ActivitySoftwareMappingTO>();
		try {
			List<ActivitySoftwareMappingTO> apdTO = (List<ActivitySoftwareMappingTO>) getHibernateTemplate().find("from ActivitySoftwareMappingTO where softwareconfigTO.id=?", selectedSoftwareConfig);
			for (ActivitySoftwareMappingTO temp : apdTO) {
				if ("Y".equals(temp.getCaReleaseActivityTO().getApplicationSpecificFlag())) {
					apdTOForY.add(temp);
				}
			}
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationParameterDAOImpl : fetchActivitySoftMapDetail", dae);
		}
		return apdTOForY;
	}
	
	@Override
	public ApplicationProfileMappingTO getApplicationProfileMapId(Long applicationid, Long profileid) throws CMMException {
	
		try {
			return (ApplicationProfileMappingTO) getHibernateTemplate().find("from ApplicationProfileMappingTO where applicationId=? and profileId=?", applicationid, profileid).get(0);
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationParameterDAOImpl : getApplicationProfileMapId", dae);
		}
	}
	
	@Override
	public Long getApplicationProfileDetId(Long selectedProfile, Long selectedSoftware, Long hardwareid, Long servergroup) throws CMMException {
	
		try {
			ApplicationProfileDetailsTO appProDet = (ApplicationProfileDetailsTO) getHibernateTemplate().find("from ApplicationProfileDetailsTO where profileId=? and mappedSoftwareId=? and hardwareId=? and serverGroup=?", selectedProfile, selectedSoftware, hardwareid, servergroup).get(0);
			return appProDet.getId();
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationParameterDAOImpl : getApplicationProfileDetId", dae);
		}
	}
	
	@Override
	public Long submitApplicationParameterDetail(ApplicationParameterTO applicationParameterTO) throws CMMException {
	
		Long saveid = null;
		try {
			for (ApplicationParameterTO form : applicationParameterTO.getApplicationParameterFormList()) {
				ApplicationProfileSoftwareParamertsTO appProSoftTO = new ApplicationProfileSoftwareParamertsTO();
				appProSoftTO.setActivityId(form.getSelActivity());
				appProSoftTO.setPropertyId(form.getSelectedParameter());
				appProSoftTO.setPropertyValue(form.getPropertyValue());
				ApplicationProfileDetailsTO appProDet = new ApplicationProfileDetailsTO();
				appProDet.setId(form.getApplicationProfileDetId());
				appProSoftTO.setApplicationProfileDetails(appProDet);
				appProSoftTO.setApplicationProfileMapId(form.getApplicationProfileMapId());
				Serializable save = getHibernateTemplate().save(appProSoftTO);
				saveid = (Long) save;
			}
		} catch (DataIntegrityViolationException | ConstraintViolationException div) {
			logger.error(div);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : submitApplicationParameterDetail", div);
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : submitApplicationParameterDetail", dae);
		}
		return saveid;
	}
	
	@Override
	public Long editApplicationParameterDetail(ApplicationParameterTO applicationParameterTO) throws CMMException {
	
		Long success = 1L;
		try {
			for (ApplicationParameterTO form : applicationParameterTO.getApplicationParameterDelFormList()) {
				ApplicationProfileSoftwareParamertsTO appProSoftTO = new ApplicationProfileSoftwareParamertsTO();
				appProSoftTO.setActivityId(form.getSelActivity());
				appProSoftTO.setPropertyId(form.getSelectedParameter());
				appProSoftTO.setPropertyValue(form.getPropertyValue());
				appProSoftTO.setId(form.getApplicationProfileSoftwareParameterId());
				ApplicationProfileDetailsTO appProDet = new ApplicationProfileDetailsTO();
				appProDet.setId(form.getApplicationProfileDetId());
				appProSoftTO.setApplicationProfileDetails(appProDet);
				appProSoftTO.setApplicationProfileMapId(form.getApplicationProfileMapId());
				getHibernateTemplate().delete(appProSoftTO);
			}
			for (ApplicationParameterTO form : applicationParameterTO.getApplicationParameterEditFormList()) {
				ApplicationProfileSoftwareParamertsTO appProSoftTO = new ApplicationProfileSoftwareParamertsTO();
				appProSoftTO.setActivityId(form.getSelActivity());
				appProSoftTO.setPropertyId(form.getSelectedParameter());
				appProSoftTO.setPropertyValue(form.getPropertyValue());
				appProSoftTO.setId(form.getApplicationProfileSoftwareParameterId());
				ApplicationProfileDetailsTO appProDet = new ApplicationProfileDetailsTO();
				appProDet.setId(form.getApplicationProfileDetId());
				appProSoftTO.setApplicationProfileDetails(appProDet);
				appProSoftTO.setApplicationProfileMapId(form.getApplicationProfileMapId());
				getHibernateTemplate().save(appProSoftTO);
			}
		} catch (DataIntegrityViolationException | ConstraintViolationException div) {
			logger.error(div);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : editApplicationParameterDetail", div);
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : editApplicationParameterDetail", dae);
		}
		return success;
	}
	
	@Override
	public List<ApplicationProfileSoftwareParamertsTO> checkDetailAlreadyPresent(Long appProfileDetailId, Long appProfileMapId) throws CMMException {
	
		try {
			return (List<ApplicationProfileSoftwareParamertsTO>) getHibernateTemplate().find("from ApplicationProfileSoftwareParamertsTO where applicationProfileDetails.id=? and applicationProfileMapId=?", appProfileDetailId, appProfileMapId);
		} catch (DataIntegrityViolationException | ConstraintViolationException div) {
			logger.error(div);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : checkDetailAlreadyPresent", div);
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : checkDetailAlreadyPresent", dae);
		}
	}
	
	@Override
	public List<NolioProcessParametersTO> getSoftwareProperties(Long softconfigid, Long activityId) throws CMMException {
	
		List<NolioProcessParametersTO> nolioProcessParametersTOs = new ArrayList<NolioProcessParametersTO>();
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(ActivitySoftwareMappingTO.class, "activitysoftware");
			criteria.add(Restrictions.eq("activitysoftware.softwareconfigTO.id", softconfigid));
			criteria.add(Restrictions.eq("activitysoftware.caReleaseActivityTO.activityId", activityId));
			List<ActivitySoftwareMappingTO> activitySoftwareMappingTO = (List<ActivitySoftwareMappingTO>) getHibernateTemplate().findByCriteria(criteria);
			if ((activitySoftwareMappingTO != null) && !activitySoftwareMappingTO.isEmpty()) {
				DetachedCriteria criteria1 = DetachedCriteria.forClass(CAActivityProcessOrderTO.class, "activityProcessOrderTO");
				criteria1.add(Restrictions.eq("activityProcessOrderTO.activitySoftwareMappingTO.activitySoftwareMapId", activitySoftwareMappingTO.get(0).getActivitySoftwareMapId()));
				List<CAActivityProcessOrderTO> activityProcessOrderTO = (List<CAActivityProcessOrderTO>) getHibernateTemplate().findByCriteria(criteria1);
				if ((activityProcessOrderTO != null) && !activityProcessOrderTO.isEmpty()) {
					for (CAActivityProcessOrderTO temp : activityProcessOrderTO) {
						DetachedCriteria criteria2 = DetachedCriteria.forClass(NolioProcessSoftwareMapping.class, "nolioProcessSoftwareMapping");
						criteria2.add(Restrictions.eq("nolioProcessSoftwareMapping.softwareProcessMappingId", temp.getNolioProcessSoftwareMapping().getSoftwareProcessMappingId()));
						List<NolioProcessSoftwareMapping> nolioProcessSoftwareMapping = (List<NolioProcessSoftwareMapping>) getHibernateTemplate().findByCriteria(criteria2);
						for (NolioProcessParametersTO nolioProcessParametersTO : nolioProcessSoftwareMapping.get(0).getNolioProcess().getNolioProcessParameters()) {
							nolioProcessParametersTOs.add(nolioProcessParametersTO);
						}
					}
				}
			}
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationParameterDAOImpl : getSoftwareProperties", dae);
		}
		return nolioProcessParametersTOs;
	}
	
	@Override
	public ProvisionedMachineTO fetchProvisionedMachineName(Long hardwareId) throws CMMException {
	
		try {
			return (ProvisionedMachineTO) getHibernateTemplate().find("from ProvisionedMachineTO where id=?", hardwareId).get(0);
		} catch (DataIntegrityViolationException | ConstraintViolationException div) {
			logger.error(div);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : fetchProvisionedMachineName", div);
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : fetchProvisionedMachineName", dae);
		}
	}
	
	@Override
	public List<ApplicationProfileConfigTO> searchAppProfileConfigDetails(ApplicationParameterTO appParaTo) throws CMMException {
	
		List<ApplicationProfileConfigTO> applicationProfileConfigList = new ArrayList<ApplicationProfileConfigTO>(0);
		List<ApplicationProfileConfigTO> temp1 = new ArrayList<ApplicationProfileConfigTO>(0);
		List<ApplicationProfileConfigTO> temp2 = new ArrayList<ApplicationProfileConfigTO>(0);
		try {
			if (appParaTo.getSelectedSoftware() != null) {
				if (appParaTo.getSelectedSoftware().longValue() >= 1L) {
					List<ApplicationProfileDetailsTO> serverObjList1 = (List<ApplicationProfileDetailsTO>) getHibernateTemplate().find("from ApplicationProfileDetailsTO where id =? ", appParaTo.getSelectedServer());
					if (!serverObjList1.isEmpty()) {
						ApplicationProfileDetailsTO serverObj1 = new ApplicationProfileDetailsTO();
						serverObj1 = serverObjList1.get(0);
						List<ApplicationProfileDetailsTO> serverObjList = (List<ApplicationProfileDetailsTO>) getHibernateTemplate().find("from ApplicationProfileDetailsTO where profileId =? and softwareConfig.id =?  and serverGroup=?", appParaTo.getSelectedApplicationProfile(), appParaTo.getSelectedSoftware(), serverObj1.getServerGroup());
						if (!serverObjList.isEmpty()) {
							ApplicationProfileDetailsTO serverObj = serverObjList.get(0);
							temp2 = (List<ApplicationProfileConfigTO>) getHibernateTemplate().find("from ApplicationProfileConfigTO a where a.softwareConfigId =?  and a.applicationId is null and a.appPrfId=? and a.appPrfDetId=?", appParaTo.getSelectedSoftware(), appParaTo.getSelectedApplicationProfile(), serverObj.getId());
							applicationProfileConfigList = temp2;
						}
					}
				}
			}
			if (appParaTo.getSelectedApplication() != null) {
				if (appParaTo.getSelectedApplication().longValue() >= 1L) {
					temp1 = (List<ApplicationProfileConfigTO>) getHibernateTemplate().find("from ApplicationProfileConfigTO a where  a.applicationId =?", appParaTo.getSelectedApplication());
					applicationProfileConfigList = temp1;
				}
			}
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : searchAppProfileConfigDetails", dae);
		}
		return applicationProfileConfigList;
	}
	
	@Override
	public ApplicationProfileConfigTO searchConfigFile(Long configFileId) throws CMMException {
	
		ApplicationProfileConfigTO appProConfigTo = new ApplicationProfileConfigTO();
		List<ApplicationProfileConfigTO> appProConfigToList = new ArrayList<ApplicationProfileConfigTO>(0);
		try {
			appProConfigToList = (List<ApplicationProfileConfigTO>) getHibernateTemplate().find("from ApplicationProfileConfigTO a where a.id =?", configFileId);
			if (!appProConfigToList.isEmpty()) {
				appProConfigTo = appProConfigToList.get(0);
			}
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : addRelease", dae);
		}
		return appProConfigTo;
	}
	
	@Override
	public ApplicationProfileConfigTO searchIfTemplateFileExist(Long configFileId) throws CMMException {
	
		ApplicationProfileConfigTO appProConfigTo = new ApplicationProfileConfigTO();
		try {
			List<ApplicationProfileConfigTO> temp = (List<ApplicationProfileConfigTO>) getHibernateTemplate().find("from ApplicationProfileConfigTO a where a.id =?", configFileId);
			if (!temp.isEmpty()) {
				appProConfigTo.setTemplateFile(temp.get(0).getTemplateFile());
			}
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : addRelease", dae);
		}
		return appProConfigTo;
	}
	
	@Override
	public ApplicationProfileConfigTO searchTemplateFile(Long configFileId) throws CMMException {
	
		ApplicationProfileConfigTO appProConfigTo = new ApplicationProfileConfigTO();
		try {
			List<Object[]> temp = (List<Object[]>) getHibernateTemplate().find("select a.id, a.templateFile, a.fileName, a.configFile, a.paramString, a.originalLineString, a.appPrfId, a.appPrfDetId, a.softwareConfigId, a.applicationId from ApplicationProfileConfigTO a where a.id =?", configFileId);
			for (Object[] obj : temp) {
				if ((Blob) obj[1] == null) {
					appProConfigTo.setTemplateFile((Blob) obj[3]);
				} else {
					appProConfigTo.setTemplateFile((Blob) obj[1]);
					appProConfigTo.setParamString((String) obj[4]);
					appProConfigTo.setOriginalLineString((String) obj[5]);
				}
				appProConfigTo.setFileName(obj[2].toString());
				appProConfigTo.setAppPrfId((Long) obj[6]);
				appProConfigTo.setAppPrfDetId((Long) obj[7]);
				appProConfigTo.setSoftwareConfigId((Long) obj[8]);
				appProConfigTo.setApplicationId((Long) obj[9]);
			}
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : addRelease", dae);
		}
		return appProConfigTo;
	}
	
	@Override
	public void deleteConfigFile(Long configFileId) throws CMMException {
	
		ApplicationProfileConfigTO appProConfigTo = new ApplicationProfileConfigTO();
		try {
			List<ApplicationProfileConfigParamsTO> appPrfConfigParamList = (List<ApplicationProfileConfigParamsTO>) getHibernateTemplate().find("from ApplicationProfileConfigParamsTO where appPrfConfigId=?", configFileId);
			for (ApplicationProfileConfigParamsTO appPrfConfig : appPrfConfigParamList) {
				List<ApplicationProfileConfigParamTmpltMappingTO> appPrfConfigParamTmpltList = (List<ApplicationProfileConfigParamTmpltMappingTO>) getHibernateTemplate().find("from ApplicationProfileConfigParamTmpltMappingTO where appPrfConfigParamsId=?", appPrfConfig.getId());
				for (ApplicationProfileConfigParamTmpltMappingTO appPrfConfigParamTmplt : appPrfConfigParamTmpltList) {
					getHibernateTemplate().delete(appPrfConfigParamTmplt);
				}
				getHibernateTemplate().delete(appPrfConfig);
			}
			appProConfigTo.setId(configFileId);
			getHibernateTemplate().delete(appProConfigTo);
		} catch (DataIntegrityViolationException | ConstraintViolationException div) {
			logger.error(div);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : addRelease", div);
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : addRelease", dae);
		}
	}
	
	@Override
	public void deleteTemplateFile(Long configFileId, Long userId) throws CMMException {
	
		ApplicationProfileConfigTO app = new ApplicationProfileConfigTO();
		List<ApplicationProfileConfigTO> appList = new ArrayList<ApplicationProfileConfigTO>(0);
		try {
			appList = (List<ApplicationProfileConfigTO>) getHibernateTemplate().find("from ApplicationProfileConfigTO a where a.id =?", configFileId);
			if (!appList.isEmpty()) {
				app = appList.get(0);
				app.setTemplateFile(null);
				app.setModifiedbyId(userId);
				app.setModifiedbyDate(DateUtils.getStartTime(new Date()));
				getHibernateTemplate().update(app);
			}
			List<ApplicationProfileConfigParamsTO> appPrfConfigParamList = new ArrayList<ApplicationProfileConfigParamsTO>(0);
			appPrfConfigParamList = (List<ApplicationProfileConfigParamsTO>) getHibernateTemplate().find("from ApplicationProfileConfigParamsTO where appPrfConfigId=?", configFileId);
			for (ApplicationProfileConfigParamsTO appPrfConfig : appPrfConfigParamList) {
				List<ApplicationProfileConfigParamTmpltMappingTO> appPrfConfigParamTmpltList = (List<ApplicationProfileConfigParamTmpltMappingTO>) getHibernateTemplate().find("from ApplicationProfileConfigParamTmpltMappingTO where appPrfConfigParamsId=?", appPrfConfig.getId());
				for (ApplicationProfileConfigParamTmpltMappingTO appPrfConfigParamTmplt : appPrfConfigParamTmpltList) {
					getHibernateTemplate().delete(appPrfConfigParamTmplt);
				}
				getHibernateTemplate().delete(appPrfConfig);
			}
		} catch (DataIntegrityViolationException | ConstraintViolationException div) {
			logger.error(div);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : addRelease", div);
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : addRelease", dae);
		}
	}
	
	@Override
	public List<ApplicationProfileDetailsTO> getselectedIPAddress(Long selectedProfile, Long selectedServer) throws CMMException {
	
		List<ApplicationProfileDetailsTO> appProDetList = new ArrayList<ApplicationProfileDetailsTO>(0);
		try {
			List<Object[]> serverGps = (List<Object[]>) getHibernateTemplate().find("select distinct serverGroup, serverName from ApplicationProfileDetailsTO where id =?", selectedServer);
			for (Object[] obj : serverGps) {
				ApplicationProfileDetailsTO appProDetObj = new ApplicationProfileDetailsTO();
				appProDetObj.setServerGroup((Long) obj[0]);
				appProDetObj.setServerGroupNumber((String) obj[1]);
				appProDetList.add(appProDetObj);
			}
		} catch (Exception he) {
			logger.error(he);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : addRelease", he);
		}
		return appProDetList;
	}
	
	@Override
	public List<NolioProcessParametersTO> fetchSoftwareParameter(Long selectedSoftware) throws CMMException {
	
		List<ApplicationProfileDetailsTO> appProDetList = (List<ApplicationProfileDetailsTO>) getHibernateTemplate().find("from ApplicationProfileDetailsTO where mappedSoftwareId =?", selectedSoftware);
		List<NolioProcessParametersTO> parameterList = new ArrayList<NolioProcessParametersTO>(0);
		if (!appProDetList.isEmpty()) {
			ApplicationProfileDetailsTO appProDet = appProDetList.get(0);
			parameterList = softwareDAO.getSoftwareProperties(appProDet.getMappedSoftwareId());
		}
		return parameterList;
	}
	
	public SoftwareDAO getSoftwareDAO() {
	
		return softwareDAO;
	}
	
	public void setSoftwareDAO(SoftwareDAO softwareDAO) {
	
		this.softwareDAO = softwareDAO;
	}
	
	@Override
	public ApplicationParameterTO loadParameter(Long configFileId, Long selectedProfile, Long selectedApplication) throws CMMException {
	
		try {
			ApplicationParameterTO applicationParameterTO = new ApplicationParameterTO();
			List<EnvironmentTO> envToList = new ArrayList<EnvironmentTO>(0);
			EnvironmentTO env = new EnvironmentTO();
			List<EnvironmentApplicationTO> envAppToList = new ArrayList<EnvironmentApplicationTO>(0);
			if (selectedApplication != null) {
				if (selectedApplication > 0L) {
					envAppToList = (List<EnvironmentApplicationTO>) getHibernateTemplate().find("from EnvironmentApplicationTO where applicationTO.id =?", selectedApplication);
				}
			}
			if ((selectedProfile != null) && (selectedProfile > 0)) {
				List<EnvironmentTO> environments = (List<EnvironmentTO>) getHibernateTemplate().find("from EnvironmentTO where profileId =?", selectedProfile);
				for (EnvironmentTO envObj : environments) {
					EnvironmentApplicationTO envApp = new EnvironmentApplicationTO();
					envApp.setEnvironmentTO(envObj);
					envAppToList.add(envApp);
				}
			}
			env.setEnvironmentName("Parameter Name");
			envToList.add(env);
			env = new EnvironmentTO();
			env.setEnvironmentName("All");
			envToList.add(env);
			for (EnvironmentApplicationTO envApp : envAppToList) {
				envToList.add(envApp.getEnvironmentTO());
			}
			List<ApplicationProfileConfigParamsTO> appPrfConfigParamsList2 = (List<ApplicationProfileConfigParamsTO>) getHibernateTemplate().find("from ApplicationProfileConfigParamsTO where appPrfConfigId =?", configFileId);
			List<ApplicationProfileConfigParamsTO> appPrfConfigParamsList = new ArrayList<ApplicationProfileConfigParamsTO>(0);
			List<String> paramList = new ArrayList<String>(0);
			boolean duplicateParam;
			for (ApplicationProfileConfigParamsTO appPrf : appPrfConfigParamsList2) {
				paramList.add(appPrf.getParamName());
			}
			for (ApplicationProfileConfigParamsTO appPrf : appPrfConfigParamsList2) {
				duplicateParam = false;
				for (ApplicationProfileConfigParamsTO param : appPrfConfigParamsList) {
					if (appPrf.getParamName().equalsIgnoreCase(param.getParamName())) {
						duplicateParam = true;
						break;
					}
				}
				if (!duplicateParam) {
					appPrfConfigParamsList.add(appPrf);
				}
			}
			List<ApplicationProfileConfigTO> appPrfConfigList = (List<ApplicationProfileConfigTO>) getHibernateTemplate().find("from ApplicationProfileConfigTO where id =?", configFileId);
			if (appPrfConfigList.size() > 0L) {
				applicationParameterTO.setConfigFileName(appPrfConfigList.get(0).getFileName());
			}
			for (ApplicationProfileConfigParamsTO app : appPrfConfigParamsList) {
				List<ApplicationProfileConfigParamsTO> appPrfConfigParamsList1 = new ArrayList<ApplicationProfileConfigParamsTO>(0);
				for (int envcount = 1; envcount < envToList.size(); envcount++) {
					ApplicationProfileConfigParamsTO appPro = new ApplicationProfileConfigParamsTO();
					appPro.setEnvironmentId(envToList.get(envcount - 0).getId());
					if (envcount == 1L) {
						appPro.setFlag(true);
						appPro.setFlagStr("show");
					}
					ApplicationProfileConfigParamTmpltMappingTO appProConfig = new ApplicationProfileConfigParamTmpltMappingTO();
					List<ApplicationProfileConfigParamTmpltMappingTO> appProConfig1 = null;
					if (appPro.getEnvironmentId() == null) {
						appProConfig1 = (List<ApplicationProfileConfigParamTmpltMappingTO>) getHibernateTemplate().find("from ApplicationProfileConfigParamTmpltMappingTO where appPrfConfigId =? and appPrfConfigParamsId =? and environmentId is NULL", app.getAppPrfConfigId(), app.getId());
						if (!appProConfig1.isEmpty()) {
							appProConfig = appProConfig1.get(0);
						}
						appPro.setParameterValue(appProConfig.getParamValue());
					} else {
						appProConfig1 = (List<ApplicationProfileConfigParamTmpltMappingTO>) getHibernateTemplate().find("from ApplicationProfileConfigParamTmpltMappingTO where appPrfConfigId =? and appPrfConfigParamsId =? and environmentId =?", app.getAppPrfConfigId(), app.getId(), appPro.getEnvironmentId());
						if (!appProConfig1.isEmpty()) {
							appProConfig = appProConfig1.get(0);
						}
						appPro.setParameterValue(appProConfig.getParamValue());
					}
					appPrfConfigParamsList1.add(appPro);
				}
				app.setParameterValueList(appPrfConfigParamsList1);
			}
			applicationParameterTO.setAppPrfConfigParamsList(appPrfConfigParamsList);
			applicationParameterTO.setEnvironmentList(envToList);
			return applicationParameterTO;
		} catch (Exception he) {
			logger.error(he);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : addRelease", he);
		}
	}
	
	@Override
	public ApplicationParameterTO fetchParameterForInvMgmt(Long configFileId, Long environmentId) throws CMMException {
	
		Session session = getSession();
		ApplicationParameterTO applicationParameterTO = new ApplicationParameterTO();
		applicationParameterTO.setAppPrfConfigParamsList(new ArrayList<ApplicationProfileConfigParamsTO>());
		try {
			String query = "select cp.param_name , cp.default_value , ptm.param_value from app_prf_conf_param_tmplt_map  ptm , app_prf_config_params cp  where  ptm.app_prf_config_params_id = cp.id and ptm.environment_id =? and cp.app_prf_config_id=?";
			SQLQuery sqlQuery = session.createSQLQuery(query);
			sqlQuery.setParameter(0, environmentId);
			sqlQuery.setParameter(1, configFileId);
			List<Object[]> obj = sqlQuery.list();
			for (Object[] temp : obj) {
				ApplicationProfileConfigParamsTO appConfigTO = new ApplicationProfileConfigParamsTO();
				appConfigTO.setParamName((String) temp[0]);
				appConfigTO.setDefaultValue((String) temp[1]);
				appConfigTO.setParameterValue((String) temp[2]);
				applicationParameterTO.getAppPrfConfigParamsList().add(appConfigTO);
			}
		} catch (Exception he) {
			logger.error(he);
			throw new CMMException("Problem encountered. ApplicationParameterDAOImpl : fetchParameterForInvMgmt", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return applicationParameterTO;
	}
	
	@Override
	public void saveParameter(ApplicationParameterTO applicationParameterTO) throws CMMException {
	
		try {
			List<ApplicationProfileConfigParamTmpltMappingTO> appProfConfigMapList = (List<ApplicationProfileConfigParamTmpltMappingTO>) getHibernateTemplate().find("from ApplicationProfileConfigParamTmpltMappingTO where appPrfConfigId =?", applicationParameterTO.getConfigFileId());
			if (!appProfConfigMapList.isEmpty()) {
				for (ApplicationProfileConfigParamsTO appPro : applicationParameterTO.getAppPrfConfigParamsList()) {
					if (appPro.getParameterValueList().get(0).isAccess()) {
						List<ApplicationProfileConfigParamTmpltMappingTO> appProfConfigMapList1 = new ArrayList<ApplicationProfileConfigParamTmpltMappingTO>(0);
						appProfConfigMapList1 = (List<ApplicationProfileConfigParamTmpltMappingTO>) getHibernateTemplate().find("from ApplicationProfileConfigParamTmpltMappingTO where appPrfConfigId =? and appPrfConfigParamsId =?", applicationParameterTO.getConfigFileId(), appPro.getId());
						if (!appProfConfigMapList1.isEmpty()) {
							if ((appProfConfigMapList1.size() == 1L) && (appProfConfigMapList1.get(0).getEnvironmentId() == null)) {
								ApplicationProfileConfigParamTmpltMappingTO appProConf1 = new ApplicationProfileConfigParamTmpltMappingTO();
								appProConf1 = appProfConfigMapList1.get(0);
								appProConf1.setParamValue(appPro.getParameterValueList().get(0).getParameterValue());
								appProConf1.setModifiedbyId(applicationParameterTO.getUserId());
								appProConf1.setModifiedbyDate(DateUtils.getStartTime(new Date()));
								getHibernateTemplate().update(appProConf1);
							} else {
								for (ApplicationProfileConfigParamTmpltMappingTO appProConf : appProfConfigMapList1) {
									getHibernateTemplate().delete(appProConf);
								}
								for (ApplicationProfileConfigParamsTO parameter : appPro.getParameterValueList()) {
									if (parameter.getEnvironmentId() == null) {
										ApplicationProfileConfigParamTmpltMappingTO appProConf1 = new ApplicationProfileConfigParamTmpltMappingTO();
										appProConf1.setAppPrfConfigId(appPro.getAppPrfConfigId());
										appProConf1.setAppPrfConfigParamsId(appPro.getId());
										appProConf1.setEnvironmentId(parameter.getEnvironmentId());
										appProConf1.setParamValue(parameter.getParameterValue());
										appProConf1.setCreatedById(applicationParameterTO.getUserId());
										appProConf1.setCreatedByDate(DateUtils.getStartTime(new Date()));
										getHibernateTemplate().save(appProConf1);
									}
								}
							}
						}
					} else {
						List<ApplicationProfileConfigParamTmpltMappingTO> appProfConfigMapList1 = new ArrayList<ApplicationProfileConfigParamTmpltMappingTO>(0);
						appProfConfigMapList1 = (List<ApplicationProfileConfigParamTmpltMappingTO>) getHibernateTemplate().find("from ApplicationProfileConfigParamTmpltMappingTO where appPrfConfigId =? and appPrfConfigParamsId =?", applicationParameterTO.getConfigFileId(), appPro.getId());
						if (!appProfConfigMapList1.isEmpty()) {
							if ((appProfConfigMapList1.size() == 1L) && (appProfConfigMapList1.get(0).getEnvironmentId() == null)) {
								getHibernateTemplate().delete(appProfConfigMapList1.get(0));
								for (ApplicationProfileConfigParamsTO parameter : appPro.getParameterValueList()) {
									if (parameter.getEnvironmentId() != null) {
										ApplicationProfileConfigParamTmpltMappingTO appProConf1 = new ApplicationProfileConfigParamTmpltMappingTO();
										appProConf1.setAppPrfConfigId(appPro.getAppPrfConfigId());
										appProConf1.setAppPrfConfigParamsId(appPro.getId());
										appProConf1.setEnvironmentId(parameter.getEnvironmentId());
										appProConf1.setParamValue(parameter.getParameterValue());
										appProConf1.setCreatedById(applicationParameterTO.getUserId());
										appProConf1.setCreatedByDate(DateUtils.getStartTime(new Date()));
										getHibernateTemplate().save(appProConf1);
									}
								}
							} else {
								for (ApplicationProfileConfigParamTmpltMappingTO appProConf : appProfConfigMapList1) {
									for (ApplicationProfileConfigParamsTO parameter : appPro.getParameterValueList()) {
										if (appProConf.getEnvironmentId().equals(parameter.getEnvironmentId())) {
											appProConf.setParamValue(parameter.getParameterValue());
											getHibernateTemplate().update(appProConf);
										}
									}
								}
							}
						}
					}
				}
			} else {
				for (ApplicationProfileConfigParamsTO appPro : applicationParameterTO.getAppPrfConfigParamsList()) {
					ApplicationProfileConfigParamTmpltMappingTO appProParamTmp = new ApplicationProfileConfigParamTmpltMappingTO();
					for (ApplicationProfileConfigParamsTO parameter : appPro.getParameterValueList()) {
						if (parameter.isAccess()) {
							appProParamTmp.setAppPrfConfigId(appPro.getAppPrfConfigId());
							appProParamTmp.setAppPrfConfigParamsId(appPro.getId());
							appProParamTmp.setEnvironmentId(null);
							appProParamTmp.setParamValue(parameter.getParameterValue());
							appProParamTmp.setCreatedById(applicationParameterTO.getUserId());
							appProParamTmp.setCreatedByDate(DateUtils.getStartTime(new Date()));
							getHibernateTemplate().save(appProParamTmp);
							break;
						} else if (parameter.getEnvironmentId() != null) {
							appProParamTmp.setAppPrfConfigId(appPro.getAppPrfConfigId());
							appProParamTmp.setAppPrfConfigParamsId(appPro.getId());
							appProParamTmp.setEnvironmentId(parameter.getEnvironmentId());
							appProParamTmp.setParamValue(parameter.getParameterValue());
							appProParamTmp.setCreatedById(applicationParameterTO.getUserId());
							appProParamTmp.setCreatedByDate(DateUtils.getStartTime(new Date()));
							getHibernateTemplate().save(appProParamTmp);
						}
					}
				}
			}
		} catch (Exception he) {
			logger.error(he);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : addRelease", he);
		}
	}
	
	@Override
	public void saveGoldToConfigTemplate(Blob templateFileForConfigFile, Long configFileId, Long userId, String paramString, String originalLine) throws CMMException {
	
		List<ApplicationProfileConfigTO> appList = new ArrayList<ApplicationProfileConfigTO>(0);
		ApplicationProfileConfigTO app = new ApplicationProfileConfigTO();
		try {
			appList = (List<ApplicationProfileConfigTO>) getHibernateTemplate().find("from ApplicationProfileConfigTO a where a.id =?", configFileId);
			if (!appList.isEmpty()) {
				app = appList.get(0);
				app.setTemplateFile(templateFileForConfigFile);
				app.setModifiedbyId(userId);
				app.setModifiedbyDate(DateUtils.getStartTime(new Date()));
				app.setParamString(paramString);
				app.setOriginalLineString(originalLine);
				getHibernateTemplate().update(app);
			}
		} catch (DataIntegrityViolationException div) {
			logger.error(div);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : addRelease", div);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : addRelease", dae);
		} catch (ConstraintViolationException e) {
			logger.error(e);
			throw new CMMException("User Name already exists. ApplicationReleaseDAOImpl : addRelease", e);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : addRelease", he);
		}
	}
	
	@Override
	public List<ApplicationProfileConfigTO> getTemplateFilesForApplication(Long appId, Long selectedProfile, Long softwareConfigId, Long serverGroup) throws CMMException {
	
		List<ApplicationProfileConfigTO> appProConfigToList = new ArrayList<ApplicationProfileConfigTO>(0);
		List<Object[]> temp = new ArrayList<Object[]>(0);
		try {
			List<ApplicationProfileDetailsTO> appPrfDet = (List<ApplicationProfileDetailsTO>) getHibernateTemplate().find("from ApplicationProfileDetailsTO a where profileId =? and mappedSoftwareId =? and serverGroup=?", selectedProfile, softwareConfigId, serverGroup);
			Long appPrfDetId = null;
			if (!appPrfDet.isEmpty()) {
				appPrfDetId = appPrfDet.get(0).getId();
			}
			if ((appId != null) && (appId > 0L)) {
				temp = (List<Object[]>) getHibernateTemplate().find("select a.id, a.templateFile, a.fileName, a.fileTargetPath, a.appPrfId, a.configFile from ApplicationProfileConfigTO a where applicationId =? ", appId);
			} else {
				temp = (List<Object[]>) getHibernateTemplate().find("select a.id, a.templateFile, a.fileName, a.fileTargetPath, a.appPrfId, a.configFile from ApplicationProfileConfigTO a where applicationId is null and appPrfId =? and softwareConfigId =? and appPrfDetId=?", selectedProfile, softwareConfigId, appPrfDetId);
			}
			for (Object[] obj : temp) {
				ApplicationProfileConfigTO appProConfigTo = new ApplicationProfileConfigTO();
				appProConfigTo.setId((Long) obj[0]);
				appProConfigTo.setTemplateFile((Blob) obj[1]);
				appProConfigTo.setFileName(obj[2].toString());
				appProConfigTo.setFileTargetPath(obj[3].toString());
				appProConfigTo.setAppPrfId((Long) obj[4]);
				appProConfigTo.setConfigFile((Blob) obj[5]);
				appProConfigToList.add(appProConfigTo);
			}
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : addRelease", dae);
		}
		return appProConfigToList;
	}
	
	@Override
	public List<ApplicationProfileConfigParamsTO> fetchParameterList(Long configFileId) throws CMMException {
	
		return (List<ApplicationProfileConfigParamsTO>) getHibernateTemplate().find("select from ApplicationProfileConfigParamsTO where appPrfConfigId =?", configFileId);
	}
	
	@Override
	public ApplicationProfileConfigParamTmpltMappingTO fetchParameterList(Long configFileId, Long parameterId, Long envId) throws CMMException {
	
		ApplicationProfileConfigParamTmpltMappingTO appPrfTmplMap = new ApplicationProfileConfigParamTmpltMappingTO();
		List<ApplicationProfileConfigParamTmpltMappingTO> appProfConfigParamList = (List<ApplicationProfileConfigParamTmpltMappingTO>) getHibernateTemplate().find("select from ApplicationProfileConfigParamsTO where appPrfConfigId =? and appPrfConfigParamsId =? ", configFileId, parameterId);
		if (!appProfConfigParamList.isEmpty()) {
			if (appProfConfigParamList.size() == 1L) {
				if (appProfConfigParamList.get(0).getEnvironmentId() == null) {
					appPrfTmplMap = appProfConfigParamList.get(0);
				}
			} else {
				for (ApplicationProfileConfigParamTmpltMappingTO appProfileConfigParamTmpltMappingTO : appProfConfigParamList) {
					if (appProfileConfigParamTmpltMappingTO.getEnvironmentId().longValue() == envId.longValue()) {
						appPrfTmplMap = appProfileConfigParamTmpltMappingTO;
					}
				}
			}
		}
		return appPrfTmplMap;
	}
	
	@Override
	public String findNolioProcessParameterValue(Long nolioProcessParameterId, Long serverNumber, Long softwareConfigId, Long selectedProfile) throws CMMException {
	
		String nolioProcessParameter = "";
		Long applicationProfileDetId = null;
		try {
			List<ApplicationProfileDetailsTO> appPrfDetList = (List<ApplicationProfileDetailsTO>) getHibernateTemplate().find("from ApplicationProfileDetailsTO where profileId =? and serverGroup =? and mappedSoftwareId =? ", selectedProfile, serverNumber, softwareConfigId);
			if (!appPrfDetList.isEmpty()) {
				applicationProfileDetId = appPrfDetList.get(0).getId();
			}
			List<ApplicationProfileSoftwareParamertsTO> appPrfSoftList = (List<ApplicationProfileSoftwareParamertsTO>) getHibernateTemplate().find("from ApplicationProfileSoftwareParamertsTO where propertyId =? and applicationProfileDetails.id =?", nolioProcessParameterId, applicationProfileDetId);
			if (!appPrfSoftList.isEmpty()) {
				nolioProcessParameter = appPrfSoftList.get(0).getPropertyValue();
			}
		} catch (Exception e) {
			throw new CMMException("Exception occurred in selectedIPAddresses ", e);
		}
		return nolioProcessParameter;
	}
	
	@Override
	public String findUserDefinedParameterValue(String param, Long appPrfConfigId, Long envId, Long userDefinedParameterCount) throws CMMException {
	
		String paramValue;
		try {
			List<ApplicationProfileConfigParamsTO> appPrfConfigParamList = (List<ApplicationProfileConfigParamsTO>) getHibernateTemplate().find("from ApplicationProfileConfigParamsTO where appPrfConfigId =? and paramName =?", appPrfConfigId, param);
			List<ApplicationProfileConfigParamTmpltMappingTO> appPrfConfigParamTmplt1 = (List<ApplicationProfileConfigParamTmpltMappingTO>) getHibernateTemplate().find("from ApplicationProfileConfigParamTmpltMappingTO where appPrfConfigParamsId =?", appPrfConfigParamList.get(0).getId());
			if (appPrfConfigParamTmplt1.size() > 0L) {
				if (appPrfConfigParamTmplt1.size() == 1L) {
					if (appPrfConfigParamTmplt1.get(0).getEnvironmentId() == null) {
						paramValue = appPrfConfigParamTmplt1.get(0).getParamValue();
					} else {
						List<ApplicationProfileConfigParamTmpltMappingTO> appPrfConfigParamTmplt2 = (List<ApplicationProfileConfigParamTmpltMappingTO>) getHibernateTemplate().find("from ApplicationProfileConfigParamTmpltMappingTO where appPrfConfigParamsId =? and environmentId =?", appPrfConfigParamList.get(0).getId(), envId);
						if (appPrfConfigParamTmplt2.size() > 0L) {
							paramValue = appPrfConfigParamTmplt2.get(0).getParamValue();
						} else {
							paramValue = appPrfConfigParamList.get(0).getDefaultValue();
						}
					}
				} else {
					List<ApplicationProfileConfigParamTmpltMappingTO> appPrfConfigParamTmplt3 = (List<ApplicationProfileConfigParamTmpltMappingTO>) getHibernateTemplate().find("from ApplicationProfileConfigParamTmpltMappingTO where appPrfConfigParamsId =? and environmentId =?", appPrfConfigParamList.get(0).getId(), envId);
					if (appPrfConfigParamTmplt3.size() > 0L) {
						paramValue = appPrfConfigParamTmplt3.get(0).getParamValue();
					} else {
						paramValue = appPrfConfigParamList.get(0).getDefaultValue();
					}
				}
			} else {
				paramValue = appPrfConfigParamList.get(0).getDefaultValue();
			}
		} catch (Exception he) {
			logger.error(he);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : addRelease", he);
		}
		return paramValue;
	}
	
	@Override
	public boolean saveConfigurationFile(ApplicationProfileConfigTO appProToObj) throws CMMException {
	
		int count = 0;
		FileReader fileReader = null;
		BufferedReader br = null;
		try {
			for (File file : appProToObj.getFiles()) {
				file.getAbsolutePath();
				appProToObj.setFileName(appProToObj.getFilesFileName().get(count));
				appProToObj.setApplicationId(appProToObj.getApplicationId());
				if (appProToObj.getSelectedLocation().longValue() != 1L) {
					String line;
					String fileStr = "";
					fileReader = new FileReader(file.getPath());
					br = new BufferedReader(fileReader);
					while (true) {
						line = br.readLine();
						if (line == null) {
							break;
						}
						fileStr = fileStr + line;
						fileStr = fileStr + "\r\n";
					}
					byte[] configFileByt = fileStr.getBytes();
					Blob configFile = new SerialBlob(configFileByt);
					appProToObj.setConfigFile(configFile);
				} else {
					appProToObj.setConfigFile(appProToObj.getConfigFileList().get(count));
				}
				count++;
				getHibernateTemplate().save(appProToObj);
				if (fileReader != null) {
					closeUp(fileReader);
				}
			}
			return true;
		} catch (Exception div) {
			logger.error(div);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : addRelease", div);
		} finally {
			if (br != null) {
				closeUp(br);
			}
			if (fileReader != null) {
				closeUp(fileReader);
			}
		}
	}
	
	@Override
	public boolean saveParamsForTemplateFile(List<ApplicationProfileConfigParamsTO> appProfConfigParamList, Long configFileId) throws CMMException {
	
		try {
			List<ApplicationProfileConfigParamsTO> appPrfConfigParamList = (List<ApplicationProfileConfigParamsTO>) getHibernateTemplate().find("from ApplicationProfileConfigParamsTO where appPrfConfigId =? ", configFileId);
			for (ApplicationProfileConfigParamsTO appPrfConfigPar : appPrfConfigParamList) {
				List<ApplicationProfileConfigParamTmpltMappingTO> appPrfConfigParamTmpltList = (List<ApplicationProfileConfigParamTmpltMappingTO>) getHibernateTemplate().find("from ApplicationProfileConfigParamTmpltMappingTO where appPrfConfigParamsId =? ", appPrfConfigPar.getId());
				for (ApplicationProfileConfigParamTmpltMappingTO appPrfTmplt : appPrfConfigParamTmpltList) {
					getHibernateTemplate().delete(appPrfTmplt);
				}
			}
			for (ApplicationProfileConfigParamsTO appPrfConfigPar : appPrfConfigParamList) {
				getHibernateTemplate().delete(appPrfConfigPar);
			}
			for (ApplicationProfileConfigParamsTO appPrfConfigParam : appProfConfigParamList) {
				ApplicationProfileConfigParamsTO appPrfConfigParamObj = new ApplicationProfileConfigParamsTO();
				appPrfConfigParamObj.setAppPrfConfigId(appPrfConfigParam.getAppPrfConfigId());
				appPrfConfigParamObj.setParamName(appPrfConfigParam.getParamName());
				appPrfConfigParamObj.setDefaultValue(appPrfConfigParam.getDefaultValue());
				appPrfConfigParamObj.setParamHintLine(appPrfConfigParam.getParamHintLine());
				appPrfConfigParamObj.setAppPrfConfigId(appPrfConfigParam.getAppPrfConfigId());
				appPrfConfigParamObj.setCreatedById(appPrfConfigParam.getCreatedById());
				appPrfConfigParamObj.setCreatedByDate(appPrfConfigParam.getCreatedByDate());
				getHibernateTemplate().save(appPrfConfigParamObj);
			}
			return true;
		} catch (Exception div) {
			logger.error(div);
			throw new CMMException("Problem encountered. ApplicationReleaseDAOImpl : addRelease", div);
		}
	}
	
	@Override
	public List<ApplicationProfileConfigTO> fetchConfigFileNames(Long selectedSoftware, Long selectedApplication, Long selectedServer) throws CMMException {
	
		List<ApplicationProfileConfigTO> configFileNames = new ArrayList<ApplicationProfileConfigTO>(0);
		try {
			if ((selectedSoftware == null) || (selectedSoftware <= 0L)) {
				configFileNames = (List<ApplicationProfileConfigTO>) getHibernateTemplate().find("from ApplicationProfileConfigTO where  applicationId =? ", selectedApplication);
			} else {
				ApplicationProfileDetailsTO appPrf = new ApplicationProfileDetailsTO();
				List<ApplicationProfileDetailsTO> appProDetList = (List<ApplicationProfileDetailsTO>) getHibernateTemplate().find("from ApplicationProfileDetailsTO where id =? ", selectedServer);
				if (!appProDetList.isEmpty()) {
					Long serverGroup = appProDetList.get(0).getServerGroup();
					List<ApplicationProfileDetailsTO> appProDetList1 = (List<ApplicationProfileDetailsTO>) getHibernateTemplate().find("from ApplicationProfileDetailsTO where profileId =? and serverGroup =? and softwareConfig.id=?", appProDetList.get(0).getProfileId(), serverGroup, selectedSoftware);
					if (!appProDetList1.isEmpty()) {
						appPrf = appProDetList1.get(0);
						configFileNames = (List<ApplicationProfileConfigTO>) getHibernateTemplate().find("from ApplicationProfileConfigTO where softwareConfigId =? and applicationId is null and appPrfDetId=? ", selectedSoftware, appPrf.getId());
					}
				}
			}
		} catch (Exception e) {
			logger.error("ApplicationParameterDAOImpl:fetchConfigFileNames", e);
			throw new CMMException("Error in fetching  details ", e);
		}
		return configFileNames;
	}
	
	@Override
	public boolean editFileTargetPathForAP(Long configFileId, String fileTargetPath) throws CMMException {
	
		try {
			ApplicationProfileConfigTO configFile = (ApplicationProfileConfigTO) getHibernateTemplate().find("from ApplicationProfileConfigTO where id =? ", configFileId).get(0);
			configFile.setFileTargetPath(fileTargetPath);
			getHibernateTemplate().update(configFile);
			return true;
		} catch (Exception e) {
			logger.error("ApplicationParameterDAOImpl:editFileTargetPathForAP", e);
			return false;
		}
	}
	
	@Override
	public List<ApplicationProfileDetailsTO> getFriendlyServerList(Long selectedApplication) throws CMMException {
	
		Session session = getSession();
		List<ApplicationProfileDetailsTO> appProList = new ArrayList<ApplicationProfileDetailsTO>(0);
		try {
			String hql = "select  b.id,  b.serverName, b.serverGroup from ApplicationProfileMappingTO a , ApplicationProfileDetailsTO b where a.profileId = b.profileId and a.applicationId=:selectedApplication  group by b.serverGroup , b.serverName";
			Query q = session.createQuery(hql);
			q.setParameter("selectedApplication", selectedApplication);
			List<Object[]> obj = q.list();
			for (Object[] temp : obj) {
				ApplicationProfileDetailsTO appProTO = new ApplicationProfileDetailsTO();
				appProTO.setId((Long) temp[0]);
				appProTO.setName((String) temp[1]);
				appProList.add(appProTO);
			}
		} catch (DataAccessException dae) {
			throw new CMMException("Error in fetching  details ", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. getFriendlyServerList : addRelease", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return appProList;
	}
	
	@Override
	public List<ApplicationProfileDetailsTO> getSoftwareListforFriendlyServerName(Long selServer) throws CMMException {
	
		try {
			String hql = String.format("select a from ApplicationProfileDetailsTO a where a.id =%d ", selServer);
			List<ApplicationProfileDetailsTO> softwareList = new ArrayList<ApplicationProfileDetailsTO>(0);
			List<ApplicationProfileDetailsTO> appProDetList = (List<ApplicationProfileDetailsTO>) getHibernateTemplate().find(hql);
			if (!appProDetList.isEmpty()) {
				List<ApplicationProfileDetailsTO> appProDetList1 = (List<ApplicationProfileDetailsTO>) getHibernateTemplate().find("from ApplicationProfileDetailsTO where profileId =? and serverGroup =?", appProDetList.get(0).getProfileId(), appProDetList.get(0).getServerGroup());
				for (ApplicationProfileDetailsTO appProfile : appProDetList1) {
					ApplicationProfileDetailsTO appPro = new ApplicationProfileDetailsTO();
					appPro.setId(appProfile.getSoftwareConfig().getId());
					appPro.setName(appProfile.getSoftwareConfig().getSoftware().getName());
					softwareList.add(appPro);
				}
			}
			return softwareList;
		} catch (DataAccessException dae) {
			throw new CMMException("Error in fetching  details ", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. ApplicationParameterDAOImpl : getSoftwareListforFriendlyServerName", he);
		}
	}
	
	@Override
	public String findServerParameterValue(String param, Long appPrfId, Long envId) throws CMMException {
	
		param.split(" ");
		String serverIp = null;
		try {
			List<ApplicationProfileDetailsTO> serverObjList = (List<ApplicationProfileDetailsTO>) getHibernateTemplate().find("from ApplicationProfileDetailsTO where profileId =? and serverName =? ", appPrfId, param);
			if (!serverObjList.isEmpty()) {
				ApplicationProfileDetailsTO serverObj = serverObjList.get(0);
				List<EnvironmentDetailsTO> envList = (List<EnvironmentDetailsTO>) getHibernateTemplate().find("from EnvironmentDetailsTO a where a.environment.id =? and a.serverGroup =? ", envId, serverObj.getServerGroup());
				if (!envList.isEmpty()) {
					ProvisionedMachineTO provisionedMachine = envList.get(0).getProvisionedMachine();
					if (provisionedMachine != null) {
						serverIp = provisionedMachine.getIp();
					}
				}
			}
		} catch (Exception e) {
			throw new CMMException("Exception occurred in selectedIPAddresses ", e);
		}
		return serverIp;
	}
	
	@Override
	public ApplicationProfileDetailsTO getappPrfDet(Long selectedProfile, Long selectedSoftware, Long selectedServer) throws CMMException {
	
		ApplicationProfileDetailsTO appPrf = new ApplicationProfileDetailsTO();
		List<ApplicationProfileDetailsTO> appProDetList = (List<ApplicationProfileDetailsTO>) getHibernateTemplate().find("from ApplicationProfileDetailsTO where id =? ", selectedServer);
		if (!appProDetList.isEmpty()) {
			Long serverGroup = appProDetList.get(0).getServerGroup();
			List<ApplicationProfileDetailsTO> appProDetList1 = (List<ApplicationProfileDetailsTO>) getHibernateTemplate().find("from ApplicationProfileDetailsTO where profileId =? and serverGroup =? and softwareConfig.id=?", selectedProfile, serverGroup, selectedSoftware);
			if (!appProDetList1.isEmpty()) {
				appPrf = appProDetList1.get(0);
			}
		}
		return appPrf;
	}
	
	private void closeUp(Closeable stream) {
	
		try {
			stream.close();
		} catch (IOException e) {
			LOG.error("Error in closing stream : ", e);
		}
	}
}
