package com.ext.puppet.dao.Impl;

import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.puppet.dao.PuppetSoftwareProcessMapDao;
import com.framework.exception.CMMException;
import com.framework.puppetMaster.to.PuppetProcessParametersTO;
import com.framework.puppetMaster.to.PuppetProcessSoftwareMapping;

/**
 * @author 584175
 */
public class PuppetSoftwareProcessMapDaoImpl extends HibernateDaoSupport implements PuppetSoftwareProcessMapDao {
	
	private static final Logger LOGGER = Logger.getLogger(PuppetSoftwareProcessMapDaoImpl.class);
	
	@Override
	public void savePuppetProcessSoftwareMapping(PuppetProcessSoftwareMapping puppetProcessSoftwareMapping) throws CMMException {
	
		try {
			getHibernateTemplate().save(puppetProcessSoftwareMapping);
		} catch (DataAccessException | HibernateException div) {
			LOGGER.error("Error in PuppetProcessParameterDaoImpl: savePuppetProcessSoftwareMapping ", div);
			throw new CMMException("Problem encountered. PuppetSoftwareProcessMapDaoImpl: savePuppetProcessSoftwareMapping", div);
		}
	}
	
	@Override
	public PuppetProcessSoftwareMapping getPuppetProcessSoftMapping(long softwareConfigId, long serviceId) throws CMMException {
	
		List<PuppetProcessSoftwareMapping> puppetProcessmappingList = new ArrayList<PuppetProcessSoftwareMapping>();
		try {
			puppetProcessmappingList = (List<PuppetProcessSoftwareMapping>) getHibernateTemplate().findByCriteria(DetachedCriteria.forClass(PuppetProcessSoftwareMapping.class).add(Restrictions.eq("softwareConfigId", softwareConfigId)).add(Restrictions.eq("serviceTO.id", serviceId)));
			if (puppetProcessmappingList == null) {
				LOGGER.debug("No record found for softwareConfigId::" + softwareConfigId);
				throw new CMMException("No software-process mapping found for given software configId::" + softwareConfigId);
			}
		} catch (DataAccessException | HibernateException da) {
			LOGGER.error("Error in PuppetProcessParameterDaoImpl: getPuppetProcessSoftMapping ", da);
			throw new CMMException("Problem encountered. PuppetSoftwareProcessMapDaoImpl: getPuppetProcessSoftMapping", da);
		}
		return puppetProcessmappingList.get(0);
	}
	
	@Override
	public List<PuppetProcessSoftwareMapping> getPuppetSoftwareProcessMapping(long softwareConfigId) throws CMMException {
	
		List<PuppetProcessSoftwareMapping> puppetProcessmappingList = new ArrayList<PuppetProcessSoftwareMapping>();
		try {
			puppetProcessmappingList = (List<PuppetProcessSoftwareMapping>) getHibernateTemplate().find("from  PuppetProcessSoftwareMapping where softwareConfigTO.id = ?", softwareConfigId);
			if (puppetProcessmappingList == null) {
				LOGGER.debug("No record found for softwareConfigId::" + softwareConfigId);
				throw new CMMException("No software-process mapping found for given software configId::" + softwareConfigId);
			}
		} catch (DataAccessException | HibernateException da) {
			LOGGER.error("Error in PuppetProcessParameterDaoImpl: getPuppetSoftwareProcessMapping ", da);
			throw new CMMException("Problem encountered. PuppetSoftwareProcessMapDaoImpl: getPuppetSoftwareProcessMapping", da);
		}
		return puppetProcessmappingList;
	}
	
	@Override
	public boolean selectedProcessName(PuppetProcessParametersTO puppetProcessParametersTO) throws CMMException {
	
		return true;
	}
}
