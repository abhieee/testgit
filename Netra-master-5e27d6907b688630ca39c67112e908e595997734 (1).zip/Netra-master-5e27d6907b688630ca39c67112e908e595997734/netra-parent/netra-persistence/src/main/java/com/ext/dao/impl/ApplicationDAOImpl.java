package com.ext.dao.impl;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.Authenticator;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.params.AuthPolicy;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.exception.ConstraintViolationException;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.ext.dao.ApplicationDAO;
import com.ext.util.DAOConstants;
import com.framework.common.CMMConstants;
import com.framework.exception.CMMException;
import com.framework.to.ApplicationCategoryTO;
import com.framework.to.ApplicationReleaseSourcecodeTO;
import com.framework.to.ApplicationReleaseTO;
import com.framework.to.ApplicationSystemTO;
import com.framework.to.ApplicationTO;
import com.framework.to.ApplicationTreeTO;
import com.framework.to.BoaMasterTo;
import com.framework.to.BusinessUnitTO;
import com.framework.to.CIServerTO;
import com.framework.to.EnvironmentApplicationTO;
import com.framework.to.EnvironmentTO;
import com.framework.to.MonitoringURLDataTo;
import com.framework.to.NamedEntityTO;
import com.framework.to.ProjectsTO;
import com.framework.to.ProvisionedMachineTO;
import com.framework.to.RepoTO;
import com.framework.to.RoleTO;
import com.framework.to.ServiceRequestTO;
import com.framework.to.ServiceTO;
import com.framework.to.SoftwareTO;
import com.framework.to.SonarReportsDetailTO;
import com.framework.to.TestingLifeCycleTO;
import com.framework.to.TestingPhaseTO;
import com.framework.to.UserBusinessUnitTO;
import com.framework.to.UserGroupDetailsTO;
import com.framework.to.UserGroupTO;
import com.framework.to.UserTO;
import com.framework.utility.DateUtils;
import com.sun.net.ssl.HostnameVerifier;

public class ApplicationDAOImpl extends HibernateDaoSupport implements ApplicationDAO {
	
	private static final Logger LOG = Logger.getLogger(ApplicationDAOImpl.class);
	
	@Override
	public ApplicationTO editApplication(ApplicationTO applicationTO) throws CMMException {
	
		applicationTO.setStatus(applicationTO.getSelectedStatus());
		try {
			String query = String.format("Select a from BusinessUnitTO a where a.id=%d", applicationTO.getSelectedBusinessUnit());
			BusinessUnitTO businessUnitTO = (BusinessUnitTO) getHibernateTemplate().find(query).get(0);
			query = String.format("Select a from ApplicationSystemTO a where a.applicationId=%d", applicationTO.getId());
			List<ApplicationSystemTO> appToOldList = (List<ApplicationSystemTO>) getHibernateTemplate().find(query);
			getHibernateTemplate().deleteAll(appToOldList);
			query = String.format("Select a from ApplicationTO a where a.id=%d", applicationTO.getId());
			ApplicationTO appTo = (ApplicationTO) getHibernateTemplate().find(query).get(0);
			BusinessUnitTO bu = businessUnitTO;
			Set<ApplicationTO> applicationTOset = new HashSet<ApplicationTO>(0);
			applicationTOset.add(applicationTO);
			bu.setApplication(applicationTOset);
			applicationTO.setBusinessUnitTO(bu);
			query = String.format("Select a from ProjectsTO a where a.id=%d", applicationTO.getSelectedProject());
			ProjectsTO projectsTO = (ProjectsTO) getHibernateTemplate().find(query).get(0);
			ProjectsTO proj = projectsTO;
			proj.setApplication(applicationTOset);
			applicationTO.setProjectTO(proj);
			applicationTO.setCreatedDate(appTo.getCreatedDate());
			if (applicationTO.getCategory() != null) {
				if (applicationTO.getCategory().equals(CMMConstants.Framework.Application.APPLICATION_CATEGORY_OTHER)) {
					applicationTO.setCategory(applicationTO.getOther());
					getHibernateTemplate().update(applicationTO);
					if (!checkAppCategoryName(applicationTO.getCategory(), applicationTO.getType())) {
						ApplicationCategoryTO appCategory = new ApplicationCategoryTO();
						appCategory.setCategory(applicationTO.getCategory());
						if (applicationTO.getType().equals(CMMConstants.Framework.Application.APPLICATION_TYPE_APP)) {
							appCategory.setCategoryType(CMMConstants.Framework.ApplicationCategory.CATEGORY_TYPE_APP);
						}
						if (applicationTO.getType().equals(CMMConstants.Framework.Application.APPLICATION_TYPE_SYS)) {
							appCategory.setCategoryType(CMMConstants.Framework.ApplicationCategory.CATEGORY_TYPE_SYS);
						}
						getHibernateTemplate().save(appCategory);
					}
				} else {
					applicationTO.setCategory(applicationTO.getCategory());
					getHibernateTemplate().update(applicationTO);
				}
			} else {
				getHibernateTemplate().update(applicationTO);
			}
			return applicationTO;
		} catch (ConstraintViolationException ce) {
			LOG.error("Problem encountered. ApplicationDAOImpl : editApplication", ce);
			throw new CMMException(DAOConstants.ERROR_MESSAGE, ce);
		} catch (DataAccessException | HibernateException dae) {
			LOG.error("Problem encountered. ApplicationDAOImpl : editApplication", dae);
			throw new CMMException(DAOConstants.ERROR_MESSAGE, dae);
		}
	}
	
	@Override
	public List<BusinessUnitTO> getsavedbusinessUnitList(Long serviceId) throws CMMException {
	
		try {
			List<BusinessUnitTO> buList = new ArrayList<BusinessUnitTO>();
			String query = String.format("select  distinct c from BusinessUnitTO c, ServiceClientTO u  where u.clientId=c.clientId and u.serviceTO.id=%d", serviceId);
			buList = (List<BusinessUnitTO>) getHibernateTemplate().find(query);
			return buList;
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : getsavedbusinessUnitList", dae);
		}
	}
	
	@Override
	public Long getRole(Long userId) throws CMMException {
	
		try {
			String hql = String.format("SELECT up.roleId FROM UserPrivilegeTO up, UserTO u WHERE u.id=up.id AND up.id=%d", userId);
			List<Long> longList1 = (List<Long>) getHibernateTemplate().find(hql);
			return longList1.get(0);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : getSavedClientList", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : getSavedClientList", he);
		}
	}
	
	@Override
	public List<ProvisionedMachineTO> getProvisionedMachines(Long selectedApplication, Long selectedEnvironment, Long releaseId) throws CMMException {
	
		List<ProvisionedMachineTO> machines = new ArrayList<ProvisionedMachineTO>();
		Session session = null;
		Transaction tx = null;
		try {
			session = getSession();
			tx = session.beginTransaction();
			String hql = "select distinct p.id, p.name from provisioned_machine p inner join environment_details ed on ed.provisioned_machine_tmplt_id = p.id inner join environment_application ea on ed.environment_id = ea.environment_id and ea.application_id = ? and ea.environment_id = ? and ea.application_release_id = ?";
			Query q = session.createSQLQuery(hql);
			q.setParameter(0, selectedApplication);
			q.setParameter(1, selectedEnvironment);
			q.setParameter(2, releaseId);
			List<Object[]> obj = q.list();
			tx.commit();
			for (Object[] temp : obj) {
				ProvisionedMachineTO machine = new ProvisionedMachineTO();
				machine.setId(Long.parseLong(String.valueOf(temp[0])));
				machine.setName(temp[1].toString());
				machines.add(machine);
			}
			return machines;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getProvisionedMachines(List)", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getProvisionedMachines(List)", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<ProvisionedMachineTO> fetchMachineDetails(Long selectedApplication, Long selectedEnvironment) throws CMMException {
	
		List<ProvisionedMachineTO> machines = new ArrayList<ProvisionedMachineTO>();
		Session session = null;
		Transaction tx = null;
		try {
			session = getSession();
			tx = session.beginTransaction();
			String hql = "select distinct p.id, p.name, p.ip, p.provisioned_machine_type from provisioned_machine p inner join environment_details ed on ed.provisioned_machine_tmplt_id = p.id inner join environment_application ea on ed.environment_id = ea.environment_id and ea.application_id = ? and ea.environment_id = ?";
			Query q = session.createSQLQuery(hql);
			q.setParameter(0, selectedApplication);
			q.setParameter(1, selectedEnvironment);
			List<Object[]> obj = q.list();
			tx.commit();
			for (Object[] temp : obj) {
				ProvisionedMachineTO machine = new ProvisionedMachineTO();
				try {
					machine.setId(Long.parseLong(String.valueOf(temp[0])));
					machine.setName(temp[1].toString());
					machine.setIp(temp[2].toString());
					machine.setProvisionedMachineType(temp[3].toString());
				} catch (RuntimeException ex) {
					LOG.error("Problem encountered. ApplicationDAOImpl : fetchMachineDetails ", ex);
					continue;
				}
				machines.add(machine);
			}
			return machines;
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getProvisionedMachines(List)", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getProvisionedMachines(List)", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public ApplicationTO getApplicationDetails(ApplicationTO applicationTO) throws CMMException {
	
		StringBuilder query = new StringBuilder("select a.appName, a.description, b.name, b.id, c.id, c.name, d.name, a.status, d.id, a.selectedOwner, a.createdDate, a.type, a.category, a.manufacturer, a.vendor , a.mobileAppType, a.nativeAppType ");
		query.append("from ApplicationTO a inner join a.userGroups b inner join a.businessUnitTO c inner join a.projectTO d ");
		query.append("where a.id=?");
		String hql = String.format("Select a from ApplicationSystemTO a where a.applicationId=%d", applicationTO.getId());
		List<ApplicationSystemTO> applicationSystemList = (List<ApplicationSystemTO>) getHibernateTemplate().find(hql);
		ApplicationTO appTO = new ApplicationTO();
		LOG.debug("QUERY...." + query);
		try {
			Object[] dbApp = (Object[]) getHibernateTemplate().find(query.toString(), applicationTO.getId()).get(0);
			List<Long> applicationIdUpList = new ArrayList<Long>();
			for (ApplicationSystemTO appSysTO : applicationSystemList) {
				if (appSysTO.getDependentType().equals(CMMConstants.Framework.ApplicationSystem.DEPENDENT_TYPE_Up)) {
					applicationIdUpList.add(appSysTO.getSystemId());
				}
			}
			if (applicationIdUpList.isEmpty()) {
				applicationIdUpList = null;
			}
			List<Long> applicationIdDownList = new ArrayList<Long>();
			for (ApplicationSystemTO appSysTO : applicationSystemList) {
				if (appSysTO.getDependentType().equals(CMMConstants.Framework.ApplicationSystem.DEPENDENT_TYPE_Down)) {
					applicationIdDownList.add(appSysTO.getSystemId());
				}
			}
			if (applicationIdDownList.isEmpty()) {
				applicationIdDownList = null;
			}
			appTO.setDefinedComponentUp(applicationIdUpList);
			appTO.setDefinedComponentDown(applicationIdDownList);
			appTO.setId(applicationTO.getId());
			String appname = (String) dbApp[0];
			appTO.setAppName(appname);
			String desc = (String) dbApp[1];
			appTO.setDescription(desc);
			String usergrp = (String) dbApp[2];
			appTO.setUserGroup(usergrp);
			Long usergrpID = (Long) dbApp[3];
			appTO.setUserGrpId(usergrpID);
			Long buid = (Long) dbApp[4];
			appTO.setSelectedBusinessUnit(buid);
			String businessunit = (String) dbApp[5];
			appTO.setBusinessUnitName(businessunit);
			String project = (String) dbApp[6];
			appTO.setProjectName(project);
			Long status = (Long) dbApp[7];
			appTO.setSelectedStatus(status);
			Long pId = (Long) dbApp[8];
			appTO.setSelectedProject(pId);
			Long appOwner = (Long) dbApp[9];
			appTO.setSelectedOwner(appOwner);
			Date createdBydate = (Date) dbApp[10];
			appTO.setCreatedDate(createdBydate);
			String type = (String) dbApp[11];
			appTO.setType(type);
			String category = (String) dbApp[12];
			appTO.setCategory(category);
			String manufacturer = (String) dbApp[13];
			appTO.setManufacturer(manufacturer);
			String vendor = (String) dbApp[14];
			appTO.setVendor(vendor);
			Long usergrpid = (Long) dbApp[3];
			String mobileAppType = (String) dbApp[15];
			appTO.setMobileAppType(mobileAppType);
			String nativeAppType = (String) dbApp[16];
			appTO.setNativeAppType(nativeAppType);
			LOG.debug("usergrpid...." + usergrpid);
			StringBuilder query2 = new StringBuilder("select u.name,u.id from UserGroupDetailsTO ud inner join ud.users u where ud.userGroups.id=?");
			LOG.debug("QERY...." + query);
			List<Object> usergrpname = (List<Object>) getHibernateTemplate().find(query2.toString(), usergrpid);
			List<UserGroupTO> userlist = new ArrayList<UserGroupTO>();
			for (int i = 0; i < usergrpname.size(); i++) {
				Object[] dbApp1 = (Object[]) usergrpname.get(i);
				UserGroupTO temp = new UserGroupTO();
				temp.setName((String) dbApp1[0]);
				userlist.add(temp);
			}
			appTO.setUserNameList(userlist);
		} catch (DataAccessException dae) {
			LOG.error("Problem encountered. ApplicationDAOImpl : getApplicationDetails", dae);
			throw new CMMException(DAOConstants.ERROR_MESSAGE, dae);
		} catch (HibernateException he) {
			LOG.error("Problem encountered. ApplicationDAOImpl : getApplicationDetails", he);
			throw new CMMException(DAOConstants.ERROR_MESSAGE, he);
		}
		return appTO;
	}
	
	@Override
	public List<ApplicationTO> getApplicationsDetails(List<Long> ids) throws CMMException {
	
		StringBuilder query = new StringBuilder("from ApplicationTO a inner join a.userGroups b inner join a.businessUnitTO c inner join a.projectTO d where a.id in (:idList)");
		LOG.debug("QUERY...." + query);
		List<ApplicationTO> applicationList = new ArrayList<ApplicationTO>();
		try {
			List<Object[]> Apps = (List<Object[]>) getHibernateTemplate().findByNamedParam(query.toString(), "idList", ids);
			for (Object[] appObj : Apps) {
				applicationList.add((ApplicationTO) appObj[0]);
			}
		} catch (DataAccessException dae) {
			LOG.error("Problem encountered. ApplicationsDAOImpl : getApplicationsDetails", dae);
			throw new CMMException(DAOConstants.ERROR_MESSAGE, dae);
		} catch (HibernateException he) {
			LOG.error("Problem encountered. ApplicationsDAOImpl : getApplicationsDetails", he);
			throw new CMMException(DAOConstants.ERROR_MESSAGE, he);
		}
		return applicationList;
	}
	
	@Override
	public List<UserGroupTO> getUserGroupNames(Long usergrpid) throws CMMException {
	
		StringBuilder query2 = new StringBuilder("select u.name,u.id from UserGroupDetailsTO ud inner join ud.users u where ud.userGroups.id=?");
		LOG.debug("QERY...." + query2);
		List<Object> usergrpname = (List<Object>) getHibernateTemplate().find(query2.toString(), usergrpid);
		List<UserGroupTO> userlist = new ArrayList<UserGroupTO>();
		for (int i = 0; i < usergrpname.size(); i++) {
			Object[] dbApp1 = (Object[]) usergrpname.get(i);
			UserGroupTO temp = new UserGroupTO();
			temp.setName((String) dbApp1[0]);
			userlist.add(temp);
		}
		return userlist;
	}
	
	@Override
	public ApplicationTO addApplication(ApplicationTO applicationTO) throws CMMException {
	
		ApplicationTO tempApp = applicationTO;
		boolean flagadd = true;
		try {
			String query = String.format("Select a from BusinessUnitTO a where a.id=%d", applicationTO.getSelectedBusinessUnit());
			tempApp.setAddCI_Id(null);
			BusinessUnitTO businessUnitTO = (BusinessUnitTO) getHibernateTemplate().find(query).get(0);
			BusinessUnitTO bu = businessUnitTO;
			Set<ApplicationTO> applicationTOset = new HashSet<ApplicationTO>(0);
			applicationTOset.add(applicationTO);
			bu.setApplication(applicationTOset);
			tempApp.setBusinessUnitTO(bu);
			query = String.format("Select a from ProjectsTO a where a.id=%d", applicationTO.getSelectedProject());
			ProjectsTO projectsTO = (ProjectsTO) getHibernateTemplate().find(query).get(0);
			ProjectsTO proj = projectsTO;
			proj.setApplication(applicationTOset);
			tempApp.setProjectTO(proj);
			tempApp.setCreatedById(applicationTO.getCreatedById());
			tempApp.setCreatedDate(DateUtils.getStartTime(new Date()));
			tempApp.setModifiedDate(DateUtils.getStartTime(new Date()));
			tempApp.setModifiedbyId(applicationTO.getCreatedById());
			tempApp.setContextPathName(applicationTO.getContextPathName());
			if (applicationTO.getMobileAppType() != null) {
				if (applicationTO.getNativeAppType() != null) {
					tempApp.setMobileAppType(applicationTO.getMobileAppType());
					tempApp.setNativeAppType(applicationTO.getNativeAppType());
				} else {
					tempApp.setMobileAppType(applicationTO.getMobileAppType());
				}
			}
			UserGroupTO temp = new UserGroupTO();
			if (applicationTO.isCheck()) {
				query = String.format("Select a from UserGroupTO a where a.id=%d", applicationTO.getSelectedUserGroup());
				UserGroupTO usergroupTO = (UserGroupTO) getHibernateTemplate().find(query).get(0);
				UserGroupTO ug = usergroupTO;
				ug.setApplicationTO(applicationTOset);
				temp = ug;
				tempApp.setUserGroups(ug);
				if ((tempApp.getSelectedLeftUsers() != null) && (tempApp.getSelectedLeftUsers().size() > 0)) {
					for (Long userId : tempApp.getSelectedLeftUsers()) {
						UserGroupDetailsTO temp1 = new UserGroupDetailsTO();
						UserTO user = new UserTO();
						user.setId(userId);
						temp1.setUsers(user);
						temp1.setUserGroups(usergroupTO);
						saveUserDetails(temp1, tempApp.getSelectedUserGroup());
					}
					/*
					 * Either the existing users may contain the application ownner or the new added users may contain.if not then add the
					 * application owner in user group
					 */
					List<UserTO> existing_users = getAllSelectedUserNames(tempApp.getSelectedUserGroup());
					for (UserTO u : existing_users) {
						if (u.getId().equals(tempApp.getSelectedOwner())) {
							flagadd = false;
							break;
						}
					}
					for (Long u : tempApp.getSelectedLeftUsers()) {
						if (u.equals(tempApp.getSelectedOwner())) {
							flagadd = false;
							break;
						}
					}
					if (flagadd) {
						UserGroupDetailsTO temp2 = new UserGroupDetailsTO();
						UserTO user2 = new UserTO();
						user2.setId(tempApp.getSelectedOwner());
						temp2.setUsers(user2);
						temp2.setUserGroups(usergroupTO);
						saveUserDetails(temp2, tempApp.getSelectedUserGroup());
					}
				}
			} else {
				temp.setName(tempApp.getUserGroup());
				temp = saveUserGroup(temp);
				temp.setApplicationTO(applicationTOset);
				tempApp.setUserGroups(temp);
				tempApp.setSelectedUserGroup(temp.getId());
				for (Long userId : tempApp.getSelectedUserName()) {
					UserGroupDetailsTO temp1 = new UserGroupDetailsTO();
					UserTO user = new UserTO();
					user.setId(userId);
					temp1.setUsers(user);
					temp1.setUserGroups(temp);
					saveUserDetails(temp1, temp.getId());
				}
				/*
				 * if Application owner is not selected while selecting users then it should be added explicitily
				 */
				for (Long u : tempApp.getSelectedUserName()) {
					if (u.equals(tempApp.getSelectedOwner())) {
						flagadd = false;
						break;
					}
				}
				if (flagadd) {
					UserGroupDetailsTO temp2 = new UserGroupDetailsTO();
					UserTO user2 = new UserTO();
					user2.setId(tempApp.getSelectedOwner());
					temp2.setUsers(user2);
					temp2.setUserGroups(temp);
					saveUserDetails(temp2, tempApp.getSelectedUserGroup());
				}
			}
			if (applicationTO.getCategory() != null) {
				if (applicationTO.getCategory().equals(CMMConstants.Framework.Application.APPLICATION_CATEGORY_OTHER)) {
					tempApp.setCategory(applicationTO.getOther());
					getHibernateTemplate().save(tempApp);
					if (!checkAppCategoryName(applicationTO.getCategory(), applicationTO.getType())) {
						ApplicationCategoryTO appCategory = new ApplicationCategoryTO();
						appCategory.setCategory(applicationTO.getCategory());
						if (applicationTO.getType().equals(CMMConstants.Framework.Application.APPLICATION_TYPE_APP)) {
							appCategory.setCategoryType(CMMConstants.Framework.ApplicationCategory.CATEGORY_TYPE_APP);
						}
						if (applicationTO.getType().equals(CMMConstants.Framework.Application.APPLICATION_TYPE_SYS)) {
							appCategory.setCategoryType(CMMConstants.Framework.ApplicationCategory.CATEGORY_TYPE_SYS);
						}
						getHibernateTemplate().save(appCategory);
					}
				} else {
					tempApp.setCategory(applicationTO.getCategory());
					getHibernateTemplate().save(tempApp);
				}
			} else {
				getHibernateTemplate().save(tempApp);
			}
		} catch (ConstraintViolationException ce) {
			LOG.error("Problem encountered. ApplicationDAOImpl : addApplication", ce);
			throw new CMMException(DAOConstants.ERROR_MESSAGE, ce);
		} catch (DataAccessException | HibernateException dae) {
			LOG.error("Problem encountered. ApplicationDAOImpl : addApplication", dae);
			throw new CMMException(DAOConstants.ERROR_MESSAGE, dae);
		}
		return tempApp;
	}
	
	@Override
	public List<BusinessUnitTO> getBusinessUnitNames(List<Long> clientIdlist) throws CMMException {
	
		List<BusinessUnitTO> businessUnitTOList = new ArrayList<BusinessUnitTO>();
		Session session = getSession();
		int flag = 0;
		try {
			for (Long clientId : clientIdlist) {
				if (clientId == 0) {
					flag = 1;
				}
			}
			if (flag == 1) {
				String hql = String.format("Select a from BusinessUnitTO a where a.status=%d", CMMConstants.Framework.Entity.BUSINESS_ACTIVE);
				businessUnitTOList = (List<BusinessUnitTO>) getHibernateTemplate().find(hql);
			} else {
				String hql = "select bu.clientId, bu.status , bu.name from BusinessUnitTO bu where bu.status=? and bu.clientId in (:userId) ";
				Query q = session.createQuery(hql);
				q.setParameterList("userId", clientIdlist);
				q.setLong(0, CMMConstants.Framework.Entity.BUSINESS_ACTIVE);
				List<Object[]> obj = q.list();
				for (Object[] temp : obj) {
					BusinessUnitTO businessUnit = new BusinessUnitTO();
					businessUnit.setClientId((Long) temp[0]);
					businessUnit.setStatus((Long) temp[1]);
					businessUnit.setName((String) temp[2]);
					businessUnitTOList.add(businessUnit);
				}
			}
			return businessUnitTOList;
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getBusinessUnitNames", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public boolean checkApplicationName(String applicationName, Long id) throws CMMException {
	
		List<ApplicationTO> applicationList = null;
		try {
			if (id != null) {
				applicationList = (List<ApplicationTO>) getHibernateTemplate().find("from ApplicationTO where appName=? and id<>?", applicationName, id);
			} else {
				applicationList = (List<ApplicationTO>) getHibernateTemplate().find("from ApplicationTO where appName=?", applicationName);
			}
			return !applicationList.isEmpty();
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getBusinessUnitNames", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getBusinessUnitNames", he);
		}
	}
	
	@Override
	public List<TestingPhaseTO> getTestingPhases(Long selectedApp) throws CMMException {
	
		try {
			String query = "select testingPhase from TestingPhaseTO testingPhase,ApplicationReleasePhaseTO ap where ap.phaseId=testingPhase.id and ap.applicationId=? and ap.stat=?";
			return (List<TestingPhaseTO>) getHibernateTemplate().find(query, selectedApp, "Y");
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getTestingPhases()", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getTestingPhases()", he);
		}
	}
	
	@Override
	public List<ProjectsTO> getAllProjectsForMultipleBU(List<Long> clientIds) throws CMMException {
	
		List<ProjectsTO> projectList = new ArrayList<ProjectsTO>(0);
		try {
			for (Long clientId : clientIds) {
				List<ProjectsTO> projects = new ArrayList<ProjectsTO>(0);
				projects = (List<ProjectsTO>) getHibernateTemplate().find("from ProjectsTO where clientId=? and status=?", clientId, CMMConstants.Framework.Entity.PROJECT_STATUS_EXISTING);
				for (ProjectsTO project : projects) {
					projectList.add(project);
				}
			}
			return projectList;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getAllProjects", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.  ApplicationDAOImpl : getAllProjects", he);
		}
	}
	
	@Override
	public List<ProjectsTO> getAllProjects(Long clientId) throws CMMException {
	
		try {
			String hql = String.format("select a from ProjectsTO a where a.clientId=%d and a.status=%s", clientId, CMMConstants.Framework.Entity.PROJECT_STATUS_EXISTING);
			return (List<ProjectsTO>) getHibernateTemplate().find(hql);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getAllProjects", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.  ApplicationDAOImpl : getAllProjects", he);
		}
	}
	
	@Override
	public List<UserTO> getAllUserNames(UserTO userTO) throws CMMException {
	
		List<UserTO> userTOList = new ArrayList<UserTO>();
		try {
			String query = String.format("Select distinct ubu.user.id, u.name,u.passwordEnc, u.email, u.phone, u.fullName ,ubu.clientId, u.status from UserTO u, UserBusinessUnitTO ubu where ubu.user.id=u.id and ubu.clientId=%d and u.status=%d", userTO.getClientId(), CMMConstants.Framework.Entity.USER_STATUS_ACTIVE);
			List<Object[]> temp = (List<Object[]>) getHibernateTemplate().find(query);
			for (Object[] temp1 : temp) {
				UserTO user = new UserTO();
				user.setId((Long) temp1[0]);
				user.setName(temp1[1].toString());
				user.setClientId((Long) temp1[6]);
				user.setStatus((Long) temp1[7]);
				userTOList.add(user);
			}
			return userTOList;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getAllUserNames", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getAllUserNames", he);
		}
	}
	
	@Override
	public void addApplicationTree(ApplicationTreeTO applicationTO) {
	
		/* No implementation required at the moment. Method for future use. */
	}
	
	@Override
	public List<Object> searchApplications(ApplicationTO applicationTO, List<UserGroupTO> userGroupIds) throws CMMException {
	
		LOG.debug("Client ID for search........" + applicationTO.getSelectedBusinessUnit());
		Session session = getSession();
		try {
			List<Long> usergrpIdList = new ArrayList<Long>();
			for (UserGroupTO u : userGroupIds) {
				usergrpIdList.add(u.getId());
			}
			if (usergrpIdList.isEmpty()) {
				usergrpIdList.add(-1L);
			}
			String query = "select a.appName, a.description, a.id, b.id,b.name, c.name, d.name, a.type, a.category from ApplicationTO a inner join a.userGroups b inner join a.businessUnitTO c inner join a.projectTO d ";
			if (applicationTO.getClientId() > 0) {
				if (applicationTO.getSelectedBusinessUnit() > 0) {
					query = query + "where a.appName like (:applicationName) and a.type like (:type) and c.clientId=:cId and b.id in(:ug)";
					LOG.debug("QERY...." + query);
					Query q;
					if (applicationTO.getSearchCount() == 0) {
						q = session.createQuery(query);
					} else {
						Query q1 = session.createQuery(query).setFirstResult(applicationTO.getFirstResult());
						q = q1.setMaxResults(applicationTO.getTableSize());
					}
					q.setParameter("cId", applicationTO.getSelectedBusinessUnit());
					q.setParameter("applicationName", "%" + applicationTO.getAppName() + "%");
					q.setParameter("type", "%" + applicationTO.getType() + "%");
					q.setParameterList("ug", usergrpIdList);
					return q.list();
				} else {
					query = query + "where a.appName like (:applicationName) and a.type like (:type) and a.businessUnitTO.clientId in (:clientList) and b.id in(:ug)";
					Query q;
					if (applicationTO.getSearchCount() == 0) {
						q = session.createQuery(query);
					} else {
						Query q1 = session.createQuery(query).setFirstResult(applicationTO.getFirstResult());
						q = q1.setMaxResults(applicationTO.getTableSize());
					}
					q.setParameterList("clientList", applicationTO.getClientIdlist());
					q.setParameter("applicationName", "%" + applicationTO.getAppName() + "%");
					q.setParameter("type", "%" + applicationTO.getType() + "%");
					q.setParameterList("ug", usergrpIdList);
					return q.list();
				}
			} else if (applicationTO.getSelectedBusinessUnit() > 0) {
				query = query + "where a.appName like (:applicationName) and a.type like (:type) and c.clientId=:cId";
				LOG.debug("QERY...." + query);
				Query q;
				if (applicationTO.getSearchCount() == 0) {
					q = session.createQuery(query);
				} else {
					Query q1 = session.createQuery(query).setFirstResult(applicationTO.getFirstResult());
					q = q1.setMaxResults(applicationTO.getTableSize());
				}
				q.setParameter("cId", applicationTO.getSelectedBusinessUnit());
				q.setParameter("applicationName", "%" + applicationTO.getAppName() + "%");
				q.setParameter("type", "%" + applicationTO.getType() + "%");
				return q.list();
			} else {
				query = query + "where a.type like (:type) and a.appName like (:applicationName) ";
				Query q;
				if (applicationTO.getSearchCount() == 0) {
					q = session.createQuery(query);
				} else {
					Query q1 = session.createQuery(query).setFirstResult(applicationTO.getFirstResult());
					q = q1.setMaxResults(applicationTO.getTableSize());
				}
				q.setParameter("applicationName", "%" + applicationTO.getAppName() + "%");
				q.setParameter("type", "%" + applicationTO.getType() + "%");
				return q.list();
			}
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : searchApplications", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : searchApplications", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<NamedEntityTO> getTemplateModeList(String entityId) throws CMMException {
	
		try {
			return (List<NamedEntityTO>) getHibernateTemplate().find("from StatusTO where ENTITY_ID=?", entityId);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getTemplateModeList", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getTemplateModeList", he);
		}
	}
	
	@Override
	public List<NamedEntityTO> getShareModeList(String entityId) throws CMMException {
	
		try {
			return (List<NamedEntityTO>) getHibernateTemplate().find("from StatusTO where ENTITY_ID=?", entityId);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getShareModeList", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getShareModeList", he);
		}
	}
	
	@Override
	public List<NamedEntityTO> getStatusList(String entityId) throws CMMException {
	
		try {
			String query = String.format("Select a from StatusTO a where a.entityId=%s", entityId);
			return (List<NamedEntityTO>) getHibernateTemplate().find(query);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getStatusList", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getStatusList", he);
		}
	}
	
	@Override
	public List<ApplicationTO> getAllApplications(List<UserGroupTO> userGroupIds) throws CMMException {
	
		List<ApplicationTO> applicationList = new ArrayList<ApplicationTO>();
		List<Long> grpIds = new ArrayList<Long>();
		Session session = null;
		Transaction tx = null;
		try {
			session = getSession();
			for (UserGroupTO groupTO : userGroupIds) {
				grpIds.add(groupTO.getId());
			}
			if (grpIds.isEmpty()) {
				grpIds.add(-1L);
			}
			tx = session.beginTransaction();
			String hql = "select a.id,a.appName, a.status from ApplicationTO a inner join a.userGroups u where u.id in (:grpId) and a.status!=52 ";
			Query q = session.createQuery(hql);
			q.setParameterList("grpId", grpIds);
			List<Object[]> obj = q.list();
			tx.commit();
			for (Object[] temp : obj) {
				ApplicationTO applications = new ApplicationTO();
				applications.setId((Long) temp[0]);
				applications.setAppName(temp[1].toString());
				applications.setStatus((Long) temp[2]);
				applicationList.add(applications);
			}
			return applicationList;
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getAllApplications(List)", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<ApplicationTO> getAllApplications(Long clientId, List<UserGroupTO> userGroupIds) throws CMMException {
	
		List<Long> grpIds = new ArrayList<Long>();
		List<ApplicationTO> applicationList = new ArrayList<ApplicationTO>();
		for (UserGroupTO groupTO : userGroupIds) {
			grpIds.add(groupTO.getId());
		}
		if (grpIds.isEmpty()) {
			grpIds.add(-1L);
		}
		Session session = null;
		Transaction tx = null;
		try {
			session = getSession();
			tx = session.beginTransaction();
			String hql = "";
			if (clientId == 0) {
				hql = "select a.id,a.appName, a.status from ApplicationTO a";
			} else {
				hql = "select a.id,a.appName, a.status from ApplicationTO a inner join a.userGroups u where u.id in (:grpId) and a.status!=52  ";
			}
			Query q = session.createQuery(hql);
			if (clientId != 0) {
				q.setParameterList("grpId", grpIds);
			}
			List<Object[]> obj = q.list();
			tx.commit();
			for (Object[] temp : obj) {
				ApplicationTO applications = new ApplicationTO();
				applications.setId((Long) temp[0]);
				applications.setAppName(temp[1].toString());
				applications.setStatus((Long) temp[2]);
				applicationList.add(applications);
			}
			return applicationList;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getAllApplications(List)", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getAllApplications(List)", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<ApplicationTO> getAllApplications(Long clientId, Long projectId) throws CMMException {
	
		try {
			String hql = "SELECT a FROM ApplicationTO a where a.businessUnitTO.id= " + clientId + " and a.projectTO.id= " + projectId + " and a.status= " + CMMConstants.Framework.Entity.APPLICATION_AVAILABLE;
			return (List<ApplicationTO>) getHibernateTemplate().find(hql);
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getAllApplications(Long, Long)", dae);
		}
	}
	
	@Override
	public List<EnvironmentTO> getAllEnvironments(Long applicationId) throws CMMException {
	
		List<EnvironmentTO> env = new ArrayList<EnvironmentTO>();
		List<EnvironmentApplicationTO> environmentApplicationList = null;
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(EnvironmentApplicationTO.class, "environmentApplicationTO");
			criteria.add(Restrictions.eq("environmentApplicationTO.applicationTO.id", applicationId));
			environmentApplicationList = (List<EnvironmentApplicationTO>) getHibernateTemplate().findByCriteria(criteria);
			if ((environmentApplicationList != null) && !environmentApplicationList.isEmpty()) {
				for (EnvironmentApplicationTO temp : environmentApplicationList) {
					if (temp.getEnvironmentTO().getProfileId() != null) {
						if (temp.getEnvironmentTO().getStatus() == 21L) {
							env.add(temp.getEnvironmentTO());
						}
					}
				}
			}
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getAllEnvironments", dae);
		}
		return env;
	}
	
	@Override
	public List<EnvironmentTO> getAllEnvironmentsForReport(List<Long> applicationId) throws CMMException {
	
		List<EnvironmentTO> env = new ArrayList<EnvironmentTO>();
		List<EnvironmentApplicationTO> environmentApplicationList = null;
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(EnvironmentApplicationTO.class, "environmentApplicationTO");
			criteria.add(Restrictions.in("environmentApplicationTO.applicationTO.id", applicationId));
			environmentApplicationList = (List<EnvironmentApplicationTO>) getHibernateTemplate().findByCriteria(criteria);
			if ((environmentApplicationList != null) && !environmentApplicationList.isEmpty()) {
				for (EnvironmentApplicationTO temp : environmentApplicationList) {
					if (temp.getEnvironmentTO().getProfileId() != null) {
						if (temp.getEnvironmentTO().getStatus() == 21L) {
							env.add(temp.getEnvironmentTO());
						}
					}
				}
			}
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getAllEnvironments", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getAllEnvironments", he);
		}
		return env;
	}
	
	@Override
	public List<UserTO> getApplicationOwner(Long clientId) throws CMMException {
	
		List<UserTO> ownersList = new ArrayList<UserTO>();
		try {
			String query = String.format("SELECT distinct ubu.user.id, u.name, u.status, up.roleId FROM UserTO u, UserPrivilegeTO up, UserBusinessUnitTO ubu where ubu.user.id= u.id and ubu.user.id=up.id and ubu.clientId= %d and up.roleId =1", clientId);
			List<Object[]> list = (List<Object[]>) getHibernateTemplate().find(query);
			for (Object[] temp : list) {
				UserTO user = new UserTO();
				user.setId((Long) temp[0]);
				user.setName(temp[1].toString());
				user.setStatus((Long) temp[2]);
				user.setRoleId((Long) temp[3]);
				ownersList.add(user);
			}
			return ownersList;
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getApplicationOwner", he);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getApplicationOwner", dae);
		} catch (Exception dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getApplicationOwner", dae);
		}
	}
	
	@Override
	public List<ApplicationTO> getAllApplications() throws CMMException {
	
		List<ApplicationTO> applicationList = new ArrayList<ApplicationTO>();
		Session session = null;
		Query query = null;
		try {
			session = getSession();
			query = session.createQuery("SELECT a.id,a.appName,a.status FROM ApplicationTO a WHERE a.status=:availableStatus ORDER BY a.appName");
			query.setLong("availableStatus", CMMConstants.Framework.Entity.APPLICATION_AVAILABLE);
			if (query != null) {
				List<Object[]> queryResultList = query.list();
				for (Object[] result : queryResultList) {
					ApplicationTO application = new ApplicationTO();
					application.setId((Long) result[0]);
					application.setAppName(result[1].toString());
					application.setStatus((Long) result[2]);
					applicationList.add(application);
				}
			}
			return applicationList;
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getAllApplications()", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<ApplicationTO> getAllApplications(Long clientId, Long projectId, List<UserGroupTO> userGroupIds, Long userClientId) throws CMMException {
	
		List<ApplicationTO> applicationList = new ArrayList<ApplicationTO>(0);
		List<Long> grpIds = new ArrayList<Long>();
		Session session = getSession();
		try {
			if (userClientId == 0L) {
				applicationList = getAllApplications(clientId, projectId);
			} else if ((userGroupIds != null) && !userGroupIds.isEmpty()) {
				for (UserGroupTO groupTO : userGroupIds) {
					grpIds.add(groupTO.getId());
				}
				if (grpIds.isEmpty()) {
					grpIds.add(-1L);
				}
				Transaction tx = null;
				tx = session.beginTransaction();
				String hql = "select a.id,a.appName,a.projectTO.id,a.businessUnitTO.id from ApplicationTO a inner join a.userGroups u where u.id in (:grpId) and a.businessUnitTO.id=:clientId  and a.projectTO.id=:projectId and a.status=:status";
				Query q = session.createQuery(hql);
				q.setParameterList("grpId", grpIds);
				q.setParameter("clientId", clientId);
				q.setParameter("projectId", projectId);
				q.setParameter("status", CMMConstants.Framework.Entity.APPLICATION_AVAILABLE);
				List<Object[]> obj = q.list();
				tx.commit();
				if (!obj.isEmpty()) {
					for (Object[] temp : obj) {
						ApplicationTO applications = new ApplicationTO();
						applications.setId((Long) temp[0]);
						applications.setAppName(temp[1].toString());
						applicationList.add(applications);
					}
				}
			}
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getAllApplications(Long, Long, List, Long)", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return applicationList;
	}
	
	@Override
	public List<UserTO> getApplicationOwner(Long clientid, List<Long> clientIdList) throws CMMException {
	
		List<UserTO> ownersList = new ArrayList<UserTO>();
		Session session = getSession();
		try {
			String hql = "SELECT distinct u.id,u.name,up.roleId FROM UserTO u, UserPrivilegeTO up , UserBusinessUnitTO ub where u.id= up.id and ub.user.id=u.id and up.roleId =1 and u.status = (:activeStatus)";
			if (clientid != 0) {
				hql = hql + " and ub.clientId in (:userId)";
			}
			Query q = session.createQuery(hql);
			if (clientid != 0) {
				q.setParameterList("userId", clientIdList);
			}
			q.setLong("activeStatus", 11L);
			List<Object[]> list = q.list();
			for (Object[] temp : list) {
				UserTO user = new UserTO();
				user.setId((Long) temp[0]);
				user.setName(temp[1].toString());
				user.setRoleId((Long) temp[2]);
				ownersList.add(user);
			}
			return ownersList;
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getApplicationOwner", he);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getApplicationOwner", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public boolean defineTestingLifeCycle(TestingLifeCycleTO testingLifeCycleTO) throws CMMException {
	
		boolean flag = false;
		LOG.info("Inside ApplicationDaoImpl--defineTestingLifeCycle()");
		try {
			DetachedCriteria criteria1 = DetachedCriteria.forClass(TestingLifeCycleTO.class);
			criteria1.add(Restrictions.eq("testingPhaseTO.id", testingLifeCycleTO.getSelectedTestingPhase()));
			List<TestingLifeCycleTO> lifeCycleList = (List<TestingLifeCycleTO>) getHibernateTemplate().findByCriteria(criteria1);
			for (TestingLifeCycleTO temp : lifeCycleList) {
				getHibernateTemplate().delete(temp);
			}
			TestingPhaseTO testingPhase = (TestingPhaseTO) getHibernateTemplate().find("from TestingPhaseTO where id=?", testingLifeCycleTO.getSelectedTestingPhase()).get(0);
			ApplicationTO appTO = (ApplicationTO) getHibernateTemplate().find("from ApplicationTO where id=?", testingLifeCycleTO.getSelectedApplication()).get(0);
			List<Long> definedServices = testingLifeCycleTO.getDefinedServices();
			TestingLifeCycleTO temp = new TestingLifeCycleTO();
			Long counter = 0L;
			for (Long service : definedServices) {
				ServiceTO serviceTO = new ServiceTO();
				serviceTO.setId(service);
				counter++;
				temp.setLifeCycleOrder(counter);
				temp.setServiceTo(serviceTO);
				temp.setTestingPhaseTO(testingPhase);
				temp.setApplicationTO(appTO);
				temp.setParentServiceId(testingLifeCycleTO.getParentServiceId());
				getHibernateTemplate().save(temp);
			}
			flag = true;
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : defineTestingLifeCycle", he);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : defineTestingLifeCycle", dae);
		}
		return flag;
	}
	
	@Override
	public List<TestingLifeCycleTO> getLifecycle(long applicationId) throws CMMException {
	
		try {
			return (List<TestingLifeCycleTO>) getHibernateTemplate().find("from TestingLifeCycleTO where applicationTO.id=?", applicationId);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getLifecycle", he);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getLifecycle", dae);
		}
	}
	
	@Override
	public List<ServiceTO> getDefinedServices(Long testingPhase) throws CMMException {
	
		List<ServiceTO> services = new ArrayList<ServiceTO>();
		try {
			DetachedCriteria criteria1 = DetachedCriteria.forClass(TestingLifeCycleTO.class);
			criteria1.add(Restrictions.eq("testingPhaseTO.id", testingPhase));
			criteria1.addOrder(Order.asc("lifeCycleOrder"));
			List<TestingLifeCycleTO> lifeCycleList = (List<TestingLifeCycleTO>) getHibernateTemplate().findByCriteria(criteria1);
			for (TestingLifeCycleTO temp : lifeCycleList) {
				services.add(temp.getServiceTo());
			}
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getDefinedServices", he);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getDefinedServices", dae);
		}
		return services;
	}
	
	@Override
	public List<RepoTO> repoList() throws CMMException {
	
		try {
			return (List<RepoTO>) getHibernateTemplate().find("from RepoTO");
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : repoList", he);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : repoList", dae);
		}
	}
	
	@Override
	public List<CIServerTO> ciList() throws CMMException {
	
		try {
			return (List<CIServerTO>) getHibernateTemplate().find("from CIServerTO");
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : ciList", he);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : ciList", dae);
		}
	}
	
	@Override
	public String getAppNameForAppId(long applicationId) throws CMMException {
	
		Session session = null;
		try {
			session = getSession();
			return (String) session.createCriteria(ApplicationTO.class).add(Restrictions.eq("id", applicationId)).setProjection(Projections.property("appName")).uniqueResult();
		} catch (DataAccessException dae) {
			throw new CMMException("Error in fetching appName for applicationId " + applicationId, dae);
		} catch (HibernateException he) {
			throw new CMMException("Can not fetch data from database for appName", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public ApplicationTO getApplicationDetailsById(Long selectedApplication) throws CMMException {
	
		try {
			return (ApplicationTO) getHibernateTemplate().find("from ApplicationTO where id=?", selectedApplication).get(0);
		} catch (DataAccessException dae) {
			throw new CMMException("Error in fetching Application Details for applicationId " + selectedApplication, dae);
		} catch (HibernateException he) {
			throw new CMMException("Can not fetch data from database for applicationId" + selectedApplication, he);
		}
	}
	
	@Override
	public List<UserGroupTO> getAllUserGrpNames(Long clientId) throws CMMException {
	
		List<UserGroupTO> userGrpList = new ArrayList<UserGroupTO>();
		try {
			String query = String.format("select distinct u from UserGroupTO u, ApplicationTO a where u.id = a.userGroups.id and a.businessUnitTO.id=%d ", clientId);
			userGrpList = (List<UserGroupTO>) getHibernateTemplate().find(query);
		} catch (Exception dae) {
			LOG.error("Error in fetching clientId and UserGroups for clientId ", dae);
			throw new CMMException("Error in fetching clientId and UserGroups for clientId " + dae);
		}
		return userGrpList;
	}
	
	@Override
	public String getSelectedUserGroup(long clientId) throws CMMException {
	
		try {
			String hql = "select name from UserGroupTO u where u.id=?";
			List<String> list = (List<String>) getHibernateTemplate().find(hql, clientId);
			return list.get(0);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getSelectedUserGroup", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getSelectedUserGroup", he);
		}
	}
	
	/*---- app view st----*/
	@Override
	public List<EnvironmentTO> getAllEnvironmentForProject(Long projectId, Long clientId, List<UserGroupTO> userGroupIds, Long userClientId) throws CMMException {
	
		List<EnvironmentTO> envList = new ArrayList<EnvironmentTO>();
		List<Long> grpIds = new ArrayList<Long>();
		Session session = null;
		try {
			Transaction tx = null;
			session = getSession();
			tx = session.beginTransaction();
			Query q = null;
			if (userClientId == 0L) {
				String hql = "SELECT e.id , e.environmentName , e.status FROM EnvironmentTO e where e.id in (SELECT DISTINCT ea.environmentTO.id from EnvironmentApplicationTO ea where ea.applicationTO.id in(select a.id from ApplicationTO a  where  a.businessUnitTO.id=:clientId  and a.projectTO.id=:projectId and a.status=:status )) and e.status in(21L,22L,24L) and e.id not in (select distinct su.environmentId from SubEnvironmentMappingTO su)";
				q = session.createQuery(hql);
				q.setParameter("projectId", projectId);
				q.setParameter("clientId", clientId);
				q.setParameter("status", CMMConstants.Framework.Entity.APPLICATION_AVAILABLE);
			} else {
				for (UserGroupTO groupTO : userGroupIds) {
					grpIds.add(groupTO.getId());
				}
				if (grpIds.isEmpty()) {
					grpIds.add(-1L);
				}
				String hql = "SELECT e.id , e.environmentName , e.status FROM EnvironmentTO e where e.id in (SELECT DISTINCT ea.environmentTO.id from EnvironmentApplicationTO ea where ea.applicationTO.id in(select a.id from ApplicationTO a inner join a.userGroups u where u.id in (:grpId) and a.businessUnitTO.id=:clientId  and a.projectTO.id=:projectId and a.status=:status )) and e.status in(21L,22L,24L) and e.id not in (select distinct su.environmentId from SubEnvironmentMappingTO su)";
				q = session.createQuery(hql);
				q.setParameter("projectId", projectId);
				q.setParameterList("grpId", grpIds);
				q.setParameter("clientId", clientId);
				q.setParameter("status", CMMConstants.Framework.Entity.APPLICATION_AVAILABLE);
			}
			List<Object[]> obj = q.list();
			tx.commit();
			for (Object[] temp : obj) {
				EnvironmentTO environments = new EnvironmentTO();
				environments.setId((Long) temp[0]);
				environments.setEnvironmentName(temp[1].toString());
				environments.setStatus((Long) temp[2]);
				envList.add(environments);
			}
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getAllEnvironmentForProject(List)", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getAllEnvironmentForProject(List)", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return envList;
	}
	
	@Override
	public List<ApplicationTO> getAllAppForEnv(Long envId, Long projectId, Long clientId, List<UserGroupTO> userGroupIds, Long userClientId) throws CMMException {
	
		List<ApplicationTO> appList = new ArrayList<ApplicationTO>();
		List<Long> grpIds = new ArrayList<Long>();
		Session session = null;
		try {
			Transaction tx = null;
			session = getSession();
			tx = session.beginTransaction();
			Query q = null;
			if (userClientId == 0L) {
				String hql = "select a.id , a.appName , a.status FROM ApplicationTO a where a.id in (select a.id from ApplicationTO a , EnvironmentApplicationTO ea   where  a.businessUnitTO.id=:clientId  and a.projectTO.id=:projectId and a.status=:status and ea.environmentTO.id =:envId and  ea.applicationTO.id = a.id)";
				q = session.createQuery(hql);
				q.setParameter("projectId", projectId);
				q.setParameter("clientId", clientId);
				q.setParameter("envId", envId);
				q.setParameter("status", CMMConstants.Framework.Entity.APPLICATION_AVAILABLE);
			} else {
				for (UserGroupTO groupTO : userGroupIds) {
					grpIds.add(groupTO.getId());
				}
				if (grpIds.isEmpty()) {
					grpIds.add(-1L);
				}
				String hql = "select a.id , a.appName , a.status FROM ApplicationTO a , EnvironmentApplicationTO ea where a.id in (select a.id from ApplicationTO a inner join a.userGroups u where u.id in (:grpId) and a.businessUnitTO.id=:clientId  and a.projectTO.id=:projectId and a.status=:status) and ea.environmentTO.id =:envId and ea.applicationTO.id = a.id)";
				q = session.createQuery(hql);
				q.setParameter("projectId", projectId);
				q.setParameterList("grpId", grpIds);
				q.setParameter("envId", envId);
				q.setParameter("clientId", clientId);
				q.setParameter("status", CMMConstants.Framework.Entity.APPLICATION_AVAILABLE);
			}
			List<Object[]> obj = q.list();
			tx.commit();
			for (Object[] temp : obj) {
				ApplicationTO applications = new ApplicationTO();
				applications.setId((Long) temp[0]);
				applications.setAppName(temp[1].toString());
				applications.setStatus((Long) temp[2]);
				appList.add(applications);
			}
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getAllApp(List)", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getAllApp(List)", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return appList;
	}
	
	@Override
	public List<ApplicationTO> selectedSonarApplicationForReport() throws CMMException {
	
		List<ApplicationTO> applicationList = new ArrayList<ApplicationTO>();
		Session session = null;
		Query query = null;
		try {
			session = getSession();
			query = session.createQuery("SELECT distinct a.id,a.appName,a.status FROM ApplicationTO a ,SonarReportsDetailTO s WHERE a.id = s.applicationId and a.status=:availableStatus ORDER BY a.appName");
			query.setLong("availableStatus", CMMConstants.Framework.Entity.APPLICATION_AVAILABLE);
			if (query != null) {
				List<Object[]> queryResultList = query.list();
				for (Object[] result : queryResultList) {
					ApplicationTO application = new ApplicationTO();
					application.setId((Long) result[0]);
					application.setAppName(result[1].toString());
					application.setStatus((Long) result[2]);
					applicationList.add(application);
				}
			}
			return applicationList;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getAllApplications()", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getAllApplications()", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<ApplicationReleaseTO> getApplicationReleaseForReports(Long applicationId) throws CMMException {
	
		List<ApplicationReleaseTO> applicationReleaseForSonarList = new ArrayList<ApplicationReleaseTO>(0);
		List<Object[]> temp;
		try {
			temp = (List<Object[]>) getHibernateTemplate().find("SELECT distinct a.id, a.name from ApplicationReleaseTO a ,SonarReportsDetailTO s where a. id = s. applicationReleaseId and a.applicationId =?", applicationId);
			for (Object[] obj : temp) {
				ApplicationReleaseTO app = new ApplicationReleaseTO();
				app.setId((Long) obj[0]);
				app.setName(obj[1].toString());
				applicationReleaseForSonarList.add(app);
			}
		} catch (DataAccessException | HibernateException dae) {
			throw new CMMException("Problem encountered. ApplicationDAOImpl:getApplicationReleaseForReports", dae);
		}
		return applicationReleaseForSonarList;
	}
	
	@Override
	public List<SonarReportsDetailTO> getSonarRequestIdForReports(Long applicationReleaseId) throws CMMException {
	
		List<SonarReportsDetailTO> requestIdForSonarList = new ArrayList<SonarReportsDetailTO>(0);
		List<Object[]> temp;
		try {
			temp = (List<Object[]>) getHibernateTemplate().find("SELECT distinct s.id, s.folderName from SonarReportsDetailTO s where s. applicationReleaseId = ? ", applicationReleaseId);
			for (Object[] obj : temp) {
				SonarReportsDetailTO app = new SonarReportsDetailTO();
				app.setId((Long) obj[0]);
				app.setFolderName(obj[1].toString());
				requestIdForSonarList.add(app);
			}
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ApplicationDAOImpl:getApplicationReleaseForReports", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ApplicationDAOImpl:getApplicationReleaseForReports", he);
		}
		return requestIdForSonarList;
	}
	
	/*--- app view end ---*/
	@Override
	public long getAppLicationOwnerId(long selectedAppId) throws CMMException {
	
		ApplicationTO appTO = new ApplicationTO();
		try {
			appTO = (ApplicationTO) getHibernateTemplate().find("from ApplicationTO where id=?", selectedAppId).get(0);
		} catch (Exception ex) {
			LOG.error("Problem encountered. ApplicationDAOImpl : getAppLicationOwnerId ", ex);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getAppLicationOwnerId ", ex);
		}
		return appTO.getSelectedOwner();
	}
	
	@Override
	public ApplicationTO getApplicationDetails(long applicationId) throws CMMException {
	
		try {
			List<ApplicationTO> applicationList = (List<ApplicationTO>) getHibernateTemplate().find("from ApplicationTO where id=?", applicationId);
			if (applicationList.isEmpty()) {
				throw new CMMException("No application details found for applicationId:: " + applicationId);
			}
			return applicationList.get(0);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ApplicationDAOImpl:getApplicationDetails", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ApplicationDAOImpl:getApplicationDetails", he);
		}
	}
	
	@Override
	public ApplicationTO getApplicationDetailsForCIReport(List<Long> applicationId) throws CMMException {
	
		try {
			List<ApplicationTO> applicationList = (List<ApplicationTO>) getHibernateTemplate().find("from ApplicationTO where id IN(?)", applicationId);
			if (applicationList.isEmpty()) {
				throw new CMMException("No application details found for applicationId:: " + applicationId);
			}
			return applicationList.get(0);
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ApplicationDAOImpl:getApplicationReleaseForReports", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ApplicationDAOImpl:getApplicationReleaseForReports", he);
		}
	}
	
	@Override
	public MonitoringURLDataTo getURL(MonitoringURLDataTo monitoringURLDataTo) throws CMMException {
	
		try {
			List<Long> selectedEnvironmentURLTemp = new ArrayList<Long>(0);
			List<Long> selectedSoftware = new ArrayList<Long>(0);
			List<EnvironmentApplicationTO> envAppToList = new ArrayList<EnvironmentApplicationTO>(0);
			List<ApplicationReleaseSourcecodeTO> releaseToList = new ArrayList<ApplicationReleaseSourcecodeTO>(0);
			List<Object> machineInfo = new ArrayList<Object>(0);
			List<Long> selectedRElease = new ArrayList<Long>(0);
			List<MonitoringURLDataTo> completeListUrl = new ArrayList<MonitoringURLDataTo>();
			envAppToList = (List<EnvironmentApplicationTO>) getHibernateTemplate().findByNamedParam("from EnvironmentApplicationTO where applicationTO.id in(:appId) and environmentTO.id in (:envId) order by environmentTO.id", new String[] { "appId", "envId" }, new Object[] { monitoringURLDataTo.getSelectedApplicationURL(), monitoringURLDataTo.getSelectedEnvironmentURL() });
			HashMap<String, String> envRelease = new HashMap<String, String>();
			try {
				for (int i = 0; i < envAppToList.size(); i++) {
					selectedRElease.add(envAppToList.get(i).getReleaseId());
					envRelease.put(String.valueOf(envAppToList.get(i).getReleaseId()), String.valueOf(monitoringURLDataTo.getSelectedEnvironmentURL().get(i)));
				}
			} catch (Exception ex) {
				LOG.error("Error encountered. ApplicationDAOImpl : getURL ", ex);
				throw new CMMException("Problem encountered. ApplicationDAOImpl : getURL ", ex);
			}
			releaseToList = (List<ApplicationReleaseSourcecodeTO>) getHibernateTemplate().findByNamedParam("from ApplicationReleaseSourcecodeTO a   where a.id in  (SELECT max(a.id)  FROM ApplicationReleaseSourcecodeTO a   where a.applicationReleaseId in (:releaseId) group by a.applicationReleaseId order by a.applicationReleaseId )", "releaseId", selectedRElease);
			for (int i = 0; i < releaseToList.size(); i++) {
				if (envRelease.size() > 1) {
					selectedEnvironmentURLTemp.add(Long.parseLong(envRelease.get(releaseToList.get(i).getApplicationReleaseId().toString())));
				} else {
					selectedEnvironmentURLTemp.addAll(monitoringURLDataTo.getSelectedEnvironmentURL());
				}
				selectedSoftware.add(releaseToList.get(i).getSoftwareConfigId());
			}
			machineInfo = (List<Object>) getHibernateTemplate().findByNamedParam("from EnvironmentDetailsTO e ,SoftwareTO s ,ProvisionedMachineTO p where e.environment.id in (:envId) and s.id=e.softwareConfig.id and s.type =:softwareType and p.id=e.provisionedMachineId and e.softwareConfig.id  in (:softwareConf) order by e.environment.id", new String[] { "envId", "softwareType", "softwareConf" }, new Object[] { selectedEnvironmentURLTemp, "APPLICATION SERVER", selectedSoftware });
			ArrayList<String> arrIp = new ArrayList<String>();
			for (int i = 0; i < machineInfo.size(); i++) {
				Object arr1[] = (Object[]) machineInfo.get(i);
				for (Object obj : arr1) {
					if (obj instanceof ProvisionedMachineTO) {
						ProvisionedMachineTO t = (ProvisionedMachineTO) obj;
						arrIp.add(t.getIp());
					}
				}
			}
			List<BoaMasterTo> urlList = (List<BoaMasterTo>) getHibernateTemplate().find("from BoaMasterTo");
			for (int i = 0; i < arrIp.size(); i++) {
				MonitoringURLDataTo monitoring = new MonitoringURLDataTo();
				monitoring.setMonitoringUrl("http://" + arrIp.get(i) + ":8080/" + releaseToList.get(i).getContextPath());
				monitoring.setEnvironment(selectedEnvironmentURLTemp.get(i).toString());
				Long stausCode = checkURL(urlList, "http://" + arrIp.get(i) + ":8080/" + releaseToList.get(i).getContextPath());
				if (stausCode == 200) {
					monitoring.setUrlStatus("Active");
				} else {
					monitoring.setUrlStatus("InActive");
				}
				completeListUrl.add(monitoring);
			}
			monitoringURLDataTo.setCompleteUrl(completeListUrl);
		} catch (Exception ex) {
			LOG.error("Problem encountered. ApplicationDAOImpl : getURL ", ex);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getURL ", ex);
		}
		return monitoringURLDataTo;
	}
	
	@Override
	public List<UserTO> getAllSelectedUserNames(long userGroupId) throws CMMException {
	
		List<UserTO> existingUserList = null;
		List<Object[]> temp;
		try {
			temp = (List<Object[]>) getHibernateTemplate().find("SELECT id,name from UserTO where id in(SELECT u.users.id from UserGroupDetailsTO u where u.userGroups.id = ?) ", userGroupId);
			if ((temp != null) && !temp.isEmpty()) {
				existingUserList = new ArrayList<UserTO>();
				for (Object[] obj : temp) {
					UserTO app = new UserTO();
					app.setId((Long) obj[0]);
					app.setName(obj[1].toString());
					existingUserList.add(app);
				}
			}
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ApplicationDAOImpl:getAllSelectedUserNames", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ApplicationDAOImpl:getAllSelectedUserNames", he);
		}
		return existingUserList;
	}
	
	@Override
	public List<UserTO> getAllLeftUserNames(long userGroupId, long clientId) throws CMMException {
	
		List<UserTO> leftUserList = new ArrayList<UserTO>(0);
		List<Object[]> temp;
		try {
			temp = (List<Object[]>) getHibernateTemplate().find("SELECT id,name from UserTO u where id not in(SELECT u.users.id from UserGroupDetailsTO u where u.userGroups.id = ?)and clientId=? ", userGroupId, clientId);
			for (Object[] obj : temp) {
				UserTO app = new UserTO();
				app.setId((Long) obj[0]);
				app.setName(obj[1].toString());
				leftUserList.add(app);
			}
		} catch (DataAccessException dae) {
			throw new CMMException("Problem encountered. ApplicationDAOImpl: getAllLeftUserNames", dae);
		} catch (HibernateException he) {
			throw new CMMException("Problem encountered. ApplicationDAOImpl: getAllLeftUserNames", he);
		}
		return leftUserList;
	}
	
	private void saveUserDetails(UserGroupDetailsTO temp1, Long selectedUserGroup) {
	
		try {
			getHibernateTemplate().save(temp1);
		} catch (Exception ex) {
			LOG.error("Problem encountered. ApplicationDAOImpl : saveUserDetails ", ex);
		}
	}
	
	private UserGroupTO saveUserGroup(UserGroupTO temp) {
	
		getHibernateTemplate().save(temp);
		return temp;
	}
	
	@Override
	public boolean checkUserGroupName(String userGroupName, Long id) throws CMMException {
	
		List<UserGroupTO> groupNameList = null;
		try {
			if (id != null) {
				groupNameList = (List<UserGroupTO>) getHibernateTemplate().find("from UserGroupTO where name=? and id<>?", userGroupName, id);
			} else {
				groupNameList = (List<UserGroupTO>) getHibernateTemplate().find("from UserGroupTO where name=?", userGroupName);
			}
			return !groupNameList.isEmpty();
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getBusinessUnitNames", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getBusinessUnitNames", he);
		}
	}
	
	@Override
	public boolean checkAppCategoryName(String other, String type) throws CMMException {
	
		List<ApplicationCategoryTO> appCategoryList = null;
		try {
			if (type.equals(CMMConstants.Framework.Application.APPLICATION_TYPE_APP)) {
				appCategoryList = (List<ApplicationCategoryTO>) getHibernateTemplate().find("from ApplicationCategoryTO where UPPER(category)=UPPER(?) and categoryType<>?", other, CMMConstants.Framework.ApplicationCategory.CATEGORY_TYPE_SYS);
			}
			if (type.equals(CMMConstants.Framework.Application.APPLICATION_TYPE_SYS)) {
				appCategoryList = (List<ApplicationCategoryTO>) getHibernateTemplate().find("from ApplicationCategoryTO where UPPER(category)=UPPER(?) and categoryType<>?", other, CMMConstants.Framework.ApplicationCategory.CATEGORY_TYPE_APP);
			}
			if ((appCategoryList == null) || appCategoryList.isEmpty()) {
				return false;
			}
			return true;
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : checkAppCategoryName", dae);
		}
	}
	
	public static void sslPass(String fileName) throws CMMException {
	
		try {
			KeyStore keyStore = KeyStore.getInstance("jks");
			InputStream readStream = new FileInputStream(fileName);
			keyStore.load(readStream, "winsso".toCharArray());
			TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance("PKIX");
			trustManagerFactory.init(keyStore);
			final SSLContext sslCntxt = SSLContext.getInstance("SSL");
			sslCntxt.init(null, trustManagerFactory.getTrustManagers(), null);
			HttpsURLConnection.setDefaultSSLSocketFactory(sslCntxt.getSocketFactory());
			HostnameVerifier allHostsValid = new HostnameVerifier() {
				
				@Override
				public boolean verify(String arg0, String arg1) {
				
					return false;
				}
			};
			HttpsURLConnection.setDefaultHostnameVerifier((javax.net.ssl.HostnameVerifier) allHostsValid);
		} catch (KeyStoreException | KeyManagementException | NoSuchAlgorithmException | CertificateException | FileNotFoundException ex) {
			LOG.error("Error encountered. ApplicationDAOImpl : sslPass ", ex);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : sslPass", ex);
		} catch (IOException e) {
			LOG.error("Problem encountered. ApplicationDAOImpl : sslPass ", e);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : sslPass", e);
		}
		TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
			
			@Override
			public java.security.cert.X509Certificate[] getAcceptedIssuers() {
			
				return null;
			}
			
			@Override
			public void checkClientTrusted(java.security.cert.X509Certificate[] arg0, String arg1) throws CertificateException {
			
				/* No implementation required at the moment. Method for future use. */
			}
			
			@Override
			public void checkServerTrusted(java.security.cert.X509Certificate[] arg0, String arg1) throws CertificateException {
			
				/* No implementation required at the moment. Method for future use. */
			}
		} };
		try {
			final SSLContext sslCntxt = SSLContext.getInstance("SSL");
			sslCntxt.init(null, trustAllCerts, new java.security.SecureRandom());
			HttpsURLConnection.setDefaultSSLSocketFactory(sslCntxt.getSocketFactory());
			HostnameVerifier allHostsValid = new HostnameVerifier() {
				
				@Override
				public boolean verify(String arg0, String arg1) {
				
					return false;
				}
			};
			HttpsURLConnection.setDefaultHostnameVerifier((javax.net.ssl.HostnameVerifier) allHostsValid);
		} catch (Exception ex) {
			LOG.error("Problem encountered. ApplicationDAOImpl : sslPass ", ex);
		}
	}
	
	public Long checkURL(List<BoaMasterTo> urlList, String url) {
	
		Long statusCode = null;
		try {
			statusCode = checkingURL(urlList, url);
		} catch (Exception ex) {
			LOG.error("Problem encountered. ApplicationDAOImpl : checkURL ", ex);
		}
		return statusCode;
	}
	
	public Long checkingURL(List<BoaMasterTo> urlList, String checkURL) {
	
		Long urlStatusCode = null;
		try {
			HttpGet request;
			HttpClient client;
			HttpResponse response;
			int code;
			if ("Y".equalsIgnoreCase(urlList.get(0).getActive())) {
				code = proxyChecker(urlList, checkURL);
			} else {
				request = new HttpGet(checkURL);
				client = new DefaultHttpClient();
				response = client.execute(request);
				code = response.getStatusLine().getStatusCode();
			}
			urlStatusCode = (long) code;
		} catch (Exception ex) {
			LOG.error("Problem encountered. ApplicationDAOImpl : CheckingURL ", ex);
		}
		return urlStatusCode;
	}
	
	public Long checkingURLForMonitoring(String checkURL) {
	
		Long urlStatusCode = 404L;
		try {
			HttpGet request;
			HttpClient client;
			HttpResponse response;
			int code;
			request = new HttpGet(checkURL);
			client = new DefaultHttpClient();
			response = client.execute(request);
			code = response.getStatusLine().getStatusCode();
			urlStatusCode = (long) code;
		} catch (Exception ex) {
			LOG.error("Problem encountered. ApplicationDAOImpl : checkingURLForMonitoring ", ex);
		}
		return urlStatusCode;
	}
	
	public int proxyChecker(List<BoaMasterTo> urlList, String checkURL) {
	
		int code = 0;
		try {
			String proxyURL = urlList.get(0).getProxy_url();
			int proxyPort = Integer.parseInt(urlList.get(0).getProxy_port());
			String userName = urlList.get(0).getUserName();
			String password = urlList.get(0).getPassword();
			urlList.get(0).getMachine();
			urlList.get(0).getDomain();
			String sslpath = urlList.get(0).getSsl_path();
			List<String> authpref = new ArrayList<String>();
			authpref.add(AuthPolicy.NTLM);
			Authenticator.setDefault(new ProxyAuthenticator(userName, password));
			System.setProperty("http.proxyHost", proxyURL);
			System.setProperty("http.proxyPort", String.valueOf(proxyPort));
			System.setProperty("https.proxyHost", proxyURL);
			System.setProperty("https.proxyPort", String.valueOf(proxyPort));
			if ((sslpath != null) && !"".equals(sslpath)) {
				sslPass(sslpath);
			}
			URL u = new URL(checkURL);
			if ("https".equals(u.getProtocol())) {
				HttpsURLConnection con = (HttpsURLConnection) u.openConnection();
				code = con.getResponseCode();
			} else {
				HttpURLConnection con = (HttpURLConnection) u.openConnection();
				code = con.getResponseCode();
			}
		} catch (Exception ex) {
			LOG.error("Problem encountered. ApplicationDAOImpl : proxyChecker ", ex);
		}
		return code;
	}
	
	@Override
	public Long fetchApplicationIdByName(String applicationName) throws CMMException {
	
		List<ApplicationTO> applicationList = null;
		try {
			applicationList = (List<ApplicationTO>) getHibernateTemplate().find("from ApplicationTO where appName=?", applicationName);
			if (applicationList.isEmpty()) {
				throw new CMMException("No application found for applicationName " + applicationName);
			} else if (applicationList.size() > 1) {
				throw new CMMException("No Unique application found for applicationName" + applicationName);
			}
			return applicationList.get(0).getId();
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : fetchApplicationIdByName", dae);
		}
	}
	
	@Override
	public List<Long> getSelectedClients(Long id) throws CMMException {
	
		List<UserBusinessUnitTO> buList = (List<UserBusinessUnitTO>) getHibernateTemplate().find("from UserBusinessUnitTO a where a.user.id=?", id);
		List<Long> bulist = new ArrayList<Long>(0);
		for (UserBusinessUnitTO bu : buList) {
			bulist.add(bu.getClientId());
		}
		return bulist;
	}
	
	@Override
	public List<ApplicationTO> getAllApplicationsNew(List<UserGroupTO> userGroupIds, Long id) throws CMMException {
	
		List<ApplicationTO> applicationList = new ArrayList<ApplicationTO>();
		List<Long> grpIds = new ArrayList<Long>();
		Session session = null;
		Transaction tx = null;
		try {
			session = getSession();
			for (UserGroupTO groupTO : userGroupIds) {
				grpIds.add(groupTO.getId());
			}
			if (grpIds.isEmpty()) {
				grpIds.add(-1L);
			}
			tx = session.beginTransaction();
			String hql = "select a.id,a.appName, a.status from ApplicationTO a inner join a.userGroups u inner join a.businessUnitTO where u.id in (:grpId) and a.businessUnitTO.clientId=:id";
			Query q = session.createQuery(hql);
			q.setParameterList("grpId", grpIds);
			q.setLong("id", id);
			List<Object[]> obj = q.list();
			tx.commit();
			for (Object[] temp : obj) {
				ApplicationTO applications = new ApplicationTO();
				applications.setId((Long) temp[0]);
				applications.setAppName(temp[1].toString());
				applications.setStatus((Long) temp[2]);
				applicationList.add(applications);
			}
			return applicationList;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getAllApplications(List)", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getAllApplications(List)", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<ApplicationTO> getAllApplicationsForBu(List<UserGroupTO> userGroupIds, List<Long> clients) throws CMMException {
	
		List<ApplicationTO> applicationList = new ArrayList<ApplicationTO>();
		List<Long> grpIds = new ArrayList<Long>();
		Session session = null;
		Transaction tx = null;
		try {
			session = getSession();
			for (UserGroupTO groupTO : userGroupIds) {
				grpIds.add(groupTO.getId());
			}
			if (grpIds.isEmpty()) {
				grpIds.add(-1L);
			}
			tx = session.beginTransaction();
			String hql = "select a.id,a.appName, a.status from ApplicationTO a inner join a.userGroups u where u.id in (:grpId) and a.businessUnitTO.id in (:clientIdList) and a.status!=52";
			Query q = session.createQuery(hql);
			q.setParameterList("grpId", grpIds);
			q.setParameterList("clientIdList", clients);
			List<Object[]> obj = q.list();
			tx.commit();
			for (Object[] temp : obj) {
				ApplicationTO applications = new ApplicationTO();
				applications.setId((Long) temp[0]);
				applications.setAppName(temp[1].toString());
				applications.setStatus((Long) temp[2]);
				applicationList.add(applications);
			}
			return applicationList;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getAllApplications(List)", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getAllApplications(List)", he);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public ApplicationReleaseTO getReleaseForApplication(Long id, Long environmentId) throws CMMException {
	
		List<EnvironmentApplicationTO> envAppList = (List<EnvironmentApplicationTO>) getHibernateTemplate().find("from EnvironmentApplicationTO where applicationTO.id=? and environmentTO.id =?", id, environmentId);
		ApplicationReleaseTO apprel = new ApplicationReleaseTO();
		if (envAppList.size() > 0L) {
			apprel = envAppList.get(0).getApplicationReleaseTO();
		}
		return apprel;
	}
	
	@Override
	public ApplicationReleaseTO getReleaseForRequest(Long serviceRequestId, Long environmentId, Long serviceId) throws CMMException {
	
		List<ServiceRequestTO> serviceReqTO = (List<ServiceRequestTO>) getHibernateTemplate().find("from ServiceRequestTO where id =? and environmentTO.id =?", serviceRequestId, environmentId);
		ApplicationReleaseTO appreleaseTO = new ApplicationReleaseTO();
		if (serviceReqTO != null) {
			Long releaseId = serviceReqTO.get(0).getApplicationReleaseId();
			List<ApplicationReleaseTO> appreleaseList = (List<ApplicationReleaseTO>) getHibernateTemplate().find("from ApplicationReleaseTO where id =? ", releaseId);
			if ((appreleaseList != null) && !appreleaseList.isEmpty()) {
				appreleaseTO = appreleaseList.get(0);
			}
		}
		return appreleaseTO;
	}
	
	@Override
	public List<ApplicationTO> getAllApplicationsForServicesForRespectiveBUs(List<Long> clientIdList, int tempServiceId) throws CMMException {
	
		List<ApplicationTO> applicationsList = new ArrayList<ApplicationTO>();
		Session session = getSession();
		try {
			if (tempServiceId == 48) {
				String query = "select distinct ss.cron_expression,ss.request_id,ss.application_release_Id,ar.release_name, s.id,s.application_name  from applications s,service_request ss,application_release ar where ss.application_id=s.id  and ar.id=ss.application_release_Id and ss.cron_expression is not null and ss.cron_expression !=''";
				Query q = session.createSQLQuery(query);
				List<Object[]> list = q.list();
				for (Object[] temp : list) {
					ApplicationTO applicationTO = new ApplicationTO();
					applicationTO.setCornStr(temp[0].toString());
					applicationTO.setRequestId(Long.parseLong(temp[1].toString()));
					applicationTO.setReleaseId(Long.parseLong(temp[2].toString()));
					applicationTO.setRelease(temp[3].toString());
					applicationTO.setId(Long.parseLong(temp[4].toString()));
					applicationTO.setAppName(temp[5].toString());
					applicationsList.add(applicationTO);
				}
				return applicationsList;
			}
			if ((clientIdList.size() > 1) || ((clientIdList.size() == 1) && (clientIdList.get(0) != 0))) {
				String query = "select a.id,a.appName, a.status from ApplicationTO a where a.businessUnitTO.clientId in (:clientIdList) and a.status=:availableApplication ORDER BY a.appName";
				Query q = session.createQuery(query);
				q.setParameterList("clientIdList", clientIdList);
				q.setParameter("availableApplication", CMMConstants.Framework.Entity.APPLICATION_AVAILABLE);
				List<Object[]> list = q.list();
				for (Object[] temp : list) {
					ApplicationTO applicationTO = new ApplicationTO();
					applicationTO.setId((Long) temp[0]);
					applicationTO.setAppName(temp[1].toString());
					applicationTO.setStatus((Long) temp[2]);
					applicationsList.add(applicationTO);
				}
				return applicationsList;
			} else {
				String query = "select a.id,a.appName, a.status from ApplicationTO a where a.status=:availableApplication ORDER BY a.appName";
				Query q = session.createQuery(query);
				q.setParameter("availableApplication", CMMConstants.Framework.Entity.APPLICATION_AVAILABLE);
				List<Object[]> list = q.list();
				for (Object[] temp : list) {
					ApplicationTO applicationTO = new ApplicationTO();
					applicationTO.setId((Long) temp[0]);
					applicationTO.setAppName(temp[1].toString());
					applicationTO.setStatus((Long) temp[2]);
					applicationsList.add(applicationTO);
				}
				return applicationsList;
			}
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getApplicationOwner", he);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getApplicationOwner", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<Long> getAppLicationsId(Long id) throws CMMException {
	
		try {
			return (List<Long>) getHibernateTemplate().find("select Distinct a.selectedOwner from ApplicationTO a where id=?", id);
		} catch (DataAccessException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : getSavedClientList", dae);
		} catch (HibernateException he) {
			logger.error(he);
			throw new CMMException("Problem encountered. UserMgmtDAOImpl : getSavedClientList", he);
		}
	}
	
	@Override
	public List<ApplicationTO> getAllApplicationsForCIReport(List<Long> clientId, List<Long> projectId, List<UserGroupTO> userGroupIds, Long userClientId) throws CMMException {
	
		List<ApplicationTO> applicationList = new ArrayList<ApplicationTO>(0);
		List<Long> grpIds = new ArrayList<Long>();
		Session session = getSession();
		try {
			if (userClientId == 0L) {
				applicationList = getAllApplicationsForCIReport(clientId, projectId);
			} else if ((userGroupIds != null) && !userGroupIds.isEmpty()) {
				for (UserGroupTO groupTO : userGroupIds) {
					grpIds.add(groupTO.getId());
				}
				if (grpIds.isEmpty()) {
					grpIds.add(-1L);
				}
				Transaction tx = null;
				tx = session.beginTransaction();
				String hql = "select a.id,a.appName,a.projectTO.id,a.businessUnitTO.id from ApplicationTO a inner join a.userGroups u where u.id in (:grpId) and a.businessUnitTO.id in(:clientId)  and a.projectTO.id IN(:projectId) and a.status=:status";
				Query q = session.createQuery(hql);
				q.setParameterList("grpId", grpIds);
				q.setParameterList("clientId", clientId);
				q.setParameterList("projectId", projectId);
				q.setParameter("status", CMMConstants.Framework.Entity.APPLICATION_AVAILABLE);
				List<Object[]> obj = q.list();
				tx.commit();
				if (!obj.isEmpty()) {
					for (Object[] temp : obj) {
						ApplicationTO applications = new ApplicationTO();
						applications.setId((Long) temp[0]);
						applications.setAppName(temp[1].toString());
						applicationList.add(applications);
					}
				}
			}
		} catch (DataAccessException | HibernateException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getAllApplications(Long, Long, List, Long)", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return applicationList;
	}
	
	@Override
	public List<ApplicationTO> getAllApplicationsForCIReport(List<Long> clientId, List<Long> projectId) throws CMMException {
	
		try {
			List<ApplicationTO> lApplicationTOList = new ArrayList<ApplicationTO>();
			for (Long id : projectId) {
				String query = String.format("SELECT a FROM ApplicationTO a where a.projectTO.id IN(%d) and a.status=%d ", id, CMMConstants.Framework.Entity.APPLICATION_AVAILABLE);
				lApplicationTOList.addAll((List<ApplicationTO>) getHibernateTemplate().find(query));
			}
			return lApplicationTOList;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getAllApplications(Long, Long)", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getAllApplications(Long, Long)", he);
		}
	}
	
	@Override
	public List<ProjectsTO> getAllProjectsForCIReport(List<Long> clientId) throws CMMException {
	
		try {
			List<ProjectsTO> lProjectsTOList = new ArrayList<ProjectsTO>();
			for (Long id : clientId) {
				String query = String.format("Select a from ProjectsTO a where a.clientId IN(%d) and a.status=%d", id, CMMConstants.Framework.Entity.PROJECT_STATUS_EXISTING);
				List<ProjectsTO> listA = (List<ProjectsTO>) getHibernateTemplate().find(query);
				lProjectsTOList.addAll(listA);
			}
			return lProjectsTOList;
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getAllProjects", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.  ApplicationDAOImpl : getAllProjects", he);
		}
	}
	
	@Override
	public List<RoleTO> getAllRoles() throws CMMException {
	
		List<RoleTO> roles = new ArrayList<RoleTO>(0);
		try {
			roles = (List<RoleTO>) getHibernateTemplate().find("from RoleTO where status =?", CMMConstants.Framework.Entity.ROLE_STATUS_ACTIVE);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getAllRoles", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.  ApplicationDAOImpl : getAllRoles", he);
		}
		return roles;
	}
	
	@Override
	public List<ApplicationCategoryTO> getApplicationCategoryList() throws CMMException {
	
		List<ApplicationCategoryTO> applicationCategoryList = null;
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(ApplicationCategoryTO.class, "applicationCategoryTO");
			criteria.addOrder(Order.asc("category"));
			applicationCategoryList = (List<ApplicationCategoryTO>) getHibernateTemplate().findByCriteria(criteria);
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getApplicationCategoryList", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.  ApplicationDAOImpl : getApplicationCategoryList", he);
		}
		return applicationCategoryList;
	}
	
	@Override
	public List<ApplicationTO> getDependentSystem(List<Long> clientIdlist) throws CMMException {
	
		List<ApplicationTO> dependentSystemTOList = new ArrayList<ApplicationTO>();
		Session session = getSession();
		int flag = 0;
		try {
			for (Long clientId : clientIdlist) {
				if (clientId == 0) {
					flag = 1;
				}
			}
			if (flag == 1) {
				String query = String.format("Select a from ApplicationTO a where a.status=%d", CMMConstants.Framework.Entity.APPLICATION_AVAILABLE);
				dependentSystemTOList = (List<ApplicationTO>) getHibernateTemplate().find(query);
			} else {
				String hql = "select a.id, a.appName from ApplicationTO a where a.status=? and a.clientId in (:userId)";
				Query q = session.createQuery(hql);
				q.setParameterList("userId", clientIdlist);
				q.setLong(0, CMMConstants.Framework.Entity.APPLICATION_AVAILABLE);
				List<Object[]> obj = q.list();
				for (Object[] temp : obj) {
					ApplicationTO application = new ApplicationTO();
					application.setId((Long) temp[0]);
					application.setAppName((String) temp[1]);
					dependentSystemTOList.add(application);
				}
			}
			return dependentSystemTOList;
		} catch (DataAccessException | HibernateException dae) {
			logger.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getDependentSystem", dae);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public Long fetchAppServerIDByName(String serverName) throws CMMException {
	
		long softwareId = 0;
		try {
			List<SoftwareTO> softList = (List<SoftwareTO>) getHibernateTemplate().find("from SoftwareTO s where s.name = ?", serverName);
			if (!softList.isEmpty()) {
				softwareId = softList.get(0).getId();
			}
		} catch (DataAccessException dae) {
			LOG.error(dae);
			throw new CMMException("Problem encountered. ApplicationDAOImpl : getApplicationCategoryList", dae);
		} catch (HibernateException he) {
			LOG.error(he);
			throw new CMMException("Problem encountered.  ApplicationDAOImpl : getApplicationCategoryList", he);
		}
		return softwareId;
	}
}