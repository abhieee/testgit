package com.ext.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.to.UserGroupDetailsTO;
import com.framework.to.UserGroupTO;
import com.framework.to.UserTO;

public interface UserGroupDAO {
	
	List<UserTO> getUserNamesForApp(long appId) throws CMMException;
	
	List<Object> getapplicationNames() throws CMMException;
	
	List<UserTO> getAllUserNames(Long appid) throws CMMException;
	
	UserGroupTO getUserGrpName(Long appid) throws CMMException;
	
	void userGrpUpdate(UserGroupDetailsTO userGrpDtlsTO) throws CMMException;
	
	List<String> getAllUserEmails(Long appid) throws CMMException;
}
