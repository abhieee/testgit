package com.ext.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.to.ApplicationReleasePhaseTO;
import com.framework.to.ReleasePlanningTO;
import com.framework.to.TestingPhaseTO;

public interface PhaseManagementDAO {
	
	List<ApplicationReleasePhaseTO> getPhaseListforServiceManagement(Long selectedApplication, Long selectedReleasePlan) throws CMMException;
	
	List<ApplicationReleasePhaseTO> getPhaseListforServiceManagement(Long selectedApplication) throws CMMException;
	
	/**
	 * Save the testing phases which are selected for a specific release corresponding to a specific application profile.
	 *
	 * @param releasePhaseList
	 *                The release phase list containing values of selected testing phases.
	 * @param releaseId
	 *                The release phase id for which the release phase is selected.
	 */
	void saveTestingPhases(List<ApplicationReleasePhaseTO> releasePhaseList, Long applicationId, Long releasePlanId) throws CMMException;
	
	/**
	 * Search the testing phases for a specific release corresponding to a specific application profile, which further corresponds to a specific
	 * application.
	 *
	 * @param selectedReleaseId
	 *                The release phase id for which the testing phases are to be displayed.
	 * @return The list of all the testing phases which correspond to selected release id.
	 */
	List<TestingPhaseTO> searchAlltestingPhases(Long applicationId, Long releasePlanId) throws CMMException;
	
	public List<TestingPhaseTO> getReleasePlanTestingPhases(Long releasePlanId) throws CMMException;
	
	List<ReleasePlanningTO> getReleasePlanning(Long id) throws CMMException;
	
	List<TestingPhaseTO> getAllTestingCycles(Long id) throws CMMException;
}