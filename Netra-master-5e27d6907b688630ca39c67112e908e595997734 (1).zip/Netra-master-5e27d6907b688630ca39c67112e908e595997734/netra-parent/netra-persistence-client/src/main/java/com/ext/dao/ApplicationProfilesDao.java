package com.ext.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.nolio.to.NolioProcessParametersTO;
import com.framework.to.ApplicationProfileDockerTO;
import com.framework.to.ApplicationProfileMappingTO;
import com.framework.to.ApplicationProfileTO;
import com.framework.to.ApplicationProfilesServerSetTO;
import com.framework.to.ApplicationReleasePhaseTO;
import com.framework.to.ApplicationTO;
import com.framework.to.MachineTO;
import com.framework.to.MachineTemplateTO;
import com.framework.to.MachineTypeTO;
import com.framework.to.PlatformTemplateTO;
import com.framework.to.ProvisionedMachineTO;
import com.framework.to.ProvisionedPlatformTO;
import com.framework.to.TemplateVMWareTO;
import com.framework.to.TemplatesAwsTO;
import com.framework.to.UserGroupTO;

public interface ApplicationProfilesDao {
	
	List<MachineTypeTO> getMachineTypeList() throws CMMException;
	
	List<TemplatesAwsTO> getAWSEC2Images(Long awsAccountId) throws CMMException;
	
	List<ApplicationTO> getAllApplicationsforProfile(Long clientId, List<UserGroupTO> userGroupIds) throws CMMException;
	
	List<ApplicationTO> getSelectedApplications(Long[] selectedApp) throws CMMException;
	
	/**
	 * The function sets the values of various application fields on the JSP page corresponding to that application.
	 *
	 * @param profileId
	 *                The Id for which the details are to be fetched.
	 * @return ApplicationProfileTO in which all the values are set.
	 */
	ApplicationProfileTO getApplicationProfile(Long applicationProfileId) throws CMMException;
	
	/**
	 * Edit function provides the facility to edit the details of any application.This function converts the bean object into ApplicationTO.
	 *
	 * @param userId
	 *                The id of logged in user.
	 * @param applicationProfileTO
	 *                Details of application in form of TO.
	 * @return ApplicationProfileTO in which all the new values are set and to be displayed on the jsp.
	 */
	ApplicationProfileTO editApplicationProfile(ApplicationProfileTO applicationProfileTO, Long userId) throws CMMException;
	
	Long addApplicationProfile(String profileName, String[] selectedApplicationsList, List<ApplicationProfilesServerSetTO> machineSetTo, Long userId, String monitoringRequired) throws CMMException;
	
	MachineTO getMachineDetailsById(long machineId) throws CMMException;
	
	List<NolioProcessParametersTO> getSoftwareProperties(Long softwareConfigId) throws CMMException;
	
	List<TemplateVMWareTO> getVMwareImages() throws CMMException;
	
	List<ProvisionedMachineTO> fetchPhysicalMachinesDetails() throws CMMException;
	
	List<ProvisionedMachineTO> fetchPhysicalMachinesDetailsByName(ProvisionedMachineTO provisionedMachineTO) throws CMMException;
	
	ApplicationProfileTO getProfileDetails(Long profileId) throws CMMException;
	
	MachineTemplateTO getMachineDetails(Long macId) throws CMMException;
	
	PlatformTemplateTO getPlatformDetails(Long platformId) throws CMMException;
	
	ProvisionedMachineTO getExistingMachineDetails(Long existingMacId) throws CMMException;
	
	ProvisionedPlatformTO getExistingPlatformDetails(Long existingPlatformId) throws CMMException;
	
	boolean checkProfileName(String profileName) throws CMMException;
	
	boolean checkProfileNameEdit(String profileName, Long id) throws CMMException;
	
	List<String> getBUNameForSelectedApplicationProfile(String profileName) throws CMMException;
	
	boolean searchIfServerNameAlreadyExist(List<Long> applicationIds, String serverName) throws CMMException;
	
	boolean searchIfServerNameAlreadyExistEdit(List<Long> applicationIds, String serverName, Long rownumber) throws CMMException;
	
	Long getApplicationProfileIDByName(String applicationProfileName) throws CMMException;
	
	ApplicationProfileDockerTO getProfileDetailsDocker(Long profileId) throws CMMException;
	
	boolean checkAppProfileEnvMapping(Long appId, Long profileId, Long envId) throws CMMException;
	
	public List<ApplicationProfileMappingTO> getAppProfileMapping(Long appId) throws CMMException;
	
	public List<ApplicationReleasePhaseTO> getAppRelPhaseMapping(Long appId) throws CMMException;
	
	Long fetchReleasePlan(Long selectedRelease) throws CMMException;
	
	Long fetchRepositoryDb(Long repoId) throws CMMException;
	
	Long fetchRepositoryForSourceCode(Long repoId) throws CMMException;
}
