/**
 *
 */
package com.ext.puppet.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.puppetMaster.to.PuppetProcess;
import com.framework.puppetMaster.to.PuppetProcessParametersTO;
import com.framework.puppetMaster.to.PuppetProcessSoftwareMapping;
import com.framework.to.SoftwareTO;

/**
 * @author 556214
 */
public interface PuppetProcessDao {
	
	PuppetProcess getPuppetProcessInfoByProcessId(long processId) throws CMMException;
	
	PuppetProcess addPuppetProcess(PuppetProcess puppetProcess) throws CMMException;
	
	List<PuppetProcess> searchPuppetProcess(PuppetProcess puppetProcess) throws CMMException;
	
	PuppetProcess getPuppetProcessDetails(PuppetProcess puppetProcess) throws CMMException;
	
	void editPuppetProcessDetails(PuppetProcess puppetProcess) throws CMMException;
	
	List<SoftwareTO> getSoftwareList() throws CMMException;
	
	List<Long> getPuppetProcessForOS(long osType) throws CMMException;
	
	List<PuppetProcess> getAllPuppetProcess() throws CMMException;
	
	boolean definePuppetProcessForSoftware(PuppetProcessSoftwareMapping mapping) throws CMMException;
	
	PuppetProcess getPuppetProcessInfoByProcessName(String processFullPath) throws CMMException;
	
	PuppetProcessParametersTO getParams(PuppetProcessParametersTO puppetProcessParametersTO) throws CMMException;
	
	List<PuppetProcessParametersTO> searchPuppetParameters(PuppetProcessParametersTO puppetProcessParametersTO) throws CMMException;
	
	boolean updateParameters(PuppetProcessParametersTO puppetProcessParametersTO) throws CMMException;
	
	boolean deleteParameters(PuppetProcessParametersTO puppetProcessParametersTO) throws CMMException;
}