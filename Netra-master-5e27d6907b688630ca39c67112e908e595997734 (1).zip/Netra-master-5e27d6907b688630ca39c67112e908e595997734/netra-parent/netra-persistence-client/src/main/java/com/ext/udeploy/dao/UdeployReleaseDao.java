package com.ext.udeploy.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.udeploy.to.UdeployReleaseDetailsTO;

public interface UdeployReleaseDao {
	
	List<UdeployReleaseDetailsTO> searchUdeployRelease(UdeployReleaseDetailsTO udeployReleaseDetailsTO) throws CMMException;
	
	UdeployReleaseDetailsTO loadUdeployRelease(UdeployReleaseDetailsTO udeployReleaseDetailsTO) throws CMMException;
	
	void editUdeployRelease(UdeployReleaseDetailsTO udeployReleaseDetailsTO) throws CMMException;
	
	boolean addUdeployProcessesInDB(List<String> processList) throws CMMException;
}
