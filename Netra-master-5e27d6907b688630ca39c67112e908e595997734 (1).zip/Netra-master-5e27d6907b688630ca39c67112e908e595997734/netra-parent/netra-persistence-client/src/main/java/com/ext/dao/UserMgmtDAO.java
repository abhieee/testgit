package com.ext.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.to.BusinessUnitTO;
import com.framework.to.ClientTO;
import com.framework.to.DelegatedUserTO;
import com.framework.to.ForgotPassTO;
import com.framework.to.SecurityAnswersTO;
import com.framework.to.StatusTO;
import com.framework.to.UserBusinessUnitTO;
import com.framework.to.UserGroupTO;
import com.framework.to.UserTO;

/**
 * @author TCS
 */
public interface UserMgmtDAO {
	
	UserTO getUserById(UserTO userTO) throws CMMException;
	
	UserTO fetchUserDetails(Long num) throws CMMException;
	
	UserTO getUserProfileById(UserTO userTO) throws CMMException;
	
	void addUser(UserTO userTO) throws CMMException;
	
	void changePassword(UserTO userTO) throws CMMException;
	
	Long deleteUser(UserTO userTO) throws CMMException;
	
	List<String> getAllUserNames() throws CMMException;
	
	List<ClientTO> getAllClients(Long clientId) throws CMMException;
	
	List<StatusTO> getStatusList() throws CMMException;
	
	List<UserTO> searchUser(UserTO userTO, List<BusinessUnitTO> businessUnitTOList) throws CMMException;
	
	List<UserTO> searchLdapUser(UserTO userTO) throws CMMException;
	
	List<Long> getUserRoles(UserTO userTO) throws CMMException;
	
	void modifyUser(UserTO userTO) throws CMMException;
	
	void modifyUserProfile(UserTO userTO) throws CMMException;
	
	List<ClientTO> getAllClientsForAccessMgmt() throws CMMException;
	
	String getUserStatusDesc(Long status) throws CMMException;
	
	UserTO getUserByName(String username) throws CMMException;
	
	boolean checkUsername(UserTO userTO) throws CMMException;
	
	List<UserTO> getAllUsers() throws CMMException;
	
	String fetchEmailIds(Long applicationId) throws CMMException;
	
	List<UserTO> getSupervisorUserNames(List<Long> clientList, Long roleId) throws CMMException;
	
	List<UserTO> getThisWeekAddedUserList() throws CMMException;
	
	List<UserTO> getAllUserNamesForEditSupervisor(List<Long> clientId, Long roleId, Long userId) throws CMMException;
	
	List<Object[]> getUserRequests(UserTO userTO) throws CMMException;
	
	List<UserGroupTO> getUserGroupByUserId(Long id) throws CMMException;
	
	String getUserEmailByRequestId(Long requestId) throws CMMException;
	
	List<BusinessUnitTO> getSavedClientList(Long userId) throws CMMException;
	
	List<BusinessUnitTO> getBUName(List<UserBusinessUnitTO> userBusinessUnitTO) throws CMMException;
	
	Long forgotPass(String username) throws CMMException;
	
	List<String> getSecurityQusetions();
	
	void setSecurityQA(SecurityAnswersTO security_ans, Long user_id);
	
	List<String> getSecurityQuesForPwd();
	
	ForgotPassTO getForgotPwd(ForgotPassTO forgotPassTO);
	
	void changeForgotPwd(ForgotPassTO forgotPassTO);
	
	UserBusinessUnitTO getUserBusinessUnitTODetailsForClientId(Long clientId) throws CMMException;
	
	UserTO getUserDetails(Long userId) throws CMMException;
	
	Boolean checkQuesExist(String username);
	
	String getOldPassword(Long userId);
	
	List<UserTO> getUserDetails(String userName) throws CMMException;
	
	List<UserTO> searchUserActiveDirectory(String username);
	
	public List<UserTO> searchUser(UserTO userTO) throws CMMException;
	
	public boolean delegateAccess(DelegatedUserTO delegatedUserTO) throws CMMException;
	
	public UserTO revokeAccess(Long userId) throws CMMException;
	
	public boolean revokeAccessSubmit(Long userId) throws CMMException;
	
	public boolean checkUserAlreadyDeledgated(Long userId) throws CMMException;
	
	public boolean checkDelegationDoneAlready(Long userId) throws CMMException;
}