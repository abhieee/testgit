package com.ext.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.to.TestingToolTO;
import com.framework.to.TestingToolsTO;

public interface UtilityDAO {
	
	TestingToolsTO getTestingToolsDetails(Long requestId, Long testToolId) throws CMMException;
	
	TestingToolsTO fetchTestingToolsDetails(Long applicationId, Long testToolId) throws CMMException;
	
	List<TestingToolTO> getTestData() throws CMMException;
	
	String getPortForSoftware(Long envDetailsId) throws CMMException;
}
