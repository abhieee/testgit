package com.ext.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.to.ApplicationTO;
import com.framework.to.EnvironmentTO;
import com.framework.to.SubAppTO;

public interface SubApplicationMgmntDAO {
	
	List<Object> getapplicationNames() throws CMMException;
	
	List<ApplicationTO> getAllSubApps(Long appid) throws CMMException;
	
	List<ApplicationTO> getAllSubAppsRight(Long appid) throws CMMException;
	
	void subAppUpdate(SubAppTO subAppTO) throws CMMException;
	
	List<EnvironmentTO> getEnvs(Long appId) throws CMMException;
}
