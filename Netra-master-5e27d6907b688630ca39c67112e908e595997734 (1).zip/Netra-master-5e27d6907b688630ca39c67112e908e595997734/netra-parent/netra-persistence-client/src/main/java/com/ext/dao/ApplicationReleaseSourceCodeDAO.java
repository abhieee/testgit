package com.ext.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.to.ApplicationReleaseSourcecodeTO;

/**
 * @author 460650
 */
public interface ApplicationReleaseSourceCodeDAO {
	
	List<ApplicationReleaseSourcecodeTO> getAppReleaseSourceCodeByRequestId(long requestId, long softwareConfigId) throws CMMException;
	
	List<ApplicationReleaseSourcecodeTO> getAppReleaseSourceCodeByReleaseId(long applicationReleaseId) throws CMMException;
	
	public List<ApplicationReleaseSourcecodeTO> getAppReleaseSourceCodeByReleaseAndPhaseId(long applicationReleaseId, long phaseId) throws CMMException;
	
	boolean saveNetraPathTODB(String nolioServerPath, Long id) throws CMMException;
	
	boolean saveNetraNexusPath(String netraNexusPath, Long sourceCodeId) throws CMMException;
}
