package com.ext.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.to.MachineTemplateBareMetalTO;
import com.framework.to.MachineTemplateTO;
import com.framework.to.PlatformTemplateBareMetalTO;
import com.framework.to.PlatformTemplateTO;
import com.framework.to.PlatformTypeTO;
import com.framework.to.StatusTO;

public interface VMWareBareMetalDAO {
	
	List<PlatformTypeTO> getDistributionListforFamilyType(String selectedFamilyType) throws CMMException;
	
	List<PlatformTypeTO> getAllPlatformTypes() throws CMMException;
	
	List<PlatformTypeTO> getVersionListforDistribution(String selectedDistribution) throws CMMException;
	
	List<PlatformTypeTO> getPackListforVersion(String selectedVersion) throws CMMException;
	
	String getHDSize(String name) throws CMMException;
	
	Boolean checkName(String name) throws CMMException;
	
	Boolean checkNameEdit(PlatformTemplateTO platformTemplateTO) throws CMMException;
	
	PlatformTemplateTO getPlatformDetails(PlatformTemplateTO platformTemplateTO) throws CMMException;
	
	Boolean editTemplateSubmit(MachineTemplateBareMetalTO machineTemplateBareMetalTO, MachineTemplateTO machineTemplateTO, PlatformTemplateBareMetalTO platformTemplateBareMetalTO, PlatformTemplateTO platformTemplateTO) throws CMMException;
	
	List<PlatformTemplateTO> searchVMWareBareMetal(PlatformTemplateTO platformTemplateTO, MachineTemplateBareMetalTO machineTemplateBareMetalTO) throws CMMException;
	
	Boolean addTemplate(MachineTemplateBareMetalTO machineTemplateBareMetalTO, MachineTemplateTO machineTemplateTO, PlatformTemplateBareMetalTO platformTemplateBareMetalTO, PlatformTemplateTO platformTemplateTO) throws CMMException;
	
	List<StatusTO> getStatusList() throws CMMException;
}
