/**
 *
 */
package com.ext.puppet.dao;

import java.sql.SQLException;
import java.util.List;
import com.framework.exception.CMMException;
import com.framework.puppetMaster.to.PuppetProcess;
import com.framework.puppetMaster.to.PuppetProcessParametersTO;

/**
 * @author 584175
 */
public interface PuppetProcessParameterDao {
	
	void updateParameterValue(long parameterId, String parameterValue) throws CMMException;
	
	PuppetProcessParametersTO getPuppetParameters(long parameterId) throws CMMException;
	
	/**
	 * method to fetch parameters for applicationReleaseDb through procedure call
	 *
	 * @param applicationReleaseDbId
	 *                for which parameters are to be fetched
	 * @throws CMMException
	 */
	long fetchParameters(long serviceId, long applicationReleaseDbId, String rollback) throws CMMException, SQLException;
	
	List<PuppetProcess> getAllPuppetProcessList() throws CMMException;
}
