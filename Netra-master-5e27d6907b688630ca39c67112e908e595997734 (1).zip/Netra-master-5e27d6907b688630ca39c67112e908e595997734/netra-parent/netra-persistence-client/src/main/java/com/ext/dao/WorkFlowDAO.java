package com.ext.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.to.ApplicationTO;
import com.framework.to.ReservationTO;
import com.framework.to.RoleTO;
import com.framework.to.WorkFlowLevelTO;
import com.framework.to.WorkFlowRequestTO;
import com.framework.to.WorkFlowTO;
import com.framework.to.WorkflowCurrentTO;
import com.framework.to.WorkflowStatusTO;

public interface WorkFlowDAO {
	
	List<WorkFlowTO> getWorkFlowActionList() throws CMMException;
	
	void defineWorkflow(WorkFlowLevelTO workFlowLevelTO) throws CMMException;
	
	List<RoleTO> getDefinedRoles(WorkFlowLevelTO workFlowLevelTO) throws CMMException;
	
	List<WorkflowCurrentTO> searchWorkList(WorkflowCurrentTO workflowCurrentTO) throws CMMException;
	
	WorkFlowRequestTO viewEnvReqWorkflow(Long reqId) throws CMMException;
	
	List<WorkflowStatusTO> getStatusList() throws CMMException;
	
	List<WorkFlowLevelTO> checkWorkFlowDefined(long clientId, long workFlowId) throws CMMException;
	
	WorkflowCurrentTO approveRequest(WorkFlowRequestTO workFlowRequestTO) throws CMMException;
	
	ApplicationTO fetchApplication(Long appId) throws CMMException;
	
	List<WorkflowCurrentTO> onLoadWorkList(Long userId) throws CMMException;
	
	List<WorkflowCurrentTO> onLoadWorkList(Long userId, List<Long> clientIdlist) throws CMMException;
	
	void rejectRequest(WorkFlowRequestTO workFlowRequestTO) throws CMMException;
	
	List<WorkflowCurrentTO> searchWorkListForAdim(WorkflowCurrentTO workflowCurrentTO) throws CMMException;
	
	WorkflowCurrentTO updateRequest(WorkFlowRequestTO workFlowRequestTO) throws CMMException;
	
	WorkflowCurrentTO fetchWorkflowDetail(Long parentRequestId) throws CMMException;
	
	void updatePipelineRequestDetail(Long serviceRequestId) throws CMMException;
	
	WorkflowCurrentTO returnWorkFlowServiceId(Long userId) throws CMMException;
	
	List<WorkflowCurrentTO> onLoadWorkListForAgentDeployment(Long userId) throws CMMException;
	
	List<WorkflowCurrentTO> onLoadWorkListForAgentDeployment(Long userId, List<Long> clientIdlist) throws CMMException;
	
	List<WorkflowCurrentTO> searchWorkListForAgentDeployment(WorkflowCurrentTO workflowCurrentTO) throws CMMException;
	
	WorkFlowRequestTO viewEnvReqWorkflowForAgentDeployment(Long reqId) throws CMMException;
	
	String fetchRemarks(WorkflowCurrentTO wct) throws CMMException;
	
	List<ReservationTO> fetchChildReservations(Long entity_id) throws CMMException;
	
	Long getIsRepetitiveReservation(Long entity_id) throws CMMException;
	
	List<ReservationTO> fetchConflictForChild(List<ReservationTO> childReservations) throws CMMException;
	
	List<ReservationTO> viewChildConfict(Long parentReservationId) throws CMMException;
	
	String getReservationToDate(Long entityId) throws CMMException;
	
	Long getWorkflowHistoryId(Long workFlowCurrentId) throws CMMException;
	
	Long getUserIdFrmDelegationId(Long id) throws CMMException;
}
