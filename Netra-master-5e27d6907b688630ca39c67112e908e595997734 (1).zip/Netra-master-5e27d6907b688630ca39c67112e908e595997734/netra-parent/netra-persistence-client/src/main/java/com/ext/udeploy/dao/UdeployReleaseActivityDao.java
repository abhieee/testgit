package com.ext.udeploy.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.to.ProvisionedMachinePhysicalTO;
import com.framework.to.SoftwareTO;
import com.framework.to.SoftwareconfigTO;
import com.framework.udeploy.to.UdeployActivitySoftwareMappingTO;
import com.framework.udeploy.to.UdeployReleaseActivityTO;
import com.framework.udeploy.to.UdeployReleaseDetailsTO;

public interface UdeployReleaseActivityDao {
	
	List<UdeployReleaseActivityTO> getAllActivity() throws CMMException;
	
	List<UdeployReleaseActivityTO> getAllUdeployReleaseActivities() throws CMMException;
	
	boolean defineUdeployActivitiesForSoftware(UdeployActivitySoftwareMappingTO udeployActivitySoftwareMappingTO) throws CMMException;
	
	List<UdeployReleaseActivityTO> getUdeploySoftwareActivitites(Long softwareConfigId) throws CMMException;
	
	long fetchMappedActivitySoftwareId(long activityId, long softwareId) throws CMMException;
	
	List<UdeployReleaseActivityTO> getAllRemainingActivities() throws CMMException;
	
	String fetchMappedSoftwareType(Long mappedSoftwareId) throws CMMException;
	
	List<UdeployReleaseDetailsTO> getUdeployReleaseList() throws CMMException;
	
	List<ProvisionedMachinePhysicalTO> getClientDetailsList(String ip) throws CMMException;
	
	SoftwareconfigTO addSoftwareUdeployMapDetails(SoftwareTO scTO) throws CMMException;
}
