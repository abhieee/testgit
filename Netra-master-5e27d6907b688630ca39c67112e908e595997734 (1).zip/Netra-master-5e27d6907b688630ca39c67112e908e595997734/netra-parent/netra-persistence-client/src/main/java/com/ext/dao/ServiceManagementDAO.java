package com.ext.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.to.ServiceTO;
import com.framework.to.ServiceTypeTO;
import com.framework.to.StatusTO;

public interface ServiceManagementDAO {
	
	List<ServiceTypeTO> getCatalogType() throws CMMException;
	
	void getBusinessUnits();
	
	void addService(ServiceTO serviceTO) throws CMMException;
	
	List<ServiceTO> searchService(ServiceTO serviceTO) throws CMMException;
	
	ServiceTO getServicesDetails(ServiceTO serviceTO) throws CMMException;
	
	void editService(ServiceTO serviceTO) throws CMMException;
	
	List<StatusTO> getStatusList(String entityId) throws CMMException;
	
	boolean checkExistingService(ServiceTO serviceTO) throws CMMException;
	
	List<Long> getselectedRoles(List<Long> clients, Long serviceId) throws CMMException;
}
