package com.ext.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.to.ItemDetails;

public interface ZabbixDAO {
	
	List<ItemDetails> getHostDetails(String itemName, long timeFrom, long timeTill) throws CMMException;
}
