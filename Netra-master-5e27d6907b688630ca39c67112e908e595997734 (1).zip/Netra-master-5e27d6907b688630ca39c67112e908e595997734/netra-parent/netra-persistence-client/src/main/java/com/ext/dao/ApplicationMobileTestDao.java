/**
 * 
 */
package com.ext.dao;

import com.framework.exception.CMMException;
import com.framework.to.ApplicationMobileTestingTO;

/**
 * @author 460650
 */
public interface ApplicationMobileTestDao {
	
	/**
	 * Fetch mobile test details by requestId.
	 * 
	 * @param requestId
	 *                of service requested
	 * @throws CMMException
	 *                 Custom Exception
	 */
	public ApplicationMobileTestingTO fetchMobileTestDetails(long requestId) throws CMMException;
	
	/**
	 * Save mobile testing details.
	 * 
	 * @param applicationMobileTestingTO
	 * @throws CMMException
	 *                 custom Exception
	 */
	public void saveMobileTestingDetails(ApplicationMobileTestingTO applicationMobileTestingTO) throws CMMException;
	
	/**
	 * Update script execution report
	 * 
	 * @param requestId
	 *                of Service Request
	 * @param perfectoReportName
	 * @throws CMMException
	 *                 custom Exception
	 */
	public void saveMobileTestReport(long requestId, String perfectoReportName) throws CMMException;
}
