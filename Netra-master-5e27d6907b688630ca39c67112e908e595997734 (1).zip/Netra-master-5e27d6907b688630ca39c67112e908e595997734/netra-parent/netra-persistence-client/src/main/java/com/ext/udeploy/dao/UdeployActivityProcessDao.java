package com.ext.udeploy.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.udeploy.to.UdeployActivityExecOrderTO;
import com.framework.udeploy.to.UdeployActivityProcessOrderTO;
import com.framework.udeploy.to.UdeployReleaseActivityTO;

/**
 * @author 460650
 */
public interface UdeployActivityProcessDao {
	
	List<UdeployActivityProcessOrderTO> fetchUdeploySoftProcessMapByActivityID(long mapActivityId) throws CMMException;
	
	void saveOrderedUdeployProcessForActivity(UdeployReleaseActivityTO udeployReleaseActivityTO) throws CMMException;
	
	void saveOrderedActivities(UdeployReleaseActivityTO udeployReleaseActivityTO) throws CMMException;
	
	List<UdeployActivityProcessOrderTO> fetchUdeployProcessOrder(UdeployReleaseActivityTO udeployReleaseActivityTO) throws CMMException;
	
	List<UdeployActivityExecOrderTO> fetchOrderedActivities(UdeployReleaseActivityTO udeployReleaseActivityTO) throws CMMException;
}
