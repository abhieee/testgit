/**
 *
 */
package com.ext.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.to.PlatformMasterTO;

/**
 * @author 460650
 */
public interface PlatformMasterDAO {
	
	List<PlatformMasterTO> fetchAllPlatforms() throws CMMException;
}
