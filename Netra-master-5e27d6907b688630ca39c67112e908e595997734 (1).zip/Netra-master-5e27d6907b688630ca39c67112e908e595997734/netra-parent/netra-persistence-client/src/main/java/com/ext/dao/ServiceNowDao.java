package com.ext.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.to.ImportTablesTO;
import com.framework.to.PlatformTypeTO;
import com.framework.to.SNColumnMappingTO;
import com.framework.to.ServiceNowConfigTO;
import com.framework.to.ServiceRequestDetailsTO;
import com.framework.to.ServiceRequestTO;
import com.framework.to.TransformMapConfigTO;
import com.framework.to.TransfromMapTO;
import com.framework.to.UserTO;

public interface ServiceNowDao {
	
	ServiceNowConfigTO fetchSNServer(String baseURL) throws CMMException;
	
	List<ImportTablesTO> searchSNTableNames() throws CMMException;
	
	List<ImportTablesTO> searchNetraTableNames() throws CMMException;
	
	boolean saveTMap(TransformMapConfigTO transformMapConfigTO, SNColumnMappingTO snColumnMapping) throws CMMException;
	
	boolean saveEditTMap(TransformMapConfigTO transformMapConfigTO, SNColumnMappingTO snColumnMapping) throws CMMException;
	
	boolean checkIfMapNameExists(String mapName) throws CMMException;
	
	boolean checkIfBaseURLExists(String baseURL) throws CMMException;
	
	List<TransformMapConfigTO> searchTMaps(String mapName) throws CMMException;
	
	TransformMapConfigTO getTransformConfigData(String mapName) throws CMMException;
	
	List<SNColumnMappingTO> getColumnNames(Long tMapId) throws CMMException;
	
	ServiceRequestTO importDataDB(ServiceRequestTO serviceNowRequestTO, List<Long> tmapID) throws CMMException;
	
	List<ServiceRequestDetailsTO> getServiceRequestDetails(Long requestID) throws CMMException;
	
	ServiceRequestTO getServiceRequest(Long requestID) throws CMMException;
	
	TransformMapConfigTO getTransformConfigDataByID(Long tMapId) throws CMMException;
	
	List<TransfromMapTO> fetchColNames(String netraTable) throws CMMException;
	
	List<String[]> fetchReferenceColNames(List<String> netraTable) throws CMMException;
	
	List<String[]> mandateRefTab(List<String[]> refTables) throws CMMException;
	
	List<Long> saveImportDataParent(String tableName, List<String> fieldNames, List<String[]> data, UserTO userTo) throws CMMException;
	
	boolean saveImportDataChild(String tableColName, List<String> fieldNames, List<String[]> data, UserTO userTo, List<Long> ids) throws CMMException;
	
	void saveSNcols(List<String> snTable, List<TransfromMapTO> tableList) throws CMMException;
	
	List<TransfromMapTO> loadSNcols(List<String> snTable, String baseURL) throws CMMException;
	
	boolean snExits(String snTable, String baseURL) throws CMMException;
	
	List<PlatformTypeTO> getOSDetailsUtility(String value) throws CMMException;
}
