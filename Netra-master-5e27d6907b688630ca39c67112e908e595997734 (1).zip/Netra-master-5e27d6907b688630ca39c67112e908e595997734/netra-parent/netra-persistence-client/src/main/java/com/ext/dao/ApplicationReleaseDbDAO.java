/**
 *
 */
package com.ext.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.to.ApplicationReleaseDbTO;

/**
 * This interface interacts with database to fetch, insert or update application release DB details.
 *
 * @author 460650
 */
public interface ApplicationReleaseDbDAO {
	
	/**
	 * Code to fetch application release DB details by requestId.
	 *
	 * @param requestId
	 *                of service request.
	 * @return List<ApplicationReleaseDbTO> which is list of application release DB.
	 * @throws CMMException
	 */
	List<ApplicationReleaseDbTO> fetchAppReleaseDbByRequestId(long requestId, long softwareConfigId, long relTestingPhase) throws CMMException;
	
	/**
	 * Code to fetch application release DB details by application releaseId.
	 *
	 * @param applicationReleaseId
	 * @return List<ApplicationReleaseDbTO> which is list of application release DB.
	 * @throws CMMException
	 */
	List<ApplicationReleaseDbTO> fetchAppReleaseDbByReleaseId(long applicationReleaseId, long softwareConfigId, long relTestingPhase) throws CMMException;
	
	List<ApplicationReleaseDbTO> fetchAppReleaseDbByRequestIdDocker(long requestId, long environmentPhaseId) throws CMMException;
	
	List<ApplicationReleaseDbTO> fetchAppReleaseDbByReleaseIdDocker(long applicationReleaseId, long environmentPhaseId) throws CMMException;
}
