/**
 *
 */
package com.ext.udeploy.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.to.NetraParametersTO;
import com.framework.to.SoftwareTO;
import com.framework.udeploy.to.UdeployProcess;
import com.framework.udeploy.to.UdeployProcessParametersTO;
import com.framework.udeploy.to.UdeployProcessSoftwareMapping;

/**
 * @author 460650
 */
public interface UdeployProcessDao {
	
	List<SoftwareTO> getSoftwareList() throws CMMException;
	
	List<UdeployProcess> getAllUdeployProcess() throws CMMException;
	
	boolean defineUdeployProcessForSoftware(UdeployProcessSoftwareMapping mapping) throws CMMException;
	
	void addNetraUdeployProcessParameterMapping(List<UdeployProcessParametersTO> udeployProcessParametersTOList) throws CMMException;
	
	List<UdeployProcessParametersTO> getUdeployProcessParametersList(Long processId) throws CMMException;
	
	List<NetraParametersTO> getNetraParametersList() throws CMMException;
	
	List<UdeployProcessParametersTO> checkForProcessIdInParameterMapping(Long selectedUdeployProcessId) throws CMMException;
	
	Long getNetraParameterId(String netraParam) throws CMMException;
}
