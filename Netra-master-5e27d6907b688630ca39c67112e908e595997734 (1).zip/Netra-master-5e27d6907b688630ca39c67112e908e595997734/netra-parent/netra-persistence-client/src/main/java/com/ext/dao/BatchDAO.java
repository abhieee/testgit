package com.ext.dao;

import com.framework.exception.CMMException;

public interface BatchDAO {
	
	boolean checkBatchRunningStatus(long id) throws CMMException;
	
	boolean updateBatchRunningStatus(long id, long statusId) throws CMMException;
}
