/**
 *
 */
package com.ext.puppet.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.puppetMaster.to.PuppetActivityExecOrderTO;
import com.framework.puppetMaster.to.PuppetActivityProcessOrderTO;
import com.framework.puppetMaster.to.PuppetReleaseActivityTO;

/**
 * @author 584175
 */
public interface PuppetActivityProcessDao {
	
	List<PuppetActivityProcessOrderTO> fetchPuppetSoftProcessMapByActivityID(long mapActivityId) throws CMMException;
	
	void saveOrderedPuppetProcessForActivity(PuppetReleaseActivityTO puppetReleaseActivityTO) throws CMMException;
	
	void saveOrderedActivities(PuppetReleaseActivityTO puppetReleaseActivityTO) throws CMMException;
	
	List<PuppetActivityProcessOrderTO> fetchPuppetProcessOrder(PuppetReleaseActivityTO puppetReleaseActivityTO) throws CMMException;
	
	List<PuppetActivityExecOrderTO> fetchOrderedActivities(PuppetReleaseActivityTO puppetReleaseActivityTO) throws CMMException;
}
