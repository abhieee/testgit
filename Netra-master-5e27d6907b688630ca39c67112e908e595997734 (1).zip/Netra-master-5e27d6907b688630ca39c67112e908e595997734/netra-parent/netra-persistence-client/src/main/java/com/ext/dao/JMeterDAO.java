package com.ext.dao;

import java.util.List;
import com.framework.exception.CMMException;

public interface JMeterDAO {
	
	List<String> getUserEmailByRequestId(Long requestId) throws CMMException;
}
