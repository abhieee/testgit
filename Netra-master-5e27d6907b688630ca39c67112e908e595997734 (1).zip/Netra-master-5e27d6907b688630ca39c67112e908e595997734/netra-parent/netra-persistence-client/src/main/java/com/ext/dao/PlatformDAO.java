package com.ext.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.to.PlatformTO;

public interface PlatformDAO {
	
	List<PlatformTO> searchPlatform(PlatformTO platformTO) throws CMMException;
	
	List<PlatformTO> getAllPlatforms() throws CMMException;
	
	boolean addplatform(PlatformTO platformTO) throws CMMException;
	
	PlatformTO getPlatformDetails(PlatformTO platformTO) throws CMMException;
	
	boolean editPlatform(PlatformTO platformTO) throws CMMException;
	
	String getProvisonedPlatformName(Long existingMachineId);
	
	String getVmwareGuestId(String architecture) throws CMMException;
}
