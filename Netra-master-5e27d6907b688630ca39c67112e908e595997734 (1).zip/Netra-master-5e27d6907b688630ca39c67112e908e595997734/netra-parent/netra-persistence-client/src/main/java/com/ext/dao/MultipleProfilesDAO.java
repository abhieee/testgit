package com.ext.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.to.ApplicationProfileTO;
import com.framework.to.MultipleProfilesTO;
import com.framework.to.StatusTO;

public interface MultipleProfilesDAO {
	
	void addMultipleProfile(MultipleProfilesTO multipleProfilesTO) throws CMMException;
	
	List<MultipleProfilesTO> searchMultipleProfiles(MultipleProfilesTO MultipleProfilesTO) throws CMMException;
	
	MultipleProfilesTO getMultipleProfilesDetails(MultipleProfilesTO multipleProfilesTO) throws CMMException;
	
	List<StatusTO> getStatusList() throws CMMException;
	
	void editMultipleProfiles(MultipleProfilesTO MultipleProfilesTO) throws CMMException;
	
	List<ApplicationProfileTO> getAllProfiles(Long appId) throws CMMException;
}
