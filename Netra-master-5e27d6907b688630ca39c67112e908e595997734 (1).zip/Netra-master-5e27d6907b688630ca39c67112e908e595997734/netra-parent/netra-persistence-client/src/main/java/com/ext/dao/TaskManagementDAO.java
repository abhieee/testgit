package com.ext.dao;

import java.util.List;
import java.util.Map;
import com.framework.exception.CMMException;
import com.framework.to.RepositoryTO;
import com.framework.to.TaskManagementTO;

public interface TaskManagementDAO {
	
	TaskManagementTO addTask(TaskManagementTO taskTO) throws CMMException;
	
	List<TaskManagementTO> searchTask(TaskManagementTO taskTO) throws CMMException;
	
	boolean checkName(TaskManagementTO taskTO) throws CMMException;
	
	List<TaskManagementTO> fetchTaskList(Long automationToolId) throws CMMException;
	
	List<TaskManagementTO> fetchTasksAndNolioProcesses(Long activityId, Long mappedSoftwareId, Long automationToolId) throws CMMException;
	
	List<TaskManagementTO> fetchNolioProcessesAndScriptsForTasks(Long activityId, Long mappedSoftwareId, Long automationToolId) throws CMMException;
	
	List<TaskManagementTO> fetchUdeployProcessesAndScriptsForTasks(Long activityId, Long mappedSoftwareId, Long automationToolId) throws CMMException;
	
	List<TaskManagementTO> fetchPuppetProcessesAndScriptsForTasks(Long activityId, Long mappedSoftwareId, Long automationToolId) throws CMMException;
	
	TaskManagementTO getTaskDetails(TaskManagementTO taskTO) throws CMMException;
	
	TaskManagementTO editTask(TaskManagementTO taskTO) throws CMMException;
	
	Map<String, String> fetchTaskParameterMap(Long taskId) throws CMMException;
	
	public boolean checkNewActivityName(TaskManagementTO taskTO) throws CMMException;
	
	List<RepositoryTO> getSharedLocations() throws CMMException;
}