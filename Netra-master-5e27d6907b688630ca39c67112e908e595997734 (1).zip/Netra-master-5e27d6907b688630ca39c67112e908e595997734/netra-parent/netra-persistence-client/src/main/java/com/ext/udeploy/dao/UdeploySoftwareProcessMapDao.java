/**
 *
 */
package com.ext.udeploy.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.udeploy.to.UdeployProcessSoftwareMapping;

/**
 * @author 460650
 */
public interface UdeploySoftwareProcessMapDao {
	
	List<UdeployProcessSoftwareMapping> getUdeploySoftwareProcessMapping(long softwareConfigId) throws CMMException;
}
