package com.ext.dao;

import java.util.List;
import java.util.Map;
import com.framework.exception.CMMException;
import com.framework.report.AppRelDetailsVO;
import com.framework.report.ApplicationDetailsReportVO;
import com.framework.report.EnvironmentChangeLogReportVO;
import com.framework.report.EnvironmentDetailsReportVO;
import com.framework.report.EnvironmentReservationDetailsReportVO;
import com.framework.report.EnvironmentSnapShotReportVO;
import com.framework.report.HardwareEnvironmentDetailsReportVO;
import com.framework.report.Hardware_summary;
import com.framework.report.ReportRequestVO;
import com.framework.report.SoftwareEnvironmentDetailsReportVO;
import com.framework.report.Software_summary;
import com.framework.report.UntaggedServerDetails;
import com.framework.report.UserStatisticsReportVO;
import com.framework.report.YearlyReservationVO;
import com.framework.to.UserGroupTO;

public interface ReportingDAO {
	
	List<EnvironmentChangeLogReportVO> getEnvironmentChangeLogReportData(ReportRequestVO reportRequestVO) throws CMMException;
	
	List<EnvironmentSnapShotReportVO> getEnvironmentSnapShotReportData(ReportRequestVO reportRequestVO) throws CMMException;
	
	List<ApplicationDetailsReportVO> getApplicationDetailsReportData(ReportRequestVO reportRequestVO, List<UserGroupTO> userGroupIds) throws CMMException;
	
	List<EnvironmentReservationDetailsReportVO> getEnvironmentReservationDetailsReportData(ReportRequestVO reportRequestVO) throws CMMException;
	
	List<UserStatisticsReportVO> getUserStatisticsReportData(ReportRequestVO reportRequestVO) throws CMMException;
	
	List<HardwareEnvironmentDetailsReportVO> getHardwareEnvironmentDetailsReport() throws CMMException;
	
	List<Hardware_summary> getHardwareSummaryData() throws CMMException;
	
	List<UntaggedServerDetails> getUntaggedServerList() throws CMMException;
	
	List<YearlyReservationVO> getYearlyReservation(String yearVal) throws CMMException;
	
	List<SoftwareEnvironmentDetailsReportVO> getSoftwareEnvironmentDetailsReport() throws CMMException;
	
	List<Software_summary> getSoftwareSummaryData() throws CMMException;
	
	List<EnvironmentDetailsReportVO> getEnvironmentDetailsReport(ReportRequestVO reportRequestVO) throws CMMException;
	
	Map<String, String> getTestExecReportFilterNames(String bU, String project, String app) throws CMMException;
	
	AppRelDetailsVO getReleaseDetailsFromRequest(Long relID) throws CMMException;
}
