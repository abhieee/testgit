/**
 *
 */
package com.ext.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.to.SoftwareTO;
import com.framework.to.SoftwareconfigTO;

/**
 * @author 460650
 */
public interface SoftwareConfigDAO {
	
	SoftwareconfigTO getSoftwareConfigDetails(long mappedSoftwareId) throws CMMException;
	
	List<SoftwareconfigTO> getVersionForSoftware(SoftwareTO softwareTO) throws CMMException;
}
