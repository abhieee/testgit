/**
 *
 */
package com.ext.nolio.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.nolio.to.ParamMappingTO;

/**
 * @author 460650
 */
public interface ParamMappingDao {
	
	List<ParamMappingTO> fetchParamMapping(long paramMappingId) throws CMMException;
}
