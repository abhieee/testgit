package com.ext.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.to.ServiceRequestHistoryTO;
import com.framework.to.ServiceRequestTO;

public interface ServiceRequestHistoryDAO {
	
	boolean updateServiceRequestHistory(Long requestId, String comments) throws CMMException;
	
	List<ServiceRequestHistoryTO> getServiceRequestHistoryList(Long requestId) throws CMMException;
	
	ServiceRequestTO fetchPipeLineRequestDetails(Long requestId) throws CMMException;
	
	List<ServiceRequestTO> fetchChildPipeLineRequestDetails(Long parentRequestId) throws CMMException;
	
	List<ServiceRequestTO> fetchServicesForSelectedEnvironment(Long selectedEnvironment, Long parentRequestId) throws CMMException;
}
