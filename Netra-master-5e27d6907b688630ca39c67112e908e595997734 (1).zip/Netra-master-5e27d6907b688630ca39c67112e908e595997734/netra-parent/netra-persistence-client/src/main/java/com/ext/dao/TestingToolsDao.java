package com.ext.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.to.ProvisionedMachineTO;
import com.framework.to.TestingToolTO;
import com.framework.to.TestingToolsTO;

public interface TestingToolsDao {
	
	List<TestingToolsTO> getAllTestingToolsConfigDetailsForApp(Long applicationId, Long projectId, Long buId, Long toolId) throws CMMException;
	
	List<TestingToolsTO> getAllTestingToolsConfigDetailsForApp(Long applicationId, Long projectId, Long buId, Long toolId, Long searchCount, int firstResult, int tableSize, List<Long> clients, Long clientId) throws CMMException;
	
	boolean saveTestingToolConfigDetails(TestingToolsTO testingToolsTO) throws CMMException;
	
	TestingToolsTO getConfigDetailsById(Long testingToolConfigId) throws CMMException;
	
	boolean updateTestingToolsConfigDetails(TestingToolsTO testingToolsTO) throws CMMException;
	
	List<TestingToolTO> getAllTestingToolName() throws CMMException;
	
	String getToolNameById(Long toolId) throws CMMException;
	
	List<ProvisionedMachineTO> getAllProvisionedMachine() throws CMMException;
}
