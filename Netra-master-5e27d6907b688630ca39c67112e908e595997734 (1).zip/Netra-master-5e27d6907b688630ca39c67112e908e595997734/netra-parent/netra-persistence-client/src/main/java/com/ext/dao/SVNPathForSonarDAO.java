package com.ext.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.to.SonarDetailTO;

public interface SVNPathForSonarDAO {
	
	List<SonarDetailTO> sVNPathForSonarDAO(Long applicationReleaseId) throws CMMException;
	
	public List<SonarDetailTO> getSonarDetailsForRelease(Long applicationReleaseId) throws CMMException;
	
	void sonarReportDetailsDAO(String folderName, Long applicationReleaseId) throws CMMException;
}
