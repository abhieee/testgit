/**
 *
 */
package com.ext.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.to.EnvironmentSoftParamsTO;

/**
 * @author 460650
 */
public interface EnvironmentSoftParamsDAO {
	
	void saveSoftwareParamsForEnv(EnvironmentSoftParamsTO environmentSoftParamsTO) throws CMMException;
	
	List<EnvironmentSoftParamsTO> getSoftwareParamsForEnv(long envId, long activityId) throws CMMException;
	
	List<EnvironmentSoftParamsTO> getSoftwareParamsByEnvAppId(long environmentApplicationId) throws CMMException;
}
