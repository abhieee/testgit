package com.ext.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.to.BUMapConfigTO;
import com.framework.to.BUMappingTO;
import com.framework.to.BulkUploadSoftwareTO;
import com.framework.to.ProvisionedMachineTO;

public interface BulkUploadDAO {
	
	List<String> uploadHardware(List<ProvisionedMachineTO> Hardwares) throws CMMException;
	
	List<String> uploadSoftware(List<BulkUploadSoftwareTO> softwares) throws CMMException;
	
	boolean saveTMap(BUMapConfigTO transformMapConfigTO, BUMappingTO buColumnMapping) throws CMMException;
	
	boolean checkIfMapNameExists(String mapName) throws CMMException;
	
	List<BUMapConfigTO> searchTmap(String mapName) throws CMMException;
	
	BUMapConfigTO fetchTmap(String mapName) throws CMMException;
	
	List<BUMappingTO> fetchMapping(Long id) throws CMMException;
	
	List<Long> saveImportDataParent(String parent, List<String> fieldNames, List<String[]> data, Long userID) throws CMMException;
	
	boolean saveImportDataChild(String tableColName, List<String> fieldNames, List<String[]> data, Long userID, List<Long> ids) throws CMMException;
}
