/**
 *
 */
package com.ext.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.to.HardwareTO;
import com.framework.to.MachineAwsTO;
import com.framework.to.MachineTO;
import com.framework.to.MachineVMWareTO;
import com.framework.to.ProvisionedMachineAwsTO;
import com.framework.to.ProvisionedMachineOSTO;
import com.framework.to.ProvisionedMachineTO;
import com.framework.to.ProvisionedMachineVmwareBareMetalTO;
import com.framework.to.ProvisionedPlatformTO;
import com.framework.to.ProvisionedPlatformVmwareBareMetalTO;

/**
 * @author 460650
 */
public interface MachineDAO {
	
	/**
	 * This method gives all the machines list.
	 *
	 * @return List<MachineTO> list of Machine Details.
	 * @throws CMMException
	 */
	List<MachineTO> getAllMachines() throws CMMException;
	
	/**
	 * This method gives all the provisioned machines list.
	 *
	 * @return List<ProvisionedMachineTO> list of Provisioned Machine Details.
	 * @throws CMMException
	 */
	List<ProvisionedMachineTO> getAllProvisionedMachines() throws CMMException;
	
	/**
	 * This method fetches the provisioned machine details for a provisioned machineId from Db.
	 *
	 * @param provisionedMachineId
	 *                of ProvisionedMachine table
	 * @return ProvisionedMachineTO
	 * @throws CMMException
	 */
	ProvisionedMachineTO getProvisionedMachineDetailsById(long provisionedMachineId) throws CMMException;
	
	/**
	 * This method updates ProvisionedMachine table in database.
	 *
	 * @param provisionedMachineTO
	 * @throws CMMException
	 */
	void updateProvisionedMachine(ProvisionedMachineTO provisionedMachineTO) throws CMMException;
	
	/**
	 * This method is used to fetch platformId from Provisioned Template table.
	 *
	 * @param provisionedtemplateId
	 *                of Provisioned Template.
	 * @return long platformId of OS.
	 * @throws CMMException
	 */
	long getPlatformIdForEC2(long provisionedtemplateId) throws CMMException;
	
	/**
	 * This method is used to fetch provisioned template id from Db corresponding to provisionedMachineId for EC2.
	 *
	 * @param provisionedMachineId
	 * @return long ProvisionedTemplateId
	 * @throws CMMException
	 */
	long fetchProvisionedTemplateIdForAWS(long provisionedMachineId) throws CMMException;
	
	MachineTO getMachineDetails(MachineTO machineTO) throws CMMException;
	
	MachineAwsTO getMachineAWSDetails(MachineTO machineTO) throws CMMException;
	
	HardwareTO getMachinePhysicalDetails(MachineTO machineTO) throws CMMException;
	
	MachineVMWareTO getMachineVMWareDetails(MachineTO machineTO) throws CMMException;
	
	/**
	 * This method is used to fetch provisioned template id from Db for VMware
	 *
	 * @param provisionedMachineId
	 *                of ProvisionedMachine
	 * @return long ProvisionedTemplateId
	 * @throws CMMException
	 */
	long fetchProvisionedTemplateIdForVMware(long provisionedMachineId) throws CMMException;
	
	/**
	 * This method fetches the ProvisionedPlatformTemplateTO details from DB.
	 *
	 * @param provisionedPlatformTemplateId
	 *                is the id in ProvisionedPlatformTemplate table.
	 * @return ProvisionedPlatformTemplateTO details of ProvisionedPlatformTemplate table.
	 * @throws CMMException
	 */
	ProvisionedPlatformTO getProvisionedPlatformTemplateDetails(long provisionedPlatformTemplateId) throws CMMException;
	
	void updateProvisionedMachineAws(ProvisionedMachineAwsTO provMachine) throws CMMException;
	
	ProvisionedMachineVmwareBareMetalTO getProMachineVmwareBareMetalDetailsById(Long proMachineId) throws CMMException;
	
	ProvisionedPlatformVmwareBareMetalTO getProPlatformVmwareBareMetalDetailsById(Long proPlatformId) throws CMMException;
	
	void updateProvisionedOSMachine(ProvisionedMachineTO provisionedMachineTO, ProvisionedMachineOSTO provisionedMachineOSTO) throws CMMException;
}
