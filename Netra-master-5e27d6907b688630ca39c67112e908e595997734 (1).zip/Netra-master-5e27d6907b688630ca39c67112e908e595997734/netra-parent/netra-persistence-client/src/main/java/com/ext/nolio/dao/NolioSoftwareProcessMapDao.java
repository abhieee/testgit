/**
 *
 */
package com.ext.nolio.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.nolio.to.NolioProcessSoftwareMapping;

/**
 * @author 460650
 */
public interface NolioSoftwareProcessMapDao {
	
	public void saveNolioProcessSoftwareMapping(NolioProcessSoftwareMapping nolioProcessSoftwareMapping) throws CMMException;
	
	public NolioProcessSoftwareMapping getNolioProcessSoftMapping(long softwareConfigId, long serviceId) throws CMMException;
	
	public List<NolioProcessSoftwareMapping> getNolioSoftwareProcessMapping(long softwareConfigId) throws CMMException;
}
