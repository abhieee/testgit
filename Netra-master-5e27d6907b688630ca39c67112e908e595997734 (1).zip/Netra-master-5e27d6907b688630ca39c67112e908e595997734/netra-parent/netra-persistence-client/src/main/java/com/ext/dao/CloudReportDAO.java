package com.ext.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.to.ProjectsTO;
import com.framework.to.ProvisionedMachineTO;
import com.framework.to.VmReportTO;

public interface CloudReportDAO {
	
	/**
	 * This function is to save pricing model
	 * 
	 * @param vmReportTO
	 * @return
	 * @throws CMMException
	 */
	public void saveModel(VmReportTO vmReportTO) throws CMMException;
	
	public List<VmReportTO> getAllModel() throws CMMException;
	
	public void saveMapping(VmReportTO vmReportTO) throws CMMException;
	
	public void saveProjectModelMapping(VmReportTO vmReportTO) throws CMMException;
	
	public List<ProvisionedMachineTO> getProvisionedMachineList(VmReportTO vmReportTO) throws CMMException;
	
	public VmReportTO getModelDetailforBU(long businessUnit) throws CMMException;
	
	public VmReportTO getModelDetailforProject(long projectId) throws CMMException;
	
	public List<ProjectsTO> getAllProjects() throws CMMException;
	
	public boolean checkModelName(String modelName) throws CMMException;
}
