package com.ext.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.to.TestingPhaseTO;

public interface ApplicationTestingPhaseDao {
	
	boolean addPhase(TestingPhaseTO testingPhaseTO) throws CMMException;
	
	List<TestingPhaseTO> searchPhase(TestingPhaseTO testingPhaseTO) throws CMMException;
	
	TestingPhaseTO loadPhase(TestingPhaseTO testingPhaseTO);
	
	boolean editPhase(TestingPhaseTO testingPhaseTO);
	
	List<TestingPhaseTO> getAllTestingPhases(Long applicationId) throws CMMException;
	
	List<TestingPhaseTO> getAllPhases() throws CMMException;
	
	public List<TestingPhaseTO> getPhaseIdFromName(String name) throws CMMException;
	
	public boolean checkEnvPhaseMapping(Long envId, Long phaseId) throws CMMException;
}
