package com.ext.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.nolio.to.NolioProcessParametersTO;
import com.framework.to.EnvironmentDetailsTO;
import com.framework.to.ParameterTO;
import com.framework.to.SoftwareTO;
import com.framework.to.SoftwareTemplatePropertyTO;
import com.framework.to.SoftwareconfigTO;
import com.framework.to.StatusTO;

public interface SoftwareDAO {
	
	SoftwareTO addSoftware(SoftwareTO softwareTO) throws CMMException;
	
	SoftwareTO addExsitingSoftware(SoftwareTO softwareTO) throws CMMException;
	
	SoftwareTO getSoftwareDetails(Long selectSoftwareId, Long selectedSoftwareConfigId) throws CMMException;
	
	Long editSoftware(SoftwareTO softwareTO) throws CMMException;
	
	List<SoftwareTO> getAllSoftwares() throws CMMException;
	
	List<SoftwareTO> searchSoftware(SoftwareTO softwareTO) throws CMMException;
	
	List<SoftwareconfigTO> searchSoftwareAll(SoftwareTO softwareTO) throws CMMException;
	
	List<SoftwareconfigTO> searchSoftwareAllForProfile(SoftwareTO softwareTO) throws CMMException;
	
	List<StatusTO> fetchSoftwareStatusList(Long entityId) throws CMMException;
	
	SoftwareTO fetchSoftwareVersionDetails(Long id) throws CMMException;
	
	List<NolioProcessParametersTO> getSoftwareProperties(Long id) throws CMMException;
	
	boolean isSoftwarePresent(String strSoftwareName, String Version) throws CMMException;
	
	List<ParameterTO> getAllParameters() throws CMMException;
	
	SoftwareconfigTO fetchSoftwareDetails(Long softwareId, String version) throws CMMException;
	
	boolean isSoftwarePresentUpdate(String strSoftwareName, String version, Long id) throws CMMException;
	
	Long removeSoftwarePropertyRow(Long softwareConfigId) throws CMMException;
	
	List<Long> getZabbixTemplatesForSoftware(Long softwareConfigId) throws CMMException;
	
	List<Long> getpropertydetails(Long softwareconfigsId);
	
	List<Long> searchSoftwareForSoftwareInstallation(Long selectedEnvironment, Long serverGroup) throws CMMException;
	
	List<String> getDetailsForExistingSoftware(Long softwareId) throws CMMException;
	
	Long getSoftwareIdByConfigId(Long softwareconfigsId) throws CMMException;
	
	List<EnvironmentDetailsTO> searchSoftwareForSoftwaresInstallation(Long selectedEnvironment, Long serverGroup) throws CMMException;
	
	List<ParameterTO> getAttributesForSoftware() throws CMMException;
	
	ParameterTO getParam(Long paramID) throws CMMException;
	
	List<SoftwareTemplatePropertyTO> getSoftwareTempProp(Long softConfID) throws CMMException;
	
	boolean isSoftwareVersionPresent(String version, Long selectedSoftwareId, Long deviceid) throws CMMException;
}
