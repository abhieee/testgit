package com.ext.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.to.BusinessUnitTO;
import com.framework.to.StatusTO;

public interface BusinessUnitDAO {
	
	List<BusinessUnitTO> searchBusinessUnit(BusinessUnitTO BusinessUnitTO) throws CMMException;
	
	void addBusinessUnit(BusinessUnitTO BusinessUnitTO) throws CMMException;
	
	BusinessUnitTO getBusinessUnitDetails(BusinessUnitTO BusinessUnitTO) throws CMMException;
	
	void editBusinessUnit(BusinessUnitTO BusinessUnitTO) throws CMMException;
	
	boolean checkName(BusinessUnitTO businessUnitTO) throws CMMException;
	
	BusinessUnitTO getBusinesUnitDetails(BusinessUnitTO businessUnitTO) throws CMMException;
	
	List<StatusTO> getStatusList() throws CMMException;
}
