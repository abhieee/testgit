/**
 *
 */
package com.ext.nolio.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.nolio.to.NolioProcess;
import com.framework.nolio.to.NolioProcessParametersTO;
import com.framework.nolio.to.NolioProcessSoftwareMapping;
import com.framework.to.NetraNolioProcessParameterMappingTO;
import com.framework.to.NetraParametersTO;
import com.framework.to.SoftwareTO;

/**
 * @author 460650
 */
public interface NolioProcessDao {
	
	NolioProcess getNolioProcessInfoByProcessId(long processId) throws CMMException;
	
	NolioProcess addNolioProcess(NolioProcess nolioProcess) throws CMMException;
	
	List<NolioProcess> searchNolioProcess(NolioProcess nolioProcess) throws CMMException;
	
	NolioProcess getNolioProcessDetails(NolioProcess nolioProcess) throws CMMException;
	
	void editNolioProcessDetails(NolioProcess nolioProcess) throws CMMException;
	
	List<SoftwareTO> getSoftwareList() throws CMMException;
	
	List<Long> getNolioProcessForOS(long osType) throws CMMException;
	
	List<NolioProcess> getAllNolioProcess() throws CMMException;
	
	List<NetraParametersTO> getNetraParametersList() throws CMMException;
	
	boolean defineNolioProcessForSoftware(NolioProcessSoftwareMapping mapping) throws CMMException;
	
	NolioProcess getNolioProcessInfoByProcessName(String processFullPath) throws CMMException;
	
	List<NolioProcessParametersTO> getNolioProcessParametersList(Long processId) throws CMMException;
	
	void addNetraNolioProcessParameterMapping(List<NolioProcessParametersTO> nolioProcessParametersTOList) throws CMMException;
	
	List<NolioProcessParametersTO> checkForProcessIdInParameterMapping(Long selectedNolioProcessId) throws CMMException;
	
	void editNetraNolioProcessParameterMapping(List<NetraNolioProcessParameterMappingTO> netraNolioProcessParameterMappingTOList) throws CMMException;
	
	List<NetraNolioProcessParameterMappingTO> getNetraNolioProcessParameterMappingTOList(Long processId) throws CMMException;
	
	Long getNetraParameterId(String netraParam) throws CMMException;
}
