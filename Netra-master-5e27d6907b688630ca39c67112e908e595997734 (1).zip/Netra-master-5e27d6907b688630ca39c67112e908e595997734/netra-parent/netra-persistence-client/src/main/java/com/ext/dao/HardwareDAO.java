package com.ext.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.to.BusinessUnit_InvTO;
import com.framework.to.CIServerTO;
import com.framework.to.HardwareTO;
import com.framework.to.ProvisionedMachineTO;
import com.framework.to.ProvisionedPlatformTO;

public interface HardwareDAO {
	
	ProvisionedMachineTO getHardwareDetails(ProvisionedMachineTO provisionedMachineTO) throws CMMException;
	
	void editHardware(ProvisionedMachineTO provisionedMachineTO, ProvisionedPlatformTO provisionedPlatformTO) throws CMMException;
	
	void deleteHardwareTemplateProperty(String deleteTemplateProperty) throws CMMException;
	
	List<HardwareTO> getAllHardwares() throws CMMException;
	
	List<ProvisionedMachineTO> searchHardware(ProvisionedMachineTO provisionedMachineTO) throws CMMException;
	
	void deleteHardware(HardwareTO hardwareTO) throws CMMException;
	
	boolean checkName(ProvisionedMachineTO provisionedMachineTO) throws CMMException;
	
	List<HardwareTO> getAllHardware() throws CMMException;
	
	List<HardwareTO> getHWdetails(HardwareTO hardwareTO) throws CMMException;
	
	List<Object[]> getHardwareUtilizationDetails(HardwareTO hardwareTO) throws CMMException;
	
	List<Object[]> getHardwareUtilizationPerc(HardwareTO hardwareTO) throws CMMException;
	
	List<BusinessUnit_InvTO> searchServerMasterList(Long clientId, List<Long> clientIdlist) throws CMMException;
	
	List<HardwareTO> getHardwareList() throws CMMException;
	
	boolean addCIServer(CIServerTO ciServerTO) throws CMMException;
	
	void addHardware(ProvisionedMachineTO provisionedMachineTO, ProvisionedPlatformTO provisionedPlatformTO) throws CMMException;
	
	List<ProvisionedMachineTO> fetchProvisionedMachineList() throws CMMException;
	
	boolean checkNameAddServer(ProvisionedMachineTO provisionedMachineTO) throws CMMException;
}
