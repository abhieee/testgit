/**
 *
 */
package com.ext.puppet.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.puppetMaster.to.PuppetProcessParametersTO;
import com.framework.puppetMaster.to.PuppetProcessSoftwareMapping;

/**
 * @author 584175
 */
public interface PuppetSoftwareProcessMapDao {
	
	void savePuppetProcessSoftwareMapping(PuppetProcessSoftwareMapping puppetProcessSoftwareMapping) throws CMMException;
	
	PuppetProcessSoftwareMapping getPuppetProcessSoftMapping(long softwareConfigId, long serviceId) throws CMMException;
	
	List<PuppetProcessSoftwareMapping> getPuppetSoftwareProcessMapping(long softwareConfigId) throws CMMException;
	
	boolean selectedProcessName(PuppetProcessParametersTO puppetProcessParametersTO) throws CMMException;
}
