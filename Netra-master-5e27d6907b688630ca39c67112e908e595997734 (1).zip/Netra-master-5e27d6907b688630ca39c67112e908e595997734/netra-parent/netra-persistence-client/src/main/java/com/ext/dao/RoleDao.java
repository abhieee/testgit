package com.ext.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.to.RoleLevelTO;
import com.framework.to.RoleTO;
import com.framework.to.StatusTO;

public interface RoleDao {
	
	RoleTO addRole(RoleTO roleTO) throws CMMException;
	
	void defineRole(RoleLevelTO roleLevelTO) throws CMMException;
	
	List<StatusTO> getStatusList() throws CMMException;
	
	List<RoleTO> searchRole(RoleTO roleTO) throws CMMException;
	
	RoleTO loadRoleDetails(RoleTO roleTO) throws CMMException;
	
	List<RoleTO> getDefinedRoles(String roleId) throws CMMException;
	
	void editRole(RoleTO roleTO) throws CMMException;
	
	boolean checkName(RoleTO roleTO) throws CMMException;
}
