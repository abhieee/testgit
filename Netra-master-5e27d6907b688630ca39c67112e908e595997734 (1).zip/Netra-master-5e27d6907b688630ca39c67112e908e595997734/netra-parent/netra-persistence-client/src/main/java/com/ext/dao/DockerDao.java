package com.ext.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.to.DockerServerConfigurationTO;
import com.framework.to.DockerTemplateTO;
import com.framework.to.EnvironmentDockerTO;
import com.framework.to.RepositoryTO;

public interface DockerDao {
	
	void saveTemplate(DockerTemplateTO dockerTemplateTO) throws CMMException;
	
	List<DockerTemplateTO> searchDockerTemplate() throws CMMException;
	
	boolean checkTemplateName(String templateName) throws CMMException;
	
	DockerTemplateTO getDockerTemplatebyId(Long templateId) throws CMMException;
	
	List<DockerTemplateTO> searchDockerTemplatesByName(DockerTemplateTO dockerTemplate) throws CMMException;
	
	void editTemplateDetails(DockerTemplateTO dockerTemplate) throws CMMException;
	
	List<DockerServerConfigurationTO> getAllDockerServerDetails() throws CMMException;
	
	List<DockerServerConfigurationTO> getToDockerServerList(String selectedServerIp) throws CMMException;
	
	List<DockerServerConfigurationTO> getDockerServerDetailsByIP(String IP) throws CMMException;
	
	void saveContainerIP(String containerIP, Long envId, String containerID) throws CMMException;
	
	EnvironmentDockerTO getDockerEnvDetails(Long envId) throws CMMException;
	
	List<RepositoryTO> getRepositoryList() throws CMMException;
	
	RepositoryTO getRepositoryDetail(long repoId) throws CMMException;
}
