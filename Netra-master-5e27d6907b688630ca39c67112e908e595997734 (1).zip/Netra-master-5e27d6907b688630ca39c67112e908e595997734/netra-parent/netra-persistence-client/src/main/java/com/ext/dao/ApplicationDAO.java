package com.ext.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.to.ApplicationCategoryTO;
import com.framework.to.ApplicationReleaseTO;
import com.framework.to.ApplicationTO;
import com.framework.to.ApplicationTreeTO;
import com.framework.to.BusinessUnitTO;
import com.framework.to.CIServerTO;
import com.framework.to.EnvironmentTO;
import com.framework.to.MonitoringURLDataTo;
import com.framework.to.NamedEntityTO;
import com.framework.to.ProjectsTO;
import com.framework.to.ProvisionedMachineTO;
import com.framework.to.RepoTO;
import com.framework.to.RoleTO;
import com.framework.to.ServiceTO;
import com.framework.to.SonarReportsDetailTO;
import com.framework.to.TestingLifeCycleTO;
import com.framework.to.TestingPhaseTO;
import com.framework.to.UserGroupTO;
import com.framework.to.UserTO;

public interface ApplicationDAO {
	
	ApplicationTO getApplicationDetails(ApplicationTO applicationTO) throws CMMException;
	
	List<ApplicationTO> getApplicationsDetails(List<Long> ids) throws CMMException;
	
	ApplicationTO editApplication(ApplicationTO applicationTO) throws CMMException;
	
	ApplicationTO addApplication(ApplicationTO applicationTO) throws CMMException;
	
	boolean checkApplicationName(String applicationName, Long id) throws CMMException;
	
	List<BusinessUnitTO> getBusinessUnitNames(List<Long> clientIdlist) throws CMMException;
	
	List<ApplicationTO> getDependentSystem(List<Long> clientIdlist) throws CMMException;
	
	List<ApplicationCategoryTO> getApplicationCategoryList() throws CMMException;
	
	List<ProjectsTO> getAllProjects(Long clientId) throws CMMException;
	
	List<ProjectsTO> getAllProjectsForMultipleBU(List<Long> clientIds) throws CMMException;
	
	List<UserTO> getAllUserNames(UserTO userTO) throws CMMException;
	
	void addApplicationTree(ApplicationTreeTO applicationTO) throws CMMException;
	
	List<Object> searchApplications(ApplicationTO applicationTO, List<UserGroupTO> userGroupIds) throws CMMException;
	
	List<NamedEntityTO> getStatusList(String entityId) throws CMMException;
	
	Long getRole(Long userId) throws CMMException;
	
	List<NamedEntityTO> getTemplateModeList(String entityId) throws CMMException;
	
	List<NamedEntityTO> getShareModeList(String entityId) throws CMMException;
	
	List<ApplicationTO> getAllApplicationsNew(List<UserGroupTO> userGroupIds, Long id) throws CMMException;
	
	List<ApplicationTO> getAllApplicationsForBu(List<UserGroupTO> userGroupIds, List<Long> clients) throws CMMException;
	
	List<ApplicationTO> getAllApplications(List<UserGroupTO> userGroupIds) throws CMMException;
	
	List<ApplicationTO> getAllApplications(Long clientId, List<UserGroupTO> userGroupIds) throws CMMException;
	
	List<ApplicationTO> getAllApplications(Long clientId, Long projectId) throws CMMException;
	
	List<ApplicationTO> getAllApplications(Long clientId, Long projectId, List<UserGroupTO> userGroupIds, Long userClientId) throws CMMException;
	
	List<EnvironmentTO> getAllEnvironments(Long applicationId) throws CMMException;
	
	List<EnvironmentTO> getAllEnvironmentsForReport(List<Long> applicationId) throws CMMException;
	
	List<ApplicationTO> getAllApplications() throws CMMException;
	
	List<UserTO> getApplicationOwner(Long clientid, List<Long> clientIdList) throws CMMException;
	
	boolean defineTestingLifeCycle(TestingLifeCycleTO testingLifeCycleTO) throws CMMException;
	
	List<ServiceTO> getDefinedServices(Long testingPhase) throws CMMException;
	
	List<RepoTO> repoList() throws CMMException;
	
	List<CIServerTO> ciList() throws CMMException;
	
	List<TestingLifeCycleTO> getLifecycle(long applicationId) throws CMMException;
	
	List<TestingPhaseTO> getTestingPhases(Long selectedApp) throws CMMException;
	
	String getAppNameForAppId(long applicationId) throws CMMException;
	
	ApplicationTO getApplicationDetailsById(Long selectedApplication) throws CMMException;
	
	List<ProvisionedMachineTO> getProvisionedMachines(Long selectedApplication, Long selectedEnvironment, Long releaseId) throws CMMException;
	
	List<ProvisionedMachineTO> fetchMachineDetails(Long selectedApplication, Long selectedEnvironment) throws CMMException;
	
	List<UserTO> getApplicationOwner(Long clientId) throws CMMException;
	
	List<BusinessUnitTO> getsavedbusinessUnitList(Long serviceId) throws CMMException;
	
	List<UserGroupTO> getAllUserGrpNames(Long clientId) throws CMMException;
	
	String getSelectedUserGroup(long clientId) throws CMMException;
	
	List<EnvironmentTO> getAllEnvironmentForProject(Long projectId, Long clientid, List<UserGroupTO> userGroupIds, Long userClientId) throws CMMException;
	
	List<ApplicationTO> getAllAppForEnv(Long envId, Long projectId, Long clientid, List<UserGroupTO> userGroupIds, Long userClientId) throws CMMException;
	
	List<ApplicationTO> selectedSonarApplicationForReport() throws CMMException;
	
	List<ApplicationReleaseTO> getApplicationReleaseForReports(Long applicationId) throws CMMException;
	
	List<SonarReportsDetailTO> getSonarRequestIdForReports(Long applicationReleaseId) throws CMMException;
	
	long getAppLicationOwnerId(long selectedAppId) throws CMMException;
	
	List<UserTO> getAllSelectedUserNames(long userGroupId) throws CMMException;
	
	List<UserTO> getAllLeftUserNames(long userGroupId, long clientId) throws CMMException;
	
	boolean checkUserGroupName(String userGroup, Long userGrpId) throws CMMException;
	
	boolean checkAppCategoryName(String other, String type) throws CMMException;
	
	MonitoringURLDataTo getURL(MonitoringURLDataTo monitoringURLDataTo) throws CMMException;
	
	/**
	 * This method fetches application details for an application.
	 *
	 * @param applicationId
	 *                of Application
	 * @return ApplicationTO application details of an application
	 * @throws CMMException
	 *                 custom Exception.
	 */
	ApplicationTO getApplicationDetails(long applicationId) throws CMMException;
	
	ApplicationTO getApplicationDetailsForCIReport(List<Long> applicationId) throws CMMException;
	
	/**
	 * This method is used to fetch applicationId by application name.
	 *
	 * @param applicationName
	 *                of Application
	 * @return Long applicationId
	 * @throws CMMException
	 */
	Long fetchApplicationIdByName(String applicationName) throws CMMException;
	
	List<Long> getSelectedClients(Long id) throws CMMException;
	
	ApplicationReleaseTO getReleaseForApplication(Long id, Long environmentId) throws CMMException;
	
	ApplicationReleaseTO getReleaseForRequest(Long serviceRequestId, Long environmentId, Long serviceId) throws CMMException;
	
	List<ApplicationTO> getAllApplicationsForServicesForRespectiveBUs(List<Long> clientIdList, int tempServiceId) throws CMMException;
	
	List<Long> getAppLicationsId(Long id) throws CMMException;
	
	List<UserGroupTO> getUserGroupNames(Long usergrpid) throws CMMException;
	
	List<ApplicationTO> getAllApplicationsForCIReport(List<Long> clientId, List<Long> projectId, List<UserGroupTO> userGroupIds, Long userClientId) throws CMMException;
	
	List<ApplicationTO> getAllApplicationsForCIReport(List<Long> clientId, List<Long> projectId) throws CMMException;
	
	List<ProjectsTO> getAllProjectsForCIReport(List<Long> clientId) throws CMMException;
	
	List<RoleTO> getAllRoles() throws CMMException;
	
	Long fetchAppServerIDByName(String serverName) throws CMMException;
}