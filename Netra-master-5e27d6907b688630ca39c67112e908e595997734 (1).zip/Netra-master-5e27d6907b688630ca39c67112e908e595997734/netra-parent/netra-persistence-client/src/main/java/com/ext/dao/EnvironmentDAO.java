package com.ext.dao;

import java.util.Date;
import java.util.List;
import java.util.Map;
import com.framework.exception.CMMException;
import com.framework.to.AddPolicyTO;
import com.framework.to.ApplicationMonitoringTO;
import com.framework.to.ApplicationTO;
import com.framework.to.EnvironmentApplicationTO;
import com.framework.to.EnvironmentDetailsTO;
import com.framework.to.EnvironmentTO;
import com.framework.to.ParameterTO;
import com.framework.to.ProvisionedMachineTO;
import com.framework.to.ReleaseDashBoradTo;
import com.framework.to.ServiceRequestTO;
import com.framework.to.SoftwareTO;
import com.framework.to.StatusTO;
import com.framework.to.UserDefinedEnvParamsTO;
import com.framework.to.UserTO;
import com.framework.to.ZabbixTriggerFunctionTO;

public interface EnvironmentDAO {
	
	/**
	 * @param environmentTO
	 * @throws CMMException
	 */
	void addEnvironment(EnvironmentTO environmentTO) throws CMMException;
	
	/**
	 * @param id
	 * @return
	 * @throws CMMException
	 */
	EnvironmentTO getEnvironmentDetails(Long id) throws CMMException;
	
	/**
	 * @param environmentTO
	 * @throws CMMException
	 */
	EnvironmentTO editEnvironment(EnvironmentTO environmentTO) throws CMMException;
	
	/**
	 * @param id
	 * @return
	 * @throws CMMException
	 */
	List<EnvironmentDetailsTO> fetchEnvironment(Long id) throws CMMException;
	
	/**
	 * @return
	 * @throws CMMException
	 */
	List<StatusTO> fetchEnvironmentStatusList() throws CMMException;;
	
	/**
	 * @param environmentTO
	 * @return
	 * @throws CMMException
	 */
	List<EnvironmentTO> searchEnv(EnvironmentTO environmentTO, UserTO userTo) throws CMMException;
	
	List<EnvironmentDetailsTO> fetchSubEnvironmentsDetail(Long id) throws CMMException;
	
	ApplicationMonitoringTO fetchChartForMonitoring(ApplicationMonitoringTO appto, UserTO userto) throws CMMException;
	
	List getEnvIdsForHost(List<String> hosts, UserTO userTO) throws CMMException;
	
	Long getRequestedEnvCount(Long clientId, List<Long> clientIdlist, long status, EnvironmentTO environmentTO) throws CMMException;
	
	List<EnvironmentTO> getAllEnvs() throws CMMException;
	
	Long getAvailableEnvCount(Long clientId, List<Long> clientIdlist, EnvironmentTO environmentTO) throws CMMException;
	
	Long getReservedEnvCount(Long clientId, List<Long> clientIdlist, EnvironmentTO environmentTO) throws CMMException;
	
	Map<String, Long> getNotReservedFrom4WeeksCount(UserTO user, List<Long> groups) throws CMMException;
	
	List<EnvironmentTO> searchAvailableEnvForHome(EnvironmentTO environmentTO) throws CMMException;
	
	List<EnvironmentTO> searchReservedEnvForHome(EnvironmentTO environmentTO) throws CMMException;
	
	List<EnvironmentTO> searchRequestedEnvForHome(EnvironmentTO environmentTO) throws CMMException;
	
	List<EnvironmentTO> searchRequestedEnvForHome(Long clientid, EnvironmentTO environmentTO) throws CMMException;
	
	List<EnvironmentTO> searchEnvNotReservedFrom4WeeksForHome(EnvironmentTO environmentTO) throws CMMException;
	
	List<Object[]> getEnvironmentSnapshot(EnvironmentTO environmentTO) throws CMMException;
	
	Long checkURLMonitoring(String releaseId, String environmentId) throws CMMException;
	
	/**
	 * Method to fetch all sub environments of a environment.
	 *
	 * @param environmentId
	 *                of parent environment.
	 * @return List of sub environment.
	 * @throws CMMException
	 */
	List<EnvironmentTO> getSubEnvironment(long environmentId) throws CMMException;
	
	/**
	 * Method to update releaseId of the environment.
	 *
	 * @param releaseId
	 *                that needs to be updated
	 * @param environmentId
	 *                of the environment for which releaseId needs to be updated.
	 * @throws CMMException
	 */
	void updateEnvironmentReleaseID(long releaseId, long environmentId, long applicationId) throws CMMException;
	
	/**
	 * This method updates environment status to available.
	 *
	 * @param environmentId
	 *                of Environment for which Status needs to be available.
	 * @throws CMMException
	 */
	void updateEnvStatusAsAvailable(long environmentId) throws CMMException;
	
	void updateEnvStatusAsUnAvailable(long environmentId) throws CMMException;
	
	/**
	 * Method to fetch environment application release mapping by environmentId.
	 *
	 * @param environmentId
	 *                of environment.
	 * @return EnvironmentApplicationTO environment application release mapping object.
	 * @throws CMMException
	 */
	List<EnvironmentApplicationTO> getEnvAppReleaseMap(long environmentId) throws CMMException;
	
	EnvironmentApplicationTO fetchEnvironmentApplicationDetails(long environmentId, long applicationId) throws CMMException;
	
	/**
	 * Method to fetch profileId for EnvironmentId.
	 *
	 * @param environmentId
	 *                for Environment.
	 * @return long profileId of Environment is returned.
	 * @throws CMMException
	 */
	long getProfileIdForEnvironment(long environmentId) throws CMMException;
	
	/**
	 * Method to fetch softwareIds for EnvironmentId.
	 *
	 * @param environmentId
	 *                for Environment.
	 * @return list softwareList of Environment is returned.
	 * @throws CMMException
	 */
	List getSoftwareListForEnv(long environmentId) throws CMMException;
	
	ReleaseDashBoradTo fetchChart(ReleaseDashBoradTo baoURLDataTo, UserTO userTo);
	
	String getEnvironmentName(long environmentId) throws CMMException;
	
	List<ApplicationTO> getAllApplications(List<Long> clientIdlist, Long profileId) throws CMMException;
	
	String getprofileName(Long profileId);
	
	void updateSoftwareInstallationStatus(EnvironmentDetailsTO envDetailsTO) throws CMMException;
	
	List getDashboardDetails(String appName, String phase, String release, UserTO userTo) throws CMMException;
	
	List<ApplicationTO> getAllApplicationsDrivenByEnv(Long environmentId) throws CMMException;
	
	List<EnvironmentTO> getAllEnvsMonitoring() throws CMMException;
	
	AddPolicyTO getPolicyDetail(long envId) throws CMMException;
	
	boolean checkEnvironmentName(String editedName, Long environmentId) throws CMMException;
	
	String fetchOwnerName(Long id) throws CMMException;
	
	List<EnvironmentTO> searchAvailableEnvForHome(EnvironmentTO environmentTO, UserTO userTo, List<Long> clientIdlist) throws CMMException;
	
	List<EnvironmentTO> searchReservedEnvForHome(EnvironmentTO environmentTO, UserTO userTo, List<Long> clientIdlist) throws CMMException;
	
	List<EnvironmentTO> searchRequestedEnvForHome(EnvironmentTO environmentTO, UserTO userTo, List<Long> clientIdList) throws CMMException;
	
	Long getAvailableEnvCount(Long clientId, List<Long> clientIdlist, EnvironmentTO environmentTO, UserTO userTO) throws CMMException;
	
	Long getReservedEnvCount(Long clientId, List<Long> clientIdlist, EnvironmentTO environmentTO, UserTO userTO) throws CMMException;
	
	Long getRequestedEnvCount(Long clientId, List<Long> clientIdlist, long status, EnvironmentTO environmentTO, UserTO userTo) throws CMMException;
	
	String getCurrentOwner(Long request_id) throws CMMException;
	
	/**
	 * This method fetches the environment Id by environment name.
	 *
	 * @param environmentName
	 *                of environment
	 * @return Long Id of environment
	 * @throws CMMException
	 *                 custom exception
	 */
	Long fetchEnvironmentIDByName(String environmentName) throws CMMException;
	
	List getServiceDashboardDetails(String service_id, String status_id, String status, UserTO userTo) throws CMMException;
	
	List getServiceDashboardDetailsPending(String service_id, String status_id, String status, UserTO userTo) throws CMMException;
	
	List getServiceDashboardDetailsForAgentDeploment(String service_id, String status_id, String status, UserTO userTo) throws CMMException;
	
	List getServiceDashboardDetailsForApplicationBasis(String service_id, String status_id, String status, UserTO userTo) throws CMMException;
	
	List getServiceDashboardDetailsPendingApplicationBasis(String service_id, String status_id, String status, UserTO userTo) throws CMMException;
	
	List getServiceDashboardDetailsForEnvironmentBasis(String service_id, String status_id, String status, UserTO userTo) throws CMMException;
	
	List getServiceDashboardDetailsPendingEnvironmentBasis(String service_id, String status_id, String status, UserTO userTo) throws CMMException;
	
	List<ZabbixTriggerFunctionTO> getAllZabbixFunctions() throws CMMException;
	
	List<ProvisionedMachineTO> getEnvListFordashboard(List<String> hosts, UserTO userTo) throws CMMException;
	
	String getHostName(String id) throws CMMException;
	
	String getContextName(Long id) throws CMMException;
	
	List<ProvisionedMachineTO> getUserDefinedMachines(UserTO userTo) throws CMMException;
	
	String getIp(String name) throws CMMException;
	
	List<SoftwareTO> getsoftwareMappingForZabbix(Long environmentId, String resourceType) throws CMMException;
	
	void updateEnvironmentStatusToUnderImplementation(Long envid) throws CMMException;
	
	void updateMonitoringAgentStatus(Long envId) throws CMMException;
	
	void updateEnvStatusAsDecommissioned(long environmentId) throws CMMException;
	
	List<EnvironmentApplicationTO> fetchEnvForAppAndRel(Long applicationId, Long releaseId) throws CMMException;
	
	/**
	 * Update update Software Installation Status By Environment Details Id
	 *
	 * @param environmentDetailsId
	 *                Id of Environment Details.
	 * @throws CMMException
	 *                 custom Exception
	 */
	void updateSoftInstallStatusByEnvDetId(Long environmentDetailsId) throws CMMException;
	
	EnvironmentTO getEnvDetails(String hostname) throws CMMException;
	
	List<ParameterTO> fetchParamsById(List<Long> paramIdList) throws CMMException;
	
	List<ServiceRequestTO> fetchCodeAnalysisDetails(UserTO userTo, List<Long> userGroupIds) throws CMMException;
	
	public Map<String, Long> getNotReservedFromPrevCount(Date modifiedDate, Date modifiedDate1, UserTO user, List<Long> groups) throws CMMException;
	
	public Map<String, Long> getCountForUnderUnTaggedServer(UserTO user, List<Long> groupIds) throws CMMException;
	
	public Map<String, Long> getServerAgeCount(UserTO user, List<Long> groupIds) throws CMMException;
	
	public List<ProvisionedMachineTO> serverAgePopupDetails(UserTO user, List<Long> groupIds, Long period) throws CMMException;
	
	public List<ProvisionedMachineTO> getUnTaggedServerDetails() throws CMMException;
	
	public List<ProvisionedMachineTO> geTaggedServerDetails() throws CMMException;
	
	public List<String> getTaggedEnvironmentNames(String hostName) throws CMMException;
	
	public List<ProvisionedMachineTO> getHostsWithIssues(List<String> hostNames) throws CMMException;
	
	public List<EnvironmentTO> getEnvironmentReservationDetails(Long id1, Long id2, UserTO user) throws CMMException;
	
	public Long getReservationCountForEnv(String environmentName, Date startDate, Date endDate) throws CMMException;
	
	public boolean updateEnvAppTestPhase(Long applicationId, Long envId, Long testingPhaseId) throws CMMException;
	
	public ProvisionedMachineTO getHostname(String envId) throws CMMException;
	
	List<UserDefinedEnvParamsTO> userDefinedNolioParams(Long environmentId) throws CMMException;
	
	List<UserDefinedEnvParamsTO> fetchUserDefinedEnvParamsForScript(Long environmentId) throws CMMException;
}
