package com.ext.dao;

import java.util.List;
import java.util.Map;
import com.framework.exception.CMMException;
import com.framework.to.EnvironmentTO;
import com.framework.to.LifeCycleServiceManagementTO;
import com.framework.to.ServiceTO;

/**
 * The interface defines the functions that stores and fetches values from the database for Life Cycle Service Management.
 */
public interface LifeCycleServiceManagementDAO {
	
	/**
	 * Interface for fetching environment values returns information about environment that a user can add into Life Cycle.
	 *
	 * @param selectedApplication
	 *                The Applications upon which environments are fetched.
	 * @return A Map of Long and String which has ID and name for each environment.
	 * @throws CMMException
	 */
	Map<Long, String> getEnvironmentForServiceManagement(Long selectedApplication, Long selectedPhase, Long selectedRelease) throws CMMException;
	
	/**
	 * Interface for fetching Services values returns information about services that a user can add into Life Cycle.
	 *
	 * @return A Map of Long and String which has ID and name for each service.
	 * @throws CMMException
	 */
	Map<Long, String> getServiceForServiceManagement() throws CMMException;
	
	/**
	 * Interface for adding all details for service management, service management environments and service management services.
	 *
	 * @param serviceManagement
	 *                All the Life Cycle service management details that are to be saved in the database.
	 * @throws CMMException
	 */
	void addServiceManagementDetails(LifeCycleServiceManagementTO serviceManagement) throws CMMException;
	
	/**
	 * Interface for fetching service management details returns information about services that a user can use in Life Cycle.
	 *
	 * @param phaseId
	 *                The phase ID upon which service details are fetched.
	 * @return A instance of LifeCycleServiceManagementTO which contains all the related information.
	 * @throws CMMException
	 */
	LifeCycleServiceManagementTO fetchServiceManagementDetails(Long phaseId) throws CMMException;
	
	List<LifeCycleServiceManagementTO> fetchLinkedEnvironmentLinkedServiceList(Long applicationPhaseLinkId) throws CMMException;
	
	List<EnvironmentTO> getEnvironmentList(List<Long> environmentIdList) throws CMMException;
	
	List<ServiceTO> fetchLinkedServiceList(Long selectedPhaseId) throws CMMException;
	
	Map<Long, String> getServiceForServiceManagementList(Long selectedApplication) throws CMMException;
}
