/**
 *
 */
package com.ext.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.to.DataStoreTO;
import com.framework.to.VSphereDetailsTO;

/**
 * @author 460650
 */
public interface VSphereDetailsDAO {
	
	VSphereDetailsTO getVSphereDetails() throws CMMException;
	
	void addDataStoresToDB(List<DataStoreTO> dataStoreList, Long dataCenterId) throws CMMException;
	
	VSphereDetailsTO getVSphereDetailsById(Long dataCentre) throws CMMException;
	
	List<DataStoreTO> getDataStoreListFromDB(Long dataCentre) throws CMMException;
}
