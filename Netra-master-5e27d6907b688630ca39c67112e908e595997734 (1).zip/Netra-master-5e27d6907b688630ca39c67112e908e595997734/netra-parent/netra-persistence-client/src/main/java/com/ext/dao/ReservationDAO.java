package com.ext.dao;

import java.util.Date;
import java.util.List;
import com.framework.exception.CMMException;
import com.framework.to.ApplicationTO;
import com.framework.to.EnvironmentTO;
import com.framework.to.ProjectsTO;
import com.framework.to.ReleasePlanningTO;
import com.framework.to.ReservationMailTO;
import com.framework.to.ReservationTO;
import com.framework.to.StatusTO;
import com.framework.to.TestingPhaseTO;
import com.framework.to.TestingTypeTO;
import com.framework.to.UserGroupTO;
import com.framework.to.UserTO;

/**
 * @author TCS
 */
public interface ReservationDAO {
	
	void deleteReservations(ReservationTO reservationTO, Long statusValue) throws CMMException;
	
	boolean makereservation(ReservationTO reservation) throws CMMException;
	
	/**
	 * This function is called on the page load to get the count of active reservations
	 *
	 * @param UserID
	 * @return
	 * @throws CMMException
	 */
	Long getActiveReservationCount(Long clientId, List<Long> clientIdlist, ReservationTO reservationTO) throws CMMException;
	
	List<ReservationTO> getActiveReservations(UserTO userTo, List<Long> clientIdlist) throws CMMException;
	
	/**
	 * This function is called on the page load to get the count of expired reservations
	 *
	 * @param UserID
	 * @return
	 * @throws CMMException
	 */
	Long getExpiredReservationCount(Long clientId, List<Long> clientIdlist, ReservationTO reservationTO) throws CMMException;
	
	/**
	 * This function is called on the page load to get the count of future reservations
	 *
	 * @param UserID
	 * @return
	 * @throws CMMException
	 */
	Long getFutureReservationCount(Long clientId, List<Long> clientIdlist, ReservationTO reservationTO) throws CMMException;
	
	String getStatusDesc(Long id) throws CMMException;
	
	List<EnvironmentTO> getReservationSummaryDetails(ReservationTO reservation, Date firstDate, Date lastDate, Long testingPhaseId) throws CMMException;
	
	boolean checkReservationAvailability(ReservationTO reservationTO) throws CMMException;
	
	List<ReservationTO> getExpiredReservations(UserTO userTo, List<Long> clientIdlist) throws CMMException;
	
	List<ReservationTO> getFutureReservations(UserTO userTo, List<Long> clientIdlist) throws CMMException;
	
	ReservationTO reservationDetail(Long resId) throws CMMException;
	
	List<ReservationTO> searchReservation(ReservationTO reservationTO) throws CMMException;
	
	ReservationTO searchReservationForConflict(Long reservationId) throws CMMException;
	
	List<EnvironmentTO> getReservationsSummaryForUser(Long userId, Long clientId) throws CMMException;
	
	List<ReservationTO> getRelease(ReservationTO reservationTO) throws CMMException;
	
	List<EnvironmentTO> getAllReservationSummaryDetails(List<Long> appIdList, List<Long> clientId, List<Long> projectId, Date firstDate, Date lastDate, Long testingPhaseId) throws CMMException;
	
	List<Object[]> getActiveReservationCountOfAllUsers() throws CMMException;
	
	List<Object[]> getExpiredReservationCountOfAllUsers() throws CMMException;
	
	List<Object[]> getFutureReservationCountOfAllUsers() throws CMMException;
	
	List<ReservationTO> getReservationsByUser(ReservationTO reservationTO, Long clientId) throws CMMException;
	
	List<Object[]> getAvailableCountForAllHardware() throws CMMException;
	
	List<Object[]> getUnavailableCountForAllHardware() throws CMMException;
	
	List<Object[]> getAllocatedCountForAllHardware() throws CMMException;
	
	Long getAvailableCount(long status) throws CMMException;
	
	Long getAllocatedCount(long status) throws CMMException;
	
	Long getUnavailableCount(long status) throws CMMException;
	
	List<ReservationTO> getReservationsExpiringIn1Day() throws CMMException;
	
	List<ReservationTO> getReservationStatistics(ReservationTO reservationTO) throws CMMException;
	
	List<ReservationTO> getReservationsExpiringIn15Days() throws CMMException;
	
	List<TestingPhaseTO> getAllTestingCycle() throws CMMException;
	
	List<TestingTypeTO> getAllTestingType() throws CMMException;
	
	Long updateReservation(ReservationTO reservationNew, ReservationTO reservationOld) throws CMMException;
	
	void updateReservationForConflict(ReservationTO reservationTO) throws CMMException;
	
	boolean checkNoConflictDurationAvailability(ReservationTO reservationTO) throws CMMException;
	
	List<ReservationTO> getReservationsForEnvironment(Long envId) throws CMMException;
	
	Long searchConflicting(ReservationTO reservation) throws CMMException;
	
	int getCountofSharedReservation(ReservationTO reservation) throws CMMException;
	
	boolean getLockedStatusForTheDuration(ReservationTO reservation) throws CMMException;
	
	List<ReservationTO> getHourlyReservationSummaryDetails(Long environmentId, Date selectedDate, Date selectedDateLast) throws CMMException;
	
	Long reserveEnvironment(ReservationTO reservation) throws CMMException;
	
	List<ReservationTO> getConflictReservation(Long resvId) throws CMMException;
	
	ReservationTO getReservationDetails(Long resvId) throws CMMException;
	
	boolean checkNoConflictDurationAvailabilityForApproved(ReservationTO reservationTO) throws CMMException;
	
	List<ApplicationTO> getAllReservationSummaryDetailsApp(List<Long> envIdList, List<Long> appIdList1, List<Long> clientId, List<Long> projectId, Date firstDate, Date lastDate, Long testingPhaseId, List<UserGroupTO> userGroupIds, Long userClientId) throws CMMException;
	
	List<ReservationTO> getHourlyReservationSummaryDetailsApp(Long applicationId, Date selectedDate, Date selectedDateLast) throws CMMException;
	
	List<EnvironmentTO> getAllEnvironmentsDrivenByEnv(Long selectedProject, Long clientId, Long userId) throws CMMException;
	
	Long getWorkflowLevelID(Long resId);
	
	List<ApplicationTO> getAllApplicationsDrivenByEnv(Long environmentId, Long clientId, Long projectId, List<UserGroupTO> userGroupIds, Long userClientId) throws CMMException;
	
	Long getPendingReservationCount(long clientId, List<Long> clientIdlist, ReservationTO reservationTO) throws CMMException;;
	
	Long getRejectedReservationCount(long clientId, List<Long> clientIdlist, ReservationTO reservationTO) throws CMMException;
	
	List<ReservationTO> getPendingReservations(UserTO userTo, List<Long> clientIdlist) throws CMMException;
	
	List<ReservationTO> getRejectedReservations(UserTO userTo, List<Long> clientIdlist) throws CMMException;
	
	Long getCancelledReservationCount(long clientId, List<Long> clientIdlist, ReservationTO reservationTO) throws CMMException;
	
	List<ReservationTO> getCancelledReservation(UserTO userTo, List<Long> clientIdlist) throws CMMException;
	
	List<StatusTO> getStatusList() throws CMMException;
	
	String getReservationToDate(Long resId) throws CMMException;
	
	Long repetetiveReservation(ReservationTO reservation, List<ReservationTO> represerv) throws CMMException;
	
	Long getuserId(Long id) throws CMMException;
	
	boolean getLockedStatusForTheDurationForUpdate(ReservationTO reservation) throws CMMException;
	
	List<ReservationTO> getChildReservationByParentID(Long id) throws CMMException;
	
	ReservationMailTO getMailContent(Long status) throws CMMException;
	
	String getBUNameForApplication(Long id) throws CMMException;
	
	boolean isEnvironmentEndDateBeforeReservationEndDate(Long envId, Date reservationEndDate) throws CMMException;
	
	public List<ReservationTO> getReservationForCancellation(UserTO user, ReservationTO reservationTO) throws CMMException;
	
	public Long getWorkflow_levelID(Long resId) throws CMMException;
	
	public ReservationTO getProjectNameForReservation(Long appId, Long resId) throws CMMException;
	
	public String getEnvironmentStartDate(Long envID) throws CMMException;
	
	public String getEnvironmentEndDate(Long envID) throws CMMException;
	
	public List<ReleasePlanningTO> fetchReleases(Long envId, Long applicationId) throws CMMException;
	
	public List<TestingPhaseTO> fetchPhases(Long applicationId) throws CMMException;
	
	public ReleasePlanningTO fetchPlanDate(Long releaseId) throws CMMException;
	
	public List<EnvironmentTO> fetchEnvironments(Long applicationid, Long releasePlanId, Long phaseId) throws CMMException;
	
	public List<ProjectsTO> getAllProjectsProjectView(List<Long> cliendIdList) throws CMMException;
}
