package com.ext.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.report.AppRelDetailsVO;
import com.framework.to.ApplicationMobileTestingTO;
import com.framework.to.TestExecutionResultsTO;
import com.framework.to.TestingToolsTO;

public interface TestExecutionResultsDAO {
	
	void updateTestingTools(TestingToolsTO testingToolsConfiguration) throws CMMException;
	
	void addTestExecutionResults(TestExecutionResultsTO testExecutionResultsTO) throws CMMException;
	
	List<TestExecutionResultsTO> searchTestResults(TestExecutionResultsTO testExecutionResultsTO) throws CMMException;
	
	List<ApplicationMobileTestingTO> searchTestResultsPerfecto(ApplicationMobileTestingTO appMobileTestingTO) throws CMMException;
	
	TestExecutionResultsTO getTestResultsDetails(TestExecutionResultsTO testExecutionResultsTO) throws CMMException;
	
	AppRelDetailsVO getDetailsFromRequest(Long reqID) throws CMMException;
	
	TestExecutionResultsTO getTestResultsDetailsForReport(Long serviceRequestId) throws CMMException;
}
