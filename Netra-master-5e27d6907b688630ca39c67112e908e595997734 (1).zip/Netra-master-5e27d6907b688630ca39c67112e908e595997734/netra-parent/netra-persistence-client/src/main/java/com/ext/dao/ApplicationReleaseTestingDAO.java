/**
 *
 */
package com.ext.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.to.ApplicationReleaseTestTO;

/**
 * @author 460650
 */
public interface ApplicationReleaseTestingDAO {
	
	/**
	 * This method fetches a list of application release test details(Eg. testing tool and testing scripts path) according to releaseId from DB.
	 *
	 * @param releaseId
	 *                of Application Release
	 * @return List<ApplicationReleaseTestTO> List of application release test details.
	 * @throws CMMException
	 */
	List<ApplicationReleaseTestTO> getAppReleaseTestDetailsByReleaseId(Long releaseId, long environmentPhaseId) throws CMMException;
}
