package com.ext.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.to.ApplicationProfileDetailsTO;
import com.framework.to.ApplicationProfileTO;
import com.framework.to.ApplicationReleaseDbTO;
import com.framework.to.ApplicationReleaseTO;
import com.framework.to.ApplicationTO;
import com.framework.to.BuildToolDefinitionTO;
import com.framework.to.BuildToolTO;
import com.framework.to.DataMaskingToolTO;
import com.framework.to.EnvironmentDetailsTO;
import com.framework.to.HardwareTO;
import com.framework.to.PlatformTemplateTO;
import com.framework.to.RepositoryTO;
import com.framework.to.ServiceRequestTO;
import com.framework.to.SoftwareconfigTO;
import com.framework.to.SonarDetailTO;
import com.framework.to.StatusTO;
import com.framework.to.TestingToolTO;
import com.framework.to.UserDefinedRelParamsTO;
import com.framework.to.UserGroupTO;

public interface ApplicationReleaseDAO {
	
	List<ApplicationReleaseTO> searchRelease(ApplicationReleaseTO applicationReleaseTO) throws CMMException;
	
	List<StatusTO> getStatusList() throws CMMException;
	
	List<ApplicationProfileTO> getAllApplicationProfiles() throws CMMException;
	
	List<ApplicationProfileTO> getAllApplicationProfiles(List<UserGroupTO> userGroupIds) throws CMMException;
	
	Long addRelease(ApplicationReleaseTO applicationReleaseTO) throws CMMException;
	
	ApplicationProfileDetailsTO fetchAppProDetails(Long profileid, Long softwareid) throws CMMException;
	
	List<ApplicationProfileDetailsTO> fetchAppProDetails(Long profileid, Long serverGroup, Long serevrId) throws CMMException;
	
	List<ApplicationProfileDetailsTO> fetchApplicationProfileDetails(Long profileid, Long serverGroup) throws CMMException;
	
	ApplicationReleaseTO getReleaseDetails(ApplicationReleaseTO applicationReleaseTO) throws CMMException;
	
	HardwareTO fetchTemplateName(Long softwareconfigid, Long serverid) throws CMMException;
	
	void editRelease(ApplicationReleaseTO applicationReleaseTO) throws CMMException;
	
	boolean checkName(ApplicationReleaseTO applicationReleaseTO) throws CMMException;
	
	SoftwareconfigTO getSoftwareConfigDetails(long mappedSoftwareId) throws CMMException;
	
	List<BuildToolTO> fetchBuildTools() throws CMMException;
	
	List<ApplicationProfileTO> getAllApplicationProfiles(Long applicationId) throws CMMException;
	
	List<ApplicationProfileDetailsTO> fetchAppProDetails(Long selectedProfile) throws CMMException;
	
	List<EnvironmentDetailsTO> fetchEnvDetails(Long selectedEnv) throws CMMException;
	
	List<SoftwareconfigTO> getSoftwareListForProfile(Long selectedProfile, String existingSoftwareConfigIds) throws CMMException;
	
	List<SoftwareconfigTO> getSoftwareListForProfileForAppServer(Long selectedProfile, String existingSoftwareConfigIds) throws CMMException;
	
	List<ApplicationReleaseDbTO> fetchReleaseDetails(Long id) throws CMMException;
	
	ApplicationReleaseTO getDetailsForRelease(Long id) throws CMMException;
	
	SonarDetailTO getCodeAnalysisDetail(Long id) throws CMMException;
	
	ServiceRequestTO editReleaseDetails(ApplicationReleaseTO applicationReleaseTO) throws CMMException;
	
	ServiceRequestTO editReleaseDetailsForDbRefresh(ApplicationReleaseTO applicationReleaseTO) throws CMMException;
	
	ApplicationReleaseTO fetchReleaseDetails(ApplicationReleaseTO applicationReleaseTO) throws CMMException;
	
	ApplicationReleaseTO fetchCurrentReleaseName(ApplicationReleaseTO applicationReleaseTO) throws CMMException;
	
	ServiceRequestTO editDeployment(ApplicationReleaseTO applicationReleaseTO) throws CMMException;
	
	ServiceRequestTO submitTestingRequest(ApplicationReleaseTO applicationReleaseTO) throws CMMException;
	
	ServiceRequestTO submitTestingRequestSmokeTesting(ApplicationReleaseTO applicationReleaseTO) throws CMMException;
	
	List<ApplicationReleaseTO> getAllReleaseIds(long startReleaseId, long currentReleaseId, long applicationId) throws CMMException;
	
	List<ApplicationReleaseTO> getReleaseIdInDecreasingOrder(long startReleaseId, long currentReleaseId, long applicationId) throws CMMException;
	
	List<ApplicationReleaseTO> fetchAllReleasesForApplication(long currentReleaseId, long applicationId) throws CMMException;
	
	Long getReleaseIdFromRequestId(long requestId) throws CMMException;
	
	List<TestingToolTO> fetchTestingTool() throws CMMException;
	
	List<ApplicationTO> getApplicationListForProfile(Long selectedProfile, Long userId) throws CMMException;
	
	PlatformTemplateTO getPlatformTempleteDetails(Long platformTempleteId) throws CMMException;
	
	List<RepositoryTO> fetchRepoDetails(Long applicationId) throws CMMException;
	
	boolean checkVersionName(String versionName) throws CMMException;
	
	ApplicationReleaseTO fetchSelectedExistingReleaseDetails(ApplicationReleaseTO applicationReleaseTO) throws CMMException;
	
	ApplicationReleaseTO checkReleaseIfExists(Long environmentId, Long selectedApplication) throws CMMException;
	
	List<ApplicationReleaseTO> fetchAllReleasesForApplication(Long applicationId) throws CMMException;
	
	List<String> getrepositDetails(Long id) throws CMMException;
	
	List<DataMaskingToolTO> getAllMaskingTools() throws CMMException;
	
	/**
	 * This method fetches application release id for given application release name.
	 *
	 * @param applicationRelease
	 *                name of application release
	 * @return Long id of application release
	 * @throws CMMException
	 *                 custom exception
	 */
	Long fetchApplicationReleaseIdByName(String applicationRelease, Long applicationId) throws CMMException;
	
	String getReleaseName(Long id) throws CMMException;
	
	ApplicationReleaseTO fetchRollbackReleaseDetails(ApplicationReleaseTO applicationReleaseTO) throws CMMException;
	
	void updateBuildLocation(BuildToolDefinitionTO buildToolDefinitionTO) throws CMMException;
	
	public List<ApplicationReleaseDbTO> fetchDBReleaseDetails(Long id) throws CMMException;
	
	List<UserDefinedRelParamsTO> loadUserDefinedReleaseParams(Long releaseId) throws CMMException;
	
	String getRepoType(Long repoID) throws CMMException;
	
	List<UserDefinedRelParamsTO> loadUserDefinedReleaseParamsForScript(Long releaseId) throws CMMException;
}
