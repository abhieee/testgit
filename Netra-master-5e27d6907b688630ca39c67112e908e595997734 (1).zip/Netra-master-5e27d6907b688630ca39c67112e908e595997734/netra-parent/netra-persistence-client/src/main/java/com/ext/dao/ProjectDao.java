package com.ext.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.to.BusinessUnitTO;
import com.framework.to.ProjectsTO;
import com.framework.to.StatusTO;

public interface ProjectDao {
	
	void addProject(ProjectsTO projectsTO) throws CMMException;
	
	boolean checkName(ProjectsTO projectsTO) throws CMMException;
	
	List<BusinessUnitTO> getAllClients(Long clientId) throws CMMException;
	
	List<StatusTO> getStatusList() throws CMMException;
	
	List<ProjectsTO> searchProject(ProjectsTO projectsTO) throws CMMException;
	
	ProjectsTO getProjectDetails(ProjectsTO projectsTO) throws CMMException;
	
	Long editProject(ProjectsTO projectsTO) throws CMMException;
	
	List<ProjectsTO> fetchAllProjects() throws CMMException;
}
