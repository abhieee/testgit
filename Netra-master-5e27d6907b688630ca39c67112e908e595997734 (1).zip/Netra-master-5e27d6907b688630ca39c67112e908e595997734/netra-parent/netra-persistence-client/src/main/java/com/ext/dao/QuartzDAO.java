package com.ext.dao;

import com.framework.exception.CMMException;

/**
 * This interface is used to update the history of the quartz triggers in the database.
 *
 * @author TCS
 */
public interface QuartzDAO {
	
	/**
	 * @param args
	 *                -An array containing the details of the trigger.
	 * @return boolean - if the insertion of the record was successful
	 * @throws CMMException
	 */
	boolean insertFiredTimeQuartzhistory(Object[] args) throws CMMException;
	
	/**
	 * @param args
	 *                -An array containing the details of the trigger.
	 * @return boolean - if the update of the record was successful
	 * @throws CMMException
	 */
	boolean updateCompletedTimeQuartzhistory(Object[] args) throws CMMException;
	
	/**
	 * @param args
	 *                -An array containing the details of the trigger.
	 * @return boolean - if the update of the record was successful
	 * @throws CMMException
	 */
	boolean updateMisfiredTimeQuartzhistory(Object[] args) throws CMMException;
}
