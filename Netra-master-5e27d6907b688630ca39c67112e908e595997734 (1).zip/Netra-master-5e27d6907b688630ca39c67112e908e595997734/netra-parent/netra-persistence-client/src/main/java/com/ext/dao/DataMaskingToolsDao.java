package com.ext.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.to.DataMaskingConfigTO;
import com.framework.to.DataMaskingToolTO;

public interface DataMaskingToolsDao {
	
	List<DataMaskingToolTO> getAllDataMaskingToolName() throws CMMException;
	
	List<DataMaskingConfigTO> getAllDataMaskingToolsConfigDetailsForApp(Long applicationId, Long projectId, Long buId, String toolName, Long searchCount, int firstResult, int tableSize, List<Long> buList) throws CMMException;
	
	boolean saveDataMaskingToolConfigDetails(DataMaskingConfigTO dataMaskToolsTO) throws CMMException;
	
	DataMaskingConfigTO getConfigDetailsById(Long dataMaskConfigId) throws CMMException;
	
	boolean updateDataMaskingToolsConfigDetails(DataMaskingConfigTO dataMaskToolsTO) throws CMMException;
	
	String getToolNameById(Long toolId) throws CMMException;
}
