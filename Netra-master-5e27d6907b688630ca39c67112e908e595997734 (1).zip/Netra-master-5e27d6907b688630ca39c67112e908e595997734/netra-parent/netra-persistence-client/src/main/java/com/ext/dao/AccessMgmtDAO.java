package com.ext.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.to.AccessTO;
import com.framework.to.RoleTO;
import com.framework.to.ScreenTO;

public interface AccessMgmtDAO {
	
	public void addAccess(AccessTO accessMgmtTO) throws CMMException;
	
	public AccessTO getAccessDetails(AccessTO accessMgmtTO) throws CMMException;
	
	public void editAccess(AccessTO accessMgmtTO) throws CMMException;
	
	public List<RoleTO> getAllRoles() throws CMMException;
	
	public List<RoleTO> getAllRoleForAdd() throws CMMException;
	
	public List<RoleTO> getAllRoleForDefineOrder() throws CMMException;
	
	public List<ScreenTO> getAllScreens() throws CMMException;
	
	public RoleTO getRole(RoleTO roleTO) throws CMMException;
	
	public List<RoleTO> getAllRoles(Long clientId) throws CMMException;
	
	public List<Object[]> getScreenTree() throws CMMException;
	
	public List<ScreenTO> getAllParentScreens() throws CMMException;
	
	public void deleteAccess(AccessTO accessMgmtTO) throws CMMException;
	
	public List<AccessTO> getScreenAccess(AccessTO accessMgmtTO) throws CMMException;
	
	public List<RoleTO> getAllRolesForAccessMgmt(Long userId, Long clientId) throws CMMException;
}
