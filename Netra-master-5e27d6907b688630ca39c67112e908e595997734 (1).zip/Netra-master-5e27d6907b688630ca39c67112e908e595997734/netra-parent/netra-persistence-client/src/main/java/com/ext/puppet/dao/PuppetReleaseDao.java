package com.ext.puppet.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.puppetMaster.to.PuppetMasterDetailsTO;
import com.framework.puppetMaster.to.PuppetProcess;

public interface PuppetReleaseDao {
	
	List<PuppetMasterDetailsTO> searchPuppetRelease(PuppetMasterDetailsTO puppetMasterDetailsTO) throws CMMException;
	
	PuppetMasterDetailsTO loadPuppetRelease(PuppetMasterDetailsTO puppetMasterDetailsTO) throws CMMException;
	
	void editPuppetRelease(PuppetMasterDetailsTO puppetMasterDetailsTO) throws CMMException;
	
	boolean addPuppetProcessesInDB(List<PuppetProcess> processList) throws CMMException;
}
