package com.ext.dao;

import java.sql.Blob;
import java.util.List;
import com.framework.exception.CMMException;
import com.framework.nolio.to.NolioProcessParametersTO;
import com.framework.to.ActivitySoftwareMappingTO;
import com.framework.to.ApplicationParameterTO;
import com.framework.to.ApplicationProfileConfigParamTmpltMappingTO;
import com.framework.to.ApplicationProfileConfigParamsTO;
import com.framework.to.ApplicationProfileConfigTO;
import com.framework.to.ApplicationProfileDetailsTO;
import com.framework.to.ApplicationProfileMappingTO;
import com.framework.to.ApplicationProfileSoftwareParamertsTO;
import com.framework.to.ProvisionedMachineTO;

public interface ApplicationParameterDAO {
	
	List<ActivitySoftwareMappingTO> fetchActivitySoftMapDetail(Long selectedSoftwareConfig) throws CMMException;
	
	List<NolioProcessParametersTO> getSoftwareProperties(Long configid, Long activityId) throws CMMException;
	
	ApplicationProfileMappingTO getApplicationProfileMapId(Long applicationid, Long profileid) throws CMMException;
	
	Long getApplicationProfileDetId(Long selectedProfile, Long selectedSoftware, Long selectedServer, Long servergroup) throws CMMException;
	
	Long submitApplicationParameterDetail(ApplicationParameterTO applicationParameterTO) throws CMMException;
	
	Long editApplicationParameterDetail(ApplicationParameterTO applicationParameterTO) throws CMMException;
	
	List<ApplicationProfileSoftwareParamertsTO> checkDetailAlreadyPresent(Long appProfileDetailId, Long appProfileMapId) throws CMMException;
	
	ProvisionedMachineTO fetchProvisionedMachineName(Long hardwareId) throws CMMException;
	
	List<ApplicationProfileConfigTO> searchAppProfileConfigDetails(ApplicationParameterTO appParaTo) throws CMMException;
	
	ApplicationProfileConfigTO searchConfigFile(Long configFileId) throws CMMException;
	
	ApplicationProfileConfigTO searchTemplateFile(Long configFileId) throws CMMException;
	
	void deleteConfigFile(Long configFileId) throws CMMException;
	
	void deleteTemplateFile(Long configFileId, Long userId) throws CMMException;
	
	List<ApplicationProfileDetailsTO> getselectedIPAddress(Long selectedProfile, Long selectedServer) throws CMMException;
	
	List<NolioProcessParametersTO> fetchSoftwareParameter(Long selectedSoftware) throws CMMException;
	
	boolean saveConfigurationFile(ApplicationProfileConfigTO appProToObj) throws CMMException;
	
	ApplicationParameterTO loadParameter(Long configFileId, Long selectedProfile, Long selectedApplication) throws CMMException;
	
	ApplicationParameterTO fetchParameterForInvMgmt(Long configFileId, Long environmentId) throws CMMException;
	
	void saveParameter(ApplicationParameterTO applicationParameterTO) throws CMMException;
	
	void saveGoldToConfigTemplate(Blob templateFile, Long configFileId, Long userId, String paramString, String originalLine) throws CMMException;
	
	List<ApplicationProfileConfigTO> getTemplateFilesForApplication(Long appId, Long selectedProfile, Long softwareConfigId, Long serverNumber) throws CMMException;
	
	List<ApplicationProfileConfigParamsTO> fetchParameterList(Long configFileId) throws CMMException;
	
	ApplicationProfileConfigParamTmpltMappingTO fetchParameterList(Long configFileId, Long parameterId, Long envId) throws CMMException;
	
	String findNolioProcessParameterValue(Long nolioProcessParameterId, Long serverNumber, Long softwareConfigId, Long selectedProfile) throws CMMException;
	
	String findUserDefinedParameterValue(String param, Long appPrfConfigId, Long envId, Long userDefinedParameterCount) throws CMMException;
	
	boolean saveParamsForTemplateFile(List<ApplicationProfileConfigParamsTO> appProfConfigParamList, Long configFileId) throws CMMException;
	
	List<ApplicationProfileConfigTO> fetchConfigFileNames(Long selectedSoftware, Long selectedApplication, Long selectedServer) throws CMMException;
	
	boolean editFileTargetPathForAP(Long configFileId, String fileTargetPath) throws CMMException;
	
	List<ApplicationProfileDetailsTO> getFriendlyServerList(Long selectedApplication) throws CMMException;
	
	List<ApplicationProfileDetailsTO> getSoftwareListforFriendlyServerName(Long selServer) throws CMMException;
	
	ApplicationProfileConfigTO searchIfTemplateFileExist(Long configFileId) throws CMMException;
	
	String findServerParameterValue(String param, Long appPrfId, Long envId) throws CMMException;
	
	ApplicationProfileDetailsTO getappPrfDet(Long selectedProfile, Long selectedSoftware, Long selectedServer) throws CMMException;
}
