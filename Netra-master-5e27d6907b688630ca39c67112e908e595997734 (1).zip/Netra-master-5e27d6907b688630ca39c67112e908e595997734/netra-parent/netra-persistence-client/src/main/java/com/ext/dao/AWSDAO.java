package com.ext.dao;

import java.util.List;
import java.util.Map;
import com.framework.exception.CMMException;
import com.framework.to.AWSAccountTO;
import com.framework.to.MachineTemplateAwsTO;
import com.framework.to.PlatformTemplateAwsTO;
import com.framework.to.PlatformTemplateTO;
import com.framework.to.aws.AWSEC2ImageTO;

/**
 * The is the dao interface for accessing the persistence layer for aws related transactions.
 *
 * @author TCS
 */
public interface AWSDAO {
	
	/**
	 * Fetches all the aws accounts that have been added to the database.
	 *
	 * @return List of all the accounts in database
	 * @throws CMMException
	 */
	List<AWSAccountTO> getAllAWSAccountsList() throws CMMException;
	
	/**
	 * Checks whether a aws account exists with the given name or not.
	 *
	 * @param awsAccountName
	 *                the name of the account which needs to be matched
	 * @return true if account exists, false otherwise
	 * @throws CMMException
	 */
	boolean checkAWSAccountExists(String awsAccountName) throws CMMException;
	
	/**
	 * Add a AWS Account to the database
	 *
	 * @param awsAccount
	 *                object of AWSAccountTO containing the details of aws account which needs to be added
	 * @throws CMMException
	 */
	void addAWSAccount(AWSAccountTO awsAccount) throws CMMException;
	
	/**
	 * Fetches a aws account details based on the account id.
	 *
	 * @param awsAccountId
	 *                id of the aws account as in the database
	 * @return object of AWSAccountTO
	 * @throws CMMException
	 */
	AWSAccountTO getAWSAccount(Long awsAccountId) throws CMMException;
	
	/**
	 * Updates the details of an aws account
	 *
	 * @param awsAccount
	 *                object of AWSAccountTO containing the details of the aws account which needs to be updated.
	 * @throws CMMException
	 */
	void updateAWSAccount(AWSAccountTO awsAccount) throws CMMException;
	
	/**
	 * Removed an aws account details from the database.
	 *
	 * @param awsAccountId
	 *                id of the aws account which has to be removed.
	 * @throws CMMException
	 */
	void deleteAWSAccount(Long awsAccountId) throws CMMException;
	
	/**
	 * Creates a map of the aws credentials which would be used for accessing the AWS services. The key of this map is the Access Key and the value is the
	 * Secure secret key.
	 *
	 * @param awsAccountId
	 *                id of the aws account for which the map needs to be created
	 * @return map of the credentials
	 * @throws CMMException
	 */
	Map<String, String> getCredentialMap(Long awsAccountId) throws CMMException;
	
	/**
	 * Add an aws image to the local database for use in profiles. Only those images which have been added would be available to netra user for environment
	 * creation and deployments.
	 *
	 * @param image
	 *                object of AWSEC2ImageTO for image id
	 * @param awsAccountId
	 *                aws account id for which the image is being added
	 * @param platformTemplate
	 *                the platform details which needs to be added
	 * @return string "IMAGE_EXISTS" in case the images being added already exists or "IMAGE_ADDED" once the image is successfully added.
	 * @throws CMMException
	 */
	String addImageToTemplates(AWSEC2ImageTO image, Long awsAccountId, PlatformTemplateTO platformTemplate) throws CMMException;
	
	/**
	 * Fetches machine templates for aws. Note : It fetches only those aws templates which have sdk 1.7.1
	 *
	 * @return list of machine templates of aws
	 * @throws CMMException
	 */
	List<MachineTemplateAwsTO> getAllMachineTemplateAws() throws CMMException;
	
	/**
	 * Fetches a list of all the aws platform templates which are tagged to the provided account.
	 *
	 * @param awsAccountId
	 *                id of the aws account
	 * @return list of platform templates for aws
	 * @throws CMMException
	 */
	List<PlatformTemplateAwsTO> getAllPlatformTemplateAws(Long awsAccountId) throws CMMException;
}
