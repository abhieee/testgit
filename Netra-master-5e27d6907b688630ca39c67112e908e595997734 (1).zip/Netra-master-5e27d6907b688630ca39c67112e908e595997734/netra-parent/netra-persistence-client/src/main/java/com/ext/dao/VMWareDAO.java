package com.ext.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.to.MachineTemplateTO;
import com.framework.to.PlatformMasterTO;
import com.framework.to.PlatformTemplateTO;
import com.framework.to.PlatformTypeTO;
import com.framework.to.StatusTO;
import com.framework.to.VSphereDetailsTO;

public interface VMWareDAO {
	
	List<PlatformMasterTO> fetchPlatforms() throws CMMException;
	
	boolean checkName(PlatformTemplateTO platformTemplateTO) throws CMMException;
	
	List<PlatformTypeTO> getAllPlatformTypes() throws CMMException;
	
	List<PlatformTypeTO> getDistributionListforFamilyType(String selectedFamilyType) throws CMMException;
	
	List<PlatformTypeTO> getVersionListforDistribution(String selectedDistribution) throws CMMException;
	
	List<PlatformTypeTO> getPackListforVersion(String selectedVersion) throws CMMException;
	
	void addVMTemplates(PlatformTemplateTO platformTemplatesTO, MachineTemplateTO machineTemplateTO, String vmTemplate) throws CMMException;
	
	List<PlatformTemplateTO> fetchPlatformTemplateList() throws CMMException;
	
	List<PlatformTemplateTO> searchTemplates(PlatformTemplateTO platformTemplateTO) throws CMMException;
	
	List<PlatformTemplateTO> searchTemplatesForBareMetal(PlatformTemplateTO platformTemplateTO) throws CMMException;
	
	List<PlatformTemplateTO> searchVMWare(PlatformTemplateTO platformTemplateTO) throws CMMException;
	
	List<StatusTO> getStatusList() throws CMMException;
	
	PlatformTemplateTO loadTemplateDetails(PlatformTemplateTO platformTemplatesTO) throws CMMException;
	
	void editBusinessUnit(PlatformTemplateTO platformTemplatesTO) throws CMMException;
	
	List<VSphereDetailsTO> getDataCenteList() throws CMMException;
	
	List<VSphereDetailsTO> getDataCenteListForPolicy(String cloudType) throws CMMException;
	
	Long addOSPlatformTemplate(PlatformTemplateTO platformTemplatesTO, String imageId, String imageName) throws CMMException;
	
	boolean addOSMachineTemplate(MachineTemplateTO machineTemplateTO, String flavorId, String flavorType, String disk, String username, String password) throws CMMException;
	
	List<PlatformTemplateTO> searchTemplatesForOS(PlatformTemplateTO platformTemplateTO) throws CMMException;
}
