package com.ext.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.nolio.to.NolioProcessParametersTO;
import com.framework.to.ApplicationProfileDetailsTO;
import com.framework.to.ApplicationProfileDockerTO;
import com.framework.to.ApplicationProfileMappingTO;
import com.framework.to.ApplicationProfileTO;
import com.framework.to.ApplicationTO;
import com.framework.to.StatusTO;
import com.framework.to.UserGroupTO;

public interface ApplicationProfileDAO {
	
	List<StatusTO> fetchEnvironmentStatusList() throws CMMException;
	
	ApplicationProfileTO addProfile(ApplicationProfileTO applicationProfileTO) throws CMMException;
	
	List<ApplicationProfileTO> searchAppProfile(ApplicationProfileTO applicationProfileTO, List<Long> clientidList, List<UserGroupTO> userGrps) throws CMMException;
	
	List<StatusTO> getStatusList() throws CMMException;
	
	ApplicationProfileTO getDetailsForProfile(Long id) throws CMMException;
	
	List<ApplicationProfileDetailsTO> fetchProfileDetails(Long id) throws CMMException;
	
	List<NolioProcessParametersTO> getUserDefinedReleaseParameters(Long softwareConfigId) throws CMMException;
	
	ApplicationProfileTO editProfile(ApplicationProfileTO applicationProfileTO) throws CMMException;
	
	boolean defineApplicationsForProfile(ApplicationProfileMappingTO applicationProfileMappingTO) throws CMMException;
	
	List<ApplicationTO> getSelectedApplicationsForProfile(Long profileId) throws CMMException;
	
	List<ApplicationTO> getApplicationsForProfile(List<Long> dapp) throws CMMException;
	
	List<ApplicationProfileTO> getProfilesForApplication(List<Long> def) throws CMMException;
	
	boolean checkName(ApplicationProfileTO applicationProfileTO) throws CMMException;
	
	/**
	 * This method is used to fetch the applicationProfileDetailsId.
	 *
	 * @param profileId
	 *                of applicationProfile
	 * @param softwareConfigId
	 *                of software.
	 * @param serverGroupId
	 *                of serverGroup.
	 * @return long applicationProfileDetailsId
	 * @throws CMMException
	 */
	long fetchApplicationProfileDetailsForMachines(long profileId, long softwareConfigId, long serverGroupId) throws CMMException;
	
	List<ApplicationProfileTO> searchAppProfileForAppPara(ApplicationProfileTO applicationProfileTO, List<Long> clientidList, List<UserGroupTO> userGroupIds) throws CMMException;
	
	List<String> getApplicationNames(Long id);
	
	ApplicationProfileDockerTO getProfileDockerDetails(Long envId) throws CMMException;
	
	List<ApplicationProfileDockerTO> fetchProfileDockerDetails(Long profileId) throws CMMException;
	
	List<NolioProcessParametersTO> getUserDefinedEnvParameters(Long softwareConfigId) throws CMMException;
}
