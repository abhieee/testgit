package com.ext.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.to.ReleasePlanningTO;

public interface ReleasePlanningDAO {
	
	Long releasePlanningAdd(ReleasePlanningTO releasePlanningTO) throws CMMException;
	
	boolean releasePlanningEdit(ReleasePlanningTO releasePlanningTO) throws CMMException;
	
	boolean checkName(ReleasePlanningTO releasePlanningTO) throws CMMException;
	
	List<ReleasePlanningTO> searchReleasePlanning(ReleasePlanningTO releasePlanningTO, List<Long> clientIdlist) throws CMMException;
	
	ReleasePlanningTO getReleasePlanningDetails(Long id) throws CMMException;
}