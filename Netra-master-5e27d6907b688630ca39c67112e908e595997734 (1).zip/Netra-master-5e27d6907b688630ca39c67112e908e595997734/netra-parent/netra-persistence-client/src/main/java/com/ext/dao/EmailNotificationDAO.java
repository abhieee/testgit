package com.ext.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.to.EmailNotificationTO;
import com.framework.to.MailSetupTO;
import com.framework.to.MsgHistoryTO;
import com.framework.to.ProjectsTO;
import com.framework.to.RoleTO;
import com.framework.to.ServiceMailTO;
import com.framework.to.ServiceRequestHistoryTO;
import com.framework.to.ServiceRequestTO;
import com.framework.to.ServiceTO;
import com.framework.to.UserTO;

public interface EmailNotificationDAO {
	
	List<ServiceTO> fetchServiceList() throws CMMException;
	
	List<RoleTO> fetchRoleList() throws CMMException;
	
	Long submitEmailNotificationDetails(EmailNotificationTO emailTO) throws CMMException;
	
	List<RoleTO> fetchDefinedRoles(List<Long> definedRoles) throws CMMException;
	
	EmailNotificationTO fetchExistingMailDetails(EmailNotificationTO emailTO) throws CMMException;
	
	List<String> fetchUsersListForMail(Long requestId) throws CMMException;
	
	MailSetupTO fetchReceiverDetails(Long serviceId, Long requestId) throws CMMException;
	
	void updateMessageHistory(MsgHistoryTO msgHistory) throws CMMException;
	
	ServiceTO fetchServiceName(long longValue) throws CMMException;
	
	List fetchUsersListForReservationMail(Long applicationIds) throws CMMException;
	
	List<String> fetchCcUsersListForMail(Long requestId) throws CMMException;
	
	List fetchUsersListForReservationMailCc(Long applicationIds) throws CMMException;
	
	List<String> fetchUsersListToMailForEnvironment(Long envId) throws CMMException;
	
	ServiceRequestTO fetchServiceDetailsMail(Long serviceRequestId) throws CMMException;
	
	List<ServiceRequestHistoryTO> fetchServiceMessages(Long serviceRequestId) throws CMMException;
	
	List<ServiceMailTO> fetchServiceMessage() throws CMMException;
	
	boolean editEmailNotificationDetails(EmailNotificationTO emailTO) throws CMMException;
	
	List<EmailNotificationTO> searchEmail(EmailNotificationTO emailTO, List<Long> clientIdlist) throws CMMException;
	
	List<ServiceTO> fetchService(Long selectedProjectId) throws CMMException;
	
	List<ProjectsTO> searchAllProjectsForEmail(Long selectedId, Long selectedClientId) throws CMMException;
	
	List<RoleTO> searchAllRolesForEmail(Long selectedId) throws CMMException;
	
	List<ProjectsTO> fetchProjectListForMultipleBU(List<Long> selectedBus) throws CMMException;
	
	MailSetupTO fetchReceiverDetailsForReservation(long makeReservationService, Long applicationId) throws CMMException;
	
	boolean checkBuConfiguration(EmailNotificationTO emailTO) throws CMMException;
	
	List<UserTO> fetchCurrentOwnerName(Long currentOwnerId) throws CMMException;
	
	List<UserTO> fetchCurrentOwner(Long resId) throws CMMException;
}