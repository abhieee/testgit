package com.ext.dao;

import com.framework.exception.CMMException;
import com.framework.to.VMDetailsTO;

public interface VMMgmtDAO {
	
	boolean addVmDetails(VMDetailsTO vmDetailsTO) throws CMMException;
	
	VMDetailsTO getVMDetails(VMDetailsTO vmTO) throws CMMException;
	
	VMDetailsTO getEnvVMDetails(long hardwareId, long serverGrpId, long environmentId) throws CMMException;
	
	/**
	 * This method is used to fetch the env details based upon request ID.
	 *
	 * @param requestId
	 *                of service request for which environment vm details needs to be fetched.
	 * @return VMDetailsTO which contains vm details for an env.
	 * @throws CMMException
	 */
	VMDetailsTO getEnvMDetailsByRequestId(long requestId) throws CMMException;
	
	/**
	 * @param machineId
	 * @param serverGrpId
	 * @param environmentId
	 * @return
	 */
	VMDetailsTO getEnvMachineDetails(long machineId, long serverGrpId, long environmentId) throws CMMException;
}
