package com.ext.dao;

import java.util.List;
import java.util.Map;
import com.framework.exception.CMMException;
import com.framework.to.ApplicationProfileTO;
import com.framework.to.ApplicationReleaseBuildTO;
import com.framework.to.ApplicationReleaseDbTO;
import com.framework.to.ApplicationReleaseNexusDetailsTO;
import com.framework.to.ApplicationReleaseSharedDetailsTO;
import com.framework.to.ApplicationReleaseSourcecodeTO;
import com.framework.to.ApplicationReleaseTO;
import com.framework.to.ApplicationTO;
import com.framework.to.BusinessUnitTO;
import com.framework.to.DeploymentPipelineForJiraTO;
import com.framework.to.EnvTypeTO;
import com.framework.to.EnvironmentApplicationTO;
import com.framework.to.EnvironmentDockerTO;
import com.framework.to.EnvironmentSoftwareAttributeTO;
import com.framework.to.EnvironmentTO;
import com.framework.to.JIRAConfigTO;
import com.framework.to.MultipleProfileDetailsTO;
import com.framework.to.MultipleProfilesTO;
import com.framework.to.NetraNexusDetailsTO;
import com.framework.to.PipelineRequestDetailsTO;
import com.framework.to.PlatformTemplateTO;
import com.framework.to.ProjectsTO;
import com.framework.to.ProvisionedMachineOSTO;
import com.framework.to.ProvisionedMachineTO;
import com.framework.to.QuartzHistoryTO;
import com.framework.to.ReleasePlanningTO;
import com.framework.to.RepositoryMasterTO;
import com.framework.to.ServiceJiraMappingTO;
import com.framework.to.ServiceRequestHistoryTO;
import com.framework.to.ServiceRequestTO;
import com.framework.to.ServiceTO;
import com.framework.to.SonarDetailTO;
import com.framework.to.TargetServerVO;
import com.framework.to.TestingPhaseTO;
import com.framework.to.TestingToolsTO;
import com.framework.to.UserTO;
import com.framework.to.VMDetailsTO;

public interface ServiceRequestDAO {
	
	ServiceRequestTO fetchServiceRequestDeatilsForPuppetAction() throws CMMException;
	
	ReleasePlanningTO getReleasePlanningDetails(Long id) throws CMMException;
	
	List<ServiceTO> getAllServices() throws CMMException;
	
	List<ServiceTO> getAllServices(Long clientId) throws CMMException;
	
	List<ServiceTO> getAllServicesNew(Long clientId, Long roleId) throws CMMException;
	
	List<TestingPhaseTO> getAllTestingCycles() throws CMMException;
	
	List<EnvTypeTO> getAllEnvTypes() throws CMMException;
	
	List<ApplicationProfileTO> getAllProfiles(Long appId) throws CMMException;
	
	List<ApplicationProfileTO> getAllProfiles() throws CMMException;
	
	List<EnvironmentSoftwareAttributeTO> loadAttributesDetails(Long softwareConfigId, Long environmentId) throws CMMException;
	
	boolean getInstallationStatus(Long softwareConfigId, Long environmentId) throws CMMException;
	
	boolean saveAttributesDetails(List<EnvironmentSoftwareAttributeTO> environmentSoftwareAttributeListTO) throws CMMException;
	
	ServiceRequestTO createEnvironmentForMachine(EnvironmentTO environmentTO, ServiceRequestTO requestTO) throws CMMException;
	
	List<ApplicationReleaseTO> getAllApplicationReleases(Long applicationProfileId) throws CMMException;
	
	List<ServiceRequestTO> searchServiceRequestList(ServiceRequestTO ServiceRequestTO) throws CMMException;
	
	List<MultipleProfileDetailsTO> searchMultiEnvReqList(MultipleProfileDetailsTO multipleProfileDetailsTO) throws CMMException;
	
	List<MultipleProfileDetailsTO> searchMultiEnvReqListDetails(MultipleProfileDetailsTO multipleProfileDetailsTO) throws CMMException;
	
	List<MultipleProfilesTO> searchMultipleProfileList(MultipleProfilesTO multipleProfilesTO) throws CMMException;
	
	List<ServiceRequestHistoryTO> getRequestDetails(Long selectRequestId) throws CMMException;
	
	List<ServiceRequestHistoryTO> getRequestDetailsForPipeline(Long selectRequestId) throws CMMException;
	
	List<ApplicationTO> getAllApplications(Long environmentId) throws CMMException;
	
	List<QuartzHistoryTO> fetchSchedulingRequestDetails(Long selectRequestId) throws CMMException;
	
	ApplicationProfileTO fetchMultiEnvReqDetails(Long selectRequestId) throws CMMException;
	
	VMDetailsTO fetchVMDetail(Long selectedEnvironment, Long hardwareid, Long serverGpNum) throws CMMException;
	
	void updateServiceRequest(String flag, Long requestId) throws CMMException;
	
	List<ProvisionedMachineTO> fetchVMDetails(Long id) throws CMMException;
	
	List<ProvisionedMachineTO> getVMDetailsForAppDashboard(Long id) throws CMMException;
	
	ServiceRequestTO editVM(ServiceRequestTO requestTO) throws CMMException;
	
	ServiceRequestTO restartServer(ServiceRequestTO requestTO) throws CMMException;
	
	ServiceRequestTO applicationUndeployment(ServiceRequestTO requestTO) throws CMMException;
	
	ServiceRequestTO addSubAppDetails(MultipleProfileDetailsTO multipleProfileDetailsTO) throws CMMException;
	
	boolean validateEnvName(String subapp) throws CMMException;
	
	ServiceRequestTO caLisaAgentSubmit(ServiceRequestTO requestTO) throws CMMException;
	
	List<ApplicationReleaseTO> fetchReleaseList(Long profileId, Long appId) throws CMMException;
	
	List<ApplicationReleaseTO> fetchReleaseList(Long profileId) throws CMMException;
	
	List<EnvironmentApplicationTO> fetchAppRelList(Long envId) throws CMMException;
	
	List<ApplicationReleaseTO> getAllReleases(Long selectedEnvironment) throws CMMException;
	
	ApplicationReleaseTO fetchParentRelease(Long subrel) throws CMMException;
	
	List<EnvironmentApplicationTO> getAllReleasesforAppEnv(Long selectedEnvironment, Long appid) throws CMMException;
	
	ServiceRequestTO submitRollBack(ServiceRequestTO requestTO) throws CMMException;
	
	List<EnvironmentTO> getAllEnvironments(Long selectedProfile) throws CMMException;
	
	List<EnvironmentTO> getAllVirtualEnvironments(Long selectedProfile) throws CMMException;
	
	List<EnvironmentTO> getAllEnvironmentsForUndeployment(Long selectedProfile) throws CMMException;
	
	List<EnvironmentTO> getEnvironmentsWithSourceCodeForUndeployment(Long selectedProfile) throws CMMException;
	
	List<EnvironmentTO> getAllEnvironmentsAccToPhases(Long selectedProfile, Long selectedTestingCycle) throws CMMException;
	
	List<EnvironmentTO> getAllEnvironmentsAccToPhasesForTC(Long selectedTestingCycle) throws CMMException;
	
	List<EnvironmentTO> getAllEnvironmentsAccToPhases1(Long selectedProfile, Long selectedTestingCycle1) throws CMMException;
	
	ServiceRequestTO submitPromotedDetails(ServiceRequestTO requestTO) throws CMMException;
	
	List<ServiceRequestTO> searchCompletedServiceStatus(ServiceRequestTO serviceRequestTO) throws CMMException;
	
	List<ApplicationReleaseTO> getAllMinorReleases(Long majorReleaseId) throws CMMException;
	
	/**
	 * Method to fetch Service Request By RequestId.
	 *
	 * @param requestId
	 *                represents the Primary Key of the service request.
	 * @return ServiceRequestTO
	 * @throws CMMException
	 */
	ServiceRequestTO fetchServiceRequestByRequestId(long requestId) throws CMMException;
	
	boolean defineApplicationsForEnvironment(EnvironmentApplicationTO mapping) throws CMMException;
	
	/**
	 * Method to fetch max request id based upon envId and current releaseId.
	 *
	 * @param envId
	 *                of the environment.
	 * @param currentReleaseId
	 *                mapped with the environment.
	 * @return long max requestId.
	 * @throws CMMException
	 */
	long getMinReqIdByCurrentReleaseId(long envId, long currentReleaseId) throws CMMException;
	
	/**
	 * method to fetch min request id based upon envId and rollback releaseId.
	 *
	 * @param envId
	 *                of the environment.
	 * @param rollBackReleaseId
	 *                mapped with the environment.
	 * @return long min request Id.
	 * @throws CMMException
	 */
	long getMaxReqIdByRollbackReleaseId(long envId, long rollBackReleaseId) throws CMMException;
	
	/**
	 * Method to fetch List of requestId between min and max releaseId.
	 *
	 * @param minRequestId
	 *                minimun requestId or requestId of rollback releaseId.
	 * @param maxRequestId
	 *                maximum requestId or requestId of current releaseId.
	 * @param applicationId
	 *                of application.
	 * @param environmentId
	 *                of environment.
	 * @return List<Long> List of requestId
	 * @throws CMMException
	 */
	List<Long> getAllRollbackRequestIds(long minRequestId, long maxRequestId, long applicationId, long environmentId) throws CMMException;
	
	List<Long> getAllDBScriptsRequestIds(long minRequestId, long maxRequestId, long applicationId, long environmentId) throws CMMException;
	
	List<ServiceTO> getServicesForYes() throws CMMException;
	
	List<ServiceTO> getServicesForYes(Long clientId) throws CMMException;
	
	List<ServiceTO> getServicesForNo() throws CMMException;
	
	int generateWorkflow(EnvironmentTO envTO, ServiceRequestTO requestTO) throws CMMException;
	
	boolean checkName(EnvironmentTO envTO);
	
	List<ApplicationReleaseTO> fetchExistingReleases(Long selectedApplication, Long selectedEnvironment, Long selectedProfile) throws CMMException;
	
	List<ApplicationReleaseTO> getAllMinorReleases(Long majorReleaseId, Long selectedEnvironment, Long applicationId) throws CMMException;
	
	long getSoftwareIdForEnvDetailsId(long environmentDetailsId) throws CMMException;
	
	ServiceRequestTO submitBuild(ServiceRequestTO serviceReqTo) throws CMMException;
	
	PlatformTemplateTO loadTemplates(Long platformTemplateId) throws CMMException;
	
	Long getWorkflowIdforCA(Long id) throws CMMException;
	
	List<ProvisionedMachineTO> getMachineDetails(String ip) throws CMMException;
	
	List<ApplicationReleaseTO> getAllApplicationReleasesForApplication(Long applicationId) throws CMMException;
	
	List<ApplicationReleaseTO> getAppReleasesMappedWithBuildForApplication(Long applicationId) throws CMMException;
	
	int generateWorkflowForBuildService(ServiceRequestTO serviceReqTO) throws CMMException;
	
	List<ProvisionedMachineTO> getPhysicalMachinesDetailsForRequest(String ip) throws CMMException;
	
	List<ProvisionedMachineTO> getPhysicalMachinesDetailsForRequest() throws CMMException;
	
	int generateWorkflowForCodeAnalysis(ServiceRequestTO serviceReqTO) throws CMMException;
	
	ServiceRequestTO runCodeAnalysis(ServiceRequestTO serviceReqTo) throws CMMException;
	
	List<EnvironmentTO> getEnvironmentListForApplications(Long selectedApplication) throws CMMException;
	
	List<ProvisionedMachineTO> getProvisionedMachineDetailsByReqId(long requestId) throws CMMException;
	
	TestingToolsTO getTestingToolsDetails(Long requestId, Long testToolId) throws CMMException;
	
	Long getWorkflowId(Long req);
	
	List<ApplicationReleaseTO> fetchReleaseListForRollback(Long selectedProfile, Long applicationId, Long selectedEnvironment) throws CMMException;
	
	ServiceRequestTO submitDeploymentRequest(Map<Long, List<ServiceRequestTO>> environmentServiceMapping, List<ServiceRequestTO> serviceReqTo, boolean generateServicelevelWorkFlow, Map<Long, List<Long>> phaseEnvironmentMapping, List<PipelineRequestDetailsTO> pipelineRequestDetails, Long userId, Long applicationId, Long applicationReleaseId, String isScheduled, String cronExp) throws CMMException;
	
	ServiceRequestTO submitSoftwareInstallation(ServiceRequestTO requestTO) throws CMMException;
	
	RepositoryMasterTO getRepositoryDetails(Long applicationReleaseId) throws CMMException;
	
	ApplicationReleaseSharedDetailsTO getSharedDetailsForRelease(Long applicationReleaseId) throws CMMException;
	
	ApplicationReleaseNexusDetailsTO getNexusDetailsForRelease(Long applicationReleaseId) throws CMMException;
	
	List<ServiceRequestTO> fetchAllPipelineRequestForParent(long parentRequestId, Long environmentId) throws CMMException;
	
	void updateServiceRequestStatus(long requestId, long serviceStatus) throws CMMException;
	
	List<PipelineRequestDetailsTO> fetchPipelineRequestDetails(long parentRequestId) throws CMMException;
	
	void updateEnvStatusInPipelineRequestDetails(Long parentRequestId, Long environmentId, Long statusId) throws CMMException;
	
	PipelineRequestDetailsTO fetchPhaseListforLoadingPipelineRequest(Long parentRequestId) throws CMMException;
	
	List<EnvironmentTO> fetchEnvironmentList(Long selectedPhase, long parentRequestId) throws CMMException;
	
	ServiceRequestTO fetchRequestDetail(Long selectedRequestId) throws CMMException;
	
	ServiceRequestTO executeServiceAgain(Long requestId) throws CMMException;
	
	List<ServiceRequestTO> fetchAllChildRequestForPipeline(long parentRequestId) throws CMMException;
	
	List<ServiceRequestTO> fetchAllPipelineRequest() throws CMMException;
	
	List<DeploymentPipelineForJiraTO> fetchAllJiraPipelineRequest() throws CMMException;
	
	List<EnvironmentTO> getEnvironmentListForApplicationsRelease(Long selectedApplication) throws CMMException;
	
	NetraNexusDetailsTO getNetraNexusDetails() throws CMMException;
	
	String fetchRepoNameById(Long repoId) throws CMMException;
	
	String getRelease(String appName) throws CMMException;
	
	void updatePipelineDetailsStatus(PipelineRequestDetailsTO pipelineRequestDetail) throws CMMException;
	
	ServiceRequestTO submitServiceRequest(ServiceRequestTO requestTO) throws CMMException;
	
	List<EnvironmentTO> fetchEnvDetails(long selectedRequestId) throws CMMException;
	
	List<ReleasePlanningTO> getReleasePlannings(Long id) throws CMMException;
	
	List<ApplicationReleaseBuildTO> getAppReleaseBuildByReleaseAndPhaseId(long releaseId, long phaseId) throws CMMException;
	
	List<ApplicationReleaseBuildTO> getAppReleaseTestByReleaseAndPhaseId(long releaseId, long phaseId) throws CMMException;
	
	List<ApplicationReleaseSourcecodeTO> fetchAppReleaseSourceCodeByReleaseAndPhaseId(long releaseId, long phaseId) throws CMMException;
	
	List<ApplicationReleaseTO> getReleaseProfiles(Long id) throws CMMException;
	
	List<TestingPhaseTO> getPhases(Long id) throws CMMException;
	
	String fetchEnvName(long selectedRequestId) throws CMMException;
	
	List<TestingPhaseTO> getAppSpecificTestPhase(List<Long> dapp) throws CMMException;
	
	List<ServiceRequestTO> searchServiceToUnschedule(ServiceRequestTO servicerequestTO);
	
	void changeFlagForUnschedule(Long requestId);
	
	List<ServiceTO> getAllServicesToUnschedule(Long clientId, Long roleId) throws CMMException;
	
	List<TestingPhaseTO> getPhasesForApplication(Long id) throws CMMException;
	
	List<TestingPhaseTO> getPhasesForApplicationAndRelease(Long releaseId) throws CMMException;
	
	List<TestingPhaseTO> getPhasesForApplication1(Long id, Long pid) throws CMMException;
	
	List<TestingPhaseTO> getPhasesForAppAndRel(Long applicationId, Long phaseId, Long releaseId) throws CMMException;
	
	List<EnvironmentTO> getAllEnvironmentsAccToPhases2(Long selectedApplication, Long selectedTestingCycle) throws CMMException;
	
	List<EnvironmentTO> getAllEnvironmentsAccToPhases3(Long selectedApplication, Long selectedTestingCycle) throws CMMException;
	
	List<EnvironmentTO> getEnvAccToPhaseAndRelease(Long selectedApplication, Long selectedTestingCycle, Long selectedRelease) throws CMMException;
	
	List<EnvironmentTO> getAllEnvironmentsAccToPhasesTC1(Long selectedApplication, Long selectedTestingCycle) throws CMMException;
	
	List<EnvironmentTO> getEnvAccToPhaseAndReleasePhases(Long selectedApplication, Long selectedTestingCycle, Long selectedRelease) throws CMMException;
	
	List<EnvironmentTO> getAllEnvForSelectedApplication(Long selectedApplication, Long selectedEnvironment) throws CMMException;
	
	List<ProvisionedMachineOSTO> fetchProvisionedMachineOSDetails(Long provisionedMachineId) throws CMMException;
	
	List<EnvironmentTO> getAllEnvironmentsForApplicationReleaseRollback(Long selectedProfile) throws CMMException;
	
	List<ApplicationTO> getAllApplication(Long requestId) throws CMMException;
	
	ApplicationReleaseTO getReleaseForApplications(Long requestId) throws CMMException;
	
	List<String> getReleaseForMultipleEnvironment(Long environmentId) throws CMMException;
	
	List<String> getApplicationsForMultipleEnvironment(Long environmentId) throws CMMException;
	
	List<ApplicationTO> getAllApplicationForServiceDetails(Long requestId) throws CMMException;
	
	void resetVMDetails(int noCPU, int memoryMB, Long id);
	
	void updateServiceRequestRelease(Long requestid, Long environmentid) throws CMMException;
	
	void updateServiceRequestReleaseForCreateEnv(Long requestid, Long environmentid) throws CMMException;
	
	List<EnvironmentTO> fetchEnvironments(Long numberOfDays) throws CMMException;
	
	ServiceRequestTO submitDbRefreshRequest(ServiceRequestTO requestTO) throws CMMException;
	
	List<EnvironmentTO> fetchEnvironmentsForDeletion() throws CMMException;
	
	EnvironmentDockerTO getEnvDockerDetails(long envID) throws CMMException;
	
	/***** jira change start *****/
	void updateJiraServiceReqMapping(ServiceJiraMappingTO serJiraMapTO) throws CMMException;
	
	String getJiraIssueForServiceRequest(Long reqId) throws CMMException;
	
	String getSelectedApplicationName(Long appID) throws CMMException;
	
	String getSelectedReleaseName(Long relID) throws CMMException;
	
	JIRAConfigTO getJiraConfiguration() throws CMMException;
	
	void updateJiraDeploymentFlag(String jiraDeploymentFlag, Long id) throws CMMException;
	
	List<ServiceRequestTO> fetchAllPipelineRequestChild(long parentRequestId) throws CMMException;
	
	/***** jira change ends *****/
	/* for service dashboard */
	List<ServiceRequestTO> getBuildList(UserTO userTo, Long serviceId) throws CMMException;
	
	List<ServiceTO> getServicesForDashBoard() throws CMMException;
	
	List<ApplicationReleaseTO> getReleaseForApplication(Long applicationId) throws CMMException;
	
	List<ServiceRequestTO> getBuildForBU(UserTO userTo, Long clientId) throws CMMException;
	
	List<ServiceRequestTO> getBuildForProject(UserTO userTo, Long projectId) throws CMMException;
	
	List<ServiceRequestTO> getBuildListForApp(UserTO userTo, Long applicationId) throws CMMException;
	
	List<ServiceRequestTO> getBuildListForRelease(UserTO userTo, Long releaseId) throws CMMException;
	
	List<BusinessUnitTO> getAllBU(UserTO userTo) throws CMMException;
	
	List<ProjectsTO> getProject(UserTO userTO, Long clientId) throws CMMException;
	
	List<ApplicationTO> getApplications(Long projectId) throws CMMException;
	
	List<ServiceRequestTO> getAllRequestForService(ServiceRequestTO req) throws CMMException;
	
	List<ServiceRequestTO> getAllRequestForServiceMonth(ServiceRequestTO req) throws CMMException;
	
	Long getCurrentOwnerId(Long req) throws CMMException;
	
	List<ProvisionedMachineTO> getMachineDetailsFromName(String name) throws CMMException;
	
	List<String> getApplicationNames(Long envId) throws CMMException;
	
	void updateRequestListStatus(ServiceRequestTO requestTO) throws CMMException;
	
	TargetServerVO getTargetServerDetails(Long provMachineId) throws CMMException;
	
	TestingToolsTO getTestConfigDetails(Long applicationId, Long testToolId) throws CMMException;
	
	List<ApplicationProfileTO> getAllProfiles2(Long appId) throws CMMException;
	
	List<ReleasePlanningTO> getReleasePlanningNameFromId(Long id) throws CMMException;
	
	List<ApplicationReleaseDbTO> fetchAppReleaseDbDetailsByReleaseAndPhaseId(long releaseId, long phaseId) throws CMMException;
	
	List<ApplicationReleaseTO> fetchNewReleases(Long selectedApplication, Long selectedEnv, Long currentReleasePlan, Long currentRelease) throws CMMException;
	
	List<ProvisionedMachineTO> getProvisionMachineByEnvId(List<Long> id) throws CMMException;
	
	ProvisionedMachineTO getProvisionedMachineById(Long provMachineId) throws CMMException;
	
	List<SonarDetailTO> getCodeReviewByReleaseAndPhaseId(long releaseId, long phaseId) throws CMMException;
	
	List<ApplicationReleaseTO> fetchReleaseListForRollbackWithPlan(Long selectedProfile, Long applicationId, Long selectedEnvironment, Long relPlanId) throws CMMException;
	
	JIRAConfigTO getJiraCredentialsFromBUIdProjectId(JIRAConfigTO jiraConfigTO) throws CMMException;
	
	List<JIRAConfigTO> getJiraCredentialsFromBUId(JIRAConfigTO jiraConfigTO) throws CMMException;
	
	Long fetchEnvName(String environmentName) throws CMMException;
}