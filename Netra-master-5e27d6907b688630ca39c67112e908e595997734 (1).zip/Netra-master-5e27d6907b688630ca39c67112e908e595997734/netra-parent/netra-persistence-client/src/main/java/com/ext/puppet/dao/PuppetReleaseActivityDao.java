package com.ext.puppet.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.puppetMaster.to.PuppetActivitySoftwareMappingTO;
import com.framework.puppetMaster.to.PuppetMasterDetailsTO;
import com.framework.puppetMaster.to.PuppetReleaseActivityTO;
import com.framework.to.SoftwareTO;
import com.framework.to.SoftwareconfigTO;

public interface PuppetReleaseActivityDao {
	
	List<PuppetReleaseActivityTO> getAllActivity() throws CMMException;
	
	List<PuppetReleaseActivityTO> getAllPuppetReleaseActivities() throws CMMException;
	
	boolean definePuppetActivitiesForSoftware(PuppetActivitySoftwareMappingTO puppetActivitySoftwareMappingTO) throws CMMException;
	
	List<PuppetReleaseActivityTO> getPuppetSoftwareActivitites(long softwareConfigId) throws CMMException;
	
	long fetchMappedActivitySoftwareId(long activityId, long softwareId) throws CMMException;
	
	String fetchMappedSoftwareType(Long mappedSoftwareId) throws CMMException;
	
	List<PuppetMasterDetailsTO> getPuppetMasterDetails() throws CMMException;
	
	String getPuppetParameters(Long processId) throws CMMException;
	
	String getaddtionalDBParameters(long requestId) throws CMMException;
	
	List<PuppetReleaseActivityTO> getAllRemainingActivities() throws CMMException;
	
	SoftwareconfigTO addSoftwarePuppetMapDetails(SoftwareTO scTO) throws CMMException;
}
