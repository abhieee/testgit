package com.ext.dao;

import java.util.List;
import java.util.Set;
import com.framework.exception.CMMException;
import com.framework.to.ApplicationReleaseBuildTO;

/**
 * This interface interacts with database to fetch, insert or update application release build details.
 *
 * @author 460650
 */
public interface ApplicationReleaseBuildDAO {
	
	/**
	 * Code to fetch application release Build details by requestId.
	 *
	 * @param requestId
	 *                of service request.
	 * @return List<ApplicationReleaseBuildTO> which is list of application release Build.
	 * @throws CMMException
	 */
	List<ApplicationReleaseBuildTO> fetchAppReleaseBuildByRequestId(long requestId) throws CMMException;
	
	public List<ApplicationReleaseBuildTO> fetchAppReleaseBuildByRequestAndPhaseId(long requestId, long phaseId) throws CMMException;
	
	/**
	 * Code to fetch application release Build details by application releaseId.
	 *
	 * @param applicationReleaseId
	 * @return List<ApplicationReleaseBuildTO> which is list of application release Build.
	 * @throws CMMException
	 */
	List<ApplicationReleaseBuildTO> fetchAppReleaseBuildByReleaseId(long applicationReleaseId) throws CMMException;
	
	public List<ApplicationReleaseBuildTO> fetchAppReleaseBuildByReleaseAndPhaseId(long applicationReleaseId, long phaseId) throws CMMException;
	
	/**
	 * This method fetches list of build name associated with an application.
	 *
	 * @param applicationId
	 *                of Application.
	 * @return Set of buildName
	 * @throws CMMException
	 *                 custom exception.
	 */
	Set<String> fetchApplicationBuildJobs(long applicationId, long ciToolId) throws CMMException;
	
	Set<String> fetchApplicationBuildJobsForCIReport(List<Long> applicationId, long ciToolId) throws CMMException;
}
