package com.ext.dao;

import com.framework.exception.CMMException;

public interface GlobalParametersDAO {
	
	String getGlobalParameterByName(String parameterName) throws CMMException;
	
	String getApplicationParameterConfigFileLocation(String fileLocation) throws CMMException;
}
