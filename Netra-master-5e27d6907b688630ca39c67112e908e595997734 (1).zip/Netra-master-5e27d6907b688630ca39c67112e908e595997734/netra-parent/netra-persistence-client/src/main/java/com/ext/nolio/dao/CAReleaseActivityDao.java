/**
 *
 */
package com.ext.nolio.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.to.ActivitySoftwareMappingTO;
import com.framework.to.CAReleaseActivityTO;
import com.framework.to.ManifestTypeTO;
import com.framework.to.SoftwareTO;
import com.framework.to.SoftwareconfigTO;

/**
 * @author 460650
 */
public interface CAReleaseActivityDao {
	
	List<CAReleaseActivityTO> getAllActivity() throws CMMException;
	
	List<CAReleaseActivityTO> getAllRemainingActivities() throws CMMException;
	
	boolean defineActivitiesForSoftware(ActivitySoftwareMappingTO activitySoftwareMappingTO) throws CMMException;
	
	SoftwareconfigTO addSoftwareMapDetails(SoftwareTO scTO) throws CMMException;
	
	List<CAReleaseActivityTO> getSoftwareActivitites(Long softwareConfigId) throws CMMException;
	
	long fetchMappedActivitySoftwareId(long activityId, long softwareId) throws CMMException;
	
	List<ManifestTypeTO> getAllManifestType(String automationTools) throws CMMException;
}
