package com.ext.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.to.DockerServerConfigurationTO;
import com.framework.to.EnvironmentDockerTO;
import com.framework.to.EnvironmentTO;

public interface MonitoringDockerDAO {
	
	List<EnvironmentTO> searchEnv(EnvironmentTO environmentTO) throws CMMException;
	
	List<EnvironmentDockerTO> searchDockerDetails(EnvironmentTO environmentTO) throws CMMException;
	
	EnvironmentTO searchEnvDocker(String containerID) throws CMMException;
	
	List<DockerServerConfigurationTO> dockerServerConf(String containerID) throws CMMException;
	
	String searchEnvName(Long envID) throws CMMException;
}
