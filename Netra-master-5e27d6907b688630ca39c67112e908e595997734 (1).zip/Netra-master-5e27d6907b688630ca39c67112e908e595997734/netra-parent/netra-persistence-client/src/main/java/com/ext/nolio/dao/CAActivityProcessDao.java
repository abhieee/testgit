/**
 *
 */
package com.ext.nolio.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.nolio.to.CAActivityProcessOrderTO;
import com.framework.nolio.to.CaActivityExecOrderTO;
import com.framework.to.CAReleaseActivityTO;

/**
 * @author 460650
 */
public interface CAActivityProcessDao {
	
	List<CAActivityProcessOrderTO> fetchNolioSoftProcessMapByActivityID(long mapActivityId) throws CMMException;
	
	void saveOrderedNolioProcessForActivity(CAReleaseActivityTO cAReleaseActivityTO) throws CMMException;
	
	void saveOrderedActivities(CAReleaseActivityTO cAReleaseActivityTO) throws CMMException;
	
	List<CAActivityProcessOrderTO> fetchNolioProcessOrder(CAReleaseActivityTO cAReleaseActivityTO) throws CMMException;
	
	List<CaActivityExecOrderTO> fetchOrderedActivities(CAReleaseActivityTO cAReleaseActivityTO) throws CMMException;
}
