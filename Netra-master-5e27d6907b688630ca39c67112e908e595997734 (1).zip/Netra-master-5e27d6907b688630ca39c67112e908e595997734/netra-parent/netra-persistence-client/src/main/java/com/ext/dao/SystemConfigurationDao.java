package com.ext.dao;

import java.util.List;
import com.framework.exception.CMMException;
import com.framework.nolio.to.NolioProcess;
import com.framework.to.AddPolicyTO;
import com.framework.to.ApplicationTO;
import com.framework.to.BuildToolTO;
import com.framework.to.CAReleaseDetailsTO;
import com.framework.to.ClientTO;
import com.framework.to.ContinuousIntegrationServerTO;
import com.framework.to.DataMaskingConfigTO;
import com.framework.to.DnsServerDetailsTO;
import com.framework.to.DockerServerConfigurationTO;
import com.framework.to.JIRAConfigTO;
import com.framework.to.LDAPDetailsTO;
import com.framework.to.ParameterTO;
import com.framework.to.ProjectsTO;
import com.framework.to.RepositoryDetailsTO;
import com.framework.to.RepositoryTO;
import com.framework.to.ServiceNowConfigTO;
import com.framework.to.VSphereDetailsTO;

public interface SystemConfigurationDao {
	
	List<VSphereDetailsTO> searchVMWare(VSphereDetailsTO vSphereDetailsTO) throws CMMException;
	
	boolean checkName(VSphereDetailsTO vSphereDetailsTO) throws CMMException;
	
	boolean addVMWare(VSphereDetailsTO vSphereDetailsTO) throws CMMException;
	
	List<CAReleaseDetailsTO> searchCARelease(CAReleaseDetailsTO caReleaseDetailsTO) throws CMMException;
	
	boolean addCARelease(CAReleaseDetailsTO caReleaseDetailsTO) throws CMMException;
	
	boolean checkNameCA(CAReleaseDetailsTO caReleaseDetailsTO) throws CMMException;
	
	List<LDAPDetailsTO> searchLDAP(LDAPDetailsTO ldapDetailsTO) throws CMMException;
	
	boolean checkNameLDAP(LDAPDetailsTO ldapDetailsTO) throws CMMException;
	
	boolean addLDAP(LDAPDetailsTO ldapDetailsTO) throws CMMException;
	
	List<ParameterTO> searchParameter(ParameterTO parameterTO) throws CMMException;
	
	List<RepositoryTO> searchRepository(RepositoryTO repositoryTO) throws CMMException;
	
	boolean editParameter(ParameterTO parameterTO) throws CMMException;
	
	boolean editRepository(RepositoryTO repositoryTO) throws CMMException;
	
	ParameterTO loadParameterDetails(ParameterTO parameterTO) throws CMMException;
	
	RepositoryTO loadRepositoryDetails(RepositoryTO repositoryTO) throws CMMException;
	
	ParameterTO addParameter(ParameterTO parameterTO) throws CMMException;
	
	RepositoryTO addRepository(RepositoryTO repositoryTO) throws CMMException;
	
	List<RepositoryTO> getAllRepoConfig() throws CMMException;
	
	/**
	 * This method is used to save continuous server details.
	 *
	 * @param continuousIntegrationServerTO
	 *                details of continuous integration server details.
	 * @return boolean true for success and false for failure.
	 * @throws CMMException
	 */
	boolean saveContinuousIntegrationConfigDetails(ContinuousIntegrationServerTO continuousIntegrationServerTO) throws CMMException;
	
	/**
	 * This method fetches the Jenkins configuration details according to applicationId/projectId/BUId whichever is applicable
	 *
	 * @param applicationTO
	 *                object of application
	 * @param ciServerId
	 *                identifies the continuous integration tool
	 * @return ContinuousIntegrationServerTO object of Jenkins configuration details.
	 * @throws CMMException
	 */
	ContinuousIntegrationServerTO getConfigDetailsForApp(ApplicationTO applicationTO, Long ciServerId) throws CMMException;
	
	/**
	 * This method fetches all the Continuous server details according to the search criteria from database.
	 *
	 * @param applicationId
	 *                of Application
	 * @param projectId
	 *                of Project.
	 * @param buId
	 *                of Business Unit
	 * @param ciToolId
	 *                identifies the continuous integration tool
	 * @return List of ContinuousIntegrationServerTO details
	 * @throws CMMException
	 */
	List<ContinuousIntegrationServerTO> getAllCIServerConfigDetailsForApp(ContinuousIntegrationServerTO continuousIntegrationServerTO, Long applicationId, Long projectId, Long buId, Long ciToolId) throws CMMException;
	
	/**
	 * This method fetches the continuous integration server details as well as application, project and bu name from database by toolConfigId.
	 *
	 * @param ciToolConfigId
	 *                is the primary key of the tools_configuration table.
	 * @return ContinuousIntegrationServerTO object mapped with tools_configuration table.
	 * @throws CMMException
	 */
	ContinuousIntegrationServerTO getConfigDetailsById(Long ciToolConfigId) throws CMMException;
	
	/**
	 * This method is used to update Continuous Integration server details in database.
	 *
	 * @param continuousIntegrationServerTO
	 *                contains continuous integration server details that are to be updated.
	 * @return boolean true is updated successfully
	 * @throws CMMException
	 */
	boolean updateContinuousIntegrationConfigDetails(ContinuousIntegrationServerTO continuousIntegrationServerTO) throws CMMException;
	
	CAReleaseDetailsTO loadCARelease(CAReleaseDetailsTO caReleaseDetailsTO) throws CMMException;
	
	boolean addNolioProcessesInDB(List<NolioProcess> processList) throws CMMException;
	
	CAReleaseDetailsTO getCAReleaseDetails() throws CMMException;
	
	List<CAReleaseDetailsTO> getCAReleaseList() throws CMMException;
	
	void editCARelease(CAReleaseDetailsTO caReleaseDetailsTO) throws CMMException;
	
	boolean checkPolicyName(AddPolicyTO addPolicyTO) throws CMMException;
	
	boolean checkNameforAddPolicy(AddPolicyTO addpolicyTo) throws CMMException;
	
	boolean checkNameforEdit(AddPolicyTO addpolicyTo) throws CMMException;
	
	boolean savePolicy(AddPolicyTO addPolicyTo) throws CMMException;
	
	List<DnsServerDetailsTO> fetchAllDnsServer() throws CMMException;
	
	List<AddPolicyTO> loadPolicy(Long selectedId) throws CMMException;
	
	List<AddPolicyTO> searchPolicy(AddPolicyTO addPolicyTO, List<Long> clientIdlist) throws CMMException;
	
	boolean updatePolicy(AddPolicyTO addPolicyTo) throws CMMException;
	
	List<ApplicationTO> fetchApplicationListForMultipleProject(List<Long> selectedBuList, List<Long> selectedProjectList, List<Long> userIds, Long clientId) throws CMMException;
	
	List<ProjectsTO> searchAllProjectsForPolicy(Long selectedPolicyId) throws CMMException;
	
	List<ClientTO> searchAllClientsForPolicy(Long selectedPolicyId) throws CMMException;
	
	List<ApplicationTO> searchAllApplicationsForPolicy(Long selectedPolicyId) throws CMMException;
	
	String policyAlreadyDefined(AddPolicyTO addPolicyTo) throws CMMException;
	
	String policyAlreadyDefinedEdit(AddPolicyTO addPolicyTo) throws CMMException;
	
	boolean submitDataMaskingConfig(DataMaskingConfigTO dataMaskingConfigTO) throws CMMException;
	
	List<DataMaskingConfigTO> searchDataMaskingConfiguration(Long selectedApplicationId, Long selectedProjectId, Long selectedBUId, String selectedMaskTool) throws CMMException;
	
	DataMaskingConfigTO getDataMaskingDetailsForApp(ApplicationTO applicationTO, String dataMaskingTool) throws CMMException;
	
	List<BuildToolTO> fetchBuildTools() throws CMMException;
	
	List<VSphereDetailsTO> fetchOpenstackDetails() throws CMMException;
	
	VSphereDetailsTO loadVm(VSphereDetailsTO vSphereDetailsTO) throws CMMException;
	
	void editCloud(VSphereDetailsTO vSphereDetailsTO) throws CMMException;
	
	boolean checkName(ParameterTO parameterTO) throws CMMException;
	
	boolean checkName(RepositoryTO repositoryTO) throws CMMException;
	
	String addDockerDetails(DockerServerConfigurationTO dockerServerConfigurationTO) throws CMMException;
	
	List<DockerServerConfigurationTO> searchDockerDetails(DockerServerConfigurationTO dockerServerConfigurationTO) throws CMMException;
	
	DockerServerConfigurationTO loadDockerDetails(Long dockerId) throws CMMException;
	
	String editDockerDetails(DockerServerConfigurationTO dockerServerConfigurationTO) throws CMMException;
	
	List<DockerServerConfigurationTO> getDockerServerDetails() throws CMMException;
	
	//serviceNow start
	String addSNDetails(ServiceNowConfigTO serviceNowConfigTO) throws CMMException;
	
	List<ServiceNowConfigTO> searchSNDetails(ServiceNowConfigTO serviceNowConfigTO) throws CMMException;
	
	ServiceNowConfigTO loadSNDetails(Long id) throws CMMException;
	
	String editSNSubmit(ServiceNowConfigTO serviceNowConfigTO) throws CMMException;
	
	//servicenow end
	void saveJiraConfig(JIRAConfigTO jiraConfigTO) throws CMMException;
	
	List<JIRAConfigTO> searchJiraConfig(JIRAConfigTO jiraConfigTO) throws CMMException;
	
	JIRAConfigTO getToolDetailsForEdit(int id) throws CMMException;
	
	boolean editToolDetails(JIRAConfigTO jiraConfigForm, int id) throws CMMException;
	
	List<RepositoryDetailsTO> getRepoDetailsForApp(ApplicationTO applicationTO) throws CMMException;
	
	String fetchBuildToolNameFromId(Long selectedTool) throws CMMException;
	
	public String toolAlreadyDefined(JIRAConfigTO jIRAConfigTO) throws CMMException;
}