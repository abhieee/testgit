/**
 *
 */
package com.ext.nolio.dao;

import com.framework.exception.CMMException;
import com.framework.nolio.to.NolioProcessParametersTO;

/**
 * This interfaces fetches the data from database for Nolio parameters
 *
 * @author 460650
 */
public interface NolioProcessParameterDao {
	
	void updateParameterValue(long parameterId, String parameterValue) throws CMMException;
	
	NolioProcessParametersTO getNolioParameters(long parameterId) throws CMMException;
	
	/**
	 * method to fetch parameters for applicationReleaseDb through procedure call
	 *
	 * @param applicationReleaseDbId
	 *                for which parameters are to be fetched
	 * @throws CMMException
	 */
	long fetchParameters(long serviceId, long applicationReleaseDbId, String rollback) throws CMMException;
}
