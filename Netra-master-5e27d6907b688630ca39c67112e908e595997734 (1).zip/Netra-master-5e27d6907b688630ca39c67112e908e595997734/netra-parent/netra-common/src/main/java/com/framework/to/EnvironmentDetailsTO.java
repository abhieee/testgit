/**
 *
 */
package com.framework.to;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @author TCS
 */
public class EnvironmentDetailsTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7715531609132318219L;
	private String harwareName;
	private Long mappedSoftwareId;
	private Long hardwareId;
	private List<Long> softwareId = new ArrayList<Long>();
	private Long environmentId;
	private Set<ReservationTO> reservationses = new HashSet<ReservationTO>(0);
	private String softwares;
	private List<SoftwareTO> softwareList = new ArrayList<SoftwareTO>();
	private EnvironmentTO environment;
	private Long platformId;
	private String platformName;
	private Long serverGroup;
	private Long envId;
	private Set<EnvironmentSoftParamsTO> environmentSoftwareParametersTO = new HashSet<EnvironmentSoftParamsTO>(0);
	private HardwareTO hardware;
	private Long machineId;
	private SoftwareconfigTO softwareConfig = null;
	private ProvisionedMachineTO provisionedMachine;
	private String existingMachineFlag;
	private Long provisionedMachineId;
	private Long provisionedPlatformId;
	private String machineName;
	private Long bflag;
	private String installationRequired;
	private String installationStatus;
	private String applicationProfName;
	private String releaseName;
	private String applicationName;
	private String environmentName;
	
	public String getApplicationName() {
	
		return applicationName;
	}
	
	public String getApplicationProfName() {
	
		return applicationProfName;
	}
	
	public Long getBflag() {
	
		return bflag;
	}
	
	public Long getEnvId() {
	
		return envId;
	}
	
	public EnvironmentTO getEnvironment() {
	
		return environment;
	}
	
	public Long getEnvironmentId() {
	
		return environmentId;
	}
	
	public String getEnvironmentName() {
	
		return environmentName;
	}
	
	public Set<EnvironmentSoftParamsTO> getEnvironmentSoftwareParametersTO() {
	
		return environmentSoftwareParametersTO;
	}
	
	public String getExistingMachineFlag() {
	
		return existingMachineFlag;
	}
	
	public HardwareTO getHardware() {
	
		return hardware;
	}
	
	public Long getHardwareId() {
	
		return hardwareId;
	}
	
	public String getHarwareName() {
	
		return harwareName;
	}
	
	public String getInstallationRequired() {
	
		return installationRequired;
	}
	
	public String getInstallationStatus() {
	
		return installationStatus;
	}
	
	public Long getMachineId() {
	
		return machineId;
	}
	
	public String getMachineName() {
	
		return machineName;
	}
	
	public Long getMappedSoftwareId() {
	
		return mappedSoftwareId;
	}
	
	public Long getPlatformId() {
	
		return platformId;
	}
	
	public String getPlatformName() {
	
		return platformName;
	}
	
	public ProvisionedMachineTO getProvisionedMachine() {
	
		return provisionedMachine;
	}
	
	public Long getProvisionedMachineId() {
	
		return provisionedMachineId;
	}
	
	public Long getProvisionedPlatformId() {
	
		return provisionedPlatformId;
	}
	
	public String getReleaseName() {
	
		return releaseName;
	}
	
	public Set<ReservationTO> getReservationses() {
	
		return reservationses;
	}
	
	public Long getServerGroup() {
	
		return serverGroup;
	}
	
	public SoftwareconfigTO getSoftwareConfig() {
	
		return softwareConfig;
	}
	
	public List<Long> getSoftwareId() {
	
		return softwareId;
	}
	
	public List<SoftwareTO> getSoftwareList() {
	
		return softwareList;
	}
	
	public String getSoftwares() {
	
		return softwares;
	}
	
	public void setApplicationName(String applicationName) {
	
		this.applicationName = applicationName;
	}
	
	public void setApplicationProfName(String applicationProfName) {
	
		this.applicationProfName = applicationProfName;
	}
	
	public void setBflag(Long bflag) {
	
		this.bflag = bflag;
	}
	
	public void setEnvId(Long envId) {
	
		this.envId = envId;
	}
	
	public void setEnvironment(EnvironmentTO environment) {
	
		this.environment = environment;
	}
	
	public void setEnvironmentId(Long environmentId) {
	
		this.environmentId = environmentId;
	}
	
	public void setEnvironmentName(String environmentName) {
	
		this.environmentName = environmentName;
	}
	
	public void setEnvironmentSoftwareParametersTO(Set<EnvironmentSoftParamsTO> environmentSoftwareParametersTO) {
	
		this.environmentSoftwareParametersTO = environmentSoftwareParametersTO;
	}
	
	public void setExistingMachineFlag(String existingMachineFlag) {
	
		this.existingMachineFlag = existingMachineFlag;
	}
	
	public void setHardware(HardwareTO hardware) {
	
		this.hardware = hardware;
	}
	
	public void setHardwareId(Long hardwareId) {
	
		this.hardwareId = hardwareId;
	}
	
	public void setHarwareName(String harwareName) {
	
		this.harwareName = harwareName;
	}
	
	public void setInstallationRequired(String installationRequired) {
	
		this.installationRequired = installationRequired;
	}
	
	public void setInstallationStatus(String installationStatus) {
	
		this.installationStatus = installationStatus;
	}
	
	public void setMachineId(Long machineId) {
	
		this.machineId = machineId;
	}
	
	public void setMachineName(String machineName) {
	
		this.machineName = machineName;
	}
	
	public void setMappedSoftwareId(Long mappedSoftwareId) {
	
		this.mappedSoftwareId = mappedSoftwareId;
	}
	
	public void setPlatformId(Long platformId) {
	
		this.platformId = platformId;
	}
	
	public void setPlatformName(String platformName) {
	
		this.platformName = platformName;
	}
	
	public void setProvisionedMachine(ProvisionedMachineTO provisionedMachine) {
	
		this.provisionedMachine = provisionedMachine;
	}
	
	public void setProvisionedMachineId(Long provisionedMachineId) {
	
		this.provisionedMachineId = provisionedMachineId;
	}
	
	public void setProvisionedPlatformId(Long provisionedPlatformId) {
	
		this.provisionedPlatformId = provisionedPlatformId;
	}
	
	public void setReleaseName(String releaseName) {
	
		this.releaseName = releaseName;
	}
	
	public void setReservationses(Set<ReservationTO> reservationses) {
	
		this.reservationses = reservationses;
	}
	
	public void setServerGroup(Long serverGroup) {
	
		this.serverGroup = serverGroup;
	}
	
	public void setSoftwareConfig(SoftwareconfigTO softwareConfig) {
	
		this.softwareConfig = softwareConfig;
	}
	
	public void setSoftwareId(List<Long> softwareId) {
	
		this.softwareId = softwareId;
	}
	
	public void setSoftwareList(List<SoftwareTO> softwareList) {
	
		this.softwareList = softwareList;
	}
	
	public void setSoftwares(String softwares) {
	
		this.softwares = softwares;
	}
	
	private String ipAddBare;
	
	public String getIpAddBare() {
	
		return ipAddBare;
	}
	
	public void setIpAddBare(String ipAddBare) {
	
		this.ipAddBare = ipAddBare;
	}
}
