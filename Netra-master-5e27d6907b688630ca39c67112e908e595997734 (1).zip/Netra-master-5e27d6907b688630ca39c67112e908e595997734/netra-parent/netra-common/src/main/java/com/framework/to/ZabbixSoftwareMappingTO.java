package com.framework.to;

import java.io.Serializable;

public class ZabbixSoftwareMappingTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long templateid;
	private String name;
	private Long softwareConfigId;
	
	public String getName() {
	
		return name;
	}
	
	public Long getSoftwareConfigId() {
	
		return softwareConfigId;
	}
	
	public Long getTemplateid() {
	
		return templateid;
	}
	
	public void setName(String name) {
	
		this.name = name;
	}
	
	public void setSoftwareConfigId(Long softwareConfigId) {
	
		this.softwareConfigId = softwareConfigId;
	}
	
	public void setTemplateid(Long templateid) {
	
		this.templateid = templateid;
	}
}
