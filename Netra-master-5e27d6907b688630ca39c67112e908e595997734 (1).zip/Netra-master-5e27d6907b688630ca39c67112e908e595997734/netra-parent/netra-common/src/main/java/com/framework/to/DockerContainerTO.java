package com.framework.to;

public class DockerContainerTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8481011257111313581L;
	private String containerId;
	private String command;
	private String status;
	private String containerName;
	private long searchCount;
	private int firstResult = 1;
	private int tableSize;
	private String imageName;
	private String created;
	private String ports;
	private String ip;
	
	/**
	 * @return the command
	 */
	public String getCommand() {
	
		return command;
	}
	
	/**
	 * @return the containerId
	 */
	public String getContainerId() {
	
		return containerId;
	}
	
	/**
	 * @return the containerName
	 */
	public String getContainerName() {
	
		return containerName;
	}
	
	/**
	 * @return the created
	 */
	public String getCreated() {
	
		return created;
	}
	
	/**
	 * @return the firstResult
	 */
	public int getFirstResult() {
	
		return firstResult;
	}
	
	/**
	 * @return the imageName
	 */
	public String getImageName() {
	
		return imageName;
	}
	
	/**
	 * @return the ip
	 */
	public String getIp() {
	
		return ip;
	}
	
	/**
	 * @return the ports
	 */
	public String getPorts() {
	
		return ports;
	}
	
	/**
	 * @return the searchCount
	 */
	public long getSearchCount() {
	
		return searchCount;
	}
	
	/**
	 * @return the status
	 */
	public String getStatus() {
	
		return status;
	}
	
	/**
	 * @return the tableSize
	 */
	public int getTableSize() {
	
		return tableSize;
	}
	
	/**
	 * @param command
	 *                the command to set
	 */
	public void setCommand(String command) {
	
		this.command = command;
	}
	
	/**
	 * @param containerId
	 *                the containerId to set
	 */
	public void setContainerId(String containerId) {
	
		this.containerId = containerId;
	}
	
	/**
	 * @param containerName
	 *                the containerName to set
	 */
	public void setContainerName(String containerName) {
	
		this.containerName = containerName;
	}
	
	/**
	 * @param created
	 *                the created to set
	 */
	public void setCreated(String created) {
	
		this.created = created;
	}
	
	/**
	 * @param firstResult
	 *                the firstResult to set
	 */
	public void setFirstResult(int firstResult) {
	
		this.firstResult = firstResult;
	}
	
	/**
	 * @param imageName
	 *                the imageName to set
	 */
	public void setImageName(String imageName) {
	
		this.imageName = imageName;
	}
	
	/**
	 * @param ip
	 *                the ip to set
	 */
	public void setIp(String ip) {
	
		this.ip = ip;
	}
	
	/**
	 * @param ports
	 *                the ports to set
	 */
	public void setPorts(String ports) {
	
		this.ports = ports;
	}
	
	/**
	 * @param searchCount
	 *                the searchCount to set
	 */
	public void setSearchCount(long searchCount) {
	
		this.searchCount = searchCount;
	}
	
	/**
	 * @param status
	 *                the status to set
	 */
	public void setStatus(String status) {
	
		this.status = status;
	}
	
	/**
	 * @param tableSize
	 *                the tableSize to set
	 */
	public void setTableSize(int tableSize) {
	
		this.tableSize = tableSize;
	}
}
