package com.framework.common;

public enum Status {
	status1("Active"), status2("Inactive");
	
	private String statusType;
	
	private Status(String s) {
	
		this.statusType = s;
	}
	
	public String getStatusType() {
	
		return statusType;
	}
}
