package com.framework.to;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * This class declares the transfer object that carries user information across the application.
 *
 * @author TCS
 */
public class ApplicationReleaseTestTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6157025891463586051L;
	private Long id;
	private Long applicationReleaseId;
	private String testTool;
	private String testScriptPath;
	private Long RequestId;
	private List<TestingToolTO> testingToolsList = new ArrayList<TestingToolTO>(0);
	private Long serverGroup;
	private int flag = 1;
	private boolean access;
	private Long testToolId;
	private String workSpace;
	private String releasePlan;
	private String phase;
	private String testCycle;
	private String testSuite;
	private String junitJenkinsJob;
	private String mavenizedProject;
	private String automationType;
	private String configurationId;
	private String configurationName;
	private String configurationVersion;
	private String configVersion;
	private Long jmeterUsers;
	private Long jmeterDuration;
	private Long jmeterRampUp;
	private String configId;
	private String softwareName;
	private Long selectedTestingPhase;
	private String testExecutionServer;
	private String testingPhaseName;
	private Long testingPhaseId;
	private String seleniumUrl;
	private Long selectedRepository;
	
	public Long getSelectedRepository() {
	
		return selectedRepository;
	}
	
	public void setSelectedRepository(Long selectedRepository) {
	
		this.selectedRepository = selectedRepository;
	}
	
	public Long getApplicationReleaseId() {
	
		return applicationReleaseId;
	}
	
	/**
	 * @return the automationType
	 */
	public String getAutomationType() {
	
		return automationType;
	}
	
	public String getConfigId() {
	
		return configId;
	}
	
	/**
	 * @return the configurationId
	 */
	public String getConfigurationId() {
	
		return configurationId;
	}
	
	/**
	 * @return the configurationName
	 */
	public String getConfigurationName() {
	
		return configurationName;
	}
	
	/**
	 * @return the configurationVersion
	 */
	public String getConfigurationVersion() {
	
		return configurationVersion;
	}
	
	public String getConfigVersion() {
	
		return configVersion;
	}
	
	public int getFlag() {
	
		return flag;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public Long getJmeterDuration() {
	
		return jmeterDuration;
	}
	
	public Long getJmeterRampUp() {
	
		return jmeterRampUp;
	}
	
	public Long getJmeterUsers() {
	
		return jmeterUsers;
	}
	
	public String getJunitJenkinsJob() {
	
		return junitJenkinsJob;
	}
	
	public String getMavenizedProject() {
	
		return mavenizedProject;
	}
	
	/**
	 * @return the phase
	 */
	public String getPhase() {
	
		return phase;
	}
	
	/**
	 * @return the releasePlan
	 */
	public String getReleasePlan() {
	
		return releasePlan;
	}
	
	public Long getRequestId() {
	
		return RequestId;
	}
	
	/**
	 * @return the selectedTestingPhase
	 */
	public Long getSelectedTestingPhase() {
	
		return selectedTestingPhase;
	}
	
	public String getSeleniumUrl() {
	
		return seleniumUrl;
	}
	
	public Long getServerGroup() {
	
		return serverGroup;
	}
	
	public String getSoftwareName() {
	
		return softwareName;
	}
	
	/**
	 * @return the testCycle
	 */
	public String getTestCycle() {
	
		return testCycle;
	}
	
	/**
	 * @return the testExecutionServer
	 */
	public String getTestExecutionServer() {
	
		return testExecutionServer;
	}
	
	public Long getTestingPhaseId() {
	
		return testingPhaseId;
	}
	
	public String getTestingPhaseName() {
	
		return testingPhaseName;
	}
	
	public List<TestingToolTO> getTestingToolsList() {
	
		return testingToolsList;
	}
	
	public String getTestScriptPath() {
	
		return testScriptPath;
	}
	
	/**
	 * @return the testSuite
	 */
	public String getTestSuite() {
	
		return testSuite;
	}
	
	public String getTestTool() {
	
		return testTool;
	}
	
	/**
	 * @return the testToolId
	 */
	public Long getTestToolId() {
	
		return testToolId;
	}
	
	/**
	 * @return the workSpace
	 */
	public String getWorkSpace() {
	
		return workSpace;
	}
	
	public boolean isAccess() {
	
		return access;
	}
	
	public void setAccess(boolean access) {
	
		this.access = access;
	}
	
	public void setApplicationReleaseId(Long applicationReleaseId) {
	
		this.applicationReleaseId = applicationReleaseId;
	}
	
	/**
	 * @param automationType
	 *                the automationType to set
	 */
	public void setAutomationType(String automationType) {
	
		this.automationType = automationType;
	}
	
	public void setConfigId(String configId) {
	
		this.configId = configId;
	}
	
	/**
	 * @param configurationId
	 *                the configurationId to set
	 */
	public void setConfigurationId(String configurationId) {
	
		this.configurationId = configurationId;
	}
	
	/**
	 * @param configurationName
	 *                the configurationName to set
	 */
	public void setConfigurationName(String configurationName) {
	
		this.configurationName = configurationName;
	}
	
	/**
	 * @param configurationVersion
	 *                the configurationVersion to set
	 */
	public void setConfigurationVersion(String configurationVersion) {
	
		this.configurationVersion = configurationVersion;
	}
	
	public void setConfigVersion(String configVersion) {
	
		this.configVersion = configVersion;
	}
	
	public void setFlag(int flag) {
	
		this.flag = flag;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setJmeterDuration(Long jmeterDuration) {
	
		this.jmeterDuration = jmeterDuration;
	}
	
	public void setJmeterRampUp(Long jmeterRampUp) {
	
		this.jmeterRampUp = jmeterRampUp;
	}
	
	public void setJmeterUsers(Long jmeterUsers) {
	
		this.jmeterUsers = jmeterUsers;
	}
	
	public void setJunitJenkinsJob(String junitJenkinsJob) {
	
		this.junitJenkinsJob = junitJenkinsJob;
	}
	
	public void setMavenizedProject(String mavenizedProject) {
	
		this.mavenizedProject = mavenizedProject;
	}
	
	/**
	 * @param phase
	 *                the phase to set
	 */
	public void setPhase(String phase) {
	
		this.phase = phase;
	}
	
	/**
	 * @param releasePlan
	 *                the releasePlan to set
	 */
	public void setReleasePlan(String releasePlan) {
	
		this.releasePlan = releasePlan;
	}
	
	public void setRequestId(Long requestId) {
	
		RequestId = requestId;
	}
	
	/**
	 * @param selectedTestingPhase
	 *                the selectedTestingPhase to set
	 */
	public void setSelectedTestingPhase(Long selectedTestingPhase) {
	
		this.selectedTestingPhase = selectedTestingPhase;
	}
	
	public void setSeleniumUrl(String seleniumUrl) {
	
		this.seleniumUrl = seleniumUrl;
	}
	
	public void setServerGroup(Long serverGroup) {
	
		this.serverGroup = serverGroup;
	}
	
	public void setSoftwareName(String softwareName) {
	
		this.softwareName = softwareName;
	}
	
	/**
	 * @param testCycle
	 *                the testCycle to set
	 */
	public void setTestCycle(String testCycle) {
	
		this.testCycle = testCycle;
	}
	
	/**
	 * @param testExecutionServer
	 *                the testExecutionServer to set
	 */
	public void setTestExecutionServer(String testExecutionServer) {
	
		this.testExecutionServer = testExecutionServer;
	}
	
	public void setTestingPhaseId(Long testingPhaseId) {
	
		this.testingPhaseId = testingPhaseId;
	}
	
	public void setTestingPhaseName(String testingPhaseName) {
	
		this.testingPhaseName = testingPhaseName;
	}
	
	public void setTestingToolsList(List<TestingToolTO> testingToolsList) {
	
		this.testingToolsList = testingToolsList;
	}
	
	public void setTestScriptPath(String testScriptPath) {
	
		this.testScriptPath = testScriptPath;
	}
	
	/**
	 * @param testSuite
	 *                the testSuite to set
	 */
	public void setTestSuite(String testSuite) {
	
		this.testSuite = testSuite;
	}
	
	public void setTestTool(String testTool) {
	
		this.testTool = testTool;
	}
	
	/**
	 * @param testToolId
	 *                the testToolId to set
	 */
	public void setTestToolId(Long testToolId) {
	
		this.testToolId = testToolId;
	}
	
	/**
	 * @param workSpace
	 *                the workSpace to set
	 */
	public void setWorkSpace(String workSpace) {
	
		this.workSpace = workSpace;
	}
}
