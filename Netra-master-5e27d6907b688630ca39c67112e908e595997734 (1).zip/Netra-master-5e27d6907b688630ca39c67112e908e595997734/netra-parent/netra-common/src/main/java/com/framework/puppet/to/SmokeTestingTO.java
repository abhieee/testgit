package com.framework.puppet.to;

public class SmokeTestingTO {
	
	private String ip;
	private String dnsname;
	private String source;
	private String svnusername;
	private String svnpassword;
	private String scriptName;
	
	public String getDnsname() {
	
		return dnsname;
	}
	
	public String getIp() {
	
		return ip;
	}
	
	public String getScriptName() {
	
		return scriptName;
	}
	
	public String getSource() {
	
		return source;
	}
	
	public String getSvnpassword() {
	
		return svnpassword;
	}
	
	public String getSvnusername() {
	
		return svnusername;
	}
	
	public void setDnsname(String dnsname) {
	
		this.dnsname = dnsname;
	}
	
	public void setIp(String ip) {
	
		this.ip = ip;
	}
	
	public void setScriptName(String scriptName) {
	
		this.scriptName = scriptName;
	}
	
	public void setSource(String source) {
	
		this.source = source;
	}
	
	public void setSvnpassword(String svnpassword) {
	
		this.svnpassword = svnpassword;
	}
	
	public void setSvnusername(String svnusername) {
	
		this.svnusername = svnusername;
	}
}
