package com.framework.to;

import java.io.Serializable;

/**
 * This class declares the transfer onject that carries disruptive
 * failure information across the application.
 *
 * @author TCS
 */
/**
 * @author 605064186
 */
public class DisruptiveFailureTO extends AbstractTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5224953456080306174L;
	private String failureType = null;
	private DeviceTO device = null;
	private String card = null;
	private String port = null;
	private String remark = null;
	private String details = null;
	private String otherDevices = null;
	private DeviceTO deviceFrom = null;
	private DeviceTO deviceTo = null;
	
	public DisruptiveFailureTO() {
	
		super();
	}
	
	/**
	 * @return the card
	 */
	public String getCard() {
	
		return card;
	}
	
	/**
	 * @return the details
	 */
	public String getDetails() {
	
		return details;
	}
	
	public String getDetailsView() {
	
		String details = "EN From: " + (this.getDeviceFrom() == null ? "-" : this.getDeviceFrom().getName()) + "; ";
		details = details + this.getDetails();
		details = details + "; EN To: " + (this.getDeviceTo() == null ? "-" : this.getDeviceTo().getName());
		return details;
	}
	
	/**
	 * @return the device
	 */
	public DeviceTO getDevice() {
	
		return device;
	}
	
	/**
	 * @return the deviceFrom
	 */
	public DeviceTO getDeviceFrom() {
	
		return deviceFrom;
	}
	
	/**
	 * @return the deviceTo
	 */
	public DeviceTO getDeviceTo() {
	
		return deviceTo;
	}
	
	/**
	 * @return the failureType
	 */
	public String getFailureType() {
	
		return failureType;
	}
	
	public String getOtherDevices() {
	
		return otherDevices;
	}
	
	/**
	 * @return the port
	 */
	public String getPort() {
	
		return port;
	}
	
	/**
	 * @return the remark
	 */
	public String getRemark() {
	
		return remark;
	}
	
	/**
	 * @param card
	 *                the card to set
	 */
	public void setCard(String card) {
	
		this.card = card;
	}
	
	/**
	 * @param details
	 *                the details to set
	 */
	public void setDetails(String details) {
	
		this.details = details;
	}
	
	/**
	 * @param device
	 *                the device to set
	 */
	public void setDevice(DeviceTO device) {
	
		this.device = device;
	}
	
	/**
	 * @param deviceFrom
	 *                the deviceFrom to set
	 */
	public void setDeviceFrom(DeviceTO deviceFrom) {
	
		this.deviceFrom = deviceFrom;
	}
	
	/**
	 * @param deviceTo
	 *                the deviceTo to set
	 */
	public void setDeviceTo(DeviceTO deviceTo) {
	
		this.deviceTo = deviceTo;
	}
	
	/**
	 * @param failureType
	 *                the failureType to set
	 */
	public void setFailureType(String failureType) {
	
		this.failureType = failureType;
	}
	
	public void setOtherDevices(String otherDevices) {
	
		this.otherDevices = otherDevices;
	}
	
	/**
	 * @param port
	 *                the port to set
	 */
	public void setPort(String port) {
	
		this.port = port;
	}
	
	/**
	 * @param remark
	 *                the remark to set
	 */
	public void setRemark(String remark) {
	
		this.remark = remark;
	}
}
