package com.framework.to;

public class WorkFlowRequestHistoryTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8555003295471623954L;
}
