package com.framework.to;

public class ApplicationProfileSoftwareParamertsTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4625648502966962240L;
	private Long applicationProfiledetailsId;
	private Long newAppProMapId;
	private Long propertyId;
	private String propertyValue;
	private ApplicationProfileDetailsTO applicationProfileDetails;
	private Long activityId;
	private Long applicationProfileMapId;
	
	public Long getActivityId() {
	
		return activityId;
	}
	
	public ApplicationProfileDetailsTO getApplicationProfileDetails() {
	
		return applicationProfileDetails;
	}
	
	public Long getApplicationProfiledetailsId() {
	
		return applicationProfiledetailsId;
	}
	
	public Long getApplicationProfileMapId() {
	
		return applicationProfileMapId;
	}
	
	public Long getNewAppProMapId() {
	
		return newAppProMapId;
	}
	
	public Long getPropertyId() {
	
		return propertyId;
	}
	
	public String getPropertyValue() {
	
		return propertyValue;
	}
	
	public void setActivityId(Long activityId) {
	
		this.activityId = activityId;
	}
	
	public void setApplicationProfileDetails(ApplicationProfileDetailsTO applicationProfileDetails) {
	
		this.applicationProfileDetails = applicationProfileDetails;
	}
	
	public void setApplicationProfiledetailsId(Long applicationProfiledetailsId) {
	
		this.applicationProfiledetailsId = applicationProfiledetailsId;
	}
	
	public void setApplicationProfileMapId(Long applicationProfileMapId) {
	
		this.applicationProfileMapId = applicationProfileMapId;
	}
	
	public void setNewAppProMapId(Long newAppProMapId) {
	
		this.newAppProMapId = newAppProMapId;
	}
	
	public void setPropertyId(Long propertyId) {
	
		this.propertyId = propertyId;
	}
	
	public void setPropertyValue(String propertyValue) {
	
		this.propertyValue = propertyValue;
	}
}
