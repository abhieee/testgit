package com.framework.puppet.to;

public class Statuslist {
	
	private String appliname;
	private String status;
	private String errmsg;
	
	public String getAppliname() {
	
		return appliname;
	}
	
	public String getErrmsg() {
	
		return errmsg;
	}
	
	public String getStatus() {
	
		return status;
	}
	
	public void setAppliname(String appliname) {
	
		this.appliname = appliname;
	}
	
	public void setErrmsg(String errmsg) {
	
		this.errmsg = errmsg;
	}
	
	public void setStatus(String status) {
	
		this.status = status;
	}
}
