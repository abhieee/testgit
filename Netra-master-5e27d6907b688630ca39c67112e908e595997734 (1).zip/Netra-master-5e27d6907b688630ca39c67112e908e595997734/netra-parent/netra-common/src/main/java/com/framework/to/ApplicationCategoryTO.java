package com.framework.to;

public class ApplicationCategoryTO {
	
	private Long id;
	private String category;
	private String categoryType;
	
	public String getCategory() {
	
		return category;
	}
	
	public String getCategoryType() {
	
		return categoryType;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public void setCategory(String category) {
	
		this.category = category;
	}
	
	public void setCategoryType(String categoryType) {
	
		this.categoryType = categoryType;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
}