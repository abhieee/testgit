package com.framework.report;

import java.util.Date;

public class EnvironmentDetailsReportVO {
	
	private String environment_name = null;
	private Date created_date = null;
	private String created_by = null;
	private String hostname = null;
	private String ip = null;
	private String software = null;
	private String project = null;
	private String business_unit = null;
	private String application_name = null;
	private String release_name = null;
	
	public EnvironmentDetailsReportVO() {
	
		/* No implementation required at the moment. Method for future use. */
	}
	
	public EnvironmentDetailsReportVO(String environment_name, Date created_date, String created_by, String hostname, String ip, String software, String project, String business_unit, String application_name, String release_name) {
	
		this.environment_name = environment_name;
		this.created_date = created_date;
		this.created_by = created_by;
		this.hostname = hostname;
		this.ip = ip;
		this.software = software;
		this.project = project;
		this.business_unit = business_unit;
		this.application_name = application_name;
		this.release_name = release_name;
	}
	
	public String getEnvironment_name() {
	
		return environment_name;
	}
	
	public void setEnvironment_name(String environment_name) {
	
		this.environment_name = environment_name;
	}
	
	public Date getCreated_date() {
	
		return created_date;
	}
	
	public void setCreated_date(Date created_date) {
	
		this.created_date = created_date;
	}
	
	public String getCreated_by() {
	
		return created_by;
	}
	
	public void setCreated_by(String created_by) {
	
		this.created_by = created_by;
	}
	
	public String getHostname() {
	
		return hostname;
	}
	
	public void setHostname(String hostname) {
	
		this.hostname = hostname;
	}
	
	public String getIp() {
	
		return ip;
	}
	
	public void setIp(String ip) {
	
		this.ip = ip;
	}
	
	public String getSoftware() {
	
		return software;
	}
	
	public void setSoftware(String software) {
	
		this.software = software;
	}
	
	public String getProject() {
	
		return project;
	}
	
	public void setProject(String project) {
	
		this.project = project;
	}
	
	public String getBusiness_unit() {
	
		return business_unit;
	}
	
	public void setBusiness_unit(String business_unit) {
	
		this.business_unit = business_unit;
	}
	
	public String getApplication_name() {
	
		return application_name;
	}
	
	public void setApplication_name(String application_name) {
	
		this.application_name = application_name;
	}
	
	public String getRelease_name() {
	
		return release_name;
	}
	
	public void setRelease_name(String release_name) {
	
		this.release_name = release_name;
	}
}
