/**
 *
 */
package com.framework.to;

/**
 * @author 737070
 */
public class SoftwareTaskMappingTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long softwareConfigId;
	private Long taskId;
	private Long taskOrder;
	
	public Long getSoftwareConfigId() {
	
		return softwareConfigId;
	}
	
	public void setSoftwareConfigId(Long softwareConfigId) {
	
		this.softwareConfigId = softwareConfigId;
	}
	
	public Long getTaskId() {
	
		return taskId;
	}
	
	public void setTaskId(Long taskId) {
	
		this.taskId = taskId;
	}
	
	public Long getTaskOrder() {
	
		return taskOrder;
	}
	
	public void setTaskOrder(Long taskOrder) {
	
		this.taskOrder = taskOrder;
	}
}