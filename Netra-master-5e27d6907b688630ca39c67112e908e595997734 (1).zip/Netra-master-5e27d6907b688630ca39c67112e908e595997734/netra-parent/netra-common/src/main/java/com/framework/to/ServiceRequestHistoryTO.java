package com.framework.to;

public class ServiceRequestHistoryTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2692991190632242280L;
	private Long RequestId;
	private String Comments;
	
	public String getComments() {
	
		return Comments;
	}
	
	public Long getRequestId() {
	
		return RequestId;
	}
	
	public void setComments(String comments) {
	
		Comments = comments;
	}
	
	public void setRequestId(Long requestId) {
	
		RequestId = requestId;
	}
}
