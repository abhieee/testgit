package com.framework.to;

import java.io.Serializable;

public class SonarDetailTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5665115466065612298L;
	private long id;
	private long applicationReleaseId;
	private long sonarId;
	private String checkoutLocation;
	private String svnPathLocation;
	private String pathForCode;
	private int flag = 1;
	private boolean access;
	private Long selectedTestingPhase;
	private Long selectedRepository;
	
	public Long getSelectedRepository() {
	
		return selectedRepository;
	}
	
	public void setSelectedRepository(Long selectedRepository) {
	
		this.selectedRepository = selectedRepository;
	}
	
	public long getApplicationReleaseId() {
	
		return applicationReleaseId;
	}
	
	public boolean isAccess() {
	
		return access;
	}
	
	public void setAccess(boolean access) {
	
		this.access = access;
	}
	
	public Long getSelectedTestingPhase() {
	
		return selectedTestingPhase;
	}
	
	public void setSelectedTestingPhase(Long selectedTestingPhase) {
	
		this.selectedTestingPhase = selectedTestingPhase;
	}
	
	public String getCheckoutLocation() {
	
		return checkoutLocation;
	}
	
	public int getFlag() {
	
		return flag;
	}
	
	public long getId() {
	
		return id;
	}
	
	public String getPathForCode() {
	
		return pathForCode;
	}
	
	public long getSonarId() {
	
		return sonarId;
	}
	
	public String getSvnPathLocation() {
	
		return svnPathLocation;
	}
	
	public void setApplicationReleaseId(long applicationReleaseId) {
	
		this.applicationReleaseId = applicationReleaseId;
	}
	
	public void setCheckoutLocation(String checkoutLocation) {
	
		this.checkoutLocation = checkoutLocation;
	}
	
	public void setFlag(int flag) {
	
		this.flag = flag;
	}
	
	public void setId(long id) {
	
		this.id = id;
	}
	
	public void setPathForCode(String pathForCode) {
	
		this.pathForCode = pathForCode;
	}
	
	public void setSonarId(long sonarId) {
	
		this.sonarId = sonarId;
	}
	
	public void setSvnPathLocation(String svnPathLocation) {
	
		this.svnPathLocation = svnPathLocation;
	}
}
