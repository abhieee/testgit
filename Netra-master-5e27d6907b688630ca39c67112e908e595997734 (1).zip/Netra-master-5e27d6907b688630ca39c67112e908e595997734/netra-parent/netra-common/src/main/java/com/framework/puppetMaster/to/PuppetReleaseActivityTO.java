/**
 *
 */
package com.framework.puppetMaster.to;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @author 584175
 */
public class PuppetReleaseActivityTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8297710560513218991L;
	private Long activityId;
	private String activityName;
	private String applicationSpecificFlag;
	private String selectedVersion;
	private long selectedActivityId;
	private Long softwareId;
	private List<Long> activity = new ArrayList<Long>();
	
	public Long getSoftwareId() {
	
		return softwareId;
	}
	
	public List<Long> getActivity() {
	
		return activity;
	}
	
	public void setActivity(List<Long> activity) {
	
		this.activity = activity;
	}
	
	public void setSoftwareId(Long softwareId) {
	
		this.softwareId = softwareId;
	}
	
	public long getSelectedActivityId() {
	
		return selectedActivityId;
	}
	
	public void setSelectedActivityId(long selectedActivityId) {
	
		this.selectedActivityId = selectedActivityId;
	}
	
	private List<Long> definedActivities;
	
	public List<Long> getDefinedActivities() {
	
		return definedActivities;
	}
	
	public void setDefinedActivities(List<Long> definedActivities) {
	
		this.definedActivities = definedActivities;
	}
	
	private List<Long> puppetProcessSoftwareMapOrderedList = null;
	
	public Long getActivityId() {
	
		return activityId;
	}
	
	public String getActivityName() {
	
		return activityName;
	}
	
	public String getApplicationSpecificFlag() {
	
		return applicationSpecificFlag;
	}
	
	/**
	 * @return the puppetProcessSoftwareMapOrderedList
	 */
	public List<Long> getPuppetProcessSoftwareMapOrderedList() {
	
		return puppetProcessSoftwareMapOrderedList;
	}
	
	public String getSelectedVersion() {
	
		return selectedVersion;
	}
	
	public void setActivityId(Long activityId) {
	
		this.activityId = activityId;
	}
	
	public void setActivityName(String activityName) {
	
		this.activityName = activityName;
	}
	
	public void setApplicationSpecificFlag(String applicationSpecificFlag) {
	
		this.applicationSpecificFlag = applicationSpecificFlag;
	}
	
	/**
	 * @param puppetProcessSoftwareMapOrderedList
	 *                the puppetProcessSoftwareMapOrderedList to set
	 */
	public void setPuppetProcessSoftwareMapOrderedList(List<Long> puppetProcessSoftwareMapOrderedList) {
	
		this.puppetProcessSoftwareMapOrderedList = puppetProcessSoftwareMapOrderedList;
	}
	
	public void setSelectedVersion(String selectedVersion) {
	
		this.selectedVersion = selectedVersion;
	}
}
