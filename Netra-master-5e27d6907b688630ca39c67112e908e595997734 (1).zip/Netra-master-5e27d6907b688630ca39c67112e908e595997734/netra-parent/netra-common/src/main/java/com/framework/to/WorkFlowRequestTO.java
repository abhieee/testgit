package com.framework.to;

import java.util.LinkedList;
import java.util.List;

public class WorkFlowRequestTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1974001907157922892L;
	private WorkflowCurrentTO workflowCurrentTO;
	private List<WorkflowHistoryTO> workflowHistoryTO = new LinkedList<WorkflowHistoryTO>();
	private List<ReservationTO> reservationTO;
	private ServiceRequestTO serviceRequestTo;
	private ServiceRequestTO serviceRequest = new ServiceRequestTO();
	private String releaseName;
	private int searchCount;
	private int tableSize = 10;
	private Long pageNumber = 1L;
	private int firstResult = 0;
	
	public Long getAction_performed_by() {
	
		return action_performed_by;
	}
	
	public void setAction_performed_by(Long action_performed_by) {
	
		this.action_performed_by = action_performed_by;
	}
	
	public Long getAction_performed_by_role() {
	
		return action_performed_by_role;
	}
	
	public void setAction_performed_by_role(Long action_performed_by_role) {
	
		this.action_performed_by_role = action_performed_by_role;
	}
	
	private Long action_performed_by;
	private Long action_performed_by_role;
	private String action_performed_by_name;
	
	public String getAction_performed_by_name() {
	
		return action_performed_by_name;
	}
	
	public void setAction_performed_by_name(String action_performed_by_name) {
	
		this.action_performed_by_name = action_performed_by_name;
	}
	
	public int getFirstResult() {
	
		return firstResult;
	}
	
	public Long getPageNumber() {
	
		return pageNumber;
	}
	
	public String getReleaseName() {
	
		return releaseName;
	}
	
	public List<ReservationTO> getReservationTO() {
	
		return reservationTO;
	}
	
	public int getSearchCount() {
	
		return searchCount;
	}
	
	public ServiceRequestTO getServiceRequest() {
	
		return serviceRequest;
	}
	
	public ServiceRequestTO getServiceRequestTo() {
	
		return serviceRequestTo;
	}
	
	public int getTableSize() {
	
		return tableSize;
	}
	
	public WorkflowCurrentTO getWorkflowCurrentTO() {
	
		return workflowCurrentTO;
	}
	
	public List<WorkflowHistoryTO> getWorkflowHistoryTO() {
	
		return workflowHistoryTO;
	}
	
	public void setFirstResult(int firstResult) {
	
		this.firstResult = firstResult;
	}
	
	public void setPageNumber(Long pageNumber) {
	
		this.pageNumber = pageNumber;
	}
	
	public void setReleaseName(String releaseName) {
	
		this.releaseName = releaseName;
	}
	
	public void setReservationTO(List<ReservationTO> reservationTO) {
	
		this.reservationTO = reservationTO;
	}
	
	public void setSearchCount(int searchCount) {
	
		this.searchCount = searchCount;
	}
	
	public void setServiceRequest(ServiceRequestTO serviceRequest) {
	
		this.serviceRequest = serviceRequest;
	}
	
	public void setServiceRequestTo(ServiceRequestTO serviceRequestTo) {
	
		this.serviceRequestTo = serviceRequestTo;
	}
	
	public void setTableSize(int tableSize) {
	
		this.tableSize = tableSize;
	}
	
	public void setWorkflowCurrentTO(WorkflowCurrentTO workflowCurrentTO) {
	
		this.workflowCurrentTO = workflowCurrentTO;
	}
	
	public void setWorkflowHistoryTO(List<WorkflowHistoryTO> workflowHistoryTO) {
	
		this.workflowHistoryTO = workflowHistoryTO;
	}
}
