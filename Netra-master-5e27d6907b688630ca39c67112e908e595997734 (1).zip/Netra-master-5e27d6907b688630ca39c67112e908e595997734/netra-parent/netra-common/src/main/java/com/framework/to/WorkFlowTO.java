package com.framework.to;

import java.util.HashSet;
import java.util.Set;

public class WorkFlowTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -654872787770505422L;
	private String description;
	private Set<WorkFlowLevelTO> workFlowLevel = new HashSet<WorkFlowLevelTO>(0);
	private Set<WorkflowCurrentTO> workflowCurrentTO = new HashSet<WorkflowCurrentTO>();
	private Set<WorkflowHistoryTO> workflowHistoryTO = new HashSet<WorkflowHistoryTO>();
	private Long linkedServiceId;
	private String wfReq;
	
	public String getDescription() {
	
		return description;
	}
	
	public Long getLinkedServiceId() {
	
		return linkedServiceId;
	}
	
	public String getWfReq() {
	
		return wfReq;
	}
	
	public Set<WorkflowCurrentTO> getWorkflowCurrentTO() {
	
		return workflowCurrentTO;
	}
	
	public Set<WorkflowHistoryTO> getWorkflowHistoryTO() {
	
		return workflowHistoryTO;
	}
	
	public Set<WorkFlowLevelTO> getWorkFlowLevel() {
	
		return workFlowLevel;
	}
	
	public void setDescription(String description) {
	
		this.description = description;
	}
	
	public void setLinkedServiceId(Long linkedServiceId) {
	
		this.linkedServiceId = linkedServiceId;
	}
	
	public void setWfReq(String wfReq) {
	
		this.wfReq = wfReq;
	}
	
	public void setWorkflowCurrentTO(Set<WorkflowCurrentTO> workflowCurrentTO) {
	
		this.workflowCurrentTO = workflowCurrentTO;
	}
	
	public void setWorkflowHistoryTO(Set<WorkflowHistoryTO> workflowHistoryTO) {
	
		this.workflowHistoryTO = workflowHistoryTO;
	}
	
	public void setWorkFlowLevel(Set<WorkFlowLevelTO> workFlowLevel) {
	
		this.workFlowLevel = workFlowLevel;
	}
}
