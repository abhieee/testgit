package com.framework.to;

import java.util.Arrays;

public class DockerImageTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -865468572331243007L;
	private String imageName;
	private long searchCount;
	private int firstResult = 1;
	private int tableSize;
	private String[] repoTags;
	private String created;
	private String imageId;
	private long virtualSize;
	private String repository;
	private String tags;
	
	/**
	 * @return the created
	 */
	public String getCreated() {
	
		return created;
	}
	
	/**
	 * @return the firstResult
	 */
	public int getFirstResult() {
	
		return firstResult;
	}
	
	/**
	 * @return the imageId
	 */
	public String getImageId() {
	
		return imageId;
	}
	
	/**
	 * @return the imageName
	 */
	public String getImageName() {
	
		return imageName;
	}
	
	/**
	 * @return the repository
	 */
	public String getRepository() {
	
		return repository;
	}
	
	/**
	 * @return the repoTags
	 */
	public String[] getRepoTags() {
	
		return repoTags;
	}
	
	/**
	 * @return the searchCount
	 */
	public long getSearchCount() {
	
		return searchCount;
	}
	
	/**
	 * @return the tableSize
	 */
	public int getTableSize() {
	
		return tableSize;
	}
	
	/**
	 * @return the tags
	 */
	public String getTags() {
	
		return tags;
	}
	
	/**
	 * @return the virtualSize
	 */
	public long getVirtualSize() {
	
		return virtualSize;
	}
	
	/**
	 * @param created
	 *                the created to set
	 */
	public void setCreated(String created) {
	
		this.created = created;
	}
	
	/**
	 * @param firstResult
	 *                the firstResult to set
	 */
	public void setFirstResult(int firstResult) {
	
		this.firstResult = firstResult;
	}
	
	/**
	 * @param imageId
	 *                the imageId to set
	 */
	public void setImageId(String imageId) {
	
		this.imageId = imageId;
	}
	
	/**
	 * @param imageName
	 *                the imageName to set
	 */
	public void setImageName(String imageName) {
	
		this.imageName = imageName;
	}
	
	/**
	 * @param repository
	 *                the repository to set
	 */
	public void setRepository(String repository) {
	
		this.repository = repository;
	}
	
	/**
	 * @param repoTags
	 *                the repoTags to set
	 */
	public void setRepoTags(String[] repoTagsDocker) {
	
		if (repoTagsDocker == null) {
			this.repoTags = new String[0];
		} else {
			this.repoTags = Arrays.copyOf(repoTagsDocker, repoTagsDocker.length);
		}
	}
	
	/**
	 * @param searchCount
	 *                the searchCount to set
	 */
	public void setSearchCount(long searchCount) {
	
		this.searchCount = searchCount;
	}
	
	/**
	 * @param tableSize
	 *                the tableSize to set
	 */
	public void setTableSize(int tableSize) {
	
		this.tableSize = tableSize;
	}
	
	/**
	 * @param tags
	 *                the tags to set
	 */
	public void setTags(String tags) {
	
		this.tags = tags;
	}
	
	/**
	 * @param virtualSize
	 *                the virtualSize to set
	 */
	public void setVirtualSize(long virtualSize) {
	
		this.virtualSize = virtualSize;
	}
}
