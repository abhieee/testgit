package com.framework.to;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class JIRAConfigTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int id;
	private String toolName;
	private String url;
	private String username;
	private String password;
	private int tableSize = 15;
	private long pageNumber = 1;
	private int firstResult = 0;
	private long searchCount;
	private List<BusinessUnitTO> businessUnitList = new ArrayList<>(0);
	private List<ProjectsTO> projectList = new ArrayList<>(0);
	private List<Long> selectedBuList = new ArrayList<>(0);
	private List<Long> selectedProjectList = new ArrayList<>(0);
	private Set<JIRAMappingTO> jiraMapping;
	private ClientTO clientTO;
	private ProjectsTO projectsTO;
	private Long buId;
	private Long projectId;
	
	public Long getBuId() {
	
		return buId;
	}
	
	public void setBuId(Long buId) {
	
		this.buId = buId;
	}
	
	public Long getProjectId() {
	
		return projectId;
	}
	
	public void setProjectId(Long projectId) {
	
		this.projectId = projectId;
	}
	
	public ClientTO getClientTO() {
	
		return clientTO;
	}
	
	public void setClientTO(ClientTO clientTO) {
	
		this.clientTO = clientTO;
	}
	
	public ProjectsTO getProjectsTO() {
	
		return projectsTO;
	}
	
	public void setProjectsTO(ProjectsTO projectsTO) {
	
		this.projectsTO = projectsTO;
	}
	
	public Set<JIRAMappingTO> getJiraMapping() {
	
		return jiraMapping;
	}
	
	public void setJiraMapping(Set<JIRAMappingTO> jiraMapping) {
	
		this.jiraMapping = jiraMapping;
	}
	
	public int getId() {
	
		return id;
	}
	
	public void setId(int id) {
	
		this.id = id;
	}
	
	public String getToolName() {
	
		return toolName;
	}
	
	public void setToolName(String toolName) {
	
		this.toolName = toolName;
	}
	
	public String getUrl() {
	
		return url;
	}
	
	public void setUrl(String url) {
	
		this.url = url;
	}
	
	public String getUsername() {
	
		return username;
	}
	
	public void setUsername(String username) {
	
		this.username = username;
	}
	
	public String getPassword() {
	
		return password;
	}
	
	public void setPassword(String password) {
	
		this.password = password;
	}
	
	public int getTableSize() {
	
		return tableSize;
	}
	
	public void setTableSize(int tableSize) {
	
		this.tableSize = tableSize;
	}
	
	public long getPageNumber() {
	
		return pageNumber;
	}
	
	public void setPageNumber(long pageNumber) {
	
		this.pageNumber = pageNumber;
	}
	
	public int getFirstResult() {
	
		return firstResult;
	}
	
	public void setFirstResult(int firstResult) {
	
		this.firstResult = firstResult;
	}
	
	public long getSearchCount() {
	
		return searchCount;
	}
	
	public void setSearchCount(long searchCount) {
	
		this.searchCount = searchCount;
	}
	
	public List<BusinessUnitTO> getBusinessUnitList() {
	
		return businessUnitList;
	}
	
	public void setBusinessUnitList(List<BusinessUnitTO> businessUnitList) {
	
		this.businessUnitList = businessUnitList;
	}
	
	public List<ProjectsTO> getProjectList() {
	
		return projectList;
	}
	
	public void setProjectList(List<ProjectsTO> projectList) {
	
		this.projectList = projectList;
	}
	
	public List<Long> getSelectedBuList() {
	
		return selectedBuList;
	}
	
	public void setSelectedBuList(List<Long> selectedBuList) {
	
		this.selectedBuList = selectedBuList;
	}
	
	public List<Long> getSelectedProjectList() {
	
		return selectedProjectList;
	}
	
	public void setSelectedProjectList(List<Long> selectedProjectList) {
	
		this.selectedProjectList = selectedProjectList;
	}
}
