package com.framework.report;

import java.io.Serializable;

public class Software_summary implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long software_count;
	private String status;
	
	public Software_summary() {
	
		/* No implementation required at the moment. Method for future use. */
	}
	
	public Software_summary(long software_count, String status) {
	
		this.software_count = software_count;
		this.status = status;
	}
	
	public long getSoftware_count() {
	
		return software_count;
	}
	
	public void setSoftware_count(long software_count) {
	
		this.software_count = software_count;
	}
	
	public String getStatus() {
	
		return status;
	}
	
	public void setStatus(String status) {
	
		this.status = status;
	}
}
