package com.framework.common;

public interface ParameterConstants {
	
	String ENVIRONEMENT_DETAILS_SET = "EnvironmentDetailsSet";
	String ENVIRONEMENT_DETAILS_TO = "EnvironmentDetailsTO";
	String REQUEST_ID = "requestId";
	String PHASE_ID = "selectedTestingPhase";
	String PROVISIONED_MACHINE_TO = "ProvisionedMachineTO";
	String NETRA_PARAMETERS_MAP = "NETRAParametersMap";
	String ROLLBACK_FLAG = "RollBackFlag";
	String SELECTED_REPO = "SelectedRepo";
	String DBUSERNAME = "DBUserName";
	String DBPASSWORD = "DBPassWord";
	String SOFTWARE_NAME = "Software_Name";
	String VIRTUAL_MACHINE_TYPE = "VirtualMachineType";
	String OS_FAMILY = "OSFamily";
	String CONNECTION_PROPERTIES = "ConnectionProperties";
	String ACTIVITY_ID = "ActivityId";
	String APP_RELEASE_ID = "AppReleaseId";
	String APPLICATION_RELEASE_TO = "ApplicationReleaseTO";
	String SOFTWARE_CONFIG_TO = "SoftwareConfigTO";
	String APPLICATION_NAME = "ApplicationName";
	String RELEASE_NAME = "ReleaseName";
	String APPLICATION_TO = "ApplicationTO";
	String ENVIRONMENT_PARAMETERS_MAP = "EnvironmentParametersMap";
	String TESTING_TOOL_CONFIG = "TestingToolConfig";
	String TESTING_TO = "TestingTool";
	String TESTING_TOOL_TO = "TestingToolTO";
	String TAM_SERVER_DETAILS = "tamServerDetails";
	String IP = "IP";
	String PORT = "PORT";
}
