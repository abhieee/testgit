package com.framework.to;

import java.io.Serializable;

public class MonitoringDockerTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3805045933319397501L;
	private String CPU;
	private String memUsage;
	private String memLimit;
	private String memPer;
	private String envName;
	private String netIO;
	private String blockIO;
	
	public String getBlockIO() {
	
		return blockIO;
	}
	
	public String getCPU() {
	
		return CPU;
	}
	
	public String getEnvName() {
	
		return envName;
	}
	
	public String getMemLimit() {
	
		return memLimit;
	}
	
	public String getMemPer() {
	
		return memPer;
	}
	
	public String getMemUsage() {
	
		return memUsage;
	}
	
	public String getNetIO() {
	
		return netIO;
	}
	
	public void setBlockIO(String blockIO) {
	
		this.blockIO = blockIO;
	}
	
	public void setCPU(String cPU) {
	
		CPU = cPU;
	}
	
	public void setEnvName(String envName) {
	
		this.envName = envName;
	}
	
	public void setMemLimit(String memLimit) {
	
		this.memLimit = memLimit;
	}
	
	public void setMemPer(String memPer) {
	
		this.memPer = memPer;
	}
	
	public void setMemUsage(String memUsage) {
	
		this.memUsage = memUsage;
	}
	
	public void setNetIO(String netIO) {
	
		this.netIO = netIO;
	}
}
