/**
 *
 */
package com.framework.puppetMaster.to;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @author 584175
 */
public class PuppetProcess implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1578356066434785768L;
	private Long processId;
	private String processFullPath;
	private List<Long> process = new ArrayList<Long>();
	private Set<PuppetProcessParametersTO> puppetProcessParameters = new HashSet<PuppetProcessParametersTO>(0);
	private String status;
	private List<PuppetProcessParametersTO> puppetProcessParameterList = new ArrayList<PuppetProcessParametersTO>(0);
	private List<PuppetProcess> allProcess = new ArrayList<PuppetProcess>();
	private Long tmpList;
	
	/**
	 * @return the processFullPath
	 */
	public String getProcessFullPath() {
	
		return processFullPath;
	}
	
	public List<Long> getProcess() {
	
		return process;
	}
	
	public void setProcess(List<Long> process) {
	
		this.process = process;
	}
	
	/**
	 * @return the processId
	 */
	public Long getProcessId() {
	
		return processId;
	}
	
	/**
	 * @return the puppetProcessParameterList
	 */
	public List<PuppetProcessParametersTO> getPuppetProcessParameterList() {
	
		return puppetProcessParameterList;
	}
	
	/**
	 * @return the puppetProcessParameters
	 */
	public Set<PuppetProcessParametersTO> getPuppetProcessParameters() {
	
		return puppetProcessParameters;
	}
	
	/**
	 * @return the status
	 */
	public String getStatus() {
	
		return status;
	}
	
	/**
	 * @param processFullPath
	 *                the processFullPath to set
	 */
	public void setProcessFullPath(String processFullPath) {
	
		this.processFullPath = processFullPath;
	}
	
	/**
	 * @param processId
	 *                the processId to set
	 */
	public void setProcessId(Long processId) {
	
		this.processId = processId;
	}
	
	/**
	 * @param puppetProcessParameterList
	 *                the puppetProcessParameterList to set
	 */
	public void setPuppetProcessParameterList(List<PuppetProcessParametersTO> puppetProcessParameterList) {
	
		this.puppetProcessParameterList = puppetProcessParameterList;
	}
	
	/**
	 * @param puppetProcessParameters
	 *                the puppetProcessParameters to set
	 */
	public void setPuppetProcessParameters(Set<PuppetProcessParametersTO> puppetProcessParameters) {
	
		this.puppetProcessParameters = puppetProcessParameters;
	}
	
	/**
	 * @param status
	 *                the status to set
	 */
	public void setStatus(String status) {
	
		this.status = status;
	}
	
	public List<PuppetProcess> getAllProcess() {
	
		return allProcess;
	}
	
	public void setAllProcess(List<PuppetProcess> allProcess) {
	
		this.allProcess = allProcess;
	}
	
	public Long getTmpList() {
	
		return tmpList;
	}
	
	public void setTmpList(Long tmpList) {
	
		this.tmpList = tmpList;
	}
}
