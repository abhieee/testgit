package com.framework.to;

import java.io.Serializable;
import com.framework.nolio.to.NolioProcessParametersTO;

public class UserDefinedEnvParamsTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2223771889282167695L;
	private Long id;
	private Long envId;
	private Long nolioProcessParameterId;
	private String nolioProcessParameterValue;
	private NolioProcessParametersTO nolioProcessParametersTO;
	private String parameterType;
	private Long scriptParameterId;
	private ScriptParameterMapTO scriptParameterMapTO;
	
	public String getParameterType() {
	
		return parameterType;
	}
	
	public void setParameterType(String parameterType) {
	
		this.parameterType = parameterType;
	}
	
	public Long getScriptParameterId() {
	
		return scriptParameterId;
	}
	
	public void setScriptParameterId(Long scriptParameterId) {
	
		this.scriptParameterId = scriptParameterId;
	}
	
	public ScriptParameterMapTO getScriptParameterMapTO() {
	
		return scriptParameterMapTO;
	}
	
	public void setScriptParameterMapTO(ScriptParameterMapTO scriptParameterMapTO) {
	
		this.scriptParameterMapTO = scriptParameterMapTO;
	}
	
	public static long getSerialversionuid() {
	
		return serialVersionUID;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public Long getNolioProcessParameterId() {
	
		return nolioProcessParameterId;
	}
	
	public void setNolioProcessParameterId(Long nolioProcessParameterId) {
	
		this.nolioProcessParameterId = nolioProcessParameterId;
	}
	
	public String getNolioProcessParameterValue() {
	
		return nolioProcessParameterValue;
	}
	
	public void setNolioProcessParameterValue(String nolioProcessParameterValue) {
	
		this.nolioProcessParameterValue = nolioProcessParameterValue;
	}
	
	public NolioProcessParametersTO getNolioProcessParametersTO() {
	
		return nolioProcessParametersTO;
	}
	
	public void setNolioProcessParametersTO(NolioProcessParametersTO nolioProcessParametersTO) {
	
		this.nolioProcessParametersTO = nolioProcessParametersTO;
	}
	
	public Long getEnvId() {
	
		return envId;
	}
	
	public void setEnvId(Long envId) {
	
		this.envId = envId;
	}
}
