package com.framework.to;

import java.io.Serializable;

public class BuildToolTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4138605737954026547L;
	private Long id;
	private String name;
	private String description;
	
	public String getDescription() {
	
		return description;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public String getName() {
	
		return name;
	}
	
	public void setDescription(String description) {
	
		this.description = description;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setName(String name) {
	
		this.name = name;
	}
}
