package com.framework.report;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class EnvironmentReservationDetailsReportVO {
	
	private String bu_name = null;
	private String env_name = null;
	private String vm_name = null;
	private String vm_ip = null;
	private String sw_name = null;
	private String app_name = null;
	private String proj_name = null;
	private String resv_user = null;
	private String resv_status = null;
	private Date start_time = null;
	private Date end_time = null;
	private String comments = null;
	private String avail_status = null;
	private Long env_id;
	private List<EnvLinkedResvDetails> weekendList = new ArrayList<EnvLinkedResvDetails>();
	private Connection conn = null;
	private List<EnvLinkedResvMonthDetails> envResvMonthData = new ArrayList<EnvLinkedResvMonthDetails>();
	
	public EnvironmentReservationDetailsReportVO() {
	
		/* No implementation required at the moment. Method for future use. */
	}
	
	public EnvironmentReservationDetailsReportVO(String bu_name, String env_name, String vm_name, String vm_ip, String sw_name, String app_name, String proj_name, String resv_user, String resv_status, Date start_time, Date end_time, String comments, String avail_status, List<EnvLinkedResvDetails> weekendList, Long env_id, Connection conn, List<EnvLinkedResvMonthDetails> envResvMonthData) {
	
		this.bu_name = bu_name;
		this.env_name = env_name;
		this.vm_name = vm_name;
		this.vm_ip = vm_ip;
		this.sw_name = sw_name;
		this.app_name = app_name;
		this.proj_name = proj_name;
		this.resv_user = resv_user;
		this.resv_status = resv_status;
		this.start_time = start_time;
		this.end_time = end_time;
		this.comments = comments;
		this.avail_status = avail_status;
		this.weekendList = weekendList;
		this.env_id = env_id;
		this.conn = conn;
		this.envResvMonthData = envResvMonthData;
	}
	
	public List<EnvLinkedResvDetails> getWeekendList() {
	
		return weekendList;
	}
	
	public void setWeekendList(List<EnvLinkedResvDetails> weekendList) {
	
		this.weekendList = weekendList;
	}
	
	public Connection getConn() {
	
		return conn;
	}
	
	public void setConn(Connection conn) {
	
		this.conn = conn;
	}
	
	public List<EnvLinkedResvMonthDetails> getEnvResvMonthData() {
	
		return envResvMonthData;
	}
	
	public void setEnvResvMonthData(List<EnvLinkedResvMonthDetails> envResvMonthData) {
	
		this.envResvMonthData = envResvMonthData;
	}
	
	public Long getEnv_id() {
	
		return env_id;
	}
	
	public void setEnv_id(Long env_id) {
	
		this.env_id = env_id;
	}
	
	public String getBu_name() {
	
		return bu_name;
	}
	
	public void setBu_name(String bu_name) {
	
		this.bu_name = bu_name;
	}
	
	public String getEnv_name() {
	
		return env_name;
	}
	
	public void setEnv_name(String env_name) {
	
		this.env_name = env_name;
	}
	
	public String getVm_name() {
	
		return vm_name;
	}
	
	public void setVm_name(String vm_name) {
	
		this.vm_name = vm_name;
	}
	
	public String getVm_ip() {
	
		return vm_ip;
	}
	
	public void setVm_ip(String vm_ip) {
	
		this.vm_ip = vm_ip;
	}
	
	public String getSw_name() {
	
		return sw_name;
	}
	
	public void setSw_name(String sw_name) {
	
		this.sw_name = sw_name;
	}
	
	public String getApp_name() {
	
		return app_name;
	}
	
	public void setApp_name(String app_name) {
	
		this.app_name = app_name;
	}
	
	public String getProj_name() {
	
		return proj_name;
	}
	
	public void setProj_name(String proj_name) {
	
		this.proj_name = proj_name;
	}
	
	public String getResv_user() {
	
		return resv_user;
	}
	
	public void setResv_user(String resv_user) {
	
		this.resv_user = resv_user;
	}
	
	public String getResv_status() {
	
		return resv_status;
	}
	
	public void setResv_status(String resv_status) {
	
		this.resv_status = resv_status;
	}
	
	public Date getStart_time() {
	
		return start_time;
	}
	
	public void setStart_time(Date start_time) {
	
		this.start_time = start_time;
	}
	
	public Date getEnd_time() {
	
		return end_time;
	}
	
	public void setEnd_time(Date end_time) {
	
		this.end_time = end_time;
	}
	
	public String getComments() {
	
		return comments;
	}
	
	public void setComments(String comments) {
	
		this.comments = comments;
	}
	
	public String getAvail_status() {
	
		return avail_status;
	}
	
	public void setAvail_status(String avail_status) {
	
		this.avail_status = avail_status;
	}
}
