package com.framework.to;

import java.util.Set;

/**
 * This class declares the transfer onject that carries device information across the application.
 *
 * @author TCS
 */
public class DeviceTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4555726549389185014L;
	private String deviceType = null;
	private String manufacturer = null;
	private String model = null;
	private DomainTO domain = null;
	private Set<DeviceConfigTO> deviceConfigs = null;
	private Long utilization = null;
	private Set<ReservationTO> reservations = null;
	
	public DeviceTO() {
	
		super();
	}
	
	public void copy(DeviceTO deviceTO) {
	
		if (deviceTO == null) {
			deviceTO = new DeviceTO();
		}
		if ((deviceTO.getName() == null) || !deviceTO.getName().equals(this.getName())) {
			deviceTO.setName(this.getName());
		}
		if ((deviceTO.getDeviceType() == null) || !deviceTO.getDeviceType().equals(this.getDeviceType())) {
			deviceTO.setDeviceType(this.getDeviceType());
		}
		if ((deviceTO.getManufacturer() == null) || !deviceTO.getManufacturer().equals(this.getManufacturer())) {
			deviceTO.setManufacturer(this.getManufacturer());
		}
		if ((deviceTO.getModel() == null) || !deviceTO.getModel().equals(this.getModel())) {
			deviceTO.setModel(this.getModel());
		}
	}
	
	/**
	 * @return the deviceConfigs
	 */
	public Set<DeviceConfigTO> getDeviceConfigs() {
	
		return deviceConfigs;
	}
	
	/**
	 * @return the deviceType
	 */
	public String getDeviceType() {
	
		return deviceType;
	}
	
	/**
	 * @return the domain
	 */
	public DomainTO getDomain() {
	
		return domain;
	}
	
	/**
	 * @return the manufacturer
	 */
	public String getManufacturer() {
	
		return manufacturer;
	}
	
	/**
	 * @return the model
	 */
	public String getModel() {
	
		return model;
	}
	
	/**
	 * @return the reservations
	 */
	public Set<ReservationTO> getReservations() {
	
		return reservations;
	}
	
	/**
	 * @return the utilization
	 */
	public Long getUtilization() {
	
		return utilization;
	}
	
	/**
	 * @param deviceConfigs
	 *                the deviceConfigs to set
	 */
	public void setDeviceConfigs(Set<DeviceConfigTO> deviceConfigs) {
	
		this.deviceConfigs = deviceConfigs;
	}
	
	/**
	 * @param deviceType
	 *                the deviceType to set
	 */
	public void setDeviceType(String deviceType) {
	
		this.deviceType = deviceType;
	}
	
	/**
	 * @param domain
	 *                the domain to set
	 */
	public void setDomain(DomainTO domain) {
	
		this.domain = domain;
	}
	
	/**
	 * @param manufacturer
	 *                the manufacturer to set
	 */
	public void setManufacturer(String manufacturer) {
	
		this.manufacturer = manufacturer;
	}
	
	/**
	 * @param model
	 *                the model to set
	 */
	public void setModel(String model) {
	
		this.model = model;
	}
	
	/**
	 * @param reservations
	 *                the reservations to set
	 */
	public void setReservations(Set<ReservationTO> reservations) {
	
		this.reservations = reservations;
	}
	
	/**
	 * @param utilization
	 *                the utilization to set
	 */
	public void setUtilization(Long utilization) {
	
		this.utilization = utilization;
	}
}
