package com.framework.to;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class PhaseManagementTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5724117069678479285L;
	private long appId;
	private long profileId;
	private long releaseId;
	private List<ReleasePlanningTO> allReleasePlans = new ArrayList<>(0);
	private Long selectedReleasePlan;
	private String appName;
	private String profileName;
	private String releaseName;
	private long phaseId;
	
	public List<ReleasePlanningTO> getAllReleasePlans() {
	
		return allReleasePlans;
	}
	
	public long getAppId() {
	
		return appId;
	}
	
	public String getAppName() {
	
		return appName;
	}
	
	public long getPhaseId() {
	
		return phaseId;
	}
	
	public long getProfileId() {
	
		return profileId;
	}
	
	public String getProfileName() {
	
		return profileName;
	}
	
	public long getReleaseId() {
	
		return releaseId;
	}
	
	public String getReleaseName() {
	
		return releaseName;
	}
	
	public Long getSelectedReleasePlan() {
	
		return selectedReleasePlan;
	}
	
	public void setAllReleasePlans(List<ReleasePlanningTO> allReleasePlans) {
	
		this.allReleasePlans = allReleasePlans;
	}
	
	public void setAppId(long appId) {
	
		this.appId = appId;
	}
	
	public void setAppName(String appName) {
	
		this.appName = appName;
	}
	
	public void setPhaseId(long phaseId) {
	
		this.phaseId = phaseId;
	}
	
	public void setProfileId(long profileId) {
	
		this.profileId = profileId;
	}
	
	public void setProfileName(String profileName) {
	
		this.profileName = profileName;
	}
	
	public void setReleaseId(long releaseId) {
	
		this.releaseId = releaseId;
	}
	
	public void setReleaseName(String releaseName) {
	
		this.releaseName = releaseName;
	}
	
	public void setSelectedReleasePlan(Long selectedReleasePlan) {
	
		this.selectedReleasePlan = selectedReleasePlan;
	}
}