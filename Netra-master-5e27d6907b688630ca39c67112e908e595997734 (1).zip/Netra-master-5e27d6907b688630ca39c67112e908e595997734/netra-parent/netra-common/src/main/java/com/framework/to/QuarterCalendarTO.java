package com.framework.to;

public class QuarterCalendarTO {
	
	private String month;
	private double width;
	
	public String getMonth() {
	
		return month;
	}
	
	public void setMonth(String month) {
	
		this.month = month;
	}
	
	public double getWidth() {
	
		return width;
	}
	
	public void setWidth(double width) {
	
		this.width = width;
	}
}
