package com.framework.to;

public class BatchTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4347902246966520336L;
	private Long status;
	private String comments;
	
	public String getComments() {
	
		return comments;
	}
	
	public Long getStatus() {
	
		return status;
	}
	
	public void setComments(String comments) {
	
		this.comments = comments;
	}
	
	public void setStatus(Long status) {
	
		this.status = status;
	}
}
