package com.framework.common;

public enum Host {
	HOST_NAME("VM{NUMBER}_{REQUESTID}_EV_{ENVIRONMENTID}");
	
	private String hostNameType;
	
	private Host(String s) {
	
		this.hostNameType = s;
	}
	
	public String getHostNameType() {
	
		return hostNameType;
	}
}
