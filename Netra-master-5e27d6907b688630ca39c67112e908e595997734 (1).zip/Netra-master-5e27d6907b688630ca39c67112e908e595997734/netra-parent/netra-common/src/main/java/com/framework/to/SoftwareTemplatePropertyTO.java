package com.framework.to;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * This class declares the transfer object that carries user information across the application.
 *
 * @author TCS
 */
public class SoftwareTemplatePropertyTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8034990464470944561L;
	private Long sofwareTemplateId;
	private SoftwareconfigTO softwareconfigTO = new SoftwareconfigTO();
	private String componentName;
	private String propertyName;
	private String propertyValue;
	private String resourceName;
	private boolean newRow;
	private boolean deleteRow;
	List<ParameterTO> paramTo = new ArrayList<ParameterTO>();
	private Long paramId;
	private String paramName;
	private Long id;
	private SoftwareconfigTO softwareConfigTO;
	private ParameterTO parameterTO;
	private String value;
	
	public String getComponentName() {
	
		return componentName;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public ParameterTO getParameterTO() {
	
		return parameterTO;
	}
	
	public Long getParamId() {
	
		return paramId;
	}
	
	public String getParamName() {
	
		return paramName;
	}
	
	public List<ParameterTO> getParamTo() {
	
		return paramTo;
	}
	
	public String getPropertyName() {
	
		return propertyName;
	}
	
	public String getPropertyValue() {
	
		return propertyValue;
	}
	
	public String getResourceName() {
	
		return resourceName;
	}
	
	public SoftwareconfigTO getSoftwareconfigTO() {
	
		return softwareconfigTO;
	}
	
	public SoftwareconfigTO getSoftwareConfigTO() {
	
		return softwareConfigTO;
	}
	
	public Long getSofwareTemplateId() {
	
		return sofwareTemplateId;
	}
	
	public String getValue() {
	
		return value;
	}
	
	public boolean isDeleteRow() {
	
		return deleteRow;
	}
	
	public boolean isNewRow() {
	
		return newRow;
	}
	
	public void setComponentName(String componentName) {
	
		this.componentName = componentName;
	}
	
	public void setDeleteRow(boolean deleteRow) {
	
		this.deleteRow = deleteRow;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setNewRow(boolean newRow) {
	
		this.newRow = newRow;
	}
	
	public void setParameterTO(ParameterTO parameterTO) {
	
		this.parameterTO = parameterTO;
	}
	
	public void setParamId(Long paramId) {
	
		this.paramId = paramId;
	}
	
	public void setParamName(String paramName) {
	
		this.paramName = paramName;
	}
	
	public void setParamTo(List<ParameterTO> paramTo) {
	
		this.paramTo = paramTo;
	}
	
	public void setPropertyName(String propertyName) {
	
		this.propertyName = propertyName;
	}
	
	public void setPropertyValue(String propertyValue) {
	
		this.propertyValue = propertyValue;
	}
	
	public void setResourceName(String resourceName) {
	
		this.resourceName = resourceName;
	}
	
	public void setSoftwareconfigTO(SoftwareconfigTO softwareconfigTO) {
	
		this.softwareconfigTO = softwareconfigTO;
	}
	
	public void setSoftwareConfigTO(SoftwareconfigTO softwareConfigTO) {
	
		this.softwareConfigTO = softwareConfigTO;
	}
	
	public void setSofwareTemplateId(Long sofwareTemplateId) {
	
		this.sofwareTemplateId = sofwareTemplateId;
	}
	
	public void setValue(String value) {
	
		this.value = value;
	}
}
