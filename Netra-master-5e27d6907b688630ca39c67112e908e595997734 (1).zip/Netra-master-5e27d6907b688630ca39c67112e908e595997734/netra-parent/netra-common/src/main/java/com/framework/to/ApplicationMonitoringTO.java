package com.framework.to;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ApplicationMonitoringTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8197053061833870760L;
	private String chartImage;
	private String areaTagValue;
	private String chartImageEnv;
	private String areaTagValueEnv;
	private String chartImageRelease;
	private String chartImagePhase;
	private String areaTagValueRelease;
	private String chartImageWorkFlow;
	private String areaTagValueWorkFlow;
	private String applicationValue;
	private String environmentValue;
	private List environmentList = new ArrayList(0);
	private List phaseList = new ArrayList(0);
	private List applicationList = new ArrayList(0);
	
	public List getApplicationList() {
	
		return applicationList;
	}
	
	public String getApplicationValue() {
	
		return applicationValue;
	}
	
	public String getAreaTagValue() {
	
		return areaTagValue;
	}
	
	public String getAreaTagValueEnv() {
	
		return areaTagValueEnv;
	}
	
	public String getAreaTagValueRelease() {
	
		return areaTagValueRelease;
	}
	
	public String getAreaTagValueWorkFlow() {
	
		return areaTagValueWorkFlow;
	}
	
	public String getChartImage() {
	
		return chartImage;
	}
	
	public String getChartImageEnv() {
	
		return chartImageEnv;
	}
	
	public String getChartImagePhase() {
	
		return chartImagePhase;
	}
	
	public String getChartImageRelease() {
	
		return chartImageRelease;
	}
	
	public String getChartImageWorkFlow() {
	
		return chartImageWorkFlow;
	}
	
	public List getEnvironmentList() {
	
		return environmentList;
	}
	
	public String getEnvironmentValue() {
	
		return environmentValue;
	}
	
	public List getPhaseList() {
	
		return phaseList;
	}
	
	public void setApplicationList(List applicationList) {
	
		this.applicationList = applicationList;
	}
	
	public void setApplicationValue(String applicationValue) {
	
		this.applicationValue = applicationValue;
	}
	
	public void setAreaTagValue(String areaTagValue) {
	
		this.areaTagValue = areaTagValue;
	}
	
	public void setAreaTagValueEnv(String areaTagValueEnv) {
	
		this.areaTagValueEnv = areaTagValueEnv;
	}
	
	public void setAreaTagValueRelease(String areaTagValueRelease) {
	
		this.areaTagValueRelease = areaTagValueRelease;
	}
	
	public void setAreaTagValueWorkFlow(String areaTagValueWorkFlow) {
	
		this.areaTagValueWorkFlow = areaTagValueWorkFlow;
	}
	
	public void setChartImage(String chartImage) {
	
		this.chartImage = chartImage;
	}
	
	public void setChartImageEnv(String chartImageEnv) {
	
		this.chartImageEnv = chartImageEnv;
	}
	
	public void setChartImagePhase(String chartImagePhase) {
	
		this.chartImagePhase = chartImagePhase;
	}
	
	public void setChartImageRelease(String chartImageRelease) {
	
		this.chartImageRelease = chartImageRelease;
	}
	
	public void setChartImageWorkFlow(String chartImageWorkFlow) {
	
		this.chartImageWorkFlow = chartImageWorkFlow;
	}
	
	public void setEnvironmentList(List environmentList) {
	
		this.environmentList = environmentList;
	}
	
	public void setEnvironmentValue(String environmentValue) {
	
		this.environmentValue = environmentValue;
	}
	
	public void setPhaseList(List phaseList) {
	
		this.phaseList = phaseList;
	}
}
