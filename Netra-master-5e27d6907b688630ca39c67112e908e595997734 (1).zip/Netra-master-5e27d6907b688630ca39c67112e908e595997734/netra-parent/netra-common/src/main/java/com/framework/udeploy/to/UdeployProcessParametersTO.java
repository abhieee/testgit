package com.framework.udeploy.to;

public class UdeployProcessParametersTO {
	
	private long parameterId;
	private String parameterPathName;
	private String parameterValue;
	private Long id;
	private String name;
	private String status;
	private UdeployProcess udeployProcess;
	private String netraParameterName;
	private String netraParameterMapping;
	private Long processId;
	
	public long getParameterId() {
	
		return parameterId;
	}
	
	public void setParameterId(long parameterId) {
	
		this.parameterId = parameterId;
	}
	
	public String getParameterPathName() {
	
		return parameterPathName;
	}
	
	public void setParameterPathName(String parameterPathName) {
	
		this.parameterPathName = parameterPathName;
	}
	
	public String getParameterValue() {
	
		return parameterValue;
	}
	
	public void setParameterValue(String parameterValue) {
	
		this.parameterValue = parameterValue;
	}
	
	@Override
	public boolean equals(Object obj) {
	
		if (obj == null) {
			return false;
		}
		if (!this.getClass().equals(obj.getClass())) {
			return false;
		}
		UdeployProcessParametersTO obj2 = (UdeployProcessParametersTO) obj;
		if ((this.parameterId == obj2.getParameterId()) && this.parameterPathName.equals(obj2.getParameterPathName())) {
			return true;
		}
		return false;
	}
	
	@Override
	public int hashCode() {
	
		int tmp = 0;
		tmp = (parameterId + parameterPathName).hashCode();
		return tmp;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public String getName() {
	
		return name;
	}
	
	public void setName(String name) {
	
		this.name = name;
	}
	
	public String getStatus() {
	
		return status;
	}
	
	public void setStatus(String status) {
	
		this.status = status;
	}
	
	public String getNetraParameterName() {
	
		return netraParameterName;
	}
	
	public void setNetraParameterName(String netraParameterName) {
	
		this.netraParameterName = netraParameterName;
	}
	
	public String getNetraParameterMapping() {
	
		return netraParameterMapping;
	}
	
	public void setNetraParameterMapping(String netraParameterMapping) {
	
		this.netraParameterMapping = netraParameterMapping;
	}
	
	public Long getProcessId() {
	
		return processId;
	}
	
	public void setProcessId(Long processId) {
	
		this.processId = processId;
	}
	
	private String selectedParameterScope;
	
	public String getSelectedParameterScope() {
	
		return selectedParameterScope;
	}
	
	public void setSelectedParameterScope(String selectedParameterScope) {
	
		this.selectedParameterScope = selectedParameterScope;
	}
	
	public UdeployProcess getUdeployProcess() {
	
		return udeployProcess;
	}
	
	public void setUdeployProcess(UdeployProcess udeployProcess) {
	
		this.udeployProcess = udeployProcess;
	}
}
