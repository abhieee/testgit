package com.framework.to;

import java.io.Serializable;
import java.util.Date;

public class ProvisionedTemplateTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3923027927330546970L;
	private Long id;
	private String name;
	private String architecture;
	private Long platformId;
	private String description;
	private Byte activeFlag;
	private Long createdBy;
	private Date createdOn;
	private Long updatedBy;
	private Date updatedOn;
	private PlatformMasterTO platform;
	
	public Byte getActiveFlag() {
	
		return activeFlag;
	}
	
	public String getArchitecture() {
	
		return architecture;
	}
	
	public Long getCreatedBy() {
	
		return createdBy;
	}
	
	public Date getCreatedOn() {
	
		return createdOn;
	}
	
	public String getDescription() {
	
		return description;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public String getName() {
	
		return name;
	}
	
	public PlatformMasterTO getPlatform() {
	
		return platform;
	}
	
	public Long getPlatformId() {
	
		return platformId;
	}
	
	public Long getUpdatedBy() {
	
		return updatedBy;
	}
	
	public Date getUpdatedOn() {
	
		return updatedOn;
	}
	
	public void setActiveFlag(Byte activeFlag) {
	
		this.activeFlag = activeFlag;
	}
	
	public void setArchitecture(String architecture) {
	
		this.architecture = architecture;
	}
	
	public void setCreatedBy(Long createdBy) {
	
		this.createdBy = createdBy;
	}
	
	public void setCreatedOn(Date createdOn) {
	
		this.createdOn = createdOn;
	}
	
	public void setDescription(String description) {
	
		this.description = description;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setName(String name) {
	
		this.name = name;
	}
	
	public void setPlatform(PlatformMasterTO platform) {
	
		this.platform = platform;
	}
	
	public void setPlatformId(Long platformId) {
	
		this.platformId = platformId;
	}
	
	public void setUpdatedBy(Long updatedBy) {
	
		this.updatedBy = updatedBy;
	}
	
	public void setUpdatedOn(Date updatedOn) {
	
		this.updatedOn = updatedOn;
	}
}
