package com.framework.to;

public class ApplicationReleasePhaseTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2245249060524186026L;
	private Long applicationId;
	private Long phaseId;
	private Long order;
	private TestingPhaseTO testingPhase;
	private String stat;
	private String statusImage;
	private boolean lastPhase;
	private Long selectedReleasePlan;
	private ReleasePlanningTO releasePlanningTO;
	
	public Long getApplicationId() {
	
		return applicationId;
	}
	
	public Long getOrder() {
	
		return order;
	}
	
	public Long getPhaseId() {
	
		return phaseId;
	}
	
	public ReleasePlanningTO getReleasePlanningTO() {
	
		return releasePlanningTO;
	}
	
	public Long getSelectedReleasePlan() {
	
		return selectedReleasePlan;
	}
	
	public String getStat() {
	
		return stat;
	}
	
	public String getStatusImage() {
	
		return statusImage;
	}
	
	public TestingPhaseTO getTestingPhase() {
	
		return testingPhase;
	}
	
	public boolean isLastPhase() {
	
		return lastPhase;
	}
	
	public void setApplicationId(Long applicationId) {
	
		this.applicationId = applicationId;
	}
	
	public void setLastPhase(boolean lastPhase) {
	
		this.lastPhase = lastPhase;
	}
	
	public void setOrder(Long order) {
	
		this.order = order;
	}
	
	public void setPhaseId(Long phaseId) {
	
		this.phaseId = phaseId;
	}
	
	public void setReleasePlanningTO(ReleasePlanningTO releasePlanningTO) {
	
		this.releasePlanningTO = releasePlanningTO;
	}
	
	public void setSelectedReleasePlan(Long selectedReleasePlan) {
	
		this.selectedReleasePlan = selectedReleasePlan;
	}
	
	public void setStat(String stat) {
	
		this.stat = stat;
	}
	
	public void setStatusImage(String statusImage) {
	
		this.statusImage = statusImage;
	}
	
	public void setTestingPhase(TestingPhaseTO testingPhase) {
	
		this.testingPhase = testingPhase;
	}
}