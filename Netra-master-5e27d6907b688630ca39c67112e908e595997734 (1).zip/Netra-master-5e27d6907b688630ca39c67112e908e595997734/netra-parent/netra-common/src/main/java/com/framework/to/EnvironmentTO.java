/**
 *
 */
package com.framework.to;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @author TCS
 */
public class EnvironmentTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8193319317320763617L;
	private Long applicationId;
	private String environmentName;
	private Long status;
	private String envStatus;
	private List<Long> applicationNameSelected = new ArrayList<Long>(0);;
	private Set<EnvironmentDetailsTO> environmentDetails = new HashSet<EnvironmentDetailsTO>(0);
	private String dockerContainerIP;
	private Set<EnvironmentDockerTO> environmentDockerTO = new HashSet<EnvironmentDockerTO>(0);
	private Set<ReservationTO> reservationses = new HashSet<ReservationTO>(0);
	private List<ApplicationTO> allApplications = new ArrayList<ApplicationTO>();
	private List<EnvironmentTO> envList = new ArrayList<EnvironmentTO>();
	private Set<WorkflowCurrentTO> workflowCurrentTO = new HashSet<WorkflowCurrentTO>();
	private List<Long> definedApplications = new ArrayList<Long>(0);
	private Long selectedApplication = null;
	private String applicationName;
	private Date createdByDate = null;
	private Date modifiedbyDate = null;
	private String project;
	private Long releaseId;
	private String businessUnit;
	private String phaseName;
	private String profileName;
	private TestingPhaseTO testingPhaseTO;
	private List<TestingPhaseTO> allTestingCycles = new ArrayList<TestingPhaseTO>();
	private ApplicationReleaseTO releaseTO;
	private Date fromDate = null;
	private Date toDate = null;
	private Long profileId;
	private Long clientId;
	private Long projectId;
	private ApplicationProfileTO applicationProfileTO;
	private Long parentEnv;
	private String envType;
	private String propertyName;
	private String allocationMode;
	private Long serviceId;
	private StatusTO statusTO;
	private String applicationValue = null;
	private String environmentValue = null;
	private Long roleId = null;
	private boolean lastPhase;
	private int tableSize = 10;
	private Long pageNumber = 1L;
	private int firstResult = 0;
	private long searchCount;
	private String taggedProjects;
	private Set<SubEnvironmentMappingTO> subEnvironmentMapping = new HashSet<SubEnvironmentMappingTO>(0);
	private List<Long> addedApplication = new ArrayList<Long>();
	private String monitoringRequired;
	private String reservationCheck;
	private UserTO usersTO;
	private Set<EnvironmentApplicationTO> environmentApplicationTO = new HashSet<EnvironmentApplicationTO>(0);
	private Set<EnvironmentApplicationTO> environmentApplicationSet = new HashSet<EnvironmentApplicationTO>(0);
	private Set<VMDetailsTO> environmentVmDet = new HashSet<VMDetailsTO>(0);
	int flag = 1;
	private Long envTypeId;
	private EnvTypeTO envTypeTO;
	private String envTypeName;
	private List<ReleasePlanningTO> planningTO = new ArrayList<ReleasePlanningTO>();
	
	public List<ReleasePlanningTO> getPlanningTO() {
	
		return planningTO;
	}
	
	public void setPlanningTO(List<ReleasePlanningTO> planningTO) {
	
		this.planningTO = planningTO;
	}
	
	public List<Long> getAddedApplication() {
	
		return addedApplication;
	}
	
	public List<ApplicationTO> getAllApplications() {
	
		return allApplications;
	}
	
	public String getAllocationMode() {
	
		return allocationMode;
	}
	
	public List<TestingPhaseTO> getAllTestingCycles() {
	
		return allTestingCycles;
	}
	
	public Long getApplicationId() {
	
		return applicationId;
	}
	
	public String getApplicationName() {
	
		return applicationName;
	}
	
	public List<Long> getApplicationNameSelected() {
	
		return applicationNameSelected;
	}
	
	public ApplicationProfileTO getApplicationProfileTO() {
	
		return applicationProfileTO;
	}
	
	public String getApplicationValue() {
	
		return applicationValue;
	}
	
	public String getBusinessUnit() {
	
		return businessUnit;
	}
	
	public Long getClientId() {
	
		return clientId;
	}
	
	public Date getCreatedByDate() {
	
		return createdByDate;
	}
	
	public List<Long> getDefinedApplications() {
	
		return definedApplications;
	}
	
	public String getDockerContainerIP() {
	
		return dockerContainerIP;
	}
	
	public Set<EnvironmentApplicationTO> getEnvironmentApplicationSet() {
	
		return environmentApplicationSet;
	}
	
	public Set<EnvironmentApplicationTO> getEnvironmentApplicationTO() {
	
		return environmentApplicationTO;
	}
	
	public Set<EnvironmentDetailsTO> getEnvironmentDetails() {
	
		return environmentDetails;
	}
	
	public Set<EnvironmentDockerTO> getEnvironmentDockerTO() {
	
		return environmentDockerTO;
	}
	
	public String getEnvironmentName() {
	
		return environmentName;
	}
	
	public String getEnvironmentValue() {
	
		return environmentValue;
	}
	
	public Set<VMDetailsTO> getEnvironmentVmDet() {
	
		return environmentVmDet;
	}
	
	public List<EnvironmentTO> getEnvList() {
	
		return envList;
	}
	
	public String getEnvStatus() {
	
		return envStatus;
	}
	
	public String getEnvType() {
	
		return envType;
	}
	
	/**
	 * @return the firstResult
	 */
	public int getFirstResult() {
	
		return firstResult;
	}
	
	public int getFlag() {
	
		return flag;
	}
	
	public Date getFromDate() {
	
		return fromDate;
	}
	
	public Date getModifiedbyDate() {
	
		return modifiedbyDate;
	}
	
	/**
	 * @return the monitoringRequired
	 */
	public String getMonitoringRequired() {
	
		return monitoringRequired;
	}
	
	/**
	 * @return the pageNumber
	 */
	public Long getPageNumber() {
	
		return pageNumber;
	}
	
	public Long getParentEnv() {
	
		return parentEnv;
	}
	
	public String getPhaseName() {
	
		return phaseName;
	}
	
	public Long getProfileId() {
	
		return profileId;
	}
	
	public String getProfileName() {
	
		return profileName;
	}
	
	public String getProject() {
	
		return project;
	}
	
	public Long getProjectId() {
	
		return projectId;
	}
	
	public String getPropertyName() {
	
		return propertyName;
	}
	
	public Long getReleaseId() {
	
		return releaseId;
	}
	
	public ApplicationReleaseTO getReleaseTO() {
	
		return releaseTO;
	}
	
	public String getReservationCheck() {
	
		return reservationCheck;
	}
	
	public Set<ReservationTO> getReservationses() {
	
		return reservationses;
	}
	
	public Long getRoleId() {
	
		return roleId;
	}
	
	/**
	 * @return the searchCount
	 */
	public long getSearchCount() {
	
		return searchCount;
	}
	
	public Long getSelectedApplication() {
	
		return selectedApplication;
	}
	
	public Long getServiceId() {
	
		return serviceId;
	}
	
	public Long getStatus() {
	
		return status;
	}
	
	public StatusTO getStatusTO() {
	
		return statusTO;
	}
	
	public Set<SubEnvironmentMappingTO> getSubEnvironmentMapping() {
	
		return subEnvironmentMapping;
	}
	
	/**
	 * @return the tableSize
	 */
	public int getTableSize() {
	
		return tableSize;
	}
	
	public String getTaggedProjects() {
	
		return taggedProjects;
	}
	
	public TestingPhaseTO getTestingPhaseTO() {
	
		return testingPhaseTO;
	}
	
	public Date getToDate() {
	
		return toDate;
	}
	
	public UserTO getUsersTO() {
	
		return usersTO;
	}
	
	public Set<WorkflowCurrentTO> getWorkflowCurrentTO() {
	
		return workflowCurrentTO;
	}
	
	public boolean isLastPhase() {
	
		return lastPhase;
	}
	
	public void setAddedApplication(List<Long> addedApplication) {
	
		this.addedApplication = addedApplication;
	}
	
	public void setAllApplications(List<ApplicationTO> allApplications) {
	
		this.allApplications = allApplications;
	}
	
	public void setAllocationMode(String allocationMode) {
	
		this.allocationMode = allocationMode;
	}
	
	public void setAllTestingCycles(List<TestingPhaseTO> allTestingCycles) {
	
		this.allTestingCycles = allTestingCycles;
	}
	
	public void setApplicationId(Long applicationId) {
	
		this.applicationId = applicationId;
	}
	
	public void setApplicationName(String applicationName) {
	
		this.applicationName = applicationName;
	}
	
	public void setApplicationNameSelected(List<Long> applicationNameSelected) {
	
		this.applicationNameSelected = applicationNameSelected;
	}
	
	public void setApplicationProfileTO(ApplicationProfileTO applicationProfileTO) {
	
		this.applicationProfileTO = applicationProfileTO;
	}
	
	public void setApplicationValue(String applicationValue) {
	
		this.applicationValue = applicationValue;
	}
	
	public void setBusinessUnit(String businessUnit) {
	
		this.businessUnit = businessUnit;
	}
	
	public void setClientId(Long clientId) {
	
		this.clientId = clientId;
	}
	
	public void setCreatedByDate(Date createdByDate) {
	
		this.createdByDate = createdByDate;
	}
	
	public void setDefinedApplications(List<Long> definedApplications) {
	
		this.definedApplications = definedApplications;
	}
	
	public void setDockerContainerIP(String dockerContainerIP) {
	
		this.dockerContainerIP = dockerContainerIP;
	}
	
	public void setEnvironmentApplicationSet(Set<EnvironmentApplicationTO> environmentApplicationSet) {
	
		this.environmentApplicationSet = environmentApplicationSet;
	}
	
	public void setEnvironmentApplicationTO(Set<EnvironmentApplicationTO> environmentApplicationTO) {
	
		this.environmentApplicationTO = environmentApplicationTO;
	}
	
	public void setEnvironmentDetails(Set<EnvironmentDetailsTO> environmentDetails) {
	
		this.environmentDetails = environmentDetails;
	}
	
	public void setEnvironmentDockerTO(Set<EnvironmentDockerTO> environmentDockerTO) {
	
		this.environmentDockerTO = environmentDockerTO;
	}
	
	public void setEnvironmentName(String environmentName) {
	
		this.environmentName = environmentName;
	}
	
	public void setEnvironmentValue(String environmentValue) {
	
		this.environmentValue = environmentValue;
	}
	
	public void setEnvironmentVmDet(Set<VMDetailsTO> environmentVmDet) {
	
		this.environmentVmDet = environmentVmDet;
	}
	
	public void setEnvList(List<EnvironmentTO> envList) {
	
		this.envList = envList;
	}
	
	public void setEnvStatus(String envStatus) {
	
		this.envStatus = envStatus;
	}
	
	public void setEnvType(String envType) {
	
		this.envType = envType;
	}
	
	/**
	 * @param firstResult
	 *                the firstResult to set
	 */
	public void setFirstResult(int firstResult) {
	
		this.firstResult = firstResult;
	}
	
	public void setFlag(int flag) {
	
		this.flag = flag;
	}
	
	public void setFromDate(Date fromDate) {
	
		this.fromDate = fromDate;
	}
	
	public void setLastPhase(boolean lastPhase) {
	
		this.lastPhase = lastPhase;
	}
	
	public void setModifiedbyDate(Date modifiedbyDate) {
	
		this.modifiedbyDate = modifiedbyDate;
	}
	
	/**
	 * @param monitoringRequired
	 *                the monitoringRequired to set
	 */
	public void setMonitoringRequired(String monitoringRequired) {
	
		this.monitoringRequired = monitoringRequired;
	}
	
	/**
	 * @param pageNumber
	 *                the pageNumber to set
	 */
	public void setPageNumber(Long pageNumber) {
	
		this.pageNumber = pageNumber;
	}
	
	public void setParentEnv(Long parentEnv) {
	
		this.parentEnv = parentEnv;
	}
	
	public void setPhaseName(String phaseName) {
	
		this.phaseName = phaseName;
	}
	
	public void setProfileId(Long profileId) {
	
		this.profileId = profileId;
	}
	
	public void setProfileName(String profileName) {
	
		this.profileName = profileName;
	}
	
	public void setProject(String project) {
	
		this.project = project;
	}
	
	public void setProjectId(Long projectId) {
	
		this.projectId = projectId;
	}
	
	public void setPropertyName(String propertyName) {
	
		this.propertyName = propertyName;
	}
	
	public void setReleaseId(Long releaseId) {
	
		this.releaseId = releaseId;
	}
	
	public void setReleaseTO(ApplicationReleaseTO releaseTO) {
	
		this.releaseTO = releaseTO;
	}
	
	public void setReservationCheck(String reservationCheck) {
	
		this.reservationCheck = reservationCheck;
	}
	
	public void setReservationses(Set<ReservationTO> reservationses) {
	
		this.reservationses = reservationses;
	}
	
	public void setRoleId(Long roleId) {
	
		this.roleId = roleId;
	}
	
	/**
	 * @param searchCount
	 *                the searchCount to set
	 */
	public void setSearchCount(long searchCount) {
	
		this.searchCount = searchCount;
	}
	
	public void setSelectedApplication(Long selectedApplication) {
	
		this.selectedApplication = selectedApplication;
	}
	
	public void setServiceId(Long serviceId) {
	
		this.serviceId = serviceId;
	}
	
	public void setStatus(Long status) {
	
		this.status = status;
	}
	
	public void setStatusTO(StatusTO statusTO) {
	
		this.statusTO = statusTO;
	}
	
	public void setSubEnvironmentMapping(Set<SubEnvironmentMappingTO> subEnvironmentMapping) {
	
		this.subEnvironmentMapping = subEnvironmentMapping;
	}
	
	/**
	 * @param tableSize
	 *                the tableSize to set
	 */
	public void setTableSize(int tableSize) {
	
		this.tableSize = tableSize;
	}
	
	public void setTaggedProjects(String taggedProjects) {
	
		this.taggedProjects = taggedProjects;
	}
	
	public void setTestingPhaseTO(TestingPhaseTO testingPhaseTO) {
	
		this.testingPhaseTO = testingPhaseTO;
	}
	
	public void setToDate(Date toDate) {
	
		this.toDate = toDate;
	}
	
	public void setUsersTO(UserTO usersTO) {
	
		this.usersTO = usersTO;
	}
	
	public void setWorkflowCurrentTO(Set<WorkflowCurrentTO> workflowCurrentTO) {
	
		this.workflowCurrentTO = workflowCurrentTO;
	}
	
	public Long getEnvTypeId() {
	
		return envTypeId;
	}
	
	public void setEnvTypeId(Long envTypeId) {
	
		this.envTypeId = envTypeId;
	}
	
	public EnvTypeTO getEnvTypeTO() {
	
		return envTypeTO;
	}
	
	public void setEnvTypeTO(EnvTypeTO envTypeTO) {
	
		this.envTypeTO = envTypeTO;
	}
	
	public String getEnvTypeName() {
	
		return envTypeName;
	}
	
	public void setEnvTypeName(String envTypeName) {
	
		this.envTypeName = envTypeName;
	}
}