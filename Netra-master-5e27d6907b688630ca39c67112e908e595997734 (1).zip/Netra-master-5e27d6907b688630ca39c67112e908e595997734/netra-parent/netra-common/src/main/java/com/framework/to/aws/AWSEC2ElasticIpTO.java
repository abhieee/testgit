package com.framework.to.aws;

/**
 * @author 459704
 */
public class AWSEC2ElasticIpTO {
	
	private String allocationId;
	private String associationId;
	private String domain;
	private String instanceId;
	private String networkInterfaceId;
	private String networkInterfaceOwnerId;
	private String privateIpAddress;
	private String publicIp;
	
	public AWSEC2ElasticIpTO() {
	
		/* No implementation required at the moment. Method for future use. */
	}
	
	public String getAllocationId() {
	
		return allocationId;
	}
	
	public String getAssociationId() {
	
		return associationId;
	}
	
	public String getDomain() {
	
		return domain;
	}
	
	public String getInstanceId() {
	
		return instanceId;
	}
	
	public String getNetworkInterfaceId() {
	
		return networkInterfaceId;
	}
	
	public String getNetworkInterfaceOwnerId() {
	
		return networkInterfaceOwnerId;
	}
	
	public String getPrivateIpAddress() {
	
		return privateIpAddress;
	}
	
	public String getPublicIp() {
	
		return publicIp;
	}
	
	public void setAllocationId(String allocationId) {
	
		this.allocationId = allocationId;
	}
	
	public void setAssociationId(String associationId) {
	
		this.associationId = associationId;
	}
	
	public void setDomain(String domain) {
	
		this.domain = domain;
	}
	
	public void setInstanceId(String instanceId) {
	
		this.instanceId = instanceId;
	}
	
	public void setNetworkInterfaceId(String networkInterfaceId) {
	
		this.networkInterfaceId = networkInterfaceId;
	}
	
	public void setNetworkInterfaceOwnerId(String networkInterfaceOwnerId) {
	
		this.networkInterfaceOwnerId = networkInterfaceOwnerId;
	}
	
	public void setPrivateIpAddress(String privateIpAddress) {
	
		this.privateIpAddress = privateIpAddress;
	}
	
	public void setPublicIp(String publicIp) {
	
		this.publicIp = publicIp;
	}
	
	@Override
	public String toString() {
	
		return "AWSEC2ElasticIpTO [publicIp=" + publicIp + ", domain=" + domain + ", instanceId=" + instanceId + "]";
	}
}
