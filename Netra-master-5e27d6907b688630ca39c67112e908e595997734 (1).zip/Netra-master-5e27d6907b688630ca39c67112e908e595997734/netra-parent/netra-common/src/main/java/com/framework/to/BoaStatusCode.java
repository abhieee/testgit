package com.framework.to;

import java.io.Serializable;

public class BoaStatusCode implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6177436739548619842L;
	private long urlcodeId;
	private long urlstauscode;
	
	public BoaStatusCode() {
	
		/* No implementation required at the moment. Method for future use. */
	}
	
	public long getUrlcodeId() {
	
		return urlcodeId;
	}
	
	public long getUrlstauscode() {
	
		return urlstauscode;
	}
	
	public void setUrlcodeId(long urlcodeId) {
	
		this.urlcodeId = urlcodeId;
	}
	
	public void setUrlstauscode(long urlstauscode) {
	
		this.urlstauscode = urlstauscode;
	}
}
