package com.framework.report;

import java.io.Serializable;

public class Hardware_summary implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int count_server;
	private String hw_status;
	
	public Hardware_summary() {
	
		/* No implementation required at the moment. Method for future use. */
	}
	
	public Hardware_summary(int count_server, String hw_status) {
	
		this.count_server = count_server;
		this.hw_status = hw_status;
	}
	
	public int getCount_server() {
	
		return count_server;
	}
	
	public void setCount_server(int count_server) {
	
		this.count_server = count_server;
	}
	
	public String getHw_status() {
	
		return hw_status;
	}
	
	public void setHw_status(String hw_status) {
	
		this.hw_status = hw_status;
	}
}
