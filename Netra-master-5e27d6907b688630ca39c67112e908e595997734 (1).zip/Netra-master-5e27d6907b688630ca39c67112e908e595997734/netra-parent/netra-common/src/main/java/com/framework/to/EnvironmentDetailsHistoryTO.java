/**
 *
 */
package com.framework.to;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @author TCS
 */
public class EnvironmentDetailsHistoryTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2221683464352230780L;
	private String harwareName;
	private Long mappedSoftwareId;
	private Long hardwareId;
	private List<Long> softwareId = new ArrayList<Long>();
	private Long environmentId;
	private Set<ReservationTO> reservationses = new HashSet<ReservationTO>(0);
	private String softwares;
	private List<SoftwareTO> softwareList = new ArrayList<SoftwareTO>();
	private EnvironmentTO environment;
	private Long platformId;
	private String platformName;
	
	public EnvironmentTO getEnvironment() {
	
		return environment;
	}
	
	public Long getEnvironmentId() {
	
		return environmentId;
	}
	
	public Long getHardwareId() {
	
		return hardwareId;
	}
	
	public String getHarwareName() {
	
		return harwareName;
	}
	
	public Long getMappedSoftwareId() {
	
		return mappedSoftwareId;
	}
	
	public Long getPlatformId() {
	
		return platformId;
	}
	
	public String getPlatformName() {
	
		return platformName;
	}
	
	public Set<ReservationTO> getReservationses() {
	
		return reservationses;
	}
	
	public List<Long> getSoftwareId() {
	
		return softwareId;
	}
	
	public List<SoftwareTO> getSoftwareList() {
	
		return softwareList;
	}
	
	public String getSoftwares() {
	
		return softwares;
	}
	
	public void setEnvironment(EnvironmentTO environment) {
	
		this.environment = environment;
	}
	
	public void setEnvironmentId(Long environmentId) {
	
		this.environmentId = environmentId;
	}
	
	public void setHardwareId(Long hardwareId) {
	
		this.hardwareId = hardwareId;
	}
	
	public void setHarwareName(String harwareName) {
	
		this.harwareName = harwareName;
	}
	
	public void setMappedSoftwareId(Long mappedSoftwareId) {
	
		this.mappedSoftwareId = mappedSoftwareId;
	}
	
	public void setPlatformId(Long platformId) {
	
		this.platformId = platformId;
	}
	
	public void setPlatformName(String platformName) {
	
		this.platformName = platformName;
	}
	
	public void setReservationses(Set<ReservationTO> reservationses) {
	
		this.reservationses = reservationses;
	}
	
	public void setSoftwareId(List<Long> softwareId) {
	
		this.softwareId = softwareId;
	}
	
	public void setSoftwareList(List<SoftwareTO> softwareList) {
	
		this.softwareList = softwareList;
	}
	
	public void setSoftwares(String softwares) {
	
		this.softwares = softwares;
	}
}
