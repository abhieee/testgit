package com.framework.to;

import java.io.Serializable;

public class DBMasterTo implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long Id = null;
	private String db_url = null;
	private String driverclassname = null;
	private String userName = null;
	private String db_name = null;
	private String password = null;
	
	public String getDb_name() {
	
		return db_name;
	}
	
	public String getDb_url() {
	
		return db_url;
	}
	
	public String getDriverclassname() {
	
		return driverclassname;
	}
	
	public Long getId() {
	
		return Id;
	}
	
	public String getPassword() {
	
		return password;
	}
	
	public String getUserName() {
	
		return userName;
	}
	
	public void setDb_name(String db_name) {
	
		this.db_name = db_name;
	}
	
	public void setDb_url(String db_url) {
	
		this.db_url = db_url;
	}
	
	public void setDriverclassname(String driverclassname) {
	
		this.driverclassname = driverclassname;
	}
	
	public void setId(Long id) {
	
		Id = id;
	}
	
	public void setPassword(String password) {
	
		this.password = password;
	}
	
	public void setUserName(String userName) {
	
		this.userName = userName;
	}
}
