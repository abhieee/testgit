package com.framework.puppet.to;

/**
 * This class declares the transfer object that carries user information across the application.
 *
 * @author TCS
 */
public class SoftwareListTO {
	
	private String appliname;
	private String uname;
	private String pwd;
	private String version;
	
	public String getAppliname() {
	
		return appliname;
	}
	
	public String getPwd() {
	
		return pwd;
	}
	
	public String getUname() {
	
		return uname;
	}
	
	public String getVersion() {
	
		return version;
	}
	
	public void setAppliname(String appliname) {
	
		this.appliname = appliname;
	}
	
	public void setPwd(String pwd) {
	
		this.pwd = pwd;
	}
	
	public void setUname(String uname) {
	
		this.uname = uname;
	}
	
	public void setVersion(String version) {
	
		this.version = version;
	}
}
