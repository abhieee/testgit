package com.framework.udeploy.to;

import java.io.Serializable;
import java.util.List;

/**
 * @author 849812
 */
public class UdeployReleaseActivityTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long activityId;
	private Long softwareId;
	private String activityName;
	private String applicationSpecificFlag;
	private String selectedVersion;
	private long selectedActivityId;
	private List<Long> definedActivities;
	private List<Long> udeployProcessSoftwareMapOrderedList = null;
	
	public Long getSoftwareId() {
	
		return softwareId;
	}
	
	public void setSoftwareId(Long softwareId) {
	
		this.softwareId = softwareId;
	}
	
	public Long getActivityId() {
	
		return activityId;
	}
	
	public String getActivityName() {
	
		return activityName;
	}
	
	public String getApplicationSpecificFlag() {
	
		return applicationSpecificFlag;
	}
	
	public List<Long> getDefinedActivities() {
	
		return definedActivities;
	}
	
	public long getSelectedActivityId() {
	
		return selectedActivityId;
	}
	
	public String getSelectedVersion() {
	
		return selectedVersion;
	}
	
	public List<Long> getUdeployProcessSoftwareMapOrderedList() {
	
		return udeployProcessSoftwareMapOrderedList;
	}
	
	public void setActivityId(Long activityId) {
	
		this.activityId = activityId;
	}
	
	public void setActivityName(String activityName) {
	
		this.activityName = activityName;
	}
	
	public void setApplicationSpecificFlag(String applicationSpecificFlag) {
	
		this.applicationSpecificFlag = applicationSpecificFlag;
	}
	
	public void setDefinedActivities(List<Long> definedActivities) {
	
		this.definedActivities = definedActivities;
	}
	
	public void setSelectedActivityId(long selectedActivityId) {
	
		this.selectedActivityId = selectedActivityId;
	}
	
	public void setSelectedVersion(String selectedVersion) {
	
		this.selectedVersion = selectedVersion;
	}
	
	public void setUdeployProcessSoftwareMapOrderedList(List<Long> udeployProcessSoftwareMapOrderedList) {
	
		this.udeployProcessSoftwareMapOrderedList = udeployProcessSoftwareMapOrderedList;
	}
}
