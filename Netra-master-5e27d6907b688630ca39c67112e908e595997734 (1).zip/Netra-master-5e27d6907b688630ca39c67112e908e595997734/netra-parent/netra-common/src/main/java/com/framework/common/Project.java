package com.framework.common;

public enum Project {
	AGILE("Agile"), WATERFALL("Waterfall");
	
	private String projectType;
	
	private Project(String s) {
	
		this.projectType = s;
	}
	
	public String getProjectType() {
	
		return projectType;
	}
}
