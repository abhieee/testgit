package com.framework.to;

public class ServicesMappingTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2954508651041418364L;
	private Long parentServiceId;
	private Long childServiceId;
	private Long executionOrder;
	private ServiceTO serviceTO;
	private String actionName;
	private boolean serviceSelectedFlag;
	private boolean access;
	
	public String getActionName() {
	
		return actionName;
	}
	
	public Long getChildServiceId() {
	
		return childServiceId;
	}
	
	public Long getExecutionOrder() {
	
		return executionOrder;
	}
	
	public Long getParentServiceId() {
	
		return parentServiceId;
	}
	
	public ServiceTO getServiceTO() {
	
		return serviceTO;
	}
	
	public boolean isAccess() {
	
		return access;
	}
	
	public boolean isServiceSelectedFlag() {
	
		return serviceSelectedFlag;
	}
	
	public void setAccess(boolean access) {
	
		this.access = access;
	}
	
	public void setActionName(String actionName) {
	
		this.actionName = actionName;
	}
	
	public void setChildServiceId(Long childServiceId) {
	
		this.childServiceId = childServiceId;
	}
	
	public void setExecutionOrder(Long executionOrder) {
	
		this.executionOrder = executionOrder;
	}
	
	public void setParentServiceId(Long parentServiceId) {
	
		this.parentServiceId = parentServiceId;
	}
	
	public void setServiceSelectedFlag(boolean serviceSelectedFlag) {
	
		this.serviceSelectedFlag = serviceSelectedFlag;
	}
	
	public void setServiceTO(ServiceTO serviceTO) {
	
		this.serviceTO = serviceTO;
	}
}