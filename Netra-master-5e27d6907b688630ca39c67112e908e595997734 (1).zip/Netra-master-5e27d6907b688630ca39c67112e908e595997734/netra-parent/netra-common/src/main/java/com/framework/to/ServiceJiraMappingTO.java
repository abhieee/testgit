package com.framework.to;

public class ServiceJiraMappingTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4509062300398672438L;
	private Long id;
	private String jira_issue;
	private long service_req_id;
	private String deployment_flag;
	
	public String getDeployment_flag() {
	
		return deployment_flag;
	}
	
	@Override
	public Long getId() {
	
		return id;
	}
	
	public String getJira_issue() {
	
		return jira_issue;
	}
	
	public long getService_req_id() {
	
		return service_req_id;
	}
	
	public void setDeployment_flag(String deployment_flag) {
	
		this.deployment_flag = deployment_flag;
	}
	
	@Override
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setJira_issue(String jira_issue) {
	
		this.jira_issue = jira_issue;
	}
	
	public void setService_req_id(long service_req_id) {
	
		this.service_req_id = service_req_id;
	}
}