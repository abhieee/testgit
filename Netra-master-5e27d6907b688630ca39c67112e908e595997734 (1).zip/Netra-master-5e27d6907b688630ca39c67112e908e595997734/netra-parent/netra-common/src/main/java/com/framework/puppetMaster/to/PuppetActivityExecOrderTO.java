package com.framework.puppetMaster.to;

import java.io.Serializable;

public class PuppetActivityExecOrderTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5995692700562433677L;
	private long activitiesExecutionId;
	private PuppetActivitySoftwareMappingTO puppetActivitySoftwareMappingTO;
	private PuppetActivitySoftwareMappingTO puppetActivitySoftwareMappingTOP;
	private long exeOrder;
	private long softwareId;
	
	public long getActivitiesExecutionId() {
	
		return activitiesExecutionId;
	}
	
	public long getExeOrder() {
	
		return exeOrder;
	}
	
	public PuppetActivitySoftwareMappingTO getPuppetActivitySoftwareMappingTO() {
	
		return puppetActivitySoftwareMappingTO;
	}
	
	public PuppetActivitySoftwareMappingTO getPuppetActivitySoftwareMappingTOP() {
	
		return puppetActivitySoftwareMappingTOP;
	}
	
	public long getSoftwareId() {
	
		return softwareId;
	}
	
	public void setActivitiesExecutionId(long activitiesExecutionId) {
	
		this.activitiesExecutionId = activitiesExecutionId;
	}
	
	public void setExeOrder(long exeOrder) {
	
		this.exeOrder = exeOrder;
	}
	
	public void setPuppetActivitySoftwareMappingTO(PuppetActivitySoftwareMappingTO puppetActivitySoftwareMappingTO) {
	
		this.puppetActivitySoftwareMappingTO = puppetActivitySoftwareMappingTO;
	}
	
	public void setPuppetActivitySoftwareMappingTOP(PuppetActivitySoftwareMappingTO puppetActivitySoftwareMappingTOP) {
	
		this.puppetActivitySoftwareMappingTOP = puppetActivitySoftwareMappingTOP;
	}
	
	public void setSoftwareId(long softwareId) {
	
		this.softwareId = softwareId;
	}
}
