package com.framework.report;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ReportRequestVO {
	
	private Map<String, Object> parameters = new HashMap<String, Object>(0);
	private String requestedReportFormat = null;
	private List<Long> selectedBusinessUnitNew = null;
	private List<Long> selectedProjectNew = null;
	private List<Long> selectedApplicationNew = null;
	private List<Long> selectedEnvironmentNew = null;
	private Long appId = null;
	private String selectedReportName = null;
	private Long userId = null;
	private String absoluteJasperPath = null;
	private String durationType;
	private String userName = null;
	
	public Map<String, Object> getParameters() {
	
		return parameters;
	}
	
	public void setParameters(Map<String, Object> parameters) {
	
		this.parameters = parameters;
	}
	
	public String getRequestedReportFormat() {
	
		return requestedReportFormat;
	}
	
	public void setRequestedReportFormat(String requestedReportFormat) {
	
		this.requestedReportFormat = requestedReportFormat;
	}
	
	public List<Long> getSelectedBusinessUnitNew() {
	
		return selectedBusinessUnitNew;
	}
	
	public void setSelectedBusinessUnitNew(List<Long> selectedBusinessUnitNew) {
	
		this.selectedBusinessUnitNew = selectedBusinessUnitNew;
	}
	
	public List<Long> getSelectedProjectNew() {
	
		return selectedProjectNew;
	}
	
	public void setSelectedProjectNew(List<Long> selectedProjectNew) {
	
		this.selectedProjectNew = selectedProjectNew;
	}
	
	public List<Long> getSelectedApplicationNew() {
	
		return selectedApplicationNew;
	}
	
	public void setSelectedApplicationNew(List<Long> selectedApplicationNew) {
	
		this.selectedApplicationNew = selectedApplicationNew;
	}
	
	public List<Long> getSelectedEnvironmentNew() {
	
		return selectedEnvironmentNew;
	}
	
	public void setSelectedEnvironmentNew(List<Long> selectedEnvironmentNew) {
	
		this.selectedEnvironmentNew = selectedEnvironmentNew;
	}
	
	public Long getAppId() {
	
		return appId;
	}
	
	public void setAppId(Long appId) {
	
		this.appId = appId;
	}
	
	public String getSelectedReportName() {
	
		return selectedReportName;
	}
	
	public void setSelectedReportName(String selectedReportName) {
	
		this.selectedReportName = selectedReportName;
	}
	
	public Long getUserId() {
	
		return userId;
	}
	
	public void setUserId(Long userId) {
	
		this.userId = userId;
	}
	
	public String getAbsoluteJasperPath() {
	
		return absoluteJasperPath;
	}
	
	public void setAbsoluteJasperPath(String absoluteJasperPath) {
	
		this.absoluteJasperPath = absoluteJasperPath;
	}
	
	public String getDurationType() {
	
		return durationType;
	}
	
	public void setDurationType(String durationType) {
	
		this.durationType = durationType;
	}
	
	public String getUserName() {
	
		return userName;
	}
	
	public void setUserName(String userName) {
	
		this.userName = userName;
	}
}
