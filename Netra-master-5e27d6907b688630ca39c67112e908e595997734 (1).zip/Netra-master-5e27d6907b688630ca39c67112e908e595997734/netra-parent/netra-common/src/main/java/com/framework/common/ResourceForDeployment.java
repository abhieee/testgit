package com.framework.common;

public enum ResourceForDeployment {
	SHARED_PATH("Shared Path"), NEXUS("Nexus Repository"), Repository("Repository");
	
	private String path;
	
	private ResourceForDeployment(String t) {
	
		this.path = t;
	}
	
	public String getPath() {
	
		return path;
	}
}
