package com.framework.to;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EnvMonitoringTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1539439004559054649L;
	private String environmentName;
	private String hostName;
	private String hostIP;
	private String hostID;
	private String status;
	private String jbossStatus;
	private String dbStatus;
	private String memoryStatus;
	private String networkstatus;
	private String isapp = "true";
	private String isdb = "true";
	Map<String, String> applicationStatus = new HashMap<String, String>();
	List<HashMap<String, String>> serverStatus = new ArrayList<HashMap<String, String>>();
	private String applicationsForServer = null;
	private String serverType;
	
	public String getApplicationsForServer() {
	
		return applicationsForServer;
	}
	
	public Map<String, String> getApplicationStatus() {
	
		return applicationStatus;
	}
	
	public String getDbStatus() {
	
		return dbStatus;
	}
	
	public String getEnvironmentName() {
	
		return environmentName;
	}
	
	public String getHostID() {
	
		return hostID;
	}
	
	public String getHostIP() {
	
		return hostIP;
	}
	
	public String getHostName() {
	
		return hostName;
	}
	
	public String getIsapp() {
	
		return isapp;
	}
	
	public String getIsdb() {
	
		return isdb;
	}
	
	public String getJbossStatus() {
	
		return jbossStatus;
	}
	
	public String getMemoryStatus() {
	
		return memoryStatus;
	}
	
	public String getNetworkstatus() {
	
		return networkstatus;
	}
	
	public List<HashMap<String, String>> getServerStatus() {
	
		return serverStatus;
	}
	
	public String getStatus() {
	
		return status;
	}
	
	public void setApplicationsForServer(String applicationsForServer) {
	
		this.applicationsForServer = applicationsForServer;
	}
	
	public void setApplicationStatus(Map<String, String> applicationStatus) {
	
		this.applicationStatus = applicationStatus;
	}
	
	public void setDbStatus(String dbStatus) {
	
		this.dbStatus = dbStatus;
	}
	
	public void setEnvironmentName(String environmentName) {
	
		this.environmentName = environmentName;
	}
	
	public void setHostID(String hostID) {
	
		this.hostID = hostID;
	}
	
	public void setHostIP(String hostIP) {
	
		this.hostIP = hostIP;
	}
	
	public void setHostName(String hostName) {
	
		this.hostName = hostName;
	}
	
	public void setIsapp(String isapp) {
	
		this.isapp = isapp;
	}
	
	public void setIsdb(String isdb) {
	
		this.isdb = isdb;
	}
	
	public void setJbossStatus(String jbossStatus) {
	
		this.jbossStatus = jbossStatus;
	}
	
	public void setMemoryStatus(String memoryStatus) {
	
		this.memoryStatus = memoryStatus;
	}
	
	public void setNetworkstatus(String networkstatus) {
	
		this.networkstatus = networkstatus;
	}
	
	public void setServerStatus(List<HashMap<String, String>> serverStatus) {
	
		this.serverStatus = serverStatus;
	}
	
	public void setStatus(String status) {
	
		this.status = status;
	}
	
	public String getServerType() {
	
		return serverType;
	}
	
	public void setServerType(String serverType) {
	
		this.serverType = serverType;
	}
}