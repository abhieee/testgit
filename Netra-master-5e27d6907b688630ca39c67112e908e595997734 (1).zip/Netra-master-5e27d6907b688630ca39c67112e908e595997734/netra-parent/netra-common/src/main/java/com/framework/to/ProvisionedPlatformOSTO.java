/**
 *
 */
package com.framework.to;

import java.io.Serializable;

/**
 * @author 460650
 */
public class ProvisionedPlatformOSTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3038939861794112513L;
	private int id;
	private String imageId;
	private String imageName;
	private Long provisionedPlatformId;
	
	public int getId() {
	
		return id;
	}
	
	public String getImageId() {
	
		return imageId;
	}
	
	public String getImageName() {
	
		return imageName;
	}
	
	public Long getProvisionedPlatformId() {
	
		return provisionedPlatformId;
	}
	
	public void setId(int id) {
	
		this.id = id;
	}
	
	public void setImageId(String imageId) {
	
		this.imageId = imageId;
	}
	
	public void setImageName(String imageName) {
	
		this.imageName = imageName;
	}
	
	public void setProvisionedPlatformId(Long provisionedPlatformId) {
	
		this.provisionedPlatformId = provisionedPlatformId;
	}
}
