package com.framework.to;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

public class BaoURLDataTo implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7736586274689238678L;
	private List<BaoURLDataTo> directoryList = null;
	private String revision1 = null;
	private String revision2 = null;
	private String directoryData = null;
	private String svnfileName = null;
	private Long Urlid = null;
	private String createdById;
	private Long modifiedbyId;
	private Date createdByDate;
	private Date modifiedbyDate;
	private Long status;
	private Timestamp urlTime;
	private Date svnDate = null;
	private String flagChart = null;
	private String directoryName = null;
	private Long directoryId = null;
	private String fileName;
	private String urlName;
	private Date chartDate = null;
	private Long urlstatusid;
	
	public BaoURLDataTo() {
	
		/* No implementation required at the moment. Method for future use. */
	}
	
	public Date getChartDate() {
	
		return chartDate;
	}
	
	public Date getCreatedByDate() {
	
		return createdByDate;
	}
	
	public String getCreatedById() {
	
		return createdById;
	}
	
	public String getDirectoryData() {
	
		return directoryData;
	}
	
	public Long getDirectoryId() {
	
		return directoryId;
	}
	
	public List<BaoURLDataTo> getDirectoryList() {
	
		return directoryList;
	}
	
	public String getDirectoryName() {
	
		return directoryName;
	}
	
	public String getFileName() {
	
		return fileName;
	}
	
	public String getFlagChart() {
	
		return flagChart;
	}
	
	public Date getModifiedbyDate() {
	
		return modifiedbyDate;
	}
	
	public Long getModifiedbyId() {
	
		return modifiedbyId;
	}
	
	public String getRevision1() {
	
		return revision1;
	}
	
	public String getRevision2() {
	
		return revision2;
	}
	
	public Long getStatus() {
	
		return status;
	}
	
	public Date getSvnDate() {
	
		return svnDate;
	}
	
	public String getSvnfileName() {
	
		return svnfileName;
	}
	
	public Long getUrlid() {
	
		return Urlid;
	}
	
	public String getUrlName() {
	
		return urlName;
	}
	
	public Long getUrlstatusid() {
	
		return urlstatusid;
	}
	
	public Date getUrlTime() {
	
		return urlTime;
	}
	
	public void setChartDate(Date chartDate) {
	
		this.chartDate = chartDate;
	}
	
	public void setCreatedByDate(Date createdByDate) {
	
		this.createdByDate = createdByDate;
	}
	
	public void setCreatedById(String createdById) {
	
		this.createdById = createdById;
	}
	
	public void setDirectoryData(String directoryData) {
	
		this.directoryData = directoryData;
	}
	
	public void setDirectoryId(Long directoryId) {
	
		this.directoryId = directoryId;
	}
	
	public void setDirectoryList(List<BaoURLDataTo> directoryList) {
	
		this.directoryList = directoryList;
	}
	
	public void setDirectoryName(String directoryName) {
	
		this.directoryName = directoryName;
	}
	
	public void setFileName(String fileName) {
	
		this.fileName = fileName;
	}
	
	public void setFlagChart(String flagChart) {
	
		this.flagChart = flagChart;
	}
	
	public void setModifiedbyDate(Date modifiedbyDate) {
	
		this.modifiedbyDate = modifiedbyDate;
	}
	
	public void setModifiedbyId(Long modifiedbyId) {
	
		this.modifiedbyId = modifiedbyId;
	}
	
	public void setRevision1(String revision1) {
	
		this.revision1 = revision1;
	}
	
	public void setRevision2(String revision2) {
	
		this.revision2 = revision2;
	}
	
	public void setStatus(Long status) {
	
		this.status = status;
	}
	
	public void setSvnDate(Date svnDate) {
	
		this.svnDate = svnDate;
	}
	
	public void setSvnfileName(String svnfileName) {
	
		this.svnfileName = svnfileName;
	}
	
	public void setUrlid(Long urlid) {
	
		Urlid = urlid;
	}
	
	public void setUrlName(String urlName) {
	
		this.urlName = urlName;
	}
	
	public void setUrlstatusid(Long urlstatusid) {
	
		this.urlstatusid = urlstatusid;
	}
	
	public void setUrlTime(Timestamp urlTime) {
	
		this.urlTime = urlTime;
	}
}
