/**
 *
 */
package com.framework.to;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @author 460650
 */
public class CAReleaseActivityTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6593270206740753429L;
	private Long activityId;
	private Long softwareId;
	private Long processId;
	private String activityName;
	private String applicationSpecificFlag;
	private String selectedVersion;
	private long SelectedActivityId;
	private List<Long> DefinedActivities;
	private List<Long> nolioProcessSoftwareMapOrderedList = new ArrayList(0);
	
	public Long getActivityId() {
	
		return activityId;
	}
	
	public String getActivityName() {
	
		return activityName;
	}
	
	public String getApplicationSpecificFlag() {
	
		return applicationSpecificFlag;
	}
	
	public List<Long> getDefinedActivities() {
	
		return DefinedActivities;
	}
	
	public List<Long> getNolioProcessSoftwareMapOrderedList() {
	
		return nolioProcessSoftwareMapOrderedList;
	}
	
	public Long getProcessId() {
	
		return processId;
	}
	
	public long getSelectedActivityId() {
	
		return SelectedActivityId;
	}
	
	public String getSelectedVersion() {
	
		return selectedVersion;
	}
	
	public Long getSoftwareId() {
	
		return softwareId;
	}
	
	public void setActivityId(Long activityId) {
	
		this.activityId = activityId;
	}
	
	public void setActivityName(String activityName) {
	
		this.activityName = activityName;
	}
	
	public void setApplicationSpecificFlag(String applicationSpecificFlag) {
	
		this.applicationSpecificFlag = applicationSpecificFlag;
	}
	
	public void setDefinedActivities(List<Long> definedActivities) {
	
		DefinedActivities = definedActivities;
	}
	
	public void setNolioProcessSoftwareMapOrderedList(List<Long> nolioProcessSoftwareMapOrderedList) {
	
		this.nolioProcessSoftwareMapOrderedList = nolioProcessSoftwareMapOrderedList;
	}
	
	public void setProcessId(Long processId) {
	
		this.processId = processId;
	}
	
	public void setSelectedActivityId(long selectedActivityId) {
	
		SelectedActivityId = selectedActivityId;
	}
	
	public void setSelectedVersion(String selectedVersion) {
	
		this.selectedVersion = selectedVersion;
	}
	
	public void setSoftwareId(Long softwareId) {
	
		this.softwareId = softwareId;
	}
}
