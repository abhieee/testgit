package com.framework.common;

import java.util.regex.Pattern;

/**
 * @author TCS
 */
public interface CMMConstants {
	
	interface Presentation {
		
		String LOGGED_IN_USER_ACCESS = "UserAccess";
		String LOGGED_IN_USER_USER_GROUP = "UserGroup";
		String USER_APPLICATION = "Application";
		String LOGGED_IN_USER_SESSION_KEY = "LoggedInUser";
		String WF_REQUEST_ID_SESSION_KEY = "wfRequestId";
		String WF_DETAILS_SESSION_KEY = "wfDetails";
		String PROJECTS_IN_BUSINESSUNIT_SESSION_KEY = "BusinessUnitsForProjects";
		String APPLICATIONS_IN_PROJECTS_SESSION_KEY = "ProjectsForApplications";
		String SOFTWARE_SESSION_KEY = "SoftwareForTEMS";
		String TOPOLOGIES_IN_DOMAINS_SESSION_KEY = "DomainsForTopologies";
		String ENVIRONMENT_RESERVATIONS_FOR_USER_SESSION_KEY = "ReservationsForUser";
		String ACTION_DETAILS_SESSION_KEY = "ActionDetailsForReservation";
		String FAILURE_TYPE_SESSION_KEY = "FailureTypeForReservation";
		String DEVICES_IN_DOMAINS_SESSION_KEY = "DevicesForDomain";
		String DEVICES_IN_DOMAINS_SESSION_KEY1 = "DevicesForDomain1";
		String DEVICE_DETAILS_SESSION_KEY = "DevicesForTopology";
		String DEVICE_DETAILS_FORM_KEY = "DeviceDetailsForForm";
		String DEVICE_DETAILS_FORM_KEY1 = "DeviceDetailsForForm1";
		String TOPOLOGY_DETAILS_FORM_KEY = "TopologyDetailsForForm";
		String PREVIOUS_RESERVATION_SELECTION_SESSION_KEY = "PreviousReservationSelection";
		String WARNING_FOR_CONFLICTING_RESERVATION_SESSION_KEY = "WarningForConflicting";
		String FAILURE_TYPE_SESSION_KEY_DISRUPTIVE = "ListofDisruptiveFailureForReservation";
		String RESERVATION_CHECKLIST_AGREEMENT_SESSION_KEY = "ReservationChecklistAgreed";
		String DEVICECONFIGTO_TO_UPDATE = "DeviceConfigTOtoUpdate";
		String RESERVATION_FAILURE_FORM = "FailuresForm";
		String TOPOLOGYID_FOR_FAILUREFORM = "topologyId";
		String THEME_SESSION_KEY = "ThemeName";
		String STANDARD_THEME = "Standard";
		String COMPACT_THEME = "Compact";
		String PLATFORM_STATUS_LIST = "PlatformStatusList";
		String BUSINESS_STATUS_LIST = "BusinessStatusList";
		String TEMPLATE_STATUS_LIST = "TemplateStatusList";
		String ROLE_STATUS_LIST = "RoleStatusList";
		String APPLICATION_PROFILE_STATUS_LIST = "ApplicationProfileStatusList";
		String APPLICATION_RELEASE_STATUS_LIST = "ApplicationReleaseStatusList";
		String SERVICES_STATUS_LIST = "ServicesStatusList";
		String PROFILES_STATUS_LIST = "ProfilesStatusList";
		String QTP_SCRIPT_FILE_PATTERN = "*.vbs";
		String ALL_BU_OPTION_FOR_LOGGED_IN_USER = "allOption";
		String LOGGED_IN_USER_CLIENTID = "cID";
		String LOGGED_IN_USER_BULIST = "cList";
		String LOGGED_IN_USER_CLIENTID_LIST = "clientIdList";
		Long PLATFORM_TEMPLATE_STATUS = 179L;
		String MACHINE_TYPE = "Virtual - VMware Bare Metal";
		String DOCKER_USERNAME = "root";
		String DOCKER_PASSWORD = "tcs#1234";
		String DOCKER_PORT = "8081";
		
		interface Reporting {
			
			String PDF_REPORT_EXTENSION = ".pdf";
			String JASPER_REPORTS_LOCATION = "/WEB-INF/jasper/";
			String JASPER_REPORTS_EXTENSION = ".jasper";
			String DOMAIN_UTILIZATION_REPORT_NAME = "DeviceUtilizationForDomainReport";
			String ENVIRONMENT_APPLICATION_DETAILS_REPORT_NAME = "Application Details";
			String ENVIRONMENT_RESERVATION_DETAILS_REPORT_NAME = "Environment Reservation Details";
			String ENVIRONMENT_USER_STATISTICS_REPORT_NAME = "User Statistics";
			String CODE_ANALYSIS_REPORT_NAME = "Code Analysis";
			String HARDWARE_ENVIRONMENT_DETAILS_REPORT_NAME = "Hardware Environment Details";
			String SOFTWARE_ENVIRONMENT_DETAILS_REPORT_NAME = "Software Environment Details";
			String ENVIRONMENT_DETAILS_REPORT_NAME = "Environment Details report";
			String TEST_EXECUTION_REPORT_NAME = "Test Execution report";
			String ENVIRONMENT_RESERVATION_DETAILS_DURATION_WEEKLY = "Weekly";
			String ENVIRONMENT_RESERVATION_DETAILS_DURATION_MONTHLY = "Monthly";
			String ENVIRONMENT_RESERVATION_DETAILS_DURATION_YEARLY = "Yearly";
			String ENVIRONMENT_RESERVATION_DETAILS_MONTH_JANUARY = "January";
			String ENVIRONMENT_RESERVATION_DETAILS_MONTH_FEBRUARY = "February";
			String ENVIRONMENT_RESERVATION_DETAILS_MONTH_MARCH = "March";
			String ENVIRONMENT_RESERVATION_DETAILS_MONTH_APRIL = "April";
			String ENVIRONMENT_RESERVATION_DETAILS_MONTH_MAY = "May";
			String ENVIRONMENT_RESERVATION_DETAILS_MONTH_JUNE = "June";
			String ENVIRONMENT_RESERVATION_DETAILS_MONTH_JULY = "July";
			String ENVIRONMENT_RESERVATION_DETAILS_MONTH_AUGUST = "August";
			String ENVIRONMENT_RESERVATION_DETAILS_MONTH_SEPTEMBER = "September";
			String ENVIRONMENT_RESERVATION_DETAILS_MONTH_OCTOBER = "October";
			String ENVIRONMENT_RESERVATION_DETAILS_MONTH_NOVEMBER = "November";
			String ENVIRONMENT_RESERVATION_DETAILS_MONTH_DECEMBER = "December";
			String ENVIRONMENT_RESERVATION_DETAILS_YEAR_2013 = "2013";
			String ENVIRONMENT_RESERVATION_DETAILS_YEAR_2014 = "2014";
			String ENVIRONMENT_RESERVATION_DETAILS_YEAR_2015 = "2015";
			String ENVIRONMENT_RESERVATION_DETAILS_YEAR_2016 = "2016";
			String ENVIRONMENT_RESERVATION_DETAILS_FORMAT_ACROBAT = "Acrobat File (PDF)";
			String ENVIRONMENT_RESERVATION_DETAILS_FORMAT_MSEXCEL = "Microsoft Excel format (XLS)";
			String PERFECTO_REPORT_FORMAT_PDF = "PDF";
			String PERFECTO_REPORT_FORMAT_CSV = "CSV";
			String PERFECTO_REPORT_FORMAT_XML = "XML";
			String PERFECTO_REPORT_FORMAT_HTML = "HTML";
			String DELETE_ENVIRONMENT = "delete from EnvironmentTO as e";
			String QUERY_ENVIRONMENT_CHANGE_LOG_REPORT_VO_DATA = "select app_client.name as bu_name, e.environmentName as env_name, env_vm_det.vmName as vm_name, env_vm_det.ip as vm_ip, soft_det.name as sw_name, app.appName as app_name, proj.name as proj_name, app_rel.name as release_name, app_rel.description as release_desc, app_rel.releaseTime as release_time, app_rel.initiatedBy as initiated_by  from EnvironmentTO as e  left join e.environmentDetails as env_det  left join e.environmentVmDet as env_vm_det  left join e.environmentApplicationTO as env_app  left join env_det.softwareConfig as sof_conf_det  left join sof_conf_det.software as soft_det left join env_app.applicationTO as app  left join app.projectTO as proj  left join app.businessUnitTO as app_client  left join env_app.applicationReleaseTO as app_rel ";
			String QUERY_ENVIRONMENT_RESV_SUMMARY_ANNUAL_REPORT = "select distinct app_client.name as bu_name, e.environmentName as env_name, e.id as env_id, app.appName as app_name, proj.name as proj_name from EnvironmentTO as e  left join e.environmentApplicationTO as env_app  left join env_app.applicationTO as app  left join app.projectTO as proj  left join app.businessUnitTO as app_client  left join e.reservationses as r";
			String QUERY_ENVIRONMENT_SNAPSHOT_REPORT_VO_DATA = "select app_client.name as bu_name, e.environmentName as env_name, env_vm_det.vmName as vm_name, env_vm_det.ip as vm_ip,  soft_det.name as sw_name, app.appName as app_name,  proj.name as proj_name  from EnvironmentTO as e  left join e.environmentDetails as env_det  left join e.environmentVmDet as env_vm_det  left join e.environmentApplicationTO as env_app  left join env_det.softwareConfig as sof_conf_det  left join sof_conf_det.software as soft_det left join env_app.applicationTO as app  left join app.projectTO as proj  left join app.businessUnitTO as app_client ";
			String QUERY_APPLICATION_DETAILS_REPORT = "select a.appName as app_name, a.description as descp,  app_proj.name as proj_name,  app_user_grp.name as app_support, tstPhase.name as testing_phase, envType.typeValue as env_name,  user_det.name as contact_det  from ApplicationTO as a  left join a.envAppTO as app_env  left join app_env.environmentTO as app_env_name left join app_env_name.envTypeTO as envType left join a.userGroups as app_user_grp  left join app_user_grp.userGroupDetailses as user_grp_det  left join user_grp_det.users as user_det  left join a.projectTO as app_proj  left join a.applicationReleasePhase as appPhase left join appPhase.testingPhase as tstPhase where a.status=" + CMMConstants.Framework.Entity.APPLICATION_AVAILABLE;
			String QUERY_ENVIRONMENT_RESERVATION_DETAIL_REPORT = "select app_client.name as bu_name, e.environmentName as env_name,  env_vm_det.vmName as vm_name,  env_vm_det.ip as vm_ip,  soft_det.name as sw_name, app.appName as app_name,  proj.name as proj_name,  resv_user.name as resv_user,  resv_status.statusDesc as resv_status,  env_resv.startTime as start_time,  env_resv.endTime as end_time,  env_resv.comments as comments,  case env_resv.disruptive when 'S' then 'Shared' when 'L' then 'Locked' when 'A' then 'Available' when 'D' then 'Disruptive' else 'N/A' end as avail_status  from EnvironmentTO as e  left join e.environmentDetails as env_det  left join e.environmentVmDet as env_vm_det  left join e.environmentApplicationTO as env_app  left join env_det.softwareConfig as sof_conf_det  left join sof_conf_det.software as soft_det left join env_app.applicationTO as app  left join app.projectTO as proj  left join app.businessUnitTO as app_client  left join env_app.environmentReservationTO as env_app_resv  left join e.reservationses as env_resv  left join env_resv.status as resv_status  left join env_resv.users as resv_user ";
			String QUERY_USER_STATISTICS_REPORT_VO_DATA = "select distinct u.id id, u.name name, u.fullname fullname, r.name role,  u.CREATED_DATE created_date,  s.status_desc status_desc from users u  left outer join status s on u.status = s.id  inner join userprivileges up on u.id = up.id  left outer join roles r on r.id = up.roleId  left outer join user_group_details ud on u.id=ud.user_id  left outer join user_groups ug on ug.id=ud.group_id  left outer join applications a on a.User_grp_id= ug.id ";
			/* Saumya,Start */
			String HARDWARE_ENVIRONMENT_DETAILS_REPORT = "select hardwareDet.ip as ip, hardwareDet.hostName as hostName, e.environmentName as environmentName, app.appName as applicationName from EnvironmentTO as e left join e.environmentDetails as env_det left join e.environmentApplicationTO as env_app left join env_det.provisionedMachine as hardwareDet left join env_app.applicationTO as app where hardwareDet.ip is not null and hardwareDet.hostName is not null and length(trim(hardwareDet.ip)) <> 0 group by hardwareDet.ip , hardwareDet.hostName , e.environmentName , app.appName ";
			String HARDWARE_SUMMARY_QUERY = "select count(*)  count_server,'TAGGED' hw_status  from provisioned_machine where id  in  (select distinct provisioned_machine_tmplt_id from environment_details where provisioned_machine_tmplt_id is not null)  and provisioned_status='AVAILABLE'  union  select count(*) count_server,'UNTAGGED' hw_status from provisioned_machine where id not in  (select distinct provisioned_machine_tmplt_id from environment_details where provisioned_machine_tmplt_id is not null)  and provisioned_status='AVAILABLE' ";
			String UNTAGGED_SERVER_DETAILS = "select distinct prov_mac.ip ip, prov_mac.hostName hostName  from provisioned_machine prov_mac  where prov_mac.id not in  (select distinct ed.provisioned_machine_tmplt_id from environment_details ed where ed.provisioned_machine_tmplt_id is not null)  and prov_mac.provisioned_status = 'AVAILABLE' ";
			String YEARLY_RESERVATION = "SELECT e.environment_Name,concat(r.actionRemark,'  ', Date(r.starttime),'  ',Date(r.endtime),'  ', u.fullname) res,r.starttime , DATE_FORMAT(r.starttime,'%b-%y') res_month,WEEK(r.starttime, 5) - WEEK(DATE_SUB(r.starttime, INTERVAL DAYOFMONTH(r.starttime) - 1 DAY), 5) + 1  res_week, CASE r.disruptive WHEN 'L' THEN 'Locked' WHEN 'S' THEN 'Shared' WHEN 'A' then 'Available' ELSE 'Disruptive' END AS res_mode, t.type_name FROM environments e,reservation r,users u,tems_testing_type t  where e.id = r.environment_id  and r.userid = u.id  and r.Testing_type = t.type_id and year(r.starttime) = :year order by starttime,environment_name ";
			/* Saumya,End */
			String SOFTWARE_ENVIRONMENT_DETAILS_REPORT = "select  s.name as name, e.environmentName as environmentName, a.appName as applicationName  from EnvironmentTO as e, EnvironmentDetailsTO as d, SoftwareTO as s, ApplicationTO as a, EnvironmentApplicationTO as j where e.id = j.environmentTO.id and d.environment.id = e.id and d.mappedSoftwareId = s.id and a.id = j.applicationTO.id  and s.name is not null  and length(trim(s.name))!=0  group by s.name , e.environmentName , a.appName ";
			String SOFTWARE_SUMMARY_QUERY = "select count(*) software_count,'TAGGED' status from software where id in  (select software_id from environment_details e)  union  select count(*) software_count, 'UNTAGGED' status from software where id not in  (select software_id from environment_details e) ";
			String UNTAGGED_SOFTWARE_DETAILS = "select name as software_name, 'UNTAGGED' as status  from SoftwareTO where id not in  (select distinct mappedSoftwareId  from EnvironmentDetailsTO as e)";
			String QUERY_BUILD_DEF_FOR_RELEASE = "select buildDef.id as id, buildDef.buildName as buildName  from ApplicationReleaseBuildTO as relBuild  inner join relBuild.buildToolDefinitionTO as buildDef where relBuild.applicationReleaseId = ";
			String QUERY_BUILD_REL_MAP = "select relBuild.id as id from ApplicationReleaseBuildTO as relBuild where relBuild.applicationReleaseId =? and relBuild.buildToolDefinitionId=? ";
			String QUERY_REL_DETAIL_FROM_REQUEST = "select rel.name as relName,app.appName as appName from ApplicationReleaseTO as rel inner join rel.applicationTO as app  where rel.id =?";
			String QUERY_DETAIL_FROM_REQUEST = "SELECT bu.name as buName,project.name as projName,rel.name as relName,app.appName as appName,env.environmentName as envName,user.name as userName,sreq.createdByDate as completionDate,bu.clientId as clientId,project.id as projId,app.id as appId,res.startTime as startTime,res.endTime as endTime from TestExecutionResultsTO as res inner join res.serviceRequestTO as sreq inner join res.releaseTO as rel inner join rel.applicationTO as app inner join sreq.environmentTO as env inner join sreq.userTO as user inner join app.projectTO as project inner join app.businessUnitTO as bu where sreq.id=?";
			String ENVIRONMENT_CHANGE_LOG_DETAILS = " SELECT e.environmentName as environment_name, e.createdByDate as created_date, u.name as created_by, pm.hostName as hostname , pm.ip as ip, s.name as software , a.appName as application_name, c.name as business_unit, p.name as project, ar.name as release_name  from EnvironmentTO as e  inner join e.environmentDetails  as env_det  inner join e.environmentApplicationTO as env_app  left join e.usersTO as u  left join env_det.provisionedMachine as pm  left join env_det.softwareConfig as sof_conf_det  left join sof_conf_det.software as s  left join env_app.applicationTO as a  left join a.businessUnitTO as c  left join a.projectTO as p  left join env_app.applicationReleaseTO as ar  where e.environmentName is not null ";
			String ENVIRONMENT_CHANGELOG_REPORT_NAME = "Environment Change Log Report";
			String ENVIRONMENT_SNAPSHOT_REPORT_NAME = "Environment Snapshot Report";
			
			interface Color_Code {
				
				String GREEN = "#006400";
				String RED = "#FF0000 ";
				String BLUE = "#0000FF";
				String PURPLE = "#80699B";
			}
		}
	}
	
	interface Framework {
		
		String USER_SOURCE_TEMS = "TEMS";
		String USER_SOURCE_LDAP = "LDAP";
		String ROOT_CONFIG_FILE = "/config.xml";
		String SECURITY_CONFIG_NAMESPACE_PREFIX = "security.roles.";
		String RESERVATION_CHECKLIST_CONFIG_NAMESPACE_PREFIX = "makeReservation.checklist.message";
		String RESERVATION_FAILURE_TYPE_CONFIG_NAMESPACE_PREFIX = "cmmweb.failuretypes.";
		String VSD_ROOT_FOLDER_CONFIG_KEY = "cmmweb.vsd.rootFolder";
		String TEMPLATES_CONFIG_NAMESPACE = "cmmweb.template.";
		String TEMPLATES_FOLDER_CONFIG_KEY = TEMPLATES_CONFIG_NAMESPACE + "rootFolder";
		String EXTERNAL_SECURITY_CONFIG_NAMESPACE = "cmmext.security.";
		String ENABLE_DBSECURITY_KEY = "enable";
		String STATUSLOG_DATASTORE_PREFIX = "Datastore: ";
		String STATUSLOG_PARSER_PREFIX = "Parse: Line ";
		Pattern EMAIL_VALIDATOR_PATTERN = Pattern.compile("\\b(^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@([A-Za-z0-9-])+(\\.[A-Za-z0-9-]+)*((\\.[A-Za-z0-9]{2,})|(\\.[A-Za-z0-9]{2,}\\.[A-Za-z0-9]{2,}))$)\\b");
		Pattern RELEASE_VALIDATOR_PATTERN = Pattern.compile("\\bRel [H-Z]\\b");
		Pattern UCB_VALIDATOR_PATTERN = Pattern.compile("\\bUCB\\d{4}\\b");
		Pattern TCR_VALIDATOR_PATTERN = Pattern.compile("\\bTCR\\d{4}\\b");
		String DATE_FORMAT_PATTERNS[] = { "dd/MM/yyyy", "dd-MMM-yy", "yyyy-MM-dd", "MM/dd/yyyy" };
		String DATE_DISPLAY_FORMAT = "dd/MM/yy HH:mm";
		String DATE_INPUT_FORMAT = "dd/MM/yyyy";
		String NOT_APPLICABLE = "NA";
		String MAIL_SUCCESS = "Mail Success";
		String MAIL_NOT_CONFIGURED = "Mail Not Configured";
		/**
		 * If dropdown selected item is 'All' then its value is 0.
		 */
		long DROPDOWN_SELECTED_VALUE_ALL = 0L;
		
		interface Config {
			
			String FAILURE_TYPES = "Type";
			String FAILURE_LABELS = "labels.";
			String LABELS_TYPE = ".type";
			String STC2 = "STC2";
			String STC3 = "STC3";
			String TEST_ONLY = "Test Only";
			String LINE_DEFECT = "Live";
			String INSCOPE = "Scope Change";
		}
		
		interface Monitoring {
			
			String OUTPUT = "output";
			String FILTER = "filter";
			String HOST_ID = "hostid";
			String APPLICATION = "application";
			String HOST_IDS = "hostids";
			String HOST_ID_NAME = "[hostID.name]";
			String SELECT_APPLICATIONS = "selectApplications";
			String GROUP_ID = "groupid";
			String MSG_ITEM = "No items found on Zabbix Server";
			String WITH_TRIGGERS = "with_triggers";
			String ITEM_ID = "itemids";
			String TIME_FROM = "time_from";
			String TIME_TILL = "time_till";
			String HISTORY = "history";
			String SUCCESS = "success";
			String FAILURE = "failure";
			String TEMPLATE_IDS = "templateids";
			String SORTORDER = "sortorder";
			String CLOCK = "clock";
			String SORTFIELD = "sortfield";
			String APPLICATION_IDS = "applicationids";
			String SEVERITY = "severity";
			String APPLICATION_LOAD_ENV = "ApplicationEnvLoadDetails";
			String HOST_NAME = "{HOST.NAME}";
			String MON_THRESHOLD = "MonitoringThreshold";
			String COLOR = "color";
			String DURATION = "duration";
			String TRIGGER = "trigger";
		}
		
		interface TopologyStatus {
			
			String AVAILABLE = "Available";
			String LOCKED = "Locked";
			String RESERVED = "Reserved";
			String ARCHIVED = "Archived";
			String PURGED = "Purged";
		}
		
		interface ReservationStatus {
			
			String DISRUPTIVE = "Disruptive";
			String NORMAL = "Normal";
			String LOCKED = "Locked";
			String SHARED = "Shared";
			String NON_DISRUPTIVE = "Non-disruptive";
			String RESERVATION_DISRUPTIVE = "D";
			String RESERVATION_SHARED = "S";
			String RESERVATION_MAX_COUNT = "SHARED_RESERVATION_COUNT";
			String ENVIRONMENT_RESERVED = "A";
			String RESERVATION_LOCKED = "L";
		}
		
		interface Entity {
			
			long USER = 1;
			long ENVIRONMENT = 2;
			long APPLICATION_PROFILE = 10;
			long APPLICATION_RELEASE = 12L;
			String RELEASE_TYPE = "18";
			long USER_STATUS_ACTIVE = 11;
			long USER_STATUS_INACTIVE = 12;
			long HARDWARE_STATUS_ACTIVE = 71;
			long HARDWARE_STATUS_INACTIVE = 72;
			long RESERVATION_STATUS_INACTIVE = 82L;
			long RESERVATION_STATUS_REJECTED = 85L;
			long PROJECT = 3;
			long BUSINESS = 4;
			long APPLICATION = 5;
			long TEMPLATE = 20;
			long ROLE = 19;
			long SUPER_CLIENT = 0L;
			long SERVICES = 13;
			long PROJECT_STATUS_EXISTING = 31L;
			long APPLICATION_PROFILE_ACTIVE = 101L;
			long APPLICATION_PROFILE_INACTIVE = 102L;
			long APPLICATION_RELEASE_ACTIVE = 121L;
			long APPLICATION_RELEASE_INACTIVE = 122L;
			long BUSINESS_ACTIVE = 41L;
			long BUSINESS_INACTIVE = 42L;
			long SERVICES_ACTIVE = 123L;
			long SERVICES_INACTIVE = 124L;
			long APPLICATION_AVAILABLE = 51L;
			long ENVIRONMENT_AVAILABLE = 21L;
			long ENVIRONMENT_REQUEST_PENDING = 25L;
			long ENVIRONMENT_REQUEST_REJECTED = 26L;
			long ENVIRONMENT_STATUS_INVALID = 27L;
			long PROFILES = 15;
			long SOFTWARES = 6;
			long SOFTWARES_AVAILABLE = 61;
			long SOFTWARES_UNAVAILABLE = 62;
			long HARDWARES = 7;
			long HARDWARES_AVAILABLE = 71;
			long HARDWARES_UNAVAILABLE = 72;
			long PROFILES_ACTIVE = 151;
			long PROFILES_INACTIVE = 152;
			long ENVIRONMENT_STATUS_AVAILABLE = 21L;
			long ENVIRONMENT_STATUS_UNDERIMPLEMENTATION = 23L;
			long ENVIRONMENT_STATUS_DECOMMISSIONED = 28L;
			long TESTING_PHASE_UNIT = 1L;
			long TESTING_PHASE_SIT = 2L;
			long ENVIRONMENT_STATUS_UNAVAILABLE = 22L;
			long TESTING_TYPE_FUNCTIONAL = 2L;
			long RESERVATION_STATUS_APPROVED = 81L;
			long TESTING_TYPE_REGRESSION = 1L;
			long RESERVATION_STATUS_PENDING = 84L;
			long SERVICE_REQUEST_PENDING_APPROVAL = 141L;
			long SERVICE_REQUEST_UNDER_IMPLEMENTATION = 142L;
			long SERVICE_REQUEST_STATUS_COMPLETED = 143L;
			long SERVICE_REQUEST_NOT_STARTED = 145L;
			long SERVICE_REQUEST_SKIPPED = 146L;
			long SERVICE_REQUEST_NOT_SUBMITTED = 147L;
			long APPLICATION_RELEASE_MAJOR = 173L;
			long APPLICATION_RELEASE_MINOR = 174L;
			long RESERVATION_LIMIT = 10L;
			long RESERVATION_STATUS_CONFLICTING = 83L;
			long ROLE_STATUS_ACTIVE = 175;
			long ROLE_STATUS_INACTIVE = 176L;
			long RESERVATION = 8;
			long RESERVATION_ISCONFLICTING = 1L;
			Long RESERVATION_UPDATEDFORCONFLICTS = 87L;
			Long RESERVATION_UPDATION_IN_CONFLICT = 88L;
			long RESERVATION_STATUS_UPDATED = 86L;
			long DOCKER_STATUS_ACTIVE = 189L;
			long DOCKER_STATUS_INACTIVE = 190L;
			String QUARTER1 = "Q1";
			String QUARTER2 = "Q2";
			String QUARTER3 = "Q3";
			String QUARTER4 = "Q4";
			int DAY1 = 1;
			int MONTH3 = 3;
			int MONTH6 = 6;
			int MONTH9 = 9;
			int MONTH12 = 11;
			int Q1 = 1;
			int Q2 = 2;
			int Q3 = 3;
			int Q4 = 4;
		}
		
		interface ServiceRequestStatus {
			
			String SERVICE_REQUEST_COMPLETED = "C";
			String SERVICE_REQUEST_ERROR = "E";
			String SERVICE_REQUEST_ACTIVE = "Y";
			String SERVICE_REQUEST_REJECTED = "R";
		}
		
		interface ServiceFlag {
			
			String SUBSERVICE_FLAG_Y = "Y";
			String SERVICE_FLAG_Y = "Y";
			String SERVICE_FLAG_N = "N";
			String LIFECYCLE_FLAG = "Y";
			String INSTALLATION_REQUIRED_FLAG = "Y";
			String MONITORING_INSTALLED_SUCCESS = "I";
		}
		
		interface PipelineRequest {
			
			String PIPELINE_REQ_FLAG = "Y";
		}
		
		interface WorkFlowStatus {
			
			long WORKFLOW_APPROVED = 4L;
			String AUTO_REJECTED = "Auto Rejected";
			String PENDING = "Pending";
		}
		
		interface Service {
			
			long CREATE_ENVIRONMENT_SERVICE_ID = 1L;
			long DATABASE_REFRESH_SERVICE_ID = 2L;
			long VM_RECONFIGURATION_SERVICE_ID = 3L;
			long MAKE_RESERVATION_SERVICE = 4L;
			long APPLICATION_DEPLOYMENT_SERVICE = 5L;
			long TEST_EXECUTION_SERVICE_ID = 6L;
			long APPLICATION_RELEASE_ROLLBACK_SERVICE_ID = 7L;
			long BUILD_AND_PROMOTE_SERVICE_ID = 8L;
			long RESTART_SERVER_SERVICE_ID = 9L;
			long APPLICATION_UNDEPLOYMENT_SERVICE_ID = 10L;
			long EC2_CONFIGURATION_SERVICE_ID = 11L;
			long CREATE_MULTIPLE_ENVIRONMENT_SERVICE_ID = 12L;
			long AGENT_DEPLOYMENT_SERVICE_ID = 13L;
			long BUILD_SERVICE_ID = 15L;
			long SOFTWARE_INSTALLATION_SERVICE_ID = 16L;
			long DEPLOYMENT_PIPELINE_SERVICE_ID = 17L;
			long CODE_DEPLOYMENT_SERVICE_ID = 18L;
			long CODE_ANALYSIS_SERVICE_ID = 19L;
			long RELEASE_DEPLOYMENT_SERVICE = 20L;
			long UNSCHEDULE_SERVICE = 21L;
			long SERVICE_ID = 2L;
			long HI_ID = 1L;
			long ATTACHMENT_ID = 5L;
			long SALUTATION_ID = 6L;
			long WARNING_ID = 7L;
			long SERVICE_NOW_IMPORT_ID = 24L;
			long MOBILE_TESTING_ID = 25L;
		}
		
		interface JiraServiceName {
			
			String ISSUE_INPROGRESS_STATUS = "21";
			String ISSUE_DONE_STATUS = "31";
			String CREATE_ENVIRONMENT_SERVICE = "Create Environment";
			String DATABASE_REFRESH_SERVICE = "Dbrefresh Service";
			String APPLICATION_DEPLOYMENT_SERVICE = "Application Deployment";
			String APPLICATION_UNDEPLOYMENT_SERVICE = "Application Undeployment";
			String BUILD_SERVICE = "Build Service";
			String CODE_ANALYSIS_SERVICE = "Code Analysis";
			String TRACKING_TOOL = "Jira";
			String PROJECT_KEY = "NET";
			String RESTART_SERVER_SERVICE = "Restart Server";
			String APPLICATION_DEPLOYMENT = "Application Deployment";
			String RELEASE_DEPLOYMENT = "Release Deployment";
			String UNSCHEDULE_SERVICE = "Unschedule Service";
			String PROMOTE_SERVICE = "Promote Service";
			String APPLICATION_ROLLBACK_SERVICE = "Application Rollback";
			String SOFTWARE_INSTALLATION_SERVICE = "Software Installation";
			String VM_RECONFIGURATION_SERVICE = "VM Reconfiguration";
			String AGENT_DEPLOYMENT = "Agent Deployment";
			String DEPLOYMENT_PIPELINE_SERVICE = "Deployment Pipeline";
			String TEST_EXECUTION_SERVICE = "Test Execution";
		}
		
		interface AutomationTool {
			
			String NOLIO = "Nolio";
			String SSH = "SSH";
			String Udeploy = "Udeploy";
			String PUPPET = "Puppet";
			Long NOLIO_ID = 1L;
			Long SCRIPT_ID = 4L;
			Long UDEPLOY_ID = 2L;
			Long PUPPET_ID = 3L;
		}
		
		interface RepositoryList {
			
			Long SVN_ID = 1L;
			Long SHAREDLOCATION_ID = 6L;
		}
		
		interface Action {
			
			String SUCCESS = "Success";
			String FAILURE = "Failure";
			String BOTH = "Both";
			String SUCCESS_FLAG = "S";
			String FAILURE_FLAG = "F";
			String BOTH_FLAG = "B";
		}
		
		interface Status {
			
			String ACTIVE = "ACT";
			String INACTIVE = "ICT";
		}
		
		interface DockerStatus {
			
			String ACTIVE = "Active";
			String INACTIVE = "Inactive";
		}
		
		interface ServiceNowTables {
			
			String SERVICE_NOW = "ServiceNow";
			String NETRA = "Netra";
			String PROVISIONED_PLATFORM = "provisioned_platform";
			String PROVISIONED_MACHINE = "provisioned_machine";
			String PROVISIONED_MACHINE_PHYSICAL = "provisioned_machine_physical";
			String SOFTWARE = "software";
		}
		
		interface ServiceNowColumns {
			
			String PROVISIONED_MACHINE_TYPE = "provisioned_machine_type";
			String PERSHIBLE_FLAG = "perishable_flag";
			String PROVISIONED_STATUS = "provisioned_status";
			String STATUS = "status";
			String TYPE = "type";
			String PASSWORD = "password";
			String APPLICATION_SERVER = "Application Server";
			String MACHINE_ARCHITECTURE = "architecture";
		}
		
		interface ApplicationRelease {
			
			String PARENT_APPLICATION_RELEASE = "P";
			String SUB_APPLICATION_RELEASE = "S";
		}
		
		interface Application {
			
			String APPLICATION_TYPE_APP = "Application";
			String APPLICATION_TYPE_SYS = "Component";
			String APPLICATION_CATEGORY_OTHER = "Other";
		}
		
		interface MobileApplication {
			
			String CATEGORY_MOBILE_APP = "Mobile Application";
			String MOBILE_TYPE_NATIVE = "Native";
		}
		
		interface ApplicationSystem {
			
			String DEPENDENT_TYPE_Up = "U";
			String DEPENDENT_TYPE_Down = "D";
		}
		
		interface ApplicationCategory {
			
			String CATEGORY_TYPE_SYS = "S";
			String CATEGORY_TYPE_APP = "A";
		}
		
		interface MachineTypes {
			
			String MACHINE_TYPE_PHYSICAL = "PHYSICAL";
			String MACHINE_TYPE_VIRTUAL = "VIRTUAL";
			String MACHINE_TYPE_EC2 = "EC2";
			String MACHINE_TYPE_VMWARE = "VMWARE";
			String MACHINE_TYPE_AZURE = "AZURE";
			String MACHINE_TYPE_VMWARE_BAREMETAL = "VMWARE_BARE";
			String MACHINE_TYPE_OPENSTACK = "OPENSTACK";
			String MACHINE_TYPE_DOCKER = "DOCKER";
		}
		
		interface ProvisionedStatus {
			
			String MACHINE_AVAILABLE = "AVAILABLE";
			String MACHINE_UNAVAILABLE = "UNAVAILABLE";
			String MACHINE_PROVISIONED = "PROVISIONED";
		}
		
		interface ProvisionedMachineStatus {
			
			String PROVISIONED_MACHINE_ACTIVE = "ACT";
			String PROVISIONED_MACHINE_INACTIVE = "ICT";
		}
		
		interface PlatformTemplateStatus {
			
			long PLATFORM_TEMPLATE_AVAILABLE = 177L;
			long PLATFORM_TEMPLATE_UNAVAILABLE = 178L;
		}
		
		interface MachineTemplateStatus {
			
			long MACHINE_TEMPLATE_AVAILABLE = 179L;
			long MACHINE_TEMPLATE_UNAVAILABLE = 180L;
		}
		
		interface Family {
			
			String FT1_WINDOWS = "FT1_WINDOWS";
			String FT2_LINUX = "FT2_LINUX";
		}
		
		interface ServerTypes {
			
			String DATA_CENTRE = "Data Centre";
			String ESXI_SERVER = "Esxi Server";
		}
		
		interface GlobalParameters {
			
			String RELEASE_NOTE_FILE_UPLOAD_LOCATION = "RELEASE_NOTE_FILE_UPLOAD_LOCATION";
			String JMETER_SCRIPTS_CHECKOUT_LOCATION = "JMETER_SCRIPTS_CHECKOUT_LOCATION";
			String JMETER_RESULT_LOCATION = "JMETER_RESULT_LOCATION";
			String JENKINS_LOGS_LOCATION = "JENKINS_LOG_LOCATION";
			String JASPER_LOCATION = "JASPER_LOCATION";
			String SERVICES_LOGS_LOCATION = "SERVICE_LOG_LOCATION";
			String CONFIG_FILE_LOCATION = "CONFIG_FILE_LOCATION";
			String SELENIUM_SCRIPTS_CHECKOUT_LOCATION = "SELENIUM_SCRIPTS_CHECKOUT_LOCATION";
			String DOUBLE_BACKSLASH = "//";
			String TASK_UNDERSCORE = "Task_";
			String SOFTWARE = "Bulk_Upload_Software";
			String HARDWARE = "Bulk_Upload_Hardware";
			String SELENIUM_HOME = "SELENIUM_HOME";
			String SELENIUM_PORT_NO = "SELENIUM_PORT_NO";
			String JMETER_HOME = "JMETER_HOME";
			String QTP_SCRIPTS_CHECKOUT_LOCATION = "QTP_SCRIPTS_CHECKOUT_LOCATION";
			String NOLIO_NETRA_SERVER_IP = "NOLIO_NETRA_SERVER_IP";
			String TECHNOLOGY_STACK = "TECHNOLOGY_STACK";
			String FILE_SOURCE_LOCATION = "FILE_SOURCE_LOCATION";
			String VBS_TEMPLATE_LOCATION = "VBS_TEMPLATE_LOCATION";
			String PSTOOLS_LOCATION = "PSTOOLS_LOCATION";
			String NETRA_SERVER_USERNAME = "NETRA_SERVER_USERNAME";
			String NETRA_SERVER_PASSWORD = "NETRA_SERVER_PASSWORD";
			String VMWARE_BAREMETAL_CREATION_COUNTER = "VMWARE_BAREMETAL_CREATION_COUNTER";
			String VMWARE_BAREMETAL_CREATION_WAIT_MILLISECONDS = "VMWARE_BAREMETAL_CREATION_WAIT_MILLISECONDS";
			String VMWARE_BAREMETAL_FILE_LOCATION = "VMWARE_BAREMETAL_FILE_LOCATION";
			String VMWARE_BAREMETAL_FILENAME = "VMWARE_BAREMETAL_FILENAME";
			String VMWARE_BAREMETAL_EDIT_SH_COMMAND = "VMWARE_BAREMETAL_EDIT_SH_COMMAND";
			String VMWARE_BAREMETAL_SH_FILENAME_VM_CREATION = "VMWARE_BAREMETAL_SH_FILENAME_VM_CREATION";
			String VMWARE_BAREMETAL_KICKSTART_FOLDER_NAME = "VMWARE_BAREMETAL_KICKSTART_FOLDER_NAME";
			String VMWARE_BAREMETAL_KICKSTART_SH_FILENAME = "VMWARE_BAREMETAL_KICKSTART_SH_FILENAME";
			String DAYS_TO_MAIL_BEFORE_ENV_EXPIRATION = "DAYS_TO_MAIL_BEFORE_ENV_EXPIRATION";
			String VMWARE_BAREMETAL_SH_FILENAME_VM_DELETION = "VMWARE_BAREMETAL_SH_FILENAME_VM_DELETION";
			String SONAR_CODECHECKOUT_LOCATION = "SONAR_CODECHECKOUT_LOCATION";
			String SONAR_PDFGENERATION_LOCATION = "SONAR_PDFGENERATION_LOCATION";
			String SONAR_URL = "SONAR_URL";
			String SONAR_USERNAME = "SONAR_USERNAME";
			String SONAR_PASSWORD = "SONAR_PASSWORD";
			String OPERATING_SYSTEM = "OPERATING_SYSTEM";
			String WINDOWS_OS = "Windows";
			String LINUX_OS = "Linux";
			String Sonar_Agent_URL = "Sonar_Agent_URL";
			String SVN_CHECKOUT_LOCATION = "SVN_CHECKOUT_LOCATION";
			String HARDWARE_TEMPLATE = "HARDWARE_TEMPLATE";
			String START_SONAR_LOCATION = "START_SONAR_LOCATION";
			String START_SONAR_RUNNER_LOCATION = "START_SONAR_RUNNER_LOCATION";
			String USERGUIDE_LOCATION = "USERGUIDE_PATH";
			String DOCKER_TEMPLATE_FILE_LOCATION = "DOCKER_TEMPLATE_FILE_LOCATION";
			String DOCKER_REMOTE_TARFILE_LOCATION = "Docker_Remote_TARFileLocation";
			String DOCKER_LOCAL_TARFILE_LOCATION = "Docker_Local_TARFileLocation";
			String DOCKER_CONTAINER_SUBNET = "Docker_Container_Subnet";
			String FILE_DIR = "FILE_DIR";
			String FILE_LOCATION = "FILE_LOCATION";
			String SMOKE_FILE_PATH = "SMOKE_FILE_PATH";
			String CREATE_ENV_FILE_PATH = "CREATE_ENV_FILE_PATH";
			String CREATE_DB_FILE_FATH = "CREATE_DB_FILE_FATH";
			String TEST_COPY_FILE_PATH = "TEST_COPY_FILE_PATH";
			String APP_DEPLOY_FILE_PATH = "APP_DEPLOY_FILE_PATH";
			String JENKINS_CLI_JAR_FILE_PATH = "JENKINS_CLI_JAR_FILE_PATH";
			String TEMS_PPK_FILE_PATH = "TEMS_PPK_FILE_PATH";
			String L_FILE = "L_FILE";
			String PUPPETAUTOMATESCRIPT = "PUPPET_AUTOMATE_SCRIPT";
			String PUPPETREPOSCRIPT = "PUPPET_REPO_SCRIPT";
			String CHECKPUPPETAGENTINSTALLATIONFOLDER = "CHECK_PUPPET_AGENT_INSTALLATION_FOLDER";
			String CHECKPUPPETAGENTINSTALLATIONFILE = "CHECK_PUPPET_AGENT_INSTALLATION_FILE";
			String VMWARE_KICKSTART_CONFIGURATION_FILE_NAME = "VMWARE_KICKSTART_CONFIGURATION_FILE_NAME";
			String VMWARE_KICKSTART_CONFIGURATION_FILE_OUT_LOC = "VMWARE_KICKSTART_CONFIGURATION_FILE_OUT_LOC";
			String ATTRIBUTE_TYPE_SOFTWARE = "Software";
			String SELENIUM_POI_JAR_LOCATION = "SELENIUM_POI_JAR_LOCATION";
			String SELENIUM_COMPILE_BATCH = "SELENIUM_COMPILE_BATCH";
			String SELENIUM_RUN_BATCH = "SELENIUM_RUN_BATCH";
			String PUPPETTARGETLOCATIONTOMOVE = "PUPPET_TARGET_LOCATION_TO_MOVE";
			String PUPPETMANIFESTLOGLOCATION = "Puppet_Manifest_Log_location";
			String PUPPETMANIFESTLOCATION = "PUPPET_MANIFEST_LOCATION";
			String JENKINS_DOCKER_CONTAINER = "Jenkins_Docker_Container";
			String NOLIO_TOOL_NAME_AS_CARA = "CARA";
			String Scripts = "Scripts";
			String NOLIO_PARAMETER = "NolioParameter";
			String SCRIPT_PARAMETER = "ScriptParameter";
			String PERFECTO_SCRIPT_PATH = "PERFECTO_SCRIPT_PATH";
		}
		
		/**
		 * Activity indicates the different services supported by NETRA
		 * 
		 * @author 460650
		 */
		interface Activity {
			
			Long INSTALLATION = 1L;
			Long EXECUTE_DATABASE_SCRIPTS = 2L;
			Long APPLICATION_DEPLOYMENT = 3L;
			Long JNDI_NAME = 4L;
			Long SERVER_RESTART = 5L;
			Long APPLICATION_UNDEPLOYMENT = 6L;
		}
		
		interface ApplicationParameter {
			
			String USER_DEFINED_PARAM_DELIMITER = "_UDP";
			String SERVER_PARAM_DELIMITER = "_ASP";
			String NOLIO_PROCESS_PARAM_DELIMITER = "_ANP";
			String USER_DEFINED_PARAM_END_DELIMITER = "UDP_";
			String SERVER_PARAM_END_DELIMITER = "ASP_";
			String NOLIO_PROCESS_PARAM_END_DELIMITER = "ANP_";
			String autoServerIPParamDelimiter = "ASP";
			String autoNolioParamDelimiter = "ANP";
			String userDefinedParamDelimiter = "UDP";
			String delimiterUnderScore = "_";
			String paramLineDelimiter = "~|~";
			String PARAM_DELIMITER = "$@$";
			String paramNolioIdDelimiter = "#^#";
			String paramDelimiterForParamLineString = "@^@";
			String NOLIO_PARAMID_DELIMITER = "#!#";
		}
		
		interface TestCaseExecutionResults {
			
			String PASSED = "PASSED";
			String FAILED = "FAILED";
			String SKIPPED = "SKIPPED";
			String EXECUTED = "EXECUTED";
		}
		
		interface ApplicationPhaseStatus {
			
			String APPLICATION_PHASE_ACTIVE = "Y";
			String APPLICATION_PHASE_INACTIVE = "N";
		}
		
		interface NetraNolioParametersMapping {
			
			String NETRA_PARAMETER_MAPPED_YES = "Y";
			String NETRA_PARAMETER_MAPPED_NO = "N";
		}
		
		interface NetraParameters {
			
			String SCHEMA_NAME = "Schema Name";
			String DATABASE_SCRIPTS = "Database Scripts";
			String DATABASE_SCRIPTS_PATH = "Database Scripts Path";
			String REPOSITORY_URL = "Repository URL";
			String REPOSITORY_USERNAME = "Repository Username";
			String REPOSITORY_PASSWORD = "Repository Password";
			String REPOSITORY_TYPE = "Repository Type";
			String PERFORCE_IP = "Perforce IP";
			String PERFORCE_PORT = "Perforce Port";
			String ORACLE_CONNECTION_DBURL = "Oracle_Connection_DBUrl";
			String MYSQL_CONNECTION_DBURL = "MySQL_Connection_DBUrl";
			String MSSQL_CONNECTION_DBURL = "MSSQL_Connection_DBUrl";
			String DEPLOYED_ARTIFACT = "Deployed Artifact";
			String SHARED_NEXUS_FLAG = "Shared-Nexus Flag";
			String SHARED_LOCATION_IP = "Shared Location IP";
			String SHARED_LOCATION_PATH = "Shared Location Path";
			String NETRA_TEMPORARY_DESTINATION = "NETRA Temporary Destination";
			String NEXUS_WAR_NAME = "Nexus WAR Name";
			String NEXUS_USERNAME = "Nexus Username";
			String NEXUS_PASSWORD = "Nexus Password";
			String NEXUS_SOURCE_URL = "Nexus Source URL";
			String NEXUS_REPO_ID = "Nexus Repo-ID";
			String NEXUS_GROUP_ID = "Nexus Group-ID";
			String NEXUS_ARTIFACT_ID = "Nexus Artifact-ID";
			String NEXUS_URL = "Nexus_URL";
			String NEXUS_VERSION_ID = "Nexus Version-ID";
			String CA_SERVER = "CA_server";
			String DEPLOYMENT_ARTIFACT_TYPE = "Deployment Artifact Type";
			String DEPLOYMENT_ARTIFACT_TYPE_VALUE = "war";
			String AGENT_IP = "Agent IP";
			String TARGET_LOCATION = "Target Location";
			String IBM_OPTIM_MACHINE_IP = "IBM Optim Machine IP";
			String IBM_OPTIM_INSTALL_LOCATION = "IBM Optim Install Location";
			String OPTIM_EXTRACT_REQUEST_NAME = "Optim Extract Request Name";
			String OPTIM_INSERT_REQUEST_NAME = "Optim Insert Request Name";
			String OPTIM_EXTRACT_FILE_NAME = "Optim Extract File Name";
			String INSTALLER_LOCATION_LINUX = "Installer Location Linux";
			String INSTALLER_LOCATION_WINDOWS = "Installer Location Windows";
			String TARGET_LOCATION_LINUX = "Target Location Linux";
			String TARGET_LOCATION_WINDOWS = "Target Location Windows";
			String DEPLOYMENT_SCRIPT_NAME = "Deployment Script Name";
			String ARTIFACT_TARGET_DIRECTORY = "Artifact Target Directory";
			String EAR_SCRIPT_SELECTOR = "EAR/Script Selector";
			String PROTOCOL = "Protocol";
			String SCRIPT_CHECKOUT_DIRECTORY = "Script Checkout Directory";
			String TFS_AGENT = "TFS Agent";
			String BUILD_LOCATION = "Build Location";
			String CURRENT_RELEASE = "Current Release";
			String ROLLBACK_FLAG = "Rollback Flag";
		}
		
		interface CommandSeparators {
			
			String COMMA = ",";
			String FORWARDSLASH = "/";
			String FORWARDSLASH_DOUBLE = "//";
			String BACKWARDSLASH = "\\";
			String AT_SIGN = "@";
			String SPACE = " ";
			String SEMICOLON = ";";
			String NEWLINE_CHARACTER = "\n";
			String UNDERSCORE = "_";
			String SINGLE_QUOTES = "'";
			String LESSTHAN = "<";
			String GREATERTHAN = ">";
			String ASTERISK = "*";
			String FULLSTOP = ".";
			String COLON = ":";
		}
		
		public interface ParameterScope {
			
			public static final String ENVIRONMENT = "ENV";
			public static final String RELEASE = "REL";
		}
	}
	
	interface External {
		
		String MYSQL_DIALECT = "org.hibernate.dialect.MySQLDialect";
		String ORACLE10G_DIALECT = "org.hibernate.dialect.Oracle10gDialect";
		
		interface AgentType {
			
			String CA_AUTOMATION_AGENT = "CA";
			String ZABBIX_AGENT = "ZA";
			String UDEPLOY_AGENT = "U";
			String PUPPET_AGENT = "P";
		}
		
		interface AutomationToolsDetails {
			
			String toolsId = "toolsId";
			String toolsName = "toolsName";
		}
		
		interface Deployment_Resource {
			
			String SHARED_RESOURCE = "sharedResource";
		}
		
		interface Udeploy {
			
			String UDEPLOY_TOOL_NAME = "UDEPLOY RELEASE AUTOMATION";
			String UDEPLOY_PROCESS_ACTIVE = "ACT";
			String UDEPLOY_PROCESS_INACTIVE = "INACT";
			String UDEPLOY_AGENT_STATUS = "OFFLINE";
		}
		
		interface Puppet {
			
			String Puppet_TOOL_NAME = "Puppet RELEASE AUTOMATION";
			String Puppet_PROCESS_ACTIVE = "ACT";
			String Puppet_PROCESS_INACTIVE = "INACT";
			
			interface Process {
				
				String RUN_SONAR_PROCESS = "run_sonar_process";
				String CONFIG_FILE_MOVEMENT = "ConfigFile";
			}
		}
		
		interface Nolio {
			
			String NOLIO_TOOL_NAME = "CA RELEASE AUTOMATION";
			String APPLICATION_ROLLBACK_SCRIPT = "ROLLBACK";
			String APPLICATION_NEW_SCRIPT = "SCRIPT";
			String NOLIO_PROCESS_ACTIVE = "ACT";
			String NOLIO_PROCESS_INACTIVE = "INACT";
			
			interface NolioGlobalParameters {
				
				String CONFIG_FILE_SOURCE_PATH = "Move Netra Files/SourcePathAddress";
				String CONFIG_FILE_TARGET_PATH = "Move Netra Files/DestinationPathAddress";
				String CONFIG_FILE_SOURCE_IP = "Move Netra Files/SourceIPAddress";
				String QTP_SCRIPT_DIRECTORY = "QTP/QTP Parameters/Qtp script directory";
				String FILENAME = "QTP/QTP Parameters/Filename";
				String TAM_ADAPTER_NAME = "MC TAM/TAM_Adapter_Name";
				String TAM_ADAPTER_INSTALLATION_DIRECTORY = "TAM/TAM_Adapter_Installation_Directory";
				String MC_TAM_ADAPTER_INSTALLATION_DIRECTORY = "MC TAM/TAM_Adapter_Installation_Directory";
				String MC_TAM_ADAPTER_LOCATION = "MC TAM/TAM_Adapter_Location_String";
				String MC_TAM_SERVER_URL = "MC TAM/TAM_Server_Url";
				String MC_TESTING_TOOL = "MC TAM/Testing_Tool";
				String MC_USERNAME = "MC TAM/UserName";
				String MC_PASSWORD = "MC TAM/Password";
				String ADAPTER_START_FILE_NAME = "TAM/TAM_Adapter_Start_File_Name";
				String SERVER_IP = "TAM/Server_Ip";
				String SERVER_PORT = "TAM/Server_Port";
				String TESTING_TOOL = "TAM/Testing_Tool";
			}
			
			interface Process {
				
				String WINDOWS_AGENT_INSTALLATION = "Windows Process/Windows_Agent_Deployer";
				String ZABBIX_AGENT_INSTALLATION = "Zabbix/ZabbixWindowsLinux";
				String CONFIG_FILE_MOVEMENT = "FolderMovement/FolderMovement";
				String QTP_SCRIPT_EXECUTION = "QTP/QTP script Execution";
				String TAM_ADAPTER_INSTALLATION = "MC TAM/MC_TAM_Adapter_Installation";
				String CREATE_URL_PARAMETERIZATION_FILE = "MC TAM/Create_URL_Parameterization_File";
				String START_ADAPTER = "MC TAM/Start Adapter";
				String IBM_OPTIM_PROCESS = "IBM Optim/Run Optim scripts";
				/* for 92 */
				String TRANSFER_WAR_FROM_SHARED_LOCATION = "REPO/RepoProcess";
				String RUN_SONAR_PROCESS = "Processes/sonar_1";
			}
		}
		
		/**
		 * Tools interface contains constants added for Continuous Integration Tools and Testing Tools.
		 * 
		 * @author 460650
		 */
		interface Tools {
			
			interface ContinuousIntegrationServer {
				
				long JENKINS = 1L;
				long TFS = 2L;
				long TEAMCITY = 3L;
				long MSBUILD = 4L;
				String JENKINS_TOOL = "Jenkins";
				String TFS_TOOL = "TFS";
				String TEAMCITY_TOOL = "TeamCity";
				String MSBUILD_TOOL = "Msbuild";
				
				interface Jenkins {
					
					interface JenkinsParameters {
						
						String JENKINS_WORKSPACE = "workspace";
						String JENKINS_BUILD_NAME = "Build_Name";
						String JENKINS_REPOSITORY_URL = "repository_url";
						String JENKINS_REPO_VERSION = "repo_version";
						String JENKINS_RELEASE_TO_NEXUS = "releaseToNexus";
						String JENKINS_REPOSITORY_ID = "repositoryId";
						String JENKINS_NEXUS_GROUP_ID = "nexusGroupId";
						String JENKINS_NEXUS_ARTIFACT_ID = "nexusArtifactId";
						String JENKINS_NEXUS_PACKAGING = "nexusPackaging";
						String JENKINS_NEXUS_REPOSITORY_URL = "nexusRepositoryUrl";
						String JENKINS_RELEASE_TO_NEXUS_FLAG = "true";
						String JENKINS_RELEASE_TO_NEXUS_NOFLAG = "false";
					}
				}
				
				interface Teamcity {
					
					interface TeamcityParameters {
						
						String PERFORCE_REPO_IP = "perforce_repo_ip";
						String PERFORCE_REPO_USERNAME = "repository_username";
					}
				}
				
				String EAR_PATH = "ear_path";
				String NETRA_NEXUS_PATH = "netra_nexus_path";
				String SCRIPTS_PATH = "scripts_path";
				String PARAMETERIZED_BUILD = "Y";
			}
			
			interface TestingTools {
				
				String SELENIUM = "SELENIUM";
				String QTP = "QTP";
				String APACHE_JMETER = "APACHE_JMETER";
				String TAM = "TAM";
				String JUNIT = "JUNIT";
				String RAFT_SELENIUM = "RAFT - Selenium";
				long QTP_TOOL_ID = 2;
				long RAFT_SELENIUM_ID = 6;
				long TEST_TOOL_ID = 4;
				long APACHE_TOOL_ID = 3;
				long SELENIUM_TOOL_ID = 1;
				long JUNIT_TOOL_ID = 5;
				String PORT = "port";
				String MASTERCRAFT_TAM_SERVER = "MasterCraft TAM Server";
				String MASTERCRAFT_TAM = "MasterCraft TAM";
				String MASTERCRAFT_TAM_CLIENT_RAFT_SELENIUM = "MasterCraft TAM Client(RAFT-Selenium)";
				String QUERY_TARGET_SERVER_DETAILS = "select distinct p.family as opSys,m.name as serverName,m.ip as ip, phy.username as phyUserName,phy.password as phyPwd,vm.username as vmUserName,vm.password as vmPwd,os.username as osUserName,os.password as osPwd,m.provisionedMachineType as provMachineType,m.virtualMachineType as virtualMachineType from ProvisionedMachineTO as m left join m.provisionedMachinePhysicalTOSet as phy left join m.provisionedMachineVMWare as vm left join m.provisionedMachineOSTOSet as os left join m.provisionedPlatform as p where m.id=";
			}
			
			interface DataMaskingTools {
				
				long MASTERCRAFT_TDEM_TEM = 1L;
				long OPTIM_ID = 2L;
				String IBM_OPTIM = "IBM Optim";
			}
			
			interface SourceControlTools {
				
				String SVN = "svn";
				String GIT = "git";
				String PERFORCE = "perforce";
			}
			
			interface DatabaseServer {
				
				String ORACLE = "oracle";
				String MYSQL = "mysql";
				String MSSQLSERVER = "ms sql";
			}
			
			interface ApplicationServer {
				
				String JBOSS = "jboss";
			}
			
			interface WebServer {
				
				String IIS = "IIS";
			}
		}
	}
	
	interface Services {
		
		String AWS_SOFTWARE_PROVIDER_AWS_ACCOUNT_ID = "awsAccountId";
		String AWS_SOFTWARE_PROVIDER_SECURITY_GROUP_ID = "securityGrouId";
		String AWS_SOFTWARE_PROVIDER_PORTS = "portsList";
	}
	
	interface DeployToNexusFlag {
		
		String TRIGGER_BUILD = "Y";
		String NOT_TO_TRIGGER_BUILD = "N";
	}
	
	interface CalendarReports {
		
		String Environ = "Environments";
		String Legends = "Legends";
		String SHARED = "	Shared Environment";
		String DISRUPTIVE = "Disruptive Environment";
		String LOCKED_ENV = "Locked Environment";
		String AVAILABLE_ENV = "Available Environment";
		String UNAVAILABLE_ENV = "Unavialable Environment";
		String HOURLY_ENV = "Hourly Environment";
		String ENV_PENDING_APPROVAL = "Environment Pending Approval";
		String CONFLICTING_ENV = "Conflicting Environment";
	}
}
