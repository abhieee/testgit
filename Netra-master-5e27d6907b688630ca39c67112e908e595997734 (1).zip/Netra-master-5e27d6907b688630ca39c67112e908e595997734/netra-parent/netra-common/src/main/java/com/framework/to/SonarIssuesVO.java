package com.framework.to;

import java.io.Serializable;
import java.util.List;

public class SonarIssuesVO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5778748114111417408L;
	private List<IssuesSonarTO> issues;
	
	public List<IssuesSonarTO> getIssues() {
	
		return issues;
	}
	
	public void setIssues(List<IssuesSonarTO> issues) {
	
		this.issues = issues;
	}
}
