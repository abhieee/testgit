package com.framework.to;

import java.io.Serializable;

public class PlatformTemplateBareMetalTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 248729593405236888L;
	private Long id;
	private PlatformTemplateTO platformTemplate;
	private String isoFilePath;
	private Long platform_template_id;
	
	public Long getId() {
	
		return id;
	}
	
	/**
	 * @return the isoFilePath
	 */
	public String getIsoFilePath() {
	
		return isoFilePath;
	}
	
	public Long getPlatform_template_id() {
	
		return platform_template_id;
	}
	
	public PlatformTemplateTO getPlatformTemplate() {
	
		return platformTemplate;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	/**
	 * @param isoFilePath
	 *                the isoFilePath to set
	 */
	public void setIsoFilePath(String isoFilePath) {
	
		this.isoFilePath = isoFilePath;
	}
	
	public void setPlatform_template_id(Long platform_template_id) {
	
		this.platform_template_id = platform_template_id;
	}
	
	public void setPlatformTemplate(PlatformTemplateTO platformTemplate) {
	
		this.platformTemplate = platformTemplate;
	}
}
