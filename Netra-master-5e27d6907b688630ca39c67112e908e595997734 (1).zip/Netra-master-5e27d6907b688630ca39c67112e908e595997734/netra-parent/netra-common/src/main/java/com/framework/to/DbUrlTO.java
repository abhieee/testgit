package com.framework.to;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

public class DbUrlTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5835834841544978619L;
	private List<DbUrlTO> directoryList = null;
	private Long dbId = null;
	private Long dbUrlID = null;
	private String dbStatus = null;
	private Timestamp dbTime = null;
	private String db_name = null;
	private Date createdDate;
	private String createdBy = null;
	
	public String getCreatedBy() {
	
		return createdBy;
	}
	
	public Date getCreatedDate() {
	
		return createdDate;
	}
	
	public String getDb_name() {
	
		return db_name;
	}
	
	public Long getDbId() {
	
		return dbId;
	}
	
	public String getDbStatus() {
	
		return dbStatus;
	}
	
	public Timestamp getDbTime() {
	
		return dbTime;
	}
	
	public Long getDbUrlID() {
	
		return dbUrlID;
	}
	
	public List<DbUrlTO> getDirectoryList() {
	
		return directoryList;
	}
	
	public void setCreatedBy(String createdBy) {
	
		this.createdBy = createdBy;
	}
	
	public void setCreatedDate(Date createdDate) {
	
		this.createdDate = createdDate;
	}
	
	public void setDb_name(String db_name) {
	
		this.db_name = db_name;
	}
	
	public void setDbId(Long dbId) {
	
		this.dbId = dbId;
	}
	
	public void setDbStatus(String dbStatus) {
	
		this.dbStatus = dbStatus;
	}
	
	public void setDbTime(Timestamp dbTime) {
	
		this.dbTime = dbTime;
	}
	
	public void setDbUrlID(Long dbUrlID) {
	
		this.dbUrlID = dbUrlID;
	}
	
	public void setDirectoryList(List<DbUrlTO> directoryList) {
	
		this.directoryList = directoryList;
	}
}
