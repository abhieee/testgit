package com.framework.to;

import java.io.Serializable;

public class DataMaskingConfigTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5087030130117006087L;
	private Long id;
	private Long selectedBUId;
	private Long selectedProjectId;
	private Long selectedApplicationId;
	private String selectedDataMaskToolName;
	private String ip;
	private String optimLocation;
	private String selectedMaskTool;
	private String optimIP;
	private String optimInstallLocation;
	private String buName;
	private String projectName;
	private String applicationName;
	private ApplicationTO applicationTO;
	private ProjectsTO projectsTO;
	private ClientTO clientTO;
	
	public String getApplicationName() {
	
		return applicationName;
	}
	
	public ApplicationTO getApplicationTO() {
	
		return applicationTO;
	}
	
	public String getBuName() {
	
		return buName;
	}
	
	public ClientTO getClientTO() {
	
		return clientTO;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public String getIp() {
	
		return ip;
	}
	
	public String getOptimInstallLocation() {
	
		return optimInstallLocation;
	}
	
	public String getOptimIP() {
	
		return optimIP;
	}
	
	public String getOptimLocation() {
	
		return optimLocation;
	}
	
	public String getProjectName() {
	
		return projectName;
	}
	
	public ProjectsTO getProjectsTO() {
	
		return projectsTO;
	}
	
	public Long getSelectedApplicationId() {
	
		return selectedApplicationId;
	}
	
	public Long getSelectedBUId() {
	
		return selectedBUId;
	}
	
	public String getSelectedDataMaskToolName() {
	
		return selectedDataMaskToolName;
	}
	
	public String getSelectedMaskTool() {
	
		return selectedMaskTool;
	}
	
	public Long getSelectedProjectId() {
	
		return selectedProjectId;
	}
	
	public void setApplicationName(String applicationName) {
	
		this.applicationName = applicationName;
	}
	
	public void setApplicationTO(ApplicationTO applicationTO) {
	
		this.applicationTO = applicationTO;
	}
	
	public void setBuName(String buName) {
	
		this.buName = buName;
	}
	
	public void setClientTO(ClientTO clientTO) {
	
		this.clientTO = clientTO;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setIp(String ip) {
	
		this.ip = ip;
	}
	
	public void setOptimInstallLocation(String optimInstallLocation) {
	
		this.optimInstallLocation = optimInstallLocation;
	}
	
	public void setOptimIP(String optimIP) {
	
		this.optimIP = optimIP;
	}
	
	public void setOptimLocation(String optimLocation) {
	
		this.optimLocation = optimLocation;
	}
	
	public void setProjectName(String projectName) {
	
		this.projectName = projectName;
	}
	
	public void setProjectsTO(ProjectsTO projectsTO) {
	
		this.projectsTO = projectsTO;
	}
	
	public void setSelectedApplicationId(Long selectedApplicationId) {
	
		this.selectedApplicationId = selectedApplicationId;
	}
	
	public void setSelectedBUId(Long selectedBUId) {
	
		this.selectedBUId = selectedBUId;
	}
	
	public void setSelectedDataMaskToolName(String selectedDataMaskToolName) {
	
		this.selectedDataMaskToolName = selectedDataMaskToolName;
	}
	
	public void setSelectedMaskTool(String selectedMaskTool) {
	
		this.selectedMaskTool = selectedMaskTool;
	}
	
	public void setSelectedProjectId(Long selectedProjectId) {
	
		this.selectedProjectId = selectedProjectId;
	}
}
