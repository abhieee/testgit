package com.framework.to;

public class ReservationMailTO extends AbstractTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6510924743983588451L;
	private String subject;
	private String content;
	private Long status;
	
	public String getContent() {
	
		return content;
	}
	
	public Long getStatus() {
	
		return status;
	}
	
	public String getSubject() {
	
		return subject;
	}
	
	public void setContent(String content) {
	
		this.content = content;
	}
	
	public void setStatus(Long status) {
	
		this.status = status;
	}
	
	public void setSubject(String subject) {
	
		this.subject = subject;
	}
}
