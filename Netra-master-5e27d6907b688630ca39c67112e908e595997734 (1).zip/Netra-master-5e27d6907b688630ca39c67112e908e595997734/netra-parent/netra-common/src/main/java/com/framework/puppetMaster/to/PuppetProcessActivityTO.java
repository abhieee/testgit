/**
 *
 */
package com.framework.puppetMaster.to;

import java.io.Serializable;
import java.util.List;

/**
 * @author 584175
 */
public class PuppetProcessActivityTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 41516538260133303L;
	private long activityId;
	private String activityName;
	private String applicationSpecificFlag;
	private long selectedVersion;
	private long selectedActivityId;
	private List<Long> definedActivities;
	private List<Long> puppetProcessSoftwareMapOrderedList = null;
	
	public long getActivityId() {
	
		return activityId;
	}
	
	public String getActivityName() {
	
		return activityName;
	}
	
	public String getApplicationSpecificFlag() {
	
		return applicationSpecificFlag;
	}
	
	public List<Long> getDefinedActivities() {
	
		return definedActivities;
	}
	
	/**
	 * @return the puppetProcessSoftwareMapOrderedList
	 */
	public List<Long> getPuppetProcessSoftwareMapOrderedList() {
	
		return puppetProcessSoftwareMapOrderedList;
	}
	
	public long getSelectedVersion() {
	
		return selectedVersion;
	}
	
	public void setActivityId(long activityId) {
	
		this.activityId = activityId;
	}
	
	public void setActivityName(String activityName) {
	
		this.activityName = activityName;
	}
	
	public void setApplicationSpecificFlag(String applicationSpecificFlag) {
	
		this.applicationSpecificFlag = applicationSpecificFlag;
	}
	
	public void setDefinedActivities(List<Long> definedActivities) {
	
		this.definedActivities = definedActivities;
	}
	
	/**
	 * @param puppetProcessSoftwareMapOrderedList
	 *                the puppetProcessSoftwareMapOrderedList to set
	 */
	public void setPuppetProcessSoftwareMapOrderedList(List<Long> puppetProcessSoftwareMapOrderedList) {
	
		this.puppetProcessSoftwareMapOrderedList = puppetProcessSoftwareMapOrderedList;
	}
	
	public long getSelectedActivityId() {
	
		return selectedActivityId;
	}
	
	public void setSelectedActivityId(long selectedActivityId) {
	
		this.selectedActivityId = selectedActivityId;
	}
	
	public void setSelectedVersion(long selectedVersion) {
	
		this.selectedVersion = selectedVersion;
	}
}
