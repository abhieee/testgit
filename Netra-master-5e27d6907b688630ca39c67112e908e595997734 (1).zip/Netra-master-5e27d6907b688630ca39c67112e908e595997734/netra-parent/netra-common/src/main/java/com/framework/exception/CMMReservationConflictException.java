package com.framework.exception;

/**
 * @author TCS
 */
public class CMMReservationConflictException extends CMMException {
	
	private static final long serialVersionUID = 888724366243610132L;
	
	public CMMReservationConflictException() {
	
		super();
	}
	
	public CMMReservationConflictException(String message) {
	
		super(message);
	}
	
	public CMMReservationConflictException(String message, Throwable cause) {
	
		super(message, cause);
	}
	
	public CMMReservationConflictException(Throwable cause) {
	
		super(cause);
	}
}
