package com.framework.to;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class RoleLevelTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8221532945823686147L;
	private Long roleLevelOrder;
	private Long roleId;
	private RoleTO roleTO;
	private List<RoleTO> roleList = new ArrayList<RoleTO>();
	private List<RoleTO> definedRolesList = new ArrayList<RoleTO>();
	private List<Long> selectedRoles = new LinkedList<Long>();
	private List<Long> definedRoles = new LinkedList<Long>();
	
	public List<Long> getDefinedRoles() {
	
		return definedRoles;
	}
	
	public List<RoleTO> getDefinedRolesList() {
	
		return definedRolesList;
	}
	
	public Long getRoleId() {
	
		return roleId;
	}
	
	public Long getRoleLevelOrder() {
	
		return roleLevelOrder;
	}
	
	public List<RoleTO> getRoleList() {
	
		return roleList;
	}
	
	public RoleTO getRoleTO() {
	
		return roleTO;
	}
	
	public List<Long> getSelectedRoles() {
	
		return selectedRoles;
	}
	
	public void setDefinedRoles(List<Long> definedRoles) {
	
		this.definedRoles = definedRoles;
	}
	
	public void setDefinedRolesList(List<RoleTO> definedRolesList) {
	
		this.definedRolesList = definedRolesList;
	}
	
	public void setRoleId(Long roleId) {
	
		this.roleId = roleId;
	}
	
	public void setRoleLevelOrder(Long roleLevelOrder) {
	
		this.roleLevelOrder = roleLevelOrder;
	}
	
	public void setRoleList(List<RoleTO> roleList) {
	
		this.roleList = roleList;
	}
	
	public void setRoleTO(RoleTO roleTO) {
	
		this.roleTO = roleTO;
	}
	
	public void setSelectedRoles(List<Long> selectedRoles) {
	
		this.selectedRoles = selectedRoles;
	}
}
