/**
 *
 */
package com.framework.udeploy.to;

import java.util.List;
import com.framework.to.SoftwareconfigTO;

/**
 * @author 460650
 */
public class UdeployProcessSoftwareMapping {
	
	private long softwareProcessMappingId;
	private SoftwareconfigTO softwareConfigTO;
	private UdeployProcess udeployProcess;
	private List<Long> processList = null;
	private Long softwareId = null;
	private Long softwareConfigId = null;
	private Long udeploySoftwareProcessMappingId;
	
	public List<Long> getProcessList() {
	
		return processList;
	}
	
	public Long getSoftwareConfigId() {
	
		return softwareConfigId;
	}
	
	public SoftwareconfigTO getSoftwareConfigTO() {
	
		return softwareConfigTO;
	}
	
	public Long getSoftwareId() {
	
		return softwareId;
	}
	
	public long getSoftwareProcessMappingId() {
	
		return softwareProcessMappingId;
	}
	
	public UdeployProcess getUdeployProcess() {
	
		return udeployProcess;
	}
	
	public Long getUdeploySoftwareProcessMappingId() {
	
		return udeploySoftwareProcessMappingId;
	}
	
	public void setProcessList(List<Long> processList) {
	
		this.processList = processList;
	}
	
	public void setSoftwareConfigId(Long softwareConfigId) {
	
		this.softwareConfigId = softwareConfigId;
	}
	
	public void setSoftwareConfigTO(SoftwareconfigTO softwareConfigTO) {
	
		this.softwareConfigTO = softwareConfigTO;
	}
	
	public void setSoftwareId(Long softwareId) {
	
		this.softwareId = softwareId;
	}
	
	public void setSoftwareProcessMappingId(long softwareProcessMappingId) {
	
		this.softwareProcessMappingId = softwareProcessMappingId;
	}
	
	public void setUdeployProcess(UdeployProcess udeployProcess) {
	
		this.udeployProcess = udeployProcess;
	}
	
	public void setUdeploySoftwareProcessMappingId(Long udeploySoftwareProcessMappingId) {
	
		this.udeploySoftwareProcessMappingId = udeploySoftwareProcessMappingId;
	}
}
