package com.framework.to;

public class ServiceMailTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6027260927069504635L;
	private String message;
	private Long serviceMailId;
	
	public String getMessage() {
	
		return message;
	}
	
	public Long getServiceMailId() {
	
		return serviceMailId;
	}
	
	public void setMessage(String message) {
	
		this.message = message;
	}
	
	public void setServiceMailId(Long serviceMailId) {
	
		this.serviceMailId = serviceMailId;
	}
}
