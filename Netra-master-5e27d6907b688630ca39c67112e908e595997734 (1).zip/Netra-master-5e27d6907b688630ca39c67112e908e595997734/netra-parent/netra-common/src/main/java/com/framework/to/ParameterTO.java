package com.framework.to;

import java.io.Serializable;

public class ParameterTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 425021097761350838L;
	private Long id;
	private String name;
	private String value;
	private int searchCount;
	private boolean editAccessFlag = false;
	private int tableSize = 10;
	private Long pageNumber = 1L;
	private int firstResult = 0;
	
	public int getFirstResult() {
	
		return firstResult;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public String getName() {
	
		return name;
	}
	
	public Long getPageNumber() {
	
		return pageNumber;
	}
	
	public int getSearchCount() {
	
		return searchCount;
	}
	
	public int getTableSize() {
	
		return tableSize;
	}
	
	public String getValue() {
	
		return value;
	}
	
	public boolean isEditAccessFlag() {
	
		return editAccessFlag;
	}
	
	public void setEditAccessFlag(boolean editAccessFlag) {
	
		this.editAccessFlag = editAccessFlag;
	}
	
	public void setFirstResult(int firstResult) {
	
		this.firstResult = firstResult;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setName(String name) {
	
		this.name = name;
	}
	
	public void setPageNumber(Long pageNumber) {
	
		this.pageNumber = pageNumber;
	}
	
	public void setSearchCount(int searchCount) {
	
		this.searchCount = searchCount;
	}
	
	public void setTableSize(int tableSize) {
	
		this.tableSize = tableSize;
	}
	
	public void setValue(String value) {
	
		this.value = value;
	}
}