package com.framework.to;

import java.io.Serializable;

public class DeploymentPipelineForJiraTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6656426949844471567L;
	private Long id;
	private Long statusId;
	private String actionFlag;
	private String jira_issue;
	
	public String getActionFlag() {
	
		return actionFlag;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public String getJira_issue() {
	
		return jira_issue;
	}
	
	public Long getStatusId() {
	
		return statusId;
	}
	
	public void setActionFlag(String actionFlag) {
	
		this.actionFlag = actionFlag;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setJira_issue(String jira_issue) {
	
		this.jira_issue = jira_issue;
	}
	
	public void setStatusId(Long statusId) {
	
		this.statusId = statusId;
	}
}
