package com.framework.to.aws;

import java.util.HashMap;
import java.util.Map;

/**
 * @author 459704
 */
public class AWSEC2ImageTO {
	
	private String architecture;
	private String description;
	private String hypervisior;
	private String imageId;
	private String imageLocation;
	private String imageOwnerAlias;
	private String imageType;
	private String name;
	private String ownerId;
	private String state;
	private String virtualizationType;
	private Map<String, String> tags;
	
	public AWSEC2ImageTO() {
	
		tags = new HashMap<String, String>();
	}
	
	public String getArchitecture() {
	
		return architecture;
	}
	
	public String getDescription() {
	
		return description;
	}
	
	public String getHypervisior() {
	
		return hypervisior;
	}
	
	public String getImageId() {
	
		return imageId;
	}
	
	public String getImageLocation() {
	
		return imageLocation;
	}
	
	public String getImageOwnerAlias() {
	
		return imageOwnerAlias;
	}
	
	public String getImageType() {
	
		return imageType;
	}
	
	public String getName() {
	
		return name;
	}
	
	public String getOwnerId() {
	
		return ownerId;
	}
	
	public String getState() {
	
		return state;
	}
	
	public Map<String, String> getTags() {
	
		return tags;
	}
	
	public String getVirtualizationType() {
	
		return virtualizationType;
	}
	
	public void setArchitecture(String architecture) {
	
		this.architecture = architecture;
	}
	
	public void setDescription(String description) {
	
		this.description = description;
	}
	
	public void setHypervisior(String hypervisior) {
	
		this.hypervisior = hypervisior;
	}
	
	public void setImageId(String imageId) {
	
		this.imageId = imageId;
	}
	
	public void setImageLocation(String imageLocation) {
	
		this.imageLocation = imageLocation;
	}
	
	public void setImageOwnerAlias(String imageOwnerAlias) {
	
		this.imageOwnerAlias = imageOwnerAlias;
	}
	
	public void setImageType(String imageType) {
	
		this.imageType = imageType;
	}
	
	public void setName(String name) {
	
		this.name = name;
	}
	
	public void setOwnerId(String ownerId) {
	
		this.ownerId = ownerId;
	}
	
	public void setState(String state) {
	
		this.state = state;
	}
	
	public void setTags(Map<String, String> tags) {
	
		this.tags = tags;
	}
	
	public void setVirtualizationType(String virtualizationType) {
	
		this.virtualizationType = virtualizationType;
	}
}
