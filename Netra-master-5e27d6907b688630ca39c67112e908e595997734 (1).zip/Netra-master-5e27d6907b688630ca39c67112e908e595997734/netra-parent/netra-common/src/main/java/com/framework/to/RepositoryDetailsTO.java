package com.framework.to;

import java.io.Serializable;
import java.util.List;

public class RepositoryDetailsTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2347886540395852689L;
	private Long buId;
	private Long projectId;
	private ClientTO clientTO;
	private ProjectsTO projectsTO;
	private RepositoryTO repositoryTO;
	private List<BusinessUnitTO> businessUnitList;
	private List<ProjectsTO> projectList;
	private List<Long> selectedBuList;
	private List<Long> selectedProjectList;
	private Long id;
	private Long repoConfigId;
	
	public Long getBuId() {
	
		return buId;
	}
	
	public List<BusinessUnitTO> getBusinessUnitList() {
	
		return businessUnitList;
	}
	
	public ClientTO getClientTO() {
	
		return clientTO;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public Long getProjectId() {
	
		return projectId;
	}
	
	public List<ProjectsTO> getProjectList() {
	
		return projectList;
	}
	
	public ProjectsTO getProjectsTO() {
	
		return projectsTO;
	}
	
	public Long getRepoConfigId() {
	
		return repoConfigId;
	}
	
	public RepositoryTO getRepositoryTO() {
	
		return repositoryTO;
	}
	
	public List<Long> getSelectedBuList() {
	
		return selectedBuList;
	}
	
	public List<Long> getSelectedProjectList() {
	
		return selectedProjectList;
	}
	
	public void setBuId(Long buId) {
	
		this.buId = buId;
	}
	
	public void setBusinessUnitList(List<BusinessUnitTO> businessUnitList) {
	
		this.businessUnitList = businessUnitList;
	}
	
	public void setClientTO(ClientTO clientTO) {
	
		this.clientTO = clientTO;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setProjectId(Long projectId) {
	
		this.projectId = projectId;
	}
	
	public void setProjectList(List<ProjectsTO> projectList) {
	
		this.projectList = projectList;
	}
	
	public void setProjectsTO(ProjectsTO projectsTO) {
	
		this.projectsTO = projectsTO;
	}
	
	public void setRepoConfigId(Long repoConfigId) {
	
		this.repoConfigId = repoConfigId;
	}
	
	public void setRepositoryTO(RepositoryTO repositoryTO) {
	
		this.repositoryTO = repositoryTO;
	}
	
	public void setSelectedBuList(List<Long> selectedBuList) {
	
		this.selectedBuList = selectedBuList;
	}
	
	public void setSelectedProjectList(List<Long> selectedProjectList) {
	
		this.selectedProjectList = selectedProjectList;
	}
}
