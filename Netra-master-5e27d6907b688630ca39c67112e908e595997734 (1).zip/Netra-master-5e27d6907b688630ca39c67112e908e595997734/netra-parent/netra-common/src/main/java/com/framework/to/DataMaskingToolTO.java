package com.framework.to;

public class DataMaskingToolTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6254284670401638447L;
	private String toolName;
	private String description;
	
	/**
	 * @return the description
	 */
	public String getDescription() {
	
		return description;
	}
	
	/**
	 * @return the toolName
	 */
	public String getToolName() {
	
		return toolName;
	}
	
	/**
	 * @param description
	 *                the description to set
	 */
	public void setDescription(String description) {
	
		this.description = description;
	}
	
	/**
	 * @param toolName
	 *                the toolName to set
	 */
	public void setToolName(String toolName) {
	
		this.toolName = toolName;
	}
}
