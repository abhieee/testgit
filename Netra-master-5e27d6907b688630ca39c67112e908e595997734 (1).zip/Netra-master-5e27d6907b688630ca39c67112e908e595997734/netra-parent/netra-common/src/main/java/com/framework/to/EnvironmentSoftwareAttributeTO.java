package com.framework.to;

import java.io.Serializable;

public class EnvironmentSoftwareAttributeTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3689908111308563705L;
	private Long id;
	private Long envId;
	private Long softwareConfigId;
	private String softwareName;
	private String attributeName;
	private String attributeValue;
	private String attributeValueTemp;
	private String serverName;
	private boolean flag;
	
	public String getAttributeName() {
	
		return attributeName;
	}
	
	public String getAttributeValue() {
	
		return attributeValue;
	}
	
	public String getAttributeValueTemp() {
	
		return attributeValueTemp;
	}
	
	public Long getEnvId() {
	
		return envId;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public String getServerName() {
	
		return serverName;
	}
	
	public Long getSoftwareConfigId() {
	
		return softwareConfigId;
	}
	
	public String getSoftwareName() {
	
		return softwareName;
	}
	
	public boolean isFlag() {
	
		return flag;
	}
	
	public void setAttributeName(String attributeName) {
	
		this.attributeName = attributeName;
	}
	
	public void setAttributeValue(String attributeValue) {
	
		this.attributeValue = attributeValue;
	}
	
	public void setAttributeValueTemp(String attributeValueTemp) {
	
		this.attributeValueTemp = attributeValueTemp;
	}
	
	public void setEnvId(Long envId) {
	
		this.envId = envId;
	}
	
	public void setFlag(boolean flag) {
	
		this.flag = flag;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setServerName(String serverName) {
	
		this.serverName = serverName;
	}
	
	public void setSoftwareConfigId(Long softwareConfigId) {
	
		this.softwareConfigId = softwareConfigId;
	}
	
	public void setSoftwareName(String softwareName) {
	
		this.softwareName = softwareName;
	}
}
