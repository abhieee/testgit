package com.framework.report;

import java.util.Date;

public class EnvLinkedResvDetails {
	
	private String month_name;
	private Date weekend_date;
	private Date previous_weekend_date;
	private String day;
	private int shared_resv_count;
	private int disruptive_resv_count;
	private int locked_resv_count;
	
	public EnvLinkedResvDetails(String month_name, Date weekend_date, Date previous_weekend_date, String day, int shared_resv_count, int disruptive_resv_count, int locked_resv_count) {
	
		this.month_name = month_name;
		this.weekend_date = weekend_date;
		this.previous_weekend_date = previous_weekend_date;
		this.day = day;
		this.shared_resv_count = shared_resv_count;
		this.disruptive_resv_count = disruptive_resv_count;
		this.locked_resv_count = locked_resv_count;
	}
	
	public EnvLinkedResvDetails() {
	
		/* No implementation required at the moment. Method for future use. */
	}
	
	public String getMonth_name() {
	
		return month_name;
	}
	
	public void setMonth_name(String month_name) {
	
		this.month_name = month_name;
	}
	
	public Date getWeekend_date() {
	
		return weekend_date;
	}
	
	public void setWeekend_date(Date weekend_date) {
	
		this.weekend_date = weekend_date;
	}
	
	public String getDay() {
	
		return day;
	}
	
	public void setDay(String day) {
	
		this.day = day;
	}
	
	public int getShared_resv_count() {
	
		return shared_resv_count;
	}
	
	public void setShared_resv_count(int shared_resv_count) {
	
		this.shared_resv_count = shared_resv_count;
	}
	
	public int getDisruptive_resv_count() {
	
		return disruptive_resv_count;
	}
	
	public void setDisruptive_resv_count(int disruptive_resv_count) {
	
		this.disruptive_resv_count = disruptive_resv_count;
	}
	
	public int getLocked_resv_count() {
	
		return locked_resv_count;
	}
	
	public void setLocked_resv_count(int locked_resv_count) {
	
		this.locked_resv_count = locked_resv_count;
	}
	
	public Date getPrevious_weekend_date() {
	
		return previous_weekend_date;
	}
	
	public void setPrevious_weekend_date(Date previous_weekend_date) {
	
		this.previous_weekend_date = previous_weekend_date;
	}
}
