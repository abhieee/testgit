package com.framework.to;

import java.io.Serializable;

public class Monitoring_urlTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long Url_id = null;
	private String url = null;
	private String application_name;
	
	public Monitoring_urlTO() {
	
		/* No implementation required at the moment. Method for future use. */
	}
	
	public String getApplication_name() {
	
		return application_name;
	}
	
	public String getUrl() {
	
		return url;
	}
	
	public Long getUrl_id() {
	
		return Url_id;
	}
	
	public void setApplication_name(String application_name) {
	
		this.application_name = application_name;
	}
	
	public void setUrl(String url) {
	
		this.url = url;
	}
	
	public void setUrl_id(Long url_id) {
	
		Url_id = url_id;
	}
}
