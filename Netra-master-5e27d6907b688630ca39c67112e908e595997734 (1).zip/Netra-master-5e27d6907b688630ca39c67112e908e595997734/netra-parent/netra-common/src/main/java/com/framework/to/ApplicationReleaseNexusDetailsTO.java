package com.framework.to;

import java.io.Serializable;

public class ApplicationReleaseNexusDetailsTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -621896699348294941L;
	private Long id;
	private String nexusUrl;
	private String repositoryId;
	private String groupId;
	private String artifactId;
	private String versionId;
	private String packaging;
	
	public String getArtifactId() {
	
		return artifactId;
	}
	
	public String getGroupId() {
	
		return groupId;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public String getNexusUrl() {
	
		return nexusUrl;
	}
	
	public String getPackaging() {
	
		return packaging;
	}
	
	public String getRepositoryId() {
	
		return repositoryId;
	}
	
	public String getVersionId() {
	
		return versionId;
	}
	
	public void setArtifactId(String artifactId) {
	
		this.artifactId = artifactId;
	}
	
	public void setGroupId(String groupId) {
	
		this.groupId = groupId;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setNexusUrl(String nexusUrl) {
	
		this.nexusUrl = nexusUrl;
	}
	
	public void setPackaging(String packaging) {
	
		this.packaging = packaging;
	}
	
	public void setRepositoryId(String repositoryId) {
	
		this.repositoryId = repositoryId;
	}
	
	public void setVersionId(String versionId) {
	
		this.versionId = versionId;
	}
}
