package com.framework.to;

import java.io.Serializable;

public class ZabbixTriggerFunctionTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8844396941805050048L;
	private Long id;
	private String function_name;
	private String function_formt;
	
	public String getFunction_formt() {
	
		return function_formt;
	}
	
	public String getFunction_name() {
	
		return function_name;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public void setFunction_formt(String function_formt) {
	
		this.function_formt = function_formt;
	}
	
	public void setFunction_name(String function_name) {
	
		this.function_name = function_name;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
}
