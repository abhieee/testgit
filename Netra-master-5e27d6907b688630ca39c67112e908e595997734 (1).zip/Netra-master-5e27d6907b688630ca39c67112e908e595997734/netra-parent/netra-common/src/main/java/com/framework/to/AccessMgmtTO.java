/**
 *
 */
package com.framework.to;

import java.util.HashSet;
import java.util.Set;

/**
 * @author TCS
 */
public class AccessMgmtTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7675286895163044750L;
	private Integer applicationId;
	private String environmentDescription;
	private Set<ReservationTO> reservations = new HashSet<ReservationTO>(0);
	
	/**
	 * @return the applicationId
	 */
	public Integer getApplicationId() {
	
		return applicationId;
	}
	
	/**
	 * @return the environmentDescription
	 */
	public String getEnvironmentDescription() {
	
		return environmentDescription;
	}
	
	/**
	 * @return the reservations
	 */
	public Set<ReservationTO> getReservations() {
	
		return reservations;
	}
	
	/**
	 * @param applicationId
	 *                the applicationId to set
	 */
	public void setApplicationId(Integer applicationId) {
	
		this.applicationId = applicationId;
	}
	
	/**
	 * @param environmentDescription
	 *                the environmentDescription to set
	 */
	public void setEnvironmentDescription(String environmentDescription) {
	
		this.environmentDescription = environmentDescription;
	}
	
	/**
	 * @param reservations
	 *                the reservations to set
	 */
	public void setReservations(Set<ReservationTO> reservations) {
	
		this.reservations = reservations;
	}
}
