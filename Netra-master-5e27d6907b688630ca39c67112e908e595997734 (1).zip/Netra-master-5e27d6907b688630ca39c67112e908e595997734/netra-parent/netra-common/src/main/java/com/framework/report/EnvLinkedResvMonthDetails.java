package com.framework.report;

import java.util.Date;

public class EnvLinkedResvMonthDetails {
	
	private String month;
	private String year;
	private Date monthDate;
	private int sharedResvCount;
	private int disruptiveResvCount;
	private int lockedResvCount;
	
	public EnvLinkedResvMonthDetails() {
	
		/* No implementation required at the moment. Method for future use. */
	}
	
	public EnvLinkedResvMonthDetails(String month, String year, Date monthDate, int sharedResvCount, int disruptiveResvCount, int lockedResvCount) {
	
		this.month = month;
		this.year = year;
		this.monthDate = monthDate;
		this.sharedResvCount = sharedResvCount;
		this.disruptiveResvCount = disruptiveResvCount;
		this.lockedResvCount = lockedResvCount;
	}
	
	public String getMonth() {
	
		return month;
	}
	
	public void setMonth(String month) {
	
		this.month = month;
	}
	
	public String getYear() {
	
		return year;
	}
	
	public void setYear(String year) {
	
		this.year = year;
	}
	
	public Date getMonthDate() {
	
		return monthDate;
	}
	
	public void setMonthDate(Date monthDate) {
	
		this.monthDate = monthDate;
	}
	
	public int getSharedResvCount() {
	
		return sharedResvCount;
	}
	
	public void setSharedResvCount(int sharedResvCount) {
	
		this.sharedResvCount = sharedResvCount;
	}
	
	public int getDisruptiveResvCount() {
	
		return disruptiveResvCount;
	}
	
	public void setDisruptiveResvCount(int disruptiveResvCount) {
	
		this.disruptiveResvCount = disruptiveResvCount;
	}
	
	public int getLockedResvCount() {
	
		return lockedResvCount;
	}
	
	public void setLockedResvCount(int lockedResvCount) {
	
		this.lockedResvCount = lockedResvCount;
	}
}
