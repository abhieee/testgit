package com.framework.puppetMaster.to;

import java.io.Serializable;
import java.util.List;
import com.framework.to.SoftwareconfigTO;

public class PuppetActivitySoftwareMappingTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1506983330536290069L;
	private long activitySoftwareMapId;
	private SoftwareconfigTO softwareconfigTO;
	private PuppetReleaseActivityTO puppetReleaseActivityTO;
	private List<Long> definedPuppetActivities;
	private String stringkey;
	private Long activityId;
	
	public Long getActivityId() {
	
		return activityId;
	}
	
	public long getActivitySoftwareMapId() {
	
		return activitySoftwareMapId;
	}
	
	public List<Long> getDefinedPuppetActivities() {
	
		return definedPuppetActivities;
	}
	
	public PuppetReleaseActivityTO getPuppetReleaseActivityTO() {
	
		return puppetReleaseActivityTO;
	}
	
	public SoftwareconfigTO getSoftwareconfigTO() {
	
		return softwareconfigTO;
	}
	
	public String getStringkey() {
	
		return stringkey;
	}
	
	public void setActivityId(Long activityId) {
	
		this.activityId = activityId;
	}
	
	public void setActivitySoftwareMapId(long activitySoftwareMapId) {
	
		this.activitySoftwareMapId = activitySoftwareMapId;
	}
	
	public void setDefinedPuppetActivities(List<Long> definedPuppetActivities) {
	
		this.definedPuppetActivities = definedPuppetActivities;
	}
	
	public void setPuppetReleaseActivityTO(PuppetReleaseActivityTO puppetReleaseActivityTO) {
	
		this.puppetReleaseActivityTO = puppetReleaseActivityTO;
	}
	
	public void setSoftwareconfigTO(SoftwareconfigTO softwareconfigTO) {
	
		this.softwareconfigTO = softwareconfigTO;
	}
	
	public void setStringkey(String stringkey) {
	
		this.stringkey = stringkey;
	}
}
