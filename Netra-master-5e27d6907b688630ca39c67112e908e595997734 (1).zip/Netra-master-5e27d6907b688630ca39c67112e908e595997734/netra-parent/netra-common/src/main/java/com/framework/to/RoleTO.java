package com.framework.to;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * @author TCS
 */
public class RoleTO extends NamedEntityTO {
	
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private String remarks;
	private Date createdDate;
	private Long status;
	private StatusTO statusTO;
	private Long selectedStatus;
	private int searchCount;
	private int tableSize = 10;
	private Long pageNumber = 1L;
	private int firstResult = 0;
	private Set<RoleLevelTO> roleLevel = new HashSet<RoleLevelTO>(0);
	
	@Override
	public Date getCreatedDate() {
	
		return createdDate;
	}
	
	public int getFirstResult() {
	
		return firstResult;
	}
	
	public Long getPageNumber() {
	
		return pageNumber;
	}
	
	public String getRemarks() {
	
		return remarks;
	}
	
	public Set<RoleLevelTO> getRoleLevel() {
	
		return roleLevel;
	}
	
	public int getSearchCount() {
	
		return searchCount;
	}
	
	public Long getSelectedStatus() {
	
		return selectedStatus;
	}
	
	public Long getStatus() {
	
		return status;
	}
	
	public StatusTO getStatusTO() {
	
		return statusTO;
	}
	
	public int getTableSize() {
	
		return tableSize;
	}
	
	@Override
	public void setCreatedDate(Date createdDate) {
	
		this.createdDate = createdDate;
	}
	
	public void setFirstResult(int firstResult) {
	
		this.firstResult = firstResult;
	}
	
	public void setPageNumber(Long pageNumber) {
	
		this.pageNumber = pageNumber;
	}
	
	public void setRemarks(String remarks) {
	
		this.remarks = remarks;
	}
	
	public void setRoleLevel(Set<RoleLevelTO> roleLevel) {
	
		this.roleLevel = roleLevel;
	}
	
	public void setSearchCount(int searchCount) {
	
		this.searchCount = searchCount;
	}
	
	public void setSelectedStatus(Long selectedStatus) {
	
		this.selectedStatus = selectedStatus;
	}
	
	public void setStatus(Long status) {
	
		this.status = status;
	}
	
	public void setStatusTO(StatusTO statusTO) {
	
		this.statusTO = statusTO;
	}
	
	public void setTableSize(int tableSize) {
	
		this.tableSize = tableSize;
	}
}
