package com.framework.to;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class TemplatesTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4654833316541997174L;
	private Long id;
	private String name;
	private String platformName;
	private String architecture;
	private Long platformId;
	private String description;
	private Byte activeFlag;
	private Long createdBy;
	private Date createdOn;
	private Long updatedBy;
	private Date updatedOn;
	private Set<TemplatesAwsTO> templateAws;
	private Set<TemplateVMWareTO> templateVMware;
	private PlatformMasterTO platform;
	private String cpu;
	private String ram;
	private Long dataCentre;
	
	public TemplatesTO() {
	
		updatedOn = new Date();
		templateAws = new HashSet<TemplatesAwsTO>();
		templateVMware = new HashSet<TemplateVMWareTO>();
	}
	
	public Byte getActiveFlag() {
	
		return activeFlag;
	}
	
	public String getArchitecture() {
	
		return architecture;
	}
	
	public String getCpu() {
	
		return cpu;
	}
	
	public Long getCreatedBy() {
	
		return createdBy;
	}
	
	public Date getCreatedOn() {
	
		return createdOn;
	}
	
	public Long getDataCentre() {
	
		return dataCentre;
	}
	
	public String getDescription() {
	
		return description;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public String getName() {
	
		return name;
	}
	
	public PlatformMasterTO getPlatform() {
	
		return platform;
	}
	
	public Long getPlatformId() {
	
		return platformId;
	}
	
	public String getPlatformName() {
	
		return platformName;
	}
	
	public String getRam() {
	
		return ram;
	}
	
	public Set<TemplatesAwsTO> getTemplateAws() {
	
		return templateAws;
	}
	
	public Set<TemplateVMWareTO> getTemplateVMware() {
	
		return templateVMware;
	}
	
	public Long getUpdatedBy() {
	
		return updatedBy;
	}
	
	public Date getUpdatedOn() {
	
		return updatedOn;
	}
	
	public void setActiveFlag(Byte activeFlag) {
	
		this.activeFlag = activeFlag;
	}
	
	public void setArchitecture(String architecture) {
	
		this.architecture = architecture;
	}
	
	public void setCpu(String cpu) {
	
		this.cpu = cpu;
	}
	
	public void setCreatedBy(Long createdBy) {
	
		this.createdBy = createdBy;
	}
	
	public void setCreatedOn(Date createdOn) {
	
		this.createdOn = createdOn;
	}
	
	public void setDataCentre(Long dataCentre) {
	
		this.dataCentre = dataCentre;
	}
	
	public void setDescription(String description) {
	
		this.description = description;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setName(String name) {
	
		this.name = name;
	}
	
	public void setPlatform(PlatformMasterTO platform) {
	
		this.platform = platform;
	}
	
	public void setPlatformId(Long platformId) {
	
		this.platformId = platformId;
	}
	
	public void setPlatformName(String platformName) {
	
		this.platformName = platformName;
	}
	
	public void setRam(String ram) {
	
		this.ram = ram;
	}
	
	public void setTemplateAws(Set<TemplatesAwsTO> templateAws) {
	
		this.templateAws = templateAws;
	}
	
	public void setTemplateVMware(Set<TemplateVMWareTO> templateVMware) {
	
		this.templateVMware = templateVMware;
	}
	
	public void setUpdatedBy(Long updatedBy) {
	
		this.updatedBy = updatedBy;
	}
	
	public void setUpdatedOn(Date updatedOn) {
	
		this.updatedOn = updatedOn;
	}
}
