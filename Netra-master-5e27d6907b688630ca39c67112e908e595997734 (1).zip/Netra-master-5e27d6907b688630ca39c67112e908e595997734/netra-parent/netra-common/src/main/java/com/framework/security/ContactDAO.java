package com.framework.security;

import java.util.List;
import com.framework.exception.CMMException;

public interface ContactDAO {
	
	List getAllContactNames() throws CMMException;
	
	List getContactDetails(String commonName);
}