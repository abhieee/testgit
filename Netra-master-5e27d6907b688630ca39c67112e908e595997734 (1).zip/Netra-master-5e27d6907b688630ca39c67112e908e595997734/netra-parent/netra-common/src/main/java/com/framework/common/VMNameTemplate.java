package com.framework.common;

public enum VMNameTemplate {
	VM_REQUESTID_EV_ENVIRONMENTID("VM{NUMBER}_{REQUESTID}_EV_{ENVIRONMENTID}");
	
	private String vMNameTemplateType;
	
	private VMNameTemplate(String s) {
	
		this.vMNameTemplateType = s;
	}
	
	public String getVMNameTemplate() {
	
		return vMNameTemplateType;
	}
}
