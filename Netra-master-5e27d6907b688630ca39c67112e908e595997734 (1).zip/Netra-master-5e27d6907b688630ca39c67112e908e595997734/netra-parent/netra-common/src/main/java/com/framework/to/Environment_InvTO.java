/**
 *
 */
package com.framework.to;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @author TCS
 */
public class Environment_InvTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 600296013018627530L;
	private String environmentName;
	private Long status;
	private Set<EnvironmentDetails_InvTO> environmentDetails = new HashSet<EnvironmentDetails_InvTO>(0);
	private Set<ApplicationProfileConfigParamTmpltMappingTO> applicationProfileconfigparamtemplate = new HashSet<ApplicationProfileConfigParamTmpltMappingTO>();
	private List<TestingPhase_InvTO> allTestingCycles = new ArrayList<TestingPhase_InvTO>();
	private TestingPhase_InvTO environmentPhaseTO;
	private String envType;
	
	public List<TestingPhase_InvTO> getAllTestingCycles() {
	
		return allTestingCycles;
	}
	
	public Set<ApplicationProfileConfigParamTmpltMappingTO> getApplicationProfileconfigparamtemplate() {
	
		return applicationProfileconfigparamtemplate;
	}
	
	public Set<EnvironmentDetails_InvTO> getEnvironmentDetails() {
	
		return environmentDetails;
	}
	
	public String getEnvironmentName() {
	
		return environmentName;
	}
	
	public TestingPhase_InvTO getEnvironmentPhaseTO() {
	
		return environmentPhaseTO;
	}
	
	public String getEnvType() {
	
		return envType;
	}
	
	public Long getStatus() {
	
		return status;
	}
	
	public void setAllTestingCycles(List<TestingPhase_InvTO> allTestingCycles) {
	
		this.allTestingCycles = allTestingCycles;
	}
	
	public void setApplicationProfileconfigparamtemplate(Set<ApplicationProfileConfigParamTmpltMappingTO> applicationProfileconfigparamtemplate) {
	
		this.applicationProfileconfigparamtemplate = applicationProfileconfigparamtemplate;
	}
	
	public void setEnvironmentDetails(Set<EnvironmentDetails_InvTO> environmentDetails) {
	
		this.environmentDetails = environmentDetails;
	}
	
	public void setEnvironmentName(String environmentName) {
	
		this.environmentName = environmentName;
	}
	
	public void setEnvironmentPhaseTO(TestingPhase_InvTO environmentPhaseTO) {
	
		this.environmentPhaseTO = environmentPhaseTO;
	}
	
	public void setEnvType(String envType) {
	
		this.envType = envType;
	}
	
	public void setStatus(Long status) {
	
		this.status = status;
	}
}
