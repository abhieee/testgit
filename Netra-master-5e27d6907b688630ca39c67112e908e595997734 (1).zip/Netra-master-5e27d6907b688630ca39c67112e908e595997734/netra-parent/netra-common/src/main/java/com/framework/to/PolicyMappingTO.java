package com.framework.to;

public class PolicyMappingTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2192451200898783696L;
	private Long businessUnitId;
	private Long projectId;
	private Long applicationId;
	private Long policyDetailId;
	private ClientTO clientTo;
	private AddPolicyTO policyDetailTo;
	private ProjectsTO projectsTo;
	private ApplicationTO applicationTo;
	
	public Long getApplicationId() {
	
		return applicationId;
	}
	
	public ApplicationTO getApplicationTo() {
	
		return applicationTo;
	}
	
	public Long getBusinessUnitId() {
	
		return businessUnitId;
	}
	
	public ClientTO getClientTo() {
	
		return clientTo;
	}
	
	public Long getPolicyDetailId() {
	
		return policyDetailId;
	}
	
	public AddPolicyTO getPolicyDetailTo() {
	
		return policyDetailTo;
	}
	
	public Long getProjectId() {
	
		return projectId;
	}
	
	public ProjectsTO getProjectsTo() {
	
		return projectsTo;
	}
	
	public void setApplicationId(Long applicationId) {
	
		this.applicationId = applicationId;
	}
	
	public void setApplicationTo(ApplicationTO applicationTo) {
	
		this.applicationTo = applicationTo;
	}
	
	public void setBusinessUnitId(Long businessUnitId) {
	
		this.businessUnitId = businessUnitId;
	}
	
	public void setClientTo(ClientTO clientTo) {
	
		this.clientTo = clientTo;
	}
	
	public void setPolicyDetailId(Long policyDetailId) {
	
		this.policyDetailId = policyDetailId;
	}
	
	public void setPolicyDetailTo(AddPolicyTO policyDetailTo) {
	
		this.policyDetailTo = policyDetailTo;
	}
	
	public void setProjectId(Long projectId) {
	
		this.projectId = projectId;
	}
	
	public void setProjectsTo(ProjectsTO projectsTo) {
	
		this.projectsTo = projectsTo;
	}
}