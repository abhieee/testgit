package com.framework.to;

import java.io.Serializable;

public class RepoTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8727369552991662012L;
	private Long repoid;
	private String repoName;
	
	public Long getRepoid() {
	
		return repoid;
	}
	
	public String getRepoName() {
	
		return repoName;
	}
	
	public void setRepoid(Long repoid) {
	
		this.repoid = repoid;
	}
	
	public void setRepoName(String repoName) {
	
		this.repoName = repoName;
	}
}
