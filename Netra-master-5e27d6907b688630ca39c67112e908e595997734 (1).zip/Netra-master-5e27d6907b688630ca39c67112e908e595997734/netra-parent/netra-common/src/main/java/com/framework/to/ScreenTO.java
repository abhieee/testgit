package com.framework.to;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @author TCS
 */
public class ScreenTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5338967830054459606L;
	private String actionStr;
	private String adminAccess;
	private String accessIds;
	private List<ScreenTO> childScreens = new ArrayList<ScreenTO>();
	private Set<ScreenTreeTO> screenTreesForChildScreenId = new HashSet<ScreenTreeTO>(0);
	private Set<ScreenTreeTO> screenTreesForParentScreenId = new HashSet<ScreenTreeTO>(0);
	private boolean access;
	
	public String getAccessIds() {
	
		return accessIds;
	}
	
	public String getActionStr() {
	
		return actionStr;
	}
	
	public String getAdminAccess() {
	
		return adminAccess;
	}
	
	public List<ScreenTO> getChildScreens() {
	
		return childScreens;
	}
	
	public Set<ScreenTreeTO> getScreenTreesForChildScreenId() {
	
		return screenTreesForChildScreenId;
	}
	
	public Set<ScreenTreeTO> getScreenTreesForParentScreenId() {
	
		return screenTreesForParentScreenId;
	}
	
	public boolean isAccess() {
	
		return access;
	}
	
	public void setAccess(boolean access) {
	
		this.access = access;
	}
	
	public void setAccessIds(String accessIds) {
	
		this.accessIds = accessIds;
	}
	
	public void setActionStr(String actionStr) {
	
		this.actionStr = actionStr;
	}
	
	public void setAdminAccess(String adminAccess) {
	
		this.adminAccess = adminAccess;
	}
	
	public void setChildScreens(List<ScreenTO> childScreens) {
	
		this.childScreens = childScreens;
	}
	
	public void setScreenTreesForChildScreenId(Set<ScreenTreeTO> screenTreesForChildScreenId) {
	
		this.screenTreesForChildScreenId = screenTreesForChildScreenId;
	}
	
	public void setScreenTreesForParentScreenId(Set<ScreenTreeTO> screenTreesForParentScreenId) {
	
		this.screenTreesForParentScreenId = screenTreesForParentScreenId;
	}
}
