package com.framework.to;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

public class TransformMapConfigTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -490843007838492988L;
	private Long id;
	private String snTableName;
	private String netraTableName;
	private String baseURL;
	private String name;
	private Set<SNColumnMappingTO> snColumnMapping = new HashSet<>(0);
	
	public Long getId() {
	
		return id;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public String getSnTableName() {
	
		return snTableName;
	}
	
	public void setSnTableName(String snTableName) {
	
		this.snTableName = snTableName;
	}
	
	public String getNetraTableName() {
	
		return netraTableName;
	}
	
	public void setNetraTableName(String netraTableName) {
	
		this.netraTableName = netraTableName;
	}
	
	public String getBaseURL() {
	
		return baseURL;
	}
	
	public void setBaseURL(String baseURL) {
	
		this.baseURL = baseURL;
	}
	
	public String getName() {
	
		return name;
	}
	
	public void setName(String name) {
	
		this.name = name;
	}
	
	public Set<SNColumnMappingTO> getSnColumnMapping() {
	
		return snColumnMapping;
	}
	
	public void setSnColumnMapping(Set<SNColumnMappingTO> snColumnMapping) {
	
		this.snColumnMapping = snColumnMapping;
	}
}
