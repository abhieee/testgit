package com.framework.to;

import java.util.HashSet;
import java.util.Set;

public class MachineTemplateTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3523848198789323390L;
	private Long platformTemplateId;
	private String type;
	private String CPU;
	private String RAM;
	private String architecture;
	private Long status;
	private StatusTO statusTO;
	private String username;
	private String password;
	private Set<MachineVMWareTO> machineTemplateVMware;
	private Set<MachineTemplateAwsTO> machineTemplateAws;
	private Set<MachineTemplateBareMetalTO> machineTemplateBareMetal;
	private Set<MachineTemplateOSTO> machineTemplateOSTOSet;
	
	public MachineTemplateTO() {
	
		machineTemplateVMware = new HashSet<MachineVMWareTO>();
		machineTemplateAws = new HashSet<MachineTemplateAwsTO>();
		machineTemplateOSTOSet = new HashSet<MachineTemplateOSTO>();
	}
	
	public String getArchitecture() {
	
		return architecture;
	}
	
	public String getCPU() {
	
		return CPU;
	}
	
	public Set<MachineTemplateAwsTO> getMachineTemplateAws() {
	
		return machineTemplateAws;
	}
	
	/**
	 * @return the machineTemplateBareMetal
	 */
	public Set<MachineTemplateBareMetalTO> getMachineTemplateBareMetal() {
	
		return machineTemplateBareMetal;
	}
	
	public Set<MachineTemplateOSTO> getMachineTemplateOSTOSet() {
	
		return machineTemplateOSTOSet;
	}
	
	public Set<MachineVMWareTO> getMachineTemplateVMware() {
	
		return machineTemplateVMware;
	}
	
	public String getPassword() {
	
		return password;
	}
	
	public Long getPlatformTemplateId() {
	
		return platformTemplateId;
	}
	
	public String getRAM() {
	
		return RAM;
	}
	
	public Long getStatus() {
	
		return status;
	}
	
	public StatusTO getStatusTO() {
	
		return statusTO;
	}
	
	public String getType() {
	
		return type;
	}
	
	public String getUsername() {
	
		return username;
	}
	
	public void setArchitecture(String architecture) {
	
		this.architecture = architecture;
	}
	
	public void setCPU(String cPU) {
	
		CPU = cPU;
	}
	
	public void setMachineTemplateAws(Set<MachineTemplateAwsTO> machineTemplateAws) {
	
		this.machineTemplateAws = machineTemplateAws;
	}
	
	/**
	 * @param machineTemplateBareMetal
	 *                the machineTemplateBareMetal to set
	 */
	public void setMachineTemplateBareMetal(Set<MachineTemplateBareMetalTO> machineTemplateBareMetal) {
	
		this.machineTemplateBareMetal = machineTemplateBareMetal;
	}
	
	public void setMachineTemplateOSTOSet(Set<MachineTemplateOSTO> machineTemplateOSTOSet) {
	
		this.machineTemplateOSTOSet = machineTemplateOSTOSet;
	}
	
	public void setMachineTemplateVMware(Set<MachineVMWareTO> machineTemplateVMware) {
	
		this.machineTemplateVMware = machineTemplateVMware;
	}
	
	public void setPassword(String password) {
	
		this.password = password;
	}
	
	public void setPlatformTemplateId(Long platformTemplateId) {
	
		this.platformTemplateId = platformTemplateId;
	}
	
	public void setRAM(String rAM) {
	
		RAM = rAM;
	}
	
	public void setStatus(Long status) {
	
		this.status = status;
	}
	
	public void setStatusTO(StatusTO statusTO) {
	
		this.statusTO = statusTO;
	}
	
	public void setType(String type) {
	
		this.type = type;
	}
	
	public void setUsername(String username) {
	
		this.username = username;
	}
}
