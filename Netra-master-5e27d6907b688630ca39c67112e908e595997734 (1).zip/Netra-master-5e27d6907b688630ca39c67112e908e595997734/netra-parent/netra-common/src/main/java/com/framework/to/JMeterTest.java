package com.framework.to;

import java.util.HashMap;
import java.util.Map;

public class JMeterTest extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long requestId;
	private String selectedRepo;
	private String scriptsSvnUrl;
	private String svnUserName;
	private String password;
	private String perforceIP;
	private String perforcePort;
	private Map<String, String> propertiesMap;
	private Long applicationReleaseId;
	private Long provisionedMachineId;
	private String scriptCopyLocation;
	private String resultLocation;
	private String toolConfigLocation;
	
	public JMeterTest() {
	
		propertiesMap = new HashMap<String, String>(0);
	}
	
	/**
	 * @return the applicationReleaseId
	 */
	public Long getApplicationReleaseId() {
	
		return applicationReleaseId;
	}
	
	public String getPassword() {
	
		return password;
	}
	
	public String getPerforceIP() {
	
		return perforceIP;
	}
	
	public String getPerforcePort() {
	
		return perforcePort;
	}
	
	public Map<String, String> getPropertiesMap() {
	
		return propertiesMap;
	}
	
	public Long getRequestId() {
	
		return requestId;
	}
	
	public String getScriptsSvnUrl() {
	
		return scriptsSvnUrl;
	}
	
	public String getSvnUserName() {
	
		return svnUserName;
	}
	
	/**
	 * @param applicationReleaseId
	 *                the applicationReleaseId to set
	 */
	public void setApplicationReleaseId(Long applicationReleaseId) {
	
		this.applicationReleaseId = applicationReleaseId;
	}
	
	public void setPassword(String password) {
	
		this.password = password;
	}
	
	public void setPerforceIP(String perforceIP) {
	
		this.perforceIP = perforceIP;
	}
	
	public void setPerforcePort(String perforcePort) {
	
		this.perforcePort = perforcePort;
	}
	
	public void setPropertiesMap(Map<String, String> propertiesMap) {
	
		this.propertiesMap = propertiesMap;
	}
	
	public void setRequestId(Long requestId) {
	
		this.requestId = requestId;
	}
	
	public void setScriptsSvnUrl(String scriptsSvnUrl) {
	
		this.scriptsSvnUrl = scriptsSvnUrl;
	}
	
	public void setSvnUserName(String svnUserName) {
	
		this.svnUserName = svnUserName;
	}
	
	public String getSelectedRepo() {
	
		return selectedRepo;
	}
	
	public void setSelectedRepo(String selectedRepo) {
	
		this.selectedRepo = selectedRepo;
	}
	
	public Long getProvisionedMachineId() {
	
		return provisionedMachineId;
	}
	
	public void setProvisionedMachineId(Long provisionedMachineId) {
	
		this.provisionedMachineId = provisionedMachineId;
	}
	
	public String getScriptCopyLocation() {
	
		return scriptCopyLocation;
	}
	
	public void setScriptCopyLocation(String scriptCopyLocation) {
	
		this.scriptCopyLocation = scriptCopyLocation;
	}
	
	public String getResultLocation() {
	
		return resultLocation;
	}
	
	public void setResultLocation(String resultLocation) {
	
		this.resultLocation = resultLocation;
	}
	
	public String getToolConfigLocation() {
	
		return toolConfigLocation;
	}
	
	public void setToolConfigLocation(String toolConfigLocation) {
	
		this.toolConfigLocation = toolConfigLocation;
	}
}
