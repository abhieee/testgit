package com.framework.to;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class UserGroupTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7810268244009891137L;
	private ApplicationTO applications;
	private List<ApplicationTO> applicationList = null;
	private Long selectedApplication = null;
	private List<UserTO> userList = null;
	private Long selectedUser = null;
	private Set<ApplicationTO> applicationTO = new HashSet<ApplicationTO>();
	private Set<UserGroupDetailsTO> userGroupDetailses = new HashSet<UserGroupDetailsTO>(0);
	
	public List<ApplicationTO> getApplicationList() {
	
		return applicationList;
	}
	
	public ApplicationTO getApplications() {
	
		return applications;
	}
	
	public Set<ApplicationTO> getApplicationTO() {
	
		return applicationTO;
	}
	
	public Long getSelectedApplication() {
	
		return selectedApplication;
	}
	
	public Long getSelectedUser() {
	
		return selectedUser;
	}
	
	public Set<UserGroupDetailsTO> getUserGroupDetailses() {
	
		return userGroupDetailses;
	}
	
	public List<UserTO> getUserList() {
	
		return userList;
	}
	
	public void setApplicationList(List<ApplicationTO> applicationList) {
	
		this.applicationList = applicationList;
	}
	
	public void setApplications(ApplicationTO applications) {
	
		this.applications = applications;
	}
	
	public void setApplicationTO(Set<ApplicationTO> applicationTO) {
	
		this.applicationTO = applicationTO;
	}
	
	public void setSelectedApplication(Long selectedApplication) {
	
		this.selectedApplication = selectedApplication;
	}
	
	public void setSelectedUser(Long selectedUser) {
	
		this.selectedUser = selectedUser;
	}
	
	public void setUserGroupDetailses(Set<UserGroupDetailsTO> userGroupDetailses) {
	
		this.userGroupDetailses = userGroupDetailses;
	}
	
	public void setUserList(List<UserTO> userList) {
	
		this.userList = userList;
	}
}
