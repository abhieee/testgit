package com.framework.to;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MonitoringURLDataTo implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3104467432169580486L;
	private List<MonitoringURLDataTo> directoryList = null;
	private String revision1 = null;
	private String revision2 = null;
	private String directoryData = null;
	private String svnfileName = null;
	private Long Urlid = null;
	private String createdById;
	private Long modifiedbyId;
	private Date createdByDate;
	private Date modifiedbyDate;
	private Long status;
	private Timestamp urlTime;
	private Date svnDate = null;
	private String flagChart = null;
	private String hostIp;
	private String applicationId;
	private Date chartToDate = null;
	private String selectedValue;
	List<ImageTO> imageList = null;
	private String hostId;
	private Long selectedApplication;
	private List<Long> selectedEnvironmentURL = new ArrayList<Long>(0);
	private String monitoringUrl = null;
	private String environment = null;
	private String urlStatus = null;
	private List<MonitoringURLDataTo> completeUrl = null;
	private List<String> EnvironmentCompleteURL = new ArrayList<String>(0);
	private List<String> EnvironmentMonitoringList = new ArrayList<String>(0);
	private List<String> applicationMonitoring = new ArrayList<String>(0);
	private List<Long> selectedApplicationURL = new ArrayList<Long>(0);
	private String directoryName = null;
	private Long directoryId = null;
	private String fileName;
	private String urlName;
	private Date chartDate = null;
	private Long urlstatusid;
	
	public MonitoringURLDataTo() {
	
		/* No implementation required at the moment. Method for future use. */
	}
	
	public String getApplicationId() {
	
		return applicationId;
	}
	
	public List<String> getApplicationMonitoring() {
	
		return applicationMonitoring;
	}
	
	public Date getChartDate() {
	
		return chartDate;
	}
	
	public Date getChartToDate() {
	
		return chartToDate;
	}
	
	public List<MonitoringURLDataTo> getCompleteUrl() {
	
		return completeUrl;
	}
	
	public Date getCreatedByDate() {
	
		return createdByDate;
	}
	
	public String getCreatedById() {
	
		return createdById;
	}
	
	public String getDirectoryData() {
	
		return directoryData;
	}
	
	public Long getDirectoryId() {
	
		return directoryId;
	}
	
	public List<MonitoringURLDataTo> getDirectoryList() {
	
		return directoryList;
	}
	
	public String getDirectoryName() {
	
		return directoryName;
	}
	
	public String getEnvironment() {
	
		return environment;
	}
	
	public List<String> getEnvironmentCompleteURL() {
	
		return EnvironmentCompleteURL;
	}
	
	public List<String> getEnvironmentMonitoringList() {
	
		return EnvironmentMonitoringList;
	}
	
	public String getFileName() {
	
		return fileName;
	}
	
	public String getFlagChart() {
	
		return flagChart;
	}
	
	public String getHostId() {
	
		return hostId;
	}
	
	public String getHostIp() {
	
		return hostIp;
	}
	
	public List<ImageTO> getImageList() {
	
		return imageList;
	}
	
	public Date getModifiedbyDate() {
	
		return modifiedbyDate;
	}
	
	public Long getModifiedbyId() {
	
		return modifiedbyId;
	}
	
	public String getMonitoringUrl() {
	
		return monitoringUrl;
	}
	
	public String getRevision1() {
	
		return revision1;
	}
	
	public String getRevision2() {
	
		return revision2;
	}
	
	public Long getSelectedApplication() {
	
		return selectedApplication;
	}
	
	public List<Long> getSelectedApplicationURL() {
	
		return selectedApplicationURL;
	}
	
	public List<Long> getSelectedEnvironmentURL() {
	
		return selectedEnvironmentURL;
	}
	
	public String getSelectedValue() {
	
		return selectedValue;
	}
	
	public Long getStatus() {
	
		return status;
	}
	
	public Date getSvnDate() {
	
		return svnDate;
	}
	
	public String getSvnfileName() {
	
		return svnfileName;
	}
	
	public Long getUrlid() {
	
		return Urlid;
	}
	
	public String getUrlName() {
	
		return urlName;
	}
	
	public String getUrlStatus() {
	
		return urlStatus;
	}
	
	public Long getUrlstatusid() {
	
		return urlstatusid;
	}
	
	public Date getUrlTime() {
	
		return urlTime;
	}
	
	public void setApplicationId(String applicationId) {
	
		this.applicationId = applicationId;
	}
	
	public void setApplicationMonitoring(List<String> applicationMonitoring) {
	
		this.applicationMonitoring = applicationMonitoring;
	}
	
	public void setChartDate(Date chartDate) {
	
		this.chartDate = chartDate;
	}
	
	public void setChartToDate(Date chartToDate) {
	
		this.chartToDate = chartToDate;
	}
	
	public void setCompleteUrl(List<MonitoringURLDataTo> completeUrl) {
	
		this.completeUrl = completeUrl;
	}
	
	public void setCreatedByDate(Date createdByDate) {
	
		this.createdByDate = createdByDate;
	}
	
	public void setCreatedById(String createdById) {
	
		this.createdById = createdById;
	}
	
	public void setDirectoryData(String directoryData) {
	
		this.directoryData = directoryData;
	}
	
	public void setDirectoryId(Long directoryId) {
	
		this.directoryId = directoryId;
	}
	
	public void setDirectoryList(List<MonitoringURLDataTo> directoryList) {
	
		this.directoryList = directoryList;
	}
	
	public void setDirectoryName(String directoryName) {
	
		this.directoryName = directoryName;
	}
	
	public void setEnvironment(String environment) {
	
		this.environment = environment;
	}
	
	public void setEnvironmentCompleteURL(List<String> environmentCompleteURL) {
	
		EnvironmentCompleteURL = environmentCompleteURL;
	}
	
	public void setEnvironmentMonitoringList(List<String> environmentMonitoringList) {
	
		EnvironmentMonitoringList = environmentMonitoringList;
	}
	
	public void setFileName(String fileName) {
	
		this.fileName = fileName;
	}
	
	public void setFlagChart(String flagChart) {
	
		this.flagChart = flagChart;
	}
	
	public void setHostId(String hostId) {
	
		this.hostId = hostId;
	}
	
	public void setHostIp(String hostIp) {
	
		this.hostIp = hostIp;
	}
	
	public void setImageList(List<ImageTO> imageList) {
	
		this.imageList = imageList;
	}
	
	public void setModifiedbyDate(Date modifiedbyDate) {
	
		this.modifiedbyDate = modifiedbyDate;
	}
	
	public void setModifiedbyId(Long modifiedbyId) {
	
		this.modifiedbyId = modifiedbyId;
	}
	
	public void setMonitoringUrl(String monitoringUrl) {
	
		this.monitoringUrl = monitoringUrl;
	}
	
	public void setRevision1(String revision1) {
	
		this.revision1 = revision1;
	}
	
	public void setRevision2(String revision2) {
	
		this.revision2 = revision2;
	}
	
	public void setSelectedApplication(Long selectedApplication) {
	
		this.selectedApplication = selectedApplication;
	}
	
	public void setSelectedApplicationURL(List<Long> selectedApplicationURL) {
	
		this.selectedApplicationURL = selectedApplicationURL;
	}
	
	public void setSelectedEnvironmentURL(List<Long> selectedEnvironmentURL) {
	
		this.selectedEnvironmentURL = selectedEnvironmentURL;
	}
	
	public void setSelectedValue(String selectedValue) {
	
		this.selectedValue = selectedValue;
	}
	
	public void setStatus(Long status) {
	
		this.status = status;
	}
	
	public void setSvnDate(Date svnDate) {
	
		this.svnDate = svnDate;
	}
	
	public void setSvnfileName(String svnfileName) {
	
		this.svnfileName = svnfileName;
	}
	
	public void setUrlid(Long urlid) {
	
		Urlid = urlid;
	}
	
	public void setUrlName(String urlName) {
	
		this.urlName = urlName;
	}
	
	public void setUrlStatus(String urlStatus) {
	
		this.urlStatus = urlStatus;
	}
	
	public void setUrlstatusid(Long urlstatusid) {
	
		this.urlstatusid = urlstatusid;
	}
	
	public void setUrlTime(Timestamp urlTime) {
	
		this.urlTime = urlTime;
	}
}
