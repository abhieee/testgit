package com.framework.to;

public class LDAPDetailsTO {
	
	private Long id;
	private String serverName;
	private String serverIp;
	private String serverPort;
	private String domain;
	private String base;
	private String username;
	private String password;
	
	public String getBase() {
	
		return base;
	}
	
	public String getDomain() {
	
		return domain;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public String getPassword() {
	
		return password;
	}
	
	public String getServerIp() {
	
		return serverIp;
	}
	
	public String getServerName() {
	
		return serverName;
	}
	
	public String getServerPort() {
	
		return serverPort;
	}
	
	public String getUsername() {
	
		return username;
	}
	
	public void setBase(String base) {
	
		this.base = base;
	}
	
	public void setDomain(String domain) {
	
		this.domain = domain;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setPassword(String password) {
	
		this.password = password;
	}
	
	public void setServerIp(String serverIp) {
	
		this.serverIp = serverIp;
	}
	
	public void setServerName(String serverName) {
	
		this.serverName = serverName;
	}
	
	public void setServerPort(String serverPort) {
	
		this.serverPort = serverPort;
	}
	
	public void setUsername(String username) {
	
		this.username = username;
	}
}
