package com.framework.udeploy.to;

import java.util.List;
import com.framework.to.SoftwareconfigTO;

public class UdeployActivitySoftwareMappingTO {
	
	private long activitySoftwareMapId;
	private SoftwareconfigTO softwareconfigTO;
	private UdeployReleaseActivityTO udeployReleaseActivityTO;
	private List<Long> definedUdeployActivities;
	private String stringkey;
	private Long activityId;
	
	public Long getActivityId() {
	
		return activityId;
	}
	
	public long getActivitySoftwareMapId() {
	
		return activitySoftwareMapId;
	}
	
	public List<Long> getDefinedUdeployActivities() {
	
		return definedUdeployActivities;
	}
	
	public SoftwareconfigTO getSoftwareconfigTO() {
	
		return softwareconfigTO;
	}
	
	public String getStringkey() {
	
		return stringkey;
	}
	
	public UdeployReleaseActivityTO getUdeployReleaseActivityTO() {
	
		return udeployReleaseActivityTO;
	}
	
	public void setActivityId(Long activityId) {
	
		this.activityId = activityId;
	}
	
	public void setActivitySoftwareMapId(long activitySoftwareMapId) {
	
		this.activitySoftwareMapId = activitySoftwareMapId;
	}
	
	public void setDefinedUdeployActivities(List<Long> definedUdeployActivities) {
	
		this.definedUdeployActivities = definedUdeployActivities;
	}
	
	public void setSoftwareconfigTO(SoftwareconfigTO softwareconfigTO) {
	
		this.softwareconfigTO = softwareconfigTO;
	}
	
	public void setStringkey(String stringkey) {
	
		this.stringkey = stringkey;
	}
	
	public void setUdeployReleaseActivityTO(UdeployReleaseActivityTO udeployReleaseActivityTO) {
	
		this.udeployReleaseActivityTO = udeployReleaseActivityTO;
	}
}
