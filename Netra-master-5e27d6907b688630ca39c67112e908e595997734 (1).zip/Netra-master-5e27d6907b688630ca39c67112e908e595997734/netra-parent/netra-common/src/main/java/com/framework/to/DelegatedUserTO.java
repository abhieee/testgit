package com.framework.to;

public class DelegatedUserTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long id;
	private Long userId;
	private Long delegatedUserId;
	
	@Override
	public Long getId() {
	
		return id;
	}
	
	@Override
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public Long getUserId() {
	
		return userId;
	}
	
	public void setUserId(Long userId) {
	
		this.userId = userId;
	}
	
	public Long getDelegatedUserId() {
	
		return delegatedUserId;
	}
	
	public void setDelegatedUserId(Long delegatedUserId) {
	
		this.delegatedUserId = delegatedUserId;
	}
}
