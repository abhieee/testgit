package com.framework.to;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

public class WorkflowStatusTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1360996373519754926L;
	private Long id;
	private String statusName;
	private Set<WorkflowCurrentTO> workflowCurrentTO = new HashSet<WorkflowCurrentTO>();
	private Set<WorkflowHistoryTO> workflowHistoryTO = new HashSet<WorkflowHistoryTO>();
	
	public Long getId() {
	
		return id;
	}
	
	public String getStatusName() {
	
		return statusName;
	}
	
	public Set<WorkflowCurrentTO> getWorkflowCurrentTO() {
	
		return workflowCurrentTO;
	}
	
	public Set<WorkflowHistoryTO> getWorkflowHistoryTO() {
	
		return workflowHistoryTO;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setStatusName(String statusName) {
	
		this.statusName = statusName;
	}
	
	public void setWorkflowCurrentTO(Set<WorkflowCurrentTO> workflowCurrentTO) {
	
		this.workflowCurrentTO = workflowCurrentTO;
	}
	
	public void setWorkflowHistoryTO(Set<WorkflowHistoryTO> workflowHistoryTO) {
	
		this.workflowHistoryTO = workflowHistoryTO;
	}
}
