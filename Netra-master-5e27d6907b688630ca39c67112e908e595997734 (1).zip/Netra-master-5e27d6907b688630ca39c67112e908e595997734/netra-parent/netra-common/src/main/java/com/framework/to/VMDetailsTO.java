package com.framework.to;

import java.util.ArrayList;
import java.util.List;

public class VMDetailsTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -9210483161576869894L;
	private String ip;
	private EnvironmentTO environmentTO;
	private ServiceRequestTO requestTO;
	private HardwareTO hardwareTO;
	private String serverName;
	private String vmName;
	private Long environmentId;
	private Long selectedEnvironment;
	private Long serverTemplateId;
	private Long memory;
	private Long cpuNo;
	private boolean access;
	private long serverGroupId;
	private long serviceRequestId;
	private List<VMDetailsTO> vmList = new ArrayList<VMDetailsTO>();
	private Long machineId;
	
	public Long getCpuNo() {
	
		return cpuNo;
	}
	
	public Long getEnvironmentId() {
	
		return environmentId;
	}
	
	public EnvironmentTO getEnvironmentTO() {
	
		return environmentTO;
	}
	
	public HardwareTO getHardwareTO() {
	
		return hardwareTO;
	}
	
	public String getIp() {
	
		return ip;
	}
	
	public Long getMachineId() {
	
		return machineId;
	}
	
	public Long getMemory() {
	
		return memory;
	}
	
	public ServiceRequestTO getRequestTO() {
	
		return requestTO;
	}
	
	public Long getSelectedEnvironment() {
	
		return selectedEnvironment;
	}
	
	public long getServerGroupId() {
	
		return serverGroupId;
	}
	
	public String getServerName() {
	
		return serverName;
	}
	
	public Long getServerTemplateId() {
	
		return serverTemplateId;
	}
	
	public long getServiceRequestId() {
	
		return serviceRequestId;
	}
	
	public List<VMDetailsTO> getVmList() {
	
		return vmList;
	}
	
	public String getVmName() {
	
		return vmName;
	}
	
	public boolean isAccess() {
	
		return access;
	}
	
	public void setAccess(boolean access) {
	
		this.access = access;
	}
	
	public void setCpuNo(Long cpuNo) {
	
		this.cpuNo = cpuNo;
	}
	
	public void setEnvironmentId(Long environmentId) {
	
		this.environmentId = environmentId;
	}
	
	public void setEnvironmentTO(EnvironmentTO environmentTO) {
	
		this.environmentTO = environmentTO;
	}
	
	public void setHardwareTO(HardwareTO hardwareTO) {
	
		this.hardwareTO = hardwareTO;
	}
	
	public void setIp(String ip) {
	
		this.ip = ip;
	}
	
	public void setMachineId(Long machineId) {
	
		this.machineId = machineId;
	}
	
	public void setMemory(Long memory) {
	
		this.memory = memory;
	}
	
	public void setRequestTO(ServiceRequestTO requestTO) {
	
		this.requestTO = requestTO;
	}
	
	public void setSelectedEnvironment(Long selectedEnvironment) {
	
		this.selectedEnvironment = selectedEnvironment;
	}
	
	public void setServerGroupId(long serverGroupId) {
	
		this.serverGroupId = serverGroupId;
	}
	
	public void setServerName(String serverName) {
	
		this.serverName = serverName;
	}
	
	public void setServerTemplateId(Long serverTemplateId) {
	
		this.serverTemplateId = serverTemplateId;
	}
	
	public void setServiceRequestId(long serviceRequestId) {
	
		this.serviceRequestId = serviceRequestId;
	}
	
	public void setVmList(List<VMDetailsTO> vmList) {
	
		this.vmList = vmList;
	}
	
	public void setVmName(String vmName) {
	
		this.vmName = vmName;
	}
}
