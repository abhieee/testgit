package com.framework.to;

import java.io.Serializable;

public class ApplicationProfileDockerTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7725998380945195708L;
	private Long id;
	private String imageId;
	private String repository;
	private String tags;
	private String serverIp;
	private Long virtualSize;
	private Long profileId;
	
	public ApplicationProfileDockerTO() {
	
		/* No implementation required at the moment. Method for future use. */
	}
	
	public Long getId() {
	
		return id;
	}
	
	public String getImageId() {
	
		return imageId;
	}
	
	public Long getProfileId() {
	
		return profileId;
	}
	
	public String getRepository() {
	
		return repository;
	}
	
	public String getServerIp() {
	
		return serverIp;
	}
	
	public String getTags() {
	
		return tags;
	}
	
	public Long getVirtualSize() {
	
		return virtualSize;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setImageId(String imageId) {
	
		this.imageId = imageId;
	}
	
	public void setProfileId(Long profileId) {
	
		this.profileId = profileId;
	}
	
	public void setRepository(String repository) {
	
		this.repository = repository;
	}
	
	public void setServerIp(String serverIp) {
	
		this.serverIp = serverIp;
	}
	
	public void setTags(String tags) {
	
		this.tags = tags;
	}
	
	public void setVirtualSize(Long virtualSize) {
	
		this.virtualSize = virtualSize;
	}
}
