package com.framework.common;

public enum DiskMode {
	persistent("persistent");
	
	private String statusCode;
	
	private DiskMode(String s) {
	
		statusCode = s;
	}
	
	public String getStatusCode() {
	
		return statusCode;
	}
}
