package com.framework.to;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ApplicationProfilesServerSetTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6039225170474660562L;
	private String machineType;
	private String hardwareDetailsName;
	private Long hardwareId;
	private ApplicationProfileDockerTO dockerImages = new ApplicationProfileDockerTO();
	private String keyName;
	private String placement;
	private String instanceName;
	private String securityGroupIds;
	private List<String> softwareConfigIds;
	private List<ApplicationProfilesServerSoftwareSetTO> softwareSet = new ArrayList<ApplicationProfilesServerSoftwareSetTO>(0);
	private String friendlyServerName;
	private String hardwareName;
	private String os;
	private String processor;
	private String storage;
	private String storageTier;
	private String cpuSpeed;
	private String systemType;
	private Long sharing;
	private List<SoftwareTO> softwareList = new ArrayList<SoftwareTO>(0);
	private Long machineId;
	private Long awsAccountId;
	private String instanceType;
	private String keyPair;
	private String availabilityZone;
	private String securityGroups;
	private Long templateId;
	private boolean flag;
	private Long applicationProfileDetailId;
	private Long platformTemplateId;
	private Long machineTemplateId;
	
	public Long getApplicationProfileDetailId() {
	
		return applicationProfileDetailId;
	}
	
	public String getAvailabilityZone() {
	
		return availabilityZone;
	}
	
	public Long getAwsAccountId() {
	
		return awsAccountId;
	}
	
	public String getCpuSpeed() {
	
		return cpuSpeed;
	}
	
	public ApplicationProfileDockerTO getDockerImages() {
	
		return dockerImages;
	}
	
	public String getFriendlyServerName() {
	
		return friendlyServerName;
	}
	
	public String getHardwareDetailsName() {
	
		return hardwareDetailsName;
	}
	
	public Long getHardwareId() {
	
		return hardwareId;
	}
	
	public String getHardwareName() {
	
		return hardwareName;
	}
	
	public String getInstanceName() {
	
		return instanceName;
	}
	
	public String getInstanceType() {
	
		return instanceType;
	}
	
	public String getKeyName() {
	
		return keyName;
	}
	
	public String getKeyPair() {
	
		return keyPair;
	}
	
	public Long getMachineId() {
	
		return machineId;
	}
	
	public Long getMachineTemplateId() {
	
		return machineTemplateId;
	}
	
	public String getMachineType() {
	
		return machineType;
	}
	
	public String getOs() {
	
		return os;
	}
	
	public String getPlacement() {
	
		return placement;
	}
	
	public Long getPlatformTemplateId() {
	
		return platformTemplateId;
	}
	
	public String getProcessor() {
	
		return processor;
	}
	
	public String getSecurityGroupIds() {
	
		return securityGroupIds;
	}
	
	public String getSecurityGroups() {
	
		return securityGroups;
	}
	
	public Long getSharing() {
	
		return sharing;
	}
	
	public List<String> getSoftwareConfigIds() {
	
		return softwareConfigIds;
	}
	
	public List<SoftwareTO> getSoftwareList() {
	
		return softwareList;
	}
	
	public List<ApplicationProfilesServerSoftwareSetTO> getSoftwareSet() {
	
		return softwareSet;
	}
	
	public String getStorage() {
	
		return storage;
	}
	
	public String getStorageTier() {
	
		return storageTier;
	}
	
	public String getSystemType() {
	
		return systemType;
	}
	
	public Long getTemplateId() {
	
		return templateId;
	}
	
	public boolean isFlag() {
	
		return flag;
	}
	
	public void setApplicationProfileDetailId(Long applicationProfileDetailId) {
	
		this.applicationProfileDetailId = applicationProfileDetailId;
	}
	
	public void setAvailabilityZone(String availabilityZone) {
	
		this.availabilityZone = availabilityZone;
	}
	
	public void setAwsAccountId(Long awsAccountId) {
	
		this.awsAccountId = awsAccountId;
	}
	
	public void setCpuSpeed(String cpuSpeed) {
	
		this.cpuSpeed = cpuSpeed;
	}
	
	public void setDockerImages(ApplicationProfileDockerTO dockerImages) {
	
		this.dockerImages = dockerImages;
	}
	
	public void setFlag(boolean flag) {
	
		this.flag = flag;
	}
	
	public void setFriendlyServerName(String friendlyServerName) {
	
		this.friendlyServerName = friendlyServerName;
	}
	
	public void setHardwareDetailsName(String hardwareDetailsName) {
	
		this.hardwareDetailsName = hardwareDetailsName;
	}
	
	public void setHardwareId(Long hardwareId) {
	
		this.hardwareId = hardwareId;
	}
	
	public void setHardwareName(String hardwareName) {
	
		this.hardwareName = hardwareName;
	}
	
	public void setInstanceName(String instanceName) {
	
		this.instanceName = instanceName;
	}
	
	public void setInstanceType(String instanceType) {
	
		this.instanceType = instanceType;
	}
	
	public void setKeyName(String keyName) {
	
		this.keyName = keyName;
	}
	
	public void setKeyPair(String keyPair) {
	
		this.keyPair = keyPair;
	}
	
	public void setMachineId(Long machineId) {
	
		this.machineId = machineId;
	}
	
	public void setMachineTemplateId(Long machineTemplateId) {
	
		this.machineTemplateId = machineTemplateId;
	}
	
	public void setMachineType(String machineType) {
	
		this.machineType = machineType;
	}
	
	public void setOs(String os) {
	
		this.os = os;
	}
	
	public void setPlacement(String placement) {
	
		this.placement = placement;
	}
	
	public void setPlatformTemplateId(Long platformTemplateId) {
	
		this.platformTemplateId = platformTemplateId;
	}
	
	public void setProcessor(String processor) {
	
		this.processor = processor;
	}
	
	public void setSecurityGroupIds(String securityGroupIds) {
	
		this.securityGroupIds = securityGroupIds;
	}
	
	public void setSecurityGroups(String securityGroups) {
	
		this.securityGroups = securityGroups;
	}
	
	public void setSharing(Long sharing) {
	
		this.sharing = sharing;
	}
	
	public void setSoftwareConfigIds(List<String> softwareConfigIds) {
	
		this.softwareConfigIds = softwareConfigIds;
	}
	
	public void setSoftwareList(List<SoftwareTO> softwareList) {
	
		this.softwareList = softwareList;
	}
	
	public void setSoftwareSet(List<ApplicationProfilesServerSoftwareSetTO> softwareSet) {
	
		this.softwareSet = softwareSet;
	}
	
	public void setStorage(String storage) {
	
		this.storage = storage;
	}
	
	public void setStorageTier(String storageTier) {
	
		this.storageTier = storageTier;
	}
	
	public void setSystemType(String systemType) {
	
		this.systemType = systemType;
	}
	
	public void setTemplateId(Long templateId) {
	
		this.templateId = templateId;
	}
}
