package com.framework.to;

import java.io.Serializable;

public class MachinePhysicalTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8015206797612595070L;
	private Long id;
	private Long hardwareId;
	private MachineTO machine;
	private HardwareTO hardware;
	
	public HardwareTO getHardware() {
	
		return hardware;
	}
	
	public Long getHardwareId() {
	
		return hardwareId;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public MachineTO getMachine() {
	
		return machine;
	}
	
	public void setHardware(HardwareTO hardware) {
	
		this.hardware = hardware;
	}
	
	public void setHardwareId(Long hardwareId) {
	
		this.hardwareId = hardwareId;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setMachine(MachineTO machine) {
	
		this.machine = machine;
	}
}
