package com.framework.to;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class WorkflowCurrentTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2973413047767380919L;
	private Long reqId;
	private Long wfAction;
	private Long appId;
	private Long wfStatus;
	private ApplicationTO appTO = new ApplicationTO();
	private Long applicationId;
	private Date createdby;
	private BusinessUnitTO businessUnitTO = new BusinessUnitTO();
	private ProjectsTO projectsTO = new ProjectsTO();
	private EnvironmentTO environmentTO = new EnvironmentTO();
	private WorkflowStatusTO wfStatusTO = new WorkflowStatusTO();
	private UserTO userTO = new UserTO();
	private WorkFlowTO workFlowTO = new WorkFlowTO();
	private Long entity_id;
	private String fromDate;
	private String toDate;
	private String fromDatestr;
	private String toDatestr;
	private Long levelOrder;
	private Long clientId;
	private Long currentOwner;
	private String currentOwnerName;
	private Long projectId;
	private Date requestDate;
	private Long loggedInUser;
	private Long serviceRequestId;
	private String disruptive;
	private Set<WorkflowHistoryTO> workflowHistoryTO = new HashSet<WorkflowHistoryTO>();
	private Long selectedApp = null;
	private Long selectedWorkFlowAction = null;
	private Long requestId = null;
	private Long environmentId;
	private String deploymentPipelineFlag;
	private List<Long> clientIdList;
	private int searchCount;
	private int tableSize = 10;
	private Long pageNumber = 1L;
	private int firstResult = 0;
	private String createdByUser;
	private Long selectedStatus = null;
	private Date createdByDate;
	private Date modifiedbyDate;
	private String releasePlanName;
	private String testingPhaseName;
	
	public Long getAppId() {
	
		return appId;
	}
	
	public Long getApplicationId() {
	
		return applicationId;
	}
	
	public ApplicationTO getAppTO() {
	
		return appTO;
	}
	
	public BusinessUnitTO getBusinessUnitTO() {
	
		return businessUnitTO;
	}
	
	public Long getClientId() {
	
		return clientId;
	}
	
	public List<Long> getClientIdList() {
	
		return clientIdList;
	}
	
	public Date getCreatedby() {
	
		return createdby;
	}
	
	public Date getCreatedByDate() {
	
		return createdByDate;
	}
	
	public String getCreatedByUser() {
	
		return createdByUser;
	}
	
	public Long getCurrentOwner() {
	
		return currentOwner;
	}
	
	public String getCurrentOwnerName() {
	
		return currentOwnerName;
	}
	
	public String getDeploymentPipelineFlag() {
	
		return deploymentPipelineFlag;
	}
	
	public String getDisruptive() {
	
		return disruptive;
	}
	
	public Long getEntity_id() {
	
		return entity_id;
	}
	
	public Long getEnvironmentId() {
	
		return environmentId;
	}
	
	public EnvironmentTO getEnvironmentTO() {
	
		return environmentTO;
	}
	
	public int getFirstResult() {
	
		return firstResult;
	}
	
	public String getFromDate() {
	
		return fromDate;
	}
	
	public String getFromDatestr() {
	
		return fromDatestr;
	}
	
	public Long getLevelOrder() {
	
		return levelOrder;
	}
	
	public Long getLoggedInUser() {
	
		return loggedInUser;
	}
	
	public Date getModifiedbyDate() {
	
		return modifiedbyDate;
	}
	
	public Long getPageNumber() {
	
		return pageNumber;
	}
	
	public Long getProjectId() {
	
		return projectId;
	}
	
	public ProjectsTO getProjectsTO() {
	
		return projectsTO;
	}
	
	public Long getReqId() {
	
		return reqId;
	}
	
	public Date getRequestDate() {
	
		return requestDate;
	}
	
	public Long getRequestId() {
	
		return requestId;
	}
	
	public int getSearchCount() {
	
		return searchCount;
	}
	
	public Long getSelectedApp() {
	
		return selectedApp;
	}
	
	public Long getSelectedStatus() {
	
		return selectedStatus;
	}
	
	public Long getSelectedWorkFlowAction() {
	
		return selectedWorkFlowAction;
	}
	
	public Long getServiceRequestId() {
	
		return serviceRequestId;
	}
	
	public int getTableSize() {
	
		return tableSize;
	}
	
	public String getToDate() {
	
		return toDate;
	}
	
	public String getToDatestr() {
	
		return toDatestr;
	}
	
	public UserTO getUserTO() {
	
		return userTO;
	}
	
	public Long getWfAction() {
	
		return wfAction;
	}
	
	public Long getWfStatus() {
	
		return wfStatus;
	}
	
	public WorkflowStatusTO getWfStatusTO() {
	
		return wfStatusTO;
	}
	
	public Set<WorkflowHistoryTO> getWorkflowHistoryTO() {
	
		return workflowHistoryTO;
	}
	
	public WorkFlowTO getWorkFlowTO() {
	
		return workFlowTO;
	}
	
	public void setAppId(Long appId) {
	
		this.appId = appId;
	}
	
	public void setApplicationId(Long applicationId) {
	
		this.applicationId = applicationId;
	}
	
	public void setAppTO(ApplicationTO appTO) {
	
		this.appTO = appTO;
	}
	
	public void setBusinessUnitTO(BusinessUnitTO businessUnitTO) {
	
		this.businessUnitTO = businessUnitTO;
	}
	
	public void setClientId(Long clientId) {
	
		this.clientId = clientId;
	}
	
	public void setClientIdList(List<Long> clientIdList) {
	
		this.clientIdList = clientIdList;
	}
	
	public void setCreatedby(Date createdby) {
	
		this.createdby = createdby;
	}
	
	public void setCreatedByDate(Date createdByDate) {
	
		this.createdByDate = createdByDate;
	}
	
	public void setCreatedByUser(String createdByUser) {
	
		this.createdByUser = createdByUser;
	}
	
	public void setCurrentOwner(Long currentOwner) {
	
		this.currentOwner = currentOwner;
	}
	
	public void setCurrentOwnerName(String currentOwnerName) {
	
		this.currentOwnerName = currentOwnerName;
	}
	
	public void setDeploymentPipelineFlag(String deploymentPipelineFlag) {
	
		this.deploymentPipelineFlag = deploymentPipelineFlag;
	}
	
	public void setDisruptive(String disruptive) {
	
		this.disruptive = disruptive;
	}
	
	public void setEntity_id(Long entity_id) {
	
		this.entity_id = entity_id;
	}
	
	public void setEnvironmentId(Long environmentId) {
	
		this.environmentId = environmentId;
	}
	
	public void setEnvironmentTO(EnvironmentTO environmentTO) {
	
		this.environmentTO = environmentTO;
	}
	
	public void setFirstResult(int firstResult) {
	
		this.firstResult = firstResult;
	}
	
	public void setFromDate(String fromDate) {
	
		this.fromDate = fromDate;
	}
	
	public void setFromDatestr(String fromDatestr) {
	
		this.fromDatestr = fromDatestr;
	}
	
	public void setLevelOrder(Long levelOrder) {
	
		this.levelOrder = levelOrder;
	}
	
	public void setLoggedInUser(Long loggedInUser) {
	
		this.loggedInUser = loggedInUser;
	}
	
	public void setModifiedbyDate(Date modifiedbyDate) {
	
		this.modifiedbyDate = modifiedbyDate;
	}
	
	public void setPageNumber(Long pageNumber) {
	
		this.pageNumber = pageNumber;
	}
	
	public void setProjectId(Long projectId) {
	
		this.projectId = projectId;
	}
	
	public void setProjectsTO(ProjectsTO projectsTO) {
	
		this.projectsTO = projectsTO;
	}
	
	public void setReqId(Long reqId) {
	
		this.reqId = reqId;
	}
	
	public void setRequestDate(Date requestDate) {
	
		this.requestDate = requestDate;
	}
	
	public void setRequestId(Long requestId) {
	
		this.requestId = requestId;
	}
	
	public void setSearchCount(int searchCount) {
	
		this.searchCount = searchCount;
	}
	
	public void setSelectedApp(Long selectedApp) {
	
		this.selectedApp = selectedApp;
	}
	
	public void setSelectedStatus(Long selectedStatus) {
	
		this.selectedStatus = selectedStatus;
	}
	
	public void setSelectedWorkFlowAction(Long selectedWorkFlowAction) {
	
		this.selectedWorkFlowAction = selectedWorkFlowAction;
	}
	
	public void setServiceRequestId(Long serviceRequestId) {
	
		this.serviceRequestId = serviceRequestId;
	}
	
	public void setTableSize(int tableSize) {
	
		this.tableSize = tableSize;
	}
	
	public void setToDate(String toDate) {
	
		this.toDate = toDate;
	}
	
	public void setToDatestr(String toDatestr) {
	
		this.toDatestr = toDatestr;
	}
	
	public void setUserTO(UserTO userTO) {
	
		this.userTO = userTO;
	}
	
	public void setWfAction(Long wfAction) {
	
		this.wfAction = wfAction;
	}
	
	public void setWfStatus(Long wfStatus) {
	
		this.wfStatus = wfStatus;
	}
	
	public void setWfStatusTO(WorkflowStatusTO wfStatusTO) {
	
		this.wfStatusTO = wfStatusTO;
	}
	
	public void setWorkflowHistoryTO(Set<WorkflowHistoryTO> workflowHistoryTO) {
	
		this.workflowHistoryTO = workflowHistoryTO;
	}
	
	public void setWorkFlowTO(WorkFlowTO workFlowTO) {
	
		this.workFlowTO = workFlowTO;
	}
	
	public String getTestingPhaseName() {
	
		return testingPhaseName;
	}
	
	public void setTestingPhaseName(String testingPhaseName) {
	
		this.testingPhaseName = testingPhaseName;
	}
	
	public String getReleasePlanName() {
	
		return releasePlanName;
	}
	
	public void setReleasePlanName(String releasePlanName) {
	
		this.releasePlanName = releasePlanName;
	}
}
