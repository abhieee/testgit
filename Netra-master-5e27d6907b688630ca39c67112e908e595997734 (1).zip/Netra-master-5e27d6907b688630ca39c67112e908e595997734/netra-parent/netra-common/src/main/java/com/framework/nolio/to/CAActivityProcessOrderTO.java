/**
 *
 */
package com.framework.nolio.to;

import java.io.Serializable;
import com.framework.to.ActivitySoftwareMappingTO;

/**
 * @author 460650
 */
public class CAActivityProcessOrderTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6285017361238758701L;
	private long activtyProcessId;
	private ActivitySoftwareMappingTO activitySoftwareMappingTO;
	private NolioProcessSoftwareMapping nolioProcessSoftwareMapping;
	private long processOrder;
	
	public ActivitySoftwareMappingTO getActivitySoftwareMappingTO() {
	
		return activitySoftwareMappingTO;
	}
	
	public long getActivtyProcessId() {
	
		return activtyProcessId;
	}
	
	public NolioProcessSoftwareMapping getNolioProcessSoftwareMapping() {
	
		return nolioProcessSoftwareMapping;
	}
	
	public long getProcessOrder() {
	
		return processOrder;
	}
	
	public void setActivitySoftwareMappingTO(ActivitySoftwareMappingTO activitySoftwareMappingTO) {
	
		this.activitySoftwareMappingTO = activitySoftwareMappingTO;
	}
	
	public void setActivtyProcessId(long activtyProcessId) {
	
		this.activtyProcessId = activtyProcessId;
	}
	
	public void setNolioProcessSoftwareMapping(NolioProcessSoftwareMapping nolioProcessSoftwareMapping) {
	
		this.nolioProcessSoftwareMapping = nolioProcessSoftwareMapping;
	}
	
	public void setProcessOrder(long processOrder) {
	
		this.processOrder = processOrder;
	}
}
