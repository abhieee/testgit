package com.framework.to;

import java.io.Serializable;

public class SonarReportsDetailTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 9202413197253362919L;
	private long id;
	private long applicationId;
	private long applicationReleaseId;
	private String folderName;
	
	public long getApplicationId() {
	
		return applicationId;
	}
	
	public long getApplicationReleaseId() {
	
		return applicationReleaseId;
	}
	
	public String getFolderName() {
	
		return folderName;
	}
	
	public long getId() {
	
		return id;
	}
	
	public void setApplicationId(long applicationId) {
	
		this.applicationId = applicationId;
	}
	
	public void setApplicationReleaseId(long applicationReleaseId) {
	
		this.applicationReleaseId = applicationReleaseId;
	}
	
	public void setFolderName(String folderName) {
	
		this.folderName = folderName;
	}
	
	public void setId(long id) {
	
		this.id = id;
	}
}
