package com.framework.to;

public class ServiceRequestDetailsTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8401421009136992408L;
	private Long vmId;
	private Long requestId;
	private VMDetailsTO vmDetailsTO;
	private ServiceRequestTO requestTO;
	private Long profileId;
	private Long applicationId;
	private Long environmentId;
	private Long provisionedMachineId;
	private Long selectedApplicationRelease;
	private EnvironmentTO environment;
	private Long environmentdetailsId;
	private String filename;
	private String filePath;
	private String agentType;
	private String WarName;
	private Long softwaresRequested;
	//servicenow
	private Long tMapID;
	
	//servicenow
	public String getAgentType() {
	
		return agentType;
	}
	
	public Long getApplicationId() {
	
		return applicationId;
	}
	
	public EnvironmentTO getEnvironment() {
	
		return environment;
	}
	
	public Long getEnvironmentdetailsId() {
	
		return environmentdetailsId;
	}
	
	public Long getEnvironmentId() {
	
		return environmentId;
	}
	
	public String getFilename() {
	
		return filename;
	}
	
	public String getFilePath() {
	
		return filePath;
	}
	
	public Long getProfileId() {
	
		return profileId;
	}
	
	public Long getProvisionedMachineId() {
	
		return provisionedMachineId;
	}
	
	public Long getRequestId() {
	
		return requestId;
	}
	
	public ServiceRequestTO getRequestTO() {
	
		return requestTO;
	}
	
	public Long getSelectedApplicationRelease() {
	
		return selectedApplicationRelease;
	}
	
	public Long getSoftwaresRequested() {
	
		return softwaresRequested;
	}
	
	public VMDetailsTO getVmDetailsTO() {
	
		return vmDetailsTO;
	}
	
	public Long getVmId() {
	
		return vmId;
	}
	
	public String getWarName() {
	
		return WarName;
	}
	
	public void setAgentType(String agentType) {
	
		this.agentType = agentType;
	}
	
	public void setApplicationId(Long applicationId) {
	
		this.applicationId = applicationId;
	}
	
	public void setEnvironment(EnvironmentTO environment) {
	
		this.environment = environment;
	}
	
	public void setEnvironmentdetailsId(Long environmentdetailsId) {
	
		this.environmentdetailsId = environmentdetailsId;
	}
	
	public void setEnvironmentId(Long environmentId) {
	
		this.environmentId = environmentId;
	}
	
	public void setFilename(String filename) {
	
		this.filename = filename;
	}
	
	public void setFilePath(String filePath) {
	
		this.filePath = filePath;
	}
	
	public void setProfileId(Long profileId) {
	
		this.profileId = profileId;
	}
	
	public void setProvisionedMachineId(Long provisionedMachineId) {
	
		this.provisionedMachineId = provisionedMachineId;
	}
	
	public void setRequestId(Long requestId) {
	
		this.requestId = requestId;
	}
	
	public void setRequestTO(ServiceRequestTO requestTO) {
	
		this.requestTO = requestTO;
	}
	
	public void setSelectedApplicationRelease(Long selectedApplicationRelease) {
	
		this.selectedApplicationRelease = selectedApplicationRelease;
	}
	
	public void setSoftwaresRequested(Long softwaresRequested) {
	
		this.softwaresRequested = softwaresRequested;
	}
	
	public void setVmDetailsTO(VMDetailsTO vmDetailsTO) {
	
		this.vmDetailsTO = vmDetailsTO;
	}
	
	public void setVmId(Long vmId) {
	
		this.vmId = vmId;
	}
	
	public void setWarName(String warName) {
	
		WarName = warName;
	}
	
	public Long gettMapID() {
	
		return tMapID;
	}
	
	public void settMapID(Long tMapID) {
	
		this.tMapID = tMapID;
	}
}
