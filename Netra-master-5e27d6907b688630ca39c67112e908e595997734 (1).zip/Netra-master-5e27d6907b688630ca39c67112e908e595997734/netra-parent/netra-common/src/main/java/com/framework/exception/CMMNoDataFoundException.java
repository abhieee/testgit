package com.framework.exception;

/**
 * @author TCS
 */
public class CMMNoDataFoundException extends CMMException {
	
	private static final long serialVersionUID = 888724366243610132L;
	
	public CMMNoDataFoundException() {
	
		super();
	}
	
	public CMMNoDataFoundException(String message) {
	
		super(message);
	}
	
	public CMMNoDataFoundException(String message, Throwable cause) {
	
		super(message, cause);
	}
	
	public CMMNoDataFoundException(Throwable cause) {
	
		super(cause);
	}
}
