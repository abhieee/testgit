package com.framework.to;

public class TestingToolsMappingTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7963659653435633372L;
	private Long businessUnitId;
	private Long projectId;
	private Long applicationId;
	private Long testingTool_Config_Id;
	private TestingToolsTO testingToolsTO;
	
	public Long getApplicationId() {
	
		return applicationId;
	}
	
	public Long getBusinessUnitId() {
	
		return businessUnitId;
	}
	
	public Long getProjectId() {
	
		return projectId;
	}
	
	public Long getTestingTool_Config_Id() {
	
		return testingTool_Config_Id;
	}
	
	public TestingToolsTO getTestingToolsTO() {
	
		return testingToolsTO;
	}
	
	public void setApplicationId(Long applicationId) {
	
		this.applicationId = applicationId;
	}
	
	public void setBusinessUnitId(Long businessUnitId) {
	
		this.businessUnitId = businessUnitId;
	}
	
	public void setProjectId(Long projectId) {
	
		this.projectId = projectId;
	}
	
	public void setTestingTool_Config_Id(Long testingTool_Config_Id) {
	
		this.testingTool_Config_Id = testingTool_Config_Id;
	}
	
	public void setTestingToolsTO(TestingToolsTO testingToolsTO) {
	
		this.testingToolsTO = testingToolsTO;
	}
}
