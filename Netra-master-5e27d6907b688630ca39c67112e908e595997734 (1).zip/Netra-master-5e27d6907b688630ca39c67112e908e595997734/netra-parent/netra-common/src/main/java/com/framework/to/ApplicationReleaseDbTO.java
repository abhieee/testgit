package com.framework.to;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * This class declares the transfer object that carries user information across the application.
 *
 * @author TCS
 */
public class ApplicationReleaseDbTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2545227686305285126L;
	private Long id;
	private Long applicationReleaseId;
	private Long check;
	private String databaseScriptsPath;
	private String databaseScripts;
	private ApplicationReleaseTO applicationRelease = new ApplicationReleaseTO();
	private SoftwareconfigTO softwareConfigTO;
	private List<ApplicationReleaseDbTO> releaseList = new ArrayList<ApplicationReleaseDbTO>();
	private Long softwareConfigId;
	private Long softwareId;
	private String softwareName;
	private String databaseName;
	private String rollbackScriptPath;
	private String rollbackOrder;
	private String schemaName;
	private String sourceCodePath;
	private String earPath;
	private List<ApplicationReleaseDbTO> applicationReleaseDb = new ArrayList<ApplicationReleaseDbTO>();
	private HardwareTO hardware;
	private boolean access;
	private int flag = 1;
	private String templateName;
	private Long serverGroupNumber;
	private Long appProDetailsId;
	private Long serverId;
	private List<ApplicationReleaseDbTO> prop1 = new ArrayList<ApplicationReleaseDbTO>();
	private List<ApplicationReleaseDbTO> propAppSerSc1 = new ArrayList<ApplicationReleaseDbTO>();
	private ApplicationProfileDetailsTO appDetTO = new ApplicationProfileDetailsTO();
	private Long RequestId;
	private Long machineId;
	private Long selectedTestingPhase;
	private Long selectedMaskingTool;
	private String dataMaskingFlag;
	private Long maskingToolId;
	private String optimExtractFilename;
	private String optimInsertRequestName;
	private String optimExtractRequestName;
	private String dbUsername;
	private String dbPassword;
	private String serverName;
	private Long selectedRepository;
	private TestingPhaseTO testingPhase = new TestingPhaseTO();
	
	public TestingPhaseTO getTestingPhase() {
	
		return testingPhase;
	}
	
	public void setTestingPhase(TestingPhaseTO testingPhase) {
	
		this.testingPhase = testingPhase;
	}
	
	public Long getSelectedRepository() {
	
		return selectedRepository;
	}
	
	public void setSelectedRepository(Long selectedRepository) {
	
		this.selectedRepository = selectedRepository;
	}
	
	public ApplicationReleaseDbTO() {
	
		/* No implementation required at the moment. Method for future use. */
	}
	
	public ApplicationProfileDetailsTO getAppDetTO() {
	
		return appDetTO;
	}
	
	public ApplicationReleaseTO getApplicationRelease() {
	
		return applicationRelease;
	}
	
	public List<ApplicationReleaseDbTO> getApplicationReleaseDb() {
	
		return applicationReleaseDb;
	}
	
	public Long getApplicationReleaseId() {
	
		return applicationReleaseId;
	}
	
	public Long getAppProDetailsId() {
	
		return appProDetailsId;
	}
	
	public Long getCheck() {
	
		return check;
	}
	
	public String getDatabaseName() {
	
		return databaseName;
	}
	
	public String getDatabaseScripts() {
	
		return databaseScripts;
	}
	
	public String getDatabaseScriptsPath() {
	
		return databaseScriptsPath;
	}
	
	/**
	 * @return the dataMaskingFlag
	 */
	public String getDataMaskingFlag() {
	
		return dataMaskingFlag;
	}
	
	public String getDbPassword() {
	
		return dbPassword;
	}
	
	public String getDbUsername() {
	
		return dbUsername;
	}
	
	public String getEarPath() {
	
		return earPath;
	}
	
	public int getFlag() {
	
		return flag;
	}
	
	public HardwareTO getHardware() {
	
		return hardware;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public Long getMachineId() {
	
		return machineId;
	}
	
	/**
	 * @return the maskingToolId
	 */
	public Long getMaskingToolId() {
	
		return maskingToolId;
	}
	
	/**
	 * @return the optimExtractFilename
	 */
	public String getOptimExtractFilename() {
	
		return optimExtractFilename;
	}
	
	/**
	 * @return the optimExtractRequestName
	 */
	public String getOptimExtractRequestName() {
	
		return optimExtractRequestName;
	}
	
	/**
	 * @return the optimInsertRequestName
	 */
	public String getOptimInsertRequestName() {
	
		return optimInsertRequestName;
	}
	
	public List<ApplicationReleaseDbTO> getProp1() {
	
		return prop1;
	}
	
	public List<ApplicationReleaseDbTO> getPropAppSerSc1() {
	
		return propAppSerSc1;
	}
	
	public List<ApplicationReleaseDbTO> getReleaseList() {
	
		return releaseList;
	}
	
	public Long getRequestId() {
	
		return RequestId;
	}
	
	public String getRollbackOrder() {
	
		return rollbackOrder;
	}
	
	public String getRollbackScriptPath() {
	
		return rollbackScriptPath;
	}
	
	public String getSchemaName() {
	
		return schemaName;
	}
	
	/**
	 * @return the selectedMaskingTool
	 */
	public Long getSelectedMaskingTool() {
	
		return selectedMaskingTool;
	}
	
	public Long getSelectedTestingPhase() {
	
		return selectedTestingPhase;
	}
	
	public Long getServerGroupNumber() {
	
		return serverGroupNumber;
	}
	
	public Long getServerId() {
	
		return serverId;
	}
	
	public String getServerName() {
	
		return serverName;
	}
	
	public Long getSoftwareConfigId() {
	
		return softwareConfigId;
	}
	
	public SoftwareconfigTO getSoftwareConfigTO() {
	
		return softwareConfigTO;
	}
	
	public Long getSoftwareId() {
	
		return softwareId;
	}
	
	public String getSoftwareName() {
	
		return softwareName;
	}
	
	public String getSourceCodePath() {
	
		return sourceCodePath;
	}
	
	public String getTemplateName() {
	
		return templateName;
	}
	
	public boolean isAccess() {
	
		return access;
	}
	
	public void setAccess(boolean access) {
	
		this.access = access;
	}
	
	public void setAppDetTO(ApplicationProfileDetailsTO appDetTO) {
	
		this.appDetTO = appDetTO;
	}
	
	public void setApplicationRelease(ApplicationReleaseTO applicationRelease) {
	
		this.applicationRelease = applicationRelease;
	}
	
	public void setApplicationReleaseDb(List<ApplicationReleaseDbTO> applicationReleaseDb) {
	
		this.applicationReleaseDb = applicationReleaseDb;
	}
	
	public void setApplicationReleaseId(Long applicationReleaseId) {
	
		this.applicationReleaseId = applicationReleaseId;
	}
	
	public void setAppProDetailsId(Long appProDetailsId) {
	
		this.appProDetailsId = appProDetailsId;
	}
	
	public void setCheck(Long check) {
	
		this.check = check;
	}
	
	public void setDatabaseName(String databaseName) {
	
		this.databaseName = databaseName;
	}
	
	public void setDatabaseScripts(String databaseScripts) {
	
		this.databaseScripts = databaseScripts;
	}
	
	public void setDatabaseScriptsPath(String databaseScriptsPath) {
	
		this.databaseScriptsPath = databaseScriptsPath;
	}
	
	/**
	 * @param dataMaskingFlag
	 *                the dataMaskingFlag to set
	 */
	public void setDataMaskingFlag(String dataMaskingFlag) {
	
		this.dataMaskingFlag = dataMaskingFlag;
	}
	
	public void setDbPassword(String dbPassword) {
	
		this.dbPassword = dbPassword;
	}
	
	public void setDbUsername(String dbUsername) {
	
		this.dbUsername = dbUsername;
	}
	
	public void setEarPath(String earPath) {
	
		this.earPath = earPath;
	}
	
	public void setFlag(int flag) {
	
		this.flag = flag;
	}
	
	public void setHardware(HardwareTO hardware) {
	
		this.hardware = hardware;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setMachineId(Long machineId) {
	
		this.machineId = machineId;
	}
	
	/**
	 * @param maskingToolId
	 *                the maskingToolId to set
	 */
	public void setMaskingToolId(Long maskingToolId) {
	
		this.maskingToolId = maskingToolId;
	}
	
	/**
	 * @param optimExtractFilename
	 *                the optimExtractFilename to set
	 */
	public void setOptimExtractFilename(String optimExtractFilename) {
	
		this.optimExtractFilename = optimExtractFilename;
	}
	
	/**
	 * @param optimExtractRequestName
	 *                the optimExtractRequestName to set
	 */
	public void setOptimExtractRequestName(String optimExtractRequestName) {
	
		this.optimExtractRequestName = optimExtractRequestName;
	}
	
	/**
	 * @param optimInsertRequestName
	 *                the optimInsertRequestName to set
	 */
	public void setOptimInsertRequestName(String optimInsertRequestName) {
	
		this.optimInsertRequestName = optimInsertRequestName;
	}
	
	public void setProp1(List<ApplicationReleaseDbTO> prop1) {
	
		this.prop1 = prop1;
	}
	
	public void setPropAppSerSc1(List<ApplicationReleaseDbTO> propAppSerSc1) {
	
		this.propAppSerSc1 = propAppSerSc1;
	}
	
	public void setReleaseList(List<ApplicationReleaseDbTO> releaseList) {
	
		this.releaseList = releaseList;
	}
	
	public void setRequestId(Long requestId) {
	
		RequestId = requestId;
	}
	
	public void setRollbackOrder(String rollbackOrder) {
	
		this.rollbackOrder = rollbackOrder;
	}
	
	public void setRollbackScriptPath(String rollbackScriptPath) {
	
		this.rollbackScriptPath = rollbackScriptPath;
	}
	
	public void setSchemaName(String schemaName) {
	
		this.schemaName = schemaName;
	}
	
	/**
	 * @param selectedMaskingTool
	 *                the selectedMaskingTool to set
	 */
	public void setSelectedMaskingTool(Long selectedMaskingTool) {
	
		this.selectedMaskingTool = selectedMaskingTool;
	}
	
	public void setSelectedTestingPhase(Long selectedTestingPhase) {
	
		this.selectedTestingPhase = selectedTestingPhase;
	}
	
	public void setServerGroupNumber(Long serverGroupNumber) {
	
		this.serverGroupNumber = serverGroupNumber;
	}
	
	public void setServerId(Long serverId) {
	
		this.serverId = serverId;
	}
	
	public void setServerName(String serverName) {
	
		this.serverName = serverName;
	}
	
	public void setSoftwareConfigId(Long softwareConfigId) {
	
		this.softwareConfigId = softwareConfigId;
	}
	
	public void setSoftwareConfigTO(SoftwareconfigTO softwareConfigTO) {
	
		this.softwareConfigTO = softwareConfigTO;
	}
	
	public void setSoftwareId(Long softwareId) {
	
		this.softwareId = softwareId;
	}
	
	public void setSoftwareName(String softwareName) {
	
		this.softwareName = softwareName;
	}
	
	public void setSourceCodePath(String sourceCodePath) {
	
		this.sourceCodePath = sourceCodePath;
	}
	
	public void setTemplateName(String templateName) {
	
		this.templateName = templateName;
	}
	
	@Override
	public String toString() {
	
		return "ApplicationReleaseDbTO [id=" + id + "; applicationReleaseId=" + applicationReleaseId + "; softwareConfigId=" + softwareConfigTO.getId() + "; databaseScriptsPath=" + databaseScriptsPath + "; databaseScStringripts=" + databaseScripts + "]";
	}
}
