/**
 *
 */
package com.framework.to;

import java.io.Serializable;

/**
 * @author 678120
 */
public class ApplicationProfileDetailsAWSTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7659604380674986214L;
	private Long id;
	private Long serverGroup;
	private String key;
	private String avalabilityZone;
	private ApplicationProfileTO applicationProfile;
	
	public ApplicationProfileDetailsAWSTO() {
	
		/* No implementation required at the moment. Method for future use. */
	}
	
	public ApplicationProfileTO getApplicationProfile() {
	
		return applicationProfile;
	}
	
	public String getAvalabilityZone() {
	
		return avalabilityZone;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public String getKey() {
	
		return key;
	}
	
	public Long getServerGroup() {
	
		return serverGroup;
	}
	
	public void setApplicationProfile(ApplicationProfileTO applicationProfile) {
	
		this.applicationProfile = applicationProfile;
	}
	
	public void setAvalabilityZone(String avalabilityZone) {
	
		this.avalabilityZone = avalabilityZone;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setKey(String key) {
	
		this.key = key;
	}
	
	public void setServerGroup(Long serverGroup) {
	
		this.serverGroup = serverGroup;
	}
}
