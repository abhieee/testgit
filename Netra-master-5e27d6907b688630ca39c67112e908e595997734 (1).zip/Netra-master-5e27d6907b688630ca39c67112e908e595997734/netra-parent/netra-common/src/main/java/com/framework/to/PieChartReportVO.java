package com.framework.to;

import java.io.Serializable;

public class PieChartReportVO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7832299566135151722L;
	private String label;
	private long data;
	private String color;
	
	public String getColor() {
	
		return color;
	}
	
	public long getData() {
	
		return data;
	}
	
	public String getLabel() {
	
		return label;
	}
	
	public void setColor(String color) {
	
		this.color = color;
	}
	
	public void setData(long data) {
	
		this.data = data;
	}
	
	public void setLabel(String label) {
	
		this.label = label;
	}
}
