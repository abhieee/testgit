package com.framework.to;

public class PlatformTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7118642032557146533L;
	private String type;
	private String processor;
	private String diskSpace;
	private String ram;
	private Long selectedStatus;
	private StatusTO statusTO;
	
	public void copy(PlatformTO hardwareTO) {
	
		if (hardwareTO == null) {
			hardwareTO = new PlatformTO();
		}
		if ((hardwareTO.getName() == null) || !hardwareTO.getName().equals(this.getName())) {
			hardwareTO.setName(this.getName());
		}
	}
	
	public String getDiskSpace() {
	
		return diskSpace;
	}
	
	public String getProcessor() {
	
		return processor;
	}
	
	public String getRam() {
	
		return ram;
	}
	
	public Long getSelectedStatus() {
	
		return selectedStatus;
	}
	
	public StatusTO getStatusTO() {
	
		return statusTO;
	}
	
	public String getType() {
	
		return type;
	}
	
	public void setDiskSpace(String diskSpace) {
	
		this.diskSpace = diskSpace;
	}
	
	public void setProcessor(String processor) {
	
		this.processor = processor;
	}
	
	public void setRam(String ram) {
	
		this.ram = ram;
	}
	
	public void setSelectedStatus(Long selectedStatus) {
	
		this.selectedStatus = selectedStatus;
	}
	
	public void setStatusTO(StatusTO statusTO) {
	
		this.statusTO = statusTO;
	}
	
	public void setType(String type) {
	
		this.type = type;
	}
}
