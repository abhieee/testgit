package com.framework.common;

public enum ServerType {
	DataCentre("Data Centre"), EsxiServer("Esxi Server");
	
	private String server;
	
	private ServerType(String s) {
	
		this.server = s;
	}
	
	public String getServer() {
	
		return server;
	}
}
