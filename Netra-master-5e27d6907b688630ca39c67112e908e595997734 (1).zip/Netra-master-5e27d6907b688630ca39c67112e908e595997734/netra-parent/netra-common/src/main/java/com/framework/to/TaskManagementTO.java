/**
 *
 */
package com.framework.to;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import com.framework.nolio.to.NolioProcess;
import com.framework.puppetMaster.to.PuppetProcess;
import com.framework.udeploy.to.UdeployProcess;

/**
 * @author 737070
 */
public class TaskManagementTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7078196166354014669L;
	private String description;
	private String taskname;
	private Long selectedActivity;
	private List<CAReleaseActivityTO> allActivities = new ArrayList<CAReleaseActivityTO>(0);
	private List<ManifestTypeTO> allmanifest = new ArrayList<ManifestTypeTO>(0);
	private Long selectedManifest;
	private Long clientId;
	private String automationTool;
	private CAReleaseActivityTO cAReleaseActivityTO;
	private ManifestTypeTO manifestTypeTO;
	private int searchCount;
	private int tableSize = 10;
	private Long pageNumber = 1L;
	private int firstResult = 0;
	private List<NolioProcess> allNolioProcess = new ArrayList<NolioProcess>();
	private List<UdeployProcess> allUdeployProcess = new ArrayList<UdeployProcess>();
	private List<PuppetProcess> allPuppetProcess = new ArrayList<PuppetProcess>();
	private List<Long> selectedProcess;
	private String writtenScripts;
	private String scriptname;
	private String scriptpath;
	private String uploadScript;
	private Set<NolioTaskMappingTO> nolioTaskMapping = new HashSet<NolioTaskMappingTO>();
	private Set<UdeployTaskMappingTO> udeployTaskMapping = new HashSet<UdeployTaskMappingTO>();
	private Set<PuppetTaskMappingTO> puppetTaskMapping = new HashSet<PuppetTaskMappingTO>();
	private Set<ScriptTaskMappingTO> scriptTaskMappingTO = new HashSet<ScriptTaskMappingTO>();
	private String newActivityName;
	private String targetLocation;
	private String filePath;
	private List<ScriptParameterMapTO> scriptParameterMap = new ArrayList<ScriptParameterMapTO>();
	private List<NetraParametersTO> netraParameters = new ArrayList<NetraParametersTO>();
	private String filesName;
	private String uploadSource;
	private long repoId;
	
	public String getDescription() {
	
		return description;
	}
	
	public void setDescription(String description) {
	
		this.description = description;
	}
	
	public String getTaskname() {
	
		return taskname;
	}
	
	public void setTaskname(String taskname) {
	
		this.taskname = taskname;
	}
	
	public Long getSelectedActivity() {
	
		return selectedActivity;
	}
	
	public void setSelectedActivity(Long selectedActivity) {
	
		this.selectedActivity = selectedActivity;
	}
	
	public Long getSelectedManifest() {
	
		return selectedManifest;
	}
	
	public void setSelectedManifest(Long selectedManifest) {
	
		this.selectedManifest = selectedManifest;
	}
	
	public List<CAReleaseActivityTO> getAllActivities() {
	
		return allActivities;
	}
	
	public void setAllActivities(List<CAReleaseActivityTO> allActivities) {
	
		this.allActivities = allActivities;
	}
	
	public Long getClientId() {
	
		return clientId;
	}
	
	public void setClientId(Long clientId) {
	
		this.clientId = clientId;
	}
	
	public String getAutomationTool() {
	
		return automationTool;
	}
	
	public void setAutomationTool(String automationTool) {
	
		this.automationTool = automationTool;
	}
	
	public List<ManifestTypeTO> getAllmanifest() {
	
		return allmanifest;
	}
	
	public void setAllmanifest(List<ManifestTypeTO> allmanifest) {
	
		this.allmanifest = allmanifest;
	}
	
	public CAReleaseActivityTO getcAReleaseActivityTO() {
	
		return cAReleaseActivityTO;
	}
	
	public void setcAReleaseActivityTO(CAReleaseActivityTO cAReleaseActivityTO) {
	
		this.cAReleaseActivityTO = cAReleaseActivityTO;
	}
	
	public ManifestTypeTO getManifestTypeTO() {
	
		return manifestTypeTO;
	}
	
	public void setManifestTypeTO(ManifestTypeTO manifestTypeTO) {
	
		this.manifestTypeTO = manifestTypeTO;
	}
	
	public int getSearchCount() {
	
		return searchCount;
	}
	
	public void setSearchCount(int searchCount) {
	
		this.searchCount = searchCount;
	}
	
	public int getTableSize() {
	
		return tableSize;
	}
	
	public void setTableSize(int tableSize) {
	
		this.tableSize = tableSize;
	}
	
	public Long getPageNumber() {
	
		return pageNumber;
	}
	
	public void setPageNumber(Long pageNumber) {
	
		this.pageNumber = pageNumber;
	}
	
	public int getFirstResult() {
	
		return firstResult;
	}
	
	public void setFirstResult(int firstResult) {
	
		this.firstResult = firstResult;
	}
	
	public List<NolioProcess> getAllNolioProcess() {
	
		return allNolioProcess;
	}
	
	public void setAllNolioProcess(List<NolioProcess> allNolioProcess) {
	
		this.allNolioProcess = allNolioProcess;
	}
	
	public String getWrittenScripts() {
	
		return writtenScripts;
	}
	
	public void setWrittenScripts(String writtenScripts) {
	
		this.writtenScripts = writtenScripts;
	}
	
	public String getScriptname() {
	
		return scriptname;
	}
	
	public void setScriptname(String scriptname) {
	
		this.scriptname = scriptname;
	}
	
	public String getScriptpath() {
	
		return scriptpath;
	}
	
	public void setScriptpath(String scriptpath) {
	
		this.scriptpath = scriptpath;
	}
	
	public String getUploadScript() {
	
		return uploadScript;
	}
	
	public void setUploadScript(String uploadScript) {
	
		this.uploadScript = uploadScript;
	}
	
	public List<UdeployProcess> getAllUdeployProcess() {
	
		return allUdeployProcess;
	}
	
	public void setAllUdeployProcess(List<UdeployProcess> allUdeployProcess) {
	
		this.allUdeployProcess = allUdeployProcess;
	}
	
	public List<PuppetProcess> getAllPuppetProcess() {
	
		return allPuppetProcess;
	}
	
	public void setAllPuppetProcess(List<PuppetProcess> allPuppetProcess) {
	
		this.allPuppetProcess = allPuppetProcess;
	}
	
	public List<Long> getSelectedProcess() {
	
		return selectedProcess;
	}
	
	public void setSelectedProcess(List<Long> selectedProcess) {
	
		this.selectedProcess = selectedProcess;
	}
	
	public Set<NolioTaskMappingTO> getNolioTaskMapping() {
	
		return nolioTaskMapping;
	}
	
	public void setNolioTaskMapping(Set<NolioTaskMappingTO> nolioTaskMapping) {
	
		this.nolioTaskMapping = nolioTaskMapping;
	}
	
	public Set<ScriptTaskMappingTO> getScriptTaskMappingTO() {
	
		return scriptTaskMappingTO;
	}
	
	public void setScriptTaskMappingTO(Set<ScriptTaskMappingTO> scriptTaskMappingTO) {
	
		this.scriptTaskMappingTO = scriptTaskMappingTO;
	}
	
	public Set<UdeployTaskMappingTO> getUdeployTaskMapping() {
	
		return udeployTaskMapping;
	}
	
	public void setUdeployTaskMapping(Set<UdeployTaskMappingTO> udeployTaskMapping) {
	
		this.udeployTaskMapping = udeployTaskMapping;
	}
	
	public Set<PuppetTaskMappingTO> getPuppetTaskMapping() {
	
		return puppetTaskMapping;
	}
	
	public void setPuppetTaskMapping(Set<PuppetTaskMappingTO> puppetTaskMapping) {
	
		this.puppetTaskMapping = puppetTaskMapping;
	}
	
	public String getNewActivityName() {
	
		return newActivityName;
	}
	
	public void setNewActivityName(String newActivityName) {
	
		this.newActivityName = newActivityName;
	}
	
	public String getTargetLocation() {
	
		return targetLocation;
	}
	
	public void setTargetLocation(String targetLocation) {
	
		this.targetLocation = targetLocation;
	}
	
	public List<ScriptParameterMapTO> getScriptParameterMap() {
	
		return scriptParameterMap;
	}
	
	public void setScriptParameterMap(List<ScriptParameterMapTO> scriptParameterMap) {
	
		this.scriptParameterMap = scriptParameterMap;
	}
	
	public List<NetraParametersTO> getNetraParameters() {
	
		return netraParameters;
	}
	
	public void setNetraParameters(List<NetraParametersTO> netraParameters) {
	
		this.netraParameters = netraParameters;
	}
	
	public String getFilePath() {
	
		return filePath;
	}
	
	public void setFilePath(String filePath) {
	
		this.filePath = filePath;
	}
	
	public String getFilesName() {
	
		return filesName;
	}
	
	public void setFilesName(String filesName) {
	
		this.filesName = filesName;
	}
	
	public String getUploadSource() {
	
		return uploadSource;
	}
	
	public void setUploadSource(String uploadSource) {
	
		this.uploadSource = uploadSource;
	}
	
	public long getRepoId() {
	
		return repoId;
	}
	
	public void setRepoId(long repoId) {
	
		this.repoId = repoId;
	}
}
