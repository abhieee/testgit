package com.framework.to;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * This class declares the transfer object that carries user information across the application.
 *
 * @author TCS
 */
public class ApplicationReleaseBuildTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8904448720511827873L;
	private Long id;
	private Long applicationReleaseId;
	private Long RequestId;
	private boolean access;
	private List<BuildToolTO> buildToolFormList = new ArrayList<>(0);
	private Long selectedBuildTool;
	private Long buildToolId;
	private BuildToolTO buildToolTo;
	private int flag = 1;
	private String jobName;
	private String jobToken;
	private String collectionName;
	private String projectName;
	private String buildDefinition;
	private Long buildToolDefinitionId;
	private BuildToolDefinitionTO buildToolDefinitionTO;
	private String paramaterizedBuild;
	private String teamCityProjectId;
	private String teamCityBuildConfig;
	private Long selectedTestingPhase;
	
	public Long getSelectedTestingPhase() {
	
		return selectedTestingPhase;
	}
	
	public void setSelectedTestingPhase(Long selectedTestingPhase) {
	
		this.selectedTestingPhase = selectedTestingPhase;
	}
	
	public Long getApplicationReleaseId() {
	
		return applicationReleaseId;
	}
	
	public String getBuildDefinition() {
	
		return buildDefinition;
	}
	
	public Long getBuildToolDefinitionId() {
	
		return buildToolDefinitionId;
	}
	
	public BuildToolDefinitionTO getBuildToolDefinitionTO() {
	
		return buildToolDefinitionTO;
	}
	
	public List<BuildToolTO> getBuildToolFormList() {
	
		return buildToolFormList;
	}
	
	public Long getBuildToolId() {
	
		return buildToolId;
	}
	
	public BuildToolTO getBuildToolTo() {
	
		return buildToolTo;
	}
	
	public String getCollectionName() {
	
		return collectionName;
	}
	
	public int getFlag() {
	
		return flag;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public String getJobName() {
	
		return jobName;
	}
	
	public String getJobToken() {
	
		return jobToken;
	}
	
	/**
	 * @return the paramaterizedBuild
	 */
	public String getParamaterizedBuild() {
	
		return paramaterizedBuild;
	}
	
	public String getProjectName() {
	
		return projectName;
	}
	
	public Long getRequestId() {
	
		return RequestId;
	}
	
	public Long getSelectedBuildTool() {
	
		return selectedBuildTool;
	}
	
	public String getTeamCityBuildConfig() {
	
		return teamCityBuildConfig;
	}
	
	public String getTeamCityProjectId() {
	
		return teamCityProjectId;
	}
	
	public boolean isAccess() {
	
		return access;
	}
	
	public void setAccess(boolean access) {
	
		this.access = access;
	}
	
	public void setApplicationReleaseId(Long applicationReleaseId) {
	
		this.applicationReleaseId = applicationReleaseId;
	}
	
	public void setBuildDefinition(String buildDefinition) {
	
		this.buildDefinition = buildDefinition;
	}
	
	public void setBuildToolDefinitionId(Long buildToolDefinitionId) {
	
		this.buildToolDefinitionId = buildToolDefinitionId;
	}
	
	public void setBuildToolDefinitionTO(BuildToolDefinitionTO buildToolDefinitionTO) {
	
		this.buildToolDefinitionTO = buildToolDefinitionTO;
	}
	
	public void setBuildToolFormList(List<BuildToolTO> buildToolFormList) {
	
		this.buildToolFormList = buildToolFormList;
	}
	
	public void setBuildToolId(Long buildToolId) {
	
		this.buildToolId = buildToolId;
	}
	
	public void setBuildToolTo(BuildToolTO buildToolTo) {
	
		this.buildToolTo = buildToolTo;
	}
	
	public void setCollectionName(String collectionName) {
	
		this.collectionName = collectionName;
	}
	
	public void setFlag(int flag) {
	
		this.flag = flag;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setJobName(String jobName) {
	
		this.jobName = jobName;
	}
	
	public void setJobToken(String jobToken) {
	
		this.jobToken = jobToken;
	}
	
	/**
	 * @param paramaterizedBuild
	 *                the paramaterizedBuild to set
	 */
	public void setParamaterizedBuild(String paramaterizedBuild) {
	
		this.paramaterizedBuild = paramaterizedBuild;
	}
	
	public void setProjectName(String projectName) {
	
		this.projectName = projectName;
	}
	
	public void setRequestId(Long requestId) {
	
		RequestId = requestId;
	}
	
	public void setSelectedBuildTool(Long selectedBuildTool) {
	
		this.selectedBuildTool = selectedBuildTool;
	}
	
	public void setTeamCityBuildConfig(String teamCityBuildConfig) {
	
		this.teamCityBuildConfig = teamCityBuildConfig;
	}
	
	public void setTeamCityProjectId(String teamCityProjectId) {
	
		this.teamCityProjectId = teamCityProjectId;
	}
}
