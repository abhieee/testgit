package com.framework.to;

public class MailSetupServicesMappingTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6044516172187640941L;
	private Long mailSetupId;
	private Long selectedServiceId;
	
	public Long getMailSetupId() {
	
		return mailSetupId;
	}
	
	public Long getSelectedServiceId() {
	
		return selectedServiceId;
	}
	
	public void setMailSetupId(Long mailSetupId) {
	
		this.mailSetupId = mailSetupId;
	}
	
	public void setSelectedServiceId(Long selectedServiceId) {
	
		this.selectedServiceId = selectedServiceId;
	}
}
