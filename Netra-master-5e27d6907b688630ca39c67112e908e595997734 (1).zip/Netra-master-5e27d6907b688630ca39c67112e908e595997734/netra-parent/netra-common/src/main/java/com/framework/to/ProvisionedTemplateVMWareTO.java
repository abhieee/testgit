package com.framework.to;

import java.io.Serializable;

public class ProvisionedTemplateVMWareTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5488740357154547454L;
	private Long id;
	private ProvisionedTemplateTO provisionedTemplate;
	private Long provisionedTemplateId;
	private String vmTemplateName;
	private Long provisionedPlatformId;
	
	public Long getId() {
	
		return id;
	}
	
	public Long getProvisionedPlatformId() {
	
		return provisionedPlatformId;
	}
	
	public ProvisionedTemplateTO getProvisionedTemplate() {
	
		return provisionedTemplate;
	}
	
	public Long getProvisionedTemplateId() {
	
		return provisionedTemplateId;
	}
	
	public String getVmTemplateName() {
	
		return vmTemplateName;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setProvisionedPlatformId(Long provisionedPlatformId) {
	
		this.provisionedPlatformId = provisionedPlatformId;
	}
	
	public void setProvisionedTemplate(ProvisionedTemplateTO provisionedTemplate) {
	
		this.provisionedTemplate = provisionedTemplate;
	}
	
	public void setProvisionedTemplateId(Long provisionedTemplateId) {
	
		this.provisionedTemplateId = provisionedTemplateId;
	}
	
	public void setVmTemplateName(String vmTemplateName) {
	
		this.vmTemplateName = vmTemplateName;
	}
}
