package com.framework.to;

import java.util.HashSet;
import java.util.Set;

/**
 * @author TCS
 */
public class DomainTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Set<TopologyTO> topologies = null;
	private Set<DeviceTO> devices = null;
	private Set<EnvironmentTO> reservations = null;
	
	public DomainTO() {
	
		super();
	}
	
	public void addTopology(TopologyTO topology) {
	
		if (this.topologies == null) {
			this.topologies = new HashSet<TopologyTO>();
		}
		this.topologies.add(topology);
	}
	
	/**
	 * @return the devices
	 */
	public Set<DeviceTO> getDevices() {
	
		return devices;
	}
	
	/**
	 * @return the id
	 */
	public Set<EnvironmentTO> getReservations() {
	
		return reservations;
	}
	
	/**
	 * @return the topologies
	 */
	public Set<TopologyTO> getTopologies() {
	
		return topologies;
	}
	
	/**
	 * @param devices
	 *                the devices to set
	 */
	public void setDevices(Set<DeviceTO> devices) {
	
		this.devices = devices;
	}
	
	/**
	 * @param id
	 *                the id to set
	 */
	public void setReservations(Set<EnvironmentTO> reservations) {
	
		this.reservations = reservations;
	}
	
	/**
	 * @param topologies
	 *                the topologies to set
	 */
	public void setTopologies(Set<TopologyTO> topologies) {
	
		this.topologies = topologies;
	}
}
