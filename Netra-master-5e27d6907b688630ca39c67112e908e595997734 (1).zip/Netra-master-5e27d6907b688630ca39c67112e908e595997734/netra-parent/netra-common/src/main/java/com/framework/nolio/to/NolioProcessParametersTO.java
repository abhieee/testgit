/**
 *
 */
package com.framework.nolio.to;

import java.io.Serializable;

/**
 * @author 460650
 */
public class NolioProcessParametersTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -9222812990170096356L;
	private long parameterId;
	private String parameterPathName;
	private String parameterValue;
	private Long id;
	private String name;
	private String status;
	private NolioProcess nolioProcess;
	private String netraParameterName;
	private String netraParameterMapping;
	private Long processId;
	private String selectedParameterScope;
	private String parameterType;
	
	@Override
	public boolean equals(Object obj) {
	
		if (obj == null) {
			return false;
		}
		if (!this.getClass().equals(obj.getClass())) {
			return false;
		}
		NolioProcessParametersTO obj2 = (NolioProcessParametersTO) obj;
		if ((this.parameterId == obj2.getParameterId()) && this.parameterPathName.equals(obj2.getParameterPathName())) {
			return true;
		}
		return false;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public String getName() {
	
		return name;
	}
	
	public String getNetraParameterMapping() {
	
		return netraParameterMapping;
	}
	
	public String getNetraParameterName() {
	
		return netraParameterName;
	}
	
	public NolioProcess getNolioProcess() {
	
		return nolioProcess;
	}
	
	public long getParameterId() {
	
		return parameterId;
	}
	
	public String getParameterPathName() {
	
		return parameterPathName;
	}
	
	public String getParameterValue() {
	
		return parameterValue;
	}
	
	public Long getProcessId() {
	
		return processId;
	}
	
	public String getSelectedParameterScope() {
	
		return selectedParameterScope;
	}
	
	public String getStatus() {
	
		return status;
	}
	
	@Override
	public int hashCode() {
	
		return (parameterId + parameterPathName).hashCode();
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setName(String name) {
	
		this.name = name;
	}
	
	public void setNetraParameterMapping(String netraParameterMapping) {
	
		this.netraParameterMapping = netraParameterMapping;
	}
	
	public void setNetraParameterName(String netraParameterName) {
	
		this.netraParameterName = netraParameterName;
	}
	
	public void setNolioProcess(NolioProcess nolioProcess) {
	
		this.nolioProcess = nolioProcess;
	}
	
	public void setParameterId(long parameterId) {
	
		this.parameterId = parameterId;
	}
	
	public void setParameterPathName(String parameterPathName) {
	
		this.parameterPathName = parameterPathName;
	}
	
	public void setParameterValue(String parameterValue) {
	
		this.parameterValue = parameterValue;
	}
	
	public void setProcessId(Long processId) {
	
		this.processId = processId;
	}
	
	public void setSelectedParameterScope(String selectedParameterScope) {
	
		this.selectedParameterScope = selectedParameterScope;
	}
	
	public void setStatus(String status) {
	
		this.status = status;
	}
	
	public String getParameterType() {
	
		return parameterType;
	}
	
	public void setParameterType(String parameterType) {
	
		this.parameterType = parameterType;
	}
}
