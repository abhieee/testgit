package com.framework.report;

import java.io.Serializable;
import java.util.List;

public class HardwareEnvironmentDetailsReportVO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String ip;
	private String hostName;
	private String environmentName;
	private String applicationName;
	private List<Hardware_summary> hw_summ;
	private List<UntaggedServerDetails> untag_server_list;
	
	public HardwareEnvironmentDetailsReportVO() {
	
		/* No implementation required at the moment. Method for future use. */
	}
	
	public HardwareEnvironmentDetailsReportVO(String ip, String hostName, String environmentName, String applicationName, List<Hardware_summary> hw_summ, List<UntaggedServerDetails> untag_server_list) {
	
		this.ip = ip;
		this.hostName = hostName;
		this.environmentName = environmentName;
		this.applicationName = applicationName;
		this.hw_summ = hw_summ;
		this.untag_server_list = untag_server_list;
	}
	
	public String getIp() {
	
		return ip;
	}
	
	public void setIp(String ip) {
	
		this.ip = ip;
	}
	
	public String getHostName() {
	
		return hostName;
	}
	
	public void setHostName(String hostName) {
	
		this.hostName = hostName;
	}
	
	public String getEnvironmentName() {
	
		return environmentName;
	}
	
	public void setEnvironmentName(String environmentName) {
	
		this.environmentName = environmentName;
	}
	
	public String getApplicationName() {
	
		return applicationName;
	}
	
	public void setApplicationName(String applicationName) {
	
		this.applicationName = applicationName;
	}
	
	public List<Hardware_summary> getHw_summ() {
	
		return hw_summ;
	}
	
	public void setHw_summ(List<Hardware_summary> hw_summ) {
	
		this.hw_summ = hw_summ;
	}
	
	public List<UntaggedServerDetails> getUntag_server_list() {
	
		return untag_server_list;
	}
	
	public void setUntag_server_list(List<UntaggedServerDetails> untag_server_list) {
	
		this.untag_server_list = untag_server_list;
	}
}
