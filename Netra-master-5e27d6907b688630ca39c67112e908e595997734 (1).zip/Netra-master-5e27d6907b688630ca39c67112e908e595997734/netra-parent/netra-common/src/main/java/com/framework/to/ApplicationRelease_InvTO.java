package com.framework.to;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ApplicationRelease_InvTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long applicationId;
	private String applicationName;
	private Long status;
	private String description;
	private List<ApplicationRelease_InvTO> releaseList = new ArrayList<ApplicationRelease_InvTO>();
	private Date releaseTime;
	private String initiatedBy;
	private String machineIp;
	
	public Long getApplicationId() {
	
		return applicationId;
	}
	
	public String getApplicationName() {
	
		return applicationName;
	}
	
	public String getDescription() {
	
		return description;
	}
	
	public String getInitiatedBy() {
	
		return initiatedBy;
	}
	
	public String getMachineIp() {
	
		return machineIp;
	}
	
	public List<ApplicationRelease_InvTO> getReleaseList() {
	
		return releaseList;
	}
	
	public Date getReleaseTime() {
	
		return releaseTime;
	}
	
	public Long getStatus() {
	
		return status;
	}
	
	public void setApplicationId(Long applicationId) {
	
		this.applicationId = applicationId;
	}
	
	public void setApplicationName(String applicationName) {
	
		this.applicationName = applicationName;
	}
	
	public void setDescription(String description) {
	
		this.description = description;
	}
	
	public void setInitiatedBy(String initiatedBy) {
	
		this.initiatedBy = initiatedBy;
	}
	
	public void setMachineIp(String machineIp) {
	
		this.machineIp = machineIp;
	}
	
	public void setReleaseList(List<ApplicationRelease_InvTO> releaseList) {
	
		this.releaseList = releaseList;
	}
	
	public void setReleaseTime(Date releaseTime) {
	
		this.releaseTime = releaseTime;
	}
	
	public void setStatus(Long status) {
	
		this.status = status;
	}
}
