/**
 *
 */
package com.framework.to;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

/**
 * @author TCS
 */
public class EnvironmentSoftParamsTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5286425472910733632L;
	private long paramId;
	private EnvironmentDetailsTO environmentDetailsTO;
	private ActivitySoftwareMappingTO activitySoftwareMappingTO;
	private ServiceRequestTO serviceRequestTO;
	private String insertUpdateFlag;
	private String latestValueFlag;
	private Set<EnvSoftParamDetailsTO> envSoftParamDetailsTO = new HashSet<EnvSoftParamDetailsTO>(0);
	private long activityId;
	private EnvironmentApplicationTO environmentApplicationTO;
	
	public long getActivityId() {
	
		return activityId;
	}
	
	public ActivitySoftwareMappingTO getActivitySoftwareMappingTO() {
	
		return activitySoftwareMappingTO;
	}
	
	public EnvironmentApplicationTO getEnvironmentApplicationTO() {
	
		return environmentApplicationTO;
	}
	
	public EnvironmentDetailsTO getEnvironmentDetailsTO() {
	
		return environmentDetailsTO;
	}
	
	public Set<EnvSoftParamDetailsTO> getEnvSoftParamDetailsTO() {
	
		return envSoftParamDetailsTO;
	}
	
	public String getInsertUpdateFlag() {
	
		return insertUpdateFlag;
	}
	
	public String getLatestValueFlag() {
	
		return latestValueFlag;
	}
	
	public long getParamId() {
	
		return paramId;
	}
	
	public ServiceRequestTO getServiceRequestTO() {
	
		return serviceRequestTO;
	}
	
	public void setActivityId(long activityId) {
	
		this.activityId = activityId;
	}
	
	public void setActivitySoftwareMappingTO(ActivitySoftwareMappingTO activitySoftwareMappingTO) {
	
		this.activitySoftwareMappingTO = activitySoftwareMappingTO;
	}
	
	public void setEnvironmentApplicationTO(EnvironmentApplicationTO environmentApplicationTO) {
	
		this.environmentApplicationTO = environmentApplicationTO;
	}
	
	public void setEnvironmentDetailsTO(EnvironmentDetailsTO environmentDetailsTO) {
	
		this.environmentDetailsTO = environmentDetailsTO;
	}
	
	public void setEnvSoftParamDetailsTO(Set<EnvSoftParamDetailsTO> envSoftParamDetailsTO) {
	
		this.envSoftParamDetailsTO = envSoftParamDetailsTO;
	}
	
	public void setInsertUpdateFlag(String insertUpdateFlag) {
	
		this.insertUpdateFlag = insertUpdateFlag;
	}
	
	public void setLatestValueFlag(String latestValueFlag) {
	
		this.latestValueFlag = latestValueFlag;
	}
	
	public void setParamId(long paramId) {
	
		this.paramId = paramId;
	}
	
	public void setServiceRequestTO(ServiceRequestTO serviceRequestTO) {
	
		this.serviceRequestTO = serviceRequestTO;
	}
}
