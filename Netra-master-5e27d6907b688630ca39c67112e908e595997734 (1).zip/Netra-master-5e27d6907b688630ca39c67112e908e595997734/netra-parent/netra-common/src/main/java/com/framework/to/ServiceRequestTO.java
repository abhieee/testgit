package com.framework.to;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import com.framework.nolio.to.NolioProcessParametersTO;

public class ServiceRequestTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2316365026807622270L;
	private String perfectoBaseUrl;
	private String perfectoUserName;
	private String perfectoPassword;
	private String isScheduled = "N";
	private long userId;
	private Long clientId;
	private String releaseName;
	private boolean access;
	private Long selectedEnvironment;
	List<ApplicationTO> appList = new ArrayList<ApplicationTO>(0);
	List<ApplicationReleaseTO> applicationReleaseTO = new ArrayList<ApplicationReleaseTO>(0);
	private String softwareName;
	private Long softwareConfigId;
	private String newReleaseName;
	private Long workFlowId;
	private Long environmentdetailsId;
	boolean generateWorkFlow = false;
	private int success;
	private String remark;
	private List<ServiceRequestTO> appSerSoftListForm = new ArrayList<ServiceRequestTO>(0);
	private String deployFromNexus;
	private Long selectedProfile;
	private Long environmentDetailId;
	private Long profileId;
	private String cronExp;
	private Long provisionedMachineId;
	private String toolConfigLocation;
	private String agentType;
	private String pathForCode;
	private String scriptsSvnUrl;
	private String svnUserName;
	private String password;
	private String createdByDateStr;
	private String imageTitle;
	private List<ServiceRequestTO> buildMonth1 = new ArrayList<ServiceRequestTO>(0);
	private Long applicationReleaseId;
	private Map<String, String> propertiesMap;
	private int flag = 1;
	private Long softwareId;
	private Long hardwareId;
	private String templateName;
	private String swInstallationStatus;
	private String swInstallationReq;
	private String actualCron;
	List<MultipleProfileDetailsTO> multipleEnvReqList = new ArrayList<MultipleProfileDetailsTO>();
	private Set<WorkflowCurrentTO> workflowCurrentTO = new HashSet<WorkflowCurrentTO>();
	private String provisionedMachineIdNew;
	private Long serverGroupNumber;
	private String vmIp;
	private String vmHost;
	private String startTimeStr;
	private String endTimeStr;
	private String childWorkflowFlag;
	private List<ApplicationTO> allApplications = new ArrayList<ApplicationTO>(0);
	private List<ProvisionedMachineTO> provisionedMachineDetails = new ArrayList<ProvisionedMachineTO>(0);
	private Set<ServiceRequestDetailsTO> serviceReqDetails = new HashSet<ServiceRequestDetailsTO>(0);
	private ApplicationReleaseTO release = new ApplicationReleaseTO();
	private Set<VMDetailsTO> vmDetailsSet = new HashSet<VMDetailsTO>(0);
	private String environmentName;
	private String applicationName;
	private Long selectedApplication;
	private Date startTime;
	private Date endTime;
	private List<ServiceTO> allServices = new ArrayList<ServiceTO>(0);
	private Long selectedService;
	private List<ServiceRequestTO> serviceRequestTo = new ArrayList<ServiceRequestTO>(0);
	private List<ServiceRequestDetailsTO> serviceRequestDetList = new ArrayList<ServiceRequestDetailsTO>(0);
	private List<TestingPhaseTO> allTestingCycles = new ArrayList<TestingPhaseTO>(0);
	private List<ApplicationProfileTO> allProfiles = new ArrayList<ApplicationProfileTO>(0);
	private Long selectedProfiles;
	private Long selectedTestingCycle;
	private Long statusId;
	private Long environmentId;
	private Long promotedEnvironment;
	private Long applicationId;
	private Long memory;
	private Long cpuNo;
	private Long serviceId;
	private Long requestId;
	private boolean lastPhase;
	private String actionFlag;
	private ApplicationTO applicationTO = null;
	private ApplicationReleaseTO releaseTO = null;
	private BusinessUnitTO businessUnitTO = null;
	private ProjectsTO projectTO = null;
	private ServiceTO serviceTO = null;
	private EnvironmentTO environmentTO = null;
	private UserTO userTO = null;
	private StatusTO statusTO;
	private Long status;
	private Date createdByDate;
	private Date modifiedbyDate;
	private List<EnvironmentApplicationTO> appReleaseList = new ArrayList<EnvironmentApplicationTO>(0);
	private List<ServiceRequestHistoryTO> serviceRequestHistoryTOList = new ArrayList<ServiceRequestHistoryTO>(0);
	private String pipelineRequest;
	private Long parentRequestId;
	private Long childRequestExecutionOrder;
	private String WarName;
	private String statusImage;
	private Long selectedSoftwareConfigIdForInstallation;
	private String selectedSoftwareForInstallation;
	private Set<PipelineRequestDetailsTO> pipelineRequestDetails = new HashSet<PipelineRequestDetailsTO>(0);
	private int tableSize = 10;
	private long pageNumber = 1;
	private int firstResult = 0;
	private long searchCount;
	private List<EnvironmentSoftwareAttributeTO> envSoftwareAttributeList = new ArrayList<EnvironmentSoftwareAttributeTO>(0);
	/*************** Jira Changes ***********/
	private List<String> allTools = new ArrayList<String>(0);
	private String selectedIssueType;
	private String selectedJiraIssue;
	private List<String> jiraIssueList = new ArrayList<String>(0);
	private String selectedTool;
	private String jiraRadio;
	private String jiraIssue;
	private String formatDate;
	private String formatDate1;
	private Long selectedTestingPhase;
	private Long selPort;
	private String resultLocation;
	private String scriptCopyLocation;
	private List<EnvTypeTO> allEnvType = new ArrayList<>(0);
	private Long selectedEnvType;
	private List<NolioProcessParametersTO> parametersList = new ArrayList<>();
	
	public String getDeployFromNexus() {
	
		return deployFromNexus;
	}
	
	public void setDeployFromNexus(String deployFromNexus) {
	
		this.deployFromNexus = deployFromNexus;
	}
	
	public Long getSelectedTestingPhase() {
	
		return selectedTestingPhase;
	}
	
	public void setSelectedTestingPhase(Long selectedTestingPhase) {
	
		this.selectedTestingPhase = selectedTestingPhase;
	}
	
	public int getDay() {
	
		return day;
	}
	
	public void setDay(int day) {
	
		this.day = day;
	}
	
	public String getMonth() {
	
		return month;
	}
	
	public void setMonth(String month) {
	
		this.month = month;
	}
	
	public int getYear() {
	
		return year;
	}
	
	public void setYear(int year) {
	
		this.year = year;
	}
	
	public Long getService() {
	
		return service;
	}
	
	public void setService(Long service) {
	
		this.service = service;
	}
	
	public int getMonthForDay() {
	
		return monthForDay;
	}
	
	public void setMonthForDay(int monthForDay) {
	
		this.monthForDay = monthForDay;
	}
	
	public String getActionFlagForGraph() {
	
		return actionFlagForGraph;
	}
	
	public void setActionFlagForGraph(String actionFlagForGraph) {
	
		this.actionFlagForGraph = actionFlagForGraph;
	}
	
	private int day;
	private String month;
	private int year;
	private Long service;
	private int monthForDay;
	private String actionFlagForGraph;
	
	public String getActionFlag() {
	
		return actionFlag;
	}
	
	public String getActualCron() {
	
		return actualCron;
	}
	
	public String getAgentType() {
	
		return agentType;
	}
	
	public List<ApplicationTO> getAllApplications() {
	
		return allApplications;
	}
	
	public List<ApplicationProfileTO> getAllProfiles() {
	
		return allProfiles;
	}
	
	public List<ServiceTO> getAllServices() {
	
		return allServices;
	}
	
	public List<TestingPhaseTO> getAllTestingCycles() {
	
		return allTestingCycles;
	}
	
	public List<String> getAllTools() {
	
		return allTools;
	}
	
	public Long getApplicationId() {
	
		return applicationId;
	}
	
	public String getApplicationName() {
	
		return applicationName;
	}
	
	public Long getApplicationReleaseId() {
	
		return applicationReleaseId;
	}
	
	public List<ApplicationReleaseTO> getApplicationReleaseTO() {
	
		return applicationReleaseTO;
	}
	
	public ApplicationTO getApplicationTO() {
	
		return applicationTO;
	}
	
	public List<ApplicationTO> getAppList() {
	
		return appList;
	}
	
	public List<EnvironmentApplicationTO> getAppReleaseList() {
	
		return appReleaseList;
	}
	
	public List<ServiceRequestTO> getAppSerSoftListForm() {
	
		return appSerSoftListForm;
	}
	
	public List<ServiceRequestTO> getBuildMonth1() {
	
		return buildMonth1;
	}
	
	public BusinessUnitTO getBusinessUnitTO() {
	
		return businessUnitTO;
	}
	
	public Long getChildRequestExecutionOrder() {
	
		return childRequestExecutionOrder;
	}
	
	public String getChildWorkflowFlag() {
	
		return childWorkflowFlag;
	}
	
	public Long getClientId() {
	
		return clientId;
	}
	
	public Long getCpuNo() {
	
		return cpuNo;
	}
	
	public Date getCreatedByDate() {
	
		return createdByDate;
	}
	
	public String getCreatedByDateStr() {
	
		return createdByDateStr;
	}
	
	public String getCronExp() {
	
		return cronExp;
	}
	
	public Date getEndTime() {
	
		return endTime;
	}
	
	public String getEndTimeStr() {
	
		return endTimeStr;
	}
	
	public Long getEnvironmentDetailId() {
	
		return environmentDetailId;
	}
	
	public Long getEnvironmentdetailsId() {
	
		return environmentdetailsId;
	}
	
	public Long getEnvironmentId() {
	
		return environmentId;
	}
	
	public String getEnvironmentName() {
	
		return environmentName;
	}
	
	public EnvironmentTO getEnvironmentTO() {
	
		return environmentTO;
	}
	
	public List<EnvironmentSoftwareAttributeTO> getEnvSoftwareAttributeList() {
	
		return envSoftwareAttributeList;
	}
	
	public int getFirstResult() {
	
		return firstResult;
	}
	
	public int getFlag() {
	
		return flag;
	}
	
	public Long getHardwareId() {
	
		return hardwareId;
	}
	
	public String getImageTitle() {
	
		return imageTitle;
	}
	
	public String getIsScheduled() {
	
		return isScheduled;
	}
	
	public String getJiraIssue() {
	
		return jiraIssue;
	}
	
	public List<String> getJiraIssueList() {
	
		return jiraIssueList;
	}
	
	public String getJiraRadio() {
	
		return jiraRadio;
	}
	
	public Long getMemory() {
	
		return memory;
	}
	
	public Date getModifiedbyDate() {
	
		return modifiedbyDate;
	}
	
	public List<MultipleProfileDetailsTO> getMultipleEnvReqList() {
	
		return multipleEnvReqList;
	}
	
	public String getNewReleaseName() {
	
		return newReleaseName;
	}
	
	public long getPageNumber() {
	
		return pageNumber;
	}
	
	public Long getParentRequestId() {
	
		return parentRequestId;
	}
	
	public String getPassword() {
	
		return password;
	}
	
	public String getPathForCode() {
	
		return pathForCode;
	}
	
	public String getPipelineRequest() {
	
		return pipelineRequest;
	}
	
	public Set<PipelineRequestDetailsTO> getPipelineRequestDetails() {
	
		return pipelineRequestDetails;
	}
	
	public Long getProfileId() {
	
		return profileId;
	}
	
	public ProjectsTO getProjectTO() {
	
		return projectTO;
	}
	
	public Long getPromotedEnvironment() {
	
		return promotedEnvironment;
	}
	
	public Map<String, String> getPropertiesMap() {
	
		return propertiesMap;
	}
	
	public List<ProvisionedMachineTO> getProvisionedMachineDetails() {
	
		return provisionedMachineDetails;
	}
	
	public Long getProvisionedMachineId() {
	
		return provisionedMachineId;
	}
	
	public String getProvisionedMachineIdNew() {
	
		return provisionedMachineIdNew;
	}
	
	public ApplicationReleaseTO getRelease() {
	
		return release;
	}
	
	public String getReleaseName() {
	
		return releaseName;
	}
	
	public ApplicationReleaseTO getReleaseTO() {
	
		return releaseTO;
	}
	
	public String getRemark() {
	
		return remark;
	}
	
	public Long getRequestId() {
	
		return requestId;
	}
	
	public String getScriptsSvnUrl() {
	
		return scriptsSvnUrl;
	}
	
	public long getSearchCount() {
	
		return searchCount;
	}
	
	public Long getSelectedApplication() {
	
		return selectedApplication;
	}
	
	public Long getSelectedEnvironment() {
	
		return selectedEnvironment;
	}
	
	public String getSelectedIssueType() {
	
		return selectedIssueType;
	}
	
	public String getSelectedJiraIssue() {
	
		return selectedJiraIssue;
	}
	
	public Long getSelectedProfile() {
	
		return selectedProfile;
	}
	
	public Long getSelectedProfiles() {
	
		return selectedProfiles;
	}
	
	public Long getSelectedService() {
	
		return selectedService;
	}
	
	public Long getSelectedSoftwareConfigIdForInstallation() {
	
		return selectedSoftwareConfigIdForInstallation;
	}
	
	public String getSelectedSoftwareForInstallation() {
	
		return selectedSoftwareForInstallation;
	}
	
	public Long getSelectedTestingCycle() {
	
		return selectedTestingCycle;
	}
	
	public String getSelectedTool() {
	
		return selectedTool;
	}
	
	public Long getServerGroupNumber() {
	
		return serverGroupNumber;
	}
	
	public Long getServiceId() {
	
		return serviceId;
	}
	
	public Set<ServiceRequestDetailsTO> getServiceReqDetails() {
	
		return serviceReqDetails;
	}
	
	public List<ServiceRequestDetailsTO> getServiceRequestDetList() {
	
		return serviceRequestDetList;
	}
	
	public List<ServiceRequestHistoryTO> getServiceRequestHistoryTOList() {
	
		return serviceRequestHistoryTOList;
	}
	
	public List<ServiceRequestTO> getServiceRequestTo() {
	
		return serviceRequestTo;
	}
	
	public ServiceTO getServiceTO() {
	
		return serviceTO;
	}
	
	public Long getSoftwareConfigId() {
	
		return softwareConfigId;
	}
	
	public Long getSoftwareId() {
	
		return softwareId;
	}
	
	public String getSoftwareName() {
	
		return softwareName;
	}
	
	public Date getStartTime() {
	
		return startTime;
	}
	
	public String getStartTimeStr() {
	
		return startTimeStr;
	}
	
	public Long getStatus() {
	
		return status;
	}
	
	public Long getStatusId() {
	
		return statusId;
	}
	
	public String getStatusImage() {
	
		return statusImage;
	}
	
	public StatusTO getStatusTO() {
	
		return statusTO;
	}
	
	public int getSuccess() {
	
		return success;
	}
	
	public String getSvnUserName() {
	
		return svnUserName;
	}
	
	public String getSwInstallationReq() {
	
		return swInstallationReq;
	}
	
	public String getSwInstallationStatus() {
	
		return swInstallationStatus;
	}
	
	public int getTableSize() {
	
		return tableSize;
	}
	
	public String getTemplateName() {
	
		return templateName;
	}
	
	public long getUserId() {
	
		return userId;
	}
	
	public UserTO getUserTO() {
	
		return userTO;
	}
	
	public Set<VMDetailsTO> getVmDetailsSet() {
	
		return vmDetailsSet;
	}
	
	public String getVmHost() {
	
		return vmHost;
	}
	
	public String getVmIp() {
	
		return vmIp;
	}
	
	public String getWarName() {
	
		return WarName;
	}
	
	public Set<WorkflowCurrentTO> getWorkflowCurrentTO() {
	
		return workflowCurrentTO;
	}
	
	public Long getWorkFlowId() {
	
		return workFlowId;
	}
	
	public boolean isAccess() {
	
		return access;
	}
	
	public boolean isGenerateWorkFlow() {
	
		return generateWorkFlow;
	}
	
	public boolean isLastPhase() {
	
		return lastPhase;
	}
	
	public void setAccess(boolean access) {
	
		this.access = access;
	}
	
	public void setActionFlag(String actionFlag) {
	
		this.actionFlag = actionFlag;
	}
	
	public void setActualCron(String actualCron) {
	
		this.actualCron = actualCron;
	}
	
	public void setAgentType(String agentType) {
	
		this.agentType = agentType;
	}
	
	public void setAllApplications(List<ApplicationTO> allApplications) {
	
		this.allApplications = allApplications;
	}
	
	public void setAllProfiles(List<ApplicationProfileTO> allProfiles) {
	
		this.allProfiles = allProfiles;
	}
	
	public void setAllServices(List<ServiceTO> allServices) {
	
		this.allServices = allServices;
	}
	
	public void setAllTestingCycles(List<TestingPhaseTO> allTestingCycles) {
	
		this.allTestingCycles = allTestingCycles;
	}
	
	public void setAllTools(List<String> allTools) {
	
		this.allTools = allTools;
	}
	
	public void setApplicationId(Long applicationId) {
	
		this.applicationId = applicationId;
	}
	
	public void setApplicationName(String applicationName) {
	
		this.applicationName = applicationName;
	}
	
	public void setApplicationReleaseId(Long applicationReleaseId) {
	
		this.applicationReleaseId = applicationReleaseId;
	}
	
	public void setApplicationReleaseTO(List<ApplicationReleaseTO> applicationReleaseTO) {
	
		this.applicationReleaseTO = applicationReleaseTO;
	}
	
	public void setApplicationTO(ApplicationTO applicationTO) {
	
		this.applicationTO = applicationTO;
	}
	
	public void setAppList(List<ApplicationTO> appList) {
	
		this.appList = appList;
	}
	
	public void setAppReleaseList(List<EnvironmentApplicationTO> appReleaseList) {
	
		this.appReleaseList = appReleaseList;
	}
	
	public void setAppSerSoftListForm(List<ServiceRequestTO> appSerSoftListForm) {
	
		this.appSerSoftListForm = appSerSoftListForm;
	}
	
	public void setBuildMonth1(List<ServiceRequestTO> buildMonth1) {
	
		this.buildMonth1 = buildMonth1;
	}
	
	/*********** Jira Changes end **********/
	public void setBusinessUnitTO(BusinessUnitTO businessUnitTO) {
	
		this.businessUnitTO = businessUnitTO;
	}
	
	public void setChildRequestExecutionOrder(Long childRequestExecutionOrder) {
	
		this.childRequestExecutionOrder = childRequestExecutionOrder;
	}
	
	public void setChildWorkflowFlag(String childWorkflowFlag) {
	
		this.childWorkflowFlag = childWorkflowFlag;
	}
	
	public void setClientId(Long clientId) {
	
		this.clientId = clientId;
	}
	
	public void setCpuNo(Long cpuNo) {
	
		this.cpuNo = cpuNo;
	}
	
	public void setCreatedByDate(Date createdByDate) {
	
		this.createdByDate = createdByDate;
	}
	
	public void setCreatedByDateStr(String createdByDateStr) {
	
		this.createdByDateStr = createdByDateStr;
	}
	
	public void setCronExp(String cronExp) {
	
		this.cronExp = cronExp;
	}
	
	public void setEndTime(Date endTime) {
	
		this.endTime = endTime;
	}
	
	public void setEndTimeStr(String endTimeStr) {
	
		this.endTimeStr = endTimeStr;
	}
	
	public void setEnvironmentDetailId(Long environmentDetailId) {
	
		this.environmentDetailId = environmentDetailId;
	}
	
	public void setEnvironmentdetailsId(Long environmentdetailsId) {
	
		this.environmentdetailsId = environmentdetailsId;
	}
	
	public void setEnvironmentId(Long environmentId) {
	
		this.environmentId = environmentId;
	}
	
	public void setEnvironmentName(String environmentName) {
	
		this.environmentName = environmentName;
	}
	
	public void setEnvironmentTO(EnvironmentTO environmentTO) {
	
		this.environmentTO = environmentTO;
	}
	
	public void setEnvSoftwareAttributeList(List<EnvironmentSoftwareAttributeTO> envSoftwareAttributeList) {
	
		this.envSoftwareAttributeList = envSoftwareAttributeList;
	}
	
	public void setFirstResult(int firstResult) {
	
		this.firstResult = firstResult;
	}
	
	public void setFlag(int flag) {
	
		this.flag = flag;
	}
	
	public void setGenerateWorkFlow(boolean generateWorkFlow) {
	
		this.generateWorkFlow = generateWorkFlow;
	}
	
	public void setHardwareId(Long hardwareId) {
	
		this.hardwareId = hardwareId;
	}
	
	public void setImageTitle(String imageTitle) {
	
		this.imageTitle = imageTitle;
	}
	
	public void setIsScheduled(String isScheduled) {
	
		this.isScheduled = isScheduled;
	}
	
	public void setJiraIssue(String jiraIssue) {
	
		this.jiraIssue = jiraIssue;
	}
	
	public void setJiraIssueList(List<String> jiraIssueList) {
	
		this.jiraIssueList = jiraIssueList;
	}
	
	public void setJiraRadio(String jiraRadio) {
	
		this.jiraRadio = jiraRadio;
	}
	
	public void setLastPhase(boolean lastPhase) {
	
		this.lastPhase = lastPhase;
	}
	
	public void setMemory(Long memory) {
	
		this.memory = memory;
	}
	
	public void setModifiedbyDate(Date modifiedbyDate) {
	
		this.modifiedbyDate = modifiedbyDate;
	}
	
	public void setMultipleEnvReqList(List<MultipleProfileDetailsTO> multipleEnvReqList) {
	
		this.multipleEnvReqList = multipleEnvReqList;
	}
	
	public void setNewReleaseName(String newReleaseName) {
	
		this.newReleaseName = newReleaseName;
	}
	
	public void setPageNumber(long pageNumber) {
	
		this.pageNumber = pageNumber;
	}
	
	public void setParentRequestId(Long parentRequestId) {
	
		this.parentRequestId = parentRequestId;
	}
	
	public void setPassword(String password) {
	
		this.password = password;
	}
	
	public void setPathForCode(String pathForCode) {
	
		this.pathForCode = pathForCode;
	}
	
	public void setPipelineRequest(String pipelineRequest) {
	
		this.pipelineRequest = pipelineRequest;
	}
	
	public void setPipelineRequestDetails(Set<PipelineRequestDetailsTO> pipelineRequestDetails) {
	
		this.pipelineRequestDetails = pipelineRequestDetails;
	}
	
	public void setProfileId(Long profileId) {
	
		this.profileId = profileId;
	}
	
	public void setProjectTO(ProjectsTO projectTO) {
	
		this.projectTO = projectTO;
	}
	
	public void setPromotedEnvironment(Long promotedEnvironment) {
	
		this.promotedEnvironment = promotedEnvironment;
	}
	
	public void setPropertiesMap(Map<String, String> propertiesMap) {
	
		this.propertiesMap = propertiesMap;
	}
	
	public void setProvisionedMachineDetails(List<ProvisionedMachineTO> provisionedMachineDetails) {
	
		this.provisionedMachineDetails = provisionedMachineDetails;
	}
	
	public void setProvisionedMachineId(Long provisionedMachineId) {
	
		this.provisionedMachineId = provisionedMachineId;
	}
	
	public void setProvisionedMachineIdNew(String provisionedMachineIdNew) {
	
		this.provisionedMachineIdNew = provisionedMachineIdNew;
	}
	
	public void setRelease(ApplicationReleaseTO release) {
	
		this.release = release;
	}
	
	public void setReleaseName(String releaseName) {
	
		this.releaseName = releaseName;
	}
	
	public void setReleaseTO(ApplicationReleaseTO releaseTO) {
	
		this.releaseTO = releaseTO;
	}
	
	public void setRemark(String remark) {
	
		this.remark = remark;
	}
	
	public void setRequestId(Long requestId) {
	
		this.requestId = requestId;
	}
	
	public void setScriptsSvnUrl(String scriptsSvnUrl) {
	
		this.scriptsSvnUrl = scriptsSvnUrl;
	}
	
	public void setSearchCount(long searchCount) {
	
		this.searchCount = searchCount;
	}
	
	public void setSelectedApplication(Long selectedApplication) {
	
		this.selectedApplication = selectedApplication;
	}
	
	public void setSelectedEnvironment(Long selectedEnvironment) {
	
		this.selectedEnvironment = selectedEnvironment;
	}
	
	public void setSelectedIssueType(String selectedIssueType) {
	
		this.selectedIssueType = selectedIssueType;
	}
	
	public void setSelectedJiraIssue(String selectedJiraIssue) {
	
		this.selectedJiraIssue = selectedJiraIssue;
	}
	
	public void setSelectedProfile(Long selectedProfile) {
	
		this.selectedProfile = selectedProfile;
	}
	
	public void setSelectedProfiles(Long selectedProfiles) {
	
		this.selectedProfiles = selectedProfiles;
	}
	
	public void setSelectedService(Long selectedService) {
	
		this.selectedService = selectedService;
	}
	
	public void setSelectedSoftwareConfigIdForInstallation(Long selectedSoftwareConfigIdForInstallation) {
	
		this.selectedSoftwareConfigIdForInstallation = selectedSoftwareConfigIdForInstallation;
	}
	
	public void setSelectedSoftwareForInstallation(String selectedSoftwareForInstallation) {
	
		this.selectedSoftwareForInstallation = selectedSoftwareForInstallation;
	}
	
	public void setSelectedTestingCycle(Long selectedTestingCycle) {
	
		this.selectedTestingCycle = selectedTestingCycle;
	}
	
	public void setSelectedTool(String selectedTool) {
	
		this.selectedTool = selectedTool;
	}
	
	public void setServerGroupNumber(Long serverGroupNumber) {
	
		this.serverGroupNumber = serverGroupNumber;
	}
	
	public void setServiceId(Long serviceId) {
	
		this.serviceId = serviceId;
	}
	
	public void setServiceReqDetails(Set<ServiceRequestDetailsTO> serviceReqDetails) {
	
		this.serviceReqDetails = serviceReqDetails;
	}
	
	public void setServiceRequestDetList(List<ServiceRequestDetailsTO> serviceRequestDetList) {
	
		this.serviceRequestDetList = serviceRequestDetList;
	}
	
	public void setServiceRequestHistoryTOList(List<ServiceRequestHistoryTO> serviceRequestHistoryTOList) {
	
		this.serviceRequestHistoryTOList = serviceRequestHistoryTOList;
	}
	
	public void setServiceRequestTo(List<ServiceRequestTO> serviceRequestTo) {
	
		this.serviceRequestTo = serviceRequestTo;
	}
	
	public void setServiceTO(ServiceTO serviceTO) {
	
		this.serviceTO = serviceTO;
	}
	
	public void setSoftwareConfigId(Long softwareConfigId) {
	
		this.softwareConfigId = softwareConfigId;
	}
	
	public void setSoftwareId(Long softwareId) {
	
		this.softwareId = softwareId;
	}
	
	public void setSoftwareName(String softwareName) {
	
		this.softwareName = softwareName;
	}
	
	public void setStartTime(Date startTime) {
	
		this.startTime = startTime;
	}
	
	public void setStartTimeStr(String startTimeStr) {
	
		this.startTimeStr = startTimeStr;
	}
	
	public void setStatus(Long status) {
	
		this.status = status;
	}
	
	public void setStatusId(Long statusId) {
	
		this.statusId = statusId;
	}
	
	public void setStatusImage(String statusImage) {
	
		this.statusImage = statusImage;
	}
	
	public void setStatusTO(StatusTO statusTO) {
	
		this.statusTO = statusTO;
	}
	
	public void setSuccess(int success) {
	
		this.success = success;
	}
	
	public void setSvnUserName(String svnUserName) {
	
		this.svnUserName = svnUserName;
	}
	
	public void setSwInstallationReq(String swInstallationReq) {
	
		this.swInstallationReq = swInstallationReq;
	}
	
	public void setSwInstallationStatus(String swInstallationStatus) {
	
		this.swInstallationStatus = swInstallationStatus;
	}
	
	public void setTableSize(int tableSize) {
	
		this.tableSize = tableSize;
	}
	
	public void setTemplateName(String templateName) {
	
		this.templateName = templateName;
	}
	
	public void setUserId(long userId) {
	
		this.userId = userId;
	}
	
	public void setUserTO(UserTO userTO) {
	
		this.userTO = userTO;
	}
	
	public void setVmDetailsSet(Set<VMDetailsTO> vmDetailsSet) {
	
		this.vmDetailsSet = vmDetailsSet;
	}
	
	public void setVmHost(String vmHost) {
	
		this.vmHost = vmHost;
	}
	
	public void setVmIp(String vmIp) {
	
		this.vmIp = vmIp;
	}
	
	public void setWarName(String warName) {
	
		WarName = warName;
	}
	
	public void setWorkflowCurrentTO(Set<WorkflowCurrentTO> workflowCurrentTO) {
	
		this.workflowCurrentTO = workflowCurrentTO;
	}
	
	public void setWorkFlowId(Long workFlowId) {
	
		this.workFlowId = workFlowId;
	}
	
	public Long getSelectedBu() {
	
		return selectedBu;
	}
	
	public void setSelectedBu(Long selectedBu) {
	
		this.selectedBu = selectedBu;
	}
	
	public Long getSelectedProject() {
	
		return selectedProject;
	}
	
	public void setSelectedProject(Long selectedProject) {
	
		this.selectedProject = selectedProject;
	}
	
	public Long getSelectedApplicationRelease() {
	
		return selectedApplicationRelease;
	}
	
	public void setSelectedApplicationRelease(Long selectedApplicationRelease) {
	
		this.selectedApplicationRelease = selectedApplicationRelease;
	}
	
	public String getFormatDate() {
	
		return formatDate;
	}
	
	public void setFormatDate(String formatDate) {
	
		this.formatDate = formatDate;
	}
	
	public String getFormatDate1() {
	
		return formatDate1;
	}
	
	public void setFormatDate1(String formatDate1) {
	
		this.formatDate1 = formatDate1;
	}
	
	public String getToolConfigLocation() {
	
		return toolConfigLocation;
	}
	
	public void setToolConfigLocation(String toolConfigLocation) {
	
		this.toolConfigLocation = toolConfigLocation;
	}
	
	public Long getSelPort() {
	
		return selPort;
	}
	
	public void setSelPort(Long selPort) {
	
		this.selPort = selPort;
	}
	
	public String getResultLocation() {
	
		return resultLocation;
	}
	
	public void setResultLocation(String resultLocation) {
	
		this.resultLocation = resultLocation;
	}
	
	public String getScriptCopyLocation() {
	
		return scriptCopyLocation;
	}
	
	public void setScriptCopyLocation(String scriptCopyLocation) {
	
		this.scriptCopyLocation = scriptCopyLocation;
	}
	
	private Long selectedBu;
	private Long selectedProject;
	private Long selectedApplicationRelease;
	
	public String getPerfectoBaseUrl() {
	
		return perfectoBaseUrl;
	}
	
	public void setPerfectoBaseUrl(String perfectoBaseUrl) {
	
		this.perfectoBaseUrl = perfectoBaseUrl;
	}
	
	public String getPerfectoUserName() {
	
		return perfectoUserName;
	}
	
	public void setPerfectoUserName(String perfectoUserName) {
	
		this.perfectoUserName = perfectoUserName;
	}
	
	public String getPerfectoPassword() {
	
		return perfectoPassword;
	}
	
	public void setPerfectoPassword(String perfectoPassword) {
	
		this.perfectoPassword = perfectoPassword;
	}
	
	public List<EnvTypeTO> getAllEnvType() {
	
		return allEnvType;
	}
	
	public void setAllEnvType(List<EnvTypeTO> allEnvType) {
	
		this.allEnvType = allEnvType;
	}
	
	public Long getSelectedEnvType() {
	
		return selectedEnvType;
	}
	
	public void setSelectedEnvType(Long selectedEnvType) {
	
		this.selectedEnvType = selectedEnvType;
	}
	
	public List<NolioProcessParametersTO> getParametersList() {
	
		return parametersList;
	}
	
	public void setParametersList(List<NolioProcessParametersTO> parametersList) {
	
		this.parametersList = parametersList;
	}
}