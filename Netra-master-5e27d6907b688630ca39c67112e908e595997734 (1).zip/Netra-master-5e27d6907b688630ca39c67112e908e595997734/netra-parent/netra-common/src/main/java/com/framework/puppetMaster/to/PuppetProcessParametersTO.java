package com.framework.puppetMaster.to;

import java.io.Serializable;

/**
 * @author 584175
 */
public class PuppetProcessParametersTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7673297000376417897L;
	private long parameterId;
	private long processId;
	private String parameterPathName;
	private String parameterValue;
	private Long id;
	private String name;
	private String status;
	private PuppetProcess puppetProcess;
	private String netraParameterName;
	private String netraParameterMapping;
	
	@Override
	public boolean equals(Object obj) {
	
		if (obj == null) {
			return false;
		}
		if (!this.getClass().equals(obj.getClass())) {
			return false;
		}
		PuppetProcessParametersTO obj2 = (PuppetProcessParametersTO) obj;
		if ((this.parameterId == obj2.getParameterId()) && this.parameterPathName.equals(obj2.getParameterPathName())) {
			return true;
		}
		return false;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public String getName() {
	
		return name;
	}
	
	/**
	 * @return the netraParameterMapping
	 */
	public String getNetraParameterMapping() {
	
		return netraParameterMapping;
	}
	
	/**
	 * @return the netraParameterName
	 */
	public String getNetraParameterName() {
	
		return netraParameterName;
	}
	
	public long getParameterId() {
	
		return parameterId;
	}
	
	public String getParameterPathName() {
	
		return parameterPathName;
	}
	
	public String getParameterValue() {
	
		return parameterValue;
	}
	
	/**
	 * @return the processId
	 */
	public long getProcessId() {
	
		return processId;
	}
	
	public PuppetProcess getPuppetProcess() {
	
		return puppetProcess;
	}
	
	public String getStatus() {
	
		return status;
	}
	
	@Override
	public int hashCode() {
	
		int tmp = 0;
		tmp = (parameterId + parameterPathName).hashCode();
		return tmp;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setName(String name) {
	
		this.name = name;
	}
	
	/**
	 * @param netraParameterMapping
	 *                the netraParameterMapping to set
	 */
	public void setNetraParameterMapping(String netraParameterMapping) {
	
		this.netraParameterMapping = netraParameterMapping;
	}
	
	/**
	 * @param netraParameterName
	 *                the netraParameterName to set
	 */
	public void setNetraParameterName(String netraParameterName) {
	
		this.netraParameterName = netraParameterName;
	}
	
	public void setParameterId(long parameterId) {
	
		this.parameterId = parameterId;
	}
	
	public void setParameterPathName(String parameterPathName) {
	
		this.parameterPathName = parameterPathName;
	}
	
	public void setParameterValue(String parameterValue) {
	
		this.parameterValue = parameterValue;
	}
	
	/**
	 * @param processId
	 *                the processId to set
	 */
	public void setProcessId(long processId) {
	
		this.processId = processId;
	}
	
	public void setPuppetProcess(PuppetProcess puppetProcess) {
	
		this.puppetProcess = puppetProcess;
	}
	
	public void setStatus(String status) {
	
		this.status = status;
	}
}
