/**
 *
 */
package com.framework.to;

import java.io.Serializable;

/**
 * @author 460650
 */
public class ProvisionedMachineOSTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -137948706068011693L;
	private int id;
	private String flavorType;
	private String flavorId;
	private Long provisionedMachineId;
	private String serverId;
	private String disk;
	private String username;
	private String password;
	private ProvisionedMachineTO provisionedMachine;
	
	public String getDisk() {
	
		return disk;
	}
	
	public String getFlavorId() {
	
		return flavorId;
	}
	
	public String getFlavorType() {
	
		return flavorType;
	}
	
	public int getId() {
	
		return id;
	}
	
	public String getPassword() {
	
		return password;
	}
	
	public ProvisionedMachineTO getProvisionedMachine() {
	
		return provisionedMachine;
	}
	
	public Long getProvisionedMachineId() {
	
		return provisionedMachineId;
	}
	
	public String getServerId() {
	
		return serverId;
	}
	
	public String getUsername() {
	
		return username;
	}
	
	public void setDisk(String disk) {
	
		this.disk = disk;
	}
	
	public void setFlavorId(String flavorId) {
	
		this.flavorId = flavorId;
	}
	
	public void setFlavorType(String flavorType) {
	
		this.flavorType = flavorType;
	}
	
	public void setId(int id) {
	
		this.id = id;
	}
	
	public void setPassword(String password) {
	
		this.password = password;
	}
	
	public void setProvisionedMachine(ProvisionedMachineTO provisionedMachine) {
	
		this.provisionedMachine = provisionedMachine;
	}
	
	public void setProvisionedMachineId(Long provisionedMachineId) {
	
		this.provisionedMachineId = provisionedMachineId;
	}
	
	public void setServerId(String serverId) {
	
		this.serverId = serverId;
	}
	
	public void setUsername(String username) {
	
		this.username = username;
	}
}
