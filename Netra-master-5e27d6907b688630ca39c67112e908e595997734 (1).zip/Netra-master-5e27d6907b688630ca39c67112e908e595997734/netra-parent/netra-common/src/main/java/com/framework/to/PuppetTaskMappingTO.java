/**
 *
 */
package com.framework.to;

import com.framework.puppetMaster.to.PuppetProcess;

/**
 * @author 737070
 */
public class PuppetTaskMappingTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4765549894542392742L;
	private PuppetProcess puppetProcess;
	private long taskId;
	private TaskManagementTO taskManagementTO;
	private long processOrder;
	
	public PuppetProcess getPuppetProcess() {
	
		return puppetProcess;
	}
	
	public void setPuppetProcess(PuppetProcess puppetProcess) {
	
		this.puppetProcess = puppetProcess;
	}
	
	public long getTaskId() {
	
		return taskId;
	}
	
	public void setTaskId(long taskId) {
	
		this.taskId = taskId;
	}
	
	public TaskManagementTO getTaskManagementTO() {
	
		return taskManagementTO;
	}
	
	public void setTaskManagementTO(TaskManagementTO taskManagementTO) {
	
		this.taskManagementTO = taskManagementTO;
	}
	
	public long getProcessOrder() {
	
		return processOrder;
	}
	
	public void setProcessOrder(long processOrder) {
	
		this.processOrder = processOrder;
	}
}
