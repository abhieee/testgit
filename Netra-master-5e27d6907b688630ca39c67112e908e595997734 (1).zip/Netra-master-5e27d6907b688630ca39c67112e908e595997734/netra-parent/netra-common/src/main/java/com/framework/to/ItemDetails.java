package com.framework.to;

import java.io.Serializable;

public class ItemDetails implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6300697125653414824L;
	private String hostName;
	private String minValue;
	private String maxValue;
	private String units;
	
	public String getHostName() {
	
		return hostName;
	}
	
	public String getMaxValue() {
	
		return maxValue;
	}
	
	public String getMinValue() {
	
		return minValue;
	}
	
	public String getUnits() {
	
		return units;
	}
	
	public void setHostName(String hostName) {
	
		this.hostName = hostName;
	}
	
	public void setMaxValue(String maxValue) {
	
		this.maxValue = maxValue;
	}
	
	public void setMinValue(String minValue) {
	
		this.minValue = minValue;
	}
	
	public void setUnits(String units) {
	
		this.units = units;
	}
}
