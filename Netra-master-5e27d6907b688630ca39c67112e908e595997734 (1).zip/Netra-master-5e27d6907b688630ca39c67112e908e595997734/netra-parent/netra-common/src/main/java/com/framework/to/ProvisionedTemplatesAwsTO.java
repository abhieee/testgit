package com.framework.to;

import java.io.Serializable;

public class ProvisionedTemplatesAwsTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5714697869394385770L;
	private Long id;
	private Long awsAccountId;
	private String imageId;
	private Long provisionedPlatformId;
	
	public Long getAwsAccountId() {
	
		return awsAccountId;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public String getImageId() {
	
		return imageId;
	}
	
	public Long getProvisionedPlatformId() {
	
		return provisionedPlatformId;
	}
	
	public void setAwsAccountId(Long awsAccountId) {
	
		this.awsAccountId = awsAccountId;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setImageId(String imageId) {
	
		this.imageId = imageId;
	}
	
	public void setProvisionedPlatformId(Long provisionedPlatformId) {
	
		this.provisionedPlatformId = provisionedPlatformId;
	}
}
