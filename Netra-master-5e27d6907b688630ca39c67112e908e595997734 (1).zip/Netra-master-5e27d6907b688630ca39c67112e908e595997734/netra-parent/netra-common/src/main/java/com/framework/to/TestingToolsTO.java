package com.framework.to;

import java.util.HashSet;
import java.util.Set;

public class TestingToolsTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -727631805612851565L;
	private Long businessUnitId;
	private Long projectId;
	private Long applicationId;
	private Long testingToolId;
	private Long provMachineId;
	private String scriptCopyLocation;
	private String selJarLocation;
	private String username;
	private String password;
	private String machineUsername;
	private String machinePassword;
	private String type;
	private String ip;
	private String serverURL;
	private String domain;
	private String parameterName;
	private Long selectedtestingToolName;
	private ApplicationTO applicationTO;
	private ProjectsTO projectsTO;
	private ClientTO clientTO;
	private TestingToolTO testingToolTO;
	private String buName;
	private String projectName;
	private String applicationName;
	private String testingTool;
	private Long selectedBUId;
	private Long selectedProjectId;
	private Long selectedApplicationId;
	private String tamAdapterFlag;
	private String tamAdapterName;
	private String adapterWinCopyLoc;
	private String adapterLinuxCopyLoc;
	private String executionServerName;
	private Long selPort;
	private String resultLocation;
	private Set<TestingToolsMappingTO> testingToolsMappingSet = new HashSet<TestingToolsMappingTO>(0);
	
	/**
	 * @return the adapterLinuxCopyLoc
	 */
	public String getAdapterLinuxCopyLoc() {
	
		return adapterLinuxCopyLoc;
	}
	
	/**
	 * @return the adapterWinCopyLoc
	 */
	public String getAdapterWinCopyLoc() {
	
		return adapterWinCopyLoc;
	}
	
	/**
	 * @return the applicationId
	 */
	public Long getApplicationId() {
	
		return applicationId;
	}
	
	public String getApplicationName() {
	
		return applicationName;
	}
	
	public ApplicationTO getApplicationTO() {
	
		return applicationTO;
	}
	
	public String getBuName() {
	
		return buName;
	}
	
	/**
	 * @return the businessUnitId
	 */
	public Long getBusinessUnitId() {
	
		return businessUnitId;
	}
	
	public ClientTO getClientTO() {
	
		return clientTO;
	}
	
	public String getDomain() {
	
		return domain;
	}
	
	/**
	 * @return the executionServerName
	 */
	public String getExecutionServerName() {
	
		return executionServerName;
	}
	
	/**
	 * @return the ip
	 */
	public String getIp() {
	
		return ip;
	}
	
	/**
	 * @return the machinePassword
	 */
	public String getMachinePassword() {
	
		return machinePassword;
	}
	
	/**
	 * @return the machineUsername
	 */
	public String getMachineUsername() {
	
		return machineUsername;
	}
	
	/**
	 * @return the parameterName
	 */
	public String getParameterName() {
	
		return parameterName;
	}
	
	/**
	 * @return the password
	 */
	public String getPassword() {
	
		return password;
	}
	
	/**
	 * @return the projectId
	 */
	public Long getProjectId() {
	
		return projectId;
	}
	
	public String getProjectName() {
	
		return projectName;
	}
	
	public ProjectsTO getProjectsTO() {
	
		return projectsTO;
	}
	
	/**
	 * @return the scriptCopyLocation
	 */
	public String getScriptCopyLocation() {
	
		return scriptCopyLocation;
	}
	
	public Long getSelectedApplicationId() {
	
		return selectedApplicationId;
	}
	
	public Long getSelectedBUId() {
	
		return selectedBUId;
	}
	
	public Long getSelectedProjectId() {
	
		return selectedProjectId;
	}
	
	public Long getSelectedtestingToolName() {
	
		return selectedtestingToolName;
	}
	
	public String getServerURL() {
	
		return serverURL;
	}
	
	/**
	 * @return the tamAdapterFlag
	 */
	public String getTamAdapterFlag() {
	
		return tamAdapterFlag;
	}
	
	/**
	 * @return the tamAdapterName
	 */
	public String getTamAdapterName() {
	
		return tamAdapterName;
	}
	
	public String getTestingTool() {
	
		return testingTool;
	}
	
	public Long getTestingToolId() {
	
		return testingToolId;
	}
	
	public Set<TestingToolsMappingTO> getTestingToolsMappingSet() {
	
		return testingToolsMappingSet;
	}
	
	public TestingToolTO getTestingToolTO() {
	
		return testingToolTO;
	}
	
	/**
	 * @return the type
	 */
	public String getType() {
	
		return type;
	}
	
	/**
	 * @return the username
	 */
	public String getUsername() {
	
		return username;
	}
	
	/**
	 * @param adapterLinuxCopyLoc
	 *                the adapterLinuxCopyLoc to set
	 */
	public void setAdapterLinuxCopyLoc(String adapterLinuxCopyLoc) {
	
		this.adapterLinuxCopyLoc = adapterLinuxCopyLoc;
	}
	
	/**
	 * @param adapterWinCopyLoc
	 *                the adapterWinCopyLoc to set
	 */
	public void setAdapterWinCopyLoc(String adapterWinCopyLoc) {
	
		this.adapterWinCopyLoc = adapterWinCopyLoc;
	}
	
	/**
	 * @param applicationId
	 *                the applicationId to set
	 */
	public void setApplicationId(Long applicationId) {
	
		this.applicationId = applicationId;
	}
	
	public void setApplicationName(String applicationName) {
	
		this.applicationName = applicationName;
	}
	
	public void setApplicationTO(ApplicationTO applicationTO) {
	
		this.applicationTO = applicationTO;
	}
	
	public void setBuName(String buName) {
	
		this.buName = buName;
	}
	
	/**
	 * @param businessUnitId
	 *                the businessUnitId to set
	 */
	public void setBusinessUnitId(Long businessUnitId) {
	
		this.businessUnitId = businessUnitId;
	}
	
	public void setClientTO(ClientTO clientTO) {
	
		this.clientTO = clientTO;
	}
	
	public void setDomain(String domain) {
	
		this.domain = domain;
	}
	
	/**
	 * @param executionServerName
	 *                the executionServerName to set
	 */
	public void setExecutionServerName(String executionServerName) {
	
		this.executionServerName = executionServerName;
	}
	
	/**
	 * @param ip
	 *                the ip to set
	 */
	public void setIp(String ip) {
	
		this.ip = ip;
	}
	
	/**
	 * @param machinePassword
	 *                the machinePassword to set
	 */
	public void setMachinePassword(String machinePassword) {
	
		this.machinePassword = machinePassword;
	}
	
	/**
	 * @param machineUsername
	 *                the machineUsername to set
	 */
	public void setMachineUsername(String machineUsername) {
	
		this.machineUsername = machineUsername;
	}
	
	/**
	 * @param parameterName
	 *                the parameterName to set
	 */
	public void setParameterName(String parameterName) {
	
		this.parameterName = parameterName;
	}
	
	/**
	 * @param password
	 *                the password to set
	 */
	public void setPassword(String password) {
	
		this.password = password;
	}
	
	/**
	 * @param projectId
	 *                the projectId to set
	 */
	public void setProjectId(Long projectId) {
	
		this.projectId = projectId;
	}
	
	public void setProjectName(String projectName) {
	
		this.projectName = projectName;
	}
	
	public void setProjectsTO(ProjectsTO projectsTO) {
	
		this.projectsTO = projectsTO;
	}
	
	/**
	 * @param scriptCopyLocation
	 *                the scriptCopyLocation to set
	 */
	public void setScriptCopyLocation(String scriptCopyLocation) {
	
		this.scriptCopyLocation = scriptCopyLocation;
	}
	
	public void setSelectedApplicationId(Long selectedApplicationId) {
	
		this.selectedApplicationId = selectedApplicationId;
	}
	
	public void setSelectedBUId(Long selectedBUId) {
	
		this.selectedBUId = selectedBUId;
	}
	
	public void setSelectedProjectId(Long selectedProjectId) {
	
		this.selectedProjectId = selectedProjectId;
	}
	
	public void setSelectedtestingToolName(Long selectedtestingToolName) {
	
		this.selectedtestingToolName = selectedtestingToolName;
	}
	
	public void setServerURL(String serverURL) {
	
		this.serverURL = serverURL;
	}
	
	/**
	 * @param tamAdapterFlag
	 *                the tamAdapterFlag to set
	 */
	public void setTamAdapterFlag(String tamAdapterFlag) {
	
		this.tamAdapterFlag = tamAdapterFlag;
	}
	
	/**
	 * @param tamAdapterName
	 *                the tamAdapterName to set
	 */
	public void setTamAdapterName(String tamAdapterName) {
	
		this.tamAdapterName = tamAdapterName;
	}
	
	public void setTestingTool(String testingTool) {
	
		this.testingTool = testingTool;
	}
	
	public void setTestingToolId(Long testingToolId) {
	
		this.testingToolId = testingToolId;
	}
	
	public void setTestingToolsMappingSet(Set<TestingToolsMappingTO> testingToolsMappingSet) {
	
		this.testingToolsMappingSet = testingToolsMappingSet;
	}
	
	public void setTestingToolTO(TestingToolTO testingToolTO) {
	
		this.testingToolTO = testingToolTO;
	}
	
	/**
	 * @param type
	 *                the type to set
	 */
	public void setType(String type) {
	
		this.type = type;
	}
	
	/**
	 * @param username
	 *                the username to set
	 */
	public void setUsername(String username) {
	
		this.username = username;
	}
	
	public Long getProvMachineId() {
	
		return provMachineId;
	}
	
	public void setProvMachineId(Long provMachineId) {
	
		this.provMachineId = provMachineId;
	}
	
	public String getSelJarLocation() {
	
		return selJarLocation;
	}
	
	public void setSelJarLocation(String selJarLocation) {
	
		this.selJarLocation = selJarLocation;
	}
	
	public Long getSelPort() {
	
		return selPort;
	}
	
	public void setSelPort(Long selPort) {
	
		this.selPort = selPort;
	}
	
	public String getResultLocation() {
	
		return resultLocation;
	}
	
	public void setResultLocation(String resultLocation) {
	
		this.resultLocation = resultLocation;
	}
}
