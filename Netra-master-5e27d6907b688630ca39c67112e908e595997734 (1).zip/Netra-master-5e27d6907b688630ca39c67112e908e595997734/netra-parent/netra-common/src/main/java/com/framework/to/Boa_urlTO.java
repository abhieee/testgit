package com.framework.to;

import java.io.Serializable;

public class Boa_urlTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5282673354820178059L;
	private Long Url_id = null;
	private String URL = null;
	
	public Boa_urlTO() {
	
		/* No implementation required at the moment. Method for future use. */
	}
	
	public String getURL() {
	
		return URL;
	}
	
	public Long getUrl_id() {
	
		return Url_id;
	}
	
	public void setURL(String uRL) {
	
		URL = uRL;
	}
	
	public void setUrl_id(Long url_id) {
	
		Url_id = url_id;
	}
}
