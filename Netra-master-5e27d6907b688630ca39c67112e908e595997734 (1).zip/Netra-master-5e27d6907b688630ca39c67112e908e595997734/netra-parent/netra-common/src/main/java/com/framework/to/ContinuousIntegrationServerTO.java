/**
 *
 */
package com.framework.to;

import java.io.Serializable;
import java.util.List;

/**
 * @author 460650
 */
public class ContinuousIntegrationServerTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1456008592971932657L;
	private Long id;
	private String serverIp;
	private String serverName;
	private String serverPort;
	private String ciToolUsername;
	private String ciToolPassword;
	private Long selectedBUId;
	private Long selectedProjectId;
	private Long selectedApplicationId;
	private String machineUserName;
	private String machinePassword;
	private Long selectedTool;
	private ApplicationTO applicationTO;
	private ProjectsTO projectsTO;
	private ClientTO clientTO;
	private BuildToolTO buildToolTO;
	private String buildToolName;
	private String buName;
	private String projectName;
	private String applicationName;
	private String baseURL;
	private int tableSize;
	private long searchCount;
	private int firstResult = 1;
	private Long clientId;
	private List<Long> clients;
	
	public String getApplicationName() {
	
		return applicationName;
	}
	
	public ApplicationTO getApplicationTO() {
	
		return applicationTO;
	}
	
	public String getBaseURL() {
	
		return baseURL;
	}
	
	public String getBuildToolName() {
	
		return buildToolName;
	}
	
	public BuildToolTO getBuildToolTO() {
	
		return buildToolTO;
	}
	
	public String getBuName() {
	
		return buName;
	}
	
	public String getCiToolPassword() {
	
		return ciToolPassword;
	}
	
	public String getCiToolUsername() {
	
		return ciToolUsername;
	}
	
	public Long getClientId() {
	
		return clientId;
	}
	
	public List<Long> getClients() {
	
		return clients;
	}
	
	public ClientTO getClientTO() {
	
		return clientTO;
	}
	
	public int getFirstResult() {
	
		return firstResult;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public String getMachinePassword() {
	
		return machinePassword;
	}
	
	public String getMachineUserName() {
	
		return machineUserName;
	}
	
	public String getProjectName() {
	
		return projectName;
	}
	
	public ProjectsTO getProjectsTO() {
	
		return projectsTO;
	}
	
	public long getSearchCount() {
	
		return searchCount;
	}
	
	public Long getSelectedApplicationId() {
	
		return selectedApplicationId;
	}
	
	public Long getSelectedBUId() {
	
		return selectedBUId;
	}
	
	public Long getSelectedProjectId() {
	
		return selectedProjectId;
	}
	
	public Long getSelectedTool() {
	
		return selectedTool;
	}
	
	public String getServerIp() {
	
		return serverIp;
	}
	
	public String getServerName() {
	
		return serverName;
	}
	
	public String getServerPort() {
	
		return serverPort;
	}
	
	public int getTableSize() {
	
		return tableSize;
	}
	
	public void setApplicationName(String applicationName) {
	
		this.applicationName = applicationName;
	}
	
	public void setApplicationTO(ApplicationTO applicationTO) {
	
		this.applicationTO = applicationTO;
	}
	
	public void setBaseURL(String baseURL) {
	
		this.baseURL = baseURL;
	}
	
	public void setBuildToolName(String buildToolName) {
	
		this.buildToolName = buildToolName;
	}
	
	public void setBuildToolTO(BuildToolTO buildToolTO) {
	
		this.buildToolTO = buildToolTO;
	}
	
	public void setBuName(String buName) {
	
		this.buName = buName;
	}
	
	public void setCiToolPassword(String ciToolPassword) {
	
		this.ciToolPassword = ciToolPassword;
	}
	
	public void setCiToolUsername(String ciToolUsername) {
	
		this.ciToolUsername = ciToolUsername;
	}
	
	public void setClientId(Long clientId) {
	
		this.clientId = clientId;
	}
	
	public void setClients(List<Long> clients) {
	
		this.clients = clients;
	}
	
	public void setClientTO(ClientTO clientTO) {
	
		this.clientTO = clientTO;
	}
	
	public void setFirstResult(int firstResult) {
	
		this.firstResult = firstResult;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setMachinePassword(String machinePassword) {
	
		this.machinePassword = machinePassword;
	}
	
	public void setMachineUserName(String machineUserName) {
	
		this.machineUserName = machineUserName;
	}
	
	public void setProjectName(String projectName) {
	
		this.projectName = projectName;
	}
	
	public void setProjectsTO(ProjectsTO projectsTO) {
	
		this.projectsTO = projectsTO;
	}
	
	public void setSearchCount(long searchCount) {
	
		this.searchCount = searchCount;
	}
	
	public void setSelectedApplicationId(Long selectedApplicationId) {
	
		this.selectedApplicationId = selectedApplicationId;
	}
	
	public void setSelectedBUId(Long selectedBUId) {
	
		this.selectedBUId = selectedBUId;
	}
	
	public void setSelectedProjectId(Long selectedProjectId) {
	
		this.selectedProjectId = selectedProjectId;
	}
	
	public void setSelectedTool(Long selectedTool) {
	
		this.selectedTool = selectedTool;
	}
	
	public void setServerIp(String serverIp) {
	
		this.serverIp = serverIp;
	}
	
	public void setServerName(String serverName) {
	
		this.serverName = serverName;
	}
	
	public void setServerPort(String serverPort) {
	
		this.serverPort = serverPort;
	}
	
	public void setTableSize(int tableSize) {
	
		this.tableSize = tableSize;
	}
}
