package com.framework.to;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MultipleProfilesTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8065050425816568437L;
	private List<ApplicationTO> allApplications = new ArrayList<ApplicationTO>();
	private List<ApplicationProfileTO> allApplicationProfiles = new ArrayList<ApplicationProfileTO>();
	private Long applicationId;
	private Long applicationProfileId;
	private String applicationName;
	private Long status;
	private List<StatusTO> statusList = new ArrayList<StatusTO>(0);
	private String statusDesc;
	private Long selectedStatus = null;
	private StatusTO statusTO;
	private ApplicationTO applicationTO;
	private ApplicationProfileTO applicationProfileTO;
	private Long statusId = null;
	private Long selectedApplication = null;
	private Long selectedProfile = null;
	private Date createdByDate;
	private Date modifiedbyDate;
	private Set<MultipleProfileDetailsTO> multipleprofDetails = new HashSet<MultipleProfileDetailsTO>(0);
	private List<MultipleProfileDetailsTO> profDetails = new ArrayList<MultipleProfileDetailsTO>();
	private Long selectedMultipleProfile;
	
	public List<ApplicationProfileTO> getAllApplicationProfiles() {
	
		return allApplicationProfiles;
	}
	
	public List<ApplicationTO> getAllApplications() {
	
		return allApplications;
	}
	
	public Long getApplicationId() {
	
		return applicationId;
	}
	
	public String getApplicationName() {
	
		return applicationName;
	}
	
	public Long getApplicationProfileId() {
	
		return applicationProfileId;
	}
	
	public ApplicationProfileTO getApplicationProfileTO() {
	
		return applicationProfileTO;
	}
	
	public ApplicationTO getApplicationTO() {
	
		return applicationTO;
	}
	
	public Date getCreatedByDate() {
	
		return createdByDate;
	}
	
	public Date getModifiedbyDate() {
	
		return modifiedbyDate;
	}
	
	public Set<MultipleProfileDetailsTO> getMultipleprofDetails() {
	
		return multipleprofDetails;
	}
	
	public List<MultipleProfileDetailsTO> getProfDetails() {
	
		return profDetails;
	}
	
	public Long getSelectedApplication() {
	
		return selectedApplication;
	}
	
	public Long getSelectedMultipleProfile() {
	
		return selectedMultipleProfile;
	}
	
	public Long getSelectedProfile() {
	
		return selectedProfile;
	}
	
	public Long getSelectedStatus() {
	
		return selectedStatus;
	}
	
	public Long getStatus() {
	
		return status;
	}
	
	public String getStatusDesc() {
	
		return statusDesc;
	}
	
	public Long getStatusId() {
	
		return statusId;
	}
	
	public List<StatusTO> getStatusList() {
	
		return statusList;
	}
	
	public StatusTO getStatusTO() {
	
		return statusTO;
	}
	
	public void setAllApplicationProfiles(List<ApplicationProfileTO> allApplicationProfiles) {
	
		this.allApplicationProfiles = allApplicationProfiles;
	}
	
	public void setAllApplications(List<ApplicationTO> allApplications) {
	
		this.allApplications = allApplications;
	}
	
	public void setApplicationId(Long applicationId) {
	
		this.applicationId = applicationId;
	}
	
	public void setApplicationName(String applicationName) {
	
		this.applicationName = applicationName;
	}
	
	public void setApplicationProfileId(Long applicationProfileId) {
	
		this.applicationProfileId = applicationProfileId;
	}
	
	public void setApplicationProfileTO(ApplicationProfileTO applicationProfileTO) {
	
		this.applicationProfileTO = applicationProfileTO;
	}
	
	public void setApplicationTO(ApplicationTO applicationTO) {
	
		this.applicationTO = applicationTO;
	}
	
	public void setCreatedByDate(Date createdByDate) {
	
		this.createdByDate = createdByDate;
	}
	
	public void setModifiedbyDate(Date modifiedbyDate) {
	
		this.modifiedbyDate = modifiedbyDate;
	}
	
	public void setMultipleprofDetails(Set<MultipleProfileDetailsTO> multipleprofDetails) {
	
		this.multipleprofDetails = multipleprofDetails;
	}
	
	public void setProfDetails(List<MultipleProfileDetailsTO> profDetails) {
	
		this.profDetails = profDetails;
	}
	
	public void setSelectedApplication(Long selectedApplication) {
	
		this.selectedApplication = selectedApplication;
	}
	
	public void setSelectedMultipleProfile(Long selectedMultipleProfile) {
	
		this.selectedMultipleProfile = selectedMultipleProfile;
	}
	
	public void setSelectedProfile(Long selectedProfile) {
	
		this.selectedProfile = selectedProfile;
	}
	
	public void setSelectedStatus(Long selectedStatus) {
	
		this.selectedStatus = selectedStatus;
	}
	
	public void setStatus(Long status) {
	
		this.status = status;
	}
	
	public void setStatusDesc(String statusDesc) {
	
		this.statusDesc = statusDesc;
	}
	
	public void setStatusId(Long statusId) {
	
		this.statusId = statusId;
	}
	
	public void setStatusList(List<StatusTO> statusList) {
	
		this.statusList = statusList;
	}
	
	public void setStatusTO(StatusTO statusTO) {
	
		this.statusTO = statusTO;
	}
}
