package com.framework.to;

import java.io.Serializable;

public class VmModelBUMappingTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7757814620632082073L;
	private Long modelId;
	private Long buId;
	private Long Id;
	
	public Long getBuId() {
	
		return buId;
	}
	
	public Long getId() {
	
		return Id;
	}
	
	public Long getModelId() {
	
		return modelId;
	}
	
	public void setBuId(Long buId) {
	
		this.buId = buId;
	}
	
	public void setId(Long id) {
	
		Id = id;
	}
	
	public void setModelId(Long modelId) {
	
		this.modelId = modelId;
	}
}
