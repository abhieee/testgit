/**
 *
 */
package com.framework.to;

import java.util.HashSet;
import java.util.Set;

/**
 * @author TCS
 */
public class Application_InvTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4593280305181790046L;
	private Long id;
	private String appName;
	private Set<EnvironmentApplication_InvTO> envAppTO = new HashSet<EnvironmentApplication_InvTO>();
	private Long status;
	
	public String getAppName() {
	
		return appName;
	}
	
	public Set<EnvironmentApplication_InvTO> getEnvAppTO() {
	
		return envAppTO;
	}
	
	@Override
	public Long getId() {
	
		return id;
	}
	
	public Long getStatus() {
	
		return status;
	}
	
	public void setAppName(String appName) {
	
		this.appName = appName;
	}
	
	public void setEnvAppTO(Set<EnvironmentApplication_InvTO> envAppTO) {
	
		this.envAppTO = envAppTO;
	}
	
	@Override
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setStatus(Long status) {
	
		this.status = status;
	}
}
