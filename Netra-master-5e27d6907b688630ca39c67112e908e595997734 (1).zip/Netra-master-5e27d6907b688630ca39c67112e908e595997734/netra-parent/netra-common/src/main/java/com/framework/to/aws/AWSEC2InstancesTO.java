package com.framework.to.aws;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author 459704
 */
public class AWSEC2InstancesTO {
	
	private String instanceId;
	private String instanceName;
	private String imageId;
	private String instanceType;
	private String availabilityZone;
	private String vpcId;
	private String subnetId;
	private String keyName;
	private String architecture;
	private String virtualizationType;
	private String privateDNSName;
	private String privateIPAddress;
	private String publicDNSName;
	private String publicIPAddress;
	private String state;
	private Map<String, String> tags;
	private Map<String, String> securityGroups;
	private String monitoringState;
	private Date launchTime;
	
	public AWSEC2InstancesTO() {
	
		tags = new HashMap<String, String>();
		securityGroups = new HashMap<String, String>();
	}
	
	public String getArchitecture() {
	
		return architecture;
	}
	
	public String getAvailabilityZone() {
	
		return availabilityZone;
	}
	
	public String getImageId() {
	
		return imageId;
	}
	
	public String getInstanceId() {
	
		return instanceId;
	}
	
	public String getInstanceName() {
	
		return instanceName;
	}
	
	public String getInstanceType() {
	
		return instanceType;
	}
	
	public String getKeyName() {
	
		return keyName;
	}
	
	public Date getLaunchTime() {
	
		return launchTime;
	}
	
	public String getMonitoringState() {
	
		return monitoringState;
	}
	
	public String getPrivateDNSName() {
	
		return privateDNSName;
	}
	
	public String getPrivateIPAddress() {
	
		return privateIPAddress;
	}
	
	public String getPublicDNSName() {
	
		return publicDNSName;
	}
	
	public String getPublicIPAddress() {
	
		return publicIPAddress;
	}
	
	public Map<String, String> getSecurityGroups() {
	
		return securityGroups;
	}
	
	public String getState() {
	
		return state;
	}
	
	public String getSubnetId() {
	
		return subnetId;
	}
	
	public Map<String, String> getTags() {
	
		return tags;
	}
	
	public String getVirtualizationType() {
	
		return virtualizationType;
	}
	
	public String getVpcId() {
	
		return vpcId;
	}
	
	public void setArchitecture(String architecture) {
	
		this.architecture = architecture;
	}
	
	public void setAvailabilityZone(String availabilityZone) {
	
		this.availabilityZone = availabilityZone;
	}
	
	public void setImageId(String imageId) {
	
		this.imageId = imageId;
	}
	
	public void setInstanceId(String instanceId) {
	
		this.instanceId = instanceId;
	}
	
	public void setInstanceName(String instanceName) {
	
		this.instanceName = instanceName;
	}
	
	public void setInstanceType(String instanceType) {
	
		this.instanceType = instanceType;
	}
	
	public void setKeyName(String keyName) {
	
		this.keyName = keyName;
	}
	
	public void setLaunchTime(Date launchTime) {
	
		this.launchTime = launchTime;
	}
	
	public void setMonitoringState(String monitoringState) {
	
		this.monitoringState = monitoringState;
	}
	
	public void setPrivateDNSName(String privateDNSName) {
	
		this.privateDNSName = privateDNSName;
	}
	
	public void setPrivateIPAddress(String privateIPAddress) {
	
		this.privateIPAddress = privateIPAddress;
	}
	
	public void setPublicDNSName(String publicDNSName) {
	
		this.publicDNSName = publicDNSName;
	}
	
	public void setPublicIPAddress(String publicIPAddress) {
	
		this.publicIPAddress = publicIPAddress;
	}
	
	public void setSecurityGroups(Map<String, String> securityGroups) {
	
		this.securityGroups = securityGroups;
	}
	
	public void setState(String state) {
	
		this.state = state;
	}
	
	public void setSubnetId(String subnetId) {
	
		this.subnetId = subnetId;
	}
	
	public void setTags(Map<String, String> tags) {
	
		this.tags = tags;
	}
	
	public void setVirtualizationType(String virtualizationType) {
	
		this.virtualizationType = virtualizationType;
	}
	
	public void setVpcId(String vpcId) {
	
		this.vpcId = vpcId;
	}
}
