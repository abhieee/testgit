/**
 * TestingTypeTO will map with TEMS_Testing_Type table
 */
package com.framework.to;

/**
 * @author 397491
 */
public class TestingTypeTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4426251522670845669L;
}
