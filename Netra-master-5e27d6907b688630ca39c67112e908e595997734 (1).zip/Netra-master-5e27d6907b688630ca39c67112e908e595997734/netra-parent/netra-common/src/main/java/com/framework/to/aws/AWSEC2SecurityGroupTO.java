package com.framework.to.aws;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.amazonaws.services.ec2.model.IpPermission;
import com.amazonaws.services.ec2.model.SecurityGroup;
import com.amazonaws.services.ec2.model.Tag;

/**
 * @author 459704
 */
public class AWSEC2SecurityGroupTO {
	
	private String description;
	private String groupId;
	private String groupName;
	private String ownerId;
	private String vpcId;
	List<AWSEC2SecurityGroupIpPermissionTO> ipPermission;
	List<AWSEC2SecurityGroupIpPermissionTO> ipPermissionEgress;
	List<AWSEC2SecurityGroupIpPermissionTO> ipPermissionNext;
	List<AWSEC2SecurityGroupIpPermissionTO> ipPermissionEgressNext;
	Map<String, String> tags;
	
	public AWSEC2SecurityGroupTO() {
	
		ipPermission = new ArrayList<AWSEC2SecurityGroupIpPermissionTO>();
		ipPermissionEgress = new ArrayList<AWSEC2SecurityGroupIpPermissionTO>();
		ipPermissionNext = new ArrayList<AWSEC2SecurityGroupIpPermissionTO>();
		ipPermissionEgressNext = new ArrayList<AWSEC2SecurityGroupIpPermissionTO>();
		tags = new HashMap<String, String>();
	}
	
	public AWSEC2SecurityGroupTO(SecurityGroup securityGroup) {
	
		this();
		setDescription(securityGroup.getDescription());
		setGroupId(securityGroup.getGroupId());
		setGroupName(securityGroup.getGroupName());
		setOwnerId(securityGroup.getOwnerId());
		setVpcId(securityGroup.getVpcId());
		for (Tag tag : securityGroup.getTags()) {
			this.getTags().put(tag.getKey(), tag.getValue());
		}
		for (IpPermission permission : securityGroup.getIpPermissions()) {
			this.getIpPermission().add(new AWSEC2SecurityGroupIpPermissionTO(permission));
		}
		for (IpPermission permission : securityGroup.getIpPermissionsEgress()) {
			this.getIpPermissionEgress().add(new AWSEC2SecurityGroupIpPermissionTO(permission));
		}
	}
	
	public String getDescription() {
	
		return description;
	}
	
	public String getGroupId() {
	
		return groupId;
	}
	
	public String getGroupName() {
	
		return groupName;
	}
	
	public List<AWSEC2SecurityGroupIpPermissionTO> getIpPermission() {
	
		return ipPermission;
	}
	
	public List<AWSEC2SecurityGroupIpPermissionTO> getIpPermissionEgress() {
	
		return ipPermissionEgress;
	}
	
	public List<AWSEC2SecurityGroupIpPermissionTO> getIpPermissionEgressNext() {
	
		return ipPermissionEgressNext;
	}
	
	public List<AWSEC2SecurityGroupIpPermissionTO> getIpPermissionNext() {
	
		return ipPermissionNext;
	}
	
	public String getOwnerId() {
	
		return ownerId;
	}
	
	public Map<String, String> getTags() {
	
		return tags;
	}
	
	public String getVpcId() {
	
		return vpcId;
	}
	
	public void setDescription(String description) {
	
		this.description = description;
	}
	
	public void setGroupId(String groupId) {
	
		this.groupId = groupId;
	}
	
	public void setGroupName(String groupName) {
	
		this.groupName = groupName;
	}
	
	public void setIpPermission(List<AWSEC2SecurityGroupIpPermissionTO> ipPermission) {
	
		this.ipPermission = ipPermission;
	}
	
	public void setIpPermissionEgress(List<AWSEC2SecurityGroupIpPermissionTO> ipPermissionEgress) {
	
		this.ipPermissionEgress = ipPermissionEgress;
	}
	
	public void setIpPermissionEgressNext(List<AWSEC2SecurityGroupIpPermissionTO> ipPermissionEgressNext) {
	
		this.ipPermissionEgressNext = ipPermissionEgressNext;
	}
	
	public void setIpPermissionNext(List<AWSEC2SecurityGroupIpPermissionTO> ipPermissionNext) {
	
		this.ipPermissionNext = ipPermissionNext;
	}
	
	public void setOwnerId(String ownerId) {
	
		this.ownerId = ownerId;
	}
	
	public void setTags(Map<String, String> tags) {
	
		this.tags = tags;
	}
	
	public void setVpcId(String vpcId) {
	
		this.vpcId = vpcId;
	}
}
