package com.framework.to;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ProvisionedMachineTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6332887670865227916L;
	private Long id;
	private String name;
	private Long machineTypeId;
	private Byte activeFlag;
	private Long createdBy;
	private Date createdOn;
	private Long updatedBy;
	private Date updatedOn;
	private String selectedPlatform;
	private String ip;
	private String hostName;
	private String serverStatus;
	private Long machineTemplateId;
	private Long CPU;
	private Long RAM;
	private String architecture;
	private String provisionedMachineType;
	private String virtualMachineType;
	private String perishableFlag;
	private Long provisionedPlatformTemplateId;
	private String provisionedStatus;
	private String macAddress;
	private Set<ProvisionedMachineAwsTO> provisionedMachineAws;
	private Set<ProvisionedMachineVMWareTO> provisionedMachineVMWare;
	private Set<ProvisionedMachineVmwareBareMetalTO> provisionedMachineVmwareBareMetalTO;
	private Set<ProvisionedMachinePhysicalTO> provisionedMachinePhysicalTOSet;
	private MachineTypeTO machineType;
	private ProvisionedPlatformTO provisionedPlatform;
	private List<ProvisionedMachineAwsTO> provisionedMachineAwsList = new ArrayList<ProvisionedMachineAwsTO>(0);
	private List<ServerTemplatePropertyTO> serverTemplateProperty;
	private List<ServerTemplatePropertyTO> serverTemplateProperty1;
	private String label1;
	private List<ProvisionedMachineOSTO> provisionedMachineOSTOList = new ArrayList<ProvisionedMachineOSTO>(0);
	private Set<ProvisionedMachineOSTO> provisionedMachineOSTOSet;
	private String selectedFlavorId;
	private String selectedFlavorType;
	private String currentDisk;
	private String agentType;
	private String username = null;
	private String password = null;
	private String remarks;
	private String mach_arch;
	private boolean access;
	private Long selectedEnvironment;
	private long serviceRequestId;
	private long pageNumber = 1;
	private int firstResult = 0;
	private long searchCount;
	private int tableSize = 15;
	private String environmentName;
	private Long physicalmachineId;
	private Long envId;
	private String triggerName;
	private String ItemName;
	private String itemValue;
	private String accessedDate;
	private Long duration;
	private String serverName;
	private ProvisionedMachinePhysicalTO proMachPhysical;
	
	public ProvisionedMachineTO() {
	
		updatedOn = new Date();
		provisionedMachineAws = new HashSet<ProvisionedMachineAwsTO>();
		provisionedMachineOSTOSet = new HashSet<ProvisionedMachineOSTO>();
	}
	
	public Byte getActiveFlag() {
	
		return activeFlag;
	}
	
	public String getAgentType() {
	
		return agentType;
	}
	
	public String getArchitecture() {
	
		return architecture;
	}
	
	public Long getCPU() {
	
		return CPU;
	}
	
	public Long getCreatedBy() {
	
		return createdBy;
	}
	
	public Date getCreatedOn() {
	
		return createdOn;
	}
	
	public String getCurrentDisk() {
	
		return currentDisk;
	}
	
	public Long getEnvId() {
	
		return envId;
	}
	
	public String getEnvironmentName() {
	
		return environmentName;
	}
	
	public int getFirstResult() {
	
		return firstResult;
	}
	
	public String getHostName() {
	
		return hostName;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public String getIp() {
	
		return ip;
	}
	
	public String getLabel1() {
	
		return label1;
	}
	
	public String getMacAddress() {
	
		return macAddress;
	}
	
	public String getMach_arch() {
	
		return mach_arch;
	}
	
	public Long getMachineTemplateId() {
	
		return machineTemplateId;
	}
	
	public MachineTypeTO getMachineType() {
	
		return machineType;
	}
	
	public Long getMachineTypeId() {
	
		return machineTypeId;
	}
	
	public String getName() {
	
		return name;
	}
	
	public long getPageNumber() {
	
		return pageNumber;
	}
	
	public String getPassword() {
	
		return password;
	}
	
	public String getPerishableFlag() {
	
		return perishableFlag;
	}
	
	public Long getPhysicalmachineId() {
	
		return physicalmachineId;
	}
	
	public Set<ProvisionedMachineAwsTO> getProvisionedMachineAws() {
	
		return provisionedMachineAws;
	}
	
	public List<ProvisionedMachineAwsTO> getProvisionedMachineAwsList() {
	
		return provisionedMachineAwsList;
	}
	
	public List<ProvisionedMachineOSTO> getProvisionedMachineOSTOList() {
	
		return provisionedMachineOSTOList;
	}
	
	public Set<ProvisionedMachineOSTO> getProvisionedMachineOSTOSet() {
	
		return provisionedMachineOSTOSet;
	}
	
	public Set<ProvisionedMachinePhysicalTO> getProvisionedMachinePhysicalTOSet() {
	
		return provisionedMachinePhysicalTOSet;
	}
	
	public String getProvisionedMachineType() {
	
		return provisionedMachineType;
	}
	
	public Set<ProvisionedMachineVMWareTO> getProvisionedMachineVMWare() {
	
		return provisionedMachineVMWare;
	}
	
	/**
	 * @return the provisionedMachineVmwareBareMetalTO
	 */
	public Set<ProvisionedMachineVmwareBareMetalTO> getProvisionedMachineVmwareBareMetalTO() {
	
		return provisionedMachineVmwareBareMetalTO;
	}
	
	public ProvisionedPlatformTO getProvisionedPlatform() {
	
		return provisionedPlatform;
	}
	
	public Long getProvisionedPlatformTemplateId() {
	
		return provisionedPlatformTemplateId;
	}
	
	public String getProvisionedStatus() {
	
		return provisionedStatus;
	}
	
	public Long getRAM() {
	
		return RAM;
	}
	
	public String getRemarks() {
	
		return remarks;
	}
	
	public long getSearchCount() {
	
		return searchCount;
	}
	
	public Long getSelectedEnvironment() {
	
		return selectedEnvironment;
	}
	
	public String getSelectedFlavorId() {
	
		return selectedFlavorId;
	}
	
	public String getSelectedFlavorType() {
	
		return selectedFlavorType;
	}
	
	public String getSelectedPlatform() {
	
		return selectedPlatform;
	}
	
	public String getServerStatus() {
	
		return serverStatus;
	}
	
	public List<ServerTemplatePropertyTO> getServerTemplateProperty() {
	
		return serverTemplateProperty;
	}
	
	public List<ServerTemplatePropertyTO> getServerTemplateProperty1() {
	
		return serverTemplateProperty1;
	}
	
	public long getServiceRequestId() {
	
		return serviceRequestId;
	}
	
	public int getTableSize() {
	
		return tableSize;
	}
	
	public Long getUpdatedBy() {
	
		return updatedBy;
	}
	
	public Date getUpdatedOn() {
	
		return updatedOn;
	}
	
	public String getUsername() {
	
		return username;
	}
	
	public String getVirtualMachineType() {
	
		return virtualMachineType;
	}
	
	public boolean isAccess() {
	
		return access;
	}
	
	public void setAccess(boolean access) {
	
		this.access = access;
	}
	
	public void setActiveFlag(Byte activeFlag) {
	
		this.activeFlag = activeFlag;
	}
	
	public void setAgentType(String agentType) {
	
		this.agentType = agentType;
	}
	
	public void setArchitecture(String architecture) {
	
		this.architecture = architecture;
	}
	
	public void setCPU(Long cPU) {
	
		CPU = cPU;
	}
	
	public void setCreatedBy(Long createdBy) {
	
		this.createdBy = createdBy;
	}
	
	public void setCreatedOn(Date createdOn) {
	
		this.createdOn = createdOn;
	}
	
	public void setCurrentDisk(String currentDisk) {
	
		this.currentDisk = currentDisk;
	}
	
	public void setEnvId(Long envId) {
	
		this.envId = envId;
	}
	
	public void setEnvironmentName(String environmentName) {
	
		this.environmentName = environmentName;
	}
	
	public void setFirstResult(int firstResult) {
	
		this.firstResult = firstResult;
	}
	
	public void setHostName(String hostName) {
	
		this.hostName = hostName;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setIp(String ip) {
	
		this.ip = ip;
	}
	
	public void setLabel1(String label1) {
	
		this.label1 = label1;
	}
	
	public void setMacAddress(String macAddress) {
	
		this.macAddress = macAddress;
	}
	
	public void setMach_arch(String mach_arch) {
	
		this.mach_arch = mach_arch;
	}
	
	public void setMachineTemplateId(Long machineTemplateId) {
	
		this.machineTemplateId = machineTemplateId;
	}
	
	public void setMachineType(MachineTypeTO machineType) {
	
		this.machineType = machineType;
	}
	
	public void setMachineTypeId(Long machineTypeId) {
	
		this.machineTypeId = machineTypeId;
	}
	
	public void setName(String name) {
	
		this.name = name;
	}
	
	public void setPageNumber(long pageNumber) {
	
		this.pageNumber = pageNumber;
	}
	
	public void setPassword(String password) {
	
		this.password = password;
	}
	
	public void setPerishableFlag(String perishableFlag) {
	
		this.perishableFlag = perishableFlag;
	}
	
	public void setPhysicalmachineId(Long physicalmachineId) {
	
		this.physicalmachineId = physicalmachineId;
	}
	
	public void setProvisionedMachineAws(Set<ProvisionedMachineAwsTO> provisionedMachineAws) {
	
		this.provisionedMachineAws = provisionedMachineAws;
	}
	
	public void setProvisionedMachineAwsList(List<ProvisionedMachineAwsTO> provisionedMachineAwsList) {
	
		this.provisionedMachineAwsList = provisionedMachineAwsList;
	}
	
	public void setProvisionedMachineOSTOList(List<ProvisionedMachineOSTO> provisionedMachineOSTOList) {
	
		this.provisionedMachineOSTOList = provisionedMachineOSTOList;
	}
	
	public void setProvisionedMachineOSTOSet(Set<ProvisionedMachineOSTO> provisionedMachineOSTOSet) {
	
		this.provisionedMachineOSTOSet = provisionedMachineOSTOSet;
	}
	
	public void setProvisionedMachinePhysicalTOSet(Set<ProvisionedMachinePhysicalTO> provisionedMachinePhysicalTOSet) {
	
		this.provisionedMachinePhysicalTOSet = provisionedMachinePhysicalTOSet;
	}
	
	public void setProvisionedMachineType(String provisionedMachineType) {
	
		this.provisionedMachineType = provisionedMachineType;
	}
	
	public void setProvisionedMachineVMWare(Set<ProvisionedMachineVMWareTO> provisionedMachineVMWare) {
	
		this.provisionedMachineVMWare = provisionedMachineVMWare;
	}
	
	/**
	 * @param provisionedMachineVmwareBareMetalTO
	 *                the provisionedMachineVmwareBareMetalTO to set
	 */
	public void setProvisionedMachineVmwareBareMetalTO(Set<ProvisionedMachineVmwareBareMetalTO> provisionedMachineVmwareBareMetalTO) {
	
		this.provisionedMachineVmwareBareMetalTO = provisionedMachineVmwareBareMetalTO;
	}
	
	public void setProvisionedPlatform(ProvisionedPlatformTO provisionedPlatform) {
	
		this.provisionedPlatform = provisionedPlatform;
	}
	
	public void setProvisionedPlatformTemplateId(Long provisionedPlatformTemplateId) {
	
		this.provisionedPlatformTemplateId = provisionedPlatformTemplateId;
	}
	
	public void setProvisionedStatus(String provisionedStatus) {
	
		this.provisionedStatus = provisionedStatus;
	}
	
	public void setRAM(Long rAM) {
	
		RAM = rAM;
	}
	
	public void setRemarks(String remarks) {
	
		this.remarks = remarks;
	}
	
	public void setSearchCount(long searchCount) {
	
		this.searchCount = searchCount;
	}
	
	public void setSelectedEnvironment(Long selectedEnvironment) {
	
		this.selectedEnvironment = selectedEnvironment;
	}
	
	public void setSelectedFlavorId(String selectedFlavorId) {
	
		this.selectedFlavorId = selectedFlavorId;
	}
	
	public void setSelectedFlavorType(String selectedFlavorType) {
	
		this.selectedFlavorType = selectedFlavorType;
	}
	
	public void setSelectedPlatform(String selectedPlatform) {
	
		this.selectedPlatform = selectedPlatform;
	}
	
	public void setServerStatus(String serverStatus) {
	
		this.serverStatus = serverStatus;
	}
	
	public void setServerTemplateProperty(List<ServerTemplatePropertyTO> serverTemplateProperty) {
	
		this.serverTemplateProperty = serverTemplateProperty;
	}
	
	public void setServerTemplateProperty1(List<ServerTemplatePropertyTO> serverTemplateProperty1) {
	
		this.serverTemplateProperty1 = serverTemplateProperty1;
	}
	
	public void setServiceRequestId(long serviceRequestId) {
	
		this.serviceRequestId = serviceRequestId;
	}
	
	public void setTableSize(int tableSize) {
	
		this.tableSize = tableSize;
	}
	
	public void setUpdatedBy(Long updatedBy) {
	
		this.updatedBy = updatedBy;
	}
	
	public void setUpdatedOn(Date updatedOn) {
	
		this.updatedOn = updatedOn;
	}
	
	public void setUsername(String username) {
	
		this.username = username;
	}
	
	public void setVirtualMachineType(String virtualMachineType) {
	
		this.virtualMachineType = virtualMachineType;
	}
	
	public String getTriggerName() {
	
		return triggerName;
	}
	
	public void setTriggerName(String triggerName) {
	
		this.triggerName = triggerName;
	}
	
	public String getItemName() {
	
		return ItemName;
	}
	
	public void setItemName(String itemName) {
	
		ItemName = itemName;
	}
	
	public String getItemValue() {
	
		return itemValue;
	}
	
	public void setItemValue(String itemValue) {
	
		this.itemValue = itemValue;
	}
	
	public String getAccessedDate() {
	
		return accessedDate;
	}
	
	public void setAccessedDate(String accessedDate) {
	
		this.accessedDate = accessedDate;
	}
	
	public Long getDuration() {
	
		return duration;
	}
	
	public void setDuration(Long duration) {
	
		this.duration = duration;
	}
	
	public String getServerName() {
	
		return serverName;
	}
	
	public void setServerName(String serverName) {
	
		this.serverName = serverName;
	}
	
	public ProvisionedMachinePhysicalTO getProMachPhysical() {
	
		return proMachPhysical;
	}
	
	public void setProMachPhysical(ProvisionedMachinePhysicalTO proMachPhysical) {
	
		this.proMachPhysical = proMachPhysical;
	}
}
