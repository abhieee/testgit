package com.framework.common;

public enum NativeApplicationType {
	ANDROID("ANDROID"), IOS("IOS"), All("All");
	
	private String mobileTest;
	
	private NativeApplicationType(String s) {
	
		this.mobileTest = s;
	}
	
	public String getNativeApplicationType() {
	
		return mobileTest;
	}
}
