/**
 *
 */
package com.framework.to;

import java.util.List;

/**
 * @author 737070
 */
public class ScriptParameterMapTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7078196166354014669L;
	private Long scriptMapId;
	private ScriptTaskMappingTO mappedScript;
	private List<NetraParametersTO> netraParametersList;
	private String selectedParameterValues;
	private String selectedParameterScopes;
	private String defaultParameterValues;
	private String parameterName;
	private String netraParameterMapping;
	
	public Long getScriptMapId() {
	
		return scriptMapId;
	}
	
	public void setScriptMapId(Long scriptMapId) {
	
		this.scriptMapId = scriptMapId;
	}
	
	public ScriptTaskMappingTO getMappedScript() {
	
		return mappedScript;
	}
	
	public void setMappedScript(ScriptTaskMappingTO mappedScript) {
	
		this.mappedScript = mappedScript;
	}
	
	public List<NetraParametersTO> getNetraParametersList() {
	
		return netraParametersList;
	}
	
	public void setNetraParametersList(List<NetraParametersTO> netraParametersList) {
	
		this.netraParametersList = netraParametersList;
	}
	
	public String getSelectedParameterValues() {
	
		return selectedParameterValues;
	}
	
	public void setSelectedParameterValues(String selectedParameterValues) {
	
		this.selectedParameterValues = selectedParameterValues;
	}
	
	public String getSelectedParameterScopes() {
	
		return selectedParameterScopes;
	}
	
	public void setSelectedParameterScopes(String selectedParameterScopes) {
	
		this.selectedParameterScopes = selectedParameterScopes;
	}
	
	public String getDefaultParameterValues() {
	
		return defaultParameterValues;
	}
	
	public void setDefaultParameterValues(String defaultParameterValues) {
	
		this.defaultParameterValues = defaultParameterValues;
	}
	
	public String getParameterName() {
	
		return parameterName;
	}
	
	public void setParameterName(String parameterName) {
	
		this.parameterName = parameterName;
	}
	
	public String getNetraParameterMapping() {
	
		return netraParameterMapping;
	}
	
	public void setNetraParameterMapping(String netraParameterMapping) {
	
		this.netraParameterMapping = netraParameterMapping;
	}
}
