package com.framework.to;

import java.util.Date;
import java.util.List;

public class ProjectViewReservationTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String name = null;
	private Long id = null;
	private Long status = null;
	private List<String> reservations = null;
	private List<String> reservationsMonthly = null;
	private List<String> reservationsHourly = null;
	private double leftMargin;
	private double reservationData;
	private double rightMargin;
	private double hourlyMarginLeft;
	private double hourlyMarginRight;
	private String cellColor;
	private String username;
	private Long reservationId;
	private Date hourlyStartDate;
	private String startTime;
	private String endTime;
	private String projectName;
	private String buName;
	private double reportInterval;
	private double daysNumForReport;
	
	@Override
	public String getName() {
	
		return name;
	}
	
	@Override
	public void setName(String name) {
	
		this.name = name;
	}
	
	@Override
	public Long getId() {
	
		return id;
	}
	
	@Override
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public Long getStatus() {
	
		return status;
	}
	
	public void setStatus(Long status) {
	
		this.status = status;
	}
	
	public List<String> getReservations() {
	
		return reservations;
	}
	
	public void setReservations(List<String> reservations) {
	
		this.reservations = reservations;
	}
	
	public List<String> getReservationsMonthly() {
	
		return reservationsMonthly;
	}
	
	public void setReservationsMonthly(List<String> reservationsMonthly) {
	
		this.reservationsMonthly = reservationsMonthly;
	}
	
	public List<String> getReservationsHourly() {
	
		return reservationsHourly;
	}
	
	public void setReservationsHourly(List<String> reservationsHourly) {
	
		this.reservationsHourly = reservationsHourly;
	}
	
	public double getLeftMargin() {
	
		return leftMargin;
	}
	
	public void setLeftMargin(double leftMargin) {
	
		this.leftMargin = leftMargin;
	}
	
	public double getReservationData() {
	
		return reservationData;
	}
	
	public void setReservationData(double reservationData) {
	
		this.reservationData = reservationData;
	}
	
	public double getRightMargin() {
	
		return rightMargin;
	}
	
	public void setRightMargin(double rightMargin) {
	
		this.rightMargin = rightMargin;
	}
	
	public double getHourlyMarginLeft() {
	
		return hourlyMarginLeft;
	}
	
	public void setHourlyMarginLeft(double hourlyMarginLeft) {
	
		this.hourlyMarginLeft = hourlyMarginLeft;
	}
	
	public double getHourlyMarginRight() {
	
		return hourlyMarginRight;
	}
	
	public void setHourlyMarginRight(double hourlyMarginRight) {
	
		this.hourlyMarginRight = hourlyMarginRight;
	}
	
	public String getCellColor() {
	
		return cellColor;
	}
	
	public void setCellColor(String cellColor) {
	
		this.cellColor = cellColor;
	}
	
	public String getUsername() {
	
		return username;
	}
	
	public void setUsername(String username) {
	
		this.username = username;
	}
	
	public Long getReservationId() {
	
		return reservationId;
	}
	
	public void setReservationId(Long reservationId) {
	
		this.reservationId = reservationId;
	}
	
	public Date getHourlyStartDate() {
	
		return hourlyStartDate;
	}
	
	public void setHourlyStartDate(Date hourlyStartDate) {
	
		this.hourlyStartDate = hourlyStartDate;
	}
	
	public String getStartTime() {
	
		return startTime;
	}
	
	public void setStartTime(String startTime) {
	
		this.startTime = startTime;
	}
	
	public String getEndTime() {
	
		return endTime;
	}
	
	public void setEndTime(String endTime) {
	
		this.endTime = endTime;
	}
	
	public String getProjectName() {
	
		return projectName;
	}
	
	public void setProjectName(String projectName) {
	
		this.projectName = projectName;
	}
	
	public String getBuName() {
	
		return buName;
	}
	
	public void setBuName(String buName) {
	
		this.buName = buName;
	}
	
	public double getReportInterval() {
	
		return reportInterval;
	}
	
	public void setReportInterval(double reportInterval) {
	
		this.reportInterval = reportInterval;
	}
	
	public double getDaysNumForReport() {
	
		return daysNumForReport;
	}
	
	public void setDaysNumForReport(double daysNumForReport) {
	
		this.daysNumForReport = daysNumForReport;
	}
}
