package com.framework.to;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class BulkUploadSoftwareTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1175306969848085320L;
	private String type;
	private String manufacturer;
	private String model;
	private Set<SoftwareconfigTO> softwareconfigs = new HashSet<SoftwareconfigTO>(0);
	private String version = null;
	private String patch = null;
	private Date effectiveDate = null;
	private String location = null;
	private String effectiveRelease = null;
	private String remark = null;
	private Long softwareconfigsId;
	private String status = null;
	private Long statusId = null;
	private Long userId = null;
	private String installerLocation = null;
	
	public Date getEffectiveDate() {
	
		return effectiveDate;
	}
	
	public String getEffectiveRelease() {
	
		return effectiveRelease;
	}
	
	/**
	 * @return the installerLocation
	 */
	public String getInstallerLocation() {
	
		return installerLocation;
	}
	
	public String getLocation() {
	
		return location;
	}
	
	public String getManufacturer() {
	
		return this.manufacturer;
	}
	
	public String getModel() {
	
		return this.model;
	}
	
	public String getPatch() {
	
		return patch;
	}
	
	public String getRemark() {
	
		return remark;
	}
	
	public Set<SoftwareconfigTO> getSoftwareconfigs() {
	
		return this.softwareconfigs;
	}
	
	public Long getSoftwareconfigsId() {
	
		return softwareconfigsId;
	}
	
	public String getStatus() {
	
		return status;
	}
	
	public Long getStatusId() {
	
		return statusId;
	}
	
	public String getType() {
	
		return this.type;
	}
	
	/**
	 * @return the userId
	 */
	public Long getUserId() {
	
		return userId;
	}
	
	public String getVersion() {
	
		return version;
	}
	
	public void setEffectiveDate(Date effectiveDate) {
	
		this.effectiveDate = effectiveDate;
	}
	
	public void setEffectiveRelease(String effectiveRelease) {
	
		this.effectiveRelease = effectiveRelease;
	}
	
	/**
	 * @param installerLocation
	 *                the installerLocation to set
	 */
	public void setInstallerLocation(String installerLocation) {
	
		this.installerLocation = installerLocation;
	}
	
	public void setLocation(String location) {
	
		this.location = location;
	}
	
	public void setManufacturer(String manufacturer) {
	
		this.manufacturer = manufacturer;
	}
	
	public void setModel(String model) {
	
		this.model = model;
	}
	
	public void setPatch(String patch) {
	
		this.patch = patch;
	}
	
	public void setRemark(String remark) {
	
		this.remark = remark;
	}
	
	public void setSoftwareconfigs(Set<SoftwareconfigTO> softwareconfigs) {
	
		this.softwareconfigs = softwareconfigs;
	}
	
	public void setSoftwareconfigsId(Long softwareconfigsId) {
	
		this.softwareconfigsId = softwareconfigsId;
	}
	
	public void setStatus(String status) {
	
		this.status = status;
	}
	
	public void setStatusId(Long statusId) {
	
		this.statusId = statusId;
	}
	
	public void setType(String type) {
	
		this.type = type;
	}
	
	/**
	 * @param userId
	 *                the userId to set
	 */
	public void setUserId(Long userId) {
	
		this.userId = userId;
	}
	
	public void setVersion(String version) {
	
		this.version = version;
	}
}
