package com.framework.to;

import java.util.Date;

public class ApplicationUserGroupTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8019133702330541803L;
	private UserGroupTO UserGroupTO;
	private ApplicationTO ApplicationsTO;
	private Integer createdBy;
	private Date createdDate;
	private Integer modifiedBy;
	private Date modifiedDate;
	
	public ApplicationUserGroupTO() {
	
		/* No implementation required at the moment. Method for future use. */
	}
	
	public ApplicationUserGroupTO(UserGroupTO UserGroupTO, ApplicationTO ApplicationsTO) {
	
		this.UserGroupTO = UserGroupTO;
		this.ApplicationsTO = ApplicationsTO;
	}
	
	public ApplicationUserGroupTO(UserGroupTO UserGroupTO, ApplicationTO ApplicationsTO, Integer createdBy, Date createdDate, Integer modifiedBy, Date modifiedDate) {
	
		this.UserGroupTO = UserGroupTO;
		this.ApplicationsTO = ApplicationsTO;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifiedDate;
	}
	
	public ApplicationTO getApplicationsTO() {
	
		return this.ApplicationsTO;
	}
	
	public Integer getCreatedBy() {
	
		return this.createdBy;
	}
	
	@Override
	public Date getCreatedDate() {
	
		return this.createdDate;
	}
	
	public Integer getModifiedBy() {
	
		return this.modifiedBy;
	}
	
	@Override
	public Date getModifiedDate() {
	
		return this.modifiedDate;
	}
	
	public UserGroupTO getUserGroupTO() {
	
		return this.UserGroupTO;
	}
	
	public void setApplicationsTO(ApplicationTO ApplicationsTO) {
	
		this.ApplicationsTO = ApplicationsTO;
	}
	
	public void setCreatedBy(Integer createdBy) {
	
		this.createdBy = createdBy;
	}
	
	@Override
	public void setCreatedDate(Date createdDate) {
	
		this.createdDate = createdDate;
	}
	
	public void setModifiedBy(Integer modifiedBy) {
	
		this.modifiedBy = modifiedBy;
	}
	
	@Override
	public void setModifiedDate(Date modifiedDate) {
	
		this.modifiedDate = modifiedDate;
	}
	
	public void setUserGroupTO(UserGroupTO UserGroupTO) {
	
		this.UserGroupTO = UserGroupTO;
	}
}
