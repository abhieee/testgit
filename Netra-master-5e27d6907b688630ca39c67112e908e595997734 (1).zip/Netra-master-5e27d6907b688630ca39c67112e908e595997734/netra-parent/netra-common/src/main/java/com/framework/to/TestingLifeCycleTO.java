package com.framework.to;

import java.util.LinkedList;
import java.util.List;

public class TestingLifeCycleTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2389392230964369628L;
	private List<ServiceTO> selectedServices = null;
	private Long selectedTestingPhase = null;
	private ServiceTO serviceTo = null;
	private ApplicationTO applicationTO;
	private Long parentServiceId;
	private List<Long> definedServices = new LinkedList<Long>();
	private Long selectedApplication = null;
	private Long lifeCycleOrder;
	private TestingPhaseTO testingPhaseTO = null;
	
	public ApplicationTO getApplicationTO() {
	
		return applicationTO;
	}
	
	public List<Long> getDefinedServices() {
	
		return definedServices;
	}
	
	public Long getLifeCycleOrder() {
	
		return lifeCycleOrder;
	}
	
	public Long getParentServiceId() {
	
		return parentServiceId;
	}
	
	public Long getSelectedApplication() {
	
		return selectedApplication;
	}
	
	public List<ServiceTO> getSelectedServices() {
	
		return selectedServices;
	}
	
	public Long getSelectedTestingPhase() {
	
		return selectedTestingPhase;
	}
	
	public ServiceTO getServiceTo() {
	
		return serviceTo;
	}
	
	public TestingPhaseTO getTestingPhaseTO() {
	
		return testingPhaseTO;
	}
	
	public void setApplicationTO(ApplicationTO applicationTO) {
	
		this.applicationTO = applicationTO;
	}
	
	public void setDefinedServices(List<Long> definedServices) {
	
		this.definedServices = definedServices;
	}
	
	public void setLifeCycleOrder(Long lifeCycleOrder) {
	
		this.lifeCycleOrder = lifeCycleOrder;
	}
	
	public void setParentServiceId(Long parentServiceId) {
	
		this.parentServiceId = parentServiceId;
	}
	
	public void setSelectedApplication(Long selectedApplication) {
	
		this.selectedApplication = selectedApplication;
	}
	
	public void setSelectedServices(List<ServiceTO> selectedServices) {
	
		this.selectedServices = selectedServices;
	}
	
	public void setSelectedTestingPhase(Long selectedTestingPhase) {
	
		this.selectedTestingPhase = selectedTestingPhase;
	}
	
	public void setServiceTo(ServiceTO serviceTo) {
	
		this.serviceTo = serviceTo;
	}
	
	public void setTestingPhaseTO(TestingPhaseTO testingPhaseTO) {
	
		this.testingPhaseTO = testingPhaseTO;
	}
}
