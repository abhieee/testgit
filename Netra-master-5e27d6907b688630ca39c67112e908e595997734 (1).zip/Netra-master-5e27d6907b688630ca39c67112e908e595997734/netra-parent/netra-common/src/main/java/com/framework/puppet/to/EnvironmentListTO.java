package com.framework.puppet.to;

import java.util.List;

public class EnvironmentListTO {
	
	private List<VMTO> envlist;
	
	public List<VMTO> getEnvlist() {
	
		return envlist;
	}
	
	public void setEnvlist(List<VMTO> envlist) {
	
		this.envlist = envlist;
	}
}
