package com.framework.puppet.to;

public class CopyPropertyFilesTO {
	
	private String ip;
	private String dnsname;
	private String source;
	private String destination;
	private String ostype;
	private String systype;
	private String svnusername;
	private String svnpassword;
	
	public String getDestination() {
	
		return destination;
	}
	
	public String getDnsname() {
	
		return dnsname;
	}
	
	public String getIp() {
	
		return ip;
	}
	
	public String getOstype() {
	
		return ostype;
	}
	
	public String getSource() {
	
		return source;
	}
	
	public String getSvnpassword() {
	
		return svnpassword;
	}
	
	public String getSvnusername() {
	
		return svnusername;
	}
	
	public String getSystype() {
	
		return systype;
	}
	
	public void setDestination(String destination) {
	
		this.destination = destination;
	}
	
	public void setDnsname(String dnsname) {
	
		this.dnsname = dnsname;
	}
	
	public void setIp(String ip) {
	
		this.ip = ip;
	}
	
	public void setOstype(String ostype) {
	
		this.ostype = ostype;
	}
	
	public void setSource(String source) {
	
		this.source = source;
	}
	
	public void setSvnpassword(String svnpassword) {
	
		this.svnpassword = svnpassword;
	}
	
	public void setSvnusername(String svnusername) {
	
		this.svnusername = svnusername;
	}
	
	public void setSystype(String systype) {
	
		this.systype = systype;
	}
}
