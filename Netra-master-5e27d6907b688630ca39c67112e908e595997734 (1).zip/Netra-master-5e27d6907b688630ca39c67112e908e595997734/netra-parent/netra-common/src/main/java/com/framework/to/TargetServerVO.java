package com.framework.to;

import java.io.Serializable;

/**
 * This class serves as an abstract transfer object to carry information across the tiers. Other TO definitions must extend this class.
 *
 * @author TCS
 */
public class TargetServerVO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8669603442835037309L;
	private String serverName;
	private String phyUserName;
	private String phyPwd;
	private String vmUserName;
	private String vmPwd;
	private String osUserName;
	private String osPwd;
	private String opSys;
	private String ip;
	private String provMachineType;
	private String virtualMachineType;
	
	public String getServerName() {
	
		return serverName;
	}
	
	public void setServerName(String serverName) {
	
		this.serverName = serverName;
	}
	
	public String getPhyUserName() {
	
		return phyUserName;
	}
	
	public void setPhyUserName(String phyUserName) {
	
		this.phyUserName = phyUserName;
	}
	
	public String getPhyPwd() {
	
		return phyPwd;
	}
	
	public void setPhyPwd(String phyPwd) {
	
		this.phyPwd = phyPwd;
	}
	
	public String getVmUserName() {
	
		return vmUserName;
	}
	
	public void setVmUserName(String vmUserName) {
	
		this.vmUserName = vmUserName;
	}
	
	public String getVmPwd() {
	
		return vmPwd;
	}
	
	public void setVmPwd(String vmPwd) {
	
		this.vmPwd = vmPwd;
	}
	
	public String getOsUserName() {
	
		return osUserName;
	}
	
	public void setOsUserName(String osUserName) {
	
		this.osUserName = osUserName;
	}
	
	public String getOsPwd() {
	
		return osPwd;
	}
	
	public void setOsPwd(String osPwd) {
	
		this.osPwd = osPwd;
	}
	
	public String getOpSys() {
	
		return opSys;
	}
	
	public void setOpSys(String opSys) {
	
		this.opSys = opSys;
	}
	
	public String getIp() {
	
		return ip;
	}
	
	public void setIp(String ip) {
	
		this.ip = ip;
	}
	
	public String getProvMachineType() {
	
		return provMachineType;
	}
	
	public void setProvMachineType(String provMachineType) {
	
		this.provMachineType = provMachineType;
	}
	
	public String getVirtualMachineType() {
	
		return virtualMachineType;
	}
	
	public void setVirtualMachineType(String virtualMachineType) {
	
		this.virtualMachineType = virtualMachineType;
	}
	
	public TargetServerVO() {
	
		super();
	}
	
	public TargetServerVO(String serverName, String phyUserName, String phyPwd, String vmUserName, String vmPwd, String osUserName, String osPwd, String opSys, String ip, String provMachineType, String virtualMachineType) {
	
		super();
		this.serverName = serverName;
		this.phyUserName = phyUserName;
		this.phyPwd = phyPwd;
		this.vmUserName = vmUserName;
		this.vmPwd = vmPwd;
		this.osUserName = osUserName;
		this.osPwd = osPwd;
		this.opSys = opSys;
		this.ip = ip;
		this.provMachineType = provMachineType;
		this.virtualMachineType = virtualMachineType;
	}
}
