package com.framework.to;

public class PlatformTypeTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6318895706776846362L;
	private String type;
	private String label;
	private String value;
	private String vmwareGuestId;
	
	public String getLabel() {
	
		return label;
	}
	
	public String getType() {
	
		return type;
	}
	
	public String getValue() {
	
		return value;
	}
	
	public String getVmwareGuestId() {
	
		return vmwareGuestId;
	}
	
	public void setLabel(String label) {
	
		this.label = label;
	}
	
	public void setType(String type) {
	
		this.type = type;
	}
	
	public void setValue(String value) {
	
		this.value = value;
	}
	
	public void setVmwareGuestId(String vmwareGuestId) {
	
		this.vmwareGuestId = vmwareGuestId;
	}
}
