package com.framework.common;

public enum AttributeType {
	HARDWARE("Hardware"), SOFTWARE("Software"), NETWORK("Network");
	
	private String attributeType;
	
	private AttributeType(String s) {
	
		this.attributeType = s;
	}
	
	public String getAttributeType() {
	
		return attributeType;
	}
}
