package com.framework.to;

import java.io.Serializable;

/**
 * Bean for containing account information for AWS
 *
 * @author 459704
 */
public class AWSAccountTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 83701816404735112L;
	private Long awsAccountId;
	private String awsAccountName;
	private String awsAccountAccessKey;
	private String awsAccountSecretKey;
	
	public String getAwsAccountAccessKey() {
	
		return awsAccountAccessKey;
	}
	
	public Long getAwsAccountId() {
	
		return awsAccountId;
	}
	
	public String getAwsAccountName() {
	
		return awsAccountName;
	}
	
	public String getAwsAccountSecretKey() {
	
		return awsAccountSecretKey;
	}
	
	public void setAwsAccountAccessKey(String awsAccountAccessKey) {
	
		this.awsAccountAccessKey = awsAccountAccessKey;
	}
	
	public void setAwsAccountId(Long awsAccountId) {
	
		this.awsAccountId = awsAccountId;
	}
	
	public void setAwsAccountName(String awsAccountName) {
	
		this.awsAccountName = awsAccountName;
	}
	
	public void setAwsAccountSecretKey(String awsAccountSecretKey) {
	
		this.awsAccountSecretKey = awsAccountSecretKey;
	}
}
