package com.framework.to;

/**
 * @author TCS
 */
public abstract class NamedEntityTO extends AbstractTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2779380124794980649L;
	private String name = "";
	
	/**
	 * @return the name
	 */
	public String getName() {
	
		return name;
	}
	
	/**
	 * @param name
	 *                the name to set
	 */
	public void setName(String name) {
	
		this.name = name;
	}
}
