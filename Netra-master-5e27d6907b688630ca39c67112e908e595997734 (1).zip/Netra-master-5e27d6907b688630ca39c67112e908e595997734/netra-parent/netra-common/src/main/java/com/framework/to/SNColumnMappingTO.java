package com.framework.to;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class SNColumnMappingTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3286474295876788780L;
	private Long id;
	private Long tMapID;
	private String snColumn;
	private String netraColumn;
	private String netraTable;
	private String snTable;
	private String data;
	private List<String> snColumns = new ArrayList<String>(0);
	private List<String> netraColumns = new ArrayList<String>(0);
	private List<String> tableNames = new ArrayList<String>(0);
	private List<String> tableNamesSN = new ArrayList<String>(0);
	
	public SNColumnMappingTO() {
	
		/* No implementation required at the moment. Method for future use. */
	}
	
	public Long getId() {
	
		return id;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public String getSnColumn() {
	
		return snColumn;
	}
	
	public void setSnColumn(String snColumn) {
	
		this.snColumn = snColumn;
	}
	
	public String getNetraColumn() {
	
		return netraColumn;
	}
	
	public void setNetraColumn(String netraColumn) {
	
		this.netraColumn = netraColumn;
	}
	
	public List<String> getSnColumns() {
	
		return snColumns;
	}
	
	public void setSnColumns(List<String> snColumns) {
	
		this.snColumns = snColumns;
	}
	
	public List<String> getNetraColumns() {
	
		return netraColumns;
	}
	
	public void setNetraColumns(List<String> netraColumns) {
	
		this.netraColumns = netraColumns;
	}
	
	public Long gettMapID() {
	
		return tMapID;
	}
	
	public void settMapID(Long tMapID) {
	
		this.tMapID = tMapID;
	}
	
	public String getNetraTable() {
	
		return netraTable;
	}
	
	public void setNetraTable(String netraTable) {
	
		this.netraTable = netraTable;
	}
	
	public List<String> getTableNames() {
	
		return tableNames;
	}
	
	public void setTableNames(List<String> tableNames) {
	
		this.tableNames = tableNames;
	}
	
	public String getData() {
	
		return data;
	}
	
	public void setData(String data) {
	
		this.data = data;
	}
	
	public List<String> getTableNamesSN() {
	
		return tableNamesSN;
	}
	
	public void setTableNamesSN(List<String> tableNamesSN) {
	
		this.tableNamesSN = tableNamesSN;
	}
	
	public String getSnTable() {
	
		return snTable;
	}
	
	public void setSnTable(String snTable) {
	
		this.snTable = snTable;
	}
}
