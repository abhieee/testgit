package com.framework.to;

import java.io.Serializable;

public class GlobalParametersTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4528400192700876905L;
	private long id;
	private String parameterName;
	private String parameterValue;
	
	public long getId() {
	
		return id;
	}
	
	public String getParameterName() {
	
		return parameterName;
	}
	
	public String getParameterValue() {
	
		return parameterValue;
	}
	
	public void setId(long id) {
	
		this.id = id;
	}
	
	public void setParameterName(String parameterName) {
	
		this.parameterName = parameterName;
	}
	
	public void setParameterValue(String parameterValue) {
	
		this.parameterValue = parameterValue;
	}
}
