package com.framework.to;

import java.util.Date;

public class MsgHistoryTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String receiverTo;
	private String receiverCc;
	private String message;
	private Date sendTime;
	private Date receivedTime;
	private String status;
	private String errormsg;
	private Long entity;
	private Long subEntity;
	
	public Long getEntity() {
	
		return entity;
	}
	
	public String getErrormsg() {
	
		return errormsg;
	}
	
	public String getMessage() {
	
		return message;
	}
	
	public Date getReceivedTime() {
	
		return receivedTime;
	}
	
	public String getReceiverCc() {
	
		return receiverCc;
	}
	
	public String getReceiverTo() {
	
		return receiverTo;
	}
	
	public Date getSendTime() {
	
		return sendTime;
	}
	
	public String getStatus() {
	
		return status;
	}
	
	public Long getSubEntity() {
	
		return subEntity;
	}
	
	public void setEntity(Long entity) {
	
		this.entity = entity;
	}
	
	public void setErrormsg(String errormsg) {
	
		this.errormsg = errormsg;
	}
	
	public void setMessage(String message) {
	
		this.message = message;
	}
	
	public void setReceivedTime(Date receivedTime) {
	
		this.receivedTime = receivedTime;
	}
	
	public void setReceiverCc(String receiverCc) {
	
		this.receiverCc = receiverCc;
	}
	
	public void setReceiverTo(String receiverTo) {
	
		this.receiverTo = receiverTo;
	}
	
	public void setSendTime(Date sendTime) {
	
		this.sendTime = sendTime;
	}
	
	public void setStatus(String status) {
	
		this.status = status;
	}
	
	public void setSubEntity(Long subEntity) {
	
		this.subEntity = subEntity;
	}
}