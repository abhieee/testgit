package com.framework.to;

import java.io.Serializable;

public class ProvisionedMachineVMWareTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2131151781235896729L;
	private Long id;
	private ProvisionedMachineTO provisionedMachine;
	private Long templateId;
	private Long provisionedMachineId;
	private Long provisionedMachineTemplateId;
	private String username;
	private String password;
	
	public Long getId() {
	
		return id;
	}
	
	public String getPassword() {
	
		return password;
	}
	
	public ProvisionedMachineTO getProvisionedMachine() {
	
		return provisionedMachine;
	}
	
	public Long getProvisionedMachineId() {
	
		return provisionedMachineId;
	}
	
	public Long getProvisionedMachineTemplateId() {
	
		return provisionedMachineTemplateId;
	}
	
	public Long getTemplateId() {
	
		return templateId;
	}
	
	public String getUsername() {
	
		return username;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setPassword(String password) {
	
		this.password = password;
	}
	
	public void setProvisionedMachine(ProvisionedMachineTO provisionedMachine) {
	
		this.provisionedMachine = provisionedMachine;
	}
	
	public void setProvisionedMachineId(Long provisionedMachineId) {
	
		this.provisionedMachineId = provisionedMachineId;
	}
	
	public void setProvisionedMachineTemplateId(Long provisionedMachineTemplateId) {
	
		this.provisionedMachineTemplateId = provisionedMachineTemplateId;
	}
	
	public void setTemplateId(Long templateId) {
	
		this.templateId = templateId;
	}
	
	public void setUsername(String username) {
	
		this.username = username;
	}
}
