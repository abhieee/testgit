package com.framework.common;

public enum Cloud {
	VMWARE_VSPEHRE("DATA CENTRE"), VMWARE_BARE_METAL("ESXI SERVER"), OPENSTACK("OPENSTACK");
	
	private String cloudType;
	
	private Cloud(String s) {
	
		this.cloudType = s;
	}
	
	public String getCloudType() {
	
		return cloudType;
	}
}
