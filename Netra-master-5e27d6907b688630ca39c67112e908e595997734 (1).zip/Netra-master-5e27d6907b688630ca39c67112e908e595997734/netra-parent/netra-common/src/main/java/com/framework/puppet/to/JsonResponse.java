package com.framework.puppet.to;

import java.util.List;

public class JsonResponse {
	
	private String status;
	private String errordescription;
	private List<Statuslist> statuslist;
	private String errmsg;
	
	public String getErrmsg() {
	
		return errmsg;
	}
	
	public String getErrordescription() {
	
		return errordescription;
	}
	
	public String getStatus() {
	
		return status;
	}
	
	public List<Statuslist> getStatuslist() {
	
		return statuslist;
	}
	
	public void setErrmsg(String errmsg) {
	
		this.errmsg = errmsg;
	}
	
	public void setErrordescription(String errordescription) {
	
		this.errordescription = errordescription;
	}
	
	public void setStatus(String status) {
	
		this.status = status;
	}
	
	public void setStatuslist(List<Statuslist> statuslist) {
	
		this.statuslist = statuslist;
	}
}
