package com.framework.common;

import java.util.Comparator;
import com.framework.to.NamedEntityTO;

/**
 * This comparator class is being used to compare the NamedEntity class objects.
 *
 * @author TCS
 */
public class CMMViewComparator implements Comparator<NamedEntityTO> {
	
	private static CMMViewComparator viewComparator = null;
	
	private CMMViewComparator() {
	
	}
	
	/**
	 * @param o1
	 *                First NamedEntity Object
	 * @param o2
	 *                Second NamedEntity Object
	 * @return a negative integer, zero, or a positive integer as the specified String is greater than, equal to, or less than this String, ignoring case
	 *         considerations
	 */
	@Override
	public int compare(NamedEntityTO o1, NamedEntityTO o2) {
	
		return o1.getName().compareToIgnoreCase(o2.getName());
	}
	
	/**
	 * This method makes sure that this class follows the singleton pattern and only one object is available for this class at any moment of time
	 *
	 * @return the object of this class
	 */
	public static CMMViewComparator getInstance() {
	
		if (viewComparator == null) {
			viewComparator = new CMMViewComparator();
		}
		return viewComparator;
	}
}
