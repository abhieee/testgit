package com.framework.to;

import java.util.ArrayList;
import java.util.List;

public class SubAppTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5431613927911752882L;
	private String appName;
	private Long childAppId;
	private Long parentAppId;
	private ApplicationTO applicationsByChildAppId;
	private ApplicationTO applicationsByParentAppId;
	private List<ApplicationTO> applicationList = new ArrayList<ApplicationTO>(0);
	private List<Object> application = new ArrayList<Object>();
	private Long selectedApplication = null;
	private Long businessUnit = null;
	private List<ApplicationTO> subAppListLeft = new ArrayList<ApplicationTO>(0);
	private List<ApplicationTO> subAppListRight = new ArrayList<ApplicationTO>(0);
	private List<Long> selectedSubAppRight = new ArrayList<Long>(0);
	private Long selectedSubAppLeft = null;
	
	public List<Object> getApplication() {
	
		return application;
	}
	
	public List<ApplicationTO> getApplicationList() {
	
		return applicationList;
	}
	
	public ApplicationTO getApplicationsByChildAppId() {
	
		return applicationsByChildAppId;
	}
	
	public ApplicationTO getApplicationsByParentAppId() {
	
		return applicationsByParentAppId;
	}
	
	public String getAppName() {
	
		return appName;
	}
	
	public Long getBusinessUnit() {
	
		return businessUnit;
	}
	
	public Long getChildAppId() {
	
		return childAppId;
	}
	
	public Long getParentAppId() {
	
		return parentAppId;
	}
	
	public Long getSelectedApplication() {
	
		return selectedApplication;
	}
	
	public Long getSelectedSubAppLeft() {
	
		return selectedSubAppLeft;
	}
	
	public List<Long> getSelectedSubAppRight() {
	
		return selectedSubAppRight;
	}
	
	public List<ApplicationTO> getSubAppListLeft() {
	
		return subAppListLeft;
	}
	
	public List<ApplicationTO> getSubAppListRight() {
	
		return subAppListRight;
	}
	
	public void setApplication(List<Object> application) {
	
		this.application = application;
	}
	
	public void setApplicationList(List<ApplicationTO> applicationList) {
	
		this.applicationList = applicationList;
	}
	
	public void setApplicationsByChildAppId(ApplicationTO applicationsByChildAppId) {
	
		this.applicationsByChildAppId = applicationsByChildAppId;
	}
	
	public void setApplicationsByParentAppId(ApplicationTO applicationsByParentAppId) {
	
		this.applicationsByParentAppId = applicationsByParentAppId;
	}
	
	public void setAppName(String appName) {
	
		this.appName = appName;
	}
	
	public void setBusinessUnit(Long businessUnit) {
	
		this.businessUnit = businessUnit;
	}
	
	public void setChildAppId(Long childAppId) {
	
		this.childAppId = childAppId;
	}
	
	public void setParentAppId(Long parentAppId) {
	
		this.parentAppId = parentAppId;
	}
	
	public void setSelectedApplication(Long selectedApplication) {
	
		this.selectedApplication = selectedApplication;
	}
	
	public void setSelectedSubAppLeft(Long selectedSubAppLeft) {
	
		this.selectedSubAppLeft = selectedSubAppLeft;
	}
	
	public void setSelectedSubAppRight(List<Long> selectedSubAppRight) {
	
		this.selectedSubAppRight = selectedSubAppRight;
	}
	
	public void setSubAppListLeft(List<ApplicationTO> subAppListLeft) {
	
		this.subAppListLeft = subAppListLeft;
	}
	
	public void setSubAppListRight(List<ApplicationTO> subAppListRight) {
	
		this.subAppListRight = subAppListRight;
	}
}
