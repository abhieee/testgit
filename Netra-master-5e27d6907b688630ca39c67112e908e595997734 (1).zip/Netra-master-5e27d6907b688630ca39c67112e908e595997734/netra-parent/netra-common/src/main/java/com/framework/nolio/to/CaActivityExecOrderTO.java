/**
 *
 */
package com.framework.nolio.to;

import java.io.Serializable;
import com.framework.to.ActivitySoftwareMappingTO;

public class CaActivityExecOrderTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2752861403319122323L;
	private long activitiesExecutionId;
	private ActivitySoftwareMappingTO activitySoftwareMappingTO;
	private ActivitySoftwareMappingTO activitySoftwareMappingTOP;
	private long exeOrder;
	private long softwareId;
	
	public long getActivitiesExecutionId() {
	
		return activitiesExecutionId;
	}
	
	public ActivitySoftwareMappingTO getActivitySoftwareMappingTO() {
	
		return activitySoftwareMappingTO;
	}
	
	public ActivitySoftwareMappingTO getActivitySoftwareMappingTOP() {
	
		return activitySoftwareMappingTOP;
	}
	
	public long getExeOrder() {
	
		return exeOrder;
	}
	
	public long getSoftwareId() {
	
		return softwareId;
	}
	
	public void setActivitiesExecutionId(long activitiesExecutionId) {
	
		this.activitiesExecutionId = activitiesExecutionId;
	}
	
	public void setActivitySoftwareMappingTO(ActivitySoftwareMappingTO activitySoftwareMappingTO) {
	
		this.activitySoftwareMappingTO = activitySoftwareMappingTO;
	}
	
	public void setActivitySoftwareMappingTOP(ActivitySoftwareMappingTO activitySoftwareMappingTOP) {
	
		this.activitySoftwareMappingTOP = activitySoftwareMappingTOP;
	}
	
	public void setExeOrder(long exeOrder) {
	
		this.exeOrder = exeOrder;
	}
	
	public void setSoftwareId(long softwareId) {
	
		this.softwareId = softwareId;
	}
}
