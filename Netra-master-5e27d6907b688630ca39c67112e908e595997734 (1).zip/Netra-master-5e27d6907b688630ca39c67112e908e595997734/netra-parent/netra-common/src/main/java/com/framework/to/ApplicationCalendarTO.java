/**
 *
 */
package com.framework.to;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @author TCS
 */
public class ApplicationCalendarTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3870326651338004255L;
	private Long id;
	private Long selectedAppId;
	private Long selectedApplicationRelease;
	private Long userGrpId;
	private List<BusinessUnitTO> businessUnit;
	private List<NamedEntityTO> project;
	private List<NamedEntityTO> statuses;
	private List<UserTO> ownerList = null;
	private Long selectedOwner = null;
	private Long selectedReservationOwner = null;
	private Long selectedStatus;
	private Long selectedProject;
	private long selectedBusinessUnit;
	private String appName;
	private Long status;
	private String description;
	private String release;
	private String userGroup;
	private String businessUnitName;
	private String projectName;
	private Set<UserGroupTO> userGroupTO = new HashSet<UserGroupTO>();
	private List<UserGroupTO> userNameList;
	private List<Long> selectedUserName = null;
	private BusinessUnitTO businessUnitTO = null;
	private ProjectsTO projectTO = null;
	private Set<SubAppTO> applicationTreesForChildAppId = new HashSet<SubAppTO>(0);
	private Set<SubAppTO> applicationTreesForParentAppId = new HashSet<SubAppTO>(0);
	private Set<ReservationTO> reservationses = new HashSet<ReservationTO>(0);
	private Set<WorkflowCurrentTO> workflowCurrentTO = new HashSet<WorkflowCurrentTO>();
	private List<NamedEntityTO> subAppListLeft = null;
	private List<ApplicationCalendarTO> allApplications = null;
	private List<ServiceTO> NServices = null;
	private List<ServiceTO> YServices = null;
	private Long createdById;
	private Long modifiedbyId;
	private Date createdByDate;
	private Date modifiedbyDate;
	private List<ApplicationReleaseTO> releaseList = new ArrayList<ApplicationReleaseTO>();
	private List<RepoTO> repoResult = null;
	private Long selectedService;
	private Long selectedApplicationReleaseMinor;
	private String archiAvail = null;
	private String ciAvail = null;
	private String thirdSupport = null;
	private String timeRationale = null;
	private List<CIServerTO> ciResult = null;
	private Long addCI_Id;
	private int mapId;
	private Set<EnvironmentApplicationTO> envAppTO = new HashSet<EnvironmentApplicationTO>(0);
	private Long selectedUserGroup = null;
	private UserGroupTO userGroups = new UserGroupTO();
	
	public Long getAddCI_Id() {
	
		return addCI_Id;
	}
	
	public List<ApplicationCalendarTO> getAllApplications() {
	
		return allApplications;
	}
	
	public Set<SubAppTO> getApplicationTreesForChildAppId() {
	
		return applicationTreesForChildAppId;
	}
	
	public Set<SubAppTO> getApplicationTreesForParentAppId() {
	
		return applicationTreesForParentAppId;
	}
	
	public String getAppName() {
	
		return appName;
	}
	
	public String getArchiAvail() {
	
		return archiAvail;
	}
	
	public List<BusinessUnitTO> getBusinessUnit() {
	
		return businessUnit;
	}
	
	public String getBusinessUnitName() {
	
		return businessUnitName;
	}
	
	public BusinessUnitTO getBusinessUnitTO() {
	
		return businessUnitTO;
	}
	
	public String getCiAvail() {
	
		return ciAvail;
	}
	
	public List<CIServerTO> getCiResult() {
	
		return ciResult;
	}
	
	public Date getCreatedByDate() {
	
		return createdByDate;
	}
	
	@Override
	public Long getCreatedById() {
	
		return createdById;
	}
	
	public String getDescription() {
	
		return description;
	}
	
	public Set<EnvironmentApplicationTO> getEnvAppTO() {
	
		return envAppTO;
	}
	
	@Override
	public Long getId() {
	
		return id;
	}
	
	public int getMapId() {
	
		return mapId;
	}
	
	public Date getModifiedbyDate() {
	
		return modifiedbyDate;
	}
	
	@Override
	public Long getModifiedbyId() {
	
		return modifiedbyId;
	}
	
	public List<ServiceTO> getNServices() {
	
		return NServices;
	}
	
	public List<UserTO> getOwnerList() {
	
		return ownerList;
	}
	
	public List<NamedEntityTO> getProject() {
	
		return project;
	}
	
	public String getProjectName() {
	
		return projectName;
	}
	
	public ProjectsTO getProjectTO() {
	
		return projectTO;
	}
	
	public String getRelease() {
	
		return release;
	}
	
	public List<ApplicationReleaseTO> getReleaseList() {
	
		return releaseList;
	}
	
	public List<RepoTO> getRepoResult() {
	
		return repoResult;
	}
	
	public Set<ReservationTO> getReservationses() {
	
		return reservationses;
	}
	
	public Long getSelectedAppId() {
	
		return selectedAppId;
	}
	
	public Long getSelectedApplicationRelease() {
	
		return selectedApplicationRelease;
	}
	
	public Long getSelectedApplicationReleaseMinor() {
	
		return selectedApplicationReleaseMinor;
	}
	
	public long getSelectedBusinessUnit() {
	
		return selectedBusinessUnit;
	}
	
	public Long getSelectedOwner() {
	
		return selectedOwner;
	}
	
	public Long getSelectedProject() {
	
		return selectedProject;
	}
	
	public Long getSelectedReservationOwner() {
	
		return selectedReservationOwner;
	}
	
	public Long getSelectedService() {
	
		return selectedService;
	}
	
	public Long getSelectedStatus() {
	
		return selectedStatus;
	}
	
	public Long getSelectedUserGroup() {
	
		return selectedUserGroup;
	}
	
	public List<Long> getSelectedUserName() {
	
		return selectedUserName;
	}
	
	public Long getStatus() {
	
		return status;
	}
	
	public List<NamedEntityTO> getStatuses() {
	
		return statuses;
	}
	
	public List<NamedEntityTO> getSubAppListLeft() {
	
		return subAppListLeft;
	}
	
	public String getThirdSupport() {
	
		return thirdSupport;
	}
	
	public String getTimeRationale() {
	
		return timeRationale;
	}
	
	public String getUserGroup() {
	
		return userGroup;
	}
	
	public UserGroupTO getUserGroups() {
	
		return userGroups;
	}
	
	public Set<UserGroupTO> getUserGroupTO() {
	
		return userGroupTO;
	}
	
	public Long getUserGrpId() {
	
		return userGrpId;
	}
	
	public List<UserGroupTO> getUserNameList() {
	
		return userNameList;
	}
	
	public Set<WorkflowCurrentTO> getWorkflowCurrentTO() {
	
		return workflowCurrentTO;
	}
	
	public List<ServiceTO> getYServices() {
	
		return YServices;
	}
	
	public void setAddCI_Id(Long addCI_Id) {
	
		this.addCI_Id = addCI_Id;
	}
	
	public void setAllApplications(List<ApplicationCalendarTO> allApplications) {
	
		this.allApplications = allApplications;
	}
	
	public void setApplicationTreesForChildAppId(Set<SubAppTO> applicationTreesForChildAppId) {
	
		this.applicationTreesForChildAppId = applicationTreesForChildAppId;
	}
	
	public void setApplicationTreesForParentAppId(Set<SubAppTO> applicationTreesForParentAppId) {
	
		this.applicationTreesForParentAppId = applicationTreesForParentAppId;
	}
	
	public void setAppName(String appName) {
	
		this.appName = appName;
	}
	
	public void setArchiAvail(String archiAvail) {
	
		this.archiAvail = archiAvail;
	}
	
	public void setBusinessUnit(List<BusinessUnitTO> businessUnit) {
	
		this.businessUnit = businessUnit;
	}
	
	public void setBusinessUnitName(String businessUnitName) {
	
		this.businessUnitName = businessUnitName;
	}
	
	public void setBusinessUnitTO(BusinessUnitTO businessUnitTO) {
	
		this.businessUnitTO = businessUnitTO;
	}
	
	public void setCiAvail(String ciAvail) {
	
		this.ciAvail = ciAvail;
	}
	
	public void setCiResult(List<CIServerTO> ciResult) {
	
		this.ciResult = ciResult;
	}
	
	public void setCreatedByDate(Date createdByDate) {
	
		this.createdByDate = createdByDate;
	}
	
	@Override
	public void setCreatedById(Long createdById) {
	
		this.createdById = createdById;
	}
	
	public void setDescription(String description) {
	
		this.description = description;
	}
	
	public void setEnvAppTO(Set<EnvironmentApplicationTO> envAppTO) {
	
		this.envAppTO = envAppTO;
	}
	
	@Override
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setMapId(int mapId) {
	
		this.mapId = mapId;
	}
	
	public void setModifiedbyDate(Date modifiedbyDate) {
	
		this.modifiedbyDate = modifiedbyDate;
	}
	
	@Override
	public void setModifiedbyId(Long modifiedbyId) {
	
		this.modifiedbyId = modifiedbyId;
	}
	
	public void setNServices(List<ServiceTO> nServices) {
	
		NServices = nServices;
	}
	
	public void setOwnerList(List<UserTO> ownerList) {
	
		this.ownerList = ownerList;
	}
	
	public void setProject(List<NamedEntityTO> project) {
	
		this.project = project;
	}
	
	public void setProjectName(String projectName) {
	
		this.projectName = projectName;
	}
	
	public void setProjectTO(ProjectsTO projectTO) {
	
		this.projectTO = projectTO;
	}
	
	public void setRelease(String release) {
	
		this.release = release;
	}
	
	public void setReleaseList(List<ApplicationReleaseTO> releaseList) {
	
		this.releaseList = releaseList;
	}
	
	public void setRepoResult(List<RepoTO> repoResult) {
	
		this.repoResult = repoResult;
	}
	
	public void setReservationses(Set<ReservationTO> reservationses) {
	
		this.reservationses = reservationses;
	}
	
	public void setSelectedAppId(Long selectedAppId) {
	
		this.selectedAppId = selectedAppId;
	}
	
	public void setSelectedApplicationRelease(Long selectedApplicationRelease) {
	
		this.selectedApplicationRelease = selectedApplicationRelease;
	}
	
	public void setSelectedApplicationReleaseMinor(Long selectedApplicationReleaseMinor) {
	
		this.selectedApplicationReleaseMinor = selectedApplicationReleaseMinor;
	}
	
	public void setSelectedBusinessUnit(long selectedBusinessUnit) {
	
		this.selectedBusinessUnit = selectedBusinessUnit;
	}
	
	public void setSelectedOwner(Long selectedOwner) {
	
		this.selectedOwner = selectedOwner;
	}
	
	public void setSelectedProject(Long selectedProject) {
	
		this.selectedProject = selectedProject;
	}
	
	public void setSelectedReservationOwner(Long selectedReservationOwner) {
	
		this.selectedReservationOwner = selectedReservationOwner;
	}
	
	public void setSelectedService(Long selectedService) {
	
		this.selectedService = selectedService;
	}
	
	public void setSelectedStatus(Long selectedStatus) {
	
		this.selectedStatus = selectedStatus;
	}
	
	public void setSelectedUserGroup(Long selectedUserGroup) {
	
		this.selectedUserGroup = selectedUserGroup;
	}
	
	public void setSelectedUserName(List<Long> selectedUserName) {
	
		this.selectedUserName = selectedUserName;
	}
	
	public void setStatus(Long status) {
	
		this.status = status;
	}
	
	public void setStatuses(List<NamedEntityTO> statuses) {
	
		this.statuses = statuses;
	}
	
	public void setSubAppListLeft(List<NamedEntityTO> subAppListLeft) {
	
		this.subAppListLeft = subAppListLeft;
	}
	
	public void setThirdSupport(String thirdSupport) {
	
		this.thirdSupport = thirdSupport;
	}
	
	public void setTimeRationale(String timeRationale) {
	
		this.timeRationale = timeRationale;
	}
	
	public void setUserGroup(String userGroup) {
	
		this.userGroup = userGroup;
	}
	
	public void setUserGroups(UserGroupTO userGroups) {
	
		this.userGroups = userGroups;
	}
	
	public void setUserGroupTO(Set<UserGroupTO> userGroupTO) {
	
		this.userGroupTO = userGroupTO;
	}
	
	public void setUserGrpId(Long userGrpId) {
	
		this.userGrpId = userGrpId;
	}
	
	public void setUserNameList(List<UserGroupTO> userNameList) {
	
		this.userNameList = userNameList;
	}
	
	public void setWorkflowCurrentTO(Set<WorkflowCurrentTO> workflowCurrentTO) {
	
		this.workflowCurrentTO = workflowCurrentTO;
	}
	
	public void setYServices(List<ServiceTO> yServices) {
	
		YServices = yServices;
	}
}
