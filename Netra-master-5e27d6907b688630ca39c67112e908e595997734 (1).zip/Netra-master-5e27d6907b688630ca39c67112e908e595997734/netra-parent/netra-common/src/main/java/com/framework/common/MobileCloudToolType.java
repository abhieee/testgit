package com.framework.common;

public enum MobileCloudToolType {
	Perfecto("PERFECTO");
	
	private String mobileTool;
	
	private MobileCloudToolType(String s) {
	
		this.mobileTool = s;
	}
	
	public String getMobileCloudToolType() {
	
		return mobileTool;
	}
}