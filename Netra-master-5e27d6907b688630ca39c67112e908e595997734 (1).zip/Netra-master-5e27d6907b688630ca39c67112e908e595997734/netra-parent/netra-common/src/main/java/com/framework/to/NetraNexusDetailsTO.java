package com.framework.to;

import java.io.Serializable;

public class NetraNexusDetailsTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long id;
	private String repoId;
	private String groupId;
	private String url;
	private String username;
	private String password;
	
	public String getGroupId() {
	
		return groupId;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public String getPassword() {
	
		return password;
	}
	
	public String getRepoId() {
	
		return repoId;
	}
	
	public String getUrl() {
	
		return url;
	}
	
	public String getUsername() {
	
		return username;
	}
	
	public void setGroupId(String groupId) {
	
		this.groupId = groupId;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setPassword(String password) {
	
		this.password = password;
	}
	
	public void setRepoId(String repoId) {
	
		this.repoId = repoId;
	}
	
	public void setUrl(String url) {
	
		this.url = url;
	}
	
	public void setUsername(String username) {
	
		this.username = username;
	}
}
