package com.framework.to;

import java.io.Serializable;

/**
 * This class declares the transfer object that carries reservation information across the application.
 * 
 * @author TCS
 */
public class VmReportTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -102836307432611126L;
	private Long Id;
	private String modelName;
	private String decription;
	private String enrollCost;
	private String billingFrequrency;
	private Long activeCost;
	private Long inActiveCost;
	private String chargesPerCPU;
	private String chargesPerRAM;
	private Long selectedBU;
	private Long selectedModel;
	private Long selectedProject;
	private String fromDate;
	private String toDate;
	
	public Long getActiveCost() {
	
		return activeCost;
	}
	
	public String getBillingFrequrency() {
	
		return billingFrequrency;
	}
	
	public String getDecription() {
	
		return decription;
	}
	
	public String getFromDate() {
	
		return fromDate;
	}
	
	public Long getId() {
	
		return Id;
	}
	
	public Long getInActiveCost() {
	
		return inActiveCost;
	}
	
	public String getModelName() {
	
		return modelName;
	}
	
	public Long getSelectedBU() {
	
		return selectedBU;
	}
	
	public Long getSelectedModel() {
	
		return selectedModel;
	}
	
	public Long getSelectedProject() {
	
		return selectedProject;
	}
	
	public String getToDate() {
	
		return toDate;
	}
	
	public void setActiveCost(Long activeCost) {
	
		this.activeCost = activeCost;
	}
	
	public void setBillingFrequrency(String billingFrequrency) {
	
		this.billingFrequrency = billingFrequrency;
	}
	
	public String getEnrollCost() {
	
		return enrollCost;
	}
	
	public void setEnrollCost(String enrollCost) {
	
		this.enrollCost = enrollCost;
	}
	
	public String getChargesPerCPU() {
	
		return chargesPerCPU;
	}
	
	public void setChargesPerCPU(String chargesPerCPU) {
	
		this.chargesPerCPU = chargesPerCPU;
	}
	
	public String getChargesPerRAM() {
	
		return chargesPerRAM;
	}
	
	public void setChargesPerRAM(String chargesPerRAM) {
	
		this.chargesPerRAM = chargesPerRAM;
	}
	
	public void setDecription(String decription) {
	
		this.decription = decription;
	}
	
	public void setFromDate(String fromDate) {
	
		this.fromDate = fromDate;
	}
	
	public void setId(Long id) {
	
		Id = id;
	}
	
	public void setInActiveCost(Long inActiveCost) {
	
		this.inActiveCost = inActiveCost;
	}
	
	public void setModelName(String modelName) {
	
		this.modelName = modelName;
	}
	
	public void setSelectedBU(Long selectedBU) {
	
		this.selectedBU = selectedBU;
	}
	
	public void setSelectedModel(Long selectedModel) {
	
		this.selectedModel = selectedModel;
	}
	
	public void setSelectedProject(Long selectedProject) {
	
		this.selectedProject = selectedProject;
	}
	
	public void setToDate(String toDate) {
	
		this.toDate = toDate;
	}
}
