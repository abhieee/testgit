package com.framework.to;

import java.io.Serializable;

public class ApplicationReleaseSharedDetailsTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2376494512830659022L;
	private Long id;
	private String sharedIp;
	private String hostname;
	
	public String getHostname() {
	
		return hostname;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public String getSharedIp() {
	
		return sharedIp;
	}
	
	public void setHostname(String hostname) {
	
		this.hostname = hostname;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setSharedIp(String sharedIp) {
	
		this.sharedIp = sharedIp;
	}
}
