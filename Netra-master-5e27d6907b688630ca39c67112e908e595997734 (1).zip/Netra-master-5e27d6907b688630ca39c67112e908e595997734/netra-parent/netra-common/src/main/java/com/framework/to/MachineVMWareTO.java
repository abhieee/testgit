package com.framework.to;

import java.io.Serializable;

public class MachineVMWareTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5864034849086049085L;
	private Long id;
	private String username;
	private String password;
	private MachineTO machine;
	private MachineTemplateTO machineTemplate;
	
	public Long getId() {
	
		return id;
	}
	
	public MachineTO getMachine() {
	
		return machine;
	}
	
	public MachineTemplateTO getMachineTemplate() {
	
		return machineTemplate;
	}
	
	public String getPassword() {
	
		return password;
	}
	
	public String getUsername() {
	
		return username;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setMachine(MachineTO machine) {
	
		this.machine = machine;
	}
	
	public void setMachineTemplate(MachineTemplateTO machineTemplate) {
	
		this.machineTemplate = machineTemplate;
	}
	
	public void setPassword(String password) {
	
		this.password = password;
	}
	
	public void setUsername(String username) {
	
		this.username = username;
	}
}
