package com.framework.to;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ReleasePlanningTO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private Long id;
	private Long buId;
	private Long projectId;
	private Long applicationId;
	private String name;
	private String version;
	private String type;
	private Date startDate;
	private Date targetDate;
	private Long managerId;
	private String description;
	private int searchCount;
	private Collection<ReleasePlanningTO> releasePlannings = new HashSet<>(0);
	private boolean editAccessFlag = false;
	private int tableSize = 10;
	private Long pageNumber = 1L;
	private int firstResult = 0;
	private List<BusinessUnitTO> businessUnitList = new ArrayList<>(0);
	private List<ProjectsTO> projectList = new ArrayList<>(0);
	private List<ApplicationTO> applicationList = new ArrayList<>(0);
	private Long selectedBUId;
	private Long selectedProjectId;
	private Long selectedApplicationId;
	private Set<ReleasePlanningPhasesTO> releasePlanningPhases = new HashSet<>(0);
	private ClientTO clientTO;
	private ProjectsTO projectsTO;
	private ApplicationTO applicationTO;
	private UserTO userTO;
	private List<ApplicationTO> allApplications = new ArrayList<>(0);
	private List<StatusTO> statusList = new ArrayList<>(0);
	private List<String> releaseTypeList = new ArrayList<>(0);
	private boolean addAccessFlag = false;
	private boolean searchAccessFlag = false;
	private Long selectedStatus;
	private List<Long> selectedPhaseIds = new ArrayList<>(0);
	private List<TestingPhaseTO> applicationPhaseList = new ArrayList<>(0);
	private List<UserTO> managerList = new ArrayList<>(0);
	private String selectedBUName;
	private String selectedProjectName;
	private String selectedApplicationName;
	private Set<ReservationTO> reservationses = new HashSet<>(0);
	private List<ReleasePlanningPhasesTO> releasePlanningPhasesTO = new ArrayList<>(0);
	private Long selectedReleaseId;
	
	public List<ReleasePlanningPhasesTO> getReleasePlanningPhasesTO() {
	
		return releasePlanningPhasesTO;
	}
	
	public void setReleasePlanningPhasesTO(List<ReleasePlanningPhasesTO> releasePlanningPhasesTO) {
	
		this.releasePlanningPhasesTO = releasePlanningPhasesTO;
	}
	
	public static long getSerialversionuid() {
	
		return serialVersionUID;
	}
	
	public List<ApplicationTO> getAllApplications() {
	
		return allApplications;
	}
	
	public Long getApplicationId() {
	
		return applicationId;
	}
	
	public List<ApplicationTO> getApplicationList() {
	
		return applicationList;
	}
	
	public List<TestingPhaseTO> getApplicationPhaseList() {
	
		return applicationPhaseList;
	}
	
	public ApplicationTO getApplicationTO() {
	
		return applicationTO;
	}
	
	public Long getBuId() {
	
		return buId;
	}
	
	public List<BusinessUnitTO> getBusinessUnitList() {
	
		return businessUnitList;
	}
	
	public ClientTO getClientTO() {
	
		return clientTO;
	}
	
	public String getDescription() {
	
		return description;
	}
	
	public int getFirstResult() {
	
		return firstResult;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public Long getManagerId() {
	
		return managerId;
	}
	
	public List<UserTO> getManagerList() {
	
		return managerList;
	}
	
	public String getName() {
	
		return name;
	}
	
	public Long getPageNumber() {
	
		return pageNumber;
	}
	
	public Long getProjectId() {
	
		return projectId;
	}
	
	public List<ProjectsTO> getProjectList() {
	
		return projectList;
	}
	
	public ProjectsTO getProjectsTO() {
	
		return projectsTO;
	}
	
	public Set<ReleasePlanningPhasesTO> getReleasePlanningPhases() {
	
		return releasePlanningPhases;
	}
	
	public Collection<ReleasePlanningTO> getReleasePlannings() {
	
		return releasePlannings;
	}
	
	public List<String> getReleaseTypeList() {
	
		return releaseTypeList;
	}
	
	public int getSearchCount() {
	
		return searchCount;
	}
	
	public Long getSelectedApplicationId() {
	
		return selectedApplicationId;
	}
	
	public String getSelectedApplicationName() {
	
		return selectedApplicationName;
	}
	
	public Long getSelectedBUId() {
	
		return selectedBUId;
	}
	
	public String getSelectedBUName() {
	
		return selectedBUName;
	}
	
	public List<Long> getSelectedPhaseIds() {
	
		return selectedPhaseIds;
	}
	
	public Long getSelectedProjectId() {
	
		return selectedProjectId;
	}
	
	public String getSelectedProjectName() {
	
		return selectedProjectName;
	}
	
	public Long getSelectedStatus() {
	
		return selectedStatus;
	}
	
	public Date getStartDate() {
	
		return startDate;
	}
	
	public List<StatusTO> getStatusList() {
	
		return statusList;
	}
	
	public int getTableSize() {
	
		return tableSize;
	}
	
	public Date getTargetDate() {
	
		return targetDate;
	}
	
	public String getType() {
	
		return type;
	}
	
	public UserTO getUserTO() {
	
		return userTO;
	}
	
	public String getVersion() {
	
		return version;
	}
	
	public boolean isAddAccessFlag() {
	
		return addAccessFlag;
	}
	
	public boolean isEditAccessFlag() {
	
		return editAccessFlag;
	}
	
	public boolean isSearchAccessFlag() {
	
		return searchAccessFlag;
	}
	
	public void setAddAccessFlag(boolean addAccessFlag) {
	
		this.addAccessFlag = addAccessFlag;
	}
	
	public void setAllApplications(List<ApplicationTO> allApplications) {
	
		this.allApplications = allApplications;
	}
	
	public void setApplicationId(Long applicationId) {
	
		this.applicationId = applicationId;
	}
	
	public void setApplicationList(List<ApplicationTO> applicationList) {
	
		this.applicationList = applicationList;
	}
	
	public void setApplicationPhaseList(List<TestingPhaseTO> applicationPhaseList) {
	
		this.applicationPhaseList = applicationPhaseList;
	}
	
	public void setApplicationTO(ApplicationTO applicationTO) {
	
		this.applicationTO = applicationTO;
	}
	
	public void setBuId(Long buId) {
	
		this.buId = buId;
	}
	
	public void setBusinessUnitList(List<BusinessUnitTO> businessUnitList) {
	
		this.businessUnitList = businessUnitList;
	}
	
	public void setClientTO(ClientTO clientTO) {
	
		this.clientTO = clientTO;
	}
	
	public void setDescription(String description) {
	
		this.description = description;
	}
	
	public void setEditAccessFlag(boolean editAccessFlag) {
	
		this.editAccessFlag = editAccessFlag;
	}
	
	public void setFirstResult(int firstResult) {
	
		this.firstResult = firstResult;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setManagerId(Long managerId) {
	
		this.managerId = managerId;
	}
	
	public void setManagerList(List<UserTO> managerList) {
	
		this.managerList = managerList;
	}
	
	public void setName(String name) {
	
		this.name = name;
	}
	
	public void setPageNumber(Long pageNumber) {
	
		this.pageNumber = pageNumber;
	}
	
	public void setProjectId(Long projectId) {
	
		this.projectId = projectId;
	}
	
	public void setProjectList(List<ProjectsTO> projectList) {
	
		this.projectList = projectList;
	}
	
	public void setProjectsTO(ProjectsTO projectsTO) {
	
		this.projectsTO = projectsTO;
	}
	
	public void setReleasePlanningPhases(Set<ReleasePlanningPhasesTO> releasePlanningPhases) {
	
		this.releasePlanningPhases = releasePlanningPhases;
	}
	
	public void setReleasePlannings(Collection<ReleasePlanningTO> releasePlannings) {
	
		this.releasePlannings = releasePlannings;
	}
	
	public void setReleaseTypeList(List<String> releaseTypeList) {
	
		this.releaseTypeList = releaseTypeList;
	}
	
	public void setSearchAccessFlag(boolean searchAccessFlag) {
	
		this.searchAccessFlag = searchAccessFlag;
	}
	
	public void setSearchCount(int searchCount) {
	
		this.searchCount = searchCount;
	}
	
	public void setSelectedApplicationId(Long selectedApplicationId) {
	
		this.selectedApplicationId = selectedApplicationId;
	}
	
	public void setSelectedApplicationName(String selectedApplicationName) {
	
		this.selectedApplicationName = selectedApplicationName;
	}
	
	public void setSelectedBUId(Long selectedBUId) {
	
		this.selectedBUId = selectedBUId;
	}
	
	public void setSelectedBUName(String selectedBUName) {
	
		this.selectedBUName = selectedBUName;
	}
	
	public void setSelectedPhaseIds(List<Long> selectedPhaseIds) {
	
		this.selectedPhaseIds = selectedPhaseIds;
	}
	
	public void setSelectedProjectId(Long selectedProjectId) {
	
		this.selectedProjectId = selectedProjectId;
	}
	
	public void setSelectedProjectName(String selectedProjectName) {
	
		this.selectedProjectName = selectedProjectName;
	}
	
	public void setSelectedStatus(Long selectedStatus) {
	
		this.selectedStatus = selectedStatus;
	}
	
	public void setStartDate(Date startDate) {
	
		this.startDate = startDate;
	}
	
	public void setStatusList(List<StatusTO> statusList) {
	
		this.statusList = statusList;
	}
	
	public void setTableSize(int tableSize) {
	
		this.tableSize = tableSize;
	}
	
	public void setTargetDate(Date targetDate) {
	
		this.targetDate = targetDate;
	}
	
	public void setType(String type) {
	
		this.type = type;
	}
	
	public void setUserTO(UserTO userTO) {
	
		this.userTO = userTO;
	}
	
	public void setVersion(String version) {
	
		this.version = version;
	}
	
	public Set<ReservationTO> getReservationses() {
	
		return reservationses;
	}
	
	public void setReservationses(Set<ReservationTO> reservationses) {
	
		this.reservationses = reservationses;
	}
	
	public Long getSelectedReleaseId() {
	
		return selectedReleaseId;
	}
	
	public void setSelectedReleaseId(Long selectedReleaseId) {
	
		this.selectedReleaseId = selectedReleaseId;
	}
}