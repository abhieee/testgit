package com.framework.to;

import java.io.Serializable;

public class DataStoreTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -9222123086893022944L;
	private Long id;
	private String name;
	private Long dataCentreId;
	private String totalCapacity;
	private String usedSpace;
	private String freeSpace;
	private String status;
	
	public Long getDataCentreId() {
	
		return dataCentreId;
	}
	
	public String getFreeSpace() {
	
		return freeSpace;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public String getName() {
	
		return name;
	}
	
	public String getStatus() {
	
		return status;
	}
	
	public String getTotalCapacity() {
	
		return totalCapacity;
	}
	
	public String getUsedSpace() {
	
		return usedSpace;
	}
	
	public void setDataCentreId(Long dataCentreId) {
	
		this.dataCentreId = dataCentreId;
	}
	
	public void setFreeSpace(String freeSpace) {
	
		this.freeSpace = freeSpace;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setName(String name) {
	
		this.name = name;
	}
	
	public void setStatus(String status) {
	
		this.status = status;
	}
	
	public void setTotalCapacity(String totalCapacity) {
	
		this.totalCapacity = totalCapacity;
	}
	
	public void setUsedSpace(String usedSpace) {
	
		this.usedSpace = usedSpace;
	}
}
