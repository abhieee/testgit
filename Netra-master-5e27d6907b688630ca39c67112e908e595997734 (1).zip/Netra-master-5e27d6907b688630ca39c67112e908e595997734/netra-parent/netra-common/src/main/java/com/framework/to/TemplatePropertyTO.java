package com.framework.to;

import java.io.Serializable;

public class TemplatePropertyTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4051651522348760512L;
	private Long id;
	private Long templateId;
	private String propertyName;
	private String propertyValue;
	private HardwareTO hardware = new HardwareTO();
	
	public HardwareTO getHardware() {
	
		return hardware;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public String getPropertyName() {
	
		return propertyName;
	}
	
	public String getPropertyValue() {
	
		return propertyValue;
	}
	
	public Long getTemplateId() {
	
		return templateId;
	}
	
	public void setHardware(HardwareTO hardware) {
	
		this.hardware = hardware;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setPropertyName(String propertyName) {
	
		this.propertyName = propertyName;
	}
	
	public void setPropertyValue(String propertyValue) {
	
		this.propertyValue = propertyValue;
	}
	
	public void setTemplateId(Long templateId) {
	
		this.templateId = templateId;
	}
}
