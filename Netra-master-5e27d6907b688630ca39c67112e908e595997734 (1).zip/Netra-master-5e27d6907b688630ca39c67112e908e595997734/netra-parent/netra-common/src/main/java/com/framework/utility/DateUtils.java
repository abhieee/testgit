package com.framework.utility;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import org.apache.log4j.Logger;
import com.framework.common.CMMConstants;

/**
 * @author TCS
 */
public class DateUtils {
	
	private static final Logger LOG = Logger.getLogger(DateUtils.class);
	
	private DateUtils() {
	
	}
	
	/**
	 * @param date
	 * @return
	 */
	public static Date getStartTime(Date date) {
	
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.set(Calendar.AM_PM, Calendar.AM);
		cal.set(Calendar.HOUR, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
		return cal.getTime();
	}
	
	/**
	 * @param date
	 * @return
	 */
	public static Date getEndTime(Date date) {
	
		Calendar cal = Calendar.getInstance();
		cal.setTime(getStartTime(date));
		cal.add(Calendar.DATE, 1);
		return cal.getTime();
	}
	
	/**
	 * @param sDate
	 * @return
	 * @throws ParseException
	 */
	public static Date parseDate(String sDate) throws ParseException {
	
		for (String pattern : CMMConstants.Framework.DATE_FORMAT_PATTERNS) {
			SimpleDateFormat dateFormatter = new SimpleDateFormat(pattern);
			try {
				return dateFormatter.parse(sDate);
			} catch (ParseException ex) {
				LOG.error("Date " + sDate + " could not be matched to any of the patterns", ex);
				throw new ParseException("Date " + sDate + " could not be matched to any of the patterns", 0);
			}
		}
		return null;
	}
	
	/**
	 * @param date
	 * @param hour
	 * @return
	 */
	public static Date prepareDateWithHour(Date date, String hour) {
	
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.set(Calendar.AM_PM, Calendar.AM);
		cal.set(Calendar.HOUR, Integer.parseInt(hour));
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
		return cal.getTime();
	}
	
	/**
	 * @param date
	 * @param hour
	 * @return
	 */
	public static Date getDateByHour(Date date, String hour) {
	
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.set(Calendar.AM_PM, Calendar.AM);
		cal.set(Calendar.HOUR, Integer.parseInt(hour));
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
		return cal.getTime();
	}
	
	/**
	 * @param dateMinuend
	 * @param dateSubtrahend
	 * @return
	 */
	public static Long dateDiff(Date dateMinuend, Date dateSubtrahend) {
	
		Calendar calMinuend = Calendar.getInstance();
		calMinuend.setTime(dateMinuend);
		Calendar calSubtrahend = Calendar.getInstance();
		calSubtrahend.setTime(dateSubtrahend);
		return calMinuend.getTimeInMillis() - calSubtrahend.getTimeInMillis();
	}
	
	/**
	 * @param date
	 * @return
	 */
	public static String format(Date date) {
	
		if (date == null) {
			return null;
		}
		SimpleDateFormat dateFormatter = new SimpleDateFormat(CMMConstants.Framework.DATE_INPUT_FORMAT);
		return dateFormatter.format(date);
	}
	
	/**
	 * @param date
	 * @return
	 */
	public static String formatForInput(Date date) {
	
		if (date == null) {
			return null;
		}
		SimpleDateFormat dateFormatter = new SimpleDateFormat(CMMConstants.Framework.DATE_INPUT_FORMAT);
		return dateFormatter.format(date);
	}
	
	/**
	 * @param date
	 * @param days
	 * @return
	 */
	public static Date addDays(Date date, int days) {
	
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.DATE, days);
		return cal.getTime();
	}
	
	/**
	 * @param monthCount
	 * @return
	 */
	public static String getCurrentMonth(int monthCount) {
	
		String month = "";
		switch (monthCount) {
			case 0:
				month = "January";
				break;
			case 1:
				month = "February";
				break;
			case 2:
				month = "March";
				break;
			case 3:
				month = "April";
				break;
			case 4:
				month = "May";
				break;
			case 5:
				month = "June";
				break;
			case 6:
				month = "July";
				break;
			case 7:
				month = "August";
				break;
			case 8:
				month = "September";
				break;
			case 9:
				month = "October";
				break;
			case 10:
				month = "November";
				break;
			case 11:
				month = "December";
				break;
			default:
				break;
		}
		return month;
	}
	
	/**
	 * @param jDate
	 * @return
	 */
	public static Date parsejQueryDate(String jDate) {
	
		SimpleDateFormat formatter = new SimpleDateFormat("dd MMM, yyyy");
		try {
			return formatter.parse(jDate);
		} catch (ParseException e) {
			LOG.error("Error in DateUtils:parsejQueryDate", e);
			return null;
		}
	}
	
	/**
	 * @param jDate
	 * @return
	 */
	public static Date parsejQueryDateTime(String jDate) {
	
		SimpleDateFormat formatter = new SimpleDateFormat("dd MMM, yyyy HH:00");
		try {
			return formatter.parse(jDate);
		} catch (ParseException e) {
			LOG.error("Error in DateUtils:parsejQueryDateTime", e);
			return null;
		}
	}
	
	/**
	 * @param date
	 * @return
	 */
	public static String getjQueryDate(Date date) {
	
		String jDate = "";
		SimpleDateFormat formatter = new SimpleDateFormat("dd MMM, yyyy");
		jDate = formatter.format(date);
		return jDate;
	}
	
	/**
	 * @param date
	 * @return
	 */
	public static String getjQueryDateTime(Date date) {
	
		String jDate = "";
		SimpleDateFormat formatter = new SimpleDateFormat("dd MMM, yyyy HH:00");
		jDate = formatter.format(date);
		return jDate;
	}
	
	public static String getjQueryDateTimeNew(Date date) {
	
		String jDate = "";
		SimpleDateFormat formatter = new SimpleDateFormat("MM-dd-yyyy");
		jDate = formatter.format(date);
		return jDate;
	}
	
	/**
	 * @param date
	 * @return
	 */
	public static String getDateTimefromDate(Date date) {
	
		String dateTime = "";
		SimpleDateFormat formatter = new SimpleDateFormat("dd MMM, yyyy h:m:s a");
		dateTime = formatter.format(date);
		return dateTime;
	}
	
	public static String getStringfromDateTime(Date date) {
	
		java.text.SimpleDateFormat formatter = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return formatter.format(date);
	}
	
	public static String getStringfromDate(Date date) {
	
		String dateTime = "";
		java.text.SimpleDateFormat formatter = new java.text.SimpleDateFormat("yyyy-MM-dd");
		dateTime = formatter.format(date);
		return dateTime;
	}
	
	public static Date getDateTimefromString(String date) {
	
		java.text.SimpleDateFormat formatter = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			return formatter.parse(date);
		} catch (ParseException e) {
			LOG.error("Error in DateUtils:getDateTimefromString", e);
			return null;
		}
	}
}
