package com.framework.to;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class SoftwareconfigTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5949724180642811856L;
	private String version;
	private SoftwareTO software;
	private Long hardwareId;
	private String patch;
	private Date effectiveDate;
	private String location;
	private String effectiveRelease;
	private String remark;
	private String status = null;
	private Long statusId = null;
	private Date createdByDate;
	private Date modifiedbyDate;
	private Long deviceId;
	private Set<SoftwareTemplatePropertyTO> softwareTemplatePropertyTO = new HashSet<SoftwareTemplatePropertyTO>(0);
	private String targetLocationLinux;
	private String targetLocationWindows;
	private String targetFlag;
	private String installerLocationLinux;
	private String installerLocationWindows;
	private String parameters = null;
	List<ZabbixSoftwareMappingTO> zabbixTemplatesList = new ArrayList<ZabbixSoftwareMappingTO>(0);
	List<Long> templates = new ArrayList<>();
	
	public SoftwareconfigTO() {
	
		/* No implementation required at the moment. Method for future use. */
	}
	
	public SoftwareconfigTO(SoftwareTO software, Date effectiveDate, String effectiveRelease) {
	
		this.software = software;
		this.effectiveDate = effectiveDate;
		this.effectiveRelease = effectiveRelease;
	}
	
	public SoftwareconfigTO(SoftwareTO software, String patch, Date effectiveDate, String location, String effectiveRelease, String remark) {
	
		this.software = software;
		this.patch = patch;
		this.effectiveDate = effectiveDate;
		this.location = location;
		this.effectiveRelease = effectiveRelease;
		this.remark = remark;
	}
	
	public Date getCreatedByDate() {
	
		return createdByDate;
	}
	
	public Long getDeviceId() {
	
		return deviceId;
	}
	
	public Date getEffectiveDate() {
	
		return this.effectiveDate;
	}
	
	public String getEffectiveRelease() {
	
		return this.effectiveRelease;
	}
	
	public Long getHardwareId() {
	
		return hardwareId;
	}
	
	public String getInstallerLocationLinux() {
	
		return installerLocationLinux;
	}
	
	public String getInstallerLocationWindows() {
	
		return installerLocationWindows;
	}
	
	public String getLocation() {
	
		return this.location;
	}
	
	public Date getModifiedbyDate() {
	
		return modifiedbyDate;
	}
	
	public String getParameters() {
	
		return parameters;
	}
	
	public String getPatch() {
	
		return this.patch;
	}
	
	public String getRemark() {
	
		return this.remark;
	}
	
	public SoftwareTO getSoftware() {
	
		return this.software;
	}
	
	public Set<SoftwareTemplatePropertyTO> getSoftwareTemplatePropertyTO() {
	
		return softwareTemplatePropertyTO;
	}
	
	public String getStatus() {
	
		return status;
	}
	
	public Long getStatusId() {
	
		return statusId;
	}
	
	public String getTargetFlag() {
	
		return targetFlag;
	}
	
	public String getTargetLocationLinux() {
	
		return targetLocationLinux;
	}
	
	public String getTargetLocationWindows() {
	
		return targetLocationWindows;
	}
	
	public List<Long> getTemplates() {
	
		return templates;
	}
	
	public String getVersion() {
	
		return this.version;
	}
	
	public List<ZabbixSoftwareMappingTO> getZabbixTemplatesList() {
	
		return zabbixTemplatesList;
	}
	
	public void setCreatedByDate(Date createdByDate) {
	
		this.createdByDate = createdByDate;
	}
	
	public void setDeviceId(Long deviceId) {
	
		this.deviceId = deviceId;
	}
	
	public void setEffectiveDate(Date effectiveDate) {
	
		this.effectiveDate = effectiveDate;
	}
	
	public void setEffectiveRelease(String effectiveRelease) {
	
		this.effectiveRelease = effectiveRelease;
	}
	
	public void setHardwareId(Long hardwareId) {
	
		this.hardwareId = hardwareId;
	}
	
	public void setInstallerLocationLinux(String installerLocationLinux) {
	
		this.installerLocationLinux = installerLocationLinux;
	}
	
	public void setInstallerLocationWindows(String installerLocationWindows) {
	
		this.installerLocationWindows = installerLocationWindows;
	}
	
	public void setLocation(String location) {
	
		this.location = location;
	}
	
	public void setModifiedbyDate(Date modifiedbyDate) {
	
		this.modifiedbyDate = modifiedbyDate;
	}
	
	public void setParameters(String parameters) {
	
		this.parameters = parameters;
	}
	
	public void setPatch(String patch) {
	
		this.patch = patch;
	}
	
	public void setRemark(String remark) {
	
		this.remark = remark;
	}
	
	public void setSoftware(SoftwareTO software) {
	
		this.software = software;
	}
	
	public void setSoftwareTemplatePropertyTO(Set<SoftwareTemplatePropertyTO> softwareTemplatePropertyTO) {
	
		this.softwareTemplatePropertyTO = softwareTemplatePropertyTO;
	}
	
	public void setStatus(String status) {
	
		this.status = status;
	}
	
	public void setStatusId(Long statusId) {
	
		this.statusId = statusId;
	}
	
	public void setTargetFlag(String targetFlag) {
	
		this.targetFlag = targetFlag;
	}
	
	public void setTargetLocationLinux(String targetLocationLinux) {
	
		this.targetLocationLinux = targetLocationLinux;
	}
	
	public void setTargetLocationWindows(String targetLocationWindows) {
	
		this.targetLocationWindows = targetLocationWindows;
	}
	
	public void setTemplates(List<Long> templates) {
	
		this.templates = templates;
	}
	
	public void setVersion(String version) {
	
		this.version = version;
	}
	
	public void setZabbixTemplatesList(List<ZabbixSoftwareMappingTO> zabbixTemplatesList) {
	
		this.zabbixTemplatesList = zabbixTemplatesList;
	}
}
