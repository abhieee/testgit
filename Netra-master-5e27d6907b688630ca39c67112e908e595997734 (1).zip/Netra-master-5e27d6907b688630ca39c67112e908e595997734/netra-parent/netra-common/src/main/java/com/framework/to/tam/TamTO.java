package com.framework.to.tam;

import com.framework.to.NamedEntityTO;

public class TamTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String serverUrl;
	private String username;
	private String password;
	private String domain;
	private String selectedWorkspaceName;
	private String selectedReleaseName;
	private String selectedPhaseName;
	private String selectedTestCycleName;
	private String selectedTestSuiteName;
	
	public String getDomain() {
	
		return domain;
	}
	
	public String getPassword() {
	
		return password;
	}
	
	public String getSelectedPhaseName() {
	
		return selectedPhaseName;
	}
	
	public String getSelectedReleaseName() {
	
		return selectedReleaseName;
	}
	
	public String getSelectedTestCycleName() {
	
		return selectedTestCycleName;
	}
	
	public String getSelectedTestSuiteName() {
	
		return selectedTestSuiteName;
	}
	
	public String getSelectedWorkspaceName() {
	
		return selectedWorkspaceName;
	}
	
	public String getServerUrl() {
	
		return serverUrl;
	}
	
	public String getUsername() {
	
		return username;
	}
	
	public void setDomain(String domain) {
	
		this.domain = domain;
	}
	
	public void setPassword(String password) {
	
		this.password = password;
	}
	
	public void setSelectedPhaseName(String selectedPhaseName) {
	
		this.selectedPhaseName = selectedPhaseName;
	}
	
	public void setSelectedReleaseName(String selectedReleaseName) {
	
		this.selectedReleaseName = selectedReleaseName;
	}
	
	public void setSelectedTestCycleName(String selectedTestCycleName) {
	
		this.selectedTestCycleName = selectedTestCycleName;
	}
	
	public void setSelectedTestSuiteName(String selectedTestSuiteName) {
	
		this.selectedTestSuiteName = selectedTestSuiteName;
	}
	
	public void setSelectedWorkspaceName(String selectedWorkspaceName) {
	
		this.selectedWorkspaceName = selectedWorkspaceName;
	}
	
	public void setServerUrl(String serverUrl) {
	
		this.serverUrl = serverUrl;
	}
	
	public void setUsername(String username) {
	
		this.username = username;
	}
}
