package com.framework.to;

import java.io.Serializable;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @author TCS
 */
public class BusinessUnitTO extends NamedEntityTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4866783538928441209L;
	private Long status;
	private long clientId;
	private String remark;
	private Long selectedStatus;
	private StatusTO statusTO;
	private int tableSize;
	private long searchCount;
	private int firstResult = 1;
	private long pageNumber;
	private Set<ApplicationTO> application = new HashSet<ApplicationTO>(0);
	private Set<ApplicationTO> applicationTO = new HashSet<ApplicationTO>();
	private Set<WorkflowCurrentTO> workflowCurrentTO = new HashSet<WorkflowCurrentTO>();
	private Set<ProjectsTO> projects = new HashSet<ProjectsTO>();
	private Set<MailSetupMappingTO> mailSetupMappingTO = new HashSet<MailSetupMappingTO>();
	private List<Long> clientList;
	
	public void copy(PlatformTO hardwareTO) {
	
		if (hardwareTO == null) {
			hardwareTO = new PlatformTO();
		}
		if ((hardwareTO.getName() == null) || !hardwareTO.getName().equals(this.getName())) {
			hardwareTO.setName(this.getName());
		}
	}
	
	public Set<ApplicationTO> getApplication() {
	
		return application;
	}
	
	public Set<ApplicationTO> getApplicationTO() {
	
		return applicationTO;
	}
	
	public long getClientId() {
	
		return clientId;
	}
	
	public int getFirstResult() {
	
		return firstResult;
	}
	
	public Set<MailSetupMappingTO> getMailSetupMappingTO() {
	
		return mailSetupMappingTO;
	}
	
	public long getPageNumber() {
	
		return pageNumber;
	}
	
	public Set<ProjectsTO> getProjects() {
	
		return projects;
	}
	
	public String getRemark() {
	
		return remark;
	}
	
	public long getSearchCount() {
	
		return searchCount;
	}
	
	public Long getSelectedStatus() {
	
		return selectedStatus;
	}
	
	public Long getStatus() {
	
		return status;
	}
	
	public StatusTO getStatusTO() {
	
		return statusTO;
	}
	
	public int getTableSize() {
	
		return tableSize;
	}
	
	public Set<WorkflowCurrentTO> getWorkflowCurrentTO() {
	
		return workflowCurrentTO;
	}
	
	public void setApplication(Set<ApplicationTO> application) {
	
		this.application = application;
	}
	
	public void setApplicationTO(Set<ApplicationTO> applicationTO) {
	
		this.applicationTO = applicationTO;
	}
	
	public void setClientId(long clientId) {
	
		this.clientId = clientId;
	}
	
	public void setFirstResult(int firstResult) {
	
		this.firstResult = firstResult;
	}
	
	public void setMailSetupMappingTO(Set<MailSetupMappingTO> mailSetupMappingTO) {
	
		this.mailSetupMappingTO = mailSetupMappingTO;
	}
	
	public void setPageNumber(long pageNumber) {
	
		this.pageNumber = pageNumber;
	}
	
	public void setProjects(Set<ProjectsTO> projects) {
	
		this.projects = projects;
	}
	
	public void setRemark(String remark) {
	
		this.remark = remark;
	}
	
	public void setSearchCount(long searchCount) {
	
		this.searchCount = searchCount;
	}
	
	public void setSelectedStatus(Long selectedStatus) {
	
		this.selectedStatus = selectedStatus;
	}
	
	public void setStatus(Long status) {
	
		this.status = status;
	}
	
	public void setStatusTO(StatusTO statusTO) {
	
		this.statusTO = statusTO;
	}
	
	public void setTableSize(int tableSize) {
	
		this.tableSize = tableSize;
	}
	
	public void setWorkflowCurrentTO(Set<WorkflowCurrentTO> workflowCurrentTO) {
	
		this.workflowCurrentTO = workflowCurrentTO;
	}
	
	public List<Long> getClientList() {
	
		return clientList;
	}
	
	public void setClientList(List<Long> clientList) {
	
		this.clientList = clientList;
	}
}
