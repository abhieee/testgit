package com.framework.to;

public class TestingToolTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1704248693123919567L;
	private String description;
	private String tamAdapterLocation;
	private String tamAdapterFolderName;
	private String tamStartFileName;
	
	public String getDescription() {
	
		return description;
	}
	
	/**
	 * @return the tamAdapterFolderName
	 */
	public String getTamAdapterFolderName() {
	
		return tamAdapterFolderName;
	}
	
	/**
	 * @return the tamAdapterLocation
	 */
	public String getTamAdapterLocation() {
	
		return tamAdapterLocation;
	}
	
	/**
	 * @return the tamStartFileName
	 */
	public String getTamStartFileName() {
	
		return tamStartFileName;
	}
	
	public void setDescription(String description) {
	
		this.description = description;
	}
	
	/**
	 * @param tamAdapterFolderName
	 *                the tamAdapterFolderName to set
	 */
	public void setTamAdapterFolderName(String tamAdapterFolderName) {
	
		this.tamAdapterFolderName = tamAdapterFolderName;
	}
	
	/**
	 * @param tamAdapterLocation
	 *                the tamAdapterLocation to set
	 */
	public void setTamAdapterLocation(String tamAdapterLocation) {
	
		this.tamAdapterLocation = tamAdapterLocation;
	}
	
	/**
	 * @param tamStartFileName
	 *                the tamStartFileName to set
	 */
	public void setTamStartFileName(String tamStartFileName) {
	
		this.tamStartFileName = tamStartFileName;
	}
}
