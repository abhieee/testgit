package com.framework.to;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ApplicationProfileTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7997251010147483198L;
	private Long applicationId;
	private Long status;
	private Long profileStatus;
	private StatusTO statusTO;
	private Long selectedStatus = null;
	private List<StatusTO> statusList = new ArrayList<StatusTO>(0);
	private String statusDesc;
	private Set<ApplicationProfileDockerTO> applicationProfileDocker = new HashSet<ApplicationProfileDockerTO>(0);
	private Set<EnvironmentDockerTO> environmentDockerTO = new HashSet<EnvironmentDockerTO>(0);
	private Set<ApplicationProfileDetailsTO> profileDetails = new HashSet<ApplicationProfileDetailsTO>(0);
	private Set<ReservationTO> reservationses = new HashSet<ReservationTO>(0);
	private List<ApplicationTO> allApplications = new ArrayList<ApplicationTO>();
	private List<ApplicationProfileTO> profileList = new ArrayList<ApplicationProfileTO>();
	private Set<WorkflowCurrentTO> workflowCurrentTO = new HashSet<WorkflowCurrentTO>();
	private Long selectedApplication = null;
	private String applicationName;
	private ApplicationTO applicationTO = new ApplicationTO();
	private Date createdByDate;
	private Date modifiedbyDate;
	private String project;
	private String businessUnit;
	private Set<ApplicationProfileDetailsAWSTO> applicationProfileDetailsAws = new HashSet<ApplicationProfileDetailsAWSTO>(0);
	private TestingPhaseTO testingPhaseTO;
	private String profileName;
	private Long awsAccountId;
	private List<MachineTypeTO> machineTypeList = new ArrayList<MachineTypeTO>(0);
	private List<TemplatesAwsTO> templatesAwsList = new ArrayList<TemplatesAwsTO>(0);
	private String[] selectedApplicationsList;
	private List<ApplicationTO> allApplicationsList = new ArrayList<ApplicationTO>(0);
	private List<ApplicationTO> selectedAppList = new ArrayList<ApplicationTO>(0);
	private String monitoringRequired;
	private long pageNumber = 1;
	private long searchCount = 0;
	private int firstResult = 0;
	private int tableSize = 10;
	private List<ApplicationProfilesServerSetTO> machineSet = new ArrayList<ApplicationProfilesServerSetTO>(0);
	private Long profileId;
	private Date fromDate;
	private Date toDate;
	private Long clientId;
	private Long projectId;
	private Set<ApplicationProfileMappingTO> applicationProfileMapping = new HashSet<ApplicationProfileMappingTO>(0);
	private List<Long> definedApplications = new ArrayList<Long>(0);
	private String label;
	private String value;
	
	public List<ApplicationTO> getAllApplications() {
	
		return allApplications;
	}
	
	public List<ApplicationTO> getAllApplicationsList() {
	
		return allApplicationsList;
	}
	
	public Long getApplicationId() {
	
		return applicationId;
	}
	
	public String getApplicationName() {
	
		return applicationName;
	}
	
	public Set<ApplicationProfileDetailsAWSTO> getApplicationProfileDetailsAws() {
	
		return applicationProfileDetailsAws;
	}
	
	public Set<ApplicationProfileDockerTO> getApplicationProfileDocker() {
	
		return applicationProfileDocker;
	}
	
	public Set<ApplicationProfileMappingTO> getApplicationProfileMapping() {
	
		return applicationProfileMapping;
	}
	
	public ApplicationTO getApplicationTO() {
	
		return applicationTO;
	}
	
	public Long getAwsAccountId() {
	
		return awsAccountId;
	}
	
	public String getBusinessUnit() {
	
		return businessUnit;
	}
	
	public Long getClientId() {
	
		return clientId;
	}
	
	public Date getCreatedByDate() {
	
		return createdByDate;
	}
	
	public List<Long> getDefinedApplications() {
	
		return definedApplications;
	}
	
	public Set<EnvironmentDockerTO> getEnvironmentDockerTO() {
	
		return environmentDockerTO;
	}
	
	public int getFirstResult() {
	
		return firstResult;
	}
	
	public Date getFromDate() {
	
		return fromDate;
	}
	
	public String getLabel() {
	
		return label;
	}
	
	public List<ApplicationProfilesServerSetTO> getMachineSet() {
	
		return machineSet;
	}
	
	public List<MachineTypeTO> getMachineTypeList() {
	
		return machineTypeList;
	}
	
	public Date getModifiedbyDate() {
	
		return modifiedbyDate;
	}
	
	/**
	 * @return the monitoringRequired
	 */
	public String getMonitoringRequired() {
	
		return monitoringRequired;
	}
	
	public long getPageNumber() {
	
		return pageNumber;
	}
	
	public Set<ApplicationProfileDetailsTO> getProfileDetails() {
	
		return profileDetails;
	}
	
	public Long getProfileId() {
	
		return profileId;
	}
	
	public List<ApplicationProfileTO> getProfileList() {
	
		return profileList;
	}
	
	public String getProfileName() {
	
		return profileName;
	}
	
	public Long getProfileStatus() {
	
		return profileStatus;
	}
	
	public String getProject() {
	
		return project;
	}
	
	public Long getProjectId() {
	
		return projectId;
	}
	
	public Set<ReservationTO> getReservationses() {
	
		return reservationses;
	}
	
	public long getSearchCount() {
	
		return searchCount;
	}
	
	public Long getSelectedApplication() {
	
		return selectedApplication;
	}
	
	public String[] getSelectedApplicationsList() {
	
		return selectedApplicationsList;
	}
	
	public List<ApplicationTO> getSelectedAppList() {
	
		return selectedAppList;
	}
	
	public Long getSelectedStatus() {
	
		return selectedStatus;
	}
	
	public Long getStatus() {
	
		return status;
	}
	
	public String getStatusDesc() {
	
		return statusDesc;
	}
	
	public List<StatusTO> getStatusList() {
	
		return statusList;
	}
	
	public StatusTO getStatusTO() {
	
		return statusTO;
	}
	
	public int getTableSize() {
	
		return tableSize;
	}
	
	public List<TemplatesAwsTO> getTemplatesAwsList() {
	
		return templatesAwsList;
	}
	
	public TestingPhaseTO getTestingPhaseTO() {
	
		return testingPhaseTO;
	}
	
	public Date getToDate() {
	
		return toDate;
	}
	
	public String getValue() {
	
		return value;
	}
	
	public Set<WorkflowCurrentTO> getWorkflowCurrentTO() {
	
		return workflowCurrentTO;
	}
	
	public void setAllApplications(List<ApplicationTO> allApplications) {
	
		this.allApplications = allApplications;
	}
	
	public void setAllApplicationsList(List<ApplicationTO> allApplicationsList) {
	
		this.allApplicationsList = allApplicationsList;
	}
	
	public void setApplicationId(Long applicationId) {
	
		this.applicationId = applicationId;
	}
	
	public void setApplicationName(String applicationName) {
	
		this.applicationName = applicationName;
	}
	
	public void setApplicationProfileDetailsAws(Set<ApplicationProfileDetailsAWSTO> applicationProfileDetailsAws) {
	
		this.applicationProfileDetailsAws = applicationProfileDetailsAws;
	}
	
	public void setApplicationProfileDocker(Set<ApplicationProfileDockerTO> applicationProfileDocker) {
	
		this.applicationProfileDocker = applicationProfileDocker;
	}
	
	public void setApplicationProfileMapping(Set<ApplicationProfileMappingTO> applicationProfileMapping) {
	
		this.applicationProfileMapping = applicationProfileMapping;
	}
	
	public void setApplicationTO(ApplicationTO applicationTO) {
	
		this.applicationTO = applicationTO;
	}
	
	public void setAwsAccountId(Long awsAccountId) {
	
		this.awsAccountId = awsAccountId;
	}
	
	public void setBusinessUnit(String businessUnit) {
	
		this.businessUnit = businessUnit;
	}
	
	public void setClientId(Long clientId) {
	
		this.clientId = clientId;
	}
	
	public void setCreatedByDate(Date createdByDate) {
	
		this.createdByDate = createdByDate;
	}
	
	public void setDefinedApplications(List<Long> definedApplications) {
	
		this.definedApplications = definedApplications;
	}
	
	public void setEnvironmentDockerTO(Set<EnvironmentDockerTO> environmentDockerTO) {
	
		this.environmentDockerTO = environmentDockerTO;
	}
	
	public void setFirstResult(int firstResult) {
	
		this.firstResult = firstResult;
	}
	
	public void setFromDate(Date fromDate) {
	
		this.fromDate = fromDate;
	}
	
	public void setLabel(String label) {
	
		this.label = label;
	}
	
	public void setMachineSet(List<ApplicationProfilesServerSetTO> machineSet) {
	
		this.machineSet = machineSet;
	}
	
	public void setMachineTypeList(List<MachineTypeTO> machineTypeList) {
	
		this.machineTypeList = machineTypeList;
	}
	
	public void setModifiedbyDate(Date modifiedbyDate) {
	
		this.modifiedbyDate = modifiedbyDate;
	}
	
	/**
	 * @param monitoringRequired
	 *                the monitoringRequired to set
	 */
	public void setMonitoringRequired(String monitoringRequired) {
	
		this.monitoringRequired = monitoringRequired;
	}
	
	public void setPageNumber(long pageNumber) {
	
		this.pageNumber = pageNumber;
	}
	
	public void setProfileDetails(Set<ApplicationProfileDetailsTO> profileDetails) {
	
		this.profileDetails = profileDetails;
	}
	
	public void setProfileId(Long profileId) {
	
		this.profileId = profileId;
	}
	
	public void setProfileList(List<ApplicationProfileTO> profileList) {
	
		this.profileList = profileList;
	}
	
	public void setProfileName(String profileName) {
	
		this.profileName = profileName;
	}
	
	public void setProfileStatus(Long profileStatus) {
	
		this.profileStatus = profileStatus;
	}
	
	public void setProject(String project) {
	
		this.project = project;
	}
	
	public void setProjectId(Long projectId) {
	
		this.projectId = projectId;
	}
	
	public void setReservationses(Set<ReservationTO> reservationses) {
	
		this.reservationses = reservationses;
	}
	
	public void setSearchCount(long searchCount) {
	
		this.searchCount = searchCount;
	}
	
	public void setSelectedApplication(Long selectedApplication) {
	
		this.selectedApplication = selectedApplication;
	}
	
	public void setSelectedApplicationsList(String[] applicationsList) {
	
		if (applicationsList == null) {
			this.selectedApplicationsList = new String[0];
		} else {
			this.selectedApplicationsList = Arrays.copyOf(applicationsList, applicationsList.length);
		}
	}
	
	public void setSelectedAppList(List<ApplicationTO> selectedAppList) {
	
		this.selectedAppList = selectedAppList;
	}
	
	public void setSelectedStatus(Long selectedStatus) {
	
		this.selectedStatus = selectedStatus;
	}
	
	public void setStatus(Long status) {
	
		this.status = status;
	}
	
	public void setStatusDesc(String statusDesc) {
	
		this.statusDesc = statusDesc;
	}
	
	public void setStatusList(List<StatusTO> statusList) {
	
		this.statusList = statusList;
	}
	
	public void setStatusTO(StatusTO statusTO) {
	
		this.statusTO = statusTO;
	}
	
	public void setTableSize(int tableSize) {
	
		this.tableSize = tableSize;
	}
	
	public void setTemplatesAwsList(List<TemplatesAwsTO> templatesAwsList) {
	
		this.templatesAwsList = templatesAwsList;
	}
	
	public void setTestingPhaseTO(TestingPhaseTO testingPhaseTO) {
	
		this.testingPhaseTO = testingPhaseTO;
	}
	
	public void setToDate(Date toDate) {
	
		this.toDate = toDate;
	}
	
	public void setValue(String value) {
	
		this.value = value;
	}
	
	public void setWorkflowCurrentTO(Set<WorkflowCurrentTO> workflowCurrentTO) {
	
		this.workflowCurrentTO = workflowCurrentTO;
	}
}
