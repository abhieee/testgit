package com.framework.to;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * This class declares the transfer object that carries user information across the application.
 *
 * @author TCS
 */
public class Software_InvTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3909026183992481263L;
	private long mapId;
	private String type;
	private String manufacturer;
	private Long applicationProfileDetailId;
	private String model;
	private Date createdByDate;
	private Date modifiedbyDate;
	private String version = null;
	private String patch = null;
	private Date effectiveDate = null;
	private String location = null;
	private String effectiveRelease = null;
	private String remark = null;
	private Long softwareconfigsId;
	private String status = null;
	private Set<ActivitySoftwareMappingTO> activitySoftwareMappingTO = new HashSet<ActivitySoftwareMappingTO>(0);
	private String installRequired;
	
	public Software_InvTO() {
	
		/* No implementation required at the moment. Method for future use. */
	}
	
	public void copy(Software_InvTO softwareTO) {
	
		if (softwareTO == null) {
			softwareTO = new Software_InvTO();
		}
		if ((softwareTO.getName() == null) || !softwareTO.getName().equals(this.getName())) {
			softwareTO.setName(this.getName());
		}
		if ((softwareTO.getType() == null) || !softwareTO.getType().equals(this.getType())) {
			softwareTO.setType(this.getType());
		}
		if ((softwareTO.getManufacturer() == null) || !softwareTO.getManufacturer().equals(this.getManufacturer())) {
			softwareTO.setManufacturer(this.getManufacturer());
		}
		if ((softwareTO.getModel() == null) || !softwareTO.getModel().equals(this.getModel())) {
			softwareTO.setModel(this.getModel());
		}
	}
	
	public Set<ActivitySoftwareMappingTO> getActivitySoftwareMappingTO() {
	
		return activitySoftwareMappingTO;
	}
	
	public Long getApplicationProfileDetailId() {
	
		return applicationProfileDetailId;
	}
	
	public Date getCreatedByDate() {
	
		return createdByDate;
	}
	
	public Date getEffectiveDate() {
	
		return effectiveDate;
	}
	
	public String getEffectiveRelease() {
	
		return effectiveRelease;
	}
	
	/**
	 * @return the installRequired
	 */
	public String getInstallRequired() {
	
		return installRequired;
	}
	
	public String getLocation() {
	
		return location;
	}
	
	public String getManufacturer() {
	
		return this.manufacturer;
	}
	
	public long getMapId() {
	
		return mapId;
	}
	
	public String getModel() {
	
		return this.model;
	}
	
	public Date getModifiedbyDate() {
	
		return modifiedbyDate;
	}
	
	public String getPatch() {
	
		return patch;
	}
	
	public String getRemark() {
	
		return remark;
	}
	
	public Long getSoftwareconfigsId() {
	
		return softwareconfigsId;
	}
	
	public String getStatus() {
	
		return status;
	}
	
	public String getType() {
	
		return this.type;
	}
	
	public String getVersion() {
	
		return version;
	}
	
	public void setActivitySoftwareMappingTO(Set<ActivitySoftwareMappingTO> activitySoftwareMappingTO) {
	
		this.activitySoftwareMappingTO = activitySoftwareMappingTO;
	}
	
	public void setApplicationProfileDetailId(Long applicationProfileDetailId) {
	
		this.applicationProfileDetailId = applicationProfileDetailId;
	}
	
	public void setCreatedByDate(Date createdByDate) {
	
		this.createdByDate = createdByDate;
	}
	
	public void setEffectiveDate(Date effectiveDate) {
	
		this.effectiveDate = effectiveDate;
	}
	
	public void setEffectiveRelease(String effectiveRelease) {
	
		this.effectiveRelease = effectiveRelease;
	}
	
	/**
	 * @param installRequired
	 *                the installRequired to set
	 */
	public void setInstallRequired(String installRequired) {
	
		this.installRequired = installRequired;
	}
	
	public void setLocation(String location) {
	
		this.location = location;
	}
	
	public void setManufacturer(String manufacturer) {
	
		this.manufacturer = manufacturer;
	}
	
	public void setMapId(long mapId) {
	
		this.mapId = mapId;
	}
	
	public void setModel(String model) {
	
		this.model = model;
	}
	
	public void setModifiedbyDate(Date modifiedbyDate) {
	
		this.modifiedbyDate = modifiedbyDate;
	}
	
	public void setPatch(String patch) {
	
		this.patch = patch;
	}
	
	public void setRemark(String remark) {
	
		this.remark = remark;
	}
	
	public void setSoftwareconfigsId(Long softwareconfigsId) {
	
		this.softwareconfigsId = softwareconfigsId;
	}
	
	public void setStatus(String status) {
	
		this.status = status;
	}
	
	public void setType(String type) {
	
		this.type = type;
	}
	
	public void setVersion(String version) {
	
		this.version = version;
	}
}
