package com.framework.to;

import java.io.Serializable;

public class TemplatesAwsTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5718759869680894401L;
	private Long id;
	private Long awsAccountId;
	private TemplatesTO template;
	private String imageId;
	private String imageType;
	private String state;
	private String virtualizationType;
	private String location;
	private String ownerId;
	private String imageOwnerAlias;
	
	public TemplatesAwsTO() {
	
		/* No implementation required at the moment. Method for future use. */
	}
	
	public Long getAwsAccountId() {
	
		return awsAccountId;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public String getImageId() {
	
		return imageId;
	}
	
	public String getImageOwnerAlias() {
	
		return imageOwnerAlias;
	}
	
	public String getImageType() {
	
		return imageType;
	}
	
	public String getLocation() {
	
		return location;
	}
	
	public String getOwnerId() {
	
		return ownerId;
	}
	
	public String getState() {
	
		return state;
	}
	
	public TemplatesTO getTemplate() {
	
		return template;
	}
	
	public String getVirtualizationType() {
	
		return virtualizationType;
	}
	
	public void setAwsAccountId(Long awsAccountId) {
	
		this.awsAccountId = awsAccountId;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setImageId(String imageId) {
	
		this.imageId = imageId;
	}
	
	public void setImageOwnerAlias(String imageOwnerAlias) {
	
		this.imageOwnerAlias = imageOwnerAlias;
	}
	
	public void setImageType(String imageType) {
	
		this.imageType = imageType;
	}
	
	public void setLocation(String location) {
	
		this.location = location;
	}
	
	public void setOwnerId(String ownerId) {
	
		this.ownerId = ownerId;
	}
	
	public void setState(String state) {
	
		this.state = state;
	}
	
	public void setTemplate(TemplatesTO template) {
	
		this.template = template;
	}
	
	public void setVirtualizationType(String virtualizationType) {
	
		this.virtualizationType = virtualizationType;
	}
}
