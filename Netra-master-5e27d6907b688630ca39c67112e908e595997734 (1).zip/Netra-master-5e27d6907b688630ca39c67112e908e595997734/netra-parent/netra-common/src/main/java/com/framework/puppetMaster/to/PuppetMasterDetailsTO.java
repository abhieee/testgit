package com.framework.puppetMaster.to;

import java.io.Serializable;

public class PuppetMasterDetailsTO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private Long id;
	private String username;
	private String password;
	private String ipaddr;
	private String hostname;
	private String domainName;
	private String status;
	private String processpath;
	private long searchCount;
	private int firstResult = 1;
	private int tableSize;
	
	/**
	 * @return the domainName
	 */
	public String getDomainName() {
	
		return domainName;
	}
	
	/**
	 * @return the firstResult
	 */
	public int getFirstResult() {
	
		return firstResult;
	}
	
	/**
	 * @return the hostname
	 */
	public String getHostname() {
	
		return hostname;
	}
	
	/**
	 * @return the id
	 */
	public Long getId() {
	
		return id;
	}
	
	/**
	 * @return the ipaddr
	 */
	public String getIpaddr() {
	
		return ipaddr;
	}
	
	/**
	 * @return the password
	 */
	public String getPassword() {
	
		return password;
	}
	
	/**
	 * @return the processpath
	 */
	public String getProcesspath() {
	
		return processpath;
	}
	
	/**
	 * @return the searchCount
	 */
	public long getSearchCount() {
	
		return searchCount;
	}
	
	/**
	 * @return the status
	 */
	public String getStatus() {
	
		return status;
	}
	
	/**
	 * @return the tableSize
	 */
	public int getTableSize() {
	
		return tableSize;
	}
	
	/**
	 * @return the username
	 */
	public String getUsername() {
	
		return username;
	}
	
	/**
	 * @param domainName
	 *                the domainName to set
	 */
	public void setDomainName(String domainName) {
	
		this.domainName = domainName;
	}
	
	/**
	 * @param firstResult
	 *                the firstResult to set
	 */
	public void setFirstResult(int firstResult) {
	
		this.firstResult = firstResult;
	}
	
	/**
	 * @param hostname
	 *                the hostname to set
	 */
	public void setHostname(String hostname) {
	
		this.hostname = hostname;
	}
	
	/**
	 * @param id
	 *                the id to set
	 */
	public void setId(Long id) {
	
		this.id = id;
	}
	
	/**
	 * @param ipaddr
	 *                the ipaddr to set
	 */
	public void setIpaddr(String ipaddr) {
	
		this.ipaddr = ipaddr;
	}
	
	/**
	 * @param password
	 *                the password to set
	 */
	public void setPassword(String password) {
	
		this.password = password;
	}
	
	/**
	 * @param processpath
	 *                the processpath to set
	 */
	public void setProcesspath(String processpath) {
	
		this.processpath = processpath;
	}
	
	/**
	 * @param searchCount
	 *                the searchCount to set
	 */
	public void setSearchCount(long searchCount) {
	
		this.searchCount = searchCount;
	}
	
	/**
	 * @param status
	 *                the status to set
	 */
	public void setStatus(String status) {
	
		this.status = status;
	}
	
	/**
	 * @param tableSize
	 *                the tableSize to set
	 */
	public void setTableSize(int tableSize) {
	
		this.tableSize = tableSize;
	}
	
	/**
	 * @param username
	 *                the username to set
	 */
	public void setUsername(String username) {
	
		this.username = username;
	}
}
