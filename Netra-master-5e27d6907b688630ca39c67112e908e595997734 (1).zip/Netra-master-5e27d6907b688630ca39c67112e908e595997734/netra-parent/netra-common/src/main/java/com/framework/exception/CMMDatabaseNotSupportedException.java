package com.framework.exception;

/**
 * @author TCS
 */
public class CMMDatabaseNotSupportedException extends CMMException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public CMMDatabaseNotSupportedException() {
	
		super();
	}
	
	public CMMDatabaseNotSupportedException(String message) {
	
		super(message);
	}
	
	public CMMDatabaseNotSupportedException(String message, Throwable cause) {
	
		super(message, cause);
	}
	
	public CMMDatabaseNotSupportedException(Throwable cause) {
	
		super(cause);
	}
}
