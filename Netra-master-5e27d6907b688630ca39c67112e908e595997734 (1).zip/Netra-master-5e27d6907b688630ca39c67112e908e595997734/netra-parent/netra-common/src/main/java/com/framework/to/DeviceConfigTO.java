package com.framework.to;

import java.text.ParseException;
import java.util.Date;
import java.util.Set;
import com.framework.utility.DateUtils;

public class DeviceConfigTO extends AbstractTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4507624245430979290L;
	private Long deviceId = null;
	private DeviceTO device = null;
	private String version = null;
	private String patch = null;
	private Date date = null;
	private String location = null;
	private String release = null;
	private Set<STCTO> stcs = null;
	private String remark = null;
	
	public DeviceConfigTO() {
	
		super();
	}
	
	public void copy(DeviceConfigTO deviceConfig) {
	
		this.setDate(deviceConfig.getDate());
		this.setDeviceId(deviceConfig.getDeviceId());
		this.setLocation(deviceConfig.getLocation());
		this.setPatch(deviceConfig.getPatch());
		this.setRelease(deviceConfig.getRelease());
		this.setVersion(deviceConfig.getVersion());
		this.setRemark(deviceConfig.getRemark());
	}
	
	/**
	 * @return the date
	 */
	public Date getDate() {
	
		return date;
	}
	
	/**
	 * @return the device
	 */
	public DeviceTO getDevice() {
	
		return device;
	}
	
	/**
	 * @return the deviceId
	 */
	public Long getDeviceId() {
	
		return deviceId;
	}
	
	/**
	 * @return the location
	 */
	public String getLocation() {
	
		return location;
	}
	
	/**
	 * @return the patch
	 */
	public String getPatch() {
	
		return patch;
	}
	
	/**
	 * @return the release
	 */
	public String getRelease() {
	
		return release;
	}
	
	/**
	 * @return the remark
	 */
	public String getRemark() {
	
		return remark;
	}
	
	/**
	 * @return the stcDetails
	 */
	public String getStcDetails() {
	
		if ((this.getStcs() == null) || this.getStcs().isEmpty()) {
			return "";
		}
		StringBuilder names = new StringBuilder("");
		for (STCTO stc : this.getStcs()) {
			if (names.length() > 0) {
				names.append(", ");
			}
			names.append(stc.getUcbNumber() + "-" + stc.getStcType());
		}
		return names.toString();
	}
	
	/**
	 * @return the stcs
	 */
	public Set<STCTO> getStcs() {
	
		return stcs;
	}
	
	/**
	 * @return the version
	 */
	public String getVersion() {
	
		return version;
	}
	
	/**
	 * @param date
	 *                the date to set
	 */
	public void setDate(Date date) {
	
		this.date = date;
	}
	
	public void setDate(String date) throws ParseException {
	
		if (date == null) {
			this.date = null;
		} else {
			this.date = DateUtils.parseDate(date);
		}
	}
	
	/**
	 * @param device
	 *                the device to set
	 */
	public void setDevice(DeviceTO device) {
	
		this.device = device;
	}
	
	/**
	 * @param deviceId
	 *                the deviceId to set
	 */
	public void setDeviceId(Long deviceId) {
	
		this.deviceId = deviceId;
	}
	
	/**
	 * @param location
	 *                the location to set
	 */
	public void setLocation(String location) {
	
		this.location = location;
	}
	
	/**
	 * @param patch
	 *                the patch to set
	 */
	public void setPatch(String patch) {
	
		this.patch = patch;
	}
	
	/**
	 * @param release
	 *                the release to set
	 */
	public void setRelease(String release) {
	
		this.release = release;
	}
	
	/**
	 * @param remark
	 *                the remark to set
	 */
	public void setRemark(String remark) {
	
		this.remark = remark;
	}
	
	/**
	 * @param stcDetails
	 *                the stcDetails to set
	 */
	public void setStcDetails(String stcDetails) {
	
	}
	
	/**
	 * @param stcs
	 *                the stcs to set
	 */
	public void setStcs(Set<STCTO> stcs) {
	
		this.stcs = stcs;
	}
	
	/**
	 * @param version
	 *                the version to set
	 */
	public void setVersion(String version) {
	
		this.version = version;
	}
}
