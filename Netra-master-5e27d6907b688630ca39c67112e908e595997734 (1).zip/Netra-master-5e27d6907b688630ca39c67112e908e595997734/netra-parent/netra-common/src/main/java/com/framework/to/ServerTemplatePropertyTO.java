package com.framework.to;

import java.io.Serializable;

public class ServerTemplatePropertyTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2801202573199328970L;
	private Long id;
	private Long provision_machine_id;
	private String propertyName;
	private String propertyValue;
	private ProvisionedMachineTO provisionedMachine = new ProvisionedMachineTO();
	
	public Long getId() {
	
		return id;
	}
	
	public String getPropertyName() {
	
		return propertyName;
	}
	
	public String getPropertyValue() {
	
		return propertyValue;
	}
	
	public Long getProvision_machine_id() {
	
		return provision_machine_id;
	}
	
	public ProvisionedMachineTO getProvisionedMachine() {
	
		return provisionedMachine;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setPropertyName(String propertyName) {
	
		this.propertyName = propertyName;
	}
	
	public void setPropertyValue(String propertyValue) {
	
		this.propertyValue = propertyValue;
	}
	
	public void setProvision_machine_id(Long provision_machine_id) {
	
		this.provision_machine_id = provision_machine_id;
	}
	
	public void setProvisionedMachine(ProvisionedMachineTO provisionedMachine) {
	
		this.provisionedMachine = provisionedMachine;
	}
}
