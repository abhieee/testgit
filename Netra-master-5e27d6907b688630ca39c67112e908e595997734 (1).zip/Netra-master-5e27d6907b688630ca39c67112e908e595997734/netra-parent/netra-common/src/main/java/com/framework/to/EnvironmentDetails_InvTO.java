/**
 *
 */
package com.framework.to;

import java.util.ArrayList;
import java.util.List;

/**
 * @author TCS
 */
public class EnvironmentDetails_InvTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -706491635805870269L;
	private Long serverGroup;
	private Long environmentId;
	private ProvisionedMachineTO provisionedMachine;
	private Long provisionedMachineId;
	private Long provisionedPlatformId;
	private Softwareconfig_InvTO softwareConfig = null;
	private List<Long> softwareId = new ArrayList<Long>();
	private String softwares;
	private List<Software_InvTO> softwareList = new ArrayList<Software_InvTO>();
	
	public Long getEnvironmentId() {
	
		return environmentId;
	}
	
	public ProvisionedMachineTO getProvisionedMachine() {
	
		return provisionedMachine;
	}
	
	public Long getProvisionedMachineId() {
	
		return provisionedMachineId;
	}
	
	public Long getProvisionedPlatformId() {
	
		return provisionedPlatformId;
	}
	
	public Long getServerGroup() {
	
		return serverGroup;
	}
	
	public Softwareconfig_InvTO getSoftwareConfig() {
	
		return softwareConfig;
	}
	
	public List<Long> getSoftwareId() {
	
		return softwareId;
	}
	
	public List<Software_InvTO> getSoftwareList() {
	
		return softwareList;
	}
	
	public String getSoftwares() {
	
		return softwares;
	}
	
	public void setEnvironmentId(Long environmentId) {
	
		this.environmentId = environmentId;
	}
	
	public void setProvisionedMachine(ProvisionedMachineTO provisionedMachine) {
	
		this.provisionedMachine = provisionedMachine;
	}
	
	public void setProvisionedMachineId(Long provisionedMachineId) {
	
		this.provisionedMachineId = provisionedMachineId;
	}
	
	public void setProvisionedPlatformId(Long provisionedPlatformId) {
	
		this.provisionedPlatformId = provisionedPlatformId;
	}
	
	public void setServerGroup(Long serverGroup) {
	
		this.serverGroup = serverGroup;
	}
	
	public void setSoftwareConfig(Softwareconfig_InvTO softwareConfig) {
	
		this.softwareConfig = softwareConfig;
	}
	
	public void setSoftwareId(List<Long> softwareId) {
	
		this.softwareId = softwareId;
	}
	
	public void setSoftwareList(List<Software_InvTO> softwareList) {
	
		this.softwareList = softwareList;
	}
	
	public void setSoftwares(String softwares) {
	
		this.softwares = softwares;
	}
}
