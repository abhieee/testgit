/**
 *
 */
package com.framework.to;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @author 460650
 */
public class ProvisionedPlatformTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3343884468185629069L;
	private Long id;
	private String platformTemplateName;
	private String type;
	private String family;
	private String distribution;
	private String version;
	private String pack;
	private String architecture;
	private Long platformTemplateStatus;
	private String provisionedPlatformStatus;
	private Long platformTemplateId;
	Set<ProvisionedMachineTO> provisionedMachine = new HashSet<ProvisionedMachineTO>(0);
	List<ProvisionedTemplatesAwsTO> provisionedMachineAwsList = new ArrayList<ProvisionedTemplatesAwsTO>(0);
	List<ProvisionedPlatformOSTO> provisionedPlatformOSTOList = new ArrayList<ProvisionedPlatformOSTO>(0);
	
	public String getArchitecture() {
	
		return architecture;
	}
	
	public String getDistribution() {
	
		return distribution;
	}
	
	public String getFamily() {
	
		return family;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public String getPack() {
	
		return pack;
	}
	
	public Long getPlatformTemplateId() {
	
		return platformTemplateId;
	}
	
	public String getPlatformTemplateName() {
	
		return platformTemplateName;
	}
	
	public Long getPlatformTemplateStatus() {
	
		return platformTemplateStatus;
	}
	
	public Set<ProvisionedMachineTO> getProvisionedMachine() {
	
		return provisionedMachine;
	}
	
	public List<ProvisionedTemplatesAwsTO> getProvisionedMachineAwsList() {
	
		return provisionedMachineAwsList;
	}
	
	public List<ProvisionedPlatformOSTO> getProvisionedPlatformOSTOList() {
	
		return provisionedPlatformOSTOList;
	}
	
	public String getProvisionedPlatformStatus() {
	
		return provisionedPlatformStatus;
	}
	
	public String getType() {
	
		return type;
	}
	
	public String getVersion() {
	
		return version;
	}
	
	public void setArchitecture(String architecture) {
	
		this.architecture = architecture;
	}
	
	public void setDistribution(String distribution) {
	
		this.distribution = distribution;
	}
	
	public void setFamily(String family) {
	
		this.family = family;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setPack(String pack) {
	
		this.pack = pack;
	}
	
	public void setPlatformTemplateId(Long platformTemplateId) {
	
		this.platformTemplateId = platformTemplateId;
	}
	
	public void setPlatformTemplateName(String platformTemplateName) {
	
		this.platformTemplateName = platformTemplateName;
	}
	
	public void setPlatformTemplateStatus(Long platformTemplateStatus) {
	
		this.platformTemplateStatus = platformTemplateStatus;
	}
	
	public void setProvisionedMachine(Set<ProvisionedMachineTO> provisionedMachine) {
	
		this.provisionedMachine = provisionedMachine;
	}
	
	public void setProvisionedMachineAwsList(List<ProvisionedTemplatesAwsTO> provisionedMachineAwsList) {
	
		this.provisionedMachineAwsList = provisionedMachineAwsList;
	}
	
	public void setProvisionedPlatformOSTOList(List<ProvisionedPlatformOSTO> provisionedPlatformOSTOList) {
	
		this.provisionedPlatformOSTOList = provisionedPlatformOSTOList;
	}
	
	public void setProvisionedPlatformStatus(String provisionedPlatformStatus) {
	
		this.provisionedPlatformStatus = provisionedPlatformStatus;
	}
	
	public void setType(String type) {
	
		this.type = type;
	}
	
	public void setVersion(String version) {
	
		this.version = version;
	}
}
