package com.framework.to;

import java.io.Serializable;
import java.util.List;

public class ServiceClientTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2648666898391422047L;
	private long id;
	private long clientId;
	private long serviceId;
	private ServiceTO serviceTO = new ServiceTO();
	private List<Long> selectedBUs = null;
	private Long roleId;
	
	public long getClientId() {
	
		return clientId;
	}
	
	public long getId() {
	
		return id;
	}
	
	public Long getRoleId() {
	
		return roleId;
	}
	
	public List<Long> getSelectedBUs() {
	
		return selectedBUs;
	}
	
	public long getServiceId() {
	
		return serviceId;
	}
	
	public ServiceTO getServiceTO() {
	
		return serviceTO;
	}
	
	public void setClientId(long clientId) {
	
		this.clientId = clientId;
	}
	
	public void setId(long id) {
	
		this.id = id;
	}
	
	public void setRoleId(Long roleId) {
	
		this.roleId = roleId;
	}
	
	public void setSelectedBUs(List<Long> selectedBUs) {
	
		this.selectedBUs = selectedBUs;
	}
	
	public void setServiceId(long serviceId) {
	
		this.serviceId = serviceId;
	}
	
	public void setServiceTO(ServiceTO serviceTO) {
	
		this.serviceTO = serviceTO;
	}
}
