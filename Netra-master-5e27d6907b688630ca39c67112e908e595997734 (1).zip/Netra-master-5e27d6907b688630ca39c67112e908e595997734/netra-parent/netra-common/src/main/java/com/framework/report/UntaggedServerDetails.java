package com.framework.report;

import java.io.Serializable;

public class UntaggedServerDetails implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String ip;
	private String hostName;
	
	public UntaggedServerDetails() {
	
		/* No implementation required at the moment. Method for future use. */
	}
	
	public String getIp() {
	
		return ip;
	}
	
	public void setIp(String ip) {
	
		this.ip = ip;
	}
	
	public String getHostName() {
	
		return hostName;
	}
	
	public void setHostName(String hostName) {
	
		this.hostName = hostName;
	}
}
