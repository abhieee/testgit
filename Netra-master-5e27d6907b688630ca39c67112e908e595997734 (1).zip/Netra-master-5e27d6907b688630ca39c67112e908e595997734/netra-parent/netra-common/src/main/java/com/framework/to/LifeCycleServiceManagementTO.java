package com.framework.to;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class LifeCycleServiceManagementTO extends AbstractTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2420078448254101839L;
	private Long releasePhaseId;
	private Set<LifeCycleServiceManagementEnvironmentTO> lifeCycleServiceMgmtEnvironment;
	private Set<LifeCycleServiceManagementServiceTO> lifeCycleServiceMgmtService;
	private List<LifeCycleServiceManagementServiceTO> servicesList = new ArrayList<LifeCycleServiceManagementServiceTO>(0);
	
	public LifeCycleServiceManagementTO() {
	
		setLifeCycleServiceMgmtEnvironment(new HashSet<LifeCycleServiceManagementEnvironmentTO>(0));
		setLifeCycleServiceMgmtService(new HashSet<LifeCycleServiceManagementServiceTO>(0));
	}
	
	public Set<LifeCycleServiceManagementEnvironmentTO> getLifeCycleServiceMgmtEnvironment() {
	
		return lifeCycleServiceMgmtEnvironment;
	}
	
	public Set<LifeCycleServiceManagementServiceTO> getLifeCycleServiceMgmtService() {
	
		return lifeCycleServiceMgmtService;
	}
	
	public Long getReleasePhaseId() {
	
		return releasePhaseId;
	}
	
	/**
	 * @return the servicesList
	 */
	public List<LifeCycleServiceManagementServiceTO> getServicesList() {
	
		return servicesList;
	}
	
	public void setLifeCycleServiceMgmtEnvironment(Set<LifeCycleServiceManagementEnvironmentTO> lifeCycleServiceMgmtEnvironment) {
	
		this.lifeCycleServiceMgmtEnvironment = lifeCycleServiceMgmtEnvironment;
	}
	
	public void setLifeCycleServiceMgmtService(Set<LifeCycleServiceManagementServiceTO> lifeCycleServiceMgmtService) {
	
		this.lifeCycleServiceMgmtService = lifeCycleServiceMgmtService;
	}
	
	public void setReleasePhaseId(Long releasePhaseId) {
	
		this.releasePhaseId = releasePhaseId;
	}
	
	/**
	 * @param servicesList
	 *                the servicesList to set
	 */
	public void setServicesList(List<LifeCycleServiceManagementServiceTO> servicesList) {
	
		this.servicesList = servicesList;
	}
}
