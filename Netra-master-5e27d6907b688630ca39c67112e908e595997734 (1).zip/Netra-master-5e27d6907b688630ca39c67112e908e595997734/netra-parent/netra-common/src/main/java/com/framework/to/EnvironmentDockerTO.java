package com.framework.to;

import java.io.Serializable;

public class EnvironmentDockerTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long id;
	private String imageId;
	private String repository;
	private String tags;
	private String serverIp;
	private Long virtualSize;
	private Long envId;
	private Long profileId;
	private String containerIp;
	private String containerID;
	private String envName;
	
	public EnvironmentDockerTO() {
	
		/* No implementation required at the moment. Method for future use. */
	}
	
	public String getContainerID() {
	
		return containerID;
	}
	
	public String getContainerIp() {
	
		return containerIp;
	}
	
	public Long getEnvId() {
	
		return envId;
	}
	
	public String getEnvName() {
	
		return envName;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public String getImageId() {
	
		return imageId;
	}
	
	public Long getProfileId() {
	
		return profileId;
	}
	
	public String getRepository() {
	
		return repository;
	}
	
	public String getServerIp() {
	
		return serverIp;
	}
	
	public String getTags() {
	
		return tags;
	}
	
	public Long getVirtualSize() {
	
		return virtualSize;
	}
	
	public void setContainerID(String containerID) {
	
		this.containerID = containerID;
	}
	
	public void setContainerIp(String containerIp) {
	
		this.containerIp = containerIp;
	}
	
	public void setEnvId(Long envId) {
	
		this.envId = envId;
	}
	
	public void setEnvName(String envName) {
	
		this.envName = envName;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setImageId(String imageId) {
	
		this.imageId = imageId;
	}
	
	public void setProfileId(Long profileId) {
	
		this.profileId = profileId;
	}
	
	public void setRepository(String repository) {
	
		this.repository = repository;
	}
	
	public void setServerIp(String serverIp) {
	
		this.serverIp = serverIp;
	}
	
	public void setTags(String tags) {
	
		this.tags = tags;
	}
	
	public void setVirtualSize(Long virtualSize) {
	
		this.virtualSize = virtualSize;
	}
}
