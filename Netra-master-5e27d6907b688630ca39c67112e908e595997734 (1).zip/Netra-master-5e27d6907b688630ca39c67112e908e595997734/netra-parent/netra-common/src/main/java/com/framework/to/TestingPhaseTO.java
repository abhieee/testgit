package com.framework.to;

import java.util.HashSet;
import java.util.Set;

public class TestingPhaseTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7927158025189185655L;
	private Set<EnvironmentTO> environment = new HashSet<EnvironmentTO>(0);
	private String PhaseName;
	private String testingPhase;
	private String statusImage;
	private Long serviceStatus;
	private boolean lastPhase;
	private String imageTitle;
	private Long phaseExecutionOrder;
	private Long phaseStatus;
	private String colorCode;
	private int tableSize;
	private long searchCount;
	private int firstResult = 1;
	private Set<ReservationTO> reservationses = new HashSet<ReservationTO>(0);
	
	public String getColorCode() {
	
		return colorCode;
	}
	
	public Set<EnvironmentTO> getEnvironment() {
	
		return environment;
	}
	
	public int getFirstResult() {
	
		return firstResult;
	}
	
	public String getImageTitle() {
	
		return imageTitle;
	}
	
	public Long getPhaseExecutionOrder() {
	
		return phaseExecutionOrder;
	}
	
	public String getPhaseName() {
	
		return PhaseName;
	}
	
	public Long getPhaseStatus() {
	
		return phaseStatus;
	}
	
	public long getSearchCount() {
	
		return searchCount;
	}
	
	public Long getServiceStatus() {
	
		return serviceStatus;
	}
	
	public String getStatusImage() {
	
		return statusImage;
	}
	
	public int getTableSize() {
	
		return tableSize;
	}
	
	public String getTestingPhase() {
	
		return testingPhase;
	}
	
	public boolean isLastPhase() {
	
		return lastPhase;
	}
	
	public void setColorCode(String colorCode) {
	
		this.colorCode = colorCode;
	}
	
	public void setEnvironment(Set<EnvironmentTO> environment) {
	
		this.environment = environment;
	}
	
	public void setFirstResult(int firstResult) {
	
		this.firstResult = firstResult;
	}
	
	public void setImageTitle(String imageTitle) {
	
		this.imageTitle = imageTitle;
	}
	
	public void setLastPhase(boolean lastPhase) {
	
		this.lastPhase = lastPhase;
	}
	
	public void setPhaseExecutionOrder(Long phaseExecutionOrder) {
	
		this.phaseExecutionOrder = phaseExecutionOrder;
	}
	
	public void setPhaseName(String phaseName) {
	
		PhaseName = phaseName;
	}
	
	public void setPhaseStatus(Long phaseStatus) {
	
		this.phaseStatus = phaseStatus;
	}
	
	public void setSearchCount(long searchCount) {
	
		this.searchCount = searchCount;
	}
	
	public void setServiceStatus(Long serviceStatus) {
	
		this.serviceStatus = serviceStatus;
	}
	
	public void setStatusImage(String statusImage) {
	
		this.statusImage = statusImage;
	}
	
	public void setTableSize(int tableSize) {
	
		this.tableSize = tableSize;
	}
	
	public void setTestingPhase(String testingPhase) {
	
		this.testingPhase = testingPhase;
	}
	
	public Set<ReservationTO> getReservationses() {
	
		return reservationses;
	}
	
	public void setReservationses(Set<ReservationTO> reservationses) {
	
		this.reservationses = reservationses;
	}
}
