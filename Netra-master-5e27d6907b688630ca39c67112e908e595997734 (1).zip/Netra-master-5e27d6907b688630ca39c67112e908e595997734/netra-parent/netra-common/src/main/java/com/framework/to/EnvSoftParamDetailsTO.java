/**
 *
 */
package com.framework.to;

import java.io.Serializable;
import com.framework.nolio.to.NolioProcessParametersTO;

/**
 * @author 460650
 */
public class EnvSoftParamDetailsTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -370826888061471015L;
	private long softParamId;
	private NolioProcessParametersTO nolioProcessParametersTO;
	private String propertyValue;
	private Long parameterId;
	private EnvironmentSoftParamsTO environmentSoftParamsTO;
	
	public EnvironmentSoftParamsTO getEnvironmentSoftParamsTO() {
	
		return environmentSoftParamsTO;
	}
	
	public NolioProcessParametersTO getNolioProcessParametersTO() {
	
		return nolioProcessParametersTO;
	}
	
	public Long getParameterId() {
	
		return parameterId;
	}
	
	public String getPropertyValue() {
	
		return propertyValue;
	}
	
	public long getSoftParamId() {
	
		return softParamId;
	}
	
	public void setEnvironmentSoftParamsTO(EnvironmentSoftParamsTO environmentSoftParamsTO) {
	
		this.environmentSoftParamsTO = environmentSoftParamsTO;
	}
	
	public void setNolioProcessParametersTO(NolioProcessParametersTO nolioProcessParametersTO) {
	
		this.nolioProcessParametersTO = nolioProcessParametersTO;
	}
	
	public void setParameterId(Long parameterId) {
	
		this.parameterId = parameterId;
	}
	
	public void setPropertyValue(String propertyValue) {
	
		this.propertyValue = propertyValue;
	}
	
	public void setSoftParamId(long softParamId) {
	
		this.softParamId = softParamId;
	}
}
