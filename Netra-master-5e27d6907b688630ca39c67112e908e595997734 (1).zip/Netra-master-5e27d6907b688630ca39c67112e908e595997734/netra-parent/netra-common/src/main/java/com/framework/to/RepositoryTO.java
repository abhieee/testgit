package com.framework.to;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class RepositoryTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8230709995096529229L;
	private Long id;
	private String repoName;
	private int searchCount;
	private boolean editAccessFlag = false;
	private int tableSize = 10;
	private Long pageNumber = 1L;
	private int firstResult = 0;
	private List<RepoTO> repoResult = new ArrayList<RepoTO>();
	private String repoUsername;
	private String repoPassword;
	private String description;
	private RepoTO repoTO;
	private Long repoType;
	private String ip;
	private String port;
	private Long buId;
	private Long projectId;
	private ClientTO clientTO;
	private ProjectsTO projectsTO;
	private List<BusinessUnitTO> businessUnitList;
	private List<ProjectsTO> projectList;
	private List<Long> selectedBuList;
	private List<Long> selectedProjectList;
	private Set<RepositoryDetailsTO> repositoryDetails = new HashSet<RepositoryDetailsTO>(0);
	private Long selectedBUId;
	private Long selectedProjectId;
	private Set<ScriptTaskMappingTO> scriptTaskMappingTO;
	
	public Long getBuId() {
	
		return buId;
	}
	
	public List<BusinessUnitTO> getBusinessUnitList() {
	
		return businessUnitList;
	}
	
	public ClientTO getClientTO() {
	
		return clientTO;
	}
	
	public String getDescription() {
	
		return description;
	}
	
	public int getFirstResult() {
	
		return firstResult;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public String getIp() {
	
		return ip;
	}
	
	public Long getPageNumber() {
	
		return pageNumber;
	}
	
	public String getPort() {
	
		return port;
	}
	
	public Long getProjectId() {
	
		return projectId;
	}
	
	public List<ProjectsTO> getProjectList() {
	
		return projectList;
	}
	
	public ProjectsTO getProjectsTO() {
	
		return projectsTO;
	}
	
	public String getRepoName() {
	
		return repoName;
	}
	
	public String getRepoPassword() {
	
		return repoPassword;
	}
	
	public List<RepoTO> getRepoResult() {
	
		return repoResult;
	}
	
	public Set<RepositoryDetailsTO> getRepositoryDetails() {
	
		return repositoryDetails;
	}
	
	public RepoTO getRepoTO() {
	
		return repoTO;
	}
	
	public Long getRepoType() {
	
		return repoType;
	}
	
	public String getRepoUsername() {
	
		return repoUsername;
	}
	
	public int getSearchCount() {
	
		return searchCount;
	}
	
	public Long getSelectedBUId() {
	
		return selectedBUId;
	}
	
	public List<Long> getSelectedBuList() {
	
		return selectedBuList;
	}
	
	public Long getSelectedProjectId() {
	
		return selectedProjectId;
	}
	
	public List<Long> getSelectedProjectList() {
	
		return selectedProjectList;
	}
	
	public int getTableSize() {
	
		return tableSize;
	}
	
	public boolean isEditAccessFlag() {
	
		return editAccessFlag;
	}
	
	public void setBuId(Long buId) {
	
		this.buId = buId;
	}
	
	public void setBusinessUnitList(List<BusinessUnitTO> businessUnitList) {
	
		this.businessUnitList = businessUnitList;
	}
	
	public void setClientTO(ClientTO clientTO) {
	
		this.clientTO = clientTO;
	}
	
	public void setDescription(String description) {
	
		this.description = description;
	}
	
	public void setEditAccessFlag(boolean editAccessFlag) {
	
		this.editAccessFlag = editAccessFlag;
	}
	
	public void setFirstResult(int firstResult) {
	
		this.firstResult = firstResult;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setIp(String ip) {
	
		this.ip = ip;
	}
	
	public void setPageNumber(Long pageNumber) {
	
		this.pageNumber = pageNumber;
	}
	
	public void setPort(String port) {
	
		this.port = port;
	}
	
	public void setProjectId(Long projectId) {
	
		this.projectId = projectId;
	}
	
	public void setProjectList(List<ProjectsTO> projectList) {
	
		this.projectList = projectList;
	}
	
	public void setProjectsTO(ProjectsTO projectsTO) {
	
		this.projectsTO = projectsTO;
	}
	
	public void setRepoName(String repoName) {
	
		this.repoName = repoName;
	}
	
	public void setRepoPassword(String repoPassword) {
	
		this.repoPassword = repoPassword;
	}
	
	public void setRepoResult(List<RepoTO> repoResult) {
	
		this.repoResult = repoResult;
	}
	
	public void setRepositoryDetails(Set<RepositoryDetailsTO> repositoryDetails) {
	
		this.repositoryDetails = repositoryDetails;
	}
	
	public void setRepoTO(RepoTO repoTO) {
	
		this.repoTO = repoTO;
	}
	
	public void setRepoType(Long repoType) {
	
		this.repoType = repoType;
	}
	
	public void setRepoUsername(String repoUsername) {
	
		this.repoUsername = repoUsername;
	}
	
	public void setSearchCount(int searchCount) {
	
		this.searchCount = searchCount;
	}
	
	public void setSelectedBUId(Long selectedBUId) {
	
		this.selectedBUId = selectedBUId;
	}
	
	public void setSelectedBuList(List<Long> selectedBuList) {
	
		this.selectedBuList = selectedBuList;
	}
	
	public void setSelectedProjectId(Long selectedProjectId) {
	
		this.selectedProjectId = selectedProjectId;
	}
	
	public void setSelectedProjectList(List<Long> selectedProjectList) {
	
		this.selectedProjectList = selectedProjectList;
	}
	
	public void setTableSize(int tableSize) {
	
		this.tableSize = tableSize;
	}
	
	public Set<ScriptTaskMappingTO> getScriptTaskMappingTO() {
	
		return scriptTaskMappingTO;
	}
	
	public void setScriptTaskMappingTO(Set<ScriptTaskMappingTO> scriptTaskMappingTO) {
	
		this.scriptTaskMappingTO = scriptTaskMappingTO;
	}
}