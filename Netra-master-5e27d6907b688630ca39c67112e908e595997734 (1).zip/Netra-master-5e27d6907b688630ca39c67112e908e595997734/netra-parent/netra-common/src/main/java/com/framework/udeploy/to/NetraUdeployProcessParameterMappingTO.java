package com.framework.udeploy.to;

import java.util.List;
import com.framework.to.NetraParametersTO;

public class NetraUdeployProcessParameterMappingTO {
	
	private Long id;
	private long selectedUdeployProcessId;
	private long parameterId;
	private long netraParameterId;
	private String parameterPathName;
	private String label;
	private List<NetraParametersTO> netraParametersTOList;
	
	public String getParameterPathName() {
	
		return parameterPathName;
	}
	
	public void setParameterPathName(String parameterPathName) {
	
		this.parameterPathName = parameterPathName;
	}
	
	public String getLabel() {
	
		return label;
	}
	
	public void setLabel(String label) {
	
		this.label = label;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public long getParameterId() {
	
		return parameterId;
	}
	
	public void setParameterId(long parameterId) {
	
		this.parameterId = parameterId;
	}
	
	public long getNetraParameterId() {
	
		return netraParameterId;
	}
	
	public void setNetraParameterId(long netraParameterId) {
	
		this.netraParameterId = netraParameterId;
	}
	
	public long getSelectedUdeployProcessId() {
	
		return selectedUdeployProcessId;
	}
	
	public void setSelectedUdeployProcessId(long selectedUdeployProcessId) {
	
		this.selectedUdeployProcessId = selectedUdeployProcessId;
	}
	
	public List<NetraParametersTO> getNetraParametersTOList() {
	
		return netraParametersTOList;
	}
	
	public void setNetraParametersTOList(List<NetraParametersTO> netraParametersTOList) {
	
		this.netraParametersTOList = netraParametersTOList;
	}
}
