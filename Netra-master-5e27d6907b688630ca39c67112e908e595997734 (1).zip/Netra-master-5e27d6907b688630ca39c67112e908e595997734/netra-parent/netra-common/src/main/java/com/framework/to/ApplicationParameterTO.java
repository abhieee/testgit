package com.framework.to;

import java.io.File;
import java.sql.Blob;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import com.framework.nolio.to.NolioProcessParametersTO;

public class ApplicationParameterTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3937628631807892594L;
	/**
	 *
	 */
	private String propertyValue;
	private String selectedActivity;
	private Long selectedParameter;
	private Long selActivity;
	private Long applicationProfileMapId;
	private Long applicationProfileDetId;
	private Long applicationProfileSoftwareParameterId;
	private Long selectedSoftware;
	private Long userId;
	private Long selectedApplication;
	private List<ApplicationParameterTO> applicationParameterFormList = new ArrayList<>(0);
	private List<EnvironmentTO> environmentList = new ArrayList<>(0);
	private List<ActivitySoftwareMappingTO> activityList = new ArrayList<>(0);
	private List<NolioProcessParametersTO> nolioproList = new ArrayList<>(0);
	private List<ApplicationParameterTO> applicationParameterEditFormList = new ArrayList<>(0);
	private List<ApplicationParameterTO> applicationParameterDelFormList = new ArrayList<>(0);
	private List<ApplicationProfileConfigParamsTO> appPrfConfigParamsList = new ArrayList<>(0);
	private Long configFileId;
	private Long selectedApplicationProfile;
	private File templateFile;
	private String fileName;
	private String fileTargetPath;
	private String replaceWithValue;
	private Long startPosition;
	private Long endPosition;
	private Long selectedServer;
	private String fileSourcePath;
	List<File> files = new ArrayList<>(0);
	List<String> filesFileName = new ArrayList<>(0);
	List<Blob> configFileList = new ArrayList<>(0);
	private boolean exportFlag = false;
	private byte[] TemplateFileContent;
	private String configFileName;
	
	public List<ActivitySoftwareMappingTO> getActivityList() {
	
		return activityList;
	}
	
	public List<ApplicationParameterTO> getApplicationParameterDelFormList() {
	
		return applicationParameterDelFormList;
	}
	
	public List<ApplicationParameterTO> getApplicationParameterEditFormList() {
	
		return applicationParameterEditFormList;
	}
	
	public List<ApplicationParameterTO> getApplicationParameterFormList() {
	
		return applicationParameterFormList;
	}
	
	public Long getApplicationProfileDetId() {
	
		return applicationProfileDetId;
	}
	
	public Long getApplicationProfileMapId() {
	
		return applicationProfileMapId;
	}
	
	public Long getApplicationProfileSoftwareParameterId() {
	
		return applicationProfileSoftwareParameterId;
	}
	
	public List<ApplicationProfileConfigParamsTO> getAppPrfConfigParamsList() {
	
		return appPrfConfigParamsList;
	}
	
	public Long getConfigFileId() {
	
		return configFileId;
	}
	
	public List<Blob> getConfigFileList() {
	
		return configFileList;
	}
	
	public String getConfigFileName() {
	
		return configFileName;
	}
	
	public Long getEndPosition() {
	
		return endPosition;
	}
	
	public List<EnvironmentTO> getEnvironmentList() {
	
		return environmentList;
	}
	
	public String getFileName() {
	
		return fileName;
	}
	
	public List<File> getFiles() {
	
		return files;
	}
	
	public List<String> getFilesFileName() {
	
		return filesFileName;
	}
	
	public String getFileSourcePath() {
	
		return fileSourcePath;
	}
	
	public String getFileTargetPath() {
	
		return fileTargetPath;
	}
	
	public List<NolioProcessParametersTO> getNolioproList() {
	
		return nolioproList;
	}
	
	public String getPropertyValue() {
	
		return propertyValue;
	}
	
	public String getReplaceWithValue() {
	
		return replaceWithValue;
	}
	
	public Long getSelActivity() {
	
		return selActivity;
	}
	
	public String getSelectedActivity() {
	
		return selectedActivity;
	}
	
	public Long getSelectedApplication() {
	
		return selectedApplication;
	}
	
	public Long getSelectedApplicationProfile() {
	
		return selectedApplicationProfile;
	}
	
	public Long getSelectedParameter() {
	
		return selectedParameter;
	}
	
	public Long getSelectedServer() {
	
		return selectedServer;
	}
	
	public Long getSelectedSoftware() {
	
		return selectedSoftware;
	}
	
	public Long getStartPosition() {
	
		return startPosition;
	}
	
	public File getTemplateFile() {
	
		return templateFile;
	}
	
	public byte[] getTemplateFileContent() {
	
		return TemplateFileContent;
	}
	
	public Long getUserId() {
	
		return userId;
	}
	
	public boolean isExportFlag() {
	
		return exportFlag;
	}
	
	public void setActivityList(List<ActivitySoftwareMappingTO> activityList) {
	
		this.activityList = activityList;
	}
	
	public void setApplicationParameterDelFormList(List<ApplicationParameterTO> applicationParameterDelFormList) {
	
		this.applicationParameterDelFormList = applicationParameterDelFormList;
	}
	
	public void setApplicationParameterEditFormList(List<ApplicationParameterTO> applicationParameterEditFormList) {
	
		this.applicationParameterEditFormList = applicationParameterEditFormList;
	}
	
	public void setApplicationParameterFormList(List<ApplicationParameterTO> applicationParameterFormList) {
	
		this.applicationParameterFormList = applicationParameterFormList;
	}
	
	public void setApplicationProfileDetId(Long applicationProfileDetId) {
	
		this.applicationProfileDetId = applicationProfileDetId;
	}
	
	public void setApplicationProfileMapId(Long applicationProfileMapId) {
	
		this.applicationProfileMapId = applicationProfileMapId;
	}
	
	public void setApplicationProfileSoftwareParameterId(Long applicationProfileSoftwareParameterId) {
	
		this.applicationProfileSoftwareParameterId = applicationProfileSoftwareParameterId;
	}
	
	public void setAppPrfConfigParamsList(List<ApplicationProfileConfigParamsTO> appPrfConfigParamsList) {
	
		this.appPrfConfigParamsList = appPrfConfigParamsList;
	}
	
	public void setConfigFileId(Long configFileId) {
	
		this.configFileId = configFileId;
	}
	
	public void setConfigFileList(List<Blob> configFileList) {
	
		this.configFileList = configFileList;
	}
	
	public void setConfigFileName(String configFileName) {
	
		this.configFileName = configFileName;
	}
	
	public void setEndPosition(Long endPosition) {
	
		this.endPosition = endPosition;
	}
	
	public void setEnvironmentList(List<EnvironmentTO> environmentList) {
	
		this.environmentList = environmentList;
	}
	
	public void setExportFlag(boolean exportFlag) {
	
		this.exportFlag = exportFlag;
	}
	
	public void setFileName(String fileName) {
	
		this.fileName = fileName;
	}
	
	public void setFiles(List<File> files) {
	
		this.files = files;
	}
	
	public void setFilesFileName(List<String> filesFileName) {
	
		this.filesFileName = filesFileName;
	}
	
	public void setFileSourcePath(String fileSourcePath) {
	
		this.fileSourcePath = fileSourcePath;
	}
	
	public void setFileTargetPath(String fileTargetPath) {
	
		this.fileTargetPath = fileTargetPath;
	}
	
	public void setNolioproList(List<NolioProcessParametersTO> nolioproList) {
	
		this.nolioproList = nolioproList;
	}
	
	public void setPropertyValue(String propertyValue) {
	
		this.propertyValue = propertyValue;
	}
	
	public void setReplaceWithValue(String replaceWithValue) {
	
		this.replaceWithValue = replaceWithValue;
	}
	
	public void setSelActivity(Long selActivity) {
	
		this.selActivity = selActivity;
	}
	
	public void setSelectedActivity(String selectedActivity) {
	
		this.selectedActivity = selectedActivity;
	}
	
	public void setSelectedApplication(Long selectedApplication) {
	
		this.selectedApplication = selectedApplication;
	}
	
	public void setSelectedApplicationProfile(Long selectedApplicationProfile) {
	
		this.selectedApplicationProfile = selectedApplicationProfile;
	}
	
	public void setSelectedParameter(Long selectedParameter) {
	
		this.selectedParameter = selectedParameter;
	}
	
	public void setSelectedServer(Long selectedServer) {
	
		this.selectedServer = selectedServer;
	}
	
	public void setSelectedSoftware(Long selectedSoftware) {
	
		this.selectedSoftware = selectedSoftware;
	}
	
	public void setStartPosition(Long startPosition) {
	
		this.startPosition = startPosition;
	}
	
	public void setTemplateFile(File templateFile) {
	
		this.templateFile = templateFile;
	}
	
	public void setTemplateFileContent(byte[] templateFileContentArray) {
	
		if (templateFileContentArray == null) {
			this.TemplateFileContent = new byte[0];
		} else {
			this.TemplateFileContent = Arrays.copyOf(templateFileContentArray, templateFileContentArray.length);
		}
	}
	
	public void setUserId(Long userId) {
	
		this.userId = userId;
	}
}
