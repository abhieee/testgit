package com.framework.to;

import java.io.Serializable;

public class MonitoringMasterTo implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6570763137224772684L;
	private Long P_Id = null;
	private String proxy_port = null;
	private String proxy_url = null;
	private String userName = null;
	private String password = null;
	private String machine = null;
	private String domain = null;
	private String active;
	
	public MonitoringMasterTo() {
	
		/* No implementation required at the moment. Method for future use. */
	}
	
	public String getActive() {
	
		return active;
	}
	
	public String getDomain() {
	
		return domain;
	}
	
	public String getMachine() {
	
		return machine;
	}
	
	public Long getP_Id() {
	
		return P_Id;
	}
	
	public String getPassword() {
	
		return password;
	}
	
	public String getProxy_port() {
	
		return proxy_port;
	}
	
	public String getProxy_url() {
	
		return proxy_url;
	}
	
	public String getUserName() {
	
		return userName;
	}
	
	public void setActive(String active) {
	
		this.active = active;
	}
	
	public void setDomain(String domain) {
	
		this.domain = domain;
	}
	
	public void setMachine(String machine) {
	
		this.machine = machine;
	}
	
	public void setP_Id(Long p_Id) {
	
		P_Id = p_Id;
	}
	
	public void setPassword(String password) {
	
		this.password = password;
	}
	
	public void setProxy_port(String proxy_port) {
	
		this.proxy_port = proxy_port;
	}
	
	public void setProxy_url(String proxy_url) {
	
		this.proxy_url = proxy_url;
	}
	
	public void setUserName(String userName) {
	
		this.userName = userName;
	}
}
