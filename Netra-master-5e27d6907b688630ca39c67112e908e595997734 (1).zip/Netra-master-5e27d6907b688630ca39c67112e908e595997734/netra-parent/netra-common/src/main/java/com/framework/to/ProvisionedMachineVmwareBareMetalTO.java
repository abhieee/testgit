package com.framework.to;

import java.io.Serializable;

public class ProvisionedMachineVmwareBareMetalTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2370760520217707059L;
	private Long id;
	private Long provisionedMachineTemplateId;
	private String username;
	private String password;
	private Long hardDiskSize;
	private String diskMode;
	
	/**
	 * @return the diskMode
	 */
	public String getDiskMode() {
	
		return diskMode;
	}
	
	/**
	 * @return the hardDiskSize
	 */
	public Long getHardDiskSize() {
	
		return hardDiskSize;
	}
	
	/**
	 * @return the id
	 */
	public Long getId() {
	
		return id;
	}
	
	/**
	 * @return the password
	 */
	public String getPassword() {
	
		return password;
	}
	
	/**
	 * @return the provisionedMachineTemplateId
	 */
	public Long getProvisionedMachineTemplateId() {
	
		return provisionedMachineTemplateId;
	}
	
	/**
	 * @return the username
	 */
	public String getUsername() {
	
		return username;
	}
	
	/**
	 * @param diskMode
	 *                the diskMode to set
	 */
	public void setDiskMode(String diskMode) {
	
		this.diskMode = diskMode;
	}
	
	/**
	 * @param hardDiskSize
	 *                the hardDiskSize to set
	 */
	public void setHardDiskSize(Long hardDiskSize) {
	
		this.hardDiskSize = hardDiskSize;
	}
	
	/**
	 * @param id
	 *                the id to set
	 */
	public void setId(Long id) {
	
		this.id = id;
	}
	
	/**
	 * @param password
	 *                the password to set
	 */
	public void setPassword(String password) {
	
		this.password = password;
	}
	
	/**
	 * @param provisionedMachineTemplateId
	 *                the provisionedMachineTemplateId to set
	 */
	public void setProvisionedMachineTemplateId(Long provisionedMachineTemplateId) {
	
		this.provisionedMachineTemplateId = provisionedMachineTemplateId;
	}
	
	/**
	 * @param username
	 *                the username to set
	 */
	public void setUsername(String username) {
	
		this.username = username;
	}
}
