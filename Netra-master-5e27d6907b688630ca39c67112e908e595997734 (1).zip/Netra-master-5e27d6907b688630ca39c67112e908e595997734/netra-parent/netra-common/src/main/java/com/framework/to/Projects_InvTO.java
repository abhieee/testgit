package com.framework.to;

import java.util.HashSet;
import java.util.Set;

public class Projects_InvTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2375384630262415042L;
	private Long clientId;
	private Long status;
	private Long applications;
	private Set<Application_InvTO> application = new HashSet<Application_InvTO>();
	
	public Set<Application_InvTO> getApplication() {
	
		return application;
	}
	
	public Long getApplications() {
	
		return applications;
	}
	
	public Long getClientId() {
	
		return clientId;
	}
	
	public Long getStatus() {
	
		return status;
	}
	
	public void setApplication(Set<Application_InvTO> application) {
	
		this.application = application;
	}
	
	public void setApplications(Long applications) {
	
		this.applications = applications;
	}
	
	public void setClientId(Long clientId) {
	
		this.clientId = clientId;
	}
	
	public void setStatus(Long status) {
	
		this.status = status;
	}
}
