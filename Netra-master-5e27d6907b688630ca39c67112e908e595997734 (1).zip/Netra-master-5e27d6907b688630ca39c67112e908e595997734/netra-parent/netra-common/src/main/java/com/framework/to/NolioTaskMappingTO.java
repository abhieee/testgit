/**
 *
 */
package com.framework.to;

import com.framework.nolio.to.NolioProcess;

/**
 * @author 737070
 */
public class NolioTaskMappingTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7897701752883466164L;
	private NolioProcess nolioProcess;
	private long task_id;
	private TaskManagementTO taskManagementTO;
	private long processOrder;
	
	public NolioProcess getNolioProcess() {
	
		return nolioProcess;
	}
	
	public void setNolioProcess(NolioProcess nolioProcess) {
	
		this.nolioProcess = nolioProcess;
	}
	
	public long getTask_id() {
	
		return task_id;
	}
	
	public void setTask_id(long task_id) {
	
		this.task_id = task_id;
	}
	
	public TaskManagementTO getTaskManagementTO() {
	
		return taskManagementTO;
	}
	
	public void setTaskManagementTO(TaskManagementTO taskManagementTO) {
	
		this.taskManagementTO = taskManagementTO;
	}
	
	public long getProcessOrder() {
	
		return processOrder;
	}
	
	public void setProcessOrder(long processOrder) {
	
		this.processOrder = processOrder;
	}
}
