package com.framework.to;

import java.io.Serializable;

public class TransfromMapTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String type;
	private String tableName;
	private Long id;
	private String element;
	private boolean isNull;
	private String columnNameNetra;
	private String columnNameSN;
	private String baseURL;
	
	public boolean getIsNull() {
	
		return isNull;
	}
	
	public void setIsNull(boolean isNull) {
	
		this.isNull = isNull;
	}
	
	public String getTableName() {
	
		return tableName;
	}
	
	public void setTableName(String tableName) {
	
		this.tableName = tableName;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public String getType() {
	
		return type;
	}
	
	public void setType(String type) {
	
		this.type = type;
	}
	
	public String getElement() {
	
		return element;
	}
	
	public void setElement(String element) {
	
		this.element = element;
	}
	
	public String getColumnNameNetra() {
	
		return columnNameNetra;
	}
	
	public void setColumnNameNetra(String columnNameNetra) {
	
		this.columnNameNetra = columnNameNetra;
	}
	
	public String getColumnNameSN() {
	
		return columnNameSN;
	}
	
	public void setColumnNameSN(String columnNameSN) {
	
		this.columnNameSN = columnNameSN;
	}
	
	public String getBaseURL() {
	
		return baseURL;
	}
	
	public void setBaseURL(String baseURL) {
	
		this.baseURL = baseURL;
	}
}
