package com.framework.report;

import java.util.HashSet;
import java.util.Set;

public class AppDetailsReportVO {
	
	private String AppName = null;
	private Set<String> contactDetails = new HashSet<String>();
	private Set<String> tstPhase = new HashSet<String>();
	private Set<String> envName = new HashSet<String>();
	private String appSupport = null;
	private String desc = null;
	private String projName = null;
	
	public String getAppName() {
	
		return AppName;
	}
	
	public void setAppName(String appName) {
	
		AppName = appName;
	}
	
	public Set<String> getContactDetails() {
	
		return contactDetails;
	}
	
	public void setContactDetails(Set<String> contactDetails) {
	
		this.contactDetails = contactDetails;
	}
	
	public Set<String> getTstPhase() {
	
		return tstPhase;
	}
	
	public void setTstPhase(Set<String> tstPhase) {
	
		this.tstPhase = tstPhase;
	}
	
	public Set<String> getEnvName() {
	
		return envName;
	}
	
	public void setEnvName(Set<String> envName) {
	
		this.envName = envName;
	}
	
	public String getAppSupport() {
	
		return appSupport;
	}
	
	public void setAppSupport(String appSupport) {
	
		this.appSupport = appSupport;
	}
	
	public String getDesc() {
	
		return desc;
	}
	
	public void setDesc(String desc) {
	
		this.desc = desc;
	}
	
	public String getProjName() {
	
		return projName;
	}
	
	public void setProjName(String projName) {
	
		this.projName = projName;
	}
}
