package com.framework.to;

public class EnvironmentApplication_InvTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3355121757275962999L;
	private Environment_InvTO environmentTO;
	private ApplicationRelease_InvTO applicationReleaseTO;
	private Long applicationId;
	private Long releaseId;
	
	public Long getApplicationId() {
	
		return applicationId;
	}
	
	public ApplicationRelease_InvTO getApplicationReleaseTO() {
	
		return applicationReleaseTO;
	}
	
	public Environment_InvTO getEnvironmentTO() {
	
		return environmentTO;
	}
	
	public Long getReleaseId() {
	
		return releaseId;
	}
	
	public void setApplicationId(Long applicationId) {
	
		this.applicationId = applicationId;
	}
	
	public void setApplicationReleaseTO(ApplicationRelease_InvTO applicationReleaseTO) {
	
		this.applicationReleaseTO = applicationReleaseTO;
	}
	
	public void setEnvironmentTO(Environment_InvTO environmentTO) {
	
		this.environmentTO = environmentTO;
	}
	
	public void setReleaseId(Long releaseId) {
	
		this.releaseId = releaseId;
	}
}
