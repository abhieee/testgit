/**
 * 
 */
package com.framework.to;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @author 460650
 */
public class ApplicationMobileTestingTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6431865717064458419L;
	private Long id;
	private long requestId;
	private long applicationId;
	private String mobileTestToolId;
	private String deviceIds;
	private String scripts;
	private String scriptsParameters;
	private String description;
	private String scriptReport;
	private String baseUrl;
	private String mobileTestToolUsername;
	private String mobileTestToolPassword;
	private String provider;
	private List<Long> selectedBusinessUnitNew = new ArrayList<>(0);
	private List<Long> selectedProjectNew = new ArrayList<>(0);
	private List<Long> selectedApplicationNew = new ArrayList<>(0);
	private Long clientId;
	private Long workFlowId;
	private Long createdById;
	private int success;
	
	public Long getId() {
	
		return id;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public long getRequestId() {
	
		return requestId;
	}
	
	public void setRequestId(long requestId) {
	
		this.requestId = requestId;
	}
	
	public long getApplicationId() {
	
		return applicationId;
	}
	
	public void setApplicationId(long applicationId) {
	
		this.applicationId = applicationId;
	}
	
	public String getMobileTestToolId() {
	
		return mobileTestToolId;
	}
	
	public void setMobileTestToolId(String mobileTestToolId) {
	
		this.mobileTestToolId = mobileTestToolId;
	}
	
	public String getDeviceIds() {
	
		return deviceIds;
	}
	
	public void setDeviceIds(String deviceIds) {
	
		this.deviceIds = deviceIds;
	}
	
	public String getScripts() {
	
		return scripts;
	}
	
	public void setScripts(String scripts) {
	
		this.scripts = scripts;
	}
	
	public String getScriptsParameters() {
	
		return scriptsParameters;
	}
	
	public void setScriptsParameters(String scriptsParameters) {
	
		this.scriptsParameters = scriptsParameters;
	}
	
	public String getDescription() {
	
		return description;
	}
	
	public void setDescription(String description) {
	
		this.description = description;
	}
	
	public String getScriptReport() {
	
		return scriptReport;
	}
	
	public void setScriptReport(String scriptReport) {
	
		this.scriptReport = scriptReport;
	}
	
	public String getBaseUrl() {
	
		return baseUrl;
	}
	
	public void setBaseUrl(String baseUrl) {
	
		this.baseUrl = baseUrl;
	}
	
	public String getMobileTestToolUsername() {
	
		return mobileTestToolUsername;
	}
	
	public void setMobileTestToolUsername(String mobileTestToolUsername) {
	
		this.mobileTestToolUsername = mobileTestToolUsername;
	}
	
	public String getMobileTestToolPassword() {
	
		return mobileTestToolPassword;
	}
	
	public void setMobileTestToolPassword(String mobileTestToolPassword) {
	
		this.mobileTestToolPassword = mobileTestToolPassword;
	}
	
	public String getProvider() {
	
		return provider;
	}
	
	public void setProvider(String provider) {
	
		this.provider = provider;
	}
	
	public List<Long> getSelectedBusinessUnitNew() {
	
		return selectedBusinessUnitNew;
	}
	
	public void setSelectedBusinessUnitNew(List<Long> selectedBusinessUnitNew) {
	
		this.selectedBusinessUnitNew = selectedBusinessUnitNew;
	}
	
	public List<Long> getSelectedProjectNew() {
	
		return selectedProjectNew;
	}
	
	public void setSelectedProjectNew(List<Long> selectedProjectNew) {
	
		this.selectedProjectNew = selectedProjectNew;
	}
	
	public List<Long> getSelectedApplicationNew() {
	
		return selectedApplicationNew;
	}
	
	public void setSelectedApplicationNew(List<Long> selectedApplicationNew) {
	
		this.selectedApplicationNew = selectedApplicationNew;
	}
	
	public Long getClientId() {
	
		return clientId;
	}
	
	public void setClientId(Long clientId) {
	
		this.clientId = clientId;
	}
	
	public Long getWorkFlowId() {
	
		return workFlowId;
	}
	
	public void setWorkFlowId(Long workFlowId) {
	
		this.workFlowId = workFlowId;
	}
	
	public Long getCreatedById() {
	
		return createdById;
	}
	
	public void setCreatedById(Long createdById) {
	
		this.createdById = createdById;
	}
	
	public int getSuccess() {
	
		return success;
	}
	
	public void setSuccess(int success) {
	
		this.success = success;
	}
}
