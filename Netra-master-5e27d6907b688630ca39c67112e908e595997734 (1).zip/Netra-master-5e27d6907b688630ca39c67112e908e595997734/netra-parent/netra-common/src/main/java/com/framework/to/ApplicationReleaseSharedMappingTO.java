package com.framework.to;

import java.io.Serializable;

public class ApplicationReleaseSharedMappingTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long id;
	private RepositoryMasterTO repositoryMaster;
	private Long sharedResourceId;
	private Long sharedNexusId;
	
	public Long getId() {
	
		return id;
	}
	
	public RepositoryMasterTO getRepositoryMaster() {
	
		return repositoryMaster;
	}
	
	public Long getSharedNexusId() {
	
		return sharedNexusId;
	}
	
	public Long getSharedResourceId() {
	
		return sharedResourceId;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setRepositoryMaster(RepositoryMasterTO repositoryMaster) {
	
		this.repositoryMaster = repositoryMaster;
	}
	
	public void setSharedNexusId(Long sharedNexusId) {
	
		this.sharedNexusId = sharedNexusId;
	}
	
	public void setSharedResourceId(Long sharedResourceId) {
	
		this.sharedResourceId = sharedResourceId;
	}
}
