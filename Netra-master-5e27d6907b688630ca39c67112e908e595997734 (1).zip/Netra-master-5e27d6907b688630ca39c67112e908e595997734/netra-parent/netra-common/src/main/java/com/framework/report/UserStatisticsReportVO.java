package com.framework.report;

import java.util.Date;

public class UserStatisticsReportVO {
	
	private int id;
	private String name = null;
	private String fullname = null;
	private String role = null;
	private Date created_date = null;
	private String status_desc = null;
	
	public UserStatisticsReportVO() {
	
		/* No implementation required at the moment. Method for future use. */
	}
	
	public UserStatisticsReportVO(int id, String name, String fullname, String role, Date created_date, String status_desc) {
	
		this.id = id;
		this.name = name;
		this.fullname = fullname;
		this.role = role;
		this.created_date = created_date;
		this.status_desc = status_desc;
	}
	
	public String getName() {
	
		return name;
	}
	
	public void setName(String name) {
	
		this.name = name;
	}
	
	public String getFullname() {
	
		return fullname;
	}
	
	public void setFullname(String fullname) {
	
		this.fullname = fullname;
	}
	
	public String getRole() {
	
		return role;
	}
	
	public void setRole(String role) {
	
		this.role = role;
	}
	
	public Date getCreated_date() {
	
		return created_date;
	}
	
	public void setCreated_date(Date created_date) {
	
		this.created_date = created_date;
	}
	
	public String getStatus_desc() {
	
		return status_desc;
	}
	
	public void setStatus_desc(String status_desc) {
	
		this.status_desc = status_desc;
	}
	
	public int getId() {
	
		return id;
	}
	
	public void setId(int id) {
	
		this.id = id;
	}
}
