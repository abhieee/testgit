/**
 *
 */
package com.framework.to;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @author TCS
 */
public class ApplicationTO extends NamedEntityTO implements Serializable {
	
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private String mobileAppType;
	private String nativeAppType;
	private Long selectedAppId;
	private Long selectedApplicationRelease;
	private Long selectedTestingPhase;
	private Long selectedReleasePlan;
	private Long userGrpId;
	private List<BusinessUnitTO> businessUnit = new ArrayList<>(0);
	private List<NamedEntityTO> project = new ArrayList<>(0);
	private List<NamedEntityTO> statuses = new ArrayList<>(0);
	private List<UserTO> ownerList = new ArrayList<UserTO>(0);
	private Long selectedOwner = null;
	private Long selectedStatus;
	private Long selectedProject;
	private long selectedBusinessUnit;
	private String appName;
	private Long status;
	private String description;
	private String release;
	private String sourcePath;
	private String userGroup;
	private String businessUnitName;
	private String projectName;
	private Set<UserGroupTO> userGroupTO = new HashSet<UserGroupTO>();
	private List<UserGroupTO> userNameList = new ArrayList<UserGroupTO>(0);
	private List<Long> selectedUserName = new ArrayList<Long>(0);
	private BusinessUnitTO businessUnitTO = null;
	private ProjectsTO projectTO = null;
	private Set<SubAppTO> applicationTreesForChildAppId = new HashSet<SubAppTO>(0);
	private Set<SubAppTO> applicationTreesForParentAppId = new HashSet<SubAppTO>(0);
	private List<Long> definedApplications = new ArrayList<Long>(0);
	private List<Long> definedComponentUp = new ArrayList<Long>(0);
	private List<Long> definedComponentDown = new ArrayList<Long>(0);
	private Set<ReservationTO> reservationses = new HashSet<ReservationTO>(0);
	private Set<WorkflowCurrentTO> workflowCurrentTO = new HashSet<WorkflowCurrentTO>();
	private List<TestingPhaseTO> test = new ArrayList<TestingPhaseTO>(0);
	private List<NamedEntityTO> subAppListLeft = new ArrayList<NamedEntityTO>(0);
	private List<ApplicationTO> allApplications = new ArrayList<ApplicationTO>(0);
	private List<ServiceTO> NServices = new ArrayList<ServiceTO>(0);
	private List<ServiceTO> YServices = new ArrayList<ServiceTO>(0);
	private Date createdByDate;
	private Date modifiedbyDate;
	private String type;
	private String category;
	private String contextPathName;
	private List<ApplicationReleaseTO> releaseList = new ArrayList<ApplicationReleaseTO>();
	private List<ReleasePlanningTO> releasePlanList = new ArrayList<>(0);
	private List<RepoTO> repoResult = new ArrayList<RepoTO>(0);
	private Long selectedService;
	private Long selectedApplicationReleaseMinor;
	private boolean check;
	private String archiAvail = null;
	private String ciAvail = null;
	private String thirdSupport = null;
	private String timeRationale = null;
	private List<CIServerTO> ciResult = new ArrayList<CIServerTO>(0);
	private Long addCI_Id;
	private List<Long> clientIdlist;
	private Long clientId;
	private int mapId;
	private UserGroupTO userGroups = new UserGroupTO();
	private List<Long> selectedLeftUsers = new ArrayList<Long>();
	private Long selectedUserGroup = null;
	private Set<EnvironmentApplicationTO> envAppTO = new HashSet<EnvironmentApplicationTO>(0);
	private Set<ApplicationProfileTO> applicationProfile = new HashSet<ApplicationProfileTO>(0);
	private Set<ApplicationSystemTO> applicationSystem = new HashSet<ApplicationSystemTO>(0);
	private Set<ApplicationReleaseTO> applicationRelease = new HashSet<ApplicationReleaseTO>(0);
	private Set<ApplicationReleasePhaseTO> applicationReleasePhase = new HashSet<ApplicationReleasePhaseTO>(0);
	private int tableSize = 15;
	private long pageNumber = 1;
	private int firstResult = 0;
	private long searchCount;
	private String machineIp;
	private List<UserTO> selectedLeftUserList = new ArrayList<UserTO>(0);
	private Long requestId = null;
	private Long releaseId = null;
	private String cornStr = null;
	private String other = null;
	private String manufacturer = null;
	private String vendor = null;
	private Set<UserGroupDetailsTO> userGroupDetailses = new HashSet<UserGroupDetailsTO>(0);
	private List<EnvironmentTO> environmentTO = new ArrayList<EnvironmentTO>();
	
	public List<EnvironmentTO> getEnvironmentTO() {
	
		return environmentTO;
	}
	
	public void setEnvironmentTO(List<EnvironmentTO> environmentTO) {
	
		this.environmentTO = environmentTO;
	}
	
	public Long getAddCI_Id() {
	
		return addCI_Id;
	}
	
	public List<ApplicationTO> getAllApplications() {
	
		return allApplications;
	}
	
	public Set<ApplicationProfileTO> getApplicationProfile() {
	
		return applicationProfile;
	}
	
	public Set<ApplicationReleaseTO> getApplicationRelease() {
	
		return applicationRelease;
	}
	
	public Set<ApplicationReleasePhaseTO> getApplicationReleasePhase() {
	
		return applicationReleasePhase;
	}
	
	public Set<ApplicationSystemTO> getApplicationSystem() {
	
		return applicationSystem;
	}
	
	public Set<SubAppTO> getApplicationTreesForChildAppId() {
	
		return applicationTreesForChildAppId;
	}
	
	public Set<SubAppTO> getApplicationTreesForParentAppId() {
	
		return applicationTreesForParentAppId;
	}
	
	public String getAppName() {
	
		return appName;
	}
	
	public String getArchiAvail() {
	
		return archiAvail;
	}
	
	public List<BusinessUnitTO> getBusinessUnit() {
	
		return businessUnit;
	}
	
	public String getBusinessUnitName() {
	
		return businessUnitName;
	}
	
	public BusinessUnitTO getBusinessUnitTO() {
	
		return businessUnitTO;
	}
	
	public String getCategory() {
	
		return category;
	}
	
	public String getCiAvail() {
	
		return ciAvail;
	}
	
	public List<CIServerTO> getCiResult() {
	
		return ciResult;
	}
	
	/**
	 * @return the clientId
	 */
	public Long getClientId() {
	
		return clientId;
	}
	
	/**
	 * @return the clientIdlist
	 */
	public List<Long> getClientIdlist() {
	
		return clientIdlist;
	}
	
	public String getContextPathName() {
	
		return contextPathName;
	}
	
	/**
	 * @return the cornStr
	 */
	public String getCornStr() {
	
		return cornStr;
	}
	
	public Date getCreatedByDate() {
	
		return createdByDate;
	}
	
	public List<Long> getDefinedApplications() {
	
		return definedApplications;
	}
	
	public List<Long> getDefinedComponentDown() {
	
		return definedComponentDown;
	}
	
	public List<Long> getDefinedComponentUp() {
	
		return definedComponentUp;
	}
	
	public String getDescription() {
	
		return description;
	}
	
	public Set<EnvironmentApplicationTO> getEnvAppTO() {
	
		return envAppTO;
	}
	
	public int getFirstResult() {
	
		return firstResult;
	}
	
	public String getMachineIp() {
	
		return machineIp;
	}
	
	public String getManufacturer() {
	
		return manufacturer;
	}
	
	public int getMapId() {
	
		return mapId;
	}
	
	public Date getModifiedbyDate() {
	
		return modifiedbyDate;
	}
	
	public List<ServiceTO> getNServices() {
	
		return NServices;
	}
	
	public String getOther() {
	
		return other;
	}
	
	public List<UserTO> getOwnerList() {
	
		return ownerList;
	}
	
	public long getPageNumber() {
	
		return pageNumber;
	}
	
	public List<NamedEntityTO> getProject() {
	
		return project;
	}
	
	public String getProjectName() {
	
		return projectName;
	}
	
	public ProjectsTO getProjectTO() {
	
		return projectTO;
	}
	
	public String getRelease() {
	
		return release;
	}
	
	/**
	 * @return the releaseId
	 */
	public Long getReleaseId() {
	
		return releaseId;
	}
	
	public List<ApplicationReleaseTO> getReleaseList() {
	
		return releaseList;
	}
	
	public List<RepoTO> getRepoResult() {
	
		return repoResult;
	}
	
	/**
	 * @return the requestId
	 */
	public Long getRequestId() {
	
		return requestId;
	}
	
	public Set<ReservationTO> getReservationses() {
	
		return reservationses;
	}
	
	public long getSearchCount() {
	
		return searchCount;
	}
	
	public Long getSelectedAppId() {
	
		return selectedAppId;
	}
	
	public Long getSelectedApplicationRelease() {
	
		return selectedApplicationRelease;
	}
	
	public Long getSelectedApplicationReleaseMinor() {
	
		return selectedApplicationReleaseMinor;
	}
	
	public long getSelectedBusinessUnit() {
	
		return selectedBusinessUnit;
	}
	
	public List<UserTO> getSelectedLeftUserList() {
	
		return selectedLeftUserList;
	}
	
	public List<Long> getSelectedLeftUsers() {
	
		return selectedLeftUsers;
	}
	
	public Long getSelectedOwner() {
	
		return selectedOwner;
	}
	
	public Long getSelectedProject() {
	
		return selectedProject;
	}
	
	public Long getSelectedService() {
	
		return selectedService;
	}
	
	public Long getSelectedStatus() {
	
		return selectedStatus;
	}
	
	public Long getSelectedUserGroup() {
	
		return selectedUserGroup;
	}
	
	public List<Long> getSelectedUserName() {
	
		return selectedUserName;
	}
	
	public String getSourcePath() {
	
		return sourcePath;
	}
	
	public Long getStatus() {
	
		return status;
	}
	
	public List<NamedEntityTO> getStatuses() {
	
		return statuses;
	}
	
	public List<NamedEntityTO> getSubAppListLeft() {
	
		return subAppListLeft;
	}
	
	public int getTableSize() {
	
		return tableSize;
	}
	
	public List<TestingPhaseTO> getTest() {
	
		return test;
	}
	
	public String getThirdSupport() {
	
		return thirdSupport;
	}
	
	public String getTimeRationale() {
	
		return timeRationale;
	}
	
	public String getType() {
	
		return type;
	}
	
	public String getUserGroup() {
	
		return userGroup;
	}
	
	public Set<UserGroupDetailsTO> getUserGroupDetailses() {
	
		return userGroupDetailses;
	}
	
	public UserGroupTO getUserGroups() {
	
		return userGroups;
	}
	
	public Set<UserGroupTO> getUserGroupTO() {
	
		return userGroupTO;
	}
	
	public Long getUserGrpId() {
	
		return userGrpId;
	}
	
	public List<UserGroupTO> getUserNameList() {
	
		return userNameList;
	}
	
	public String getVendor() {
	
		return vendor;
	}
	
	public Set<WorkflowCurrentTO> getWorkflowCurrentTO() {
	
		return workflowCurrentTO;
	}
	
	public List<ServiceTO> getYServices() {
	
		return YServices;
	}
	
	public boolean isCheck() {
	
		return check;
	}
	
	public void setAddCI_Id(Long addCI_Id) {
	
		this.addCI_Id = addCI_Id;
	}
	
	public void setAllApplications(List<ApplicationTO> allApplications) {
	
		this.allApplications = allApplications;
	}
	
	public void setApplicationProfile(Set<ApplicationProfileTO> applicationProfile) {
	
		this.applicationProfile = applicationProfile;
	}
	
	public void setApplicationRelease(Set<ApplicationReleaseTO> applicationRelease) {
	
		this.applicationRelease = applicationRelease;
	}
	
	public void setApplicationReleasePhase(Set<ApplicationReleasePhaseTO> applicationReleasePhase) {
	
		this.applicationReleasePhase = applicationReleasePhase;
	}
	
	public void setApplicationSystem(Set<ApplicationSystemTO> applicationSystem) {
	
		this.applicationSystem = applicationSystem;
	}
	
	public void setApplicationTreesForChildAppId(Set<SubAppTO> applicationTreesForChildAppId) {
	
		this.applicationTreesForChildAppId = applicationTreesForChildAppId;
	}
	
	public void setApplicationTreesForParentAppId(Set<SubAppTO> applicationTreesForParentAppId) {
	
		this.applicationTreesForParentAppId = applicationTreesForParentAppId;
	}
	
	public void setAppName(String appName) {
	
		this.appName = appName;
	}
	
	public void setArchiAvail(String archiAvail) {
	
		this.archiAvail = archiAvail;
	}
	
	public void setBusinessUnit(List<BusinessUnitTO> businessUnit) {
	
		this.businessUnit = businessUnit;
	}
	
	public void setBusinessUnitName(String businessUnitName) {
	
		this.businessUnitName = businessUnitName;
	}
	
	public void setBusinessUnitTO(BusinessUnitTO businessUnitTO) {
	
		this.businessUnitTO = businessUnitTO;
	}
	
	public void setCategory(String category) {
	
		this.category = category;
	}
	
	public void setCheck(boolean check) {
	
		this.check = check;
	}
	
	public void setCiAvail(String ciAvail) {
	
		this.ciAvail = ciAvail;
	}
	
	public void setCiResult(List<CIServerTO> ciResult) {
	
		this.ciResult = ciResult;
	}
	
	/**
	 * @param clientId
	 *                the clientId to set
	 */
	public void setClientId(Long clientId) {
	
		this.clientId = clientId;
	}
	
	/**
	 * @param clientIdlist
	 *                the clientIdlist to set
	 */
	public void setClientIdlist(List<Long> clientIdlist) {
	
		this.clientIdlist = clientIdlist;
	}
	
	public void setContextPathName(String contextPathName) {
	
		this.contextPathName = contextPathName;
	}
	
	/**
	 * @param cornStr
	 *                the cornStr to set
	 */
	public void setCornStr(String cornStr) {
	
		this.cornStr = cornStr;
	}
	
	public void setCreatedByDate(Date createdByDate) {
	
		this.createdByDate = createdByDate;
	}
	
	public void setDefinedApplications(List<Long> definedApplications) {
	
		this.definedApplications = definedApplications;
	}
	
	public void setDefinedComponentDown(List<Long> definedComponentDown) {
	
		this.definedComponentDown = definedComponentDown;
	}
	
	public void setDefinedComponentUp(List<Long> definedComponentUp) {
	
		this.definedComponentUp = definedComponentUp;
	}
	
	public void setDescription(String description) {
	
		this.description = description;
	}
	
	public void setEnvAppTO(Set<EnvironmentApplicationTO> envAppTO) {
	
		this.envAppTO = envAppTO;
	}
	
	public void setFirstResult(int firstResult) {
	
		this.firstResult = firstResult;
	}
	
	public void setMachineIp(String machineIp) {
	
		this.machineIp = machineIp;
	}
	
	public void setManufacturer(String manufacturer) {
	
		this.manufacturer = manufacturer;
	}
	
	public void setMapId(int mapId) {
	
		this.mapId = mapId;
	}
	
	public void setModifiedbyDate(Date modifiedbyDate) {
	
		this.modifiedbyDate = modifiedbyDate;
	}
	
	public void setNServices(List<ServiceTO> nServices) {
	
		NServices = nServices;
	}
	
	public void setOther(String other) {
	
		this.other = other;
	}
	
	public void setOwnerList(List<UserTO> ownerList) {
	
		this.ownerList = ownerList;
	}
	
	public void setPageNumber(long pageNumber) {
	
		this.pageNumber = pageNumber;
	}
	
	public void setProject(List<NamedEntityTO> project) {
	
		this.project = project;
	}
	
	public void setProjectName(String projectName) {
	
		this.projectName = projectName;
	}
	
	public void setProjectTO(ProjectsTO projectTO) {
	
		this.projectTO = projectTO;
	}
	
	public void setRelease(String release) {
	
		this.release = release;
	}
	
	/**
	 * @param releaseId
	 *                the releaseId to set
	 */
	public void setReleaseId(Long releaseId) {
	
		this.releaseId = releaseId;
	}
	
	public void setReleaseList(List<ApplicationReleaseTO> releaseList) {
	
		this.releaseList = releaseList;
	}
	
	public void setRepoResult(List<RepoTO> repoResult) {
	
		this.repoResult = repoResult;
	}
	
	/**
	 * @param requestId
	 *                the requestId to set
	 */
	public void setRequestId(Long requestId) {
	
		this.requestId = requestId;
	}
	
	public void setReservationses(Set<ReservationTO> reservationses) {
	
		this.reservationses = reservationses;
	}
	
	public void setSearchCount(long searchCount) {
	
		this.searchCount = searchCount;
	}
	
	public void setSelectedAppId(Long selectedAppId) {
	
		this.selectedAppId = selectedAppId;
	}
	
	public void setSelectedApplicationRelease(Long selectedApplicationRelease) {
	
		this.selectedApplicationRelease = selectedApplicationRelease;
	}
	
	public void setSelectedApplicationReleaseMinor(Long selectedApplicationReleaseMinor) {
	
		this.selectedApplicationReleaseMinor = selectedApplicationReleaseMinor;
	}
	
	public void setSelectedBusinessUnit(long selectedBusinessUnit) {
	
		this.selectedBusinessUnit = selectedBusinessUnit;
	}
	
	public void setSelectedLeftUserList(List<UserTO> selectedLeftUserList) {
	
		this.selectedLeftUserList = selectedLeftUserList;
	}
	
	public void setSelectedLeftUsers(List<Long> selectedLeftUsers) {
	
		this.selectedLeftUsers = selectedLeftUsers;
	}
	
	public void setSelectedOwner(Long selectedOwner) {
	
		this.selectedOwner = selectedOwner;
	}
	
	public void setSelectedProject(Long selectedProject) {
	
		this.selectedProject = selectedProject;
	}
	
	public void setSelectedService(Long selectedService) {
	
		this.selectedService = selectedService;
	}
	
	public void setSelectedStatus(Long selectedStatus) {
	
		this.selectedStatus = selectedStatus;
	}
	
	public void setSelectedUserGroup(Long selectedUserGroup) {
	
		this.selectedUserGroup = selectedUserGroup;
	}
	
	public void setSelectedUserName(List<Long> selectedUserName) {
	
		this.selectedUserName = selectedUserName;
	}
	
	public void setSourcePath(String sourcePath) {
	
		this.sourcePath = sourcePath;
	}
	
	public void setStatus(Long status) {
	
		this.status = status;
	}
	
	public void setStatuses(List<NamedEntityTO> statuses) {
	
		this.statuses = statuses;
	}
	
	public void setSubAppListLeft(List<NamedEntityTO> subAppListLeft) {
	
		this.subAppListLeft = subAppListLeft;
	}
	
	public void setTableSize(int tableSize) {
	
		this.tableSize = tableSize;
	}
	
	public void setTest(List<TestingPhaseTO> test) {
	
		this.test = test;
	}
	
	public void setThirdSupport(String thirdSupport) {
	
		this.thirdSupport = thirdSupport;
	}
	
	public void setTimeRationale(String timeRationale) {
	
		this.timeRationale = timeRationale;
	}
	
	public void setType(String type) {
	
		this.type = type;
	}
	
	public void setUserGroup(String userGroup) {
	
		this.userGroup = userGroup;
	}
	
	public void setUserGroupDetailses(Set<UserGroupDetailsTO> userGroupDetailses) {
	
		this.userGroupDetailses = userGroupDetailses;
	}
	
	public void setUserGroups(UserGroupTO userGroups) {
	
		this.userGroups = userGroups;
	}
	
	public void setUserGroupTO(Set<UserGroupTO> userGroupTO) {
	
		this.userGroupTO = userGroupTO;
	}
	
	public void setUserGrpId(Long userGrpId) {
	
		this.userGrpId = userGrpId;
	}
	
	public void setUserNameList(List<UserGroupTO> userNameList) {
	
		this.userNameList = userNameList;
	}
	
	public void setVendor(String vendor) {
	
		this.vendor = vendor;
	}
	
	public void setWorkflowCurrentTO(Set<WorkflowCurrentTO> workflowCurrentTO) {
	
		this.workflowCurrentTO = workflowCurrentTO;
	}
	
	public void setYServices(List<ServiceTO> yServices) {
	
		YServices = yServices;
	}
	
	public String getMobileAppType() {
	
		return mobileAppType;
	}
	
	public void setMobileAppType(String mobileAppType) {
	
		this.mobileAppType = mobileAppType;
	}
	
	public String getNativeAppType() {
	
		return nativeAppType;
	}
	
	public void setNativeAppType(String nativeAppType) {
	
		this.nativeAppType = nativeAppType;
	}
	
	public Long getSelectedTestingPhase() {
	
		return selectedTestingPhase;
	}
	
	public void setSelectedTestingPhase(Long selectedTestingPhase) {
	
		this.selectedTestingPhase = selectedTestingPhase;
	}
	
	public Long getSelectedReleasePlan() {
	
		return selectedReleasePlan;
	}
	
	public void setSelectedReleasePlan(Long selectedReleasePlan) {
	
		this.selectedReleasePlan = selectedReleasePlan;
	}
	
	public List<ReleasePlanningTO> getReleasePlanList() {
	
		return releasePlanList;
	}
	
	public void setReleasePlanList(List<ReleasePlanningTO> releasePlanList) {
	
		this.releasePlanList = releasePlanList;
	}
}