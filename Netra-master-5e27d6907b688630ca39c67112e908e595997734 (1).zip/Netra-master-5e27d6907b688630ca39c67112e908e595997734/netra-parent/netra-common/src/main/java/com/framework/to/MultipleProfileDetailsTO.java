package com.framework.to;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MultipleProfileDetailsTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -43015972432140543L;
	private Long multipleProfileId;
	private Long selectedApplication = null;
	private MultipleProfilesTO multipleProfiles;
	private ApplicationProfileTO profile;
	private Long selectedApplicationRelease = null;
	private Long selectedApplicationReleaseMinor = null;
	private ApplicationTO applicationTO;
	private Long selectedProfiles = null;
	private Long selectedMultipleProfile;
	private String appName;
	private String profileName;
	private List<MultipleProfileDetailsTO> mpList = new ArrayList<MultipleProfileDetailsTO>();
	private List<ApplicationReleaseTO> releaseList = new ArrayList<ApplicationReleaseTO>();
	private List<ApplicationProfileTO> allApplicationProfiles = new ArrayList<ApplicationProfileTO>();
	private Long profileId;
	private String subApplication;
	private int flag = 1;
	private String envName;
	private Long subEnvId;
	private Long selectedService;
	private Long clientId;
	private Long workFlowId;
	private String remark;
	private String startTimeStr;
	private String endTimeStr;
	private Date startTime;
	private Date endTime;
	private Long roleId;
	private boolean doProvisioning;
	private boolean doMonitoring;
	private Long existingEnvironment = null;
	private String taggedProjects;
	private List<EnvironmentSoftwareAttributeTO> envSoftwareAttributeList = new ArrayList<EnvironmentSoftwareAttributeTO>(0);
	private String cronExp;
	private String isScheduled = "N";
	private Long selectedEnvType;
	private List<ReleasePlanningTO> allReleasePlans = new ArrayList<>(0);
	private Long selectedReleasePlan;
	private Long selectedPhase;
	private Long selectedTestingPhase;
	
	public List<ApplicationProfileTO> getAllApplicationProfiles() {
	
		return allApplicationProfiles;
	}
	
	public ApplicationTO getApplicationTO() {
	
		return applicationTO;
	}
	
	public String getAppName() {
	
		return appName;
	}
	
	public Long getClientId() {
	
		return clientId;
	}
	
	public String getCronExp() {
	
		return cronExp;
	}
	
	/**
	 * @return the endTime
	 */
	public Date getEndTime() {
	
		return endTime;
	}
	
	/**
	 * @return the endTimeStr
	 */
	public String getEndTimeStr() {
	
		return endTimeStr;
	}
	
	public String getEnvName() {
	
		return envName;
	}
	
	public List<EnvironmentSoftwareAttributeTO> getEnvSoftwareAttributeList() {
	
		return envSoftwareAttributeList;
	}
	
	public Long getExistingEnvironment() {
	
		return existingEnvironment;
	}
	
	public int getFlag() {
	
		return flag;
	}
	
	public String getIsScheduled() {
	
		return isScheduled;
	}
	
	public List<MultipleProfileDetailsTO> getMpList() {
	
		return mpList;
	}
	
	public Long getMultipleProfileId() {
	
		return multipleProfileId;
	}
	
	public MultipleProfilesTO getMultipleProfiles() {
	
		return multipleProfiles;
	}
	
	public ApplicationProfileTO getProfile() {
	
		return profile;
	}
	
	public Long getProfileId() {
	
		return profileId;
	}
	
	public String getProfileName() {
	
		return profileName;
	}
	
	public List<ApplicationReleaseTO> getReleaseList() {
	
		return releaseList;
	}
	
	public String getRemark() {
	
		return remark;
	}
	
	public Long getRoleId() {
	
		return roleId;
	}
	
	public Long getSelectedApplication() {
	
		return selectedApplication;
	}
	
	public Long getSelectedApplicationRelease() {
	
		return selectedApplicationRelease;
	}
	
	public Long getSelectedApplicationReleaseMinor() {
	
		return selectedApplicationReleaseMinor;
	}
	
	public Long getSelectedMultipleProfile() {
	
		return selectedMultipleProfile;
	}
	
	public Long getSelectedProfiles() {
	
		return selectedProfiles;
	}
	
	public Long getSelectedService() {
	
		return selectedService;
	}
	
	/**
	 * @return the startTime
	 */
	public Date getStartTime() {
	
		return startTime;
	}
	
	/**
	 * @return the startTimeStr
	 */
	public String getStartTimeStr() {
	
		return startTimeStr;
	}
	
	public String getSubApplication() {
	
		return subApplication;
	}
	
	public Long getSubEnvId() {
	
		return subEnvId;
	}
	
	public String getTaggedProjects() {
	
		return taggedProjects;
	}
	
	public Long getWorkFlowId() {
	
		return workFlowId;
	}
	
	public boolean isDoMonitoring() {
	
		return doMonitoring;
	}
	
	public boolean isDoProvisioning() {
	
		return doProvisioning;
	}
	
	public void setAllApplicationProfiles(List<ApplicationProfileTO> allApplicationProfiles) {
	
		this.allApplicationProfiles = allApplicationProfiles;
	}
	
	public void setApplicationTO(ApplicationTO applicationTO) {
	
		this.applicationTO = applicationTO;
	}
	
	public void setAppName(String appName) {
	
		this.appName = appName;
	}
	
	public void setClientId(Long clientId) {
	
		this.clientId = clientId;
	}
	
	public void setCronExp(String cronExp) {
	
		this.cronExp = cronExp;
	}
	
	public void setDoMonitoring(boolean doMonitoring) {
	
		this.doMonitoring = doMonitoring;
	}
	
	public void setDoProvisioning(boolean doProvisioning) {
	
		this.doProvisioning = doProvisioning;
	}
	
	/**
	 * @param endTime
	 *                the endTime to set
	 */
	public void setEndTime(Date endTime) {
	
		this.endTime = endTime;
	}
	
	/**
	 * @param endTimeStr
	 *                the endTimeStr to set
	 */
	public void setEndTimeStr(String endTimeStr) {
	
		this.endTimeStr = endTimeStr;
	}
	
	public void setEnvName(String envName) {
	
		this.envName = envName;
	}
	
	public void setEnvSoftwareAttributeList(List<EnvironmentSoftwareAttributeTO> envSoftwareAttributeList) {
	
		this.envSoftwareAttributeList = envSoftwareAttributeList;
	}
	
	public void setExistingEnvironment(Long existingEnvironment) {
	
		this.existingEnvironment = existingEnvironment;
	}
	
	public void setFlag(int flag) {
	
		this.flag = flag;
	}
	
	public void setIsScheduled(String isScheduled) {
	
		this.isScheduled = isScheduled;
	}
	
	public void setMpList(List<MultipleProfileDetailsTO> mpList) {
	
		this.mpList = mpList;
	}
	
	public void setMultipleProfileId(Long multipleProfileId) {
	
		this.multipleProfileId = multipleProfileId;
	}
	
	public void setMultipleProfiles(MultipleProfilesTO multipleProfiles) {
	
		this.multipleProfiles = multipleProfiles;
	}
	
	public void setProfile(ApplicationProfileTO profile) {
	
		this.profile = profile;
	}
	
	public void setProfileId(Long profileId) {
	
		this.profileId = profileId;
	}
	
	public void setProfileName(String profileName) {
	
		this.profileName = profileName;
	}
	
	public void setReleaseList(List<ApplicationReleaseTO> releaseList) {
	
		this.releaseList = releaseList;
	}
	
	public void setRemark(String remark) {
	
		this.remark = remark;
	}
	
	public void setRoleId(Long roleId) {
	
		this.roleId = roleId;
	}
	
	public void setSelectedApplication(Long selectedApplication) {
	
		this.selectedApplication = selectedApplication;
	}
	
	public void setSelectedApplicationRelease(Long selectedApplicationRelease) {
	
		this.selectedApplicationRelease = selectedApplicationRelease;
	}
	
	public void setSelectedApplicationReleaseMinor(Long selectedApplicationReleaseMinor) {
	
		this.selectedApplicationReleaseMinor = selectedApplicationReleaseMinor;
	}
	
	public void setSelectedMultipleProfile(Long selectedMultipleProfile) {
	
		this.selectedMultipleProfile = selectedMultipleProfile;
	}
	
	public void setSelectedProfiles(Long selectedProfiles) {
	
		this.selectedProfiles = selectedProfiles;
	}
	
	public void setSelectedService(Long selectedService) {
	
		this.selectedService = selectedService;
	}
	
	/**
	 * @param startTime
	 *                the startTime to set
	 */
	public void setStartTime(Date startTime) {
	
		this.startTime = startTime;
	}
	
	/**
	 * @param startTimeStr
	 *                the startTimeStr to set
	 */
	public void setStartTimeStr(String startTimeStr) {
	
		this.startTimeStr = startTimeStr;
	}
	
	public void setSubApplication(String subApplication) {
	
		this.subApplication = subApplication;
	}
	
	public void setSubEnvId(Long subEnvId) {
	
		this.subEnvId = subEnvId;
	}
	
	public void setTaggedProjects(String taggedProjects) {
	
		this.taggedProjects = taggedProjects;
	}
	
	public void setWorkFlowId(Long workFlowId) {
	
		this.workFlowId = workFlowId;
	}
	
	public Long getSelectedEnvType() {
	
		return selectedEnvType;
	}
	
	public void setSelectedEnvType(Long selectedEnvType) {
	
		this.selectedEnvType = selectedEnvType;
	}
	
	public List<ReleasePlanningTO> getAllReleasePlans() {
	
		return allReleasePlans;
	}
	
	public void setAllReleasePlans(List<ReleasePlanningTO> allReleasePlans) {
	
		this.allReleasePlans = allReleasePlans;
	}
	
	public Long getSelectedReleasePlan() {
	
		return selectedReleasePlan;
	}
	
	public void setSelectedReleasePlan(Long selectedReleasePlan) {
	
		this.selectedReleasePlan = selectedReleasePlan;
	}
	
	public Long getSelectedPhase() {
	
		return selectedPhase;
	}
	
	public void setSelectedPhase(Long selectedPhase) {
	
		this.selectedPhase = selectedPhase;
	}
	
	public Long getSelectedTestingPhase() {
	
		return selectedTestingPhase;
	}
	
	public void setSelectedTestingPhase(Long selectedTestingPhase) {
	
		this.selectedTestingPhase = selectedTestingPhase;
	}
}