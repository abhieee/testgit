package com.framework.puppet.to;

import java.util.List;

public class VMTO {
	
	private String ip;
	private String dnsname;
	private String ostype;
	private String systype;
	private List<SoftwareListTO> appliList;
	
	public List<SoftwareListTO> getAppliList() {
	
		return appliList;
	}
	
	public String getDnsname() {
	
		return dnsname;
	}
	
	public String getIp() {
	
		return ip;
	}
	
	public String getOstype() {
	
		return ostype;
	}
	
	public String getSystype() {
	
		return systype;
	}
	
	public void setAppliList(List<SoftwareListTO> appliList) {
	
		this.appliList = appliList;
	}
	
	public void setDnsname(String dnsname) {
	
		this.dnsname = dnsname;
	}
	
	public void setIp(String ip) {
	
		this.ip = ip;
	}
	
	public void setOstype(String ostype) {
	
		this.ostype = ostype;
	}
	
	public void setSystype(String systype) {
	
		this.systype = systype;
	}
}
