package com.framework.to;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class TestExecutionResultsTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4658991418727963831L;
	private Long serviceRequestId;
	private Long selectedApplication;
	private Long appReleaseId;
	private String provider;
	private String status;
	private Date startTime;
	private Date endTime;
	private Long totalTests;
	private Long skipped;
	private Long failed;
	private Long passed;
	private ServiceRequestTO serviceRequestTO;
	private Set<TestExecutionResultsDetailsTO> testExecutionResultsDetailsSet = new HashSet<TestExecutionResultsDetailsTO>(0);
	private int tableSize;
	private long searchCount;
	private int firstResult = 1;
	private long pageNumber;
	private List<Long> selectedBusinessUnitNew = new ArrayList<>(0);
	private List<Long> selectedProjectNew = new ArrayList<>(0);
	private List<Long> selectedApplicationNew = new ArrayList<>(0);
	private List<Long> selectedEnvironmentNew = new ArrayList<>(0);
	private Set<Long> grpIds = new HashSet<Long>();
	private ApplicationReleaseTO releaseTO = null;
	
	public Long getAppReleaseId() {
	
		return appReleaseId;
	}
	
	public Date getEndTime() {
	
		return endTime;
	}
	
	public Long getFailed() {
	
		return failed;
	}
	
	public int getFirstResult() {
	
		return firstResult;
	}
	
	public Set<Long> getGrpIds() {
	
		return grpIds;
	}
	
	public long getPageNumber() {
	
		return pageNumber;
	}
	
	public Long getPassed() {
	
		return passed;
	}
	
	public String getProvider() {
	
		return provider;
	}
	
	public ApplicationReleaseTO getReleaseTO() {
	
		return releaseTO;
	}
	
	public long getSearchCount() {
	
		return searchCount;
	}
	
	public Long getSelectedApplication() {
	
		return selectedApplication;
	}
	
	public List<Long> getSelectedApplicationNew() {
	
		return selectedApplicationNew;
	}
	
	public List<Long> getSelectedBusinessUnitNew() {
	
		return selectedBusinessUnitNew;
	}
	
	public List<Long> getSelectedEnvironmentNew() {
	
		return selectedEnvironmentNew;
	}
	
	public List<Long> getSelectedProjectNew() {
	
		return selectedProjectNew;
	}
	
	public Long getServiceRequestId() {
	
		return serviceRequestId;
	}
	
	public ServiceRequestTO getServiceRequestTO() {
	
		return serviceRequestTO;
	}
	
	public Long getSkipped() {
	
		return skipped;
	}
	
	public Date getStartTime() {
	
		return startTime;
	}
	
	public String getStatus() {
	
		return status;
	}
	
	public int getTableSize() {
	
		return tableSize;
	}
	
	public Set<TestExecutionResultsDetailsTO> getTestExecutionResultsDetailsSet() {
	
		return testExecutionResultsDetailsSet;
	}
	
	public Long getTotalTests() {
	
		return totalTests;
	}
	
	public void setAppReleaseId(Long appReleaseId) {
	
		this.appReleaseId = appReleaseId;
	}
	
	public void setEndTime(Date endTime) {
	
		this.endTime = endTime;
	}
	
	public void setFailed(Long failed) {
	
		this.failed = failed;
	}
	
	public void setFirstResult(int firstResult) {
	
		this.firstResult = firstResult;
	}
	
	public void setGrpIds(Set<Long> grpIds) {
	
		this.grpIds = grpIds;
	}
	
	public void setPageNumber(long pageNumber) {
	
		this.pageNumber = pageNumber;
	}
	
	public void setPassed(Long passed) {
	
		this.passed = passed;
	}
	
	public void setProvider(String provider) {
	
		this.provider = provider;
	}
	
	public void setReleaseTO(ApplicationReleaseTO releaseTO) {
	
		this.releaseTO = releaseTO;
	}
	
	public void setSearchCount(long searchCount) {
	
		this.searchCount = searchCount;
	}
	
	public void setSelectedApplication(Long selectedApplication) {
	
		this.selectedApplication = selectedApplication;
	}
	
	public void setSelectedApplicationNew(List<Long> selectedApplicationNew) {
	
		this.selectedApplicationNew = selectedApplicationNew;
	}
	
	public void setSelectedBusinessUnitNew(List<Long> selectedBusinessUnitNew) {
	
		this.selectedBusinessUnitNew = selectedBusinessUnitNew;
	}
	
	public void setSelectedEnvironmentNew(List<Long> selectedEnvironmentNew) {
	
		this.selectedEnvironmentNew = selectedEnvironmentNew;
	}
	
	public void setSelectedProjectNew(List<Long> selectedProjectNew) {
	
		this.selectedProjectNew = selectedProjectNew;
	}
	
	public void setServiceRequestId(Long serviceRequestId) {
	
		this.serviceRequestId = serviceRequestId;
	}
	
	public void setServiceRequestTO(ServiceRequestTO serviceRequestTO) {
	
		this.serviceRequestTO = serviceRequestTO;
	}
	
	public void setSkipped(Long skipped) {
	
		this.skipped = skipped;
	}
	
	public void setStartTime(Date startTime) {
	
		this.startTime = startTime;
	}
	
	public void setStatus(String status) {
	
		this.status = status;
	}
	
	public void setTableSize(int tableSize) {
	
		this.tableSize = tableSize;
	}
	
	public void setTestExecutionResultsDetailsSet(Set<TestExecutionResultsDetailsTO> testExecutionResultsDetailsSet) {
	
		this.testExecutionResultsDetailsSet = testExecutionResultsDetailsSet;
	}
	
	public void setTotalTests(Long totalTests) {
	
		this.totalTests = totalTests;
	}
}
