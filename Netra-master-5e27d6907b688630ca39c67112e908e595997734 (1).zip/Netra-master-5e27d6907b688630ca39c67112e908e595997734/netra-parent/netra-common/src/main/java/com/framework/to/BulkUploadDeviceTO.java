/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.framework.to;

import java.io.Serializable;

/**
 * @author TCS
 */
public class BulkUploadDeviceTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4769082133270284826L;
	private String serverName;
	private String cpuSpeed;
	private String memory;
	private String distribution;
	private String version;
	private String packs;
	private String ipAdderss;
	private String host;
	private String machineArch;
	private String macAddress;
	private String swapMemory;
	private String storage;
	private String storageTier;
	private String platformName;
	private String systemType;
	private String imagePath;
	private Long status;
	private boolean validate = true;
	private String comments;
	private String osConf;
	private String username;
	private String password;
	private Long createdById;
	
	public String getComments() {
	
		return comments;
	}
	
	public String getCpuSpeed() {
	
		return cpuSpeed;
	}
	
	public String getDistribution() {
	
		return distribution;
	}
	
	public String getHost() {
	
		return host;
	}
	
	public String getImagePath() {
	
		return imagePath;
	}
	
	public String getIpAdderss() {
	
		return ipAdderss;
	}
	
	public String getMacAddress() {
	
		return macAddress;
	}
	
	public String getMachineArch() {
	
		return machineArch;
	}
	
	public String getMemory() {
	
		return memory;
	}
	
	public String getPacks() {
	
		return packs;
	}
	
	public String getPlatformName() {
	
		return platformName;
	}
	
	public String getServerName() {
	
		return serverName;
	}
	
	public Long getStatus() {
	
		return status;
	}
	
	public String getStorage() {
	
		return storage;
	}
	
	public String getStorageTier() {
	
		return storageTier;
	}
	
	public String getSwapMemory() {
	
		return swapMemory;
	}
	
	public String getSystemType() {
	
		return systemType;
	}
	
	public String getVersion() {
	
		return version;
	}
	
	public boolean isValidate() {
	
		return validate;
	}
	
	public void setComments(String comments) {
	
		this.comments = comments;
	}
	
	public void setCpuSpeed(String cpuSpeed) {
	
		this.cpuSpeed = cpuSpeed;
	}
	
	public void setDistribution(String distribution) {
	
		this.distribution = distribution;
	}
	
	public void setHost(String host) {
	
		this.host = host;
	}
	
	public void setImagePath(String imagePath) {
	
		this.imagePath = imagePath;
	}
	
	public void setIpAdderss(String ipAdderss) {
	
		this.ipAdderss = ipAdderss;
	}
	
	public void setMacAddress(String macAddress) {
	
		this.macAddress = macAddress;
	}
	
	public void setMachineArch(String machineArch) {
	
		this.machineArch = machineArch;
	}
	
	public void setMemory(String memory) {
	
		this.memory = memory;
	}
	
	public void setPacks(String packs) {
	
		this.packs = packs;
	}
	
	public void setPlatformName(String platformName) {
	
		this.platformName = platformName;
	}
	
	public void setServerName(String serverName) {
	
		this.serverName = serverName;
	}
	
	public void setStatus(Long status) {
	
		this.status = status;
	}
	
	public void setStorage(String storage) {
	
		this.storage = storage;
	}
	
	public void setStorageTier(String storageTier) {
	
		this.storageTier = storageTier;
	}
	
	public void setSwapMemory(String swapMemory) {
	
		this.swapMemory = swapMemory;
	}
	
	public void setSystemType(String systemType) {
	
		this.systemType = systemType;
	}
	
	public void setValidate(boolean validate) {
	
		this.validate = validate;
	}
	
	public void setVersion(String version) {
	
		this.version = version;
	}
	
	public String getOsConf() {
	
		return osConf;
	}
	
	public void setOsConf(String osConf) {
	
		this.osConf = osConf;
	}
	
	public String getUsername() {
	
		return username;
	}
	
	public void setUsername(String username) {
	
		this.username = username;
	}
	
	public String getPassword() {
	
		return password;
	}
	
	public void setPassword(String password) {
	
		this.password = password;
	}
	
	public Long getCreatedById() {
	
		return createdById;
	}
	
	public void setCreatedById(Long userId) {
	
		this.createdById = userId;
	}
}
