package com.framework.common;

public enum Resource {
	APPLICATION_SERVER("Application Server"), DATABASE("Database"), WEB_SERVER("Web Server");
	
	private String statusCode;
	
	private Resource(String s) {
	
		statusCode = s;
	}
	
	public String getStatusCode() {
	
		return statusCode;
	}
}
