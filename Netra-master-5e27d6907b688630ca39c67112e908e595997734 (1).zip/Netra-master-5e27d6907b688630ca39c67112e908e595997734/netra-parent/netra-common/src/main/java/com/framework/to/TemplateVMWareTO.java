package com.framework.to;

import java.io.Serializable;

public class TemplateVMWareTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6153194824771872818L;
	private Long id;
	private String vmTemplateName;
	private PlatformTemplateTO platformTemplate;
	
	public Long getId() {
	
		return id;
	}
	
	public PlatformTemplateTO getPlatformTemplate() {
	
		return platformTemplate;
	}
	
	public String getVmTemplateName() {
	
		return vmTemplateName;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setPlatformTemplate(PlatformTemplateTO platformTemplate) {
	
		this.platformTemplate = platformTemplate;
	}
	
	public void setVmTemplateName(String vmTemplateName) {
	
		this.vmTemplateName = vmTemplateName;
	}
}
