package com.framework.to;

import java.io.Serializable;

public class MailSetupMappingTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8975645430043859281L;
	private Long clientId;
	private Long id;
	private Long projectId;
	private Long mailSetupId;
	private BusinessUnitTO businessUnitTO = null;
	private ProjectsTO projectsTo = null;
	
	public BusinessUnitTO getBusinessUnitTO() {
	
		return businessUnitTO;
	}
	
	public Long getClientId() {
	
		return clientId;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public Long getMailSetupId() {
	
		return mailSetupId;
	}
	
	public Long getProjectId() {
	
		return projectId;
	}
	
	public ProjectsTO getProjectsTo() {
	
		return projectsTo;
	}
	
	public void setBusinessUnitTO(BusinessUnitTO businessUnitTO) {
	
		this.businessUnitTO = businessUnitTO;
	}
	
	public void setClientId(Long clientId) {
	
		this.clientId = clientId;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setMailSetupId(Long mailSetupId) {
	
		this.mailSetupId = mailSetupId;
	}
	
	public void setProjectId(Long projectId) {
	
		this.projectId = projectId;
	}
	
	public void setProjectsTo(ProjectsTO projectsTo) {
	
		this.projectsTo = projectsTo;
	}
}
