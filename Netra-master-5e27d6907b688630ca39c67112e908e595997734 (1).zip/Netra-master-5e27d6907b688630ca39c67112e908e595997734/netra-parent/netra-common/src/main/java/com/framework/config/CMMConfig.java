package com.framework.config;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.ConfigurationFactory;
import com.framework.common.CMMConstants;

public class CMMConfig {
	
	protected CMMConfig() {
	
	}
	
	private static CMMConfig cmmConfig = null;
	private Configuration config = null;
	
	public synchronized static CMMConfig getInstance() throws ConfigurationException {
	
		if (cmmConfig == null) {
			cmmConfig = new CMMConfig();
			cmmConfig.readConfiguration();
		}
		return cmmConfig;
	}
	
	private CMMConfig readConfiguration() throws ConfigurationException {
	
		ConfigurationFactory factory = new ConfigurationFactory();
		factory.setConfigurationURL(getClass().getResource(CMMConstants.Framework.ROOT_CONFIG_FILE));
		config = factory.getConfiguration();
		return cmmConfig;
	}
	
	public String getString(String key) {
	
		return this.config.getString(key);
	}
	
	public String[] getStringArray(String key) {
	
		return this.config.getStringArray(key);
	}
}
