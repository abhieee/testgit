package com.framework.to;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * This class declares the transfer object that carries user information across the application.
 *
 * @author TCS
 */
public class SoftwareTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1721625398031049610L;
	private String type;
	private String manufacturer;
	private Long applicationProfileDetailId;
	private String model;
	private Set<SoftwareconfigTO> softwareconfigs = new HashSet<SoftwareconfigTO>(0);
	private ApplicationProfilesServerSoftwareSetTO softwareSet = new ApplicationProfilesServerSoftwareSetTO();
	private String version = null;
	private String patch = null;
	private Date effectiveDate = null;
	private String location = null;
	private String effectiveRelease = null;
	private String remark = null;
	private Long softwareconfigsId;
	private String status = null;
	private Long statusId = null;
	private Date createdByDate;
	private Date modifiedbyDate;
	private Long clientId;
	private Long projectId;
	private Date fromDate;
	private Date toDate;
	private String installRequired;
	private int tableSize;
	private long pageNumber;
	private long searchCount;
	private int firstResult = 1;
	private boolean installationFlag = false;
	private String targetFlag;
	private String installerLocationLinux;
	private String installerLocationWindows;
	private String targetLocationLinux;
	private String targetLocationWindows;
	private List<ParameterTO> allParameters = null;
	private List<Long> parameters = null;
	private String automationTool;
	private List<SoftwareTemplatePropertyTO> prop = new ArrayList<SoftwareTemplatePropertyTO>();
	List<ZabbixSoftwareMappingTO> zabbixTemplatesList = new ArrayList<ZabbixSoftwareMappingTO>(0);
	List<ZabbixSoftwareMappingTO> selectedZabbixTemplates = new ArrayList<ZabbixSoftwareMappingTO>(0);
	
	public String getHostname() {
	
		return hostname;
	}
	
	public void setHostname(String hostname) {
	
		this.hostname = hostname;
	}
	
	public String getIp() {
	
		return ip;
	}
	
	public void setIp(String ip) {
	
		this.ip = ip;
	}
	
	List<Long> selectedTemplates = new ArrayList<>();
	String hostname;
	String ip;
	private List<Long> tasks = new ArrayList<>();
	
	public SoftwareTO() {
	
	}
	
	public SoftwareTO(String name, String type, String manufacturer, String model) {
	
		this.type = type;
		this.manufacturer = manufacturer;
		this.model = model;
	}
	
	public SoftwareTO(String name, String type, String manufacturer, String model, Set<SoftwareconfigTO> softwareconfigs) {
	
		this.type = type;
		this.manufacturer = manufacturer;
		this.model = model;
		this.softwareconfigs = softwareconfigs;
	}
	
	public void copy(SoftwareTO softwareTO) {
	
		if (softwareTO == null) {
			softwareTO = new SoftwareTO();
		}
		if ((softwareTO.getName() == null) || !softwareTO.getName().equals(this.getName())) {
			softwareTO.setName(this.getName());
		}
		if ((softwareTO.getType() == null) || !softwareTO.getType().equals(this.getType())) {
			softwareTO.setType(this.getType());
		}
		if ((softwareTO.getManufacturer() == null) || !softwareTO.getManufacturer().equals(this.getManufacturer())) {
			softwareTO.setManufacturer(this.getManufacturer());
		}
		if ((softwareTO.getModel() == null) || !softwareTO.getModel().equals(this.getModel())) {
			softwareTO.setModel(this.getModel());
		}
	}
	
	public List<ParameterTO> getAllParameters() {
	
		return allParameters;
	}
	
	public Long getApplicationProfileDetailId() {
	
		return applicationProfileDetailId;
	}
	
	public String getAutomationTool() {
	
		return automationTool;
	}
	
	public Long getClientId() {
	
		return clientId;
	}
	
	public Date getCreatedByDate() {
	
		return createdByDate;
	}
	
	public Date getEffectiveDate() {
	
		return effectiveDate;
	}
	
	public String getEffectiveRelease() {
	
		return effectiveRelease;
	}
	
	public int getFirstResult() {
	
		return firstResult;
	}
	
	public Date getFromDate() {
	
		return fromDate;
	}
	
	public String getInstallerLocationLinux() {
	
		return installerLocationLinux;
	}
	
	public String getInstallerLocationWindows() {
	
		return installerLocationWindows;
	}
	
	/**
	 * @return the installRequired
	 */
	public String getInstallRequired() {
	
		return installRequired;
	}
	
	public String getLocation() {
	
		return location;
	}
	
	public String getManufacturer() {
	
		return this.manufacturer;
	}
	
	public String getModel() {
	
		return this.model;
	}
	
	public Date getModifiedbyDate() {
	
		return modifiedbyDate;
	}
	
	public long getPageNumber() {
	
		return pageNumber;
	}
	
	public List<Long> getParameters() {
	
		return parameters;
	}
	
	public String getPatch() {
	
		return patch;
	}
	
	public Long getProjectId() {
	
		return projectId;
	}
	
	public List<SoftwareTemplatePropertyTO> getProp() {
	
		return prop;
	}
	
	public String getRemark() {
	
		return remark;
	}
	
	public long getSearchCount() {
	
		return searchCount;
	}
	
	public List<Long> getSelectedTemplates() {
	
		return selectedTemplates;
	}
	
	public List<ZabbixSoftwareMappingTO> getSelectedZabbixTemplates() {
	
		return selectedZabbixTemplates;
	}
	
	public Set<SoftwareconfigTO> getSoftwareconfigs() {
	
		return this.softwareconfigs;
	}
	
	public Long getSoftwareconfigsId() {
	
		return softwareconfigsId;
	}
	
	public ApplicationProfilesServerSoftwareSetTO getSoftwareSet() {
	
		return softwareSet;
	}
	
	public String getStatus() {
	
		return status;
	}
	
	public Long getStatusId() {
	
		return statusId;
	}
	
	public int getTableSize() {
	
		return tableSize;
	}
	
	public String getTargetFlag() {
	
		return targetFlag;
	}
	
	public String getTargetLocationLinux() {
	
		return targetLocationLinux;
	}
	
	public String getTargetLocationWindows() {
	
		return targetLocationWindows;
	}
	
	public Date getToDate() {
	
		return toDate;
	}
	
	public String getType() {
	
		return this.type;
	}
	
	public String getVersion() {
	
		return version;
	}
	
	public List<ZabbixSoftwareMappingTO> getZabbixTemplatesList() {
	
		return zabbixTemplatesList;
	}
	
	public boolean isInstallationFlag() {
	
		return installationFlag;
	}
	
	public void setAllParameters(List<ParameterTO> allParameters) {
	
		this.allParameters = allParameters;
	}
	
	public void setApplicationProfileDetailId(Long applicationProfileDetailId) {
	
		this.applicationProfileDetailId = applicationProfileDetailId;
	}
	
	public void setAutomationTool(String automationTool) {
	
		this.automationTool = automationTool;
	}
	
	public void setClientId(Long clientId) {
	
		this.clientId = clientId;
	}
	
	public void setCreatedByDate(Date createdByDate) {
	
		this.createdByDate = createdByDate;
	}
	
	public void setEffectiveDate(Date effectiveDate) {
	
		this.effectiveDate = effectiveDate;
	}
	
	public void setEffectiveRelease(String effectiveRelease) {
	
		this.effectiveRelease = effectiveRelease;
	}
	
	public void setFirstResult(int firstResult) {
	
		this.firstResult = firstResult;
	}
	
	public void setFromDate(Date fromDate) {
	
		this.fromDate = fromDate;
	}
	
	public void setInstallationFlag(boolean installationFlag) {
	
		this.installationFlag = installationFlag;
	}
	
	public void setInstallerLocationLinux(String installerLocationLinux) {
	
		this.installerLocationLinux = installerLocationLinux;
	}
	
	public void setInstallerLocationWindows(String installerLocationWindows) {
	
		this.installerLocationWindows = installerLocationWindows;
	}
	
	/**
	 * @param installRequired
	 *                the installRequired to set
	 */
	public void setInstallRequired(String installRequired) {
	
		this.installRequired = installRequired;
	}
	
	public void setLocation(String location) {
	
		this.location = location;
	}
	
	public void setManufacturer(String manufacturer) {
	
		this.manufacturer = manufacturer;
	}
	
	public void setModel(String model) {
	
		this.model = model;
	}
	
	public void setModifiedbyDate(Date modifiedbyDate) {
	
		this.modifiedbyDate = modifiedbyDate;
	}
	
	public void setPageNumber(long pageNumber) {
	
		this.pageNumber = pageNumber;
	}
	
	public void setParameters(List<Long> parameters) {
	
		this.parameters = parameters;
	}
	
	public void setPatch(String patch) {
	
		this.patch = patch;
	}
	
	public void setProjectId(Long projectId) {
	
		this.projectId = projectId;
	}
	
	public void setProp(List<SoftwareTemplatePropertyTO> prop) {
	
		this.prop = prop;
	}
	
	public void setRemark(String remark) {
	
		this.remark = remark;
	}
	
	public void setSearchCount(long searchCount) {
	
		this.searchCount = searchCount;
	}
	
	public void setSelectedTemplates(List<Long> selectedTemplates) {
	
		this.selectedTemplates = selectedTemplates;
	}
	
	public void setSelectedZabbixTemplates(List<ZabbixSoftwareMappingTO> selectedZabbixTemplates) {
	
		this.selectedZabbixTemplates = selectedZabbixTemplates;
	}
	
	public void setSoftwareconfigs(Set<SoftwareconfigTO> softwareconfigs) {
	
		this.softwareconfigs = softwareconfigs;
	}
	
	public void setSoftwareconfigsId(Long softwareconfigsId) {
	
		this.softwareconfigsId = softwareconfigsId;
	}
	
	public void setSoftwareSet(ApplicationProfilesServerSoftwareSetTO softwareSet) {
	
		this.softwareSet = softwareSet;
	}
	
	public void setStatus(String status) {
	
		this.status = status;
	}
	
	public void setStatusId(Long statusId) {
	
		this.statusId = statusId;
	}
	
	public void setTableSize(int tableSize) {
	
		this.tableSize = tableSize;
	}
	
	public void setTargetFlag(String targetFlag) {
	
		this.targetFlag = targetFlag;
	}
	
	public void setTargetLocationLinux(String targetLocationLinux) {
	
		this.targetLocationLinux = targetLocationLinux;
	}
	
	public void setTargetLocationWindows(String targetLocationWindows) {
	
		this.targetLocationWindows = targetLocationWindows;
	}
	
	public void setToDate(Date toDate) {
	
		this.toDate = toDate;
	}
	
	public void setType(String type) {
	
		this.type = type;
	}
	
	public void setVersion(String version) {
	
		this.version = version;
	}
	
	public void setZabbixTemplatesList(List<ZabbixSoftwareMappingTO> zabbixTemplatesList) {
	
		this.zabbixTemplatesList = zabbixTemplatesList;
	}
	
	public List<Long> getTasks() {
	
		return tasks;
	}
	
	public void setTasks(List<Long> tasks) {
	
		this.tasks = tasks;
	}
}
