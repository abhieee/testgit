package com.framework.security;

public class ContactDTO {
	
	String mail;
	String sap;
	
	public String getSap() {
	
		return sap;
	}
	
	public void setSap(String sap) {
	
		this.sap = sap;
	}
	
	public String getMail() {
	
		return mail;
	}
	
	public void setMail(String mail) {
	
		this.mail = mail;
	}
	
	@Override
	public String toString() {
	
		StringBuilder contactDTOStr = new StringBuilder("Person=[");
		contactDTOStr.append(" mail = " + mail);
		contactDTOStr.append(" ]");
		return contactDTOStr.toString();
	}
}
