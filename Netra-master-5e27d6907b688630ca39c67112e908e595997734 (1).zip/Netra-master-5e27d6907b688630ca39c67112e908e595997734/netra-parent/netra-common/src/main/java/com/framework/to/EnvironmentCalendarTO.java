/**
 *
 */
package com.framework.to;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @author TCS
 */
public class EnvironmentCalendarTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8657175419272746891L;
	private Long applicationId;
	private String environmentName;
	private Long status;
	private String envStatus;
	private Set<EnvironmentDetailsTO> environmentDetails = new HashSet<EnvironmentDetailsTO>(0);
	private Set<ReservationTO> reservationses = new HashSet<ReservationTO>(0);
	private List<ApplicationTO> allApplications = new ArrayList<ApplicationTO>();
	private List<EnvironmentTO> envList = new ArrayList<EnvironmentTO>();
	private Set<WorkflowCurrentTO> workflowCurrentTO = new HashSet<WorkflowCurrentTO>();
	private List<Long> definedApplications = null;
	private Long selectedApplication = null;
	private String applicationName;
	private Date createdByDate;
	private Date modifiedbyDate;
	private String project;
	private Long releaseId;
	private String businessUnit;
	private TestingPhaseTO testingPhaseTO;
	private Long selectedTestingCycle;
	private List<TestingPhaseTO> allTestingCycles = new ArrayList<TestingPhaseTO>();
	private ApplicationReleaseTO releaseTO;
	private Date fromDate;
	private Date toDate;
	private Long profileId;
	private Long clientId;
	private Long projectId;
	private ApplicationProfileTO applicationProfileTO;
	private Long parentEnv;
	private String envType;
	private String propertyName;
	private String allocationMode;
	private Long serviceId;
	private StatusTO statusTO;
	private Set<EnvironmentApplicationTO> environmentApplicationTO = new HashSet<EnvironmentApplicationTO>(0);
	private Set<EnvironmentApplicationTO> environmentApplicationSet = new HashSet<EnvironmentApplicationTO>(0);
	int flag = 1;
	
	public List<ApplicationTO> getAllApplications() {
	
		return allApplications;
	}
	
	public String getAllocationMode() {
	
		return allocationMode;
	}
	
	public List<TestingPhaseTO> getAllTestingCycles() {
	
		return allTestingCycles;
	}
	
	public Long getApplicationId() {
	
		return applicationId;
	}
	
	public String getApplicationName() {
	
		return applicationName;
	}
	
	public ApplicationProfileTO getApplicationProfileTO() {
	
		return applicationProfileTO;
	}
	
	public String getBusinessUnit() {
	
		return businessUnit;
	}
	
	public Long getClientId() {
	
		return clientId;
	}
	
	public Date getCreatedByDate() {
	
		return createdByDate;
	}
	
	public List<Long> getDefinedApplications() {
	
		return definedApplications;
	}
	
	public Set<EnvironmentApplicationTO> getEnvironmentApplicationSet() {
	
		return environmentApplicationSet;
	}
	
	public Set<EnvironmentApplicationTO> getEnvironmentApplicationTO() {
	
		return environmentApplicationTO;
	}
	
	public Set<EnvironmentDetailsTO> getEnvironmentDetails() {
	
		return environmentDetails;
	}
	
	public String getEnvironmentName() {
	
		return environmentName;
	}
	
	public List<EnvironmentTO> getEnvList() {
	
		return envList;
	}
	
	public String getEnvStatus() {
	
		return envStatus;
	}
	
	public String getEnvType() {
	
		return envType;
	}
	
	public int getFlag() {
	
		return flag;
	}
	
	public Date getFromDate() {
	
		return fromDate;
	}
	
	public Date getModifiedbyDate() {
	
		return modifiedbyDate;
	}
	
	public Long getParentEnv() {
	
		return parentEnv;
	}
	
	public Long getProfileId() {
	
		return profileId;
	}
	
	public String getProject() {
	
		return project;
	}
	
	public Long getProjectId() {
	
		return projectId;
	}
	
	public String getPropertyName() {
	
		return propertyName;
	}
	
	public Long getReleaseId() {
	
		return releaseId;
	}
	
	public ApplicationReleaseTO getReleaseTO() {
	
		return releaseTO;
	}
	
	public Set<ReservationTO> getReservationses() {
	
		return reservationses;
	}
	
	public Long getSelectedApplication() {
	
		return selectedApplication;
	}
	
	public Long getSelectedTestingCycle() {
	
		return selectedTestingCycle;
	}
	
	public Long getServiceId() {
	
		return serviceId;
	}
	
	public Long getStatus() {
	
		return status;
	}
	
	public StatusTO getStatusTO() {
	
		return statusTO;
	}
	
	public TestingPhaseTO getTestingPhaseTO() {
	
		return testingPhaseTO;
	}
	
	public Date getToDate() {
	
		return toDate;
	}
	
	public Set<WorkflowCurrentTO> getWorkflowCurrentTO() {
	
		return workflowCurrentTO;
	}
	
	public void setAllApplications(List<ApplicationTO> allApplications) {
	
		this.allApplications = allApplications;
	}
	
	public void setAllocationMode(String allocationMode) {
	
		this.allocationMode = allocationMode;
	}
	
	public void setAllTestingCycles(List<TestingPhaseTO> allTestingCycles) {
	
		this.allTestingCycles = allTestingCycles;
	}
	
	public void setApplicationId(Long applicationId) {
	
		this.applicationId = applicationId;
	}
	
	public void setApplicationName(String applicationName) {
	
		this.applicationName = applicationName;
	}
	
	public void setApplicationProfileTO(ApplicationProfileTO applicationProfileTO) {
	
		this.applicationProfileTO = applicationProfileTO;
	}
	
	public void setBusinessUnit(String businessUnit) {
	
		this.businessUnit = businessUnit;
	}
	
	public void setClientId(Long clientId) {
	
		this.clientId = clientId;
	}
	
	public void setCreatedByDate(Date createdByDate) {
	
		this.createdByDate = createdByDate;
	}
	
	public void setDefinedApplications(List<Long> definedApplications) {
	
		this.definedApplications = definedApplications;
	}
	
	public void setEnvironmentApplicationSet(Set<EnvironmentApplicationTO> environmentApplicationSet) {
	
		this.environmentApplicationSet = environmentApplicationSet;
	}
	
	public void setEnvironmentApplicationTO(Set<EnvironmentApplicationTO> environmentApplicationTO) {
	
		this.environmentApplicationTO = environmentApplicationTO;
	}
	
	public void setEnvironmentDetails(Set<EnvironmentDetailsTO> environmentDetails) {
	
		this.environmentDetails = environmentDetails;
	}
	
	public void setEnvironmentName(String environmentName) {
	
		this.environmentName = environmentName;
	}
	
	public void setEnvList(List<EnvironmentTO> envList) {
	
		this.envList = envList;
	}
	
	public void setEnvStatus(String envStatus) {
	
		this.envStatus = envStatus;
	}
	
	public void setEnvType(String envType) {
	
		this.envType = envType;
	}
	
	public void setFlag(int flag) {
	
		this.flag = flag;
	}
	
	public void setFromDate(Date fromDate) {
	
		this.fromDate = fromDate;
	}
	
	public void setModifiedbyDate(Date modifiedbyDate) {
	
		this.modifiedbyDate = modifiedbyDate;
	}
	
	public void setParentEnv(Long parentEnv) {
	
		this.parentEnv = parentEnv;
	}
	
	public void setProfileId(Long profileId) {
	
		this.profileId = profileId;
	}
	
	public void setProject(String project) {
	
		this.project = project;
	}
	
	public void setProjectId(Long projectId) {
	
		this.projectId = projectId;
	}
	
	public void setPropertyName(String propertyName) {
	
		this.propertyName = propertyName;
	}
	
	public void setReleaseId(Long releaseId) {
	
		this.releaseId = releaseId;
	}
	
	public void setReleaseTO(ApplicationReleaseTO releaseTO) {
	
		this.releaseTO = releaseTO;
	}
	
	public void setReservationses(Set<ReservationTO> reservationses) {
	
		this.reservationses = reservationses;
	}
	
	public void setSelectedApplication(Long selectedApplication) {
	
		this.selectedApplication = selectedApplication;
	}
	
	public void setSelectedTestingCycle(Long selectedTestingCycle) {
	
		this.selectedTestingCycle = selectedTestingCycle;
	}
	
	public void setServiceId(Long serviceId) {
	
		this.serviceId = serviceId;
	}
	
	public void setStatus(Long status) {
	
		this.status = status;
	}
	
	public void setStatusTO(StatusTO statusTO) {
	
		this.statusTO = statusTO;
	}
	
	public void setTestingPhaseTO(TestingPhaseTO testingPhaseTO) {
	
		this.testingPhaseTO = testingPhaseTO;
	}
	
	public void setToDate(Date toDate) {
	
		this.toDate = toDate;
	}
	
	public void setWorkflowCurrentTO(Set<WorkflowCurrentTO> workflowCurrentTO) {
	
		this.workflowCurrentTO = workflowCurrentTO;
	}
}
