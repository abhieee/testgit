package com.framework.to;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class CollectionAndProjectsTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3419266004428101343L;
	private String collectionName;
	private List<String> projectList = new ArrayList<String>(0);
	
	public String getCollectionName() {
	
		return collectionName;
	}
	
	public List<String> getProjectList() {
	
		return projectList;
	}
	
	public void setCollectionName(String collectionName) {
	
		this.collectionName = collectionName;
	}
	
	public void setProjectList(List<String> projectList) {
	
		this.projectList = projectList;
	}
}
