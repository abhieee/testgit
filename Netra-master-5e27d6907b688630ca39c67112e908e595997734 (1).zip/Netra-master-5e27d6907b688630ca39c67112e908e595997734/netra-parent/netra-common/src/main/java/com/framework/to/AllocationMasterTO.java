package com.framework.to;

public class AllocationMasterTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
}
