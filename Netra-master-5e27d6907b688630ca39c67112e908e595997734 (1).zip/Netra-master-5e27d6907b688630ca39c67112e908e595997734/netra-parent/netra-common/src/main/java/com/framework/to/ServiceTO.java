package com.framework.to;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ServiceTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String description;
	private Long selectedCatalogType;
	private Set<BusinessUnitTO> allBusinessUnits = new HashSet<BusinessUnitTO>();
	private Set<ServiceTypeTO> allServiceTypes = new HashSet<ServiceTypeTO>();
	private Set<BusinessUnitTO> selectedAllBUnits = new HashSet<BusinessUnitTO>();
	private Set<ServiceClientTO> serviceClientTO = new HashSet<ServiceClientTO>(0);
	private ServiceTypeTO serviceTypeTO = new ServiceTypeTO();
	private Long status;
	private Long selectedStatus;
	private StatusTO statusTO;
	private List<StatusTO> statusList = new ArrayList<StatusTO>(0);
	private String statusDesc;
	private String flag;
	private String subServiceFlag;
	private boolean lastPhase;
	private int tableSize = 15;
	private long pageNumber = 1;
	private int firstResult = 0;
	private long searchCount;
	private String servName;
	private List<Long> selectedRoles;
	private List<Long> selectedClients;
	
	public Set<BusinessUnitTO> getAllBusinessUnits() {
	
		return allBusinessUnits;
	}
	
	public Set<ServiceTypeTO> getAllServiceTypes() {
	
		return allServiceTypes;
	}
	
	public String getDescription() {
	
		return description;
	}
	
	public int getFirstResult() {
	
		return firstResult;
	}
	
	public String getFlag() {
	
		return flag;
	}
	
	public long getPageNumber() {
	
		return pageNumber;
	}
	
	public long getSearchCount() {
	
		return searchCount;
	}
	
	public Set<BusinessUnitTO> getSelectedAllBUnits() {
	
		return selectedAllBUnits;
	}
	
	public Long getSelectedCatalogType() {
	
		return selectedCatalogType;
	}
	
	public List<Long> getSelectedClients() {
	
		return selectedClients;
	}
	
	public List<Long> getSelectedRoles() {
	
		return selectedRoles;
	}
	
	public Long getSelectedStatus() {
	
		return selectedStatus;
	}
	
	public Set<ServiceClientTO> getServiceClientTO() {
	
		return serviceClientTO;
	}
	
	public ServiceTypeTO getServiceTypeTO() {
	
		return serviceTypeTO;
	}
	
	public String getServName() {
	
		return servName;
	}
	
	public Long getStatus() {
	
		return status;
	}
	
	public String getStatusDesc() {
	
		return statusDesc;
	}
	
	public List<StatusTO> getStatusList() {
	
		return statusList;
	}
	
	public StatusTO getStatusTO() {
	
		return statusTO;
	}
	
	public String getSubServiceFlag() {
	
		return subServiceFlag;
	}
	
	public int getTableSize() {
	
		return tableSize;
	}
	
	public boolean isLastPhase() {
	
		return lastPhase;
	}
	
	public void setAllBusinessUnits(Set<BusinessUnitTO> allBusinessUnits) {
	
		this.allBusinessUnits = allBusinessUnits;
	}
	
	public void setAllServiceTypes(Set<ServiceTypeTO> allServiceTypes) {
	
		this.allServiceTypes = allServiceTypes;
	}
	
	public void setDescription(String description) {
	
		this.description = description;
	}
	
	public void setFirstResult(int firstResult) {
	
		this.firstResult = firstResult;
	}
	
	public void setFlag(String flag) {
	
		this.flag = flag;
	}
	
	public void setLastPhase(boolean lastPhase) {
	
		this.lastPhase = lastPhase;
	}
	
	public void setPageNumber(long pageNumber) {
	
		this.pageNumber = pageNumber;
	}
	
	public void setSearchCount(long searchCount) {
	
		this.searchCount = searchCount;
	}
	
	public void setSelectedAllBUnits(Set<BusinessUnitTO> selectedAllBUnits) {
	
		this.selectedAllBUnits = selectedAllBUnits;
	}
	
	public void setSelectedCatalogType(Long selectedCatalogType) {
	
		this.selectedCatalogType = selectedCatalogType;
	}
	
	public void setSelectedClients(List<Long> selectedClients) {
	
		this.selectedClients = selectedClients;
	}
	
	public void setSelectedRoles(List<Long> selectedRoles) {
	
		this.selectedRoles = selectedRoles;
	}
	
	public void setSelectedStatus(Long selectedStatus) {
	
		this.selectedStatus = selectedStatus;
	}
	
	public void setServiceClientTO(Set<ServiceClientTO> serviceClientTO) {
	
		this.serviceClientTO = serviceClientTO;
	}
	
	public void setServiceTypeTO(ServiceTypeTO serviceTypeTO) {
	
		this.serviceTypeTO = serviceTypeTO;
	}
	
	public void setServName(String servName) {
	
		this.servName = servName;
	}
	
	public void setStatus(Long status) {
	
		this.status = status;
	}
	
	public void setStatusDesc(String statusDesc) {
	
		this.statusDesc = statusDesc;
	}
	
	public void setStatusList(List<StatusTO> statusList) {
	
		this.statusList = statusList;
	}
	
	public void setStatusTO(StatusTO statusTO) {
	
		this.statusTO = statusTO;
	}
	
	public void setSubServiceFlag(String subServiceFlag) {
	
		this.subServiceFlag = subServiceFlag;
	}
	
	public void setTableSize(int tableSize) {
	
		this.tableSize = tableSize;
	}
}
