package com.framework.to;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class ApplicationProfilesServerSoftwareSetTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6903902121448270142L;
	private Long softwareConfigId;
	private Map<Long, String> parameters = new HashMap<Long, String>();
	private String installRequired;
	
	public ApplicationProfilesServerSoftwareSetTO() {
	
		parameters = new HashMap<Long, String>();
	}
	
	public String getInstallRequired() {
	
		return installRequired;
	}
	
	public Map<Long, String> getParameters() {
	
		return parameters;
	}
	
	public Long getSoftwareConfigId() {
	
		return softwareConfigId;
	}
	
	public void setInstallRequired(String installRequired) {
	
		this.installRequired = installRequired;
	}
	
	public void setParameters(Map<Long, String> parameters) {
	
		this.parameters = parameters;
	}
	
	public void setSoftwareConfigId(Long softwareConfigId) {
	
		this.softwareConfigId = softwareConfigId;
	}
}
