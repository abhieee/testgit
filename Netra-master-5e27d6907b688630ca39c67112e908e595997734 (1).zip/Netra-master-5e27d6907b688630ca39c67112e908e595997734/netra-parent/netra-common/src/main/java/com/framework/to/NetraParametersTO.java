package com.framework.to;

import java.io.Serializable;

public class NetraParametersTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4542824069415904699L;
	private long id;
	private String label;
	
	public long getId() {
	
		return id;
	}
	
	public String getLabel() {
	
		return label;
	}
	
	public void setId(long id) {
	
		this.id = id;
	}
	
	public void setLabel(String label) {
	
		this.label = label;
	}
}
