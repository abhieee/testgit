/**
 *
 */
package com.framework.to;

import java.util.Set;

/**
 * @author TCS
 */
public class ApplicationTreeTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7624943363689683603L;
	private Set<BusinessUnitTO> businessUnit;
	private Set<NamedEntityTO> project;
	private String appName;
	private String description;
	private String userGroup;
	private Set<NamedEntityTO> userNameList;
	private Long subAppId;
	private String selectedUserName;
	
	public String getAppName() {
	
		return appName;
	}
	
	public Set<BusinessUnitTO> getBusinessUnit() {
	
		return businessUnit;
	}
	
	public String getDescription() {
	
		return description;
	}
	
	public Set<NamedEntityTO> getProject() {
	
		return project;
	}
	
	public String getSelectedUserName() {
	
		return selectedUserName;
	}
	
	public Long getSubAppId() {
	
		return subAppId;
	}
	
	public String getUserGroup() {
	
		return userGroup;
	}
	
	public Set<NamedEntityTO> getUserNameList() {
	
		return userNameList;
	}
	
	public void setAppName(String appName) {
	
		this.appName = appName;
	}
	
	public void setBusinessUnit(Set<BusinessUnitTO> businessUnit) {
	
		this.businessUnit = businessUnit;
	}
	
	public void setDescription(String description) {
	
		this.description = description;
	}
	
	public void setProject(Set<NamedEntityTO> project) {
	
		this.project = project;
	}
	
	public void setSelectedUserName(String selectedUserName) {
	
		this.selectedUserName = selectedUserName;
	}
	
	public void setSubAppId(Long subAppId) {
	
		this.subAppId = subAppId;
	}
	
	public void setUserGroup(String userGroup) {
	
		this.userGroup = userGroup;
	}
	
	public void setUserNameList(Set<NamedEntityTO> userNameList) {
	
		this.userNameList = userNameList;
	}
}
