package com.framework.to;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

public class WorkFlowLevelTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7759873625347840870L;
	private Long id;
	private Long workflowId;
	private Long clientId;
	private Long levelOrder;
	private Long roleId;
	private List<RoleTO> roleList = new ArrayList<RoleTO>();
	private List<RoleTO> definedRolesList = new ArrayList<RoleTO>();
	private List<Long> selectedRoles = new LinkedList<Long>();
	private List<Long> definedRoles = new LinkedList<Long>();
	private WorkFlowTO workFlows;
	private Long createdById;
	private Long modifiedbyId;
	private Date createdByDate;
	private Date modifiedbyDate;
	private Long selectedBusinessUnit = null;
	private Long selectedWorkFlowAction = null;
	
	public Long getClientId() {
	
		return clientId;
	}
	
	public Date getCreatedByDate() {
	
		return createdByDate;
	}
	
	public Long getCreatedById() {
	
		return createdById;
	}
	
	public List<Long> getDefinedRoles() {
	
		return definedRoles;
	}
	
	public List<RoleTO> getDefinedRolesList() {
	
		return definedRolesList;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public Long getLevelOrder() {
	
		return levelOrder;
	}
	
	public Date getModifiedbyDate() {
	
		return modifiedbyDate;
	}
	
	public Long getModifiedbyId() {
	
		return modifiedbyId;
	}
	
	public Long getRoleId() {
	
		return roleId;
	}
	
	public List<RoleTO> getRoleList() {
	
		return roleList;
	}
	
	public Long getSelectedBusinessUnit() {
	
		return selectedBusinessUnit;
	}
	
	public List<Long> getSelectedRoles() {
	
		return selectedRoles;
	}
	
	public Long getSelectedWorkFlowAction() {
	
		return selectedWorkFlowAction;
	}
	
	public Long getWorkflowId() {
	
		return workflowId;
	}
	
	public WorkFlowTO getWorkFlows() {
	
		return workFlows;
	}
	
	public void setClientId(Long clientId) {
	
		this.clientId = clientId;
	}
	
	public void setCreatedByDate(Date createdByDate) {
	
		this.createdByDate = createdByDate;
	}
	
	public void setCreatedById(Long createdById) {
	
		this.createdById = createdById;
	}
	
	public void setDefinedRoles(List<Long> definedRoles) {
	
		this.definedRoles = definedRoles;
	}
	
	public void setDefinedRolesList(List<RoleTO> definedRolesList) {
	
		this.definedRolesList = definedRolesList;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setLevelOrder(Long levelOrder) {
	
		this.levelOrder = levelOrder;
	}
	
	public void setModifiedbyDate(Date modifiedbyDate) {
	
		this.modifiedbyDate = modifiedbyDate;
	}
	
	public void setModifiedbyId(Long modifiedbyId) {
	
		this.modifiedbyId = modifiedbyId;
	}
	
	public void setRoleId(Long roleId) {
	
		this.roleId = roleId;
	}
	
	public void setRoleList(List<RoleTO> roleList) {
	
		this.roleList = roleList;
	}
	
	public void setSelectedBusinessUnit(Long selectedBusinessUnit) {
	
		this.selectedBusinessUnit = selectedBusinessUnit;
	}
	
	public void setSelectedRoles(List<Long> selectedRoles) {
	
		this.selectedRoles = selectedRoles;
	}
	
	public void setSelectedWorkFlowAction(Long selectedWorkFlowAction) {
	
		this.selectedWorkFlowAction = selectedWorkFlowAction;
	}
	
	public void setWorkflowId(Long workflowId) {
	
		this.workflowId = workflowId;
	}
	
	public void setWorkFlows(WorkFlowTO workFlows) {
	
		this.workFlows = workFlows;
	}
}
