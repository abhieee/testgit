package com.framework.to;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

public class ServiceTypeTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 80328975141044546L;
	private Long id;
	private String catalogType;
	private Long status;
	private Set<ServiceTO> serviceTO = new HashSet<ServiceTO>(0);
	
	public String getCatalogType() {
	
		return catalogType;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public Set<ServiceTO> getServiceTO() {
	
		return serviceTO;
	}
	
	public Long getStatus() {
	
		return status;
	}
	
	public void setCatalogType(String catalogType) {
	
		this.catalogType = catalogType;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setServiceTO(Set<ServiceTO> serviceTO) {
	
		this.serviceTO = serviceTO;
	}
	
	public void setStatus(Long status) {
	
		this.status = status;
	}
}
