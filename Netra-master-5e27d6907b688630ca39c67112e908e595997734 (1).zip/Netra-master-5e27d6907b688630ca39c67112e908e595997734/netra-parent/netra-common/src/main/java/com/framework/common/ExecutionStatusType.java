package com.framework.common;

public enum ExecutionStatusType {
	PUBLIC("PUBLIC"), PRIVATE("PRIVATE");
	
	private String statusType;
	
	private ExecutionStatusType(String s) {
	
		this.statusType = s;
	}
	
	public String getExecutionStatusType() {
	
		return statusType;
	}
}
