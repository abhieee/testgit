package com.framework.to;

import java.util.Date;

public class UserPrivilegeTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3524408453642671069L;
	private UserTO userTO;
	private RoleTO roleTO;
	private Long roleId;
	private Integer createdBy;
	private Date createdDate;
	private Integer modifiedBy;
	private Date modifiedDate;
	
	public UserPrivilegeTO() {
	
		/* No implementation required at the moment. Method for future use. */
	}
	
	public UserPrivilegeTO(Long roleId, Long id) {
	
		this.roleId = roleId;
	}
	
	public UserPrivilegeTO(Long roleId, Long id, Integer createdBy, Date createdDate, Integer modifiedBy, Date modifiedDate) {
	
		super();
		this.roleId = roleId;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifiedDate;
	}
	
	public Integer getCreatedBy() {
	
		return this.createdBy;
	}
	
	@Override
	public Date getCreatedDate() {
	
		return this.createdDate;
	}
	
	public Integer getModifiedBy() {
	
		return this.modifiedBy;
	}
	
	@Override
	public Date getModifiedDate() {
	
		return this.modifiedDate;
	}
	
	public Long getRoleId() {
	
		return roleId;
	}
	
	public RoleTO getRoleTO() {
	
		return roleTO;
	}
	
	public UserTO getUserTO() {
	
		return userTO;
	}
	
	public void setCreatedBy(Integer createdBy) {
	
		this.createdBy = createdBy;
	}
	
	@Override
	public void setCreatedDate(Date createdDate) {
	
		this.createdDate = createdDate;
	}
	
	public void setModifiedBy(Integer modifiedBy) {
	
		this.modifiedBy = modifiedBy;
	}
	
	@Override
	public void setModifiedDate(Date modifiedDate) {
	
		this.modifiedDate = modifiedDate;
	}
	
	public void setRoleId(Long roleId) {
	
		this.roleId = roleId;
	}
	
	public void setRoleTO(RoleTO roleTO) {
	
		this.roleTO = roleTO;
	}
	
	public void setUserTO(UserTO userTO) {
	
		this.userTO = userTO;
	}
}
