package com.framework.to;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * This class declares the transfer object that carries user information across the application.
 *
 * @author TCS
 */
public class ApplicationReleaseSourcecodeTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5814069586625798410L;
	private Long id;
	private Long softwareConfigId;
	private String sourceCodePath;
	private ApplicationReleaseTO applicationReleaseSc = new ApplicationReleaseTO();
	private String earPath;
	private String tempArtifactPath;
	private String softwareName;
	private Long applicationReleaseId;
	private SoftwareconfigTO softwareConfigTO;
	private String templateName;
	private Long serverGroupNumber;
	private Long appProDetailsId;
	private Long serverId;
	private Long softwareId;
	private Long RequestId;
	private int flag = 1;
	private HardwareTO hardware;
	private boolean access;
	private List<ApplicationReleaseSourcecodeTO> propAppSerSc1 = new ArrayList<>();
	private ApplicationReleaseTO applicationRelease = new ApplicationReleaseTO();
	private String netraNexusPath;
	private String overWriteFlag;
	private String contextPath;
	private String serverName;
	private String selectedDomain;
	private String scriptsPath;
	private Long machineId;
	private Long selectedTestingPhase;
	private Long selectedRepository;
	private String monitoringFlag;
	
	public Long getSelectedRepository() {
	
		return selectedRepository;
	}
	
	public String getMonitoringFlag() {
	
		return monitoringFlag;
	}
	
	public void setMonitoringFlag(String monitoringFlag) {
	
		this.monitoringFlag = monitoringFlag;
	}
	
	public void setSelectedRepository(Long selectedRepository) {
	
		this.selectedRepository = selectedRepository;
	}
	
	public Long getSelectedTestingPhase() {
	
		return selectedTestingPhase;
	}
	
	public void setSelectedTestingPhase(Long selectedTestingPhase) {
	
		this.selectedTestingPhase = selectedTestingPhase;
	}
	
	public ApplicationReleaseTO getApplicationRelease() {
	
		return applicationRelease;
	}
	
	public Long getApplicationReleaseId() {
	
		return applicationReleaseId;
	}
	
	public ApplicationReleaseTO getApplicationReleaseSc() {
	
		return applicationReleaseSc;
	}
	
	public Long getAppProDetailsId() {
	
		return appProDetailsId;
	}
	
	public String getContextPath() {
	
		return contextPath;
	}
	
	public String getEarPath() {
	
		return earPath;
	}
	
	public int getFlag() {
	
		return flag;
	}
	
	public HardwareTO getHardware() {
	
		return hardware;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public Long getMachineId() {
	
		return machineId;
	}
	
	public String getNetraNexusPath() {
	
		return netraNexusPath;
	}
	
	public String getOverWriteFlag() {
	
		return overWriteFlag;
	}
	
	public List<ApplicationReleaseSourcecodeTO> getPropAppSerSc1() {
	
		return propAppSerSc1;
	}
	
	public Long getRequestId() {
	
		return RequestId;
	}
	
	public String getScriptsPath() {
	
		return scriptsPath;
	}
	
	/**
	 * @return the selectedDomain
	 */
	public String getSelectedDomain() {
	
		return selectedDomain;
	}
	
	public Long getServerGroupNumber() {
	
		return serverGroupNumber;
	}
	
	public Long getServerId() {
	
		return serverId;
	}
	
	/**
	 * @return the serverName
	 */
	public String getServerName() {
	
		return serverName;
	}
	
	public Long getSoftwareConfigId() {
	
		return softwareConfigId;
	}
	
	public SoftwareconfigTO getSoftwareConfigTO() {
	
		return softwareConfigTO;
	}
	
	public Long getSoftwareId() {
	
		return softwareId;
	}
	
	public String getSoftwareName() {
	
		return softwareName;
	}
	
	public String getSourceCodePath() {
	
		return sourceCodePath;
	}
	
	public String getTempArtifactPath() {
	
		return tempArtifactPath;
	}
	
	public String getTemplateName() {
	
		return templateName;
	}
	
	public boolean isAccess() {
	
		return access;
	}
	
	public void setAccess(boolean access) {
	
		this.access = access;
	}
	
	public void setApplicationRelease(ApplicationReleaseTO applicationRelease) {
	
		this.applicationRelease = applicationRelease;
	}
	
	public void setApplicationReleaseId(Long applicationReleaseId) {
	
		this.applicationReleaseId = applicationReleaseId;
	}
	
	public void setApplicationReleaseSc(ApplicationReleaseTO applicationReleaseSc) {
	
		this.applicationReleaseSc = applicationReleaseSc;
	}
	
	public void setAppProDetailsId(Long appProDetailsId) {
	
		this.appProDetailsId = appProDetailsId;
	}
	
	public void setContextPath(String contextPath) {
	
		this.contextPath = contextPath;
	}
	
	public void setEarPath(String earPath) {
	
		this.earPath = earPath;
	}
	
	public void setFlag(int flag) {
	
		this.flag = flag;
	}
	
	public void setHardware(HardwareTO hardware) {
	
		this.hardware = hardware;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setMachineId(Long machineId) {
	
		this.machineId = machineId;
	}
	
	public void setNetraNexusPath(String netraNexusPath) {
	
		this.netraNexusPath = netraNexusPath;
	}
	
	public void setOverWriteFlag(String overWriteFlag) {
	
		this.overWriteFlag = overWriteFlag;
	}
	
	public void setPropAppSerSc1(List<ApplicationReleaseSourcecodeTO> propAppSerSc1) {
	
		this.propAppSerSc1 = propAppSerSc1;
	}
	
	public void setRequestId(Long requestId) {
	
		RequestId = requestId;
	}
	
	public void setScriptsPath(String scriptsPath) {
	
		this.scriptsPath = scriptsPath;
	}
	
	/**
	 * @param selectedDomain
	 *                the selectedDomain to set
	 */
	public void setSelectedDomain(String selectedDomain) {
	
		this.selectedDomain = selectedDomain;
	}
	
	public void setServerGroupNumber(Long serverGroupNumber) {
	
		this.serverGroupNumber = serverGroupNumber;
	}
	
	public void setServerId(Long serverId) {
	
		this.serverId = serverId;
	}
	
	/**
	 * @param serverName
	 *                the serverName to set
	 */
	public void setServerName(String serverName) {
	
		this.serverName = serverName;
	}
	
	public void setSoftwareConfigId(Long softwareConfigId) {
	
		this.softwareConfigId = softwareConfigId;
	}
	
	public void setSoftwareConfigTO(SoftwareconfigTO softwareConfigTO) {
	
		this.softwareConfigTO = softwareConfigTO;
	}
	
	public void setSoftwareId(Long softwareId) {
	
		this.softwareId = softwareId;
	}
	
	public void setSoftwareName(String softwareName) {
	
		this.softwareName = softwareName;
	}
	
	public void setSourceCodePath(String sourceCodePath) {
	
		this.sourceCodePath = sourceCodePath;
	}
	
	public void setTempArtifactPath(String tempArtifactPath) {
	
		this.tempArtifactPath = tempArtifactPath;
	}
	
	public void setTemplateName(String templateName) {
	
		this.templateName = templateName;
	}
}