package com.framework.to;

import java.io.Serializable;

public class MachineTemplateAwsTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 247905846675325903L;
	private Long id;
	private Long awsAccountId;
	private Long machineId;
	private String instanceType;
	private Long templateId;
	private String sdk;
	private MachineTemplateTO machineTemplate;
	
	public MachineTemplateAwsTO() {
	
		/* No implementation required at the moment. Method for future use. */
	}
	
	public Long getAwsAccountId() {
	
		return awsAccountId;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public String getInstanceType() {
	
		return instanceType;
	}
	
	public Long getMachineId() {
	
		return machineId;
	}
	
	public MachineTemplateTO getMachineTemplate() {
	
		return machineTemplate;
	}
	
	public String getSdk() {
	
		return sdk;
	}
	
	public Long getTemplateId() {
	
		return templateId;
	}
	
	public void setAwsAccountId(Long awsAccountId) {
	
		this.awsAccountId = awsAccountId;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setInstanceType(String instanceType) {
	
		this.instanceType = instanceType;
	}
	
	public void setMachineId(Long machineId) {
	
		this.machineId = machineId;
	}
	
	public void setMachineTemplate(MachineTemplateTO machineTemplate) {
	
		this.machineTemplate = machineTemplate;
	}
	
	public void setSdk(String sdk) {
	
		this.sdk = sdk;
	}
	
	public void setTemplateId(Long templateId) {
	
		this.templateId = templateId;
	}
}
