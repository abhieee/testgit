package com.framework.to;

import java.io.Serializable;

public class ProvisionedMachinePhysicalTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5496007795461264818L;
	private Long id;
	private ProvisionedMachineTO povisionedMachine;
	private Long provisionedtemplateId;
	private Long provisionedMachineId;
	private String username;
	private String password;
	
	public Long getId() {
	
		return id;
	}
	
	public String getPassword() {
	
		return password;
	}
	
	public ProvisionedMachineTO getPovisionedMachine() {
	
		return povisionedMachine;
	}
	
	public Long getProvisionedMachineId() {
	
		return provisionedMachineId;
	}
	
	public Long getProvisionedtemplateId() {
	
		return provisionedtemplateId;
	}
	
	public String getUsername() {
	
		return username;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setPassword(String password) {
	
		this.password = password;
	}
	
	public void setPovisionedMachine(ProvisionedMachineTO povisionedMachine) {
	
		this.povisionedMachine = povisionedMachine;
	}
	
	public void setProvisionedMachineId(Long provisionedMachineId) {
	
		this.provisionedMachineId = provisionedMachineId;
	}
	
	public void setProvisionedtemplateId(Long provisionedtemplateId) {
	
		this.provisionedtemplateId = provisionedtemplateId;
	}
	
	public void setUsername(String username) {
	
		this.username = username;
	}
}
