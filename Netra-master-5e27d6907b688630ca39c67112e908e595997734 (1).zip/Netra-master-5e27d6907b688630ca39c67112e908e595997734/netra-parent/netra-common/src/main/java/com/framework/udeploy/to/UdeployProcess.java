/**
 *
 */
package com.framework.udeploy.to;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @author 460650
 */
public class UdeployProcess implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6331638102443080116L;
	private Long processId;
	private String processFullPath;
	private String status;
	private Long tmpList;
	private Set<UdeployProcessParametersTO> udeployProcessParameters = new HashSet<UdeployProcessParametersTO>(0);
	private List<UdeployProcessParametersTO> udeployProcessParameterList = new ArrayList<UdeployProcessParametersTO>(0);
	
	public Long getTmpList() {
	
		return tmpList;
	}
	
	public void setTmpList(Long tmpList) {
	
		this.tmpList = tmpList;
	}
	
	public String getProcessFullPath() {
	
		return processFullPath;
	}
	
	public Long getProcessId() {
	
		return processId;
	}
	
	public String getStatus() {
	
		return status;
	}
	
	/**
	 * @param processFullPath
	 *                the processFullPath to set
	 */
	public void setProcessFullPath(String processFullPath) {
	
		this.processFullPath = processFullPath;
	}
	
	public void setProcessId(Long processId) {
	
		this.processId = processId;
	}
	
	public void setStatus(String status) {
	
		this.status = status;
	}
	
	public Set<UdeployProcessParametersTO> getUdeployProcessParameters() {
	
		return udeployProcessParameters;
	}
	
	public void setUdeployProcessParameters(Set<UdeployProcessParametersTO> udeployProcessParameters) {
	
		this.udeployProcessParameters = udeployProcessParameters;
	}
	
	public List<UdeployProcessParametersTO> getUdeployProcessParameterList() {
	
		return udeployProcessParameterList;
	}
	
	public void setUdeployProcessParameterList(List<UdeployProcessParametersTO> udeployProcessParameterList) {
	
		this.udeployProcessParameterList = udeployProcessParameterList;
	}
}
