package com.framework.common;

public enum ReleaseType {
	MAJOR_RELEASE("Major"), MINOR_RELEASE("Minor"), PATCH_RELEASE("Patch");
	
	private String releaseType;
	
	private ReleaseType(String releaseType) {
	
		this.releaseType = releaseType;
	}
	
	public String getReleaseType() {
	
		return releaseType;
	}
	
	void setReleaseType(String releaseType) {
	
		this.releaseType = releaseType;
	}
}