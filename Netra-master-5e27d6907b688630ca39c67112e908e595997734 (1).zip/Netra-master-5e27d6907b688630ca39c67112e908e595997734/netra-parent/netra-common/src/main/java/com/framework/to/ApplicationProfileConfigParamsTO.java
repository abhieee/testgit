package com.framework.to;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ApplicationProfileConfigParamsTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3922085958814500680L;
	private Long id;
	private String paramName;
	private String defaultValue;
	private String paramHintLine;
	private Long createdById;
	private Date createdByDate;
	private Long modifiedbyId;
	private Date modifiedbyDate;
	private String parameterValue;
	private List<ApplicationProfileConfigParamsTO> parameterValueList = new ArrayList<ApplicationProfileConfigParamsTO>(0);
	private boolean flag = false;
	private boolean access;
	private Long environmentId;
	private Long appPrfConfigId;
	private Long ApplicationProfileConfigParamTmpltMapId;
	private ApplicationProfileConfigTO appPrfConfigTO;
	private Long lineNumber;
	private Long paramCount;
	private String flagStr;
	
	public Long getApplicationProfileConfigParamTmpltMapId() {
	
		return ApplicationProfileConfigParamTmpltMapId;
	}
	
	public Long getAppPrfConfigId() {
	
		return appPrfConfigId;
	}
	
	public ApplicationProfileConfigTO getAppPrfConfigTO() {
	
		return appPrfConfigTO;
	}
	
	public Date getCreatedByDate() {
	
		return createdByDate;
	}
	
	public Long getCreatedById() {
	
		return createdById;
	}
	
	public String getDefaultValue() {
	
		return defaultValue;
	}
	
	public Long getEnvironmentId() {
	
		return environmentId;
	}
	
	public String getFlagStr() {
	
		return flagStr;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public Long getLineNumber() {
	
		return lineNumber;
	}
	
	public Date getModifiedbyDate() {
	
		return modifiedbyDate;
	}
	
	public Long getModifiedbyId() {
	
		return modifiedbyId;
	}
	
	public Long getParamCount() {
	
		return paramCount;
	}
	
	public String getParameterValue() {
	
		return parameterValue;
	}
	
	public List<ApplicationProfileConfigParamsTO> getParameterValueList() {
	
		return parameterValueList;
	}
	
	public String getParamHintLine() {
	
		return paramHintLine;
	}
	
	public String getParamName() {
	
		return paramName;
	}
	
	public boolean isAccess() {
	
		return access;
	}
	
	public boolean isFlag() {
	
		return flag;
	}
	
	public void setAccess(boolean access) {
	
		this.access = access;
	}
	
	public void setApplicationProfileConfigParamTmpltMapId(Long applicationProfileConfigParamTmpltMapId) {
	
		ApplicationProfileConfigParamTmpltMapId = applicationProfileConfigParamTmpltMapId;
	}
	
	public void setAppPrfConfigId(Long appPrfConfigId) {
	
		this.appPrfConfigId = appPrfConfigId;
	}
	
	public void setAppPrfConfigTO(ApplicationProfileConfigTO appPrfConfigTO) {
	
		this.appPrfConfigTO = appPrfConfigTO;
	}
	
	public void setCreatedByDate(Date createdByDate) {
	
		this.createdByDate = createdByDate;
	}
	
	public void setCreatedById(Long createdById) {
	
		this.createdById = createdById;
	}
	
	public void setDefaultValue(String defaultValue) {
	
		this.defaultValue = defaultValue;
	}
	
	public void setEnvironmentId(Long environmentId) {
	
		this.environmentId = environmentId;
	}
	
	public void setFlag(boolean flag) {
	
		this.flag = flag;
	}
	
	public void setFlagStr(String flagStr) {
	
		this.flagStr = flagStr;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setLineNumber(Long lineNumber) {
	
		this.lineNumber = lineNumber;
	}
	
	public void setModifiedbyDate(Date modifiedbyDate) {
	
		this.modifiedbyDate = modifiedbyDate;
	}
	
	public void setModifiedbyId(Long modifiedbyId) {
	
		this.modifiedbyId = modifiedbyId;
	}
	
	public void setParamCount(Long paramCount) {
	
		this.paramCount = paramCount;
	}
	
	public void setParameterValue(String parameterValue) {
	
		this.parameterValue = parameterValue;
	}
	
	public void setParameterValueList(List<ApplicationProfileConfigParamsTO> parameterValueList) {
	
		this.parameterValueList = parameterValueList;
	}
	
	public void setParamHintLine(String paramHintLine) {
	
		this.paramHintLine = paramHintLine;
	}
	
	public void setParamName(String paramName) {
	
		this.paramName = paramName;
	}
}