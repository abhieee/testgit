package com.framework.to;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * This class declares the transfer object that carries user information across the application.
 *
 * @author TCS
 */
public class UserTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 749508094549274524L;
	private String usrName;
	private String usrFullName;
	private Long businessUnit;
	private String comment;
	private boolean validate = true;
	private String password;
	private String passwordEnc;
	private String email;
	private String phone;
	private int tableSize = 15;
	private long pageNumber = 1;
	private int firstResult = 0;
	private long searchCount;
	private String username = null;
	private String userSource;
	private List<UserPrivilegeTO> userRoles;
	private List<Long> selectedClientList = new ArrayList<Long>(0);
	private String fullName;
	private Set<RoleTO> roles;
	private Set<UserPrivilegeTO> userPrivilegeTO;
	private Date lastPasswordChanged;
	private String role;
	private Boolean annex2Certified;
	private DomainTO domain;
	private long clientId;
	private long status;
	private Set<UserGroupDetailsTO> userGroupDetailses = new HashSet<UserGroupDetailsTO>(0);
	private Set<ReservationTO> reservationses = new HashSet<ReservationTO>(0);
	private Set<WorkflowCurrentTO> workflowCurrentTO = new HashSet<WorkflowCurrentTO>();
	private Set<WorkflowHistoryTO> workflowHistoryTO = new HashSet<WorkflowHistoryTO>();
	private UserTO users;
	private Date createdByDate;
	private Date modifiedbyDate;
	private Long roleId;
	private Long selectedSupervisorId;
	private Long projectId;
	private Date fromDate;
	private Date toDate;
	private String Address = null;
	private Set<UserBusinessUnitTO> userBusinessUnit = new HashSet<UserBusinessUnitTO>(0);
	private List<Long> clientList = new ArrayList<Long>(0);
	private List<Long> userList = new ArrayList<Long>(0);
	private Long selectedRole;
	
	public UserTO() {
	
		super();
	}
	
	private Set<DelegatedUserTO> delegation;
	
	public Set<DelegatedUserTO> getDelegation() {
	
		return delegation;
	}
	
	public void setDelegation(Set<DelegatedUserTO> delegation) {
	
		this.delegation = delegation;
	}
	
	public Long getSelectedRole() {
	
		return selectedRole;
	}
	
	public void setSelectedRole(Long selectedRole) {
	
		this.selectedRole = selectedRole;
	}
	
	public void copy(UserTO userTO) {
	
		if (userTO == null) {
			userTO = new UserTO();
		}
		if ((userTO.getName() == null) || !userTO.getName().equals(this.getName())) {
			userTO.setName(this.getName());
		}
		if ((userTO.getPassword() == null) || !userTO.getPassword().equals(this.getPassword())) {
			userTO.setPassword(this.getPassword());
		}
		if ((userTO.getPhone() == null) || !userTO.getPhone().equals(this.getPhone())) {
			userTO.setPhone(this.getPhone());
		}
		if ((userTO.getFullName() == null) || !userTO.getFullName().equals(this.getFullName())) {
			userTO.setFullName(this.getFullName());
		}
		userTO.setRoles(this.getRoles());
	}
	
	public String getAddress() {
	
		return Address;
	}
	
	public Boolean getAnnex2Certified() {
	
		return annex2Certified;
	}
	
	public Long getBusinessUnit() {
	
		return businessUnit;
	}
	
	public long getClientId() {
	
		return clientId;
	}
	
	/**
	 * @return the clientList
	 */
	public List<Long> getClientList() {
	
		return clientList;
	}
	
	public String getComment() {
	
		return comment;
	}
	
	public Date getCreatedByDate() {
	
		return createdByDate;
	}
	
	/**
	 * @return the domainid
	 */
	public DomainTO getDomain() {
	
		return domain;
	}
	
	/**
	 * @return the email
	 */
	public String getEmail() {
	
		return email;
	}
	
	public int getFirstResult() {
	
		return firstResult;
	}
	
	public Date getFromDate() {
	
		return fromDate;
	}
	
	/**
	 * @return the fullName
	 */
	public String getFullName() {
	
		return fullName;
	}
	
	/**
	 * @return the lastPasswordChanged
	 */
	public Date getLastPasswordChanged() {
	
		return lastPasswordChanged;
	}
	
	public Date getModifiedbyDate() {
	
		return modifiedbyDate;
	}
	
	public long getPageNumber() {
	
		return pageNumber;
	}
	
	/**
	 * @return the password
	 */
	public String getPassword() {
	
		return password;
	}
	
	public String getPasswordEnc() {
	
		return passwordEnc;
	}
	
	/**
	 * @return the phone
	 */
	public String getPhone() {
	
		return phone;
	}
	
	public Long getProjectId() {
	
		return projectId;
	}
	
	public Set<ReservationTO> getReservationses() {
	
		return reservationses;
	}
	
	public String getRole() {
	
		return role;
	}
	
	public Long getRoleId() {
	
		return roleId;
	}
	
	/**
	 * @return the roles
	 */
	public Set<RoleTO> getRoles() {
	
		return roles;
	}
	
	public long getSearchCount() {
	
		return searchCount;
	}
	
	public List<Long> getSelectedClientList() {
	
		return selectedClientList;
	}
	
	public Long getSelectedSupervisorId() {
	
		return selectedSupervisorId;
	}
	
	public long getStatus() {
	
		return status;
	}
	
	public int getTableSize() {
	
		return tableSize;
	}
	
	public Date getToDate() {
	
		return toDate;
	}
	
	/**
	 * @return the userBusinessUnit
	 */
	public Set<UserBusinessUnitTO> getUserBusinessUnit() {
	
		return userBusinessUnit;
	}
	
	public Set<UserGroupDetailsTO> getUserGroupDetailses() {
	
		return userGroupDetailses;
	}
	
	public List<Long> getUserList() {
	
		return userList;
	}
	
	public String getUsername() {
	
		return username;
	}
	
	public Set<UserPrivilegeTO> getUserPrivilegeTO() {
	
		return userPrivilegeTO;
	}
	
	public List<UserPrivilegeTO> getUserRoles() {
	
		return userRoles;
	}
	
	public UserTO getUsers() {
	
		return users;
	}
	
	public String getUserSource() {
	
		return userSource;
	}
	
	public String getUsrFullName() {
	
		return usrFullName;
	}
	
	public String getUsrName() {
	
		return usrName;
	}
	
	public Set<WorkflowCurrentTO> getWorkflowCurrentTO() {
	
		return workflowCurrentTO;
	}
	
	public Set<WorkflowHistoryTO> getWorkflowHistoryTO() {
	
		return workflowHistoryTO;
	}
	
	/**
	 * @return the annex2Certified
	 */
	public Boolean isAnnex2Certified() {
	
		return annex2Certified;
	}
	
	public boolean isValidate() {
	
		return validate;
	}
	
	public void setAddress(String address) {
	
		Address = address;
	}
	
	/**
	 * @param annex2Certified
	 *                the annex2Certified to set
	 */
	public void setAnnex2Certified(Boolean annex2Certified) {
	
		this.annex2Certified = annex2Certified;
	}
	
	public void setBusinessUnit(Long businessUnit) {
	
		this.businessUnit = businessUnit;
	}
	
	public void setClientId(long clientId) {
	
		this.clientId = clientId;
	}
	
	/**
	 * @param clientList
	 *                the clientList to set
	 */
	public void setClientList(List<Long> clientList) {
	
		this.clientList = clientList;
	}
	
	public void setComment(String comment) {
	
		this.comment = comment;
	}
	
	public void setCreatedByDate(Date createdByDate) {
	
		this.createdByDate = createdByDate;
	}
	
	/**
	 * @param domainid
	 *                the domainid to set
	 */
	public void setDomain(DomainTO domain) {
	
		this.domain = domain;
	}
	
	/**
	 * @param email
	 *                the email to set
	 */
	public void setEmail(String email) {
	
		this.email = email;
	}
	
	public void setFirstResult(int firstResult) {
	
		this.firstResult = firstResult;
	}
	
	public void setFromDate(Date fromDate) {
	
		this.fromDate = fromDate;
	}
	
	/**
	 * @param fullName
	 *                the fullName to set
	 */
	public void setFullName(String fullName) {
	
		this.fullName = fullName;
	}
	
	/**
	 * @param lastPasswordChanged
	 *                the lastPasswordChanged to set
	 */
	public void setLastPasswordChanged(Date lastPasswordChanged) {
	
		this.lastPasswordChanged = lastPasswordChanged;
	}
	
	public void setModifiedbyDate(Date modifiedbyDate) {
	
		this.modifiedbyDate = modifiedbyDate;
	}
	
	public void setPageNumber(long pageNumber) {
	
		this.pageNumber = pageNumber;
	}
	
	/**
	 * @param password
	 *                the password to set
	 */
	public void setPassword(String password) {
	
		this.password = password;
	}
	
	public void setPasswordEnc(String passwordEnc) {
	
		this.passwordEnc = passwordEnc;
	}
	
	/**
	 * @param phone
	 *                the phone to set
	 */
	public void setPhone(String phone) {
	
		this.phone = phone;
	}
	
	public void setProjectId(Long projectId) {
	
		this.projectId = projectId;
	}
	
	public void setReservationses(Set<ReservationTO> reservationses) {
	
		this.reservationses = reservationses;
	}
	
	public void setRole(String role) {
	
		this.role = role;
	}
	
	public void setRoleId(Long roleId) {
	
		this.roleId = roleId;
	}
	
	/**
	 * @param roles
	 *                the roles to set
	 */
	public void setRoles(Set<RoleTO> roles) {
	
		this.roles = roles;
	}
	
	public void setSearchCount(long searchCount) {
	
		this.searchCount = searchCount;
	}
	
	public void setSelectedClientList(List<Long> selectedClientList) {
	
		this.selectedClientList = selectedClientList;
	}
	
	public void setSelectedSupervisorId(Long selectedSupervisorId) {
	
		this.selectedSupervisorId = selectedSupervisorId;
	}
	
	public void setStatus(long status) {
	
		this.status = status;
	}
	
	public void setTableSize(int tableSize) {
	
		this.tableSize = tableSize;
	}
	
	public void setToDate(Date toDate) {
	
		this.toDate = toDate;
	}
	
	/**
	 * @param userBusinessUnit
	 *                the userBusinessUnit to set
	 */
	public void setUserBusinessUnit(Set<UserBusinessUnitTO> userBusinessUnit) {
	
		this.userBusinessUnit = userBusinessUnit;
	}
	
	public void setUserGroupDetailses(Set<UserGroupDetailsTO> userGroupDetailses) {
	
		this.userGroupDetailses = userGroupDetailses;
	}
	
	public void setUserList(List<Long> userList) {
	
		this.userList = userList;
	}
	
	public void setUsername(String username) {
	
		this.username = username;
	}
	
	public void setUserPrivilegeTO(Set<UserPrivilegeTO> userPrivilegeTO) {
	
		this.userPrivilegeTO = userPrivilegeTO;
	}
	
	public void setUserRoles(List<UserPrivilegeTO> userRoles) {
	
		this.userRoles = userRoles;
	}
	
	public void setUsers(UserTO users) {
	
		this.users = users;
	}
	
	public void setUserSource(String userSource) {
	
		this.userSource = userSource;
	}
	
	public void setUsrFullName(String usrFullName) {
	
		this.usrFullName = usrFullName;
	}
	
	public void setUsrName(String usrName) {
	
		this.usrName = usrName;
	}
	
	public void setValidate(boolean validate) {
	
		this.validate = validate;
	}
	
	public void setWorkflowCurrentTO(Set<WorkflowCurrentTO> workflowCurrentTO) {
	
		this.workflowCurrentTO = workflowCurrentTO;
	}
	
	public void setWorkflowHistoryTO(Set<WorkflowHistoryTO> workflowHistoryTO) {
	
		this.workflowHistoryTO = workflowHistoryTO;
	}
}
