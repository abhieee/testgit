package com.pres.mail;

import java.util.Date;

public class MailUtility {
	
	private Long reservationId;
	private Date startTime = null;
	private Date endTime = null;
	private String applicationName = null;
	private String environmentName = null;
	private String status = null;
	private String createdBy = null;
	private String updatedBy = null;
	private Long resStatusId;
	private String serviceName = null;
	private String actionFlag = null;
	private Long createdById;
	private String createdByDate;
	private String isScheduled = "N";
	private Long SelectedRequestId;
	private String appName = null;
	private String pipelineRequest = null;
	private String scheduledDetails = null;
	private String applicationReleaseName = null;
	
	public Long getReservationId() {
	
		return reservationId;
	}
	
	public void setReservationId(Long reservationId) {
	
		this.reservationId = reservationId;
	}
	
	public Date getStartTime() {
	
		return startTime;
	}
	
	public void setStartTime(Date startTime) {
	
		this.startTime = startTime;
	}
	
	public Date getEndTime() {
	
		return endTime;
	}
	
	public void setEndTime(Date endTime) {
	
		this.endTime = endTime;
	}
	
	public String getApplicationName() {
	
		return applicationName;
	}
	
	public void setApplicationName(String applicationName) {
	
		this.applicationName = applicationName;
	}
	
	public String getEnvironmentName() {
	
		return environmentName;
	}
	
	public void setEnvironmentName(String environmentName) {
	
		this.environmentName = environmentName;
	}
	
	public String getStatus() {
	
		return status;
	}
	
	public void setStatus(String status) {
	
		this.status = status;
	}
	
	public String getCreatedBy() {
	
		return createdBy;
	}
	
	public void setCreatedBy(String createdBy) {
	
		this.createdBy = createdBy;
	}
	
	public String getUpdatedBy() {
	
		return updatedBy;
	}
	
	public void setUpdatedBy(String updatedBy) {
	
		this.updatedBy = updatedBy;
	}
	
	public Long getResStatusId() {
	
		return resStatusId;
	}
	
	public void setResStatusId(Long resStatusId) {
	
		this.resStatusId = resStatusId;
	}
	
	public String getActionFlag() {
	
		return actionFlag;
	}
	
	public void setActionFlag(String actionFlag) {
	
		this.actionFlag = actionFlag;
	}
	
	public Long getCreatedById() {
	
		return createdById;
	}
	
	public void setCreatedById(Long createdById) {
	
		this.createdById = createdById;
	}
	
	public String getCreatedByDate() {
	
		return createdByDate;
	}
	
	public void setCreatedByDate(String createdByDate) {
	
		this.createdByDate = createdByDate;
	}
	
	public String getIsScheduled() {
	
		return isScheduled;
	}
	
	public void setIsScheduled(String isScheduled) {
	
		this.isScheduled = isScheduled;
	}
	
	public Long getSelectedRequestId() {
	
		return SelectedRequestId;
	}
	
	public void setSelectedRequestId(Long selectedRequestId) {
	
		SelectedRequestId = selectedRequestId;
	}
	
	public String getAppName() {
	
		return appName;
	}
	
	public void setAppName(String appName) {
	
		this.appName = appName;
	}
	
	public String getPipelineRequest() {
	
		return pipelineRequest;
	}
	
	public void setPipelineRequest(String pipelineRequest) {
	
		this.pipelineRequest = pipelineRequest;
	}
	
	public String getScheduledDetails() {
	
		return scheduledDetails;
	}
	
	public void setScheduledDetails(String scheduledDetails) {
	
		this.scheduledDetails = scheduledDetails;
	}
	
	public String getServiceName() {
	
		return serviceName;
	}
	
	public void setServiceName(String serviceName) {
	
		this.serviceName = serviceName;
	}
	
	public String getApplicationReleaseName() {
	
		return applicationReleaseName;
	}
	
	public void setApplicationReleaseName(String applicationReleaseName) {
	
		this.applicationReleaseName = applicationReleaseName;
	}
}
