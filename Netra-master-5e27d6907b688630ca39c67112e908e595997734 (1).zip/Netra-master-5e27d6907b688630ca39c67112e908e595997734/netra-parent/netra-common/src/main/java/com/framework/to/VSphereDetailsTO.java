/**
 *
 */
package com.framework.to;

import java.io.Serializable;

/**
 * @author 460650
 */
public class VSphereDetailsTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long id = 0L;
	private String dataCenterName;
	private String url;
	private String username;
	private String password;
	private String name;
	private String cloudType;
	private int searchCount;
	private int tableSize = 10;
	private int firstResult = 0;
	private String tenant;
	
	public String getCloudType() {
	
		return cloudType;
	}
	
	public String getDataCenterName() {
	
		return dataCenterName;
	}
	
	public int getFirstResult() {
	
		return firstResult;
	}
	
	public Long getId() {
	
		return id;
	}
	
	/**
	 * @return the name
	 */
	public String getName() {
	
		return name;
	}
	
	public String getPassword() {
	
		return password;
	}
	
	public int getSearchCount() {
	
		return searchCount;
	}
	
	public int getTableSize() {
	
		return tableSize;
	}
	
	public String getTenant() {
	
		return tenant;
	}
	
	public String getUrl() {
	
		return url;
	}
	
	public String getUsername() {
	
		return username;
	}
	
	public void setCloudType(String cloudType) {
	
		this.cloudType = cloudType;
	}
	
	public void setDataCenterName(String dataCenterName) {
	
		this.dataCenterName = dataCenterName;
	}
	
	public void setFirstResult(int firstResult) {
	
		this.firstResult = firstResult;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	/**
	 * @param name
	 *                the name to set
	 */
	public void setName(String name) {
	
		this.name = name;
	}
	
	public void setPassword(String password) {
	
		this.password = password;
	}
	
	public void setSearchCount(int searchCount) {
	
		this.searchCount = searchCount;
	}
	
	public void setTableSize(int tableSize) {
	
		this.tableSize = tableSize;
	}
	
	public void setTenant(String tenant) {
	
		this.tenant = tenant;
	}
	
	public void setUrl(String url) {
	
		this.url = url;
	}
	
	public void setUsername(String username) {
	
		this.username = username;
	}
}
