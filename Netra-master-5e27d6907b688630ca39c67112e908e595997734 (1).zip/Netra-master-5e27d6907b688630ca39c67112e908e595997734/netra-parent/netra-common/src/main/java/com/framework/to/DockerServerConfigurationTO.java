package com.framework.to;

public class DockerServerConfigurationTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5307585500916907912L;
	private String username;
	private String password;
	private String serverIp;
	private Long port;
	private long searchCount;
	private int firstResult = 1;
	private int tableSize;
	private String status;
	private String passwordEnc;
	
	/**
	 * @return the firstResult
	 */
	public int getFirstResult() {
	
		return firstResult;
	}
	
	public String getPasswordEnc() {
	
		return passwordEnc;
	}
	
	public void setPasswordEnc(String passwordEnc) {
	
		this.passwordEnc = passwordEnc;
	}
	
	/**
	 * @return the password
	 */
	public String getPassword() {
	
		return password;
	}
	
	/**
	 * @return the port
	 */
	public Long getPort() {
	
		return port;
	}
	
	/**
	 * @return the searchCount
	 */
	public long getSearchCount() {
	
		return searchCount;
	}
	
	/**
	 * @return the serverIp
	 */
	public String getServerIp() {
	
		return serverIp;
	}
	
	/**
	 * @return the status
	 */
	public String getStatus() {
	
		return status;
	}
	
	/**
	 * @return the tableSize
	 */
	public int getTableSize() {
	
		return tableSize;
	}
	
	/**
	 * @return the username
	 */
	public String getUsername() {
	
		return username;
	}
	
	/**
	 * @param firstResult
	 *                the firstResult to set
	 */
	public void setFirstResult(int firstResult) {
	
		this.firstResult = firstResult;
	}
	
	/**
	 * @param password
	 *                the password to set
	 */
	public void setPassword(String password) {
	
		this.password = password;
	}
	
	/**
	 * @param port
	 *                the port to set
	 */
	public void setPort(Long port) {
	
		this.port = port;
	}
	
	/**
	 * @param searchCount
	 *                the searchCount to set
	 */
	public void setSearchCount(long searchCount) {
	
		this.searchCount = searchCount;
	}
	
	/**
	 * @param serverIp
	 *                the serverIp to set
	 */
	public void setServerIp(String serverIp) {
	
		this.serverIp = serverIp;
	}
	
	/**
	 * @param status
	 *                the status to set
	 */
	public void setStatus(String status) {
	
		this.status = status;
	}
	
	/**
	 * @param tableSize
	 *                the tableSize to set
	 */
	public void setTableSize(int tableSize) {
	
		this.tableSize = tableSize;
	}
	
	/**
	 * @param username
	 *                the username to set
	 */
	public void setUsername(String username) {
	
		this.username = username;
	}
}
