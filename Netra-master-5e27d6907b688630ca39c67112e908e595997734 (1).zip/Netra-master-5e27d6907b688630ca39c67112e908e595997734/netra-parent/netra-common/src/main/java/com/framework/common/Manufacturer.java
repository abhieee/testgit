package com.framework.common;

public enum Manufacturer {
	INHOUSE("In-House"), COTS("COTS");
	
	private String manufacturerType;
	
	private Manufacturer(String manufacturerType) {
	
		this.manufacturerType = manufacturerType;
	}
	
	public String getManufacturerType() {
	
		return manufacturerType;
	}
	
	public void setManufacturerType(String manufacturerType) {
	
		this.manufacturerType = manufacturerType;
	}
}