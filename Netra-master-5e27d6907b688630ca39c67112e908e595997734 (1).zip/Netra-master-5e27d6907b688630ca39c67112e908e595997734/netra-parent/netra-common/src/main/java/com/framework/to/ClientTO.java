package com.framework.to;

public class ClientTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7770423264706106647L;
	private Long status;
	private long clientId;
	
	public long getClientId() {
	
		return clientId;
	}
	
	public Long getStatus() {
	
		return status;
	}
	
	public void setClientId(long clientId) {
	
		this.clientId = clientId;
	}
	
	public void setStatus(Long status) {
	
		this.status = status;
	}
}
