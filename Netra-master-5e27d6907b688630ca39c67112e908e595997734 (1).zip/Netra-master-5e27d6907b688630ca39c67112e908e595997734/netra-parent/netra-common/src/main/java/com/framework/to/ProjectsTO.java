package com.framework.to;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ProjectsTO extends NamedEntityTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8217178195184651818L;
	private String selectedClientName;
	private String projectType;
	private Long status;
	private Long clientId;
	private String remark;
	private StatusTO statusTO;
	private Long selectedStatus;
	private Long selectedClientId;
	private Long selectedOwner;
	private BusinessUnitTO businessUnitTO;
	private String businessUnitName;
	private Collection<BusinessUnitTO> allClients = null;
	private String clientName;
	private Long applications;
	private Set<ApplicationTO> application = new HashSet<ApplicationTO>(0);
	private Set<WorkflowCurrentTO> workflowCurrentTO = new HashSet<WorkflowCurrentTO>();
	private List<Long> clientIdlist = new ArrayList<Long>(0);
	private long searchCount;
	private int firstResult = 1;
	private int tableSize;
	private Long pageNumber = 1L;
	private Set<MailSetupMappingTO> mailSetupMappingTO = new HashSet<MailSetupMappingTO>();
	private List<UserTO> ownerList = null;
	private List<ApplicationTO> applicationList = new ArrayList<ApplicationTO>(0);
	
	public List<ApplicationTO> getApplicationList() {
	
		return applicationList;
	}
	
	public void setApplicationList(List<ApplicationTO> applicationList) {
	
		this.applicationList = applicationList;
	}
	
	public Collection<BusinessUnitTO> getAllClients() {
	
		return allClients;
	}
	
	public Set<ApplicationTO> getApplication() {
	
		return application;
	}
	
	public Long getApplications() {
	
		return applications;
	}
	
	public String getBusinessUnitName() {
	
		return businessUnitName;
	}
	
	public BusinessUnitTO getBusinessUnitTO() {
	
		return businessUnitTO;
	}
	
	public Long getClientId() {
	
		return clientId;
	}
	
	/**
	 * @return the clientIdlist
	 */
	public List<Long> getClientIdlist() {
	
		return clientIdlist;
	}
	
	public String getClientName() {
	
		return clientName;
	}
	
	public int getFirstResult() {
	
		return firstResult;
	}
	
	public Set<MailSetupMappingTO> getMailSetupMappingTO() {
	
		return mailSetupMappingTO;
	}
	
	public List<UserTO> getOwnerList() {
	
		return ownerList;
	}
	
	public Long getPageNumber() {
	
		return pageNumber;
	}
	
	public String getProjectType() {
	
		return projectType;
	}
	
	public String getRemark() {
	
		return remark;
	}
	
	public long getSearchCount() {
	
		return searchCount;
	}
	
	public Long getSelectedClientId() {
	
		return selectedClientId;
	}
	
	public String getSelectedClientName() {
	
		return selectedClientName;
	}
	
	public Long getSelectedOwner() {
	
		return selectedOwner;
	}
	
	public Long getSelectedStatus() {
	
		return selectedStatus;
	}
	
	public Long getStatus() {
	
		return status;
	}
	
	public StatusTO getStatusTO() {
	
		return statusTO;
	}
	
	public int getTableSize() {
	
		return tableSize;
	}
	
	public Set<WorkflowCurrentTO> getWorkflowCurrentTO() {
	
		return workflowCurrentTO;
	}
	
	public void setAllClients(Collection<BusinessUnitTO> allClients) {
	
		this.allClients = allClients;
	}
	
	public void setApplication(Set<ApplicationTO> application) {
	
		this.application = application;
	}
	
	public void setApplications(Long applications) {
	
		this.applications = applications;
	}
	
	public void setBusinessUnitName(String businessUnitName) {
	
		this.businessUnitName = businessUnitName;
	}
	
	public void setBusinessUnitTO(BusinessUnitTO businessUnitTO) {
	
		this.businessUnitTO = businessUnitTO;
	}
	
	public void setClientId(Long clientId) {
	
		this.clientId = clientId;
	}
	
	/**
	 * @param clientIdlist
	 *                the clientIdlist to set
	 */
	public void setClientIdlist(List<Long> clientIdlist) {
	
		this.clientIdlist = clientIdlist;
	}
	
	public void setClientName(String clientName) {
	
		this.clientName = clientName;
	}
	
	public void setFirstResult(int firstResult) {
	
		this.firstResult = firstResult;
	}
	
	public void setMailSetupMappingTO(Set<MailSetupMappingTO> mailSetupMappingTO) {
	
		this.mailSetupMappingTO = mailSetupMappingTO;
	}
	
	public void setOwnerList(List<UserTO> ownerList) {
	
		this.ownerList = ownerList;
	}
	
	public void setPageNumber(Long pageNumber) {
	
		this.pageNumber = pageNumber;
	}
	
	public void setProjectType(String projectType) {
	
		this.projectType = projectType;
	}
	
	public void setRemark(String remark) {
	
		this.remark = remark;
	}
	
	public void setSearchCount(long searchCount) {
	
		this.searchCount = searchCount;
	}
	
	public void setSelectedClientId(Long selectedClientId) {
	
		this.selectedClientId = selectedClientId;
	}
	
	public void setSelectedClientName(String selectedClientName) {
	
		this.selectedClientName = selectedClientName;
	}
	
	public void setSelectedOwner(Long selectedOwner) {
	
		this.selectedOwner = selectedOwner;
	}
	
	public void setSelectedStatus(Long selectedStatus) {
	
		this.selectedStatus = selectedStatus;
	}
	
	public void setStatus(Long status) {
	
		this.status = status;
	}
	
	public void setStatusTO(StatusTO statusTO) {
	
		this.statusTO = statusTO;
	}
	
	public void setTableSize(int tableSize) {
	
		this.tableSize = tableSize;
	}
	
	public void setWorkflowCurrentTO(Set<WorkflowCurrentTO> workflowCurrentTO) {
	
		this.workflowCurrentTO = workflowCurrentTO;
	}
}
