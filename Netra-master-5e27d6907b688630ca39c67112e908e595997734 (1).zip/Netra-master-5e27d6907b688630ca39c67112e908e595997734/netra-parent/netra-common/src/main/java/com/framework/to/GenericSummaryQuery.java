package com.framework.to;

import java.io.Serializable;

/**
 * @author TCS
 */
public class GenericSummaryQuery implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8355896662921707687L;
	private DomainTO domain = null;
	
	/**
	 * @return the domain
	 */
	public DomainTO getDomain() {
	
		return domain;
	}
	
	/**
	 * @param domain
	 *                the domain to set
	 */
	public void setDomain(DomainTO domain) {
	
		this.domain = domain;
	}
}
