package com.framework.to;

public class ApplicationSystemTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4785187808141002890L;
	private Long applicationId;
	private Long systemId;
	private String dependentType;
	
	public Long getApplicationId() {
	
		return applicationId;
	}
	
	public String getDependentType() {
	
		return dependentType;
	}
	
	public Long getSystemId() {
	
		return systemId;
	}
	
	public void setApplicationId(Long applicationId) {
	
		this.applicationId = applicationId;
	}
	
	public void setDependentType(String dependentType) {
	
		this.dependentType = dependentType;
	}
	
	public void setSystemId(Long systemId) {
	
		this.systemId = systemId;
	}
}