package com.framework.to;

import java.util.ArrayList;
import java.util.List;

public class EmailNotificationTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7504773478379571043L;
	private List<ServiceTO> serviceList = new ArrayList<ServiceTO>(0);
	private List<RoleTO> roleList = new ArrayList<RoleTO>(0);
	private List<Long> definedRoles = new ArrayList<Long>(0);
	private List<Long> roles = new ArrayList<Long>(0);
	private List<RoleTO> allRoles = new ArrayList<RoleTO>(0);
	private List<RoleTO> selectedRoles = new ArrayList<RoleTO>(0);
	private List<ServicesMappingTO> serviceMapList = new ArrayList<>(0);
	private List<ServicesMappingTO> actionList = new ArrayList<>(0);
	private String destinationName;
	private String ccName;
	private String message;
	private Long serviceSize;
	private Long selectedParentServiceId;
	private String selectedAction;
	private List<MailSetupTO> mailsetupToList = new ArrayList<MailSetupTO>(0);
	private List<MailSetupRoleMappingTO> mailsetupRoleMapToList = new ArrayList<MailSetupRoleMappingTO>(0);
	private List<MailSetupServicesMappingTO> mailsetupServicesMapToList = new ArrayList<MailSetupServicesMappingTO>(0);
	private List<BusinessUnitTO> businessUnitList = new ArrayList<BusinessUnitTO>(0);
	private List<ProjectsTO> projectList = new ArrayList<ProjectsTO>(0);
	private List<Long> selectedBuList = new ArrayList<Long>(0);
	private List<Long> selectedProjectList = new ArrayList<Long>(0);
	private long searchCount;
	private int firstResult = 1;
	private int tableSize;
	private Long pageNumber = 1L;
	private String applicationCount;
	private Long selectedService;
	private Long selectedBUId;
	private Long selectedProjectId;
	private Long selectedRole;
	private String actionName;
	private String serviceName;
	private String buName;
	private String roleName;
	private String projectName;
	private String roleCount;
	private String projectCount;
	private Long selectedId;
	private Long selectedClientId;
	private List<Long> selectedBuLists = new ArrayList<Long>(0);
	private String actionExist;
	
	public List<ServicesMappingTO> getActionList() {
	
		return actionList;
	}
	
	public String getActionName() {
	
		return actionName;
	}
	
	public List<RoleTO> getAllRoles() {
	
		return allRoles;
	}
	
	public String getApplicationCount() {
	
		return applicationCount;
	}
	
	public String getBuName() {
	
		return buName;
	}
	
	public List<BusinessUnitTO> getBusinessUnitList() {
	
		return businessUnitList;
	}
	
	public String getCcName() {
	
		return ccName;
	}
	
	public List<Long> getDefinedRoles() {
	
		return definedRoles;
	}
	
	public String getDestinationName() {
	
		return destinationName;
	}
	
	public int getFirstResult() {
	
		return firstResult;
	}
	
	public List<MailSetupRoleMappingTO> getMailsetupRoleMapToList() {
	
		return mailsetupRoleMapToList;
	}
	
	public List<MailSetupServicesMappingTO> getMailsetupServicesMapToList() {
	
		return mailsetupServicesMapToList;
	}
	
	public List<MailSetupTO> getMailsetupToList() {
	
		return mailsetupToList;
	}
	
	public String getMessage() {
	
		return message;
	}
	
	public Long getPageNumber() {
	
		return pageNumber;
	}
	
	public String getProjectCount() {
	
		return projectCount;
	}
	
	public List<ProjectsTO> getProjectList() {
	
		return projectList;
	}
	
	public String getProjectName() {
	
		return projectName;
	}
	
	public String getRoleCount() {
	
		return roleCount;
	}
	
	public List<RoleTO> getRoleList() {
	
		return roleList;
	}
	
	public String getRoleName() {
	
		return roleName;
	}
	
	public List<Long> getRoles() {
	
		return roles;
	}
	
	public long getSearchCount() {
	
		return searchCount;
	}
	
	public String getSelectedAction() {
	
		return selectedAction;
	}
	
	public Long getSelectedBUId() {
	
		return selectedBUId;
	}
	
	public List<Long> getSelectedBuList() {
	
		return selectedBuList;
	}
	
	public List<Long> getSelectedBuLists() {
	
		return selectedBuLists;
	}
	
	public Long getSelectedClientId() {
	
		return selectedClientId;
	}
	
	public Long getSelectedId() {
	
		return selectedId;
	}
	
	public Long getSelectedParentServiceId() {
	
		return selectedParentServiceId;
	}
	
	public Long getSelectedProjectId() {
	
		return selectedProjectId;
	}
	
	public List<Long> getSelectedProjectList() {
	
		return selectedProjectList;
	}
	
	public Long getSelectedRole() {
	
		return selectedRole;
	}
	
	public List<RoleTO> getSelectedRoles() {
	
		return selectedRoles;
	}
	
	public Long getSelectedService() {
	
		return selectedService;
	}
	
	public List<ServiceTO> getServiceList() {
	
		return serviceList;
	}
	
	public List<ServicesMappingTO> getServiceMapList() {
	
		return serviceMapList;
	}
	
	public String getServiceName() {
	
		return serviceName;
	}
	
	public Long getServiceSize() {
	
		return serviceSize;
	}
	
	public int getTableSize() {
	
		return tableSize;
	}
	
	public void setActionList(List<ServicesMappingTO> actionList) {
	
		this.actionList = actionList;
	}
	
	public void setActionName(String actionName) {
	
		this.actionName = actionName;
	}
	
	public void setAllRoles(List<RoleTO> allRoles) {
	
		this.allRoles = allRoles;
	}
	
	public void setApplicationCount(String applicationCount) {
	
		this.applicationCount = applicationCount;
	}
	
	public void setBuName(String buName) {
	
		this.buName = buName;
	}
	
	public void setBusinessUnitList(List<BusinessUnitTO> businessUnitList) {
	
		this.businessUnitList = businessUnitList;
	}
	
	public void setCcName(String ccName) {
	
		this.ccName = ccName;
	}
	
	public void setDefinedRoles(List<Long> definedRoles) {
	
		this.definedRoles = definedRoles;
	}
	
	public void setDestinationName(String destinationName) {
	
		this.destinationName = destinationName;
	}
	
	public void setFirstResult(int firstResult) {
	
		this.firstResult = firstResult;
	}
	
	public void setMailsetupRoleMapToList(List<MailSetupRoleMappingTO> mailsetupRoleMapToList) {
	
		this.mailsetupRoleMapToList = mailsetupRoleMapToList;
	}
	
	public void setMailsetupServicesMapToList(List<MailSetupServicesMappingTO> mailsetupServicesMapToList) {
	
		this.mailsetupServicesMapToList = mailsetupServicesMapToList;
	}
	
	public void setMailsetupToList(List<MailSetupTO> mailsetupToList) {
	
		this.mailsetupToList = mailsetupToList;
	}
	
	public void setMessage(String message) {
	
		this.message = message;
	}
	
	public void setPageNumber(Long pageNumber) {
	
		this.pageNumber = pageNumber;
	}
	
	public void setProjectCount(String projectCount) {
	
		this.projectCount = projectCount;
	}
	
	public void setProjectList(List<ProjectsTO> projectList) {
	
		this.projectList = projectList;
	}
	
	public void setProjectName(String projectName) {
	
		this.projectName = projectName;
	}
	
	public void setRoleCount(String roleCount) {
	
		this.roleCount = roleCount;
	}
	
	public void setRoleList(List<RoleTO> roleList) {
	
		this.roleList = roleList;
	}
	
	public void setRoleName(String roleName) {
	
		this.roleName = roleName;
	}
	
	public void setRoles(List<Long> roles) {
	
		this.roles = roles;
	}
	
	public void setSearchCount(long searchCount) {
	
		this.searchCount = searchCount;
	}
	
	public void setSelectedAction(String selectedAction) {
	
		this.selectedAction = selectedAction;
	}
	
	public void setSelectedBUId(Long selectedBUId) {
	
		this.selectedBUId = selectedBUId;
	}
	
	public void setSelectedBuList(List<Long> selectedBuList) {
	
		this.selectedBuList = selectedBuList;
	}
	
	public void setSelectedBuLists(List<Long> selectedBuLists) {
	
		this.selectedBuLists = selectedBuLists;
	}
	
	public void setSelectedClientId(Long selectedClientId) {
	
		this.selectedClientId = selectedClientId;
	}
	
	public void setSelectedId(Long selectedId) {
	
		this.selectedId = selectedId;
	}
	
	public void setSelectedParentServiceId(Long selectedParentServiceId) {
	
		this.selectedParentServiceId = selectedParentServiceId;
	}
	
	public void setSelectedProjectId(Long selectedProjectId) {
	
		this.selectedProjectId = selectedProjectId;
	}
	
	public void setSelectedProjectList(List<Long> selectedProjectList) {
	
		this.selectedProjectList = selectedProjectList;
	}
	
	public void setSelectedRole(Long selectedRole) {
	
		this.selectedRole = selectedRole;
	}
	
	public void setSelectedRoles(List<RoleTO> selectedRoles) {
	
		this.selectedRoles = selectedRoles;
	}
	
	public void setSelectedService(Long selectedService) {
	
		this.selectedService = selectedService;
	}
	
	public void setServiceList(List<ServiceTO> serviceList) {
	
		this.serviceList = serviceList;
	}
	
	public void setServiceMapList(List<ServicesMappingTO> serviceMapList) {
	
		this.serviceMapList = serviceMapList;
	}
	
	public void setServiceName(String serviceName) {
	
		this.serviceName = serviceName;
	}
	
	public void setServiceSize(Long serviceSize) {
	
		this.serviceSize = serviceSize;
	}
	
	public void setTableSize(int tableSize) {
	
		this.tableSize = tableSize;
	}
	
	public String getActionExist() {
	
		return actionExist;
	}
	
	public void setActionExist(String actionExist) {
	
		this.actionExist = actionExist;
	}
}