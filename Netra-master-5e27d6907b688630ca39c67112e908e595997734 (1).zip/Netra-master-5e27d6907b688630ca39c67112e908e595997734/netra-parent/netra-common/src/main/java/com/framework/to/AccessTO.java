/**
 *
 */
package com.framework.to;

/**
 * @author TCS
 */
public class AccessTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 253145800531542347L;
	private long clientId;
	private long roleId;
	private long screenId;
	private boolean access;
	
	public long getClientId() {
	
		return clientId;
	}
	
	public long getRoleId() {
	
		return roleId;
	}
	
	public long getScreenId() {
	
		return screenId;
	}
	
	public boolean isAccess() {
	
		return access;
	}
	
	public void setAccess(boolean access) {
	
		this.access = access;
	}
	
	public void setClientId(long clientId) {
	
		this.clientId = clientId;
	}
	
	public void setRoleId(long roleId) {
	
		this.roleId = roleId;
	}
	
	public void setScreenId(long screenId) {
	
		this.screenId = screenId;
	}
}
