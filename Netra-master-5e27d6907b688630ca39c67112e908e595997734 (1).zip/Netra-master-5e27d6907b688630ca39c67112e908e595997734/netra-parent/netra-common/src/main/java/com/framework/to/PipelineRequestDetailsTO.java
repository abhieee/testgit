package com.framework.to;

import java.util.ArrayList;
import java.util.List;

public class PipelineRequestDetailsTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 119479618323911525L;
	private Long requestId;
	private Long phaseId;
	private Long environmentId;
	private Long statusId;
	private Long phaseExecutionOrder;
	private String comments;
	private ServiceRequestTO serviceRequestTO;
	List<TestingPhaseTO> testingPhases = new ArrayList<TestingPhaseTO>(0);
	private Long serviceId;
	List<Long> serviceList = new ArrayList<Long>(0);
	
	public String getComments() {
	
		return comments;
	}
	
	public Long getEnvironmentId() {
	
		return environmentId;
	}
	
	public Long getPhaseExecutionOrder() {
	
		return phaseExecutionOrder;
	}
	
	public Long getPhaseId() {
	
		return phaseId;
	}
	
	public Long getRequestId() {
	
		return requestId;
	}
	
	public Long getServiceId() {
	
		return serviceId;
	}
	
	public List<Long> getServiceList() {
	
		return serviceList;
	}
	
	public ServiceRequestTO getServiceRequestTO() {
	
		return serviceRequestTO;
	}
	
	public Long getStatusId() {
	
		return statusId;
	}
	
	public List<TestingPhaseTO> getTestingPhases() {
	
		return testingPhases;
	}
	
	public void setComments(String comments) {
	
		this.comments = comments;
	}
	
	public void setEnvironmentId(Long environmentId) {
	
		this.environmentId = environmentId;
	}
	
	public void setPhaseExecutionOrder(Long phaseExecutionOrder) {
	
		this.phaseExecutionOrder = phaseExecutionOrder;
	}
	
	public void setPhaseId(Long phaseId) {
	
		this.phaseId = phaseId;
	}
	
	public void setRequestId(Long requestId) {
	
		this.requestId = requestId;
	}
	
	public void setServiceId(Long serviceId) {
	
		this.serviceId = serviceId;
	}
	
	public void setServiceList(List<Long> serviceList) {
	
		this.serviceList = serviceList;
	}
	
	public void setServiceRequestTO(ServiceRequestTO serviceRequestTO) {
	
		this.serviceRequestTO = serviceRequestTO;
	}
	
	public void setStatusId(Long statusId) {
	
		this.statusId = statusId;
	}
	
	public void setTestingPhases(List<TestingPhaseTO> testingPhases) {
	
		this.testingPhases = testingPhases;
	}
}
