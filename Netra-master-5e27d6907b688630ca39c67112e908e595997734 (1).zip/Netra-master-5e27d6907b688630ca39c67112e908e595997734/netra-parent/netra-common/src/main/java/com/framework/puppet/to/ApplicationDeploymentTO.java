package com.framework.puppet.to;

public class ApplicationDeploymentTO {
	
	private String ip;
	private String dnsname;
	private String source;
	private String uname;
	private String pwd;
	private String warpath;
	
	public String getDnsname() {
	
		return dnsname;
	}
	
	public String getIp() {
	
		return ip;
	}
	
	public String getPwd() {
	
		return pwd;
	}
	
	public String getSource() {
	
		return source;
	}
	
	public String getUname() {
	
		return uname;
	}
	
	public String getWarpath() {
	
		return warpath;
	}
	
	public void setDnsname(String dnsname) {
	
		this.dnsname = dnsname;
	}
	
	public void setIp(String ip) {
	
		this.ip = ip;
	}
	
	public void setPwd(String pwd) {
	
		this.pwd = pwd;
	}
	
	public void setSource(String source) {
	
		this.source = source;
	}
	
	public void setUname(String uname) {
	
		this.uname = uname;
	}
	
	public void setWarpath(String warpath) {
	
		this.warpath = warpath;
	}
}
