/**
 *
 */
package com.framework.nolio.to;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @author 460650
 */
public class NolioProcess implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5082976295134096366L;
	private Long processId;
	private List<Long> process = new ArrayList<Long>();
	private String applicationName;
	private String environmentName;
	private String serverType;
	private String processFullPath;
	private String processTag;
	private Set<NolioProcessParametersTO> nolioProcessParameters = new HashSet<NolioProcessParametersTO>(0);
	private String status;
	private List<NolioProcessParametersTO> nolioProcessParameterList = new ArrayList<NolioProcessParametersTO>(0);
	private List<NolioProcess> allProcess = new ArrayList<NolioProcess>();
	private Long tmpList;
	
	public List<NolioProcess> getAllProcess() {
	
		return allProcess;
	}
	
	/**
	 * @return the processId
	 */
	/**
	 * @param processId
	 *                the processId to set
	 */
	/**
	 * @return the applicationName
	 */
	public String getApplicationName() {
	
		return applicationName;
	}
	
	/**
	 * @return the environmentName
	 */
	public String getEnvironmentName() {
	
		return environmentName;
	}
	
	public List<NolioProcessParametersTO> getNolioProcessParameterList() {
	
		return nolioProcessParameterList;
	}
	
	public Set<NolioProcessParametersTO> getNolioProcessParameters() {
	
		return nolioProcessParameters;
	}
	
	public List<Long> getProcess() {
	
		return process;
	}
	
	/**
	 * @return the processFullPath
	 */
	public String getProcessFullPath() {
	
		return processFullPath;
	}
	
	public Long getProcessId() {
	
		return processId;
	}
	
	/**
	 * @return the processTag
	 */
	public String getProcessTag() {
	
		return processTag;
	}
	
	public String getServerType() {
	
		return serverType;
	}
	
	public String getStatus() {
	
		return status;
	}
	
	public void setAllProcess(List<NolioProcess> allProcess) {
	
		this.allProcess = allProcess;
	}
	
	/**
	 * @param applicationName
	 *                the applicationName to set
	 */
	public void setApplicationName(String applicationName) {
	
		this.applicationName = applicationName;
	}
	
	/**
	 * @param environmentName
	 *                the environmentName to set
	 */
	public void setEnvironmentName(String environmentName) {
	
		this.environmentName = environmentName;
	}
	
	public void setNolioProcessParameterList(List<NolioProcessParametersTO> nolioProcessParameterList) {
	
		this.nolioProcessParameterList = nolioProcessParameterList;
	}
	
	public void setNolioProcessParameters(Set<NolioProcessParametersTO> nolioProcessParameters) {
	
		this.nolioProcessParameters = nolioProcessParameters;
	}
	
	public void setProcess(List<Long> process) {
	
		this.process = process;
	}
	
	/**
	 * @param processFullPath
	 *                the processFullPath to set
	 */
	public void setProcessFullPath(String processFullPath) {
	
		this.processFullPath = processFullPath;
	}
	
	public void setProcessId(Long processId) {
	
		this.processId = processId;
	}
	
	/**
	 * @param processTag
	 *                the processTag to set
	 */
	public void setProcessTag(String processTag) {
	
		this.processTag = processTag;
	}
	
	public void setServerType(String serverType) {
	
		this.serverType = serverType;
	}
	
	public void setStatus(String status) {
	
		this.status = status;
	}
	
	public Long getTmpList() {
	
		return tmpList;
	}
	
	public void setTmpList(Long tmpList) {
	
		this.tmpList = tmpList;
	}
}
