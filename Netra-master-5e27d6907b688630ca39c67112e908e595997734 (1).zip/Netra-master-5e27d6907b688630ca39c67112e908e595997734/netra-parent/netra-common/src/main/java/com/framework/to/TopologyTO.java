package com.framework.to;

import java.io.File;
import java.text.ParseException;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import com.framework.common.CMMConstants;
import com.framework.exception.CMMException;
import com.framework.utility.DateUtils;

/**
 * This class declares the transfer onject that carries topology information across the application.
 *
 * @author TCS
 */
public class TopologyTO extends NamedEntityTO {
	
	private static final long serialVersionUID = 4573265526399617683L;
	private UserTO author = null;
	private Set<DeviceTO> devices = null;
	private Set<ReservationTO> reservations = null;
	private String vsdFileLocation = null;
	private File vsdFile = null;
	private Date lastModified = null;
	private Long domainId = null;
	private String status = null;
	private String description = null;
	private Long utilization = null;
	private Set<TopologyTO> subtopologies = null;
	
	public TopologyTO() {
	
		super();
		status = CMMConstants.Framework.TopologyStatus.AVAILABLE;
	}
	
	public void addReservation(ReservationTO reservation) {
	
		if (this.reservations == null) {
			this.reservations = new HashSet<ReservationTO>();
		}
		this.reservations.add(reservation);
	}
	
	public void copy(TopologyTO topology) throws CMMException {
	
		if (topology == null) {
			topology = new TopologyTO();
		}
		if ((topology.getName() == null) || !topology.getName().equals(this.getName())) {
			topology.setName(this.getName());
		}
		if ((topology.getVsdFileLocation() == null) || !topology.getVsdFileLocation().equals(this.getVsdFileLocation())) {
			topology.setVsdFileLocation(this.getVsdFileLocation());
		}
		if ((topology.getLastModified() == null) || !topology.getLastModified().equals(this.getLastModified())) {
			topology.setLastModified(this.getLastModified());
		}
		if ((topology.getStatus() == null) || !topology.getStatus().equals(this.getStatus())) {
			topology.setStatus(this.getStatus());
		}
		if ((topology.getDescription() == null) || !topology.getDescription().equals(this.getDescription())) {
			topology.setDescription(this.getDescription());
		}
	}
	
	/**
	 * @return the author
	 */
	public UserTO getAuthor() {
	
		return author;
	}
	
	/**
	 * @return the description
	 */
	public String getDescription() {
	
		return description;
	}
	
	/**
	 * @return the devices
	 */
	public Set<DeviceTO> getDevices() {
	
		return devices;
	}
	
	public Set<Long> getDisruptiveDeviceIds() {
	
		Set<Long> allDisruptiveDeviceIds = new HashSet<Long>();
		if ((this.getReservations() == null) || this.getReservations().isEmpty()) {
			return allDisruptiveDeviceIds;
		}
		for (ReservationTO reservation : this.getReservations()) {
			Set<Long> disruptiveDeviceIds = reservation.getDisruptiveDeviceIds();
			if (disruptiveDeviceIds != null) {
				allDisruptiveDeviceIds.addAll(disruptiveDeviceIds);
			}
		}
		return allDisruptiveDeviceIds;
	}
	
	public Set<DisruptiveFailureTO> getDisruptiveFailures() {
	
		Set<DisruptiveFailureTO> disruptiveFailures = new HashSet<DisruptiveFailureTO>();
		if ((this.getReservations() == null) || this.getReservations().isEmpty()) {
			return disruptiveFailures;
		}
		for (ReservationTO res : this.getReservations()) {
			Set<DisruptiveFailureTO> resDisruptiveFailures = res.getDisruptiveFailures();
			disruptiveFailures.addAll(resDisruptiveFailures);
		}
		return disruptiveFailures;
	}
	
	/**
	 * @return the domainId
	 */
	public Long getDomainId() {
	
		return domainId;
	}
	
	/**
	 * @return the lastModified
	 */
	public Date getLastModified() {
	
		return lastModified;
	}
	
	/**
	 * @return the reservations
	 */
	public Set<ReservationTO> getReservations() {
	
		return reservations;
	}
	
	/**
	 * @return the status
	 */
	public String getStatus() {
	
		return status;
	}
	
	/**
	 * @return the subtopologies
	 */
	public Set<TopologyTO> getSubtopologies() {
	
		return subtopologies;
	}
	
	/**
	 * @return the utilization
	 */
	public Long getUtilization() {
	
		return utilization;
	}
	
	/**
	 * @return the vsdFile
	 */
	public File getVsdFile() {
	
		return vsdFile;
	}
	
	/**
	 * @return the vsdFileLocation
	 */
	public String getVsdFileLocation() {
	
		return vsdFileLocation;
	}
	
	/**
	 * @param author
	 *                the author to set
	 */
	public void setAuthor(UserTO author) {
	
		this.author = author;
	}
	
	/**
	 * @param description
	 *                the description to set
	 */
	public void setDescription(String description) {
	
		this.description = description;
	}
	
	/**
	 * @param devices
	 *                the devices to set
	 */
	public void setDevices(Set<DeviceTO> devices) {
	
		this.devices = devices;
	}
	
	/**
	 * @param domainId
	 *                the domainId to set
	 */
	public void setDomainId(Long domainId) {
	
		this.domainId = domainId;
	}
	
	/**
	 * @param lastModified
	 *                the lastModified to set
	 */
	public void setLastModified(Date lastModified) {
	
		this.lastModified = lastModified;
	}
	
	public void setLastModified(String lastModified) throws ParseException {
	
		if (lastModified == null) {
			this.lastModified = null;
		} else {
			this.lastModified = DateUtils.parseDate(lastModified);
		}
	}
	
	/**
	 * @param reservations
	 *                the reservations to set
	 */
	public void setReservations(Set<ReservationTO> reservations) {
	
		this.reservations = reservations;
	}
	
	/**
	 * @param status
	 *                the status to set
	 */
	public void setStatus(String status) throws CMMException {
	
		if (this.status == null) {
			this.status = status;
			return;
		}
		if (this.status.equalsIgnoreCase(CMMConstants.Framework.TopologyStatus.LOCKED)) {
			if (status.equalsIgnoreCase(CMMConstants.Framework.TopologyStatus.AVAILABLE)) {
				this.status = status;
			} else {
				throw new CMMException("Selected Topology status is " + this.status + ". It can not change into " + status);
			}
		} else if (this.status.equals(CMMConstants.Framework.TopologyStatus.PURGED)) {
			throw new CMMException("Selected Topology status is " + this.status + ". It can not change into " + status);
		} else if (this.status.equals(CMMConstants.Framework.TopologyStatus.ARCHIVED)) {
			if (status.equalsIgnoreCase(CMMConstants.Framework.TopologyStatus.AVAILABLE)) {
				this.status = status;
			} else {
				throw new CMMException("Selected Topology status is " + this.status + ". It can not change into " + status);
			}
		} else if (this.status.equals(CMMConstants.Framework.TopologyStatus.RESERVED)) {
			if (status.equalsIgnoreCase(CMMConstants.Framework.TopologyStatus.AVAILABLE)) {
				this.status = status;
			} else {
				throw new CMMException("Selected Topology status is " + this.status + ". It can not change into " + status);
			}
		} else {
			this.status = status;
		}
	}
	
	/**
	 * @param subtopologies
	 *                the subtopologies to set
	 */
	public void setSubtopologies(Set<TopologyTO> subtopologies) {
	
		this.subtopologies = subtopologies;
	}
	
	/**
	 * @param utilization
	 *                the utilization to set
	 */
	public void setUtilization(Long utilization) {
	
		this.utilization = utilization;
	}
	
	/**
	 * @param vsdFile
	 *                the vsdFile to set
	 */
	public void setVsdFile(File vsdFile) {
	
		this.vsdFile = vsdFile;
	}
	
	/**
	 * @param vsdFileLocation
	 *                the vsdFileLocation to set
	 */
	public void setVsdFileLocation(String vsdFileLocation) {
	
		this.vsdFileLocation = vsdFileLocation;
	}
}
