package com.framework.to;

import java.util.List;

public class UserGroupDetailsTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private UserTO users;
	private UserGroupTO userGroups;
	private List<UserTO> selectedUserList = null;
	private List<Long> selectedUserName = null;
	
	public List<UserTO> getSelectedUserList() {
	
		return selectedUserList;
	}
	
	public List<Long> getSelectedUserName() {
	
		return selectedUserName;
	}
	
	public UserGroupTO getUserGroups() {
	
		return userGroups;
	}
	
	public UserTO getUsers() {
	
		return users;
	}
	
	public void setSelectedUserList(List<UserTO> selectedUserList) {
	
		this.selectedUserList = selectedUserList;
	}
	
	public void setSelectedUserName(List<Long> selectedUserName) {
	
		this.selectedUserName = selectedUserName;
	}
	
	public void setUserGroups(UserGroupTO userGroups) {
	
		this.userGroups = userGroups;
	}
	
	public void setUsers(UserTO users) {
	
		this.users = users;
	}
}
