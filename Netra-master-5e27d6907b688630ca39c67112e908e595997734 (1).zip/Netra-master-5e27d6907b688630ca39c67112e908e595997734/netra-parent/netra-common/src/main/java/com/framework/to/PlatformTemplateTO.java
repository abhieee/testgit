package com.framework.to;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class PlatformTemplateTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6074774785885457113L;
	private String type;
	private String family;
	private String distribution = null;
	private String version = null;
	private String pack = null;
	private String architecture = null;
	private StatusTO statusTO;
	private Long status;
	private String platformName;
	private String label;
	private String value;
	private String username;
	private String password;
	private PlatformMasterTO platform;
	private String description;
	private Byte activeFlag;
	private Long createdBy;
	private Date createdOn;
	private Long updatedBy;
	private Date updatedOn;
	private List<PlatformTypeTO> allPlatformTypes = null;
	private List<PlatformTypeTO> allFamilyTypes = null;
	private Set<TemplateVMWareTO> platformTemplateVMware;
	private List<VSphereDetailsTO> vsphereList = new ArrayList<VSphereDetailsTO>(0);
	private Set<PlatformTemplateAwsTO> platformTemplateAws;
	private String cpu;
	private String ram;
	private String machineTemplateId;
	private String platformTemplateId;
	private int tableSize = 10;
	private Long pageNumber = 1L;
	private int firstResult = 0;
	private long searchCount;
	private Set<PlatformTemplateBareMetalTO> platformTemplateBareMetal;
	private MachineTemplateBareMetalTO machineTemplateBareMetalTO;
	private PlatformTemplateBareMetalTO platformTemplateBareMetalTO;
	private MachineTemplateTO machineTemplateTO;
	private String hardDisk;
	private Set<PlatformTemplateOSTO> platformTemplateOSTOSet;
	private PlatformTemplateOSTO platformTemplateOSTO;
	private String instanceType;
	
	public PlatformTemplateTO() {
	
		platformTemplateVMware = new HashSet<TemplateVMWareTO>();
		platformTemplateAws = new HashSet<PlatformTemplateAwsTO>();
		platformTemplateOSTOSet = new HashSet<PlatformTemplateOSTO>();
	}
	
	public Byte getActiveFlag() {
	
		return activeFlag;
	}
	
	public List<PlatformTypeTO> getAllFamilyTypes() {
	
		return allFamilyTypes;
	}
	
	public List<PlatformTypeTO> getAllPlatformTypes() {
	
		return allPlatformTypes;
	}
	
	public String getArchitecture() {
	
		return architecture;
	}
	
	public String getCpu() {
	
		return cpu;
	}
	
	public Long getCreatedBy() {
	
		return createdBy;
	}
	
	public Date getCreatedOn() {
	
		return createdOn;
	}
	
	public String getDescription() {
	
		return description;
	}
	
	public String getDistribution() {
	
		return distribution;
	}
	
	public String getFamily() {
	
		return family;
	}
	
	/**
	 * @return the firstResult
	 */
	public int getFirstResult() {
	
		return firstResult;
	}
	
	public String getHardDisk() {
	
		return hardDisk;
	}
	
	public String getInstanceType() {
	
		return instanceType;
	}
	
	public String getLabel() {
	
		return label;
	}
	
	public MachineTemplateBareMetalTO getMachineTemplateBareMetalTO() {
	
		return machineTemplateBareMetalTO;
	}
	
	public String getMachineTemplateId() {
	
		return machineTemplateId;
	}
	
	public MachineTemplateTO getMachineTemplateTO() {
	
		return machineTemplateTO;
	}
	
	public String getPack() {
	
		return pack;
	}
	
	/**
	 * @return the pageNumber
	 */
	public Long getPageNumber() {
	
		return pageNumber;
	}
	
	public String getPassword() {
	
		return password;
	}
	
	public PlatformMasterTO getPlatform() {
	
		return platform;
	}
	
	public String getPlatformName() {
	
		return platformName;
	}
	
	public Set<PlatformTemplateAwsTO> getPlatformTemplateAws() {
	
		return platformTemplateAws;
	}
	
	/**
	 * @return the platformTemplateBareMetal
	 */
	public Set<PlatformTemplateBareMetalTO> getPlatformTemplateBareMetal() {
	
		return platformTemplateBareMetal;
	}
	
	public PlatformTemplateBareMetalTO getPlatformTemplateBareMetalTO() {
	
		return platformTemplateBareMetalTO;
	}
	
	public String getPlatformTemplateId() {
	
		return platformTemplateId;
	}
	
	public PlatformTemplateOSTO getPlatformTemplateOSTO() {
	
		return platformTemplateOSTO;
	}
	
	public Set<PlatformTemplateOSTO> getPlatformTemplateOSTOSet() {
	
		return platformTemplateOSTOSet;
	}
	
	public Set<TemplateVMWareTO> getPlatformTemplateVMware() {
	
		return platformTemplateVMware;
	}
	
	public String getRam() {
	
		return ram;
	}
	
	/**
	 * @return the searchCount
	 */
	public long getSearchCount() {
	
		return searchCount;
	}
	
	public Long getStatus() {
	
		return status;
	}
	
	public StatusTO getStatusTO() {
	
		return statusTO;
	}
	
	/**
	 * @return the tableSize
	 */
	public int getTableSize() {
	
		return tableSize;
	}
	
	public String getType() {
	
		return type;
	}
	
	public Long getUpdatedBy() {
	
		return updatedBy;
	}
	
	public Date getUpdatedOn() {
	
		return updatedOn;
	}
	
	public String getUsername() {
	
		return username;
	}
	
	public String getValue() {
	
		return value;
	}
	
	public String getVersion() {
	
		return version;
	}
	
	public List<VSphereDetailsTO> getVsphereList() {
	
		return vsphereList;
	}
	
	public void setActiveFlag(Byte activeFlag) {
	
		this.activeFlag = activeFlag;
	}
	
	public void setAllFamilyTypes(List<PlatformTypeTO> allFamilyTypes) {
	
		this.allFamilyTypes = allFamilyTypes;
	}
	
	public void setAllPlatformTypes(List<PlatformTypeTO> allPlatformTypes) {
	
		this.allPlatformTypes = allPlatformTypes;
	}
	
	public void setArchitecture(String architecture) {
	
		this.architecture = architecture;
	}
	
	public void setCpu(String cpu) {
	
		this.cpu = cpu;
	}
	
	public void setCreatedBy(Long createdBy) {
	
		this.createdBy = createdBy;
	}
	
	public void setCreatedOn(Date createdOn) {
	
		this.createdOn = createdOn;
	}
	
	public void setDescription(String description) {
	
		this.description = description;
	}
	
	public void setDistribution(String distribution) {
	
		this.distribution = distribution;
	}
	
	public void setFamily(String family) {
	
		this.family = family;
	}
	
	/**
	 * @param firstResult
	 *                the firstResult to set
	 */
	public void setFirstResult(int firstResult) {
	
		this.firstResult = firstResult;
	}
	
	public void setHardDisk(String hardDisk) {
	
		this.hardDisk = hardDisk;
	}
	
	public void setInstanceType(String instanceType) {
	
		this.instanceType = instanceType;
	}
	
	public void setLabel(String label) {
	
		this.label = label;
	}
	
	public void setMachineTemplateBareMetalTO(MachineTemplateBareMetalTO machineTemplateBareMetalTO) {
	
		this.machineTemplateBareMetalTO = machineTemplateBareMetalTO;
	}
	
	public void setMachineTemplateId(String machineTemplateId) {
	
		this.machineTemplateId = machineTemplateId;
	}
	
	public void setMachineTemplateTO(MachineTemplateTO machineTemplateTO) {
	
		this.machineTemplateTO = machineTemplateTO;
	}
	
	public void setPack(String pack) {
	
		this.pack = pack;
	}
	
	/**
	 * @param pageNumber
	 *                the pageNumber to set
	 */
	public void setPageNumber(Long pageNumber) {
	
		this.pageNumber = pageNumber;
	}
	
	public void setPassword(String password) {
	
		this.password = password;
	}
	
	public void setPlatform(PlatformMasterTO platform) {
	
		this.platform = platform;
	}
	
	public void setPlatformName(String platformName) {
	
		this.platformName = platformName;
	}
	
	public void setPlatformTemplateAws(Set<PlatformTemplateAwsTO> platformTemplateAws) {
	
		this.platformTemplateAws = platformTemplateAws;
	}
	
	/**
	 * @param platformTemplateBareMetal
	 *                the platformTemplateBareMetal to set
	 */
	public void setPlatformTemplateBareMetal(Set<PlatformTemplateBareMetalTO> platformTemplateBareMetal) {
	
		this.platformTemplateBareMetal = platformTemplateBareMetal;
	}
	
	public void setPlatformTemplateBareMetalTO(PlatformTemplateBareMetalTO platformTemplateBareMetalTO) {
	
		this.platformTemplateBareMetalTO = platformTemplateBareMetalTO;
	}
	
	public void setPlatformTemplateId(String platformTemplateId) {
	
		this.platformTemplateId = platformTemplateId;
	}
	
	public void setPlatformTemplateOSTO(PlatformTemplateOSTO platformTemplateOSTO) {
	
		this.platformTemplateOSTO = platformTemplateOSTO;
	}
	
	public void setPlatformTemplateOSTOSet(Set<PlatformTemplateOSTO> platformTemplateOSTOSet) {
	
		this.platformTemplateOSTOSet = platformTemplateOSTOSet;
	}
	
	public void setPlatformTemplateVMware(Set<TemplateVMWareTO> platformTemplateVMware) {
	
		this.platformTemplateVMware = platformTemplateVMware;
	}
	
	public void setRam(String ram) {
	
		this.ram = ram;
	}
	
	/**
	 * @param searchCount
	 *                the searchCount to set
	 */
	public void setSearchCount(long searchCount) {
	
		this.searchCount = searchCount;
	}
	
	public void setStatus(Long status) {
	
		this.status = status;
	}
	
	public void setStatusTO(StatusTO statusTO) {
	
		this.statusTO = statusTO;
	}
	
	/**
	 * @param tableSize
	 *                the tableSize to set
	 */
	public void setTableSize(int tableSize) {
	
		this.tableSize = tableSize;
	}
	
	public void setType(String type) {
	
		this.type = type;
	}
	
	public void setUpdatedBy(Long updatedBy) {
	
		this.updatedBy = updatedBy;
	}
	
	public void setUpdatedOn(Date updatedOn) {
	
		this.updatedOn = updatedOn;
	}
	
	public void setUsername(String username) {
	
		this.username = username;
	}
	
	public void setValue(String value) {
	
		this.value = value;
	}
	
	public void setVersion(String version) {
	
		this.version = version;
	}
	
	public void setVsphereList(List<VSphereDetailsTO> vsphereList) {
	
		this.vsphereList = vsphereList;
	}
}
