package com.framework.to;

public class ServiceNowConfigTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4594526973266300057L;
	private String username;
	private String baseURL;
	private String password;
	private Long port;
	private String proxyURL;
	private Long proxyPort;
	private String proxyPassword;
	private String proxyUsername;
	private String proxyPasswordEnc;
	private String passwordEnc;
	
	public String getProxyURL() {
	
		return proxyURL;
	}
	
	public void setProxyURL(String proxyURL) {
	
		this.proxyURL = proxyURL;
	}
	
	public Long getProxyPort() {
	
		return proxyPort;
	}
	
	public void setProxyPort(Long proxyPort) {
	
		this.proxyPort = proxyPort;
	}
	
	public String getProxyPassword() {
	
		return proxyPassword;
	}
	
	public void setProxyPassword(String proxyPassword) {
	
		this.proxyPassword = proxyPassword;
	}
	
	public String getProxyUsername() {
	
		return proxyUsername;
	}
	
	public void setProxyUsername(String proxyUsername) {
	
		this.proxyUsername = proxyUsername;
	}
	
	public String getUsername() {
	
		return username;
	}
	
	public void setUsername(String username) {
	
		this.username = username;
	}
	
	public String getBaseURL() {
	
		return baseURL;
	}
	
	public void setBaseURL(String baseURL) {
	
		this.baseURL = baseURL;
	}
	
	public String getPassword() {
	
		return password;
	}
	
	public void setPassword(String password) {
	
		this.password = password;
	}
	
	public Long getPort() {
	
		return port;
	}
	
	public void setPort(Long port) {
	
		this.port = port;
	}
	
	public String getProxyPasswordEnc() {
	
		return proxyPasswordEnc;
	}
	
	public void setProxyPasswordEnc(String proxyPasswordEnc) {
	
		this.proxyPasswordEnc = proxyPasswordEnc;
	}
	
	public String getPasswordEnc() {
	
		return passwordEnc;
	}
	
	public void setPasswordEnc(String passwordEnc) {
	
		this.passwordEnc = passwordEnc;
	}
}
