package com.framework.utility;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.apache.log4j.Logger;
import com.framework.common.CMMViewComparator;
import com.framework.exception.CMMException;
import com.framework.to.AbstractTO;
import com.framework.to.EnvironmentTO;
import com.framework.to.NamedEntityTO;

/**
 * @author TCS
 */
public class TOHelper {
	
	private TOHelper() {
	
	}
	
	// ----- ---------------------------------------------------------------------------------------------- -----
	// ----- CHANGE ALL THESE METHODS TO ONE METHOD USING NAMEDENTITYTO or ABSTRACTTO CLASS AND COMPARATORS -----
	// ----- ---------------------------------------------------------------------------------------------- -----
	private static final Logger LOG = Logger.getLogger(TOHelper.class);
	
	public static EnvironmentTO getTopologyFromList(Collection<EnvironmentTO> environments, Long environmentId) {
	
		if (environments == null) {
			return null;
		}
		for (EnvironmentTO environment : environments) {
			if (environment.getId().equals(environmentId)) {
				return environment;
			}
		}
		return null;
	}
	
	public static NamedEntityTO getNamedEntityFromList(String name, Collection collection) {
	
		Set<NamedEntityTO> namesSet = (Set<NamedEntityTO>) collection;
		for (NamedEntityTO item : namesSet) {
			if (item.getName().equals(name)) {
				return item;
			}
		}
		return null;
	}
	
	public static Object getObjectInListOrNew(String name, Map map, NamedEntityTO obj, Class cls) throws CMMException {
	
		if ((obj != null) && obj.getName().equals(name)) {
			return obj;
		}
		if (map.containsKey(name)) {
			return map.get(name);
		}
		Object newObj;
		try {
			newObj = cls.newInstance();
			((NamedEntityTO) newObj).setName(name);
			map.put(name, newObj);
		} catch (InstantiationException e) {
			LOG.error("Problem encountered. TOHelper : GetObjectInListOrNew ", e);
			throw new CMMException("Problem encountered. TOHelper : GetObjectInListOrNew", e);
		} catch (IllegalAccessException e) {
			LOG.error("Problem encountered. TOHelper : GetObjectInListOrNew ", e);
			throw new CMMException("Problem encountered. TOHelper : GetObjectInListOrNew", e);
		}
		return newObj;
	}
	
	public static Object getObjectInListOrNew(String name, Set set, NamedEntityTO obj, Class cls) throws CMMException {
	
		for (NamedEntityTO namedEntity : (Set<NamedEntityTO>) set) {
			if (namedEntity.getName().equalsIgnoreCase(name)) {
				return namedEntity;
			}
		}
		Object newObj;
		try {
			newObj = cls.newInstance();
			((NamedEntityTO) newObj).setName(name);
			set.add(newObj);
		} catch (InstantiationException e) {
			LOG.error("Problem encountered. TOHelper : GetObjectInListOrNew ", e);
			throw new CMMException("Problem encountered. TOHelper : GetObjectInListOrNew", e);
		} catch (IllegalAccessException e) {
			LOG.error("Problem encountered. TOHelper : GetObjectInListOrNew ", e);
			throw new CMMException("Problem encountered. TOHelper : GetObjectInListOrNew", e);
		}
		return newObj;
	}
	
	public static Object getObjectInListOrNew(String name, List list, NamedEntityTO obj, Class cls) throws CMMException {
	
		for (NamedEntityTO namedEntity : (List<NamedEntityTO>) list) {
			if (namedEntity.getName().equalsIgnoreCase(name)) {
				return namedEntity;
			}
		}
		Object newObj;
		try {
			newObj = cls.newInstance();
			((NamedEntityTO) newObj).setName(name);
			list.add(newObj);
		} catch (InstantiationException e) {
			LOG.error("Problem encountered. TOHelper : GetObjectInListOrNew ", e);
			throw new CMMException("Problem encountered. TOHelper : GetObjectInListOrNew", e);
		} catch (IllegalAccessException e) {
			LOG.error("Problem encountered. TOHelper : GetObjectInListOrNew ", e);
			throw new CMMException("Problem encountered. TOHelper : GetObjectInListOrNew", e);
		}
		return newObj;
	}
	
	public static void addToListIfNotAdded(Set set, NamedEntityTO obj) {
	
		for (NamedEntityTO namedEntity : (Set<NamedEntityTO>) set) {
			if (namedEntity.getName().equalsIgnoreCase(obj.getName())) {
				return;
			}
		}
		set.add(obj);
	}
	
	public static Map getIDToNameMap(Collection col) {
	
		Map map = new HashMap(col.size());
		for (Object to : col) {
			map.put(((NamedEntityTO) to).getId(), ((NamedEntityTO) to).getName());
		}
		return map;
	}
	
	public static Set<Long> getIds(Collection list) {
	
		if (list == null) {
			return null;
		}
		Set Ids = new HashSet<Long>();
		for (AbstractTO to : (Collection<AbstractTO>) list) {
			Ids.add(to.getId());
		}
		return Ids;
	}
	
	public static String getNames(Collection list) {
	
		StringBuilder names = new StringBuilder("none");
		if (list == null) {
			return names.toString();
		}
		boolean firstName = true;
		for (NamedEntityTO to : (Collection<NamedEntityTO>) list) {
			if (firstName) {
				names = new StringBuilder("");
				names.append(to.getName());
				firstName = false;
			} else {
				names.append(", " + to.getName());
			}
		}
		return names.toString();
	}
	
	public static void sortListForUI(List<NamedEntityTO> list) {
	
		Collections.sort(list, CMMViewComparator.getInstance());
	}
}
