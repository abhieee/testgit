package com.framework.to;

import java.io.Serializable;

public class LifeCycleServiceManagementServiceTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5873021000092880485L;
	private Long id;
	private Long serviceOrder;
	private LifeCycleServiceManagementTO lifeCycleServiceManagement;
	private Long serviceId;
	private String name;
	
	public Long getId() {
	
		return id;
	}
	
	public LifeCycleServiceManagementTO getLifeCycleServiceManagement() {
	
		return lifeCycleServiceManagement;
	}
	
	/**
	 * @return the name
	 */
	public String getName() {
	
		return name;
	}
	
	public Long getServiceId() {
	
		return serviceId;
	}
	
	public Long getServiceOrder() {
	
		return serviceOrder;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setLifeCycleServiceManagement(LifeCycleServiceManagementTO lifeCycleServiceManagement) {
	
		this.lifeCycleServiceManagement = lifeCycleServiceManagement;
	}
	
	/**
	 * @param name
	 *                the name to set
	 */
	public void setName(String name) {
	
		this.name = name;
	}
	
	public void setServiceId(Long serviceId) {
	
		this.serviceId = serviceId;
	}
	
	public void setServiceOrder(Long serviceOrder) {
	
		this.serviceOrder = serviceOrder;
	}
}
