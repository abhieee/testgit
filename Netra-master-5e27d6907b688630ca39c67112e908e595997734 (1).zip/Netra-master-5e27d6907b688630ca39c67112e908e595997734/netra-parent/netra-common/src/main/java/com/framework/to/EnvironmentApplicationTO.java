package com.framework.to;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class EnvironmentApplicationTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8753879115077030489L;
	private ApplicationTO applicationTO;
	private List<Long> definedApplications;
	private EnvironmentTO environmentTO;
	private ApplicationReleaseTO applicationReleaseTO;
	private Long applicationId;
	private Long releaseId;
	private Long envId;
	private boolean access;
	private String timeStamp;
	private Set<ReservationTO> environmentReservationTO = new HashSet<ReservationTO>(0);
	private Set<EnvironmentSoftParamsTO> environmentSoftParamsTO = new HashSet<EnvironmentSoftParamsTO>(0);
	private Long selectedTestingPhase;
	private TestingPhaseTO testingPhaseTO;
	
	public Long getApplicationId() {
	
		return applicationId;
	}
	
	public ApplicationReleaseTO getApplicationReleaseTO() {
	
		return applicationReleaseTO;
	}
	
	public ApplicationTO getApplicationTO() {
	
		return applicationTO;
	}
	
	public List<Long> getDefinedApplications() {
	
		return definedApplications;
	}
	
	public Long getEnvId() {
	
		return envId;
	}
	
	public Set<ReservationTO> getEnvironmentReservationTO() {
	
		return environmentReservationTO;
	}
	
	public Set<EnvironmentSoftParamsTO> getEnvironmentSoftParamsTO() {
	
		return environmentSoftParamsTO;
	}
	
	public EnvironmentTO getEnvironmentTO() {
	
		return environmentTO;
	}
	
	public Long getReleaseId() {
	
		return releaseId;
	}
	
	public String getTimeStamp() {
	
		return timeStamp;
	}
	
	public boolean isAccess() {
	
		return access;
	}
	
	public void setAccess(boolean access) {
	
		this.access = access;
	}
	
	public void setApplicationId(Long applicationId) {
	
		this.applicationId = applicationId;
	}
	
	public void setApplicationReleaseTO(ApplicationReleaseTO applicationReleaseTO) {
	
		this.applicationReleaseTO = applicationReleaseTO;
	}
	
	public void setApplicationTO(ApplicationTO applicationTO) {
	
		this.applicationTO = applicationTO;
	}
	
	public void setDefinedApplications(List<Long> definedApplications) {
	
		this.definedApplications = definedApplications;
	}
	
	public void setEnvId(Long envId) {
	
		this.envId = envId;
	}
	
	public void setEnvironmentReservationTO(Set<ReservationTO> environmentReservationTO) {
	
		this.environmentReservationTO = environmentReservationTO;
	}
	
	public void setEnvironmentSoftParamsTO(Set<EnvironmentSoftParamsTO> environmentSoftParamsTO) {
	
		this.environmentSoftParamsTO = environmentSoftParamsTO;
	}
	
	public void setEnvironmentTO(EnvironmentTO environmentTO) {
	
		this.environmentTO = environmentTO;
	}
	
	public void setReleaseId(Long releaseId) {
	
		this.releaseId = releaseId;
	}
	
	public void setTimeStamp(String timeStamp) {
	
		this.timeStamp = timeStamp;
	}
	
	public Long getSelectedTestingPhase() {
	
		return selectedTestingPhase;
	}
	
	public void setSelectedTestingPhase(Long selectedTestingPhase) {
	
		this.selectedTestingPhase = selectedTestingPhase;
	}
	
	public TestingPhaseTO getTestingPhaseTO() {
	
		return testingPhaseTO;
	}
	
	public void setTestingPhaseTO(TestingPhaseTO testingPhaseTO) {
	
		this.testingPhaseTO = testingPhaseTO;
	}
}