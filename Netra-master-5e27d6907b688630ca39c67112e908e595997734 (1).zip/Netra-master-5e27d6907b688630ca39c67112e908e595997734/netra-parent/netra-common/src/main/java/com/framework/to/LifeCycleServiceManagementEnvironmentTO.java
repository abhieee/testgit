package com.framework.to;

import java.io.Serializable;

public class LifeCycleServiceManagementEnvironmentTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6298080104093900745L;
	private Long id;
	private Long environmentId;
	private LifeCycleServiceManagementTO lifeCycleServiceManagement;
	
	public Long getEnvironmentId() {
	
		return environmentId;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public LifeCycleServiceManagementTO getLifeCycleServiceManagement() {
	
		return lifeCycleServiceManagement;
	}
	
	public void setEnvironmentId(Long environmentId) {
	
		this.environmentId = environmentId;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setLifeCycleServiceManagement(LifeCycleServiceManagementTO lifeCycleServiceManagement) {
	
		this.lifeCycleServiceManagement = lifeCycleServiceManagement;
	}
}
