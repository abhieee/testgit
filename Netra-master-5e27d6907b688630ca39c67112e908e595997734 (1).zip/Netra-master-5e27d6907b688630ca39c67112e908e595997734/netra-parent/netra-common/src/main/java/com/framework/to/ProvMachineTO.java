package com.framework.to;

import java.util.Date;

public class ProvMachineTO {
	
	private Long id;
	private String name;
	private Long createdBy;
	private Date createdOn;
	private Long updatedBy;
	private Date updatedOn;
	private String ip;
	private String hostName;
	private String serverStatus;
	private Long machineTemplateId;
	private String CPU;
	private String RAM;
	private String architecture;
	private String provisionedMachineType;
	private String virtualMachineType;
	private String perishableFlag;
	private Long provisionedPlatformTemplateId;
	private String provisionedStatus;
	private String macAddress;
	private String remarks;
	
	public ProvMachineTO() {
	
		updatedOn = new Date();
	}
	
	public String getArchitecture() {
	
		return architecture;
	}
	
	public String getCPU() {
	
		return CPU;
	}
	
	public Long getCreatedBy() {
	
		return createdBy;
	}
	
	public Date getCreatedOn() {
	
		return createdOn;
	}
	
	public String getHostName() {
	
		return hostName;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public String getIp() {
	
		return ip;
	}
	
	public String getMacAddress() {
	
		return macAddress;
	}
	
	public Long getMachineTemplateId() {
	
		return machineTemplateId;
	}
	
	public String getName() {
	
		return name;
	}
	
	public String getPerishableFlag() {
	
		return perishableFlag;
	}
	
	public String getProvisionedMachineType() {
	
		return provisionedMachineType;
	}
	
	public Long getProvisionedPlatformTemplateId() {
	
		return provisionedPlatformTemplateId;
	}
	
	public String getProvisionedStatus() {
	
		return provisionedStatus;
	}
	
	public String getRAM() {
	
		return RAM;
	}
	
	public String getRemarks() {
	
		return remarks;
	}
	
	public String getServerStatus() {
	
		return serverStatus;
	}
	
	public Long getUpdatedBy() {
	
		return updatedBy;
	}
	
	public Date getUpdatedOn() {
	
		return updatedOn;
	}
	
	public String getVirtualMachineType() {
	
		return virtualMachineType;
	}
	
	public void setArchitecture(String architecture) {
	
		this.architecture = architecture;
	}
	
	public void setCPU(String cPU) {
	
		CPU = cPU;
	}
	
	public void setCreatedBy(Long createdBy) {
	
		this.createdBy = createdBy;
	}
	
	public void setCreatedOn(Date createdOn) {
	
		this.createdOn = createdOn;
	}
	
	public void setHostName(String hostName) {
	
		this.hostName = hostName;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setIp(String ip) {
	
		this.ip = ip;
	}
	
	public void setMacAddress(String macAddress) {
	
		this.macAddress = macAddress;
	}
	
	public void setMachineTemplateId(Long machineTemplateId) {
	
		this.machineTemplateId = machineTemplateId;
	}
	
	public void setName(String name) {
	
		this.name = name;
	}
	
	public void setPerishableFlag(String perishableFlag) {
	
		this.perishableFlag = perishableFlag;
	}
	
	public void setProvisionedMachineType(String provisionedMachineType) {
	
		this.provisionedMachineType = provisionedMachineType;
	}
	
	public void setProvisionedPlatformTemplateId(Long provisionedPlatformTemplateId) {
	
		this.provisionedPlatformTemplateId = provisionedPlatformTemplateId;
	}
	
	public void setProvisionedStatus(String provisionedStatus) {
	
		this.provisionedStatus = provisionedStatus;
	}
	
	public void setRAM(String rAM) {
	
		RAM = rAM;
	}
	
	public void setRemarks(String remarks) {
	
		this.remarks = remarks;
	}
	
	public void setServerStatus(String serverStatus) {
	
		this.serverStatus = serverStatus;
	}
	
	public void setUpdatedBy(Long updatedBy) {
	
		this.updatedBy = updatedBy;
	}
	
	public void setUpdatedOn(Date updatedOn) {
	
		this.updatedOn = updatedOn;
	}
	
	public void setVirtualMachineType(String virtualMachineType) {
	
		this.virtualMachineType = virtualMachineType;
	}
}
