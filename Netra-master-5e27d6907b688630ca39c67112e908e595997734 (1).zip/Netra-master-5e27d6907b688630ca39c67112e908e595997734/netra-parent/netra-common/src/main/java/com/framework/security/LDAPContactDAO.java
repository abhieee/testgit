package com.framework.security;

import java.util.List;
import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import org.apache.log4j.Logger;
import org.springframework.ldap.core.AttributesMapper;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.filter.AndFilter;
import org.springframework.ldap.filter.EqualsFilter;
import com.framework.exception.CMMException;

public class LDAPContactDAO implements ContactDAO {
	
	private static final Logger LOGGER = Logger.getLogger(LDAPContactDAO.class);
	private LdapTemplate ldapTemplate;
	
	@Override
	public List getAllContactNames() throws CMMException {
	
		try {
			return ldapTemplate.search("ou=users,ou=groups,o=tcs,o=mycomany", "(objectClass=groupOfNames)", new AttributesMapper() {
				
				@Override
				public Object mapFromAttributes(Attributes attrs) throws NamingException {
				
					return attrs.get("member").get();
				}
			});
		} catch (Exception e) {
			LOGGER.error("Please contact the administrator.Unable to connect to the LDAP server", e);
			throw new CMMException("LDAPContactDAO:getAllContactNames", e);
		}
	}
	
	@Override
	public List getContactDetails(String objectclass) {
	
		AndFilter andFilter = new AndFilter();
		andFilter.and(new EqualsFilter("objectClass", objectclass));
		return ldapTemplate.search("", andFilter.encode(), new ContactAttributeMapper());
	}
	
	public LdapTemplate getLdapTemplate() {
	
		return ldapTemplate;
	}
	
	public void setLdapTemplate(LdapTemplate ldapTemplate) {
	
		this.ldapTemplate = ldapTemplate;
	}
}
