package com.framework.puppet.to;

public class DatabaseSchemaTO {
	
	private String ip;
	private String dnsname;
	private String source;
	private String uname;
	private String pwd;
	private String filename;
	private String dbname;
	private String svnusername;
	private String svnpassword;
	
	public String getDbname() {
	
		return dbname;
	}
	
	public String getDnsname() {
	
		return dnsname;
	}
	
	public String getFilename() {
	
		return filename;
	}
	
	public String getIp() {
	
		return ip;
	}
	
	public String getPwd() {
	
		return pwd;
	}
	
	public String getSource() {
	
		return source;
	}
	
	public String getSvnpassword() {
	
		return svnpassword;
	}
	
	public String getSvnusername() {
	
		return svnusername;
	}
	
	public String getUname() {
	
		return uname;
	}
	
	public void setDbname(String dbname) {
	
		this.dbname = dbname;
	}
	
	public void setDnsname(String dnsname) {
	
		this.dnsname = dnsname;
	}
	
	public void setFilename(String filename) {
	
		this.filename = filename;
	}
	
	public void setIp(String ip) {
	
		this.ip = ip;
	}
	
	public void setPwd(String pwd) {
	
		this.pwd = pwd;
	}
	
	public void setSource(String source) {
	
		this.source = source;
	}
	
	public void setSvnpassword(String svnpassword) {
	
		this.svnpassword = svnpassword;
	}
	
	public void setSvnusername(String svnusername) {
	
		this.svnusername = svnusername;
	}
	
	public void setUname(String uname) {
	
		this.uname = uname;
	}
}
