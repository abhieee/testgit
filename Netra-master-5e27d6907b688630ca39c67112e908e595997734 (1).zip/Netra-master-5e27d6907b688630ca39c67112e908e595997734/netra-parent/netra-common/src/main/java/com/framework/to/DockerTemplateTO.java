package com.framework.to;

import java.io.File;
import java.sql.Blob;
import java.util.List;

public class DockerTemplateTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 378613981563109960L;
	private String templateName;
	private Blob templateData;
	private String templateDataStr;
	private String imageName;
	private long searchCount;
	private int firstResult = 1;
	private int tableSize;
	private String uploadScript;
	private String uploadSource;
	private long repoId;
	private String repositoryPath;
	private List<File> file;
	private byte[] fileData;
	
	/**
	 * @return the firstResult
	 */
	public int getFirstResult() {
	
		return firstResult;
	}
	
	/**
	 * @return the imageName
	 */
	public String getImageName() {
	
		return imageName;
	}
	
	/**
	 * @return the searchCount
	 */
	public long getSearchCount() {
	
		return searchCount;
	}
	
	/**
	 * @return the tableSize
	 */
	public int getTableSize() {
	
		return tableSize;
	}
	
	/**
	 * @return the templateData
	 */
	public Blob getTemplateData() {
	
		return templateData;
	}
	
	/**
	 * @return the templateDataStr
	 */
	public String getTemplateDataStr() {
	
		return templateDataStr;
	}
	
	/**
	 * @return the templateName
	 */
	public String getTemplateName() {
	
		return templateName;
	}
	
	/**
	 * @param firstResult
	 *                the firstResult to set
	 */
	public void setFirstResult(int firstResult) {
	
		this.firstResult = firstResult;
	}
	
	/**
	 * @param imageName
	 *                the imageName to set
	 */
	public void setImageName(String imageName) {
	
		this.imageName = imageName;
	}
	
	/**
	 * @param searchCount
	 *                the searchCount to set
	 */
	public void setSearchCount(long searchCount) {
	
		this.searchCount = searchCount;
	}
	
	/**
	 * @param tableSize
	 *                the tableSize to set
	 */
	public void setTableSize(int tableSize) {
	
		this.tableSize = tableSize;
	}
	
	/**
	 * @param templateData
	 *                the templateData to set
	 */
	public void setTemplateData(Blob templateData) {
	
		this.templateData = templateData;
	}
	
	/**
	 * @param templateDataStr
	 *                the templateDataStr to set
	 */
	public void setTemplateDataStr(String templateDataStr) {
	
		this.templateDataStr = templateDataStr;
	}
	
	/**
	 * @param templateName
	 *                the templateName to set
	 */
	public void setTemplateName(String templateName) {
	
		this.templateName = templateName;
	}
	
	public String getUploadScript() {
	
		return uploadScript;
	}
	
	public void setUploadScript(String uploadScript) {
	
		this.uploadScript = uploadScript;
	}
	
	public String getUploadSource() {
	
		return uploadSource;
	}
	
	public void setUploadSource(String uploadSource) {
	
		this.uploadSource = uploadSource;
	}
	
	public long getRepoId() {
	
		return repoId;
	}
	
	public void setRepoId(long repoId) {
	
		this.repoId = repoId;
	}
	
	public String getRepositoryPath() {
	
		return repositoryPath;
	}
	
	public void setRepositoryPath(String repositoryPath) {
	
		this.repositoryPath = repositoryPath;
	}
	
	public List<File> getFile() {
	
		return file;
	}
	
	public void setFile(List<File> file) {
	
		this.file = file;
	}
	
	public byte[] getFileData() {
	
		return fileData;
	}
	
	public void setFileData(byte[] fileData) {
	
		this.fileData = fileData;
	}
}
