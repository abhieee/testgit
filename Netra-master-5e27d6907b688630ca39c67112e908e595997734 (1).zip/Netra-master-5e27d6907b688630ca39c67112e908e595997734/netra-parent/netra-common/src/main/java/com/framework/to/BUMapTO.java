package com.framework.to;

import java.io.Serializable;

public class BUMapTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4673523511682805375L;
	private String type;
	private String tableName;
	private Long id;
	private boolean isNull;
	private String columnNameNetra;
	private String columnNameFile;
	
	public boolean getIsNull() {
	
		return isNull;
	}
	
	public void setIsNull(boolean isNull) {
	
		this.isNull = isNull;
	}
	
	public String getTableName() {
	
		return tableName;
	}
	
	public void setTableName(String tableName) {
	
		this.tableName = tableName;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public String getType() {
	
		return type;
	}
	
	public void setType(String type) {
	
		this.type = type;
	}
	
	public String getColumnNameNetra() {
	
		return columnNameNetra;
	}
	
	public void setColumnNameNetra(String columnNameNetra) {
	
		this.columnNameNetra = columnNameNetra;
	}
	
	public String getColumnNameFile() {
	
		return columnNameFile;
	}
	
	public void setColumnNameFile(String columnNameFile) {
	
		this.columnNameFile = columnNameFile;
	}
}
