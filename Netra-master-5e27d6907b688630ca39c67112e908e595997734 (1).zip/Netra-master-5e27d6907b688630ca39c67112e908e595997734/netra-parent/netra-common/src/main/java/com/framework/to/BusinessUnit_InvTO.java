package com.framework.to;

import java.util.HashSet;
import java.util.Set;

/**
 * @author TCS
 */
public class BusinessUnit_InvTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3919613298683634081L;
	private long clientId;
	private Set<Projects_InvTO> projects = new HashSet<Projects_InvTO>();
	private Long status;
	
	public long getClientId() {
	
		return clientId;
	}
	
	public Set<Projects_InvTO> getProjects() {
	
		return projects;
	}
	
	public Long getStatus() {
	
		return status;
	}
	
	public void setClientId(long clientId) {
	
		this.clientId = clientId;
	}
	
	public void setProjects(Set<Projects_InvTO> projects) {
	
		this.projects = projects;
	}
	
	public void setStatus(Long status) {
	
		this.status = status;
	}
}
