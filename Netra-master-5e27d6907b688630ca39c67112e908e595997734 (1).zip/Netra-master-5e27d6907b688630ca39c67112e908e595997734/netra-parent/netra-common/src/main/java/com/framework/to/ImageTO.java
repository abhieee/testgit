package com.framework.to;

import java.io.Serializable;

public class ImageTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4023818054204977114L;
	private String imageName;
	
	public String getImageName() {
	
		return imageName;
	}
	
	public void setImageName(String imageName) {
	
		this.imageName = imageName;
	}
}