package com.framework.to;

import java.util.Date;

/**
 * @author TCS
 */
public class STCTO extends AbstractTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1627063569201646255L;
	private String stcType = null;
	private String ucbNumber = null;
	private Date testCompletionDate = null;
	private DeviceConfigTO deviceConfig = null;
	private Date stcDate = null;
	private String ucbRefNo = null;
	
	public STCTO() {
	
		super();
	}
	
	/**
	 * @return the deviceConfig
	 */
	public DeviceConfigTO getDeviceConfig() {
	
		return deviceConfig;
	}
	
	public Date getStcDate() {
	
		return stcDate;
	}
	
	/**
	 * @return the stcType
	 */
	public String getStcType() {
	
		return stcType;
	}
	
	/**
	 * @return the testCompletionDate
	 */
	public Date getTestCompletionDate() {
	
		return testCompletionDate;
	}
	
	/**
	 * @return the ucbNumber
	 */
	public String getUcbNumber() {
	
		return ucbNumber;
	}
	
	public String getUcbRefNo() {
	
		return ucbRefNo;
	}
	
	/**
	 * @param deviceConfig
	 *                the deviceConfig to set
	 */
	public void setDeviceConfig(DeviceConfigTO deviceConfig) {
	
		this.deviceConfig = deviceConfig;
	}
	
	public void setStcDate(Date stcDate) {
	
		this.stcDate = stcDate;
	}
	
	/**
	 * @param stcType
	 *                the stcType to set
	 */
	public void setStcType(String stcType) {
	
		this.stcType = stcType;
	}
	
	/**
	 * @param testCompletionDate
	 *                the testCompletionDate to set
	 */
	public void setTestCompletionDate(Date testCompletionDate) {
	
		this.testCompletionDate = testCompletionDate;
	}
	
	/**
	 * @param ucbNumber
	 *                the ucbNumber to set
	 */
	public void setUcbNumber(String ucbNumber) {
	
		this.ucbNumber = ucbNumber;
	}
	
	public void setUcbRefNo(String ucbRefNo) {
	
		this.ucbRefNo = ucbRefNo;
	}
}
