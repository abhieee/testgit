package com.framework.to;

import java.io.Serializable;

public class ApplicationSonarDetailTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3495008353316833125L;
	private Long sonarId;
	private Long applicationId;
	
	public Long getApplicationId() {
	
		return applicationId;
	}
	
	public Long getSonarId() {
	
		return sonarId;
	}
	
	public void setApplicationId(Long applicationId) {
	
		this.applicationId = applicationId;
	}
	
	public void setSonarId(Long sonarId) {
	
		this.sonarId = sonarId;
	}
}
