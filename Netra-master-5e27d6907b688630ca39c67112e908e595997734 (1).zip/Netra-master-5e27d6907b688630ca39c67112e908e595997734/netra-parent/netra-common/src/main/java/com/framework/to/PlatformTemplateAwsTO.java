package com.framework.to;

import java.io.Serializable;

public class PlatformTemplateAwsTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6356840280494142614L;
	private Long id;
	private Long awsAccountId;
	private Long templateId;
	private String imageId;
	private PlatformTemplateTO platformTemplate;
	
	public PlatformTemplateAwsTO() {
	
		/* No implementation required at the moment. Method for future use. */
	}
	
	public Long getAwsAccountId() {
	
		return awsAccountId;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public String getImageId() {
	
		return imageId;
	}
	
	public PlatformTemplateTO getPlatformTemplate() {
	
		return platformTemplate;
	}
	
	public Long getTemplateId() {
	
		return templateId;
	}
	
	public void setAwsAccountId(Long awsAccountId) {
	
		this.awsAccountId = awsAccountId;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setImageId(String imageId) {
	
		this.imageId = imageId;
	}
	
	public void setPlatformTemplate(PlatformTemplateTO platformTemplate) {
	
		this.platformTemplate = platformTemplate;
	}
	
	public void setTemplateId(Long templateId) {
	
		this.templateId = templateId;
	}
}
