package com.framework.to;

import java.util.Date;

public class UserPrivilegeTOInsert extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1148498017294828067L;
	private Long roleId;
	private Long id;
	private Integer createdBy;
	private Date createdDate;
	private Integer modifiedBy;
	private Date modifiedDate;
	
	public UserPrivilegeTOInsert() {
	
		/* No implementation required at the moment. Method for future use. */
	}
	
	public UserPrivilegeTOInsert(Long roleId, Long id) {
	
		this.roleId = roleId;
		this.id = id;
	}
	
	public UserPrivilegeTOInsert(Long roleId, Long id, Integer createdBy, Date createdDate, Integer modifiedBy, Date modifiedDate) {
	
		super();
		this.roleId = roleId;
		this.id = id;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.modifiedBy = modifiedBy;
		this.modifiedDate = modifiedDate;
	}
	
	public Integer getCreatedBy() {
	
		return this.createdBy;
	}
	
	@Override
	public Date getCreatedDate() {
	
		return this.createdDate;
	}
	
	@Override
	public Long getId() {
	
		return id;
	}
	
	public Integer getModifiedBy() {
	
		return this.modifiedBy;
	}
	
	@Override
	public Date getModifiedDate() {
	
		return this.modifiedDate;
	}
	
	public Long getRoleId() {
	
		return roleId;
	}
	
	public void setCreatedBy(Integer createdBy) {
	
		this.createdBy = createdBy;
	}
	
	@Override
	public void setCreatedDate(Date createdDate) {
	
		this.createdDate = createdDate;
	}
	
	@Override
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setModifiedBy(Integer modifiedBy) {
	
		this.modifiedBy = modifiedBy;
	}
	
	@Override
	public void setModifiedDate(Date modifiedDate) {
	
		this.modifiedDate = modifiedDate;
	}
	
	public void setRoleId(Long roleId) {
	
		this.roleId = roleId;
	}
}
