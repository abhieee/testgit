/**
 *
 */
package com.framework.nolio.to;

import java.io.Serializable;
import com.framework.to.ApplicationReleaseTestTO;

/**
 * @author 460650
 */
public class ParamMappingTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6354692079658349564L;
	private long id;
	private String paramValue;
	private long paramMappingId;
	private NolioProcessParametersTO nolioProcessParametersTO;
	private ApplicationReleaseTestTO applicationReleaseTestTO;
	
	public ApplicationReleaseTestTO getApplicationReleaseTestTO() {
	
		return applicationReleaseTestTO;
	}
	
	public long getId() {
	
		return id;
	}
	
	public NolioProcessParametersTO getNolioProcessParametersTO() {
	
		return nolioProcessParametersTO;
	}
	
	public long getParamMappingId() {
	
		return paramMappingId;
	}
	
	public String getParamValue() {
	
		return paramValue;
	}
	
	public void setApplicationReleaseTestTO(ApplicationReleaseTestTO applicationReleaseTestTO) {
	
		this.applicationReleaseTestTO = applicationReleaseTestTO;
	}
	
	public void setId(long id) {
	
		this.id = id;
	}
	
	public void setNolioProcessParametersTO(NolioProcessParametersTO nolioProcessParametersTO) {
	
		this.nolioProcessParametersTO = nolioProcessParametersTO;
	}
	
	public void setParamMappingId(long paramMappingId) {
	
		this.paramMappingId = paramMappingId;
	}
	
	public void setParamValue(String paramValue) {
	
		this.paramValue = paramValue;
	}
}
