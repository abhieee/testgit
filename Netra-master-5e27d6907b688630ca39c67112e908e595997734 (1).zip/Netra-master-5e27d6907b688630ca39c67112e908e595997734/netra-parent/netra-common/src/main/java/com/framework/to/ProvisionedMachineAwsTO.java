package com.framework.to;

import java.io.Serializable;

public class ProvisionedMachineAwsTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8597243493465104685L;
	private Long id;
	private Long awsAccountId;
	private String instanceType;
	private String keyPair;
	private String availabilityZone;
	private String securityGroups;
	private Long provisionedtemplateId;
	private Long provisionedMachineTemplateId;
	private Long serverGroup;
	private ProvisionedMachineTO provisionedMachine;
	
	public ProvisionedMachineAwsTO() {
	
		/* No implementation required at the moment. Method for future use. */
	}
	
	public String getAvailabilityZone() {
	
		return availabilityZone;
	}
	
	public Long getAwsAccountId() {
	
		return awsAccountId;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public String getInstanceType() {
	
		return instanceType;
	}
	
	public String getKeyPair() {
	
		return keyPair;
	}
	
	public ProvisionedMachineTO getProvisionedMachine() {
	
		return provisionedMachine;
	}
	
	public Long getProvisionedMachineTemplateId() {
	
		return provisionedMachineTemplateId;
	}
	
	public Long getProvisionedtemplateId() {
	
		return provisionedtemplateId;
	}
	
	public String getSecurityGroups() {
	
		return securityGroups;
	}
	
	public Long getServerGroup() {
	
		return serverGroup;
	}
	
	public void setAvailabilityZone(String availabilityZone) {
	
		this.availabilityZone = availabilityZone;
	}
	
	public void setAwsAccountId(Long awsAccountId) {
	
		this.awsAccountId = awsAccountId;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setInstanceType(String instanceType) {
	
		this.instanceType = instanceType;
	}
	
	public void setKeyPair(String keyPair) {
	
		this.keyPair = keyPair;
	}
	
	public void setProvisionedMachine(ProvisionedMachineTO provisionedMachine) {
	
		this.provisionedMachine = provisionedMachine;
	}
	
	public void setProvisionedMachineTemplateId(Long provisionedMachineTemplateId) {
	
		this.provisionedMachineTemplateId = provisionedMachineTemplateId;
	}
	
	public void setProvisionedtemplateId(Long provisionedtemplateId) {
	
		this.provisionedtemplateId = provisionedtemplateId;
	}
	
	public void setSecurityGroups(String securityGroups) {
	
		this.securityGroups = securityGroups;
	}
	
	public void setServerGroup(Long serverGroup) {
	
		this.serverGroup = serverGroup;
	}
}
