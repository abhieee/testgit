package com.framework.to;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class MachineTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3773731216056694462L;
	private Long id;
	private String name;
	private Long machineTypeId;
	private Byte activeFlag;
	private Long createdBy;
	private Date createdOn;
	private Long updatedBy;
	private Date updatedOn;
	private Set<MachineAwsTO> machineAws;
	private Set<MachineVMWareTO> machineVMware;
	private Set<MachinePhysicalTO> machinePhysical;
	private MachineTypeTO machineType;
	
	public MachineTO() {
	
		updatedOn = new Date();
		machineAws = new HashSet<MachineAwsTO>();
		machineVMware = new HashSet<MachineVMWareTO>();
		machinePhysical = new HashSet<MachinePhysicalTO>();
	}
	
	public Byte getActiveFlag() {
	
		return activeFlag;
	}
	
	public Long getCreatedBy() {
	
		return createdBy;
	}
	
	public Date getCreatedOn() {
	
		return createdOn;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public Set<MachineAwsTO> getMachineAws() {
	
		return machineAws;
	}
	
	public Set<MachinePhysicalTO> getMachinePhysical() {
	
		return machinePhysical;
	}
	
	public MachineTypeTO getMachineType() {
	
		return machineType;
	}
	
	public Long getMachineTypeId() {
	
		return machineTypeId;
	}
	
	public Set<MachineVMWareTO> getMachineVMware() {
	
		return machineVMware;
	}
	
	public String getName() {
	
		return name;
	}
	
	public Long getUpdatedBy() {
	
		return updatedBy;
	}
	
	public Date getUpdatedOn() {
	
		return updatedOn;
	}
	
	public void setActiveFlag(Byte activeFlag) {
	
		this.activeFlag = activeFlag;
	}
	
	public void setCreatedBy(Long createdBy) {
	
		this.createdBy = createdBy;
	}
	
	public void setCreatedOn(Date createdOn) {
	
		this.createdOn = createdOn;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setMachineAws(Set<MachineAwsTO> machineAws) {
	
		this.machineAws = machineAws;
	}
	
	public void setMachinePhysical(Set<MachinePhysicalTO> machinePhysical) {
	
		this.machinePhysical = machinePhysical;
	}
	
	public void setMachineType(MachineTypeTO machineType) {
	
		this.machineType = machineType;
	}
	
	public void setMachineTypeId(Long machineTypeId) {
	
		this.machineTypeId = machineTypeId;
	}
	
	public void setMachineVMware(Set<MachineVMWareTO> machineVMware) {
	
		this.machineVMware = machineVMware;
	}
	
	public void setName(String name) {
	
		this.name = name;
	}
	
	public void setUpdatedBy(Long updatedBy) {
	
		this.updatedBy = updatedBy;
	}
	
	public void setUpdatedOn(Date updatedOn) {
	
		this.updatedOn = updatedOn;
	}
}
