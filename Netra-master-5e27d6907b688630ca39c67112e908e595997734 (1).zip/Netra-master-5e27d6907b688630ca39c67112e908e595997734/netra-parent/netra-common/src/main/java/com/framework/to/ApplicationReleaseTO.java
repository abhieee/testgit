package com.framework.to;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import com.framework.nolio.to.NolioProcessParametersTO;

public class ApplicationReleaseTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4470965780075232676L;
	private List<ApplicationTO> allApplications = new ArrayList<>();
	private List<ApplicationProfileTO> allApplicationProfiles = new ArrayList<>();
	private Long applicationId;
	private Long applicationProfileId;
	private String applicationName;
	private Long status;
	private boolean access;
	private String typeDet;
	private Long selectedReleaseType;
	private Long clientId;
	private Long workFlowId;
	private String remark;
	private String deployFromNexus;
	private Long roleId;
	private String selectedResource;
	private Long selectedExistingRelease;
	private String existAndNewRadio;
	private Long buildToolId;
	private String isScheduled = "N";
	private List<String> allTools = new ArrayList<String>(0);
	private String selectedIssueType;
	private String selectedJiraIssue;
	private List<String> jiraIssueList = new ArrayList<String>(0);
	private String selectedIssueTrackingTool;
	private String jiraRadio;
	private String sourcePath;
	private String scriptPath;
	private String scriptOrder;
	private List<StatusTO> statusList = new ArrayList<StatusTO>(0);
	private String statusDesc;
	private Long selectedStatus = null;
	private StatusTO statusTO;
	private ApplicationTO applicationTO;
	private ApplicationProfileTO applicationProfileTO;
	private Long statusId = null;
	private Long selectedApplication = null;
	private Long selectedProfile = null;
	private String description;
	private Long parentReleaseId;
	private String type;
	private Long serviceId;
	private Long environmentId;
	private String modifiedName;
	private Long RequestId;
	private String buildTool;
	private String buildScriptPath;
	private String testTool;
	private String testScriptPath;
	private List<ApplicationReleaseTO> releaseList = new ArrayList<>();
	private Set<ApplicationReleaseDbTO> applicationReleaseDbSet = new HashSet<>(0);
	private Set<ApplicationReleaseBuildTO> applicationReleaseBuildSet = new HashSet<>(0);
	private Set<ApplicationReleaseTestTO> applicationReleaseTestSet = new HashSet<>(0);
	private Set<ApplicationReleaseSourcecodeTO> appRelSourcecodeSet = new HashSet<>(0);
	private List<ApplicationReleaseDbTO> applicationReleaseSourcecodeSet = new ArrayList<>(0);
	private Set<SonarDetailTO> SonarDetailSet = new HashSet<>(0);
	private Set<RepositoryMasterTO> repositorySet = new HashSet<>(0);
	private RepositoryMasterTO repositoryMaster;
	private ApplicationReleaseSharedDetailsTO applicationReleaseSharedDetailsTO;
	private ApplicationReleaseNexusDetailsTO applicationReleaseNexusDetailsTO;
	private ApplicationReleaseSharedMappingTO applicationReleaseSharedMappingTO;
	private List<ApplicationReleaseBuildTO> applicationReleaseBuild = new ArrayList<>(0);
	private List<ApplicationReleaseDbTO> applicationReleaseDb = new ArrayList<>(0);
	private List<ApplicationReleaseSourcecodeTO> appRelSourcecode = new ArrayList<>(0);
	private List<ApplicationReleaseTestTO> applicationReleaseTest = new ArrayList<>(0);
	private List<SonarDetailTO> applicationCodeReview = new ArrayList<>(0);
	private Date releaseTime;
	private String initiatedBy;
	private String jobName;
	private String jobToken;
	private boolean releaseExistFlag;
	private Long selectedExistingReleaseid;
	private int tableSize = 10;
	private Long pageNumber = 1L;
	private int firstResult = 0;
	private long searchCount;
	private boolean overwriteFlag;
	private boolean monitoringFlag;
	private String yesNoRadio;
	private String machineIp;
	private String cronExp;
	private String resourceName;
	private String userName;
	private String password;
	private String ip;
	private String hostName;
	private String selectedTool;
	private String jiraIssue;
	private List<NolioProcessParametersTO> parametersList = new ArrayList<>(0);
	private Long repoTypeSourcecode;
	private Long repoTypeDatabase;
	private Long repoTypeTest;
	private Long repoTypeCodeReview;
	private Long selectedReleasePlan;
	private RepositoryTO repositoryTO;
	private ReleasePlanningTO releasePlanningTO;
	private String toolConfigLoc;
	private Long provMachineId;
	private Long selectedTestingPhase;
	private Long buildDefinitionId;
	private Long currentTestingPhase;
	private String currentTestingPhaseName = null;
	private Long selPort;
	private String resultLocation;
	private String scriptCopyLocation;
	
	public String getCurrentTestingPhaseName() {
	
		return currentTestingPhaseName;
	}
	
	public void setCurrentTestingPhaseName(String currentTestingPhaseName) {
	
		this.currentTestingPhaseName = currentTestingPhaseName;
	}
	
	public Long getCurrentTestingPhase() {
	
		return currentTestingPhase;
	}
	
	public void setCurrentTestingPhase(Long currentTestingPhase) {
	
		this.currentTestingPhase = currentTestingPhase;
	}
	
	public boolean isMonitoringFlag() {
	
		return monitoringFlag;
	}
	
	public void setMonitoringFlag(boolean monitoringFlag) {
	
		this.monitoringFlag = monitoringFlag;
	}
	
	public Long getBuildDefinitionId() {
	
		return buildDefinitionId;
	}
	
	public void setBuildDefinitionId(Long buildDefinitionId) {
	
		this.buildDefinitionId = buildDefinitionId;
	}
	
	public Long getSelectedTestingPhase() {
	
		return selectedTestingPhase;
	}
	
	public void setSelectedTestingPhase(Long selectedTestingPhase) {
	
		this.selectedTestingPhase = selectedTestingPhase;
	}
	
	public Long getSelectedReleasePlan() {
	
		return selectedReleasePlan;
	}
	
	public void setSelectedReleasePlan(Long selectedReleasePlan) {
	
		this.selectedReleasePlan = selectedReleasePlan;
	}
	
	public ReleasePlanningTO getReleasePlanningTO() {
	
		return releasePlanningTO;
	}
	
	public void setReleasePlanningTO(ReleasePlanningTO releasePlanningTO) {
	
		this.releasePlanningTO = releasePlanningTO;
	}
	
	public RepositoryTO getRepositoryTO() {
	
		return repositoryTO;
	}
	
	public void setRepositoryTO(RepositoryTO repositoryTO) {
	
		this.repositoryTO = repositoryTO;
	}
	
	public Long getRepoTypeSourcecode() {
	
		return repoTypeSourcecode;
	}
	
	public void setRepoTypeSourcecode(Long repoTypeSourcecode) {
	
		this.repoTypeSourcecode = repoTypeSourcecode;
	}
	
	public Long getRepoTypeDatabase() {
	
		return repoTypeDatabase;
	}
	
	public void setRepoTypeDatabase(Long repoTypeDatabase) {
	
		this.repoTypeDatabase = repoTypeDatabase;
	}
	
	public Long getRepoTypeTest() {
	
		return repoTypeTest;
	}
	
	public void setRepoTypeTest(Long repoTypeTest) {
	
		this.repoTypeTest = repoTypeTest;
	}
	
	public Long getRepoTypeCodeReview() {
	
		return repoTypeCodeReview;
	}
	
	public void setRepoTypeCodeReview(Long repoTypeCodeReview) {
	
		this.repoTypeCodeReview = repoTypeCodeReview;
	}
	
	public List<ApplicationProfileTO> getAllApplicationProfiles() {
	
		return allApplicationProfiles;
	}
	
	public List<ApplicationTO> getAllApplications() {
	
		return allApplications;
	}
	
	public List<String> getAllTools() {
	
		return allTools;
	}
	
	public List<SonarDetailTO> getApplicationCodeReview() {
	
		return applicationCodeReview;
	}
	
	public Long getApplicationId() {
	
		return applicationId;
	}
	
	public String getApplicationName() {
	
		return applicationName;
	}
	
	public Long getApplicationProfileId() {
	
		return applicationProfileId;
	}
	
	public ApplicationProfileTO getApplicationProfileTO() {
	
		return applicationProfileTO;
	}
	
	public List<ApplicationReleaseBuildTO> getApplicationReleaseBuild() {
	
		return applicationReleaseBuild;
	}
	
	public Set<ApplicationReleaseBuildTO> getApplicationReleaseBuildSet() {
	
		return applicationReleaseBuildSet;
	}
	
	public List<ApplicationReleaseDbTO> getApplicationReleaseDb() {
	
		return applicationReleaseDb;
	}
	
	public Set<ApplicationReleaseDbTO> getApplicationReleaseDbSet() {
	
		return applicationReleaseDbSet;
	}
	
	public ApplicationReleaseNexusDetailsTO getApplicationReleaseNexusDetailsTO() {
	
		return applicationReleaseNexusDetailsTO;
	}
	
	public ApplicationReleaseSharedDetailsTO getApplicationReleaseSharedDetailsTO() {
	
		return applicationReleaseSharedDetailsTO;
	}
	
	public ApplicationReleaseSharedMappingTO getApplicationReleaseSharedMappingTO() {
	
		return applicationReleaseSharedMappingTO;
	}
	
	public List<ApplicationReleaseDbTO> getApplicationReleaseSourcecodeSet() {
	
		return applicationReleaseSourcecodeSet;
	}
	
	public List<ApplicationReleaseTestTO> getApplicationReleaseTest() {
	
		return applicationReleaseTest;
	}
	
	public Set<ApplicationReleaseTestTO> getApplicationReleaseTestSet() {
	
		return applicationReleaseTestSet;
	}
	
	public ApplicationTO getApplicationTO() {
	
		return applicationTO;
	}
	
	public List<ApplicationReleaseSourcecodeTO> getAppRelSourcecode() {
	
		return appRelSourcecode;
	}
	
	public Set<ApplicationReleaseSourcecodeTO> getAppRelSourcecodeSet() {
	
		return appRelSourcecodeSet;
	}
	
	public String getBuildScriptPath() {
	
		return buildScriptPath;
	}
	
	public String getBuildTool() {
	
		return buildTool;
	}
	
	public Long getBuildToolId() {
	
		return buildToolId;
	}
	
	public Long getClientId() {
	
		return clientId;
	}
	
	/**
	 * @return the cronExp
	 */
	public String getCronExp() {
	
		return cronExp;
	}
	
	public String getDeployFromNexus() {
	
		return deployFromNexus;
	}
	
	public String getDescription() {
	
		return description;
	}
	
	public Long getEnvironmentId() {
	
		return environmentId;
	}
	
	public String getExistAndNewRadio() {
	
		return existAndNewRadio;
	}
	
	/**
	 * @return the firstResult
	 */
	public int getFirstResult() {
	
		return firstResult;
	}
	
	public String getHostName() {
	
		return hostName;
	}
	
	public String getInitiatedBy() {
	
		return initiatedBy;
	}
	
	public String getIp() {
	
		return ip;
	}
	
	public String getIsScheduled() {
	
		return isScheduled;
	}
	
	public String getJiraIssue() {
	
		return jiraIssue;
	}
	
	public List<String> getJiraIssueList() {
	
		return jiraIssueList;
	}
	
	public String getJiraRadio() {
	
		return jiraRadio;
	}
	
	public String getJobName() {
	
		return jobName;
	}
	
	public String getJobToken() {
	
		return jobToken;
	}
	
	public String getMachineIp() {
	
		return machineIp;
	}
	
	public String getModifiedName() {
	
		return modifiedName;
	}
	
	/**
	 * @return the pageNumber
	 */
	public Long getPageNumber() {
	
		return pageNumber;
	}
	
	public Long getParentReleaseId() {
	
		return parentReleaseId;
	}
	
	public String getPassword() {
	
		return password;
	}
	
	public List<ApplicationReleaseTO> getReleaseList() {
	
		return releaseList;
	}
	
	public Date getReleaseTime() {
	
		return releaseTime;
	}
	
	public String getRemark() {
	
		return remark;
	}
	
	public RepositoryMasterTO getRepositoryMaster() {
	
		return repositoryMaster;
	}
	
	public Set<RepositoryMasterTO> getRepositorySet() {
	
		return repositorySet;
	}
	
	/*********** Jira Changes end **********/
	public Long getRequestId() {
	
		return RequestId;
	}
	
	public String getResourceName() {
	
		return resourceName;
	}
	
	public Long getRoleId() {
	
		return roleId;
	}
	
	public String getScriptOrder() {
	
		return scriptOrder;
	}
	
	public String getScriptPath() {
	
		return scriptPath;
	}
	
	/**
	 * @return the searchCount
	 */
	public long getSearchCount() {
	
		return searchCount;
	}
	
	public Long getSelectedApplication() {
	
		return selectedApplication;
	}
	
	public Long getSelectedExistingRelease() {
	
		return selectedExistingRelease;
	}
	
	public Long getSelectedExistingReleaseid() {
	
		return selectedExistingReleaseid;
	}
	
	public String getSelectedIssueTrackingTool() {
	
		return selectedIssueTrackingTool;
	}
	
	public String getSelectedIssueType() {
	
		return selectedIssueType;
	}
	
	public String getSelectedJiraIssue() {
	
		return selectedJiraIssue;
	}
	
	public Long getSelectedProfile() {
	
		return selectedProfile;
	}
	
	public Long getSelectedReleaseType() {
	
		return selectedReleaseType;
	}
	
	public String getSelectedResource() {
	
		return selectedResource;
	}
	
	public Long getSelectedStatus() {
	
		return selectedStatus;
	}
	
	public String getSelectedTool() {
	
		return selectedTool;
	}
	
	public Long getServiceId() {
	
		return serviceId;
	}
	
	/**
	 * @return the sonarDetailSet
	 */
	public Set<SonarDetailTO> getSonarDetailSet() {
	
		return SonarDetailSet;
	}
	
	public String getSourcePath() {
	
		return sourcePath;
	}
	
	public Long getStatus() {
	
		return status;
	}
	
	public String getStatusDesc() {
	
		return statusDesc;
	}
	
	public Long getStatusId() {
	
		return statusId;
	}
	
	public List<StatusTO> getStatusList() {
	
		return statusList;
	}
	
	public StatusTO getStatusTO() {
	
		return statusTO;
	}
	
	/**
	 * @return the tableSize
	 */
	public int getTableSize() {
	
		return tableSize;
	}
	
	public String getTestScriptPath() {
	
		return testScriptPath;
	}
	
	public String getTestTool() {
	
		return testTool;
	}
	
	public String getType() {
	
		return type;
	}
	
	public String getTypeDet() {
	
		return typeDet;
	}
	
	public String getUserName() {
	
		return userName;
	}
	
	public Long getWorkFlowId() {
	
		return workFlowId;
	}
	
	/**
	 * @return the yesNoRadio
	 */
	public String getYesNoRadio() {
	
		return yesNoRadio;
	}
	
	public boolean isAccess() {
	
		return access;
	}
	
	/**
	 * @return the overwriteFlag
	 */
	public boolean isOverwriteFlag() {
	
		return overwriteFlag;
	}
	
	public boolean isReleaseExistFlag() {
	
		return releaseExistFlag;
	}
	
	public void setAccess(boolean access) {
	
		this.access = access;
	}
	
	public void setAllApplicationProfiles(List<ApplicationProfileTO> allApplicationProfiles) {
	
		this.allApplicationProfiles = allApplicationProfiles;
	}
	
	public void setAllApplications(List<ApplicationTO> allApplications) {
	
		this.allApplications = allApplications;
	}
	
	public void setAllTools(List<String> allTools) {
	
		this.allTools = allTools;
	}
	
	public void setApplicationCodeReview(List<SonarDetailTO> applicationCodeReview) {
	
		this.applicationCodeReview = applicationCodeReview;
	}
	
	public void setApplicationId(Long applicationId) {
	
		this.applicationId = applicationId;
	}
	
	public void setApplicationName(String applicationName) {
	
		this.applicationName = applicationName;
	}
	
	public void setApplicationProfileId(Long applicationProfileId) {
	
		this.applicationProfileId = applicationProfileId;
	}
	
	public void setApplicationProfileTO(ApplicationProfileTO applicationProfileTO) {
	
		this.applicationProfileTO = applicationProfileTO;
	}
	
	public void setApplicationReleaseBuild(List<ApplicationReleaseBuildTO> applicationReleaseBuild) {
	
		this.applicationReleaseBuild = applicationReleaseBuild;
	}
	
	public void setApplicationReleaseBuildSet(Set<ApplicationReleaseBuildTO> applicationReleaseBuildSet) {
	
		this.applicationReleaseBuildSet = applicationReleaseBuildSet;
	}
	
	public void setApplicationReleaseDb(List<ApplicationReleaseDbTO> applicationReleaseDb) {
	
		this.applicationReleaseDb = applicationReleaseDb;
	}
	
	public void setApplicationReleaseDbSet(Set<ApplicationReleaseDbTO> applicationReleaseDbSet) {
	
		this.applicationReleaseDbSet = applicationReleaseDbSet;
	}
	
	public void setApplicationReleaseNexusDetailsTO(ApplicationReleaseNexusDetailsTO applicationReleaseNexusDetailsTO) {
	
		this.applicationReleaseNexusDetailsTO = applicationReleaseNexusDetailsTO;
	}
	
	public void setApplicationReleaseSharedDetailsTO(ApplicationReleaseSharedDetailsTO applicationReleaseSharedDetailsTO) {
	
		this.applicationReleaseSharedDetailsTO = applicationReleaseSharedDetailsTO;
	}
	
	public void setApplicationReleaseSharedMappingTO(ApplicationReleaseSharedMappingTO applicationReleaseSharedMappingTO) {
	
		this.applicationReleaseSharedMappingTO = applicationReleaseSharedMappingTO;
	}
	
	public void setApplicationReleaseSourcecodeSet(List<ApplicationReleaseDbTO> applicationReleaseSourcecodeSet) {
	
		this.applicationReleaseSourcecodeSet = applicationReleaseSourcecodeSet;
	}
	
	public void setApplicationReleaseTest(List<ApplicationReleaseTestTO> applicationReleaseTest) {
	
		this.applicationReleaseTest = applicationReleaseTest;
	}
	
	public void setApplicationReleaseTestSet(Set<ApplicationReleaseTestTO> applicationReleaseTestSet) {
	
		this.applicationReleaseTestSet = applicationReleaseTestSet;
	}
	
	public void setApplicationTO(ApplicationTO applicationTO) {
	
		this.applicationTO = applicationTO;
	}
	
	public void setAppRelSourcecode(List<ApplicationReleaseSourcecodeTO> appRelSourcecode) {
	
		this.appRelSourcecode = appRelSourcecode;
	}
	
	public void setAppRelSourcecodeSet(Set<ApplicationReleaseSourcecodeTO> appRelSourcecodeSet) {
	
		this.appRelSourcecodeSet = appRelSourcecodeSet;
	}
	
	public void setBuildScriptPath(String buildScriptPath) {
	
		this.buildScriptPath = buildScriptPath;
	}
	
	public void setBuildTool(String buildTool) {
	
		this.buildTool = buildTool;
	}
	
	public void setBuildToolId(Long buildToolId) {
	
		this.buildToolId = buildToolId;
	}
	
	public void setClientId(Long clientId) {
	
		this.clientId = clientId;
	}
	
	/**
	 * @param cronExp
	 *                the cronExp to set
	 */
	public void setCronExp(String cronExp) {
	
		this.cronExp = cronExp;
	}
	
	public void setDeployFromNexus(String deployFromNexus) {
	
		this.deployFromNexus = deployFromNexus;
	}
	
	public void setDescription(String description) {
	
		this.description = description;
	}
	
	public void setEnvironmentId(Long environmentId) {
	
		this.environmentId = environmentId;
	}
	
	public void setExistAndNewRadio(String existAndNewRadio) {
	
		this.existAndNewRadio = existAndNewRadio;
	}
	
	/**
	 * @param firstResult
	 *                the firstResult to set
	 */
	public void setFirstResult(int firstResult) {
	
		this.firstResult = firstResult;
	}
	
	public void setHostName(String hostName) {
	
		this.hostName = hostName;
	}
	
	public void setInitiatedBy(String initiatedBy) {
	
		this.initiatedBy = initiatedBy;
	}
	
	public void setIp(String ip) {
	
		this.ip = ip;
	}
	
	public void setIsScheduled(String isScheduled) {
	
		this.isScheduled = isScheduled;
	}
	
	public void setJiraIssue(String jiraIssue) {
	
		this.jiraIssue = jiraIssue;
	}
	
	/*********** Jira Changes end **********/
	public void setJiraIssueList(List<String> jiraIssueList) {
	
		this.jiraIssueList = jiraIssueList;
	}
	
	public void setJiraRadio(String jiraRadio) {
	
		this.jiraRadio = jiraRadio;
	}
	
	public void setJobName(String jobName) {
	
		this.jobName = jobName;
	}
	
	public void setJobToken(String jobToken) {
	
		this.jobToken = jobToken;
	}
	
	public void setMachineIp(String machineIp) {
	
		this.machineIp = machineIp;
	}
	
	public void setModifiedName(String modifiedName) {
	
		this.modifiedName = modifiedName;
	}
	
	/**
	 * @param overwriteFlag
	 *                the overwriteFlag to set
	 */
	public void setOverwriteFlag(boolean overwriteFlag) {
	
		this.overwriteFlag = overwriteFlag;
	}
	
	/**
	 * @param pageNumber
	 *                the pageNumber to set
	 */
	public void setPageNumber(Long pageNumber) {
	
		this.pageNumber = pageNumber;
	}
	
	public void setParentReleaseId(Long parentReleaseId) {
	
		this.parentReleaseId = parentReleaseId;
	}
	
	public void setPassword(String password) {
	
		this.password = password;
	}
	
	public void setReleaseExistFlag(boolean releaseExistFlag) {
	
		this.releaseExistFlag = releaseExistFlag;
	}
	
	public void setReleaseList(List<ApplicationReleaseTO> releaseList) {
	
		this.releaseList = releaseList;
	}
	
	public void setReleaseTime(Date releaseTime) {
	
		this.releaseTime = releaseTime;
	}
	
	public void setRemark(String remark) {
	
		this.remark = remark;
	}
	
	public void setRepositoryMaster(RepositoryMasterTO repositoryMaster) {
	
		this.repositoryMaster = repositoryMaster;
	}
	
	public void setRepositorySet(Set<RepositoryMasterTO> repositorySet) {
	
		this.repositorySet = repositorySet;
	}
	
	public void setRequestId(Long requestId) {
	
		RequestId = requestId;
	}
	
	public void setResourceName(String resourceName) {
	
		this.resourceName = resourceName;
	}
	
	public void setRoleId(Long roleId) {
	
		this.roleId = roleId;
	}
	
	public void setScriptOrder(String scriptOrder) {
	
		this.scriptOrder = scriptOrder;
	}
	
	public void setScriptPath(String scriptPath) {
	
		this.scriptPath = scriptPath;
	}
	
	/**
	 * @param searchCount
	 *                the searchCount to set
	 */
	public void setSearchCount(long searchCount) {
	
		this.searchCount = searchCount;
	}
	
	public void setSelectedApplication(Long selectedApplication) {
	
		this.selectedApplication = selectedApplication;
	}
	
	public void setSelectedExistingRelease(Long selectedExistingRelease) {
	
		this.selectedExistingRelease = selectedExistingRelease;
	}
	
	public void setSelectedExistingReleaseid(Long selectedExistingReleaseid) {
	
		this.selectedExistingReleaseid = selectedExistingReleaseid;
	}
	
	public void setSelectedIssueTrackingTool(String selectedIssueTrackingTool) {
	
		this.selectedIssueTrackingTool = selectedIssueTrackingTool;
	}
	
	public void setSelectedIssueType(String selectedIssueType) {
	
		this.selectedIssueType = selectedIssueType;
	}
	
	public void setSelectedJiraIssue(String selectedJiraIssue) {
	
		this.selectedJiraIssue = selectedJiraIssue;
	}
	
	public void setSelectedProfile(Long selectedProfile) {
	
		this.selectedProfile = selectedProfile;
	}
	
	public void setSelectedReleaseType(Long selectedReleaseType) {
	
		this.selectedReleaseType = selectedReleaseType;
	}
	
	public void setSelectedResource(String selectedResource) {
	
		this.selectedResource = selectedResource;
	}
	
	public void setSelectedStatus(Long selectedStatus) {
	
		this.selectedStatus = selectedStatus;
	}
	
	public void setSelectedTool(String selectedTool) {
	
		this.selectedTool = selectedTool;
	}
	
	public void setServiceId(Long serviceId) {
	
		this.serviceId = serviceId;
	}
	
	/**
	 * @param sonarDetailSet
	 *                the sonarDetailSet to set
	 */
	public void setSonarDetailSet(Set<SonarDetailTO> sonarDetailSet) {
	
		SonarDetailSet = sonarDetailSet;
	}
	
	public void setSourcePath(String sourcePath) {
	
		this.sourcePath = sourcePath;
	}
	
	public void setStatus(Long status) {
	
		this.status = status;
	}
	
	public void setStatusDesc(String statusDesc) {
	
		this.statusDesc = statusDesc;
	}
	
	public void setStatusId(Long statusId) {
	
		this.statusId = statusId;
	}
	
	public void setStatusList(List<StatusTO> statusList) {
	
		this.statusList = statusList;
	}
	
	public void setStatusTO(StatusTO statusTO) {
	
		this.statusTO = statusTO;
	}
	
	/**
	 * @param tableSize
	 *                the tableSize to set
	 */
	public void setTableSize(int tableSize) {
	
		this.tableSize = tableSize;
	}
	
	public void setTestScriptPath(String testScriptPath) {
	
		this.testScriptPath = testScriptPath;
	}
	
	public void setTestTool(String testTool) {
	
		this.testTool = testTool;
	}
	
	public void setType(String type) {
	
		this.type = type;
	}
	
	public void setTypeDet(String typeDet) {
	
		this.typeDet = typeDet;
	}
	
	public void setUserName(String userName) {
	
		this.userName = userName;
	}
	
	public void setWorkFlowId(Long workFlowId) {
	
		this.workFlowId = workFlowId;
	}
	
	/**
	 * @param yesNoRadio
	 *                the yesNoRadio to set
	 */
	public void setYesNoRadio(String yesNoRadio) {
	
		this.yesNoRadio = yesNoRadio;
	}
	
	public List<NolioProcessParametersTO> getParametersList() {
	
		return parametersList;
	}
	
	public void setParametersList(List<NolioProcessParametersTO> parametersList) {
	
		this.parametersList = parametersList;
	}
	
	public String getToolConfigLoc() {
	
		return toolConfigLoc;
	}
	
	public void setToolConfigLoc(String toolConfigLoc) {
	
		this.toolConfigLoc = toolConfigLoc;
	}
	
	public Long getProvMachineId() {
	
		return provMachineId;
	}
	
	public void setProvMachineId(Long provMachineId) {
	
		this.provMachineId = provMachineId;
	}
	
	public Long getSelPort() {
	
		return selPort;
	}
	
	public void setSelPort(Long selPort) {
	
		this.selPort = selPort;
	}
	
	public String getResultLocation() {
	
		return resultLocation;
	}
	
	public void setResultLocation(String resultLocation) {
	
		this.resultLocation = resultLocation;
	}
	
	public String getScriptCopyLocation() {
	
		return scriptCopyLocation;
	}
	
	public void setScriptCopyLocation(String scriptCopyLocation) {
	
		this.scriptCopyLocation = scriptCopyLocation;
	}
}
