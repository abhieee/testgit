package com.framework.to;

import java.io.Serializable;

public class BuildToolDefinitionTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1656540839197343614L;
	private Long id;
	private Long buildToolId;
	private String buildName;
	private String tfsCollection;
	private String tfsProject;
	private String jenkinsJobToken;
	private ApplicationReleaseBuildTO applicationReleaseBuildTO = new ApplicationReleaseBuildTO();
	private String paramaterizedBuild;
	private String buildLocation;
	
	public ApplicationReleaseBuildTO getApplicationReleaseBuildTO() {
	
		return applicationReleaseBuildTO;
	}
	
	public String getBuildName() {
	
		return buildName;
	}
	
	public Long getBuildToolId() {
	
		return buildToolId;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public String getJenkinsJobToken() {
	
		return jenkinsJobToken;
	}
	
	public String getParamaterizedBuild() {
	
		return paramaterizedBuild;
	}
	
	public String getTfsCollection() {
	
		return tfsCollection;
	}
	
	public String getTfsProject() {
	
		return tfsProject;
	}
	
	public void setApplicationReleaseBuildTO(ApplicationReleaseBuildTO applicationReleaseBuildTO) {
	
		this.applicationReleaseBuildTO = applicationReleaseBuildTO;
	}
	
	public void setBuildName(String buildName) {
	
		this.buildName = buildName;
	}
	
	public void setBuildToolId(Long buildToolId) {
	
		this.buildToolId = buildToolId;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setJenkinsJobToken(String jenkinsJobToken) {
	
		this.jenkinsJobToken = jenkinsJobToken;
	}
	
	public void setParamaterizedBuild(String paramaterizedBuild) {
	
		this.paramaterizedBuild = paramaterizedBuild;
	}
	
	public void setTfsCollection(String tfsCollection) {
	
		this.tfsCollection = tfsCollection;
	}
	
	public void setTfsProject(String tfsProject) {
	
		this.tfsProject = tfsProject;
	}
	
	public String getBuildLocation() {
	
		return buildLocation;
	}
	
	public void setBuildLocation(String buildLocation) {
	
		this.buildLocation = buildLocation;
	}
}
