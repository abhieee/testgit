package com.framework.utility;

import java.io.File;
import java.util.List;

/**
 * @author TCS
 */
public class StringUtils {
	
	private StringUtils() {
	
	}
	
	public static String unescape(String str) {
	
		if (str == null) {
			return null;
		}
		str = str.replaceAll("\n", "\\\\n");
		str = str.replaceAll("\t", "\\\\t");
		str = str.replaceAll("\b", "\\\\b");
		str = str.replaceAll("\f", "\\\\f");
		str = str.replaceAll("\r", "\\\\r");
		str = str.replaceAll("\"", "\\\\\"");
		str = str.replaceAll("\'", "\\\\\'");
		return str;
	}
	
	public static String getNamePostSeparator(String str) {
	
		int separator = str.indexOf(File.separatorChar);
		if (separator == -1) {
			return str;
		}
		return str.substring(separator + 1);
	}
	
	public static String getErrorsToDisplay(List<String> errLog) {
	
		StringBuilder errors = new StringBuilder();
		for (String err : errLog) {
			errors.append(err);
		}
		return errors.toString();
	}
}
