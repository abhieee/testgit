package com.framework.to;

import java.util.ArrayList;
import java.util.List;

public class AddPolicyTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8457405198744986314L;
	private String selectedCloudType;
	private ClientTO clientTo;
	private ProjectsTO projectsTo;
	private ApplicationTO applicationTo;
	private List<Long> selectedBuList = new ArrayList<Long>(0);
	private List<Long> selectedProjectList = new ArrayList<Long>(0);
	private List<Long> selectedApplicationList = new ArrayList<Long>(0);
	private String selectedVMTemplate;
	private String selectedHostName;
	private String subnetMask;
	private String policyName;
	private String policyDescription;
	private String selectedDataStore;
	private Long selectedDataCenter;
	private String dhcpFlag;
	private String status;
	private String domain;
	private String gateway;
	private String timeZone;
	private String server;
	private Long selectedBUId;
	private Long selectedProjectId;
	private Long selectedApp;
	private String buName;
	private String projectName;
	private String applicationName;
	private String kickstartUName;
	private String kickstartpwd;
	private String kickStartIP;
	private String kickstartConfigFileName;
	private String staticIp;
	private long searchCount;
	private int firstResult = 1;
	private int tableSize;
	private Long pageNumber = 1L;
	private List<PolicyMappingTO> policyMappingList = new ArrayList<PolicyMappingTO>(0);
	private List<Long> appIds = new ArrayList<Long>(0);
	private List<Long> projectIds = new ArrayList<Long>(0);
	private List<Long> buIds = new ArrayList<Long>(0);
	private List<ClientTO> clientList = new ArrayList<ClientTO>(0);
	private List<ProjectsTO> projectList = new ArrayList<ProjectsTO>(0);
	private List<ApplicationTO> applicationList = new ArrayList<ApplicationTO>(0);
	private String applicationCount;
	private String clientCount;
	private String projectCount;
	private Long userId;
	
	public List<Long> getAppIds() {
	
		return appIds;
	}
	
	public String getApplicationCount() {
	
		return applicationCount;
	}
	
	public List<ApplicationTO> getApplicationList() {
	
		return applicationList;
	}
	
	public String getApplicationName() {
	
		return applicationName;
	}
	
	public ApplicationTO getApplicationTo() {
	
		return applicationTo;
	}
	
	public List<Long> getBuIds() {
	
		return buIds;
	}
	
	public String getBuName() {
	
		return buName;
	}
	
	public String getClientCount() {
	
		return clientCount;
	}
	
	public List<ClientTO> getClientList() {
	
		return clientList;
	}
	
	public ClientTO getClientTo() {
	
		return clientTo;
	}
	
	public String getDhcpFlag() {
	
		return dhcpFlag;
	}
	
	public String getDomain() {
	
		return domain;
	}
	
	public int getFirstResult() {
	
		return firstResult;
	}
	
	public String getGateway() {
	
		return gateway;
	}
	
	public String getKickstartConfigFileName() {
	
		return kickstartConfigFileName;
	}
	
	public String getKickStartIP() {
	
		return kickStartIP;
	}
	
	public String getKickstartpwd() {
	
		return kickstartpwd;
	}
	
	public String getKickstartUName() {
	
		return kickstartUName;
	}
	
	public Long getPageNumber() {
	
		return pageNumber;
	}
	
	public String getPolicyDescription() {
	
		return policyDescription;
	}
	
	public List<PolicyMappingTO> getPolicyMappingList() {
	
		return policyMappingList;
	}
	
	public String getPolicyName() {
	
		return policyName;
	}
	
	public String getProjectCount() {
	
		return projectCount;
	}
	
	public List<Long> getProjectIds() {
	
		return projectIds;
	}
	
	public List<ProjectsTO> getProjectList() {
	
		return projectList;
	}
	
	public String getProjectName() {
	
		return projectName;
	}
	
	public ProjectsTO getProjectsTo() {
	
		return projectsTo;
	}
	
	public long getSearchCount() {
	
		return searchCount;
	}
	
	public Long getSelectedApp() {
	
		return selectedApp;
	}
	
	public List<Long> getSelectedApplicationList() {
	
		return selectedApplicationList;
	}
	
	public Long getSelectedBUId() {
	
		return selectedBUId;
	}
	
	public List<Long> getSelectedBuList() {
	
		return selectedBuList;
	}
	
	public String getSelectedCloudType() {
	
		return selectedCloudType;
	}
	
	public Long getSelectedDataCenter() {
	
		return selectedDataCenter;
	}
	
	public String getSelectedDataStore() {
	
		return selectedDataStore;
	}
	
	public String getSelectedHostName() {
	
		return selectedHostName;
	}
	
	public Long getSelectedProjectId() {
	
		return selectedProjectId;
	}
	
	public List<Long> getSelectedProjectList() {
	
		return selectedProjectList;
	}
	
	public String getSelectedVMTemplate() {
	
		return selectedVMTemplate;
	}
	
	public String getServer() {
	
		return server;
	}
	
	public String getStaticIp() {
	
		return staticIp;
	}
	
	public String getStatus() {
	
		return status;
	}
	
	public String getSubnetMask() {
	
		return subnetMask;
	}
	
	public int getTableSize() {
	
		return tableSize;
	}
	
	public String getTimeZone() {
	
		return timeZone;
	}
	
	public Long getUserId() {
	
		return userId;
	}
	
	public void setAppIds(List<Long> appIds) {
	
		this.appIds = appIds;
	}
	
	public void setApplicationCount(String applicationCount) {
	
		this.applicationCount = applicationCount;
	}
	
	public void setApplicationList(List<ApplicationTO> applicationList) {
	
		this.applicationList = applicationList;
	}
	
	public void setApplicationName(String applicationName) {
	
		this.applicationName = applicationName;
	}
	
	public void setApplicationTo(ApplicationTO applicationTo) {
	
		this.applicationTo = applicationTo;
	}
	
	public void setBuIds(List<Long> buIds) {
	
		this.buIds = buIds;
	}
	
	public void setBuName(String buName) {
	
		this.buName = buName;
	}
	
	public void setClientCount(String clientCount) {
	
		this.clientCount = clientCount;
	}
	
	public void setClientList(List<ClientTO> clientList) {
	
		this.clientList = clientList;
	}
	
	public void setClientTo(ClientTO clientTo) {
	
		this.clientTo = clientTo;
	}
	
	public void setDhcpFlag(String dhcpFlag) {
	
		this.dhcpFlag = dhcpFlag;
	}
	
	public void setDomain(String domain) {
	
		this.domain = domain;
	}
	
	public void setFirstResult(int firstResult) {
	
		this.firstResult = firstResult;
	}
	
	public void setGateway(String gateway) {
	
		this.gateway = gateway;
	}
	
	public void setKickstartConfigFileName(String kickstartConfigFileName) {
	
		this.kickstartConfigFileName = kickstartConfigFileName;
	}
	
	public void setKickStartIP(String kickStartIP) {
	
		this.kickStartIP = kickStartIP;
	}
	
	public void setKickstartpwd(String kickstartpwd) {
	
		this.kickstartpwd = kickstartpwd;
	}
	
	public void setKickstartUName(String kickstartUName) {
	
		this.kickstartUName = kickstartUName;
	}
	
	public void setPageNumber(Long pageNumber) {
	
		this.pageNumber = pageNumber;
	}
	
	public void setPolicyDescription(String policyDescription) {
	
		this.policyDescription = policyDescription;
	}
	
	public void setPolicyMappingList(List<PolicyMappingTO> policyMappingList) {
	
		this.policyMappingList = policyMappingList;
	}
	
	public void setPolicyName(String policyName) {
	
		this.policyName = policyName;
	}
	
	public void setProjectCount(String projectCount) {
	
		this.projectCount = projectCount;
	}
	
	public void setProjectIds(List<Long> projectIds) {
	
		this.projectIds = projectIds;
	}
	
	public void setProjectList(List<ProjectsTO> projectList) {
	
		this.projectList = projectList;
	}
	
	public void setProjectName(String projectName) {
	
		this.projectName = projectName;
	}
	
	public void setProjectsTo(ProjectsTO projectsTo) {
	
		this.projectsTo = projectsTo;
	}
	
	public void setSearchCount(long searchCount) {
	
		this.searchCount = searchCount;
	}
	
	public void setSelectedApp(Long selectedApp) {
	
		this.selectedApp = selectedApp;
	}
	
	public void setSelectedApplicationList(List<Long> selectedApplicationList) {
	
		this.selectedApplicationList = selectedApplicationList;
	}
	
	public void setSelectedBUId(Long selectedBUId) {
	
		this.selectedBUId = selectedBUId;
	}
	
	public void setSelectedBuList(List<Long> selectedBuList) {
	
		this.selectedBuList = selectedBuList;
	}
	
	public void setSelectedCloudType(String selectedCloudType) {
	
		this.selectedCloudType = selectedCloudType;
	}
	
	public void setSelectedDataCenter(Long selectedDataCenter) {
	
		this.selectedDataCenter = selectedDataCenter;
	}
	
	public void setSelectedDataStore(String selectedDataStore) {
	
		this.selectedDataStore = selectedDataStore;
	}
	
	public void setSelectedHostName(String selectedHostName) {
	
		this.selectedHostName = selectedHostName;
	}
	
	public void setSelectedProjectId(Long selectedProjectId) {
	
		this.selectedProjectId = selectedProjectId;
	}
	
	public void setSelectedProjectList(List<Long> selectedProjectList) {
	
		this.selectedProjectList = selectedProjectList;
	}
	
	public void setSelectedVMTemplate(String selectedVMTemplate) {
	
		this.selectedVMTemplate = selectedVMTemplate;
	}
	
	public void setServer(String server) {
	
		this.server = server;
	}
	
	public void setStaticIp(String staticIp) {
	
		this.staticIp = staticIp;
	}
	
	public void setStatus(String status) {
	
		this.status = status;
	}
	
	public void setSubnetMask(String subnetMask) {
	
		this.subnetMask = subnetMask;
	}
	
	public void setTableSize(int tableSize) {
	
		this.tableSize = tableSize;
	}
	
	public void setTimeZone(String timeZone) {
	
		this.timeZone = timeZone;
	}
	
	public void setUserId(Long userId) {
	
		this.userId = userId;
	}
}
