package com.framework.report;

import java.sql.Timestamp;

public class YearlyReservationVO {
	
	private String environment_Name;
	private String res;
	private Timestamp starttime;
	private String res_month;
	private int res_week;
	private String res_mode;
	private String type_name;
	
	public YearlyReservationVO() {
	
		/* No implementation required at the moment. Method for future use. */
	}
	
	public YearlyReservationVO(String environment_Name, String res, Timestamp starttime, String res_month, int res_week, String res_mode, String type_name) {
	
		super();
		this.environment_Name = environment_Name;
		this.res = res;
		this.starttime = starttime;
		this.res_month = res_month;
		this.res_week = res_week;
		this.res_mode = res_mode;
		this.type_name = type_name;
	}
	
	public String getEnvironment_Name() {
	
		return environment_Name;
	}
	
	public void setEnvironment_Name(String environment_Name) {
	
		this.environment_Name = environment_Name;
	}
	
	public String getRes() {
	
		return res;
	}
	
	public void setRes(String res) {
	
		this.res = res;
	}
	
	public Timestamp getStarttime() {
	
		return starttime;
	}
	
	public void setStarttime(Timestamp starttime) {
	
		this.starttime = starttime;
	}
	
	public String getRes_month() {
	
		return res_month;
	}
	
	public void setRes_month(String res_month) {
	
		this.res_month = res_month;
	}
	
	public int getRes_week() {
	
		return res_week;
	}
	
	public void setRes_week(int res_week) {
	
		this.res_week = res_week;
	}
	
	public String getRes_mode() {
	
		return res_mode;
	}
	
	public void setRes_mode(String res_mode) {
	
		this.res_mode = res_mode;
	}
	
	public String getType_name() {
	
		return type_name;
	}
	
	public void setType_name(String type_name) {
	
		this.type_name = type_name;
	}
}
