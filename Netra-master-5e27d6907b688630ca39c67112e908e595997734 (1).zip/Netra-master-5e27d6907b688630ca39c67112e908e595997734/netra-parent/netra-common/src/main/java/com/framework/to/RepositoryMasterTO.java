package com.framework.to;

import java.io.Serializable;

public class RepositoryMasterTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8872412076281444419L;
	private Long id;
	private Long type;
	private String username;
	private String password;
	private ApplicationReleaseTO applicationRelease;
	
	public ApplicationReleaseTO getApplicationRelease() {
	
		return applicationRelease;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public String getPassword() {
	
		return password;
	}
	
	public Long getType() {
	
		return type;
	}
	
	public String getUsername() {
	
		return username;
	}
	
	public void setApplicationRelease(ApplicationReleaseTO applicationRelease) {
	
		this.applicationRelease = applicationRelease;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setPassword(String password) {
	
		this.password = password;
	}
	
	public void setType(Long type) {
	
		this.type = type;
	}
	
	public void setUsername(String username) {
	
		this.username = username;
	}
}
