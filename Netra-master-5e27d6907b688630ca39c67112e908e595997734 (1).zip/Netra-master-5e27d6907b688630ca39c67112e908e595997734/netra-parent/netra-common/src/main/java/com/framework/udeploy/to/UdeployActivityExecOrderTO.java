/**
 *
 */
package com.framework.udeploy.to;

public class UdeployActivityExecOrderTO {
	
	private long activitiesExecutionId;
	private UdeployActivitySoftwareMappingTO udeployActivitySoftwareMappingTO;
	private UdeployActivitySoftwareMappingTO udeployActivitySoftwareMappingTOP;
	private long exeOrder;
	private long softwareId;
	
	public long getActivitiesExecutionId() {
	
		return activitiesExecutionId;
	}
	
	public long getExeOrder() {
	
		return exeOrder;
	}
	
	public long getSoftwareId() {
	
		return softwareId;
	}
	
	public UdeployActivitySoftwareMappingTO getUdeployActivitySoftwareMappingTO() {
	
		return udeployActivitySoftwareMappingTO;
	}
	
	public UdeployActivitySoftwareMappingTO getUdeployActivitySoftwareMappingTOP() {
	
		return udeployActivitySoftwareMappingTOP;
	}
	
	public void setActivitiesExecutionId(long activitiesExecutionId) {
	
		this.activitiesExecutionId = activitiesExecutionId;
	}
	
	public void setExeOrder(long exeOrder) {
	
		this.exeOrder = exeOrder;
	}
	
	public void setSoftwareId(long softwareId) {
	
		this.softwareId = softwareId;
	}
	
	public void setUdeployActivitySoftwareMappingTO(UdeployActivitySoftwareMappingTO udeployActivitySoftwareMappingTO) {
	
		this.udeployActivitySoftwareMappingTO = udeployActivitySoftwareMappingTO;
	}
	
	public void setUdeployActivitySoftwareMappingTOP(UdeployActivitySoftwareMappingTO udeployActivitySoftwareMappingTOP) {
	
		this.udeployActivitySoftwareMappingTOP = udeployActivitySoftwareMappingTOP;
	}
}
