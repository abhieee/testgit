package com.framework.to;

import java.io.Serializable;

public class MachineAwsTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7971922944435459263L;
	private Long id;
	private Long awsAccountId;
	private String instanceType;
	private String keyPair;
	private String availabilityZone;
	private String securityGroups;
	private Long templateId;
	private MachineTO machine;
	private TemplatesTO template;
	
	public MachineAwsTO() {
	
		/* No implementation required at the moment. Method for future use. */
	}
	
	public String getAvailabilityZone() {
	
		return availabilityZone;
	}
	
	public Long getAwsAccountId() {
	
		return awsAccountId;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public String getInstanceType() {
	
		return instanceType;
	}
	
	public String getKeyPair() {
	
		return keyPair;
	}
	
	public MachineTO getMachine() {
	
		return machine;
	}
	
	public String getSecurityGroups() {
	
		return securityGroups;
	}
	
	public TemplatesTO getTemplate() {
	
		return template;
	}
	
	public Long getTemplateId() {
	
		return templateId;
	}
	
	public void setAvailabilityZone(String availabilityZone) {
	
		this.availabilityZone = availabilityZone;
	}
	
	public void setAwsAccountId(Long awsAccountId) {
	
		this.awsAccountId = awsAccountId;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setInstanceType(String instanceType) {
	
		this.instanceType = instanceType;
	}
	
	public void setKeyPair(String keyPair) {
	
		this.keyPair = keyPair;
	}
	
	public void setMachine(MachineTO machine) {
	
		this.machine = machine;
	}
	
	public void setSecurityGroups(String securityGroups) {
	
		this.securityGroups = securityGroups;
	}
	
	public void setTemplate(TemplatesTO template) {
	
		this.template = template;
	}
	
	public void setTemplateId(Long templateId) {
	
		this.templateId = templateId;
	}
}
