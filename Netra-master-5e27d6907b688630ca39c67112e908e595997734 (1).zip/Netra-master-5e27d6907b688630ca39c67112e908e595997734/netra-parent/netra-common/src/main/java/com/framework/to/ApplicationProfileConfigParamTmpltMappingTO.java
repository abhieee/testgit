package com.framework.to;

import java.io.Serializable;
import java.util.Date;

public class ApplicationProfileConfigParamTmpltMappingTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1836379676180960576L;
	private Long id;
	private Long appPrfConfigId;
	private Long appPrfConfigParamsId;
	private Long environmentId;
	private String paramValue;
	private Long createdById;
	private Date createdByDate;
	private Long modifiedbyId;
	private Date modifiedbyDate;
	private ApplicationProfileConfigParamsTO appPrfConfigParamsTO;
	private EnvironmentTO environmentTO;
	
	public Long getAppPrfConfigId() {
	
		return appPrfConfigId;
	}
	
	public Long getAppPrfConfigParamsId() {
	
		return appPrfConfigParamsId;
	}
	
	public ApplicationProfileConfigParamsTO getAppPrfConfigParamsTO() {
	
		return appPrfConfigParamsTO;
	}
	
	public Date getCreatedByDate() {
	
		return createdByDate;
	}
	
	public Long getCreatedById() {
	
		return createdById;
	}
	
	public Long getEnvironmentId() {
	
		return environmentId;
	}
	
	public EnvironmentTO getEnvironmentTO() {
	
		return environmentTO;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public Date getModifiedbyDate() {
	
		return modifiedbyDate;
	}
	
	public Long getModifiedbyId() {
	
		return modifiedbyId;
	}
	
	public String getParamValue() {
	
		return paramValue;
	}
	
	public void setAppPrfConfigId(Long appPrfConfigId) {
	
		this.appPrfConfigId = appPrfConfigId;
	}
	
	public void setAppPrfConfigParamsId(Long appPrfConfigParamsId) {
	
		this.appPrfConfigParamsId = appPrfConfigParamsId;
	}
	
	public void setAppPrfConfigParamsTO(ApplicationProfileConfigParamsTO appPrfConfigParamsTO) {
	
		this.appPrfConfigParamsTO = appPrfConfigParamsTO;
	}
	
	public void setCreatedByDate(Date createdByDate) {
	
		this.createdByDate = createdByDate;
	}
	
	public void setCreatedById(Long createdById) {
	
		this.createdById = createdById;
	}
	
	public void setEnvironmentId(Long environmentId) {
	
		this.environmentId = environmentId;
	}
	
	public void setEnvironmentTO(EnvironmentTO environmentTO) {
	
		this.environmentTO = environmentTO;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setModifiedbyDate(Date modifiedbyDate) {
	
		this.modifiedbyDate = modifiedbyDate;
	}
	
	public void setModifiedbyId(Long modifiedbyId) {
	
		this.modifiedbyId = modifiedbyId;
	}
	
	public void setParamValue(String paramValue) {
	
		this.paramValue = paramValue;
	}
}