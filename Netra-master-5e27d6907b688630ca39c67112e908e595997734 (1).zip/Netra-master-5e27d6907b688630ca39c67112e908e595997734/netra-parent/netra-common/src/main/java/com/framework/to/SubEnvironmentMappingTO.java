package com.framework.to;

public class SubEnvironmentMappingTO extends NamedEntityTO {
	
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private Long environmentId;
	private Long subEnvronmentId;
	
	public Long getEnvironmentId() {
	
		return environmentId;
	}
	
	public Long getSubEnvronmentId() {
	
		return subEnvronmentId;
	}
	
	public void setEnvironmentId(Long environmentId) {
	
		this.environmentId = environmentId;
	}
	
	public void setSubEnvronmentId(Long subEnvronmentId) {
	
		this.subEnvronmentId = subEnvronmentId;
	}
}