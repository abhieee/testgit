package com.framework.to;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class BUMappingTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5915917993335320860L;
	private Long id;
	private Long bUtMapID;
	private String fileColumn;
	private String netraColumn;
	private String netraTable;
	private String data;
	private List<String> fileColumns = new ArrayList<String>(0);
	private List<String> netraColumns = new ArrayList<String>(0);
	private List<String> tableNames = new ArrayList<String>(0);
	
	public BUMappingTO() {
	
	}
	
	public Long getId() {
	
		return id;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public String getFileColumn() {
	
		return fileColumn;
	}
	
	public void setFileColumn(String fileColumn) {
	
		this.fileColumn = fileColumn;
	}
	
	public String getNetraColumn() {
	
		return netraColumn;
	}
	
	public void setNetraColumn(String netraColumn) {
	
		this.netraColumn = netraColumn;
	}
	
	public List<String> getFileColumns() {
	
		return fileColumns;
	}
	
	public void setFileColumns(List<String> fileColumns) {
	
		this.fileColumns = fileColumns;
	}
	
	public List<String> getNetraColumns() {
	
		return netraColumns;
	}
	
	public void setNetraColumns(List<String> netraColumns) {
	
		this.netraColumns = netraColumns;
	}
	
	public Long getbUtMapID() {
	
		return bUtMapID;
	}
	
	public void setbUtMapID(Long bUtMapID) {
	
		this.bUtMapID = bUtMapID;
	}
	
	public String getNetraTable() {
	
		return netraTable;
	}
	
	public void setNetraTable(String netraTable) {
	
		this.netraTable = netraTable;
	}
	
	public List<String> getTableNames() {
	
		return tableNames;
	}
	
	public void setTableNames(List<String> tableNames) {
	
		this.tableNames = tableNames;
	}
	
	public String getData() {
	
		return data;
	}
	
	public void setData(String data) {
	
		this.data = data;
	}
}
