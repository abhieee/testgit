package com.framework.to;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

public class BUMapConfigTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 625616021089888537L;
	private Long id;
	private String fileName;
	private String netraTableName;
	private String name;
	private Set<BUMappingTO> buColumnMapping = new HashSet<>(0);
	
	public Long getId() {
	
		return id;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public String getFileName() {
	
		return fileName;
	}
	
	public void setFileName(String fileName) {
	
		this.fileName = fileName;
	}
	
	public String getNetraTableName() {
	
		return netraTableName;
	}
	
	public void setNetraTableName(String netraTableName) {
	
		this.netraTableName = netraTableName;
	}
	
	public String getName() {
	
		return name;
	}
	
	public void setName(String name) {
	
		this.name = name;
	}
	
	public Set<BUMappingTO> getBuColumnMapping() {
	
		return buColumnMapping;
	}
	
	public void setBuColumnMapping(Set<BUMappingTO> buColumnMapping) {
	
		this.buColumnMapping = buColumnMapping;
	}
}
