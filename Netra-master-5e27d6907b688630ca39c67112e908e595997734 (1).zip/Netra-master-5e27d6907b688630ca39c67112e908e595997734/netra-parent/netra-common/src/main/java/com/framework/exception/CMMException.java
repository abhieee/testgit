package com.framework.exception;

import org.apache.log4j.Logger;

/**
 * The exception class for the application which logs all the throwable exeception generated in any module.
 *
 * @author TCS
 */
public class CMMException extends Exception {
	
	private static final long serialVersionUID = 1L;
	private static final Logger LOG = Logger.getLogger(CMMException.class);
	
	/**
	 * Public empty constructor of CMMException.
	 */
	public CMMException() {
	
		super();
	}
	
	/**
	 * Public constructor of CMMException. Just logs the message as error
	 *
	 * @param message
	 *                error message generated for the exeception
	 */
	public CMMException(String message) {
	
		super(message);
		LOG.error(message);
	}
	
	/**
	 * Public constructor of CMMException. Logs both the message and the throwable message that thrown as a CMMException
	 *
	 * @param message
	 *                Exception message
	 * @param cause
	 *                the original exception that was generated
	 */
	public CMMException(String message, Throwable cause) {
	
		super(message, cause);
		LOG.error(cause);
	}
	
	/**
	 * Public constructor of CMMException. Just logs the error message as a throwable exception that has been generated
	 *
	 * @param cause
	 *                the original exception that was generated
	 */
	public CMMException(Throwable cause) {
	
		super(cause);
		LOG.error(cause);
	}
}
