package com.framework.to;

import java.util.HashSet;
import java.util.Set;

/**
 * @author TCS
 */
public class StatusTO extends NamedEntityTO {
	
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private long entityId;
	private String statusDesc;
	private Set<PlatformTO> platformTO = new HashSet<PlatformTO>();
	private Set<BusinessUnitTO> businessUnitTO = new HashSet<BusinessUnitTO>();
	private Set<ProjectsTO> projectsTO = new HashSet<ProjectsTO>();
	private Set<ServiceTO> serviceTO = new HashSet<ServiceTO>();
	
	public Set<BusinessUnitTO> getBusinessUnitTO() {
	
		return businessUnitTO;
	}
	
	public long getEntityId() {
	
		return entityId;
	}
	
	public Set<PlatformTO> getPlatformTO() {
	
		return platformTO;
	}
	
	public Set<ProjectsTO> getProjectsTO() {
	
		return projectsTO;
	}
	
	public Set<ServiceTO> getServiceTO() {
	
		return serviceTO;
	}
	
	public String getStatusDesc() {
	
		return statusDesc;
	}
	
	public void setBusinessUnitTO(Set<BusinessUnitTO> businessUnitTO) {
	
		this.businessUnitTO = businessUnitTO;
	}
	
	public void setEntityId(long entityId) {
	
		this.entityId = entityId;
	}
	
	public void setPlatformTO(Set<PlatformTO> platformTO) {
	
		this.platformTO = platformTO;
	}
	
	public void setProjectsTO(Set<ProjectsTO> projectsTO) {
	
		this.projectsTO = projectsTO;
	}
	
	public void setServiceTO(Set<ServiceTO> serviceTO) {
	
		this.serviceTO = serviceTO;
	}
	
	public void setStatusDesc(String statusDesc) {
	
		this.statusDesc = statusDesc;
	}
}
