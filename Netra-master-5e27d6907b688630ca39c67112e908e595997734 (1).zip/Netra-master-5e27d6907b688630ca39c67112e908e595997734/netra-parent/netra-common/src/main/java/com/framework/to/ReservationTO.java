package com.framework.to;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.springframework.util.StringUtils;
import com.framework.common.CMMConstants;
import com.framework.utility.DateUtils;

/**
 * This class declares the transfer object that carries reservation information across the application.
 *
 * @author TCS
 */
public class ReservationTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4107806891943190551L;
	private Long id;
	private Long createdById;
	private Long modifiedbyId;
	private Date createdDate;
	private Date modifiedDate;
	private UserTO author = null;
	private Date startTime = null;
	private Date endTime = null;
	private Set<DisruptiveFailureTO> disruptiveFailures = new HashSet<DisruptiveFailureTO>(0);
	private Long topologyId = null;
	private Long applicationId = null;
	private Long environmentId = null;
	private ApplicationTO applications;
	private long userId;
	private UserTO users;
	private String userName;
	private StatusTO status;
	private String release;
	private Long testingCycle;
	private String testingCycleId;
	private String disruptive = null;
	private String actionRemark = null;
	private Long parentId = null;
	private boolean selectResForReject = false;
	private List<Long> selectedReservations = new ArrayList<Long>(0);
	private List<Long> resIdsToCompare = new ArrayList<Long>();
	private int checkAvailabiltyStatus = 0;
	private List<Long> selectedResvIdToReject = new ArrayList<Long>();
	private Long cancelUserRoleId = null;
	private String cancelUserName = null;
	private List<Long> clientIdList = new ArrayList<Long>();
	private long roleId;
	private String testingTypeDesc = null;
	private long selectedStatus;
	private int searchCount;
	private int tableSize = 10;
	private Long pageNumber = 1L;
	private int firstResult = 0;
	private Long isRepetetive;
	private String testingType1;
	private int chkflag = 1;
	private String RowStrtTime;
	private String RowEndTime;
	private Date ListStartDate = null;
	private Date ListEndDate = null;
	public Long countConf;
	private Long messageFlg;
	private boolean isMakeReservation = false;
	private Long childFlow = 0L;
	private List<ReservationTO> allIdsList = new ArrayList<ReservationTO>();
	private List<ReservationTO> allIdsListApproved = new ArrayList<ReservationTO>();
	private boolean isRepetitiveFlag = false;
	private String conflictsId;
	private String createdByUser;
	private String comments = null;
	private Long cancelUserId = null;
	private Long activeResCount;
	private Date releaseDate;
	private Long testingType;
	private Long priority;
	private List<TestingPhaseTO> allTestingCycles = new ArrayList<TestingPhaseTO>(0);
	private Long projectId = null;
	private Long clientId = null;
	private String projectName = null;
	private String clientName = null;
	private Long isconflicting = null;
	private String statusDesc;
	private Long selectedBusinessUnit = null;
	private Long selectedProject = null;
	private Long selectedApplication = null;
	private Long selectedEnvironment = null;
	private String applicationName = null;
	private String environmentName = null;
	private String applicationValue = null;
	private String environmentValue = null;
	private Long status1 = null;
	private String startTimeString = null;
	private String endTimeString = null;
	private List<ReservationTO> conflictingReservationList = new ArrayList<ReservationTO>(0);
	private List<ReservationTO> conflictingReservationListApproved = new ArrayList<ReservationTO>(0);
	private String WhyNeededExclusive;
	private String WhyCantshared;
	private EnvironmentTO environments;
	private boolean updateFlag = false;
	private List<Long> selectedReservationIDsRejection = new ArrayList<Long>();
	private Long releasePlan;
	private Long testingPhase;
	private String releasePlanName;
	private String testingPhaseName;
	private ReleasePlanningTO releasePlanTO;
	private TestingPhaseTO testingPhaseTO;
	
	public ReservationTO() {
	
		super();
	}
	
	/**
	 * @return the actionRemark
	 */
	public String getActionRemark() {
	
		return actionRemark;
	}
	
	public Long getActiveResCount() {
	
		return activeResCount;
	}
	
	public List<ReservationTO> getAllIdsList() {
	
		return allIdsList;
	}
	
	public List<ReservationTO> getAllIdsListApproved() {
	
		return allIdsListApproved;
	}
	
	public List<TestingPhaseTO> getAllTestingCycles() {
	
		return allTestingCycles;
	}
	
	public Long getApplicationId() {
	
		return applicationId;
	}
	
	public String getApplicationName() {
	
		return applicationName;
	}
	
	public ApplicationTO getApplications() {
	
		return applications;
	}
	
	public String getApplicationValue() {
	
		return applicationValue;
	}
	
	/**
	 * @return the author
	 */
	public UserTO getAuthor() {
	
		return author;
	}
	
	public Long getCancelUserId() {
	
		return cancelUserId;
	}
	
	public String getCancelUserName() {
	
		return cancelUserName;
	}
	
	public Long getCancelUserRoleId() {
	
		return cancelUserRoleId;
	}
	
	public int getCheckAvailabiltyStatus() {
	
		return checkAvailabiltyStatus;
	}
	
	public Long getChildFlow() {
	
		return childFlow;
	}
	
	public int getChkflag() {
	
		return chkflag;
	}
	
	public Long getClientId() {
	
		return clientId;
	}
	
	/**
	 * @return the clientIdList
	 */
	public List<Long> getClientIdList() {
	
		return clientIdList;
	}
	
	public String getClientName() {
	
		return clientName;
	}
	
	public String getComments() {
	
		return comments;
	}
	
	public List<ReservationTO> getConflictingReservationList() {
	
		return conflictingReservationList;
	}
	
	public List<ReservationTO> getConflictingReservationListApproved() {
	
		return conflictingReservationListApproved;
	}
	
	public String getConflictsId() {
	
		return conflictsId;
	}
	
	public Long getCountConf() {
	
		return countConf;
	}
	
	public Long getCreatedById() {
	
		return createdById;
	}
	
	public String getCreatedByUser() {
	
		return createdByUser;
	}
	
	public Date getCreatedDate() {
	
		return createdDate;
	}
	
	public String getDisplayName() {
	
		return DateUtils.format(this.getStartTime()) + " - " + DateUtils.format(this.getEndTime());
	}
	
	/**
	 * @return the disruptive
	 */
	public String getDisruptive() {
	
		return disruptive;
	}
	
	public Set<Long> getDisruptiveDeviceIds() {
	
		if (!this.getDisruptive().equalsIgnoreCase(CMMConstants.Framework.ReservationStatus.DISRUPTIVE) || (this.getDisruptiveFailures() == null) || this.getDisruptiveFailures().isEmpty()) {
			return null;
		}
		String[] stringArray = null;
		Set<Long> disruptiveDeviceIds = new HashSet<Long>();
		for (DisruptiveFailureTO df : this.getDisruptiveFailures()) {
			if ((df.getDeviceFrom() != null) && (df.getDeviceFrom().getId() != null)) {
				disruptiveDeviceIds.add(df.getDeviceFrom().getId());
			}
			if ((df.getDeviceTo() != null) && (df.getDeviceTo().getId() != null)) {
				disruptiveDeviceIds.add(df.getDeviceTo().getId());
			}
			if (!":".equals(df.getOtherDevices())) {
				String a = df.getOtherDevices();
				stringArray = a.split(":");
				for (String ab : stringArray) {
					if (StringUtils.hasText(ab)) {
						disruptiveDeviceIds.add(Long.parseLong(ab));
					}
				}
			}
		}
		if (disruptiveDeviceIds.isEmpty()) {
			disruptiveDeviceIds = null;
		}
		return disruptiveDeviceIds;
	}
	
	/**
	 * @return the disruptiveFailures
	 */
	public Set<DisruptiveFailureTO> getDisruptiveFailures() {
	
		return disruptiveFailures;
	}
	
	/**
	 * @return the endTime
	 */
	public Date getEndTime() {
	
		return endTime;
	}
	
	public String getEndTimeString() {
	
		return endTimeString;
	}
	
	public Long getEnvironmentId() {
	
		return environmentId;
	}
	
	public String getEnvironmentName() {
	
		return environmentName;
	}
	
	public EnvironmentTO getEnvironments() {
	
		return environments;
	}
	
	public String getEnvironmentValue() {
	
		return environmentValue;
	}
	
	public int getFirstResult() {
	
		return firstResult;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public Long getIsconflicting() {
	
		return isconflicting;
	}
	
	public Long getIsRepetetive() {
	
		return isRepetetive;
	}
	
	public Date getListEndDate() {
	
		return ListEndDate;
	}
	
	public Date getListStartDate() {
	
		return ListStartDate;
	}
	
	public Long getMessageFlg() {
	
		return messageFlg;
	}
	
	public Long getModifiedbyId() {
	
		return modifiedbyId;
	}
	
	public Date getModifiedDate() {
	
		return modifiedDate;
	}
	
	public Long getPageNumber() {
	
		return pageNumber;
	}
	
	/**
	 * @return the parentId
	 */
	public Long getParentId() {
	
		return parentId;
	}
	
	public Long getPriority() {
	
		return priority;
	}
	
	public Long getProjectId() {
	
		return projectId;
	}
	
	public String getProjectName() {
	
		return projectName;
	}
	
	public String getRelease() {
	
		return release;
	}
	
	public Date getReleaseDate() {
	
		return releaseDate;
	}
	
	public List<Long> getResIdsToCompare() {
	
		return resIdsToCompare;
	}
	
	public long getRoleId() {
	
		return roleId;
	}
	
	public String getRowEndTime() {
	
		return RowEndTime;
	}
	
	public String getRowStrtTime() {
	
		return RowStrtTime;
	}
	
	public int getSearchCount() {
	
		return searchCount;
	}
	
	public Long getSelectedApplication() {
	
		return selectedApplication;
	}
	
	public Long getSelectedBusinessUnit() {
	
		return selectedBusinessUnit;
	}
	
	public Long getSelectedEnvironment() {
	
		return selectedEnvironment;
	}
	
	public Long getSelectedProject() {
	
		return selectedProject;
	}
	
	public List<Long> getSelectedReservationIDsRejection() {
	
		return selectedReservationIDsRejection;
	}
	
	public List<Long> getSelectedReservations() {
	
		return selectedReservations;
	}
	
	public List<Long> getSelectedResvIdToReject() {
	
		return selectedResvIdToReject;
	}
	
	public long getSelectedStatus() {
	
		return selectedStatus;
	}
	
	/**
	 * @return the startTime
	 */
	public Date getStartTime() {
	
		return startTime;
	}
	
	public String getStartTimeString() {
	
		return startTimeString;
	}
	
	public StatusTO getStatus() {
	
		return status;
	}
	
	public long getStatus1() {
	
		return status1;
	}
	
	public String getStatusDesc() {
	
		return statusDesc;
	}
	
	public int getTableSize() {
	
		return tableSize;
	}
	
	public Long getTestingCycle() {
	
		return testingCycle;
	}
	
	public String getTestingCycleId() {
	
		return testingCycleId;
	}
	
	public Long getTestingType() {
	
		return testingType;
	}
	
	public String getTestingType1() {
	
		return testingType1;
	}
	
	public String getTestingTypeDesc() {
	
		return testingTypeDesc;
	}
	
	/**
	 * @return the topologyId
	 */
	public Long getTopologyId() {
	
		return topologyId;
	}
	
	public long getUserId() {
	
		return userId;
	}
	
	public String getUserName() {
	
		return userName;
	}
	
	public UserTO getUsers() {
	
		return users;
	}
	
	public String getWhyCantshared() {
	
		return WhyCantshared;
	}
	
	public String getWhyNeededExclusive() {
	
		return WhyNeededExclusive;
	}
	
	public boolean isMakeReservation() {
	
		return isMakeReservation;
	}
	
	public boolean isRepetitiveFlag() {
	
		return isRepetitiveFlag;
	}
	
	public boolean isSelectResForReject() {
	
		return selectResForReject;
	}
	
	public boolean isUpdateFlag() {
	
		return updateFlag;
	}
	
	/**
	 * @param actionRemark
	 *                the actionRemark to set
	 */
	public void setActionRemark(String actionRemark) {
	
		this.actionRemark = actionRemark;
	}
	
	public void setActiveResCount(Long activeResCount) {
	
		this.activeResCount = activeResCount;
	}
	
	public void setAllIdsList(List<ReservationTO> allIdsList) {
	
		this.allIdsList = allIdsList;
	}
	
	public void setAllIdsListApproved(List<ReservationTO> allIdsListApproved) {
	
		this.allIdsListApproved = allIdsListApproved;
	}
	
	public void setAllTestingCycles(List<TestingPhaseTO> allTestingCycles) {
	
		this.allTestingCycles = allTestingCycles;
	}
	
	public void setApplicationId(Long applicationId) {
	
		this.applicationId = applicationId;
	}
	
	public void setApplicationName(String applicationName) {
	
		this.applicationName = applicationName;
	}
	
	public void setApplications(ApplicationTO applications) {
	
		this.applications = applications;
	}
	
	public void setApplicationValue(String applicationValue) {
	
		this.applicationValue = applicationValue;
	}
	
	/**
	 * @param author
	 *                the author to set
	 */
	public void setAuthor(UserTO author) {
	
		this.author = author;
	}
	
	public void setCancelUserId(Long cancelUserId) {
	
		this.cancelUserId = cancelUserId;
	}
	
	public void setCancelUserName(String cancelUserName) {
	
		this.cancelUserName = cancelUserName;
	}
	
	public void setCancelUserRoleId(Long cancelUserRoleId) {
	
		this.cancelUserRoleId = cancelUserRoleId;
	}
	
	public void setCheckAvailabiltyStatus(int checkAvailabiltyStatus) {
	
		this.checkAvailabiltyStatus = checkAvailabiltyStatus;
	}
	
	public void setChildFlow(Long childFlow) {
	
		this.childFlow = childFlow;
	}
	
	public void setChkflag(int chkflag) {
	
		this.chkflag = chkflag;
	}
	
	public void setClientId(Long clientId) {
	
		this.clientId = clientId;
	}
	
	/**
	 * @param clientIdList
	 *                the clientIdList to set
	 */
	public void setClientIdList(List<Long> clientIdList) {
	
		this.clientIdList = clientIdList;
	}
	
	public void setClientName(String clientName) {
	
		this.clientName = clientName;
	}
	
	public void setComments(String comments) {
	
		this.comments = comments;
	}
	
	public void setConflictingReservationList(List<ReservationTO> conflictingReservationList) {
	
		this.conflictingReservationList = conflictingReservationList;
	}
	
	public void setConflictingReservationListApproved(List<ReservationTO> conflictingReservationListApproved) {
	
		this.conflictingReservationListApproved = conflictingReservationListApproved;
	}
	
	public void setConflictsId(String conflictsId) {
	
		this.conflictsId = conflictsId;
	}
	
	public void setCountConf(Long countConf) {
	
		this.countConf = countConf;
	}
	
	public void setCreatedById(Long createdById) {
	
		this.createdById = createdById;
	}
	
	public void setCreatedByUser(String createdByUser) {
	
		this.createdByUser = createdByUser;
	}
	
	public void setCreatedDate(Date createdDate) {
	
		this.createdDate = createdDate;
	}
	
	/**
	 * @param disruptive
	 *                the disruptive to set
	 */
	public void setDisruptive(String disruptive) {
	
		this.disruptive = disruptive;
	}
	
	/**
	 * @param disruptiveFailures
	 *                the disruptiveFailures to set
	 */
	public void setDisruptiveFailures(Set<DisruptiveFailureTO> disruptiveFailures) {
	
		this.disruptiveFailures = disruptiveFailures;
	}
	
	/**
	 * @param endTime
	 *                the endTime to set
	 */
	public void setEndTime(Date endTime) {
	
		this.endTime = endTime;
	}
	
	public void setEndTimeString(String endTimeString) {
	
		this.endTimeString = endTimeString;
	}
	
	public void setEnvironmentId(Long environmentId) {
	
		this.environmentId = environmentId;
	}
	
	public void setEnvironmentName(String environmentName) {
	
		this.environmentName = environmentName;
	}
	
	public void setEnvironments(EnvironmentTO environments) {
	
		this.environments = environments;
	}
	
	public void setEnvironmentValue(String environmentValue) {
	
		this.environmentValue = environmentValue;
	}
	
	public void setFirstResult(int firstResult) {
	
		this.firstResult = firstResult;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setIsconflicting(Long isconflicting) {
	
		this.isconflicting = isconflicting;
	}
	
	public void setIsRepetetive(Long isRepetetive) {
	
		this.isRepetetive = isRepetetive;
	}
	
	public void setListEndDate(Date listEndDate) {
	
		ListEndDate = listEndDate;
	}
	
	public void setListStartDate(Date listStartDate) {
	
		ListStartDate = listStartDate;
	}
	
	public void setMakeReservation(boolean isMakeReservation) {
	
		this.isMakeReservation = isMakeReservation;
	}
	
	public void setMessageFlg(Long messageFlg) {
	
		this.messageFlg = messageFlg;
	}
	
	public void setModifiedbyId(Long modifiedbyId) {
	
		this.modifiedbyId = modifiedbyId;
	}
	
	public void setModifiedDate(Date modifiedDate) {
	
		this.modifiedDate = modifiedDate;
	}
	
	public void setPageNumber(Long pageNumber) {
	
		this.pageNumber = pageNumber;
	}
	
	/**
	 * @param parentId
	 *                the parentId to set
	 */
	public void setParentId(Long parentId) {
	
		this.parentId = parentId;
	}
	
	public void setPriority(Long priority) {
	
		this.priority = priority;
	}
	
	public void setProjectId(Long projectId) {
	
		this.projectId = projectId;
	}
	
	public void setProjectName(String projectName) {
	
		this.projectName = projectName;
	}
	
	public void setRelease(String release) {
	
		this.release = release;
	}
	
	public void setReleaseDate(Date releaseDate) {
	
		this.releaseDate = releaseDate;
	}
	
	public void setRepetitiveFlag(boolean isRepetitiveFlag) {
	
		this.isRepetitiveFlag = isRepetitiveFlag;
	}
	
	public void setResIdsToCompare(List<Long> resIdsToCompare) {
	
		this.resIdsToCompare = resIdsToCompare;
	}
	
	public void setRoleId(long roleId) {
	
		this.roleId = roleId;
	}
	
	public void setRowEndTime(String rowEndTime) {
	
		RowEndTime = rowEndTime;
	}
	
	public void setRowStrtTime(String rowStrtTime) {
	
		RowStrtTime = rowStrtTime;
	}
	
	public void setSearchCount(int searchCount) {
	
		this.searchCount = searchCount;
	}
	
	public void setSelectedApplication(Long selectedApplication) {
	
		this.selectedApplication = selectedApplication;
	}
	
	public void setSelectedBusinessUnit(Long selectedBusinessUnit) {
	
		this.selectedBusinessUnit = selectedBusinessUnit;
	}
	
	public void setSelectedEnvironment(Long selectedEnvironment) {
	
		this.selectedEnvironment = selectedEnvironment;
	}
	
	public void setSelectedProject(Long selectedProject) {
	
		this.selectedProject = selectedProject;
	}
	
	public void setSelectedReservationIDsRejection(List<Long> selectedReservationIDsRejection) {
	
		this.selectedReservationIDsRejection = selectedReservationIDsRejection;
	}
	
	public void setSelectedReservations(List<Long> selectedReservations) {
	
		this.selectedReservations = selectedReservations;
	}
	
	public void setSelectedResvIdToReject(List<Long> selectedResvIdToReject) {
	
		this.selectedResvIdToReject = selectedResvIdToReject;
	}
	
	public void setSelectedStatus(long selectedStatus) {
	
		this.selectedStatus = selectedStatus;
	}
	
	public void setSelectResForReject(boolean selectResForReject) {
	
		this.selectResForReject = selectResForReject;
	}
	
	/**
	 * @param startTime
	 *                the startTime to set
	 */
	public void setStartTime(Date startTime) {
	
		this.startTime = startTime;
	}
	
	public void setStartTimeString(String startTimeString) {
	
		this.startTimeString = startTimeString;
	}
	
	public void setStatus(StatusTO status) {
	
		this.status = status;
	}
	
	public void setStatus1(long status1) {
	
		this.status1 = status1;
	}
	
	public void setStatus1(Long status1) {
	
		this.status1 = status1;
	}
	
	public void setStatusDesc(String statusDesc) {
	
		this.statusDesc = statusDesc;
	}
	
	public void setTableSize(int tableSize) {
	
		this.tableSize = tableSize;
	}
	
	public void setTestingCycle(Long testingCycle) {
	
		this.testingCycle = testingCycle;
	}
	
	public void setTestingCycleId(String testingCycleId) {
	
		this.testingCycleId = testingCycleId;
	}
	
	public void setTestingType(Long testingType) {
	
		this.testingType = testingType;
	}
	
	public void setTestingType1(String testingType1) {
	
		this.testingType1 = testingType1;
	}
	
	public void setTestingTypeDesc(String testingTypeDesc) {
	
		this.testingTypeDesc = testingTypeDesc;
	}
	
	/**
	 * @param topologyId
	 *                the topologyId to set
	 */
	public void setTopologyId(Long topologyId) {
	
		this.topologyId = topologyId;
	}
	
	public void setUpdateFlag(boolean updateFlag) {
	
		this.updateFlag = updateFlag;
	}
	
	public void setUserId(long userId) {
	
		this.userId = userId;
	}
	
	public void setUserName(String userName) {
	
		this.userName = userName;
	}
	
	public void setUsers(UserTO users) {
	
		this.users = users;
	}
	
	public void setWhyCantshared(String whyCantshared) {
	
		WhyCantshared = whyCantshared;
	}
	
	public void setWhyNeededExclusive(String whyNeededExclusive) {
	
		WhyNeededExclusive = whyNeededExclusive;
	}
	
	public Long getReleasePlan() {
	
		return releasePlan;
	}
	
	public void setReleasePlan(Long releasePlan) {
	
		this.releasePlan = releasePlan;
	}
	
	public Long getTestingPhase() {
	
		return testingPhase;
	}
	
	public void setTestingPhase(Long testingPhase) {
	
		this.testingPhase = testingPhase;
	}
	
	public String getReleasePlanName() {
	
		return releasePlanName;
	}
	
	public void setReleasePlanName(String releasePlanName) {
	
		this.releasePlanName = releasePlanName;
	}
	
	public String getTestingPhaseName() {
	
		return testingPhaseName;
	}
	
	public void setTestingPhaseName(String testingPhaseName) {
	
		this.testingPhaseName = testingPhaseName;
	}
	
	public TestingPhaseTO getTestingPhaseTO() {
	
		return testingPhaseTO;
	}
	
	public void setTestingPhaseTO(TestingPhaseTO testingPhaseTO) {
	
		this.testingPhaseTO = testingPhaseTO;
	}
	
	public ReleasePlanningTO getReleasePlanTO() {
	
		return releasePlanTO;
	}
	
	public void setReleasePlanTO(ReleasePlanningTO releasePlanTO) {
	
		this.releasePlanTO = releasePlanTO;
	}
}
