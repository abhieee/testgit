package com.framework.to;

import java.io.File;
import java.io.Serializable;
import java.sql.Blob;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ApplicationProfileConfigTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8347052006216079889L;
	private Long id;
	private Long softwareConfigId;
	private Long applicationId;
	private String fileName;
	private String fileTargetPath;
	private Blob configFile;
	private Blob templateFile;
	private Long createdById;
	private Date createdByDate;
	private Long modifiedbyId;
	private Date modifiedbyDate;
	private String type;
	private ApplicationTO applicationTO;
	private SoftwareconfigTO softwareConfigTO;
	List<ApplicationProfileConfigTO> applicationProfileConfigList = new ArrayList<ApplicationProfileConfigTO>(0);
	List<ApplicationProfileConfigTO> applicationProfileConfigWithAppList = new ArrayList<ApplicationProfileConfigTO>(0);
	private Long appPrfId;
	private boolean appFlag = false;
	private List<File> files;
	private List<String> filesFileName = new ArrayList<String>(0);
	private Long profileId;
	private String noParamExist;
	private String paramString;
	private String originalLineString;
	private List<Blob> configFileList = new ArrayList<Blob>(0);
	private Long selectedLocation;
	private Long appPrfDetId;
	
	public Long getApplicationId() {
	
		return applicationId;
	}
	
	public List<ApplicationProfileConfigTO> getApplicationProfileConfigList() {
	
		return applicationProfileConfigList;
	}
	
	public List<ApplicationProfileConfigTO> getApplicationProfileConfigWithAppList() {
	
		return applicationProfileConfigWithAppList;
	}
	
	public ApplicationTO getApplicationTO() {
	
		return applicationTO;
	}
	
	public Long getAppPrfDetId() {
	
		return appPrfDetId;
	}
	
	public Long getAppPrfId() {
	
		return appPrfId;
	}
	
	public Blob getConfigFile() {
	
		return configFile;
	}
	
	public List<Blob> getConfigFileList() {
	
		return configFileList;
	}
	
	public Date getCreatedByDate() {
	
		return createdByDate;
	}
	
	public Long getCreatedById() {
	
		return createdById;
	}
	
	public String getFileName() {
	
		return fileName;
	}
	
	public List<File> getFiles() {
	
		return files;
	}
	
	public List<String> getFilesFileName() {
	
		return filesFileName;
	}
	
	public String getFileTargetPath() {
	
		return fileTargetPath;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public Date getModifiedbyDate() {
	
		return modifiedbyDate;
	}
	
	public Long getModifiedbyId() {
	
		return modifiedbyId;
	}
	
	public String getNoParamExist() {
	
		return noParamExist;
	}
	
	public String getOriginalLineString() {
	
		return originalLineString;
	}
	
	public String getParamString() {
	
		return paramString;
	}
	
	public Long getProfileId() {
	
		return profileId;
	}
	
	public Long getSelectedLocation() {
	
		return selectedLocation;
	}
	
	public Long getSoftwareConfigId() {
	
		return softwareConfigId;
	}
	
	public SoftwareconfigTO getSoftwareConfigTO() {
	
		return softwareConfigTO;
	}
	
	public Blob getTemplateFile() {
	
		return templateFile;
	}
	
	public String getType() {
	
		return type;
	}
	
	public boolean isAppFlag() {
	
		return appFlag;
	}
	
	public void setAppFlag(boolean appFlag) {
	
		this.appFlag = appFlag;
	}
	
	public void setApplicationId(Long applicationId) {
	
		this.applicationId = applicationId;
	}
	
	public void setApplicationProfileConfigList(List<ApplicationProfileConfigTO> applicationProfileConfigList) {
	
		this.applicationProfileConfigList = applicationProfileConfigList;
	}
	
	public void setApplicationProfileConfigWithAppList(List<ApplicationProfileConfigTO> applicationProfileConfigWithAppList) {
	
		this.applicationProfileConfigWithAppList = applicationProfileConfigWithAppList;
	}
	
	public void setApplicationTO(ApplicationTO applicationTO) {
	
		this.applicationTO = applicationTO;
	}
	
	public void setAppPrfDetId(Long appPrfDetId) {
	
		this.appPrfDetId = appPrfDetId;
	}
	
	public void setAppPrfId(Long appPrfId) {
	
		this.appPrfId = appPrfId;
	}
	
	public void setConfigFile(Blob configFile) {
	
		this.configFile = configFile;
	}
	
	public void setConfigFileList(List<Blob> configFileList) {
	
		this.configFileList = configFileList;
	}
	
	public void setCreatedByDate(Date createdByDate) {
	
		this.createdByDate = createdByDate;
	}
	
	public void setCreatedById(Long createdById) {
	
		this.createdById = createdById;
	}
	
	public void setFileName(String fileName) {
	
		this.fileName = fileName;
	}
	
	public void setFiles(List<File> files) {
	
		this.files = files;
	}
	
	public void setFilesFileName(List<String> filesFileName) {
	
		this.filesFileName = filesFileName;
	}
	
	public void setFileTargetPath(String fileTargetPath) {
	
		this.fileTargetPath = fileTargetPath;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setModifiedbyDate(Date modifiedbyDate) {
	
		this.modifiedbyDate = modifiedbyDate;
	}
	
	public void setModifiedbyId(Long modifiedbyId) {
	
		this.modifiedbyId = modifiedbyId;
	}
	
	public void setNoParamExist(String noParamExist) {
	
		this.noParamExist = noParamExist;
	}
	
	public void setOriginalLineString(String originalLineString) {
	
		this.originalLineString = originalLineString;
	}
	
	public void setParamString(String paramString) {
	
		this.paramString = paramString;
	}
	
	public void setProfileId(Long profileId) {
	
		this.profileId = profileId;
	}
	
	public void setSelectedLocation(Long selectedLocation) {
	
		this.selectedLocation = selectedLocation;
	}
	
	public void setSoftwareConfigId(Long softwareConfigId) {
	
		this.softwareConfigId = softwareConfigId;
	}
	
	public void setSoftwareConfigTO(SoftwareconfigTO softwareConfigTO) {
	
		this.softwareConfigTO = softwareConfigTO;
	}
	
	public void setTemplateFile(Blob templateFile) {
	
		this.templateFile = templateFile;
	}
	
	public void setType(String type) {
	
		this.type = type;
	}
}