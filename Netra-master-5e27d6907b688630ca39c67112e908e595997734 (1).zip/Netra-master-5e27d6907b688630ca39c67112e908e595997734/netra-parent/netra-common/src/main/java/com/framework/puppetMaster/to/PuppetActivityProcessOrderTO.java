package com.framework.puppetMaster.to;

import java.io.Serializable;

public class PuppetActivityProcessOrderTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7775238180301030230L;
	private long activtyProcessId;
	private PuppetActivitySoftwareMappingTO puppetActivitySoftwareMappingTO;
	private PuppetProcessSoftwareMapping puppetProcessSoftwareMapping;
	private long processOrder;
	
	public long getActivtyProcessId() {
	
		return activtyProcessId;
	}
	
	public long getProcessOrder() {
	
		return processOrder;
	}
	
	public PuppetActivitySoftwareMappingTO getPuppetActivitySoftwareMappingTO() {
	
		return puppetActivitySoftwareMappingTO;
	}
	
	public PuppetProcessSoftwareMapping getPuppetProcessSoftwareMapping() {
	
		return puppetProcessSoftwareMapping;
	}
	
	public void setActivtyProcessId(long activtyProcessId) {
	
		this.activtyProcessId = activtyProcessId;
	}
	
	public void setProcessOrder(long processOrder) {
	
		this.processOrder = processOrder;
	}
	
	public void setPuppetActivitySoftwareMappingTO(PuppetActivitySoftwareMappingTO puppetActivitySoftwareMappingTO) {
	
		this.puppetActivitySoftwareMappingTO = puppetActivitySoftwareMappingTO;
	}
	
	public void setPuppetProcessSoftwareMapping(PuppetProcessSoftwareMapping puppetProcessSoftwareMapping) {
	
		this.puppetProcessSoftwareMapping = puppetProcessSoftwareMapping;
	}
}
