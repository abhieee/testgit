package com.framework.to;

public class DnsServerDetailsTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String server;
	
	public String getServer() {
	
		return server;
	}
	
	public void setServer(String server) {
	
		this.server = server;
	}
}
