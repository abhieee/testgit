package com.framework.to;

import java.io.Serializable;
import java.util.Date;

public class QuartzHistoryTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -934362542918351416L;
	private Long id;
	private Long requestId;
	private String triggerName;
	private String triggerGroup;
	private String jobName;
	private String jobGroup;
	private String status;
	private String triggerStatus;
	private String createdBy;
	private String startedTime;
	private Date misFiredTime;
	private Date completedTime;
	private Date firedTime;
	private String uniqueId;
	
	public Date getCompletedTime() {
	
		return completedTime;
	}
	
	public String getCreatedBy() {
	
		return createdBy;
	}
	
	public Date getFiredTime() {
	
		return firedTime;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public String getJobGroup() {
	
		return jobGroup;
	}
	
	public String getJobName() {
	
		return jobName;
	}
	
	public Date getMisFiredTime() {
	
		return misFiredTime;
	}
	
	public Long getRequestId() {
	
		return requestId;
	}
	
	public String getStartedTime() {
	
		return startedTime;
	}
	
	public String getStatus() {
	
		return status;
	}
	
	public String getTriggerGroup() {
	
		return triggerGroup;
	}
	
	public String getTriggerName() {
	
		return triggerName;
	}
	
	public String getTriggerStatus() {
	
		return triggerStatus;
	}
	
	public String getUniqueId() {
	
		return uniqueId;
	}
	
	public void setCompletedTime(Date completedTime) {
	
		this.completedTime = completedTime;
	}
	
	public void setCreatedBy(String createdBy) {
	
		this.createdBy = createdBy;
	}
	
	public void setFiredTime(Date firedTime) {
	
		this.firedTime = firedTime;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setJobGroup(String jobGroup) {
	
		this.jobGroup = jobGroup;
	}
	
	public void setJobName(String jobName) {
	
		this.jobName = jobName;
	}
	
	public void setMisFiredTime(Date misFiredTime) {
	
		this.misFiredTime = misFiredTime;
	}
	
	public void setRequestId(Long requestId) {
	
		this.requestId = requestId;
	}
	
	public void setStartedTime(String startedTime) {
	
		this.startedTime = startedTime;
	}
	
	public void setStatus(String status) {
	
		this.status = status;
	}
	
	public void setTriggerGroup(String triggerGroup) {
	
		this.triggerGroup = triggerGroup;
	}
	
	public void setTriggerName(String triggerName) {
	
		this.triggerName = triggerName;
	}
	
	public void setTriggerStatus(String triggerStatus) {
	
		this.triggerStatus = triggerStatus;
	}
	
	public void setUniqueId(String uniqueId) {
	
		this.uniqueId = uniqueId;
	}
}
