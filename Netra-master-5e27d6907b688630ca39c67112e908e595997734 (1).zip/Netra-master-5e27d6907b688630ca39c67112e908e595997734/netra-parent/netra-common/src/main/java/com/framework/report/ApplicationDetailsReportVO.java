package com.framework.report;

import java.io.Serializable;

public class ApplicationDetailsReportVO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String app_support = null;
	private String env_name = null;
	private String app_name = null;
	private String proj_name = null;
	private String descp = null;
	private String contact_det = null;
	private String testing_phase = null;
	
	public ApplicationDetailsReportVO() {
	
		/* No implementation required at the moment. Method for future use. */
	}
	
	public ApplicationDetailsReportVO(String app_support, String env_name, String descp, String app_name, String proj_name, String contact_det, String testing_phase) {
	
		this.app_support = app_support;
		this.env_name = env_name;
		this.descp = descp;
		this.app_name = app_name;
		this.proj_name = proj_name;
		this.contact_det = contact_det;
		this.testing_phase = testing_phase;
	}
	
	public String getApp_support() {
	
		return app_support;
	}
	
	public void setApp_support(String app_support) {
	
		this.app_support = app_support;
	}
	
	public String getEnv_name() {
	
		return env_name;
	}
	
	public void setEnv_name(String env_name) {
	
		this.env_name = env_name;
	}
	
	public String getApp_name() {
	
		return app_name;
	}
	
	public void setApp_name(String app_name) {
	
		this.app_name = app_name;
	}
	
	public String getProj_name() {
	
		return proj_name;
	}
	
	public void setProj_name(String proj_name) {
	
		this.proj_name = proj_name;
	}
	
	public String getContact_det() {
	
		return contact_det;
	}
	
	public void setContact_det(String contact_det) {
	
		this.contact_det = contact_det;
	}
	
	public String getDescp() {
	
		return descp;
	}
	
	public void setDescp(String descp) {
	
		this.descp = descp;
	}
	
	public String getTesting_phase() {
	
		return testing_phase;
	}
	
	public void setTesting_phase(String testing_phase) {
	
		this.testing_phase = testing_phase;
	}
}
