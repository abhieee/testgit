package com.framework.to;

import java.io.Serializable;
import java.util.List;

public class SecurityAnswersTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long answers_id;
	private Long question_id;
	private String answer_name;
	private List<String> s_ans;
	private Long user_id;
	
	public String getAnswer_name() {
	
		return answer_name;
	}
	
	public Long getAnswers_id() {
	
		return answers_id;
	}
	
	public Long getQuestion_id() {
	
		return question_id;
	}
	
	public List<String> getS_ans() {
	
		return s_ans;
	}
	
	public Long getUser_id() {
	
		return user_id;
	}
	
	public void setAnswer_name(String answer_name) {
	
		this.answer_name = answer_name;
	}
	
	public void setAnswers_id(Long answers_id) {
	
		this.answers_id = answers_id;
	}
	
	public void setQuestion_id(Long question_id) {
	
		this.question_id = question_id;
	}
	
	public void setS_ans(List<String> s_ans) {
	
		this.s_ans = s_ans;
	}
	
	public void setUser_id(Long user_id) {
	
		this.user_id = user_id;
	}
}
