package com.framework.to.aws;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author 459704
 */
public class AWSEC2InstanceRequestTO {
	
	private String imageId;
	private String instanceType;
	private String keyName;
	private String placement;
	private String instanceName;
	String[] securityGroupIds;
	private List<AWSEC2ImageTO> allImages;
	private List<String> allInstanceTypes;
	private List<String> allKeyNames;
	private List<String> allPlacements;
	private List<AWSEC2SecurityGroupTO> allSecurityGroups;
	
	public AWSEC2InstanceRequestTO() {
	
		allImages = new ArrayList<AWSEC2ImageTO>();
		allInstanceTypes = new ArrayList<String>();
		allKeyNames = new ArrayList<String>();
		allPlacements = new ArrayList<String>();
		allSecurityGroups = new ArrayList<AWSEC2SecurityGroupTO>();
	}
	
	public List<AWSEC2ImageTO> getAllImages() {
	
		return allImages;
	}
	
	public List<String> getAllInstanceTypes() {
	
		return allInstanceTypes;
	}
	
	public List<String> getAllKeyNames() {
	
		return allKeyNames;
	}
	
	public List<String> getAllPlacements() {
	
		return allPlacements;
	}
	
	public List<AWSEC2SecurityGroupTO> getAllSecurityGroups() {
	
		return allSecurityGroups;
	}
	
	public String getImageId() {
	
		return imageId;
	}
	
	public String getInstanceName() {
	
		return instanceName;
	}
	
	public String getInstanceType() {
	
		return instanceType;
	}
	
	public String getKeyName() {
	
		return keyName;
	}
	
	public String getPlacement() {
	
		return placement;
	}
	
	public String[] getSecurityGroupIds() {
	
		return securityGroupIds;
	}
	
	public void setAllImages(List<AWSEC2ImageTO> allImages) {
	
		this.allImages = allImages;
	}
	
	public void setAllInstanceTypes(List<String> allInstanceTypes) {
	
		this.allInstanceTypes = allInstanceTypes;
	}
	
	public void setAllKeyNames(List<String> allKeyNames) {
	
		this.allKeyNames = allKeyNames;
	}
	
	public void setAllPlacements(List<String> allPlacements) {
	
		this.allPlacements = allPlacements;
	}
	
	public void setAllSecurityGroups(List<AWSEC2SecurityGroupTO> allSecurityGroups) {
	
		this.allSecurityGroups = allSecurityGroups;
	}
	
	public void setImageId(String imageId) {
	
		this.imageId = imageId;
	}
	
	public void setInstanceName(String instanceName) {
	
		this.instanceName = instanceName;
	}
	
	public void setInstanceType(String instanceType) {
	
		this.instanceType = instanceType;
	}
	
	public void setKeyName(String keyName) {
	
		this.keyName = keyName;
	}
	
	public void setPlacement(String placement) {
	
		this.placement = placement;
	}
	
	public void setSecurityGroupIds(String[] securityGroupIdsNew) {
	
		if (securityGroupIdsNew == null) {
			this.securityGroupIds = new String[0];
		} else {
			this.securityGroupIds = Arrays.copyOf(securityGroupIdsNew, securityGroupIdsNew.length);
		}
	}
}
