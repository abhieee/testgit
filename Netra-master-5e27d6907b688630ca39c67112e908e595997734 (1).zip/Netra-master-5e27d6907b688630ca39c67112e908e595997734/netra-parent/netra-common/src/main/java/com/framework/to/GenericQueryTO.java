package com.framework.to;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @author TCS
 */
public class GenericQueryTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5844015992965580371L;
	private Long deviceId = null;
	private Date startTime = null;
	private Date endTime = null;
	private Long deviceConfigId = null;
	private String release = null;
	private String name = null;
	private List<Long> deviceIds = null;
	private String stc = null;
	private String ucb = null;
	private Long domainId = null;
	private String choiceForStcReports = null;
	private Date stcDate = null;
	
	public String getChoiceForStcReports() {
	
		return choiceForStcReports;
	}
	
	/**
	 * @return the deviceConfigId
	 */
	public Long getDeviceConfigId() {
	
		return deviceConfigId;
	}
	
	/**
	 * @return the deviceId
	 */
	public Long getDeviceId() {
	
		return deviceId;
	}
	
	/**
	 * @return the deviceIds
	 */
	public List<Long> getDeviceIds() {
	
		return deviceIds;
	}
	
	public Long getDomainId() {
	
		return domainId;
	}
	
	/**
	 * @return the endTime
	 */
	public Date getEndTime() {
	
		return endTime;
	}
	
	/**
	 * @return the name
	 */
	public String getName() {
	
		return name;
	}
	
	/**
	 * @return the release
	 */
	public String getRelease() {
	
		return release;
	}
	
	/**
	 * @return the startTime
	 */
	public Date getStartTime() {
	
		return startTime;
	}
	
	/**
	 * @return the stc
	 */
	public String getStc() {
	
		return stc;
	}
	
	public Date getStcDate() {
	
		return stcDate;
	}
	
	/**
	 * @return the ucb
	 */
	public String getUcb() {
	
		return ucb;
	}
	
	public void setChoiceForStcReports(String choiceForStcReports) {
	
		this.choiceForStcReports = choiceForStcReports;
	}
	
	/**
	 * @param deviceConfigId
	 *                the deviceConfigId to set
	 */
	public void setDeviceConfigId(Long deviceConfigId) {
	
		this.deviceConfigId = deviceConfigId;
	}
	
	/**
	 * @param deviceId
	 *                the deviceId to set
	 */
	public void setDeviceId(Long deviceId) {
	
		this.deviceId = deviceId;
	}
	
	/**
	 * @param deviceIds
	 *                the deviceIds to set
	 */
	public void setDeviceIds(List<Long> deviceIds) {
	
		this.deviceIds = deviceIds;
	}
	
	public void setDomainId(Long domainId) {
	
		this.domainId = domainId;
	}
	
	/**
	 * @param endTime
	 *                the endTime to set
	 */
	public void setEndTime(Date endTime) {
	
		this.endTime = endTime;
	}
	
	/**
	 * @param name
	 *                the name to set
	 */
	public void setName(String name) {
	
		this.name = name;
	}
	
	/**
	 * @param release
	 *                the release to set
	 */
	public void setRelease(String release) {
	
		this.release = release;
	}
	
	/**
	 * @param startTime
	 *                the startTime to set
	 */
	public void setStartTime(Date startTime) {
	
		this.startTime = startTime;
	}
	
	/**
	 * @param stc
	 *                the stc to set
	 */
	public void setStc(String stc) {
	
		this.stc = stc;
	}
	
	public void setStcDate(Date stcDate) {
	
		this.stcDate = stcDate;
	}
	
	/**
	 * @param ucb
	 *                the ucb to set
	 */
	public void setUcb(String ucb) {
	
		this.ucb = ucb;
	}
}
