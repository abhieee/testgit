package com.framework.to;

import java.io.Serializable;
import java.util.Date;

public class IssuesSonarTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4034415428274819493L;
	private long id;
	private String kee;
	private long componentId;
	private long rootComponentId;
	private long ruleId;
	private String severity;
	private long manualSeverity;
	private String message;
	private long line;
	private double effortToFix;
	private String status;
	private String resolution;
	private String checksum;
	private String reporter;
	private String assignee;
	private String authorLogin;
	private String actionPlanKey;
	private String issueAttributes;
	private Date issueCreationDate;
	private Date issueCloseDate;
	private Date issueUpdateDate;
	private Date createdAt;
	private Date updatedAt;
	private long technicalDebt;
	private String component;
	
	public String getComponent() {
	
		return component;
	}
	
	public void setComponent(String component) {
	
		this.component = component;
	}
	
	public String getActionPlanKey() {
	
		return actionPlanKey;
	}
	
	public String getAssignee() {
	
		return assignee;
	}
	
	public String getAuthorLogin() {
	
		return authorLogin;
	}
	
	public String getChecksum() {
	
		return checksum;
	}
	
	public long getComponentId() {
	
		return componentId;
	}
	
	public Date getCreatedAt() {
	
		return createdAt;
	}
	
	public double getEffortToFix() {
	
		return effortToFix;
	}
	
	public long getId() {
	
		return id;
	}
	
	public String getIssueAttributes() {
	
		return issueAttributes;
	}
	
	public Date getIssueCloseDate() {
	
		return issueCloseDate;
	}
	
	public Date getIssueCreationDate() {
	
		return issueCreationDate;
	}
	
	public Date getIssueUpdateDate() {
	
		return issueUpdateDate;
	}
	
	public String getKee() {
	
		return kee;
	}
	
	public long getLine() {
	
		return line;
	}
	
	public long getManualSeverity() {
	
		return manualSeverity;
	}
	
	public String getMessage() {
	
		return message;
	}
	
	public String getReporter() {
	
		return reporter;
	}
	
	public String getResolution() {
	
		return resolution;
	}
	
	public long getRootComponentId() {
	
		return rootComponentId;
	}
	
	public long getRuleId() {
	
		return ruleId;
	}
	
	public String getSeverity() {
	
		return severity;
	}
	
	public String getStatus() {
	
		return status;
	}
	
	public long getTechnicalDebt() {
	
		return technicalDebt;
	}
	
	public Date getUpdatedAt() {
	
		return updatedAt;
	}
	
	public void setActionPlanKey(String actionPlanKey) {
	
		this.actionPlanKey = actionPlanKey;
	}
	
	public void setAssignee(String assignee) {
	
		this.assignee = assignee;
	}
	
	public void setAuthorLogin(String authorLogin) {
	
		this.authorLogin = authorLogin;
	}
	
	public void setChecksum(String checksum) {
	
		this.checksum = checksum;
	}
	
	public void setComponentId(long componentId) {
	
		this.componentId = componentId;
	}
	
	public void setCreatedAt(Date createdAt) {
	
		this.createdAt = createdAt;
	}
	
	public void setEffortToFix(double effortToFix) {
	
		this.effortToFix = effortToFix;
	}
	
	public void setId(long id) {
	
		this.id = id;
	}
	
	public void setIssueAttributes(String issueAttributes) {
	
		this.issueAttributes = issueAttributes;
	}
	
	public void setIssueCloseDate(Date issueCloseDate) {
	
		this.issueCloseDate = issueCloseDate;
	}
	
	public void setIssueCreationDate(Date issueCreationDate) {
	
		this.issueCreationDate = issueCreationDate;
	}
	
	public void setIssueUpdateDate(Date issueUpdateDate) {
	
		this.issueUpdateDate = issueUpdateDate;
	}
	
	public void setKee(String kee) {
	
		this.kee = kee;
	}
	
	public void setLine(long line) {
	
		this.line = line;
	}
	
	public void setManualSeverity(long manualSeverity) {
	
		this.manualSeverity = manualSeverity;
	}
	
	public void setMessage(String message) {
	
		this.message = message;
	}
	
	public void setReporter(String reporter) {
	
		this.reporter = reporter;
	}
	
	public void setResolution(String resolution) {
	
		this.resolution = resolution;
	}
	
	public void setRootComponentId(long rootComponentId) {
	
		this.rootComponentId = rootComponentId;
	}
	
	public void setRuleId(long ruleId) {
	
		this.ruleId = ruleId;
	}
	
	public void setSeverity(String severity) {
	
		this.severity = severity;
	}
	
	public void setStatus(String status) {
	
		this.status = status;
	}
	
	public void setTechnicalDebt(long technicalDebt) {
	
		this.technicalDebt = technicalDebt;
	}
	
	public void setUpdatedAt(Date updatedAt) {
	
		this.updatedAt = updatedAt;
	}
}
