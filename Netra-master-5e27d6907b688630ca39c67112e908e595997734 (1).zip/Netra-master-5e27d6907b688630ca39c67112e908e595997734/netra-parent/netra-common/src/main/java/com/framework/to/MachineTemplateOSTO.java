/**
 *
 */
package com.framework.to;

import java.io.Serializable;

/**
 * @author 460650
 */
public class MachineTemplateOSTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6193912532760675861L;
	private String id;
	private String flavorType;
	private String flavorId;
	private String disk;
	private String username;
	private String password;
	private MachineTemplateTO machineTemplate;
	
	public String getDisk() {
	
		return disk;
	}
	
	public String getFlavorId() {
	
		return flavorId;
	}
	
	public String getFlavorType() {
	
		return flavorType;
	}
	
	public String getId() {
	
		return id;
	}
	
	public MachineTemplateTO getMachineTemplate() {
	
		return machineTemplate;
	}
	
	public String getPassword() {
	
		return password;
	}
	
	public String getUsername() {
	
		return username;
	}
	
	public void setDisk(String disk) {
	
		this.disk = disk;
	}
	
	public void setFlavorId(String flavorId) {
	
		this.flavorId = flavorId;
	}
	
	public void setFlavorType(String flavorType) {
	
		this.flavorType = flavorType;
	}
	
	public void setId(String id) {
	
		this.id = id;
	}
	
	public void setMachineTemplate(MachineTemplateTO machineTemplate) {
	
		this.machineTemplate = machineTemplate;
	}
	
	public void setPassword(String password) {
	
		this.password = password;
	}
	
	public void setUsername(String username) {
	
		this.username = username;
	}
}
