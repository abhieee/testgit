/**
 *
 */
package com.framework.puppetMaster.to;

import java.io.Serializable;
import java.util.List;
import com.framework.to.SoftwareconfigTO;

/**
 * @author 584175
 */
public class PuppetProcessSoftwareMapping implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 9177864210680701927L;
	private long softwareProcessMappingId;
	private SoftwareconfigTO softwareConfigTO;
	private PuppetProcess puppetProcess;
	private List<Long> puppetProcessList = null;
	private Long softwareId = null;
	private Long softwareConfigId = null;
	
	/**
	 * @return the puppetProcess
	 */
	public PuppetProcess getPuppetProcess() {
	
		return puppetProcess;
	}
	
	/**
	 * @return the puppetProcessList
	 */
	public List<Long> getPuppetProcessList() {
	
		return puppetProcessList;
	}
	
	public Long getSoftwareConfigId() {
	
		return softwareConfigId;
	}
	
	/**
	 * @return the puppetSoftwareProcessMappingId
	 */
	/**
	 * @param puppetSoftwareProcessMappingId
	 *                the puppetSoftwareProcessMappingId to set
	 */
	public SoftwareconfigTO getSoftwareConfigTO() {
	
		return softwareConfigTO;
	}
	
	public Long getSoftwareId() {
	
		return softwareId;
	}
	
	/**
	 * @return the softwareProcessMappingId
	 */
	public long getSoftwareProcessMappingId() {
	
		return softwareProcessMappingId;
	}
	
	/**
	 * @param puppetProcess
	 *                the puppetProcess to set
	 */
	public void setPuppetProcess(PuppetProcess puppetProcess) {
	
		this.puppetProcess = puppetProcess;
	}
	
	/**
	 * @param puppetProcessList
	 *                the puppetProcessList to set
	 */
	public void setPuppetProcessList(List<Long> puppetProcessList) {
	
		this.puppetProcessList = puppetProcessList;
	}
	
	public void setSoftwareConfigId(Long softwareConfigId) {
	
		this.softwareConfigId = softwareConfigId;
	}
	
	public void setSoftwareConfigTO(SoftwareconfigTO softwareConfigTO) {
	
		this.softwareConfigTO = softwareConfigTO;
	}
	
	public void setSoftwareId(Long softwareId) {
	
		this.softwareId = softwareId;
	}
	
	/**
	 * @param softwareProcessMappingId
	 *                the softwareProcessMappingId to set
	 */
	public void setSoftwareProcessMappingId(long softwareProcessMappingId) {
	
		this.softwareProcessMappingId = softwareProcessMappingId;
	}
}
