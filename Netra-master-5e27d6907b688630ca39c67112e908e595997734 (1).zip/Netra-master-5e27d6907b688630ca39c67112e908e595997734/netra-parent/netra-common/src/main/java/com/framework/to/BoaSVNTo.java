package com.framework.to;

import java.io.Serializable;

public class BoaSVNTo implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5486438021917878586L;
	private String directoryName = null;
	private String directoryId = null;
	
	public BoaSVNTo() {
	
		/* No implementation required at the moment. Method for future use. */
	}
	
	public String getDirectoryId() {
	
		return directoryId;
	}
	
	public String getDirectoryName() {
	
		return directoryName;
	}
	
	public void setDirectoryId(String directoryId) {
	
		this.directoryId = directoryId;
	}
	
	public void setDirectoryName(String directoryName) {
	
		this.directoryName = directoryName;
	}
}
