package com.framework.common;

import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Base64;
import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;

/**
 * Encrypts the password
 *
 * @author TCS
 */
public class PasswordEncryptorUtil {
	
	public static String encodeTextByB64(String plainText) {
	
		return new String(Base64.encodeBase64(plainText.getBytes(StandardCharsets.UTF_8)));
	}
	
	public static String decodeTextByB64(String encodedText) {
	
		return new String(Base64.decodeBase64(encodedText.getBytes(StandardCharsets.UTF_8)));
	}
	
	public String encrypt(String plainText) {
	
		return encryptor.encrypt(plainText);
	}
	
	public String decryptPassword(String encryptedText) {
	
		return encryptor.decrypt(encryptedText);
	}
	
	private StandardPBEStringEncryptor encryptor;
	
	public StandardPBEStringEncryptor getEncryptor() {
	
		return encryptor;
	}
	
	public void setEncryptor(StandardPBEStringEncryptor encryptor) {
	
		this.encryptor = encryptor;
	}
}
