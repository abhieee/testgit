package com.framework.to;

import java.util.Date;

public class Softwareconfig_InvTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8886854622375243284L;
	private String version;
	private Software_InvTO software;
	private Long deviceId;
	
	public Softwareconfig_InvTO() {
	
		/* No implementation required at the moment. Method for future use. */
	}
	
	public Softwareconfig_InvTO(Software_InvTO software, Date effectiveDate, String effectiveRelease) {
	
		this.software = software;
	}
	
	public Softwareconfig_InvTO(Software_InvTO software, String patch, Date effectiveDate, String location, String effectiveRelease, String remark) {
	
		this.software = software;
	}
	
	public Long getDeviceId() {
	
		return deviceId;
	}
	
	public Software_InvTO getSoftware() {
	
		return this.software;
	}
	
	public String getVersion() {
	
		return this.version;
	}
	
	public void setDeviceId(Long deviceId) {
	
		this.deviceId = deviceId;
	}
	
	public void setSoftware(Software_InvTO software) {
	
		this.software = software;
	}
	
	public void setVersion(String version) {
	
		this.version = version;
	}
}
