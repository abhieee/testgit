package com.pres.mail;

import java.util.List;
import java.util.Properties;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Authenticator;
import javax.mail.BodyPart;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Part;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.mail.MailAuthenticationException;
import org.springframework.mail.MailException;
import org.springframework.mail.MailPreparationException;
import org.springframework.mail.MailSendException;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import com.framework.exception.CMMException;

@PropertySource("classpath:/messages.properties")
public class Mail {
	
	private List<String> mailReceiver;
	private List<String> mailReceiverInCc;
	private String mailSubject;
	private String mailMessage;
	private String username;
	private List<String> attachmentList;
	private int port;
	private String host;
	private String password;
	private static final Logger LOG = Logger.getLogger(Mail.class);
	@Value("${logging.mail.error.details:ThisValue}")
	private String mailErrorDetails;
	@Value("${logging.mail.error.info:ThisValue}")
	private String mailErrorInfo;
	@Value("${logging.mail.errorMsg:ThisValue}")
	private String mailErrorMsg;
	
	public Mail() {
	
		/* No implementation required at the moment. Method for future use. */
	}
	
	public List<String> getMailReceiver() {
	
		return mailReceiver;
	}
	
	public List<String> setMailReceiver(List<String> mailReceiver) {
	
		return this.mailReceiver = mailReceiver;
	}
	
	public String getMailSubject() {
	
		return mailSubject;
	}
	
	public void setMailSubject(String mailSubjct) {
	
		mailSubject = mailSubjct;
	}
	
	public String getMailMessage() {
	
		return mailMessage;
	}
	
	public void setMailMessage(String mailMsge) {
	
		mailMessage = mailMsge;
	}
	
	public void sendMail() throws CMMException {
	
		try {
			Properties propsSingle = new Properties();
			Authenticator auth = new Authenticator() {
				
				@Override
				protected PasswordAuthentication getPasswordAuthentication() {
				
					return new PasswordAuthentication(getUsername(), getPassword());
				}
			};
			Session sessionSingle = Session.getInstance(propsSingle, auth);
			MimeMessage forwardMsgSingle = new MimeMessage(sessionSingle);
			MimeMessageHelper messageHelperSingle = new MimeMessageHelper(forwardMsgSingle, true);
			messageHelperSingle.setFrom(getUsername(), "NETRA");
			messageHelperSingle.setSubject(mailSubject);
			if (getMailReceiver().size() == 1) {
				messageHelperSingle.setTo(getMailReceiver().get(0));
			}
			if (getMailReceiver().size() > 1) {
				String[] userEmailList = getReceiverForMail(getMailReceiver());
				messageHelperSingle.setTo(userEmailList);
			}
			if (getMailReceiverInCc().size() == 1) {
				messageHelperSingle.setCc(getMailReceiverInCc().get(0));
			}
			if (getMailReceiverInCc().size() > 1) {
				String[] userEmailList = getReceiverInCcForMail(getMailReceiverInCc());
				messageHelperSingle.setCc(userEmailList);
			}
			String messageContentSingle = mailMessage;
			forwardMsgSingle.setContent(messageContentSingle, "text/html; charset=utf-8");
			BodyPart messageBodyPart = new MimeBodyPart();
			Multipart multipart = new MimeMultipart();
			messageBodyPart.setContent(messageContentSingle, "text/html; charset=utf-8");
			multipart.addBodyPart(messageBodyPart);
			messageBodyPart = new MimeBodyPart();
			if (attachmentList != null) {
				for (String str : attachmentList) {
					MimeBodyPart messageBodyPart1 = new MimeBodyPart();
					DataSource source = new FileDataSource(str);
					messageBodyPart1.setDataHandler(new DataHandler(source));
					messageBodyPart1.setFileName(source.getName());
					messageBodyPart1.setDisposition(Part.ATTACHMENT);
					multipart.addBodyPart(messageBodyPart1);
				}
			}
			forwardMsgSingle.setContent(multipart, "text/html; charset=utf-8");
			JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
			mailSender.setUsername(getUsername());
			mailSender.setPassword(getPassword());
			mailSender.setHost(getHost());
			mailSender.setPort(getPort());
			mailSender.send(forwardMsgSingle);
		} catch (MailAuthenticationException mae) {
			LOG.error(mailErrorDetails + mailReceiver + mailErrorInfo + mae.getMessage());
			throw new CMMException("Error in sending mail- mail authentication exception", mae);
		} catch (MailPreparationException e) {
			LOG.error(mailErrorDetails + mailReceiver + mailErrorInfo + e.getMessage());
			throw new CMMException("Error in sending mail- mail preparation exception", e);
		} catch (MailSendException e) {
			LOG.error(mailErrorDetails + mailReceiver + mailErrorInfo + e.getMessage());
			throw new CMMException("Error in sending mail- mail send exception", e);
		} catch (MessagingException e) {
			LOG.error(mailErrorDetails + mailReceiver + mailErrorInfo + e.getMessage());
			throw new CMMException("Error in sending mail- mail messaging exception", e);
		} catch (MailException me) {
			LOG.debug(mailErrorInfo + me);
			throw new CMMException("Error occured in sending Mail", me);
		} catch (Exception me) {
			LOG.debug(mailErrorInfo + me);
			throw new CMMException("Error occured in sending Mail", me);
		}
	}
	
	private String[] getReceiverInCcForMail(List<String> mailReceiverInCc2) {
	
		int size = mailReceiverInCc2.size();
		String[] emailArray = new String[size];
		int count = 0;
		for (String email : mailReceiverInCc2) {
			emailArray[count] = email.trim();
			count++;
		}
		return emailArray;
	}
	
	public String[] getReceiverForMail(List<String> userEmailList) throws CMMException {
	
		int size = userEmailList.size();
		String[] emailArray = new String[size];
		int count = 0;
		for (String email : userEmailList) {
			emailArray[count] = email.trim();
			count++;
		}
		return emailArray;
	}
	
	public String getUsername() {
	
		return username;
	}
	
	public void setUsername(String username) {
	
		this.username = username;
	}
	
	public List<String> getAttachmentList() {
	
		return attachmentList;
	}
	
	public void setAttachmentList(List<String> attachmentList) {
	
		this.attachmentList = attachmentList;
	}
	
	public int getPort() {
	
		return port;
	}
	
	public void setPort(int port) {
	
		this.port = port;
	}
	
	public String getHost() {
	
		return host;
	}
	
	public void setHost(String host) {
	
		this.host = host;
	}
	
	public String getPassword() {
	
		return password;
	}
	
	public void setPassword(String password) {
	
		this.password = password;
	}
	
	public List<String> getMailReceiverInCc() {
	
		return mailReceiverInCc;
	}
	
	public void setMailReceiverInCc(List<String> mailReceiverInCc) {
	
		this.mailReceiverInCc = mailReceiverInCc;
	}
}