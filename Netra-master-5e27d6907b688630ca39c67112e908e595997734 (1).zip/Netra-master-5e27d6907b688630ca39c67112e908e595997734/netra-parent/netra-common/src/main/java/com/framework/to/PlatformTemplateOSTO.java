/**
 *
 */
package com.framework.to;

import java.io.Serializable;

/**
 * @author 460650
 */
public class PlatformTemplateOSTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6414214505646427596L;
	private String id;
	private String imageId;
	private String imageName;
	private PlatformTemplateTO platformTemplate;
	
	public String getId() {
	
		return id;
	}
	
	public String getImageId() {
	
		return imageId;
	}
	
	public String getImageName() {
	
		return imageName;
	}
	
	public PlatformTemplateTO getPlatformTemplate() {
	
		return platformTemplate;
	}
	
	public void setId(String id) {
	
		this.id = id;
	}
	
	public void setImageId(String imageId) {
	
		this.imageId = imageId;
	}
	
	public void setImageName(String imageName) {
	
		this.imageName = imageName;
	}
	
	public void setPlatformTemplate(PlatformTemplateTO platformTemplate) {
	
		this.platformTemplate = platformTemplate;
	}
}
