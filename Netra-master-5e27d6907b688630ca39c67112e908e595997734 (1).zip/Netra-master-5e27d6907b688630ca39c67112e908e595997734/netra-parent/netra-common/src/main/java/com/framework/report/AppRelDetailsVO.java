package com.framework.report;

import java.sql.Timestamp;

public class AppRelDetailsVO {
	
	private String buName;
	private String projName;
	private String relName;
	private String appName;
	private String envName;
	private String userName;
	private Timestamp completionDate;
	private long clientId;
	private long projId;
	private long appId;
	private Timestamp startTime;
	private Timestamp endTime;
	
	public String getBuName() {
	
		return buName;
	}
	
	public void setBuName(String buName) {
	
		this.buName = buName;
	}
	
	public String getProjName() {
	
		return projName;
	}
	
	public void setProjName(String projName) {
	
		this.projName = projName;
	}
	
	public String getRelName() {
	
		return relName;
	}
	
	public void setRelName(String relName) {
	
		this.relName = relName;
	}
	
	public String getAppName() {
	
		return appName;
	}
	
	public void setAppName(String appName) {
	
		this.appName = appName;
	}
	
	public String getUserName() {
	
		return userName;
	}
	
	public String getEnvName() {
	
		return envName;
	}
	
	public void setEnvName(String envName) {
	
		this.envName = envName;
	}
	
	public void setUserName(String userName) {
	
		this.userName = userName;
	}
	
	public Timestamp getCompletionDate() {
	
		return completionDate;
	}
	
	public void setCompletionDate(Timestamp completionDate) {
	
		this.completionDate = completionDate;
	}
	
	public long getClientId() {
	
		return clientId;
	}
	
	public void setClientId(long clientId) {
	
		this.clientId = clientId;
	}
	
	public long getProjId() {
	
		return projId;
	}
	
	public void setProjId(long projId) {
	
		this.projId = projId;
	}
	
	public long getAppId() {
	
		return appId;
	}
	
	public void setAppId(long appId) {
	
		this.appId = appId;
	}
	
	public Timestamp getStartTime() {
	
		return startTime;
	}
	
	public void setStartTime(Timestamp startTime) {
	
		this.startTime = startTime;
	}
	
	public Timestamp getEndTime() {
	
		return endTime;
	}
	
	public void setEndTime(Timestamp endTime) {
	
		this.endTime = endTime;
	}
}
