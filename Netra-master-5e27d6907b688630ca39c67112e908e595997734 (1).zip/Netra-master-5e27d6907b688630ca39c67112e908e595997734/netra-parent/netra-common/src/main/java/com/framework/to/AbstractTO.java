package com.framework.to;

import java.io.Serializable;
import java.util.Date;

/**
 * This class serves as an abstract transfer object to carry information across the tiers. Other TO definitions must extend this class.
 *
 * @author TCS
 */
public abstract class AbstractTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8271803022924840600L;
	/** Used for database rowset identification */
	private Long id;
	private Long createdById;
	private Long modifiedbyId;
	private Date createdDate;
	private Date modifiedDate;
	
	/**
	 * @return the createdById
	 */
	public Long getCreatedById() {
	
		return createdById;
	}
	
	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
	
		return createdDate;
	}
	
	public Long getId() {
	
		return id;
	}
	
	/**
	 * @return the modifiedbyId
	 */
	public Long getModifiedbyId() {
	
		return modifiedbyId;
	}
	
	/**
	 * @return the modifiedDate
	 */
	public Date getModifiedDate() {
	
		return modifiedDate;
	}
	
	/**
	 * @param createdById
	 *                the createdById to set
	 */
	public void setCreatedById(Long createdById) {
	
		this.createdById = createdById;
	}
	
	/**
	 * @param createdDate
	 *                the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
	
		this.createdDate = createdDate;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	/**
	 * @param modifiedbyId
	 *                the modifiedbyId to set
	 */
	public void setModifiedbyId(Long modifiedbyId) {
	
		this.modifiedbyId = modifiedbyId;
	}
	
	/**
	 * @param modifiedDate
	 *                the modifiedDate to set
	 */
	public void setModifiedDate(Date modifiedDate) {
	
		this.modifiedDate = modifiedDate;
	}
}
