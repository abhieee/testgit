package com.framework.to;

public class MailSetupRoleMappingTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1568990840221725322L;
	private Long mailSetupId;
	private Long roleId;
	RoleTO roleTO = new RoleTO();
	
	public Long getMailSetupId() {
	
		return mailSetupId;
	}
	
	public Long getRoleId() {
	
		return roleId;
	}
	
	public RoleTO getRoleTO() {
	
		return roleTO;
	}
	
	public void setMailSetupId(Long mailSetupId) {
	
		this.mailSetupId = mailSetupId;
	}
	
	public void setRoleId(Long roleId) {
	
		this.roleId = roleId;
	}
	
	public void setRoleTO(RoleTO roleTO) {
	
		this.roleTO = roleTO;
	}
}