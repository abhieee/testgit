package com.framework.to;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

public class ReleasePlanningPhasesTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2549658269085498658L;
	private Long id;
	private Long releasePlanningId;
	private Long applicationPhaseId;
	private ReleasePlanningTO releasePlanningTO;
	private ApplicationReleasePhaseTO applicationReleasePhaseTO;
	private List<ApplicationReleasePhaseTO> applicationReleasePhaseList;
	private List<Long> selectedPhasesList;
	private TestingPhaseTO testingPhaseTO;
	private List<EnvironmentTO> enviromentTO = null;
	private Set<ReservationTO> reservationTO = null;
	private List<ProjectViewReservationTO> topologyTO = null;
	
	public List<ProjectViewReservationTO> getTopologyTO() {
	
		return topologyTO;
	}
	
	public void setTopologyTO(List<ProjectViewReservationTO> topologyTO) {
	
		this.topologyTO = topologyTO;
	}
	
	public Set<ReservationTO> getReservationTO() {
	
		return reservationTO;
	}
	
	public void setReservationTO(Set<ReservationTO> reservationTO) {
	
		this.reservationTO = reservationTO;
	}
	
	public List<EnvironmentTO> getEnviromentTO() {
	
		return enviromentTO;
	}
	
	public void setEnviromentTO(List<EnvironmentTO> enviromentTO) {
	
		this.enviromentTO = enviromentTO;
	}
	
	public Long getApplicationPhaseId() {
	
		return applicationPhaseId;
	}
	
	public List<ApplicationReleasePhaseTO> getApplicationReleasePhaseList() {
	
		return applicationReleasePhaseList;
	}
	
	public ApplicationReleasePhaseTO getApplicationReleasePhaseTO() {
	
		return applicationReleasePhaseTO;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public Long getReleasePlanningId() {
	
		return releasePlanningId;
	}
	
	public ReleasePlanningTO getReleasePlanningTO() {
	
		return releasePlanningTO;
	}
	
	public List<Long> getSelectedPhasesList() {
	
		return selectedPhasesList;
	}
	
	public TestingPhaseTO getTestingPhaseTO() {
	
		return testingPhaseTO;
	}
	
	public void setApplicationPhaseId(Long applicationPhaseId) {
	
		this.applicationPhaseId = applicationPhaseId;
	}
	
	public void setApplicationReleasePhaseList(List<ApplicationReleasePhaseTO> applicationReleasePhaseList) {
	
		this.applicationReleasePhaseList = applicationReleasePhaseList;
	}
	
	public void setApplicationReleasePhaseTO(ApplicationReleasePhaseTO applicationReleasePhaseTO) {
	
		this.applicationReleasePhaseTO = applicationReleasePhaseTO;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setReleasePlanningId(Long releasePlanningId) {
	
		this.releasePlanningId = releasePlanningId;
	}
	
	public void setReleasePlanningTO(ReleasePlanningTO releasePlanningTO) {
	
		this.releasePlanningTO = releasePlanningTO;
	}
	
	public void setSelectedPhasesList(List<Long> selectedPhasesList) {
	
		this.selectedPhasesList = selectedPhasesList;
	}
	
	public void setTestingPhaseTO(TestingPhaseTO testingPhaseTO) {
	
		this.testingPhaseTO = testingPhaseTO;
	}
}