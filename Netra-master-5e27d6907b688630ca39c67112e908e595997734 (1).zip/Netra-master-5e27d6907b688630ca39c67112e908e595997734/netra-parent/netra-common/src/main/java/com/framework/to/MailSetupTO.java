package com.framework.to;

import java.util.ArrayList;
import java.util.List;

public class MailSetupTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -855855819336613754L;
	private Long serviceId;
	private String receiverTo = null;
	private String receiverCc = null;
	private String message;
	private String action;
	private boolean serviceStatus;
	private Long subServiceId;
	private String userEmails;
	private boolean parentServiceFlag = false;
	private Long serviceRequestId;
	List<MailSetupServicesMappingTO> selectedServiceList = new ArrayList<MailSetupServicesMappingTO>(0);
	private String subject;
	private Long lastUpdatedBy;
	private Long currentOwnerId;
	private Long status;
	private boolean approveFlag = false;
	private boolean rejectFlag = false;
	private boolean completionFlag = false;
	private boolean attachmentFlag = true;
	private boolean submitFlag = true;
	
	public String getAction() {
	
		return action;
	}
	
	public Long getCurrentOwnerId() {
	
		return currentOwnerId;
	}
	
	public Long getLastUpdatedBy() {
	
		return lastUpdatedBy;
	}
	
	public String getMessage() {
	
		return message;
	}
	
	public String getReceiverCc() {
	
		return receiverCc;
	}
	
	public String getReceiverTo() {
	
		return receiverTo;
	}
	
	public List<MailSetupServicesMappingTO> getSelectedServiceList() {
	
		return selectedServiceList;
	}
	
	public Long getServiceId() {
	
		return serviceId;
	}
	
	public Long getServiceRequestId() {
	
		return serviceRequestId;
	}
	
	public Long getStatus() {
	
		return status;
	}
	
	public String getSubject() {
	
		return subject;
	}
	
	public Long getSubServiceId() {
	
		return subServiceId;
	}
	
	public String getUserEmails() {
	
		return userEmails;
	}
	
	public boolean isApproveFlag() {
	
		return approveFlag;
	}
	
	public boolean isAttachmentFlag() {
	
		return attachmentFlag;
	}
	
	public boolean isParentServiceFlag() {
	
		return parentServiceFlag;
	}
	
	public boolean isRejectFlag() {
	
		return rejectFlag;
	}
	
	public boolean isServiceStatus() {
	
		return serviceStatus;
	}
	
	public void setAction(String action) {
	
		this.action = action;
	}
	
	public void setApproveFlag(boolean approveFlag) {
	
		this.approveFlag = approveFlag;
	}
	
	public void setAttachmentFlag(boolean attachmentFlag) {
	
		this.attachmentFlag = attachmentFlag;
	}
	
	public void setCurrentOwnerId(Long currentOwnerId) {
	
		this.currentOwnerId = currentOwnerId;
	}
	
	public void setLastUpdatedBy(Long lastUpdatedBy) {
	
		this.lastUpdatedBy = lastUpdatedBy;
	}
	
	public void setMessage(String message) {
	
		this.message = message;
	}
	
	public void setParentServiceFlag(boolean parentServiceFlag) {
	
		this.parentServiceFlag = parentServiceFlag;
	}
	
	public void setReceiverCc(String receiverCc) {
	
		this.receiverCc = receiverCc;
	}
	
	public void setReceiverTo(String receiverTo) {
	
		this.receiverTo = receiverTo;
	}
	
	public void setRejectFlag(boolean rejectFlag) {
	
		this.rejectFlag = rejectFlag;
	}
	
	public void setSelectedServiceList(List<MailSetupServicesMappingTO> selectedServiceList) {
	
		this.selectedServiceList = selectedServiceList;
	}
	
	public void setServiceId(Long serviceId) {
	
		this.serviceId = serviceId;
	}
	
	public void setServiceRequestId(Long serviceRequestId) {
	
		this.serviceRequestId = serviceRequestId;
	}
	
	public void setServiceStatus(boolean serviceStatus) {
	
		this.serviceStatus = serviceStatus;
	}
	
	public void setStatus(Long status) {
	
		this.status = status;
	}
	
	public void setSubject(String subject) {
	
		this.subject = subject;
	}
	
	public void setSubServiceId(Long subServiceId) {
	
		this.subServiceId = subServiceId;
	}
	
	public void setUserEmails(String userEmails) {
	
		this.userEmails = userEmails;
	}
	
	public boolean isCompletionFlag() {
	
		return completionFlag;
	}
	
	public void setCompletionFlag(boolean completionFlag) {
	
		this.completionFlag = completionFlag;
	}
	
	public boolean isSubmitFlag() {
	
		return submitFlag;
	}
	
	public void setSubmitFlag(boolean submitFlag) {
	
		this.submitFlag = submitFlag;
	}
}