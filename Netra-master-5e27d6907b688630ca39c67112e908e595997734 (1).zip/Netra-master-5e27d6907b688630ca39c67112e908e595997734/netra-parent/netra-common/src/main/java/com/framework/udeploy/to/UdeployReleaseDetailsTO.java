package com.framework.udeploy.to;

public class UdeployReleaseDetailsTO {
	
	private Long id;
	private String username;
	private String password;
	private String ipaddr;
	private String hostName;
	private String status;
	private String url;
	private String sharename;
	private long searchCount;
	private int firstResult = 1;
	private int tableSize;
	
	public int getFirstResult() {
	
		return firstResult;
	}
	
	public String getHostName() {
	
		return hostName;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public String getIpaddr() {
	
		return ipaddr;
	}
	
	public String getPassword() {
	
		return password;
	}
	
	public long getSearchCount() {
	
		return searchCount;
	}
	
	public String getSharename() {
	
		return sharename;
	}
	
	public String getStatus() {
	
		return status;
	}
	
	public int getTableSize() {
	
		return tableSize;
	}
	
	public String getUrl() {
	
		return url;
	}
	
	public String getUsername() {
	
		return username;
	}
	
	public void setFirstResult(int firstResult) {
	
		this.firstResult = firstResult;
	}
	
	public void setHostName(String hostName) {
	
		this.hostName = hostName;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setIpaddr(String ipaddr) {
	
		this.ipaddr = ipaddr;
	}
	
	public void setPassword(String password) {
	
		this.password = password;
	}
	
	public void setSearchCount(long searchCount) {
	
		this.searchCount = searchCount;
	}
	
	public void setSharename(String sharename) {
	
		this.sharename = sharename;
	}
	
	public void setStatus(String status) {
	
		this.status = status;
	}
	
	public void setTableSize(int tableSize) {
	
		this.tableSize = tableSize;
	}
	
	public void setUrl(String url) {
	
		this.url = url;
	}
	
	public void setUsername(String username) {
	
		this.username = username;
	}
}
