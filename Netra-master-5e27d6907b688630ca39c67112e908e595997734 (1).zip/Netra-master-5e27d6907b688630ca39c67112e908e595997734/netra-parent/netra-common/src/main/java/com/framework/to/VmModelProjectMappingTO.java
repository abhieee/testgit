package com.framework.to;

import java.io.Serializable;

public class VmModelProjectMappingTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 662607357796944580L;
	private Long modelId;
	private Long projectId;
	private Long Id;
	
	public Long getId() {
	
		return Id;
	}
	
	public Long getModelId() {
	
		return modelId;
	}
	
	public Long getProjectId() {
	
		return projectId;
	}
	
	public void setId(Long id) {
	
		Id = id;
	}
	
	public void setModelId(Long modelId) {
	
		this.modelId = modelId;
	}
	
	public void setProjectId(Long projectId) {
	
		this.projectId = projectId;
	}
}
