/**
 *
 */
package com.framework.nolio.to;

import java.io.Serializable;
import java.util.List;
import com.framework.to.SoftwareconfigTO;

/**
 * @author 460650
 */
public class NolioProcessSoftwareMapping implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -59481433740147125L;
	private long softwareProcessMappingId;
	private SoftwareconfigTO softwareConfigTO;
	private NolioProcess nolioProcess;
	private List<Long> processList = null;
	private Long softwareId = null;
	private Long softwareConfigId = null;
	
	public NolioProcess getNolioProcess() {
	
		return nolioProcess;
	}
	
	public List<Long> getProcessList() {
	
		return processList;
	}
	
	public Long getSoftwareConfigId() {
	
		return softwareConfigId;
	}
	
	public SoftwareconfigTO getSoftwareConfigTO() {
	
		return softwareConfigTO;
	}
	
	public Long getSoftwareId() {
	
		return softwareId;
	}
	
	public long getSoftwareProcessMappingId() {
	
		return softwareProcessMappingId;
	}
	
	public void setNolioProcess(NolioProcess nolioProcess) {
	
		this.nolioProcess = nolioProcess;
	}
	
	public void setProcessList(List<Long> processList) {
	
		this.processList = processList;
	}
	
	public void setSoftwareConfigId(Long softwareConfigId) {
	
		this.softwareConfigId = softwareConfigId;
	}
	
	public void setSoftwareConfigTO(SoftwareconfigTO softwareConfigTO) {
	
		this.softwareConfigTO = softwareConfigTO;
	}
	
	public void setSoftwareId(Long softwareId) {
	
		this.softwareId = softwareId;
	}
	
	public void setSoftwareProcessMappingId(long softwareProcessMappingId) {
	
		this.softwareProcessMappingId = softwareProcessMappingId;
	}
}
