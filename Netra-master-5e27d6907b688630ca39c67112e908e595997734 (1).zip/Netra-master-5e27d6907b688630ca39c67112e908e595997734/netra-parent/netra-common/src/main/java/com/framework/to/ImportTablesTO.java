package com.framework.to;

import java.io.Serializable;

public class ImportTablesTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String tableName;
	private String tool;
	private Long id;
	
	public String getTableName() {
	
		return tableName;
	}
	
	public void setTableName(String tableName) {
	
		this.tableName = tableName;
	}
	
	public String getTool() {
	
		return tool;
	}
	
	public void setTool(String tool) {
	
		this.tool = tool;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
}
