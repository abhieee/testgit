package com.framework.report;

import java.io.Serializable;
import java.util.List;

public class SoftwareEnvironmentDetailsReportVO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String name;
	private String applicationName;
	private String environmentName;
	private List<Software_summary> software_summary;
	
	public SoftwareEnvironmentDetailsReportVO() {
	
		/* No implementation required at the moment. Method for future use. */
	}
	
	public SoftwareEnvironmentDetailsReportVO(String name, String applicationName, String environmentName, List<Software_summary> software_summary) {
	
		this.name = name;
		this.applicationName = applicationName;
		this.environmentName = environmentName;
		this.software_summary = software_summary;
	}
	
	public String getName() {
	
		return name;
	}
	
	public void setName(String name) {
	
		this.name = name;
	}
	
	public String getApplicationName() {
	
		return applicationName;
	}
	
	public void setApplicationName(String applicationName) {
	
		this.applicationName = applicationName;
	}
	
	public String getEnvironmentName() {
	
		return environmentName;
	}
	
	public void setEnvironmentName(String environmentName) {
	
		this.environmentName = environmentName;
	}
	
	public List<Software_summary> getSoftware_summary() {
	
		return software_summary;
	}
	
	public void setSoftware_summary(List<Software_summary> software_summary) {
	
		this.software_summary = software_summary;
	}
}
