package com.framework.to;

import java.io.Serializable;
import java.util.Date;

public class ProjectsSonarTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2700070457641619654L;
	private Long id;
	private String name;
	private String description;
	private Long enabled;
	private String scope;
	private String qualifier;
	private String kee;
	private Long rootId;
	private String language;
	private Long copyResourceId;
	private String longName;
	private Long personId;
	private Date createdAt;
	
	public Long getCopyResourceId() {
	
		return copyResourceId;
	}
	
	public Date getCreatedAt() {
	
		return createdAt;
	}
	
	public String getDescription() {
	
		return description;
	}
	
	public Long getEnabled() {
	
		return enabled;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public String getKee() {
	
		return kee;
	}
	
	public String getLanguage() {
	
		return language;
	}
	
	public String getLongName() {
	
		return longName;
	}
	
	public String getName() {
	
		return name;
	}
	
	public Long getPersonId() {
	
		return personId;
	}
	
	public String getQualifier() {
	
		return qualifier;
	}
	
	public Long getRootId() {
	
		return rootId;
	}
	
	public String getScope() {
	
		return scope;
	}
	
	public void setCopyResourceId(Long copyResourceId) {
	
		this.copyResourceId = copyResourceId;
	}
	
	public void setCreatedAt(Date createdAt) {
	
		this.createdAt = createdAt;
	}
	
	public void setDescription(String description) {
	
		this.description = description;
	}
	
	public void setEnabled(Long enabled) {
	
		this.enabled = enabled;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setKee(String kee) {
	
		this.kee = kee;
	}
	
	public void setLanguage(String language) {
	
		this.language = language;
	}
	
	public void setLongName(String longName) {
	
		this.longName = longName;
	}
	
	public void setName(String name) {
	
		this.name = name;
	}
	
	public void setPersonId(Long personId) {
	
		this.personId = personId;
	}
	
	public void setQualifier(String qualifier) {
	
		this.qualifier = qualifier;
	}
	
	public void setRootId(Long rootId) {
	
		this.rootId = rootId;
	}
	
	public void setScope(String scope) {
	
		this.scope = scope;
	}
}
