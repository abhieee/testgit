/**
 *
 */
package com.framework.to;

import java.util.HashSet;
import java.util.Set;

/**
 * @author 737070
 */
public class ScriptTaskMappingTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -9145639306121797823L;
	private long scriptId;
	private TaskManagementTO taskManagementTO;
	private RepositoryTO repository;
	private String uploadFlag;
	private String filePath;
	private String targetLocation;
	private Set<ScriptParameterMapTO> scriptParameterMap = new HashSet<ScriptParameterMapTO>();
	private String filesName;
	private String uploadSource;
	
	public long getScriptId() {
	
		return scriptId;
	}
	
	public void setScriptId(long scriptId) {
	
		this.scriptId = scriptId;
	}
	
	public TaskManagementTO getTaskManagementTO() {
	
		return taskManagementTO;
	}
	
	public void setTaskManagementTO(TaskManagementTO taskManagementTO) {
	
		this.taskManagementTO = taskManagementTO;
	}
	
	public String getUploadFlag() {
	
		return uploadFlag;
	}
	
	public void setUploadFlag(String uploadFlag) {
	
		this.uploadFlag = uploadFlag;
	}
	
	public String getFilePath() {
	
		return filePath;
	}
	
	public void setFilePath(String filePath) {
	
		this.filePath = filePath;
	}
	
	public String getTargetLocation() {
	
		return targetLocation;
	}
	
	public void setTargetLocation(String targetLocation) {
	
		this.targetLocation = targetLocation;
	}
	
	public Set<ScriptParameterMapTO> getScriptParameterMap() {
	
		return scriptParameterMap;
	}
	
	public void setScriptParameterMap(Set<ScriptParameterMapTO> scriptParameterMap) {
	
		this.scriptParameterMap = scriptParameterMap;
	}
	
	public String getFilesName() {
	
		return filesName;
	}
	
	public void setFilesName(String filesName) {
	
		this.filesName = filesName;
	}
	
	public String getUploadSource() {
	
		return uploadSource;
	}
	
	public void setUploadSource(String uploadSource) {
	
		this.uploadSource = uploadSource;
	}
	
	public RepositoryTO getRepository() {
	
		return repository;
	}
	
	public void setRepository(RepositoryTO repository) {
	
		this.repository = repository;
	}
}
