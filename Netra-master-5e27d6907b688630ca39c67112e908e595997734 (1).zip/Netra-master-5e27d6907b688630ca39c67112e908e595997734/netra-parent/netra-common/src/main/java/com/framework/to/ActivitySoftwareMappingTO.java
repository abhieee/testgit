/**
 *
 */
package com.framework.to;

import java.io.Serializable;
import java.util.List;

/**
 * @author 460650
 */
public class ActivitySoftwareMappingTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4812068439188340503L;
	private long activitySoftwareMapId;
	private SoftwareconfigTO softwareconfigTO;
	private CAReleaseActivityTO caReleaseActivityTO;
	private List<Long> definedActivities;
	private String stringkey;
	private Long activityId;
	
	public Long getActivityId() {
	
		return activityId;
	}
	
	public long getActivitySoftwareMapId() {
	
		return activitySoftwareMapId;
	}
	
	public CAReleaseActivityTO getCaReleaseActivityTO() {
	
		return caReleaseActivityTO;
	}
	
	public List<Long> getDefinedActivities() {
	
		return definedActivities;
	}
	
	public SoftwareconfigTO getSoftwareconfigTO() {
	
		return softwareconfigTO;
	}
	
	public String getStringkey() {
	
		return stringkey;
	}
	
	public void setActivityId(Long activityId) {
	
		this.activityId = activityId;
	}
	
	public void setActivitySoftwareMapId(long activitySoftwareMapId) {
	
		this.activitySoftwareMapId = activitySoftwareMapId;
	}
	
	public void setCaReleaseActivityTO(CAReleaseActivityTO caReleaseActivityTO) {
	
		this.caReleaseActivityTO = caReleaseActivityTO;
	}
	
	public void setDefinedActivities(List<Long> definedActivities) {
	
		this.definedActivities = definedActivities;
	}
	
	public void setSoftwareconfigTO(SoftwareconfigTO softwareconfigTO) {
	
		this.softwareconfigTO = softwareconfigTO;
	}
	
	public void setStringkey(String stringkey) {
	
		this.stringkey = stringkey;
	}
}
