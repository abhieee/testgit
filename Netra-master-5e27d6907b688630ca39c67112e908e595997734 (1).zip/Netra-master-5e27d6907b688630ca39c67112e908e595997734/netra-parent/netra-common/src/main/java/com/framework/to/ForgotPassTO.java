package com.framework.to;

import java.io.Serializable;

public class ForgotPassTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String new_pwd;
	private String passwordEnc;
	private String confirm_pwd;
	private String ques1;
	private String ques2;
	private String ans1;
	private String ans2;
	private String username;
	private Long userId;
	private Long flag;
	private Long flag1;
	
	public String getAns1() {
	
		return ans1;
	}
	
	public String getAns2() {
	
		return ans2;
	}
	
	public String getConfirm_pwd() {
	
		return confirm_pwd;
	}
	
	public Long getFlag() {
	
		return flag;
	}
	
	public Long getFlag1() {
	
		return flag1;
	}
	
	public String getNew_pwd() {
	
		return new_pwd;
	}
	
	public String getPasswordEnc() {
	
		return passwordEnc;
	}
	
	public String getQues1() {
	
		return ques1;
	}
	
	public String getQues2() {
	
		return ques2;
	}
	
	public Long getUserId() {
	
		return userId;
	}
	
	public String getUsername() {
	
		return username;
	}
	
	public void setAns1(String ans1) {
	
		this.ans1 = ans1;
	}
	
	public void setAns2(String ans2) {
	
		this.ans2 = ans2;
	}
	
	public void setConfirm_pwd(String confirm_pwd) {
	
		this.confirm_pwd = confirm_pwd;
	}
	
	public void setFlag(Long flag) {
	
		this.flag = flag;
	}
	
	public void setFlag1(Long flag1) {
	
		this.flag1 = flag1;
	}
	
	public void setNew_pwd(String new_pwd) {
	
		this.new_pwd = new_pwd;
	}
	
	public void setPasswordEnc(String passwordEnc) {
	
		this.passwordEnc = passwordEnc;
	}
	
	public void setQues1(String ques1) {
	
		this.ques1 = ques1;
	}
	
	public void setQues2(String ques2) {
	
		this.ques2 = ques2;
	}
	
	public void setUserId(Long userId) {
	
		this.userId = userId;
	}
	
	public void setUsername(String username) {
	
		this.username = username;
	}
}
