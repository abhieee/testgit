package com.framework.to;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * This class declares the transfer object that carries user information across the application.
 *
 * @author TCS
 */
public class HardwareTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3093459890764520277L;
	private int mapId;
	private String osType;// This has been bind to the column location of table hardware
	private String processor;
	private String storage;
	private String ip;
	private String systemType;
	private Long status;
	private String sel1;
	private String sel2;
	private String hwStatus;
	private Long selectedStatus;
	private StatusTO statusTO = null;
	private StatusTO statusTO1 = null;
	private String softwareName;
	private String remarks;
	private double cost;
	private boolean validate;
	private String comments;
	private SoftwareTO software = new SoftwareTO();
	private Date modifiedbyDate;
	private Long projectId;
	private Long clientId;
	private Date fromDate;
	private Date toDate;
	private String operatingSystemName;
	private String cpuSpeed;
	private String swapMemory;
	private String storageTier;
	private String memory;
	private String imagePath;
	private PlatformMasterTO platformName;
	private Long selectedTemplate;
	private Long selectedShare;
	private Long selectedPlatformName = null;
	private Set<TemplatePropertyTO> templateProperties = new HashSet<TemplatePropertyTO>(0);
	private CIServerTO serverTO;
	private MachineTO machineTO;
	private String department;
	private String region;
	private String cityStateCountry;
	private String buildingAddress;
	private String room;
	private String model;
	private String patchLevel;
	private Date purchasedDate;
	private Date receivedDate;
	private Date installDate;
	
	public HardwareTO() {
	
		super();
	}
	
	public void copy(HardwareTO hardwareTO) {
	
		if (hardwareTO == null) {
			hardwareTO = new HardwareTO();
		}
		if ((hardwareTO.getName() == null) || !hardwareTO.getName().equals(this.getName())) {
			hardwareTO.setName(this.getName());
		}
		if ((hardwareTO.getOsType() == null) || !hardwareTO.getOsType().equals(this.getOsType())) {
			hardwareTO.setOsType(this.getOsType());
		}
		if ((hardwareTO.getProcessor() == null) || !hardwareTO.getProcessor().equals(this.getProcessor())) {
			hardwareTO.setProcessor(this.getProcessor());
		}
		if ((hardwareTO.getStorage() == null) || !hardwareTO.getStorage().equals(this.getStorage())) {
			hardwareTO.setStorage(this.getStorage());
		}
		if ((hardwareTO.getIp() == null) || !hardwareTO.getIp().equals(this.getIp())) {
			hardwareTO.setIp(this.getIp());
		}
		if ((hardwareTO.getSystemType() == null) || !hardwareTO.getSystemType().equals(this.getSystemType())) {
			hardwareTO.setSystemType(this.getSystemType());
		}
		if ((hardwareTO.getStatus() == null) || !hardwareTO.getStatus().equals(this.getStatus())) {
			hardwareTO.setStatus(this.getStatus());
		}
		if ((hardwareTO.getCpuSpeed() == null) || !hardwareTO.getCpuSpeed().equals(this.getCpuSpeed())) {
			hardwareTO.setCpuSpeed(this.getCpuSpeed());
		}
		if ((hardwareTO.getSwapMemory() == null) || !hardwareTO.getSwapMemory().equals(this.getSwapMemory())) {
			hardwareTO.setSwapMemory(this.getSwapMemory());
		}
		if ((hardwareTO.getStorageTier() == null) || !hardwareTO.getStorageTier().equals(this.getStorageTier())) {
			hardwareTO.setStorageTier(this.getStorageTier());
		}
		if ((hardwareTO.getMemory() == null) || !hardwareTO.getMemory().equals(this.getMemory())) {
			hardwareTO.setMemory(this.getMemory());
		}
		if ((hardwareTO.getImagePath() == null) || !hardwareTO.getImagePath().equals(this.getImagePath())) {
			hardwareTO.setImagePath(this.getImagePath());
		}
		if ((hardwareTO.getPlatformName() == null) || !hardwareTO.getPlatformName().equals(this.getPlatformName())) {
			hardwareTO.setPlatformName(this.getPlatformName());
		}
	}
	
	public String getBuildingAddress() {
	
		return buildingAddress;
	}
	
	public String getCityStateCountry() {
	
		return cityStateCountry;
	}
	
	public Long getClientId() {
	
		return clientId;
	}
	
	public String getComments() {
	
		return comments;
	}
	
	public double getCost() {
	
		return cost;
	}
	
	public String getCpuSpeed() {
	
		return cpuSpeed;
	}
	
	public String getDepartment() {
	
		return department;
	}
	
	public Date getFromDate() {
	
		return fromDate;
	}
	
	public String getHwStatus() {
	
		return hwStatus;
	}
	
	public String getImagePath() {
	
		return imagePath;
	}
	
	public Date getInstallDate() {
	
		return installDate;
	}
	
	public String getIp() {
	
		return ip;
	}
	
	public MachineTO getMachineTO() {
	
		return machineTO;
	}
	
	public int getMapId() {
	
		return mapId;
	}
	
	public String getMemory() {
	
		return memory;
	}
	
	public String getModel() {
	
		return model;
	}
	
	public Date getModifiedbyDate() {
	
		return modifiedbyDate;
	}
	
	public String getOperatingSystemName() {
	
		return operatingSystemName;
	}
	
	public String getOsType() {
	
		return osType;
	}
	
	public String getPatchLevel() {
	
		return patchLevel;
	}
	
	public PlatformMasterTO getPlatformName() {
	
		return platformName;
	}
	
	public String getProcessor() {
	
		return processor;
	}
	
	public Long getProjectId() {
	
		return projectId;
	}
	
	public Date getPurchasedDate() {
	
		return purchasedDate;
	}
	
	public Date getReceivedDate() {
	
		return receivedDate;
	}
	
	public String getRegion() {
	
		return region;
	}
	
	public String getRemarks() {
	
		return remarks;
	}
	
	public String getRoom() {
	
		return room;
	}
	
	public String getSel1() {
	
		return sel1;
	}
	
	public String getSel2() {
	
		return sel2;
	}
	
	public Long getSelectedPlatformName() {
	
		return selectedPlatformName;
	}
	
	public Long getSelectedShare() {
	
		return selectedShare;
	}
	
	public Long getSelectedStatus() {
	
		return selectedStatus;
	}
	
	public Long getSelectedTemplate() {
	
		return selectedTemplate;
	}
	
	public CIServerTO getServerTO() {
	
		return serverTO;
	}
	
	public SoftwareTO getSoftware() {
	
		return software;
	}
	
	public String getSoftwareName() {
	
		return softwareName;
	}
	
	public Long getStatus() {
	
		return status;
	}
	
	public StatusTO getStatusTO() {
	
		return statusTO;
	}
	
	public StatusTO getStatusTO1() {
	
		return statusTO1;
	}
	
	public String getStorage() {
	
		return storage;
	}
	
	public String getStorageTier() {
	
		return storageTier;
	}
	
	public String getSwapMemory() {
	
		return swapMemory;
	}
	
	public String getSystemType() {
	
		return systemType;
	}
	
	public Set<TemplatePropertyTO> getTemplateProperties() {
	
		return templateProperties;
	}
	
	public Date getToDate() {
	
		return toDate;
	}
	
	public boolean isValidate() {
	
		return validate;
	}
	
	public void setBuildingAddress(String buildingAddress) {
	
		this.buildingAddress = buildingAddress;
	}
	
	public void setCityStateCountry(String cityStateCountry) {
	
		this.cityStateCountry = cityStateCountry;
	}
	
	public void setClientId(Long clientId) {
	
		this.clientId = clientId;
	}
	
	public void setComments(String comments) {
	
		this.comments = comments;
	}
	
	public void setCost(double cost) {
	
		this.cost = cost;
	}
	
	public void setCpuSpeed(String cpuSpeed) {
	
		this.cpuSpeed = cpuSpeed;
	}
	
	public void setCreatedByDate(Date createdByDate) {
	
	}
	
	public void setDepartment(String department) {
	
		this.department = department;
	}
	
	public void setFromDate(Date fromDate) {
	
		this.fromDate = fromDate;
	}
	
	public void setHwStatus(String hwStatus) {
	
		this.hwStatus = hwStatus;
	}
	
	public void setImagePath(String imagePath) {
	
		this.imagePath = imagePath;
	}
	
	public void setInstallDate(Date installDate) {
	
		this.installDate = installDate;
	}
	
	public void setIp(String ip) {
	
		this.ip = ip;
	}
	
	public void setMachineTO(MachineTO machineTO) {
	
		this.machineTO = machineTO;
	}
	
	public void setMapId(int mapId) {
	
		this.mapId = mapId;
	}
	
	public void setMemory(String memory) {
	
		this.memory = memory;
	}
	
	public void setModel(String model) {
	
		this.model = model;
	}
	
	public void setModifiedbyDate(Date modifiedbyDate) {
	
		this.modifiedbyDate = modifiedbyDate;
	}
	
	public void setOperatingSystemName(String operatingSystemName) {
	
		this.operatingSystemName = operatingSystemName;
	}
	
	public void setOsType(String osType) {
	
		this.osType = osType;
	}
	
	public void setPatchLevel(String patchLevel) {
	
		this.patchLevel = patchLevel;
	}
	
	public void setPlatformName(PlatformMasterTO platformName) {
	
		this.platformName = platformName;
	}
	
	public void setProcessor(String processor) {
	
		this.processor = processor;
	}
	
	public void setProjectId(Long projectId) {
	
		this.projectId = projectId;
	}
	
	public void setPurchasedDate(Date purchasedDate) {
	
		this.purchasedDate = purchasedDate;
	}
	
	public void setReceivedDate(Date receivedDate) {
	
		this.receivedDate = receivedDate;
	}
	
	public void setRegion(String region) {
	
		this.region = region;
	}
	
	public void setRemarks(String remarks) {
	
		this.remarks = remarks;
	}
	
	public void setRoom(String room) {
	
		this.room = room;
	}
	
	public void setSel1(String sel1) {
	
		this.sel1 = sel1;
	}
	
	public void setSel2(String sel2) {
	
		this.sel2 = sel2;
	}
	
	public void setSelectedPlatformName(Long selectedPlatformName) {
	
		this.selectedPlatformName = selectedPlatformName;
	}
	
	public void setSelectedShare(Long selectedShare) {
	
		this.selectedShare = selectedShare;
	}
	
	public void setSelectedStatus(Long selectedStatus) {
	
		this.selectedStatus = selectedStatus;
	}
	
	public void setSelectedTemplate(Long selectedTemplate) {
	
		this.selectedTemplate = selectedTemplate;
	}
	
	public void setServerTO(CIServerTO serverTO) {
	
		this.serverTO = serverTO;
	}
	
	public void setSoftware(SoftwareTO software) {
	
		this.software = software;
	}
	
	public void setSoftwareName(String softwareName) {
	
		this.softwareName = softwareName;
	}
	
	public void setStatus(Long status) {
	
		this.status = status;
	}
	
	public void setStatusTO(StatusTO statusTO) {
	
		this.statusTO = statusTO;
	}
	
	public void setStatusTO1(StatusTO statusTO1) {
	
		this.statusTO1 = statusTO1;
	}
	
	public void setStorage(String storage) {
	
		this.storage = storage;
	}
	
	public void setStorageTier(String storageTier) {
	
		this.storageTier = storageTier;
	}
	
	public void setSwapMemory(String swapMemory) {
	
		this.swapMemory = swapMemory;
	}
	
	public void setSystemType(String systemType) {
	
		this.systemType = systemType;
	}
	
	public void setTemplateProperties(Set<TemplatePropertyTO> templateProperties) {
	
		this.templateProperties = templateProperties;
	}
	
	public void setToDate(Date toDate) {
	
		this.toDate = toDate;
	}
	
	public void setValidate(boolean validate) {
	
		this.validate = validate;
	}
}
