package com.framework.to;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ReleaseDashBoradTo implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5485884258740742063L;
	private String chartImage;
	private String areaTagValue;
	private String chartImageEnv;
	private String areaTagValueEnv;
	private String chartImageRelease;
	private String areaTagValueRelease;
	private String chartImageWorkFlow;
	private String areaTagValueWorkFlow;
	private String applicationValue;
	private String environmentValue;
	private List releaseList = new ArrayList(0);
	private List serviceList = new ArrayList(0);
	private String fileName;
	private Map<String, Long> pieDataMapReserv;
	private Map<String, Long> pieDataMapEnv;
	
	public ReleaseDashBoradTo() {
	
		/* No implementation required at the moment. Method for future use. */
	}
	
	public String getApplicationValue() {
	
		return applicationValue;
	}
	
	public String getAreaTagValue() {
	
		return areaTagValue;
	}
	
	public String getAreaTagValueEnv() {
	
		return areaTagValueEnv;
	}
	
	public String getAreaTagValueRelease() {
	
		return areaTagValueRelease;
	}
	
	public String getAreaTagValueWorkFlow() {
	
		return areaTagValueWorkFlow;
	}
	
	public String getChartImage() {
	
		return chartImage;
	}
	
	public String getChartImageEnv() {
	
		return chartImageEnv;
	}
	
	public String getChartImageRelease() {
	
		return chartImageRelease;
	}
	
	public String getChartImageWorkFlow() {
	
		return chartImageWorkFlow;
	}
	
	public String getEnvironmentValue() {
	
		return environmentValue;
	}
	
	public String getFileName() {
	
		return fileName;
	}
	
	public Map<String, Long> getPieDataMapEnv() {
	
		return pieDataMapEnv;
	}
	
	public Map<String, Long> getPieDataMapReserv() {
	
		return pieDataMapReserv;
	}
	
	public List getReleaseList() {
	
		return releaseList;
	}
	
	public List getServiceList() {
	
		return serviceList;
	}
	
	public void setApplicationValue(String applicationValue) {
	
		this.applicationValue = applicationValue;
	}
	
	public void setAreaTagValue(String areaTagValue) {
	
		this.areaTagValue = areaTagValue;
	}
	
	public void setAreaTagValueEnv(String areaTagValueEnv) {
	
		this.areaTagValueEnv = areaTagValueEnv;
	}
	
	public void setAreaTagValueRelease(String areaTagValueRelease) {
	
		this.areaTagValueRelease = areaTagValueRelease;
	}
	
	public void setAreaTagValueWorkFlow(String areaTagValueWorkFlow) {
	
		this.areaTagValueWorkFlow = areaTagValueWorkFlow;
	}
	
	public void setChartImage(String chartImage) {
	
		this.chartImage = chartImage;
	}
	
	public void setChartImageEnv(String chartImageEnv) {
	
		this.chartImageEnv = chartImageEnv;
	}
	
	public void setChartImageRelease(String chartImageRelease) {
	
		this.chartImageRelease = chartImageRelease;
	}
	
	public void setChartImageWorkFlow(String chartImageWorkFlow) {
	
		this.chartImageWorkFlow = chartImageWorkFlow;
	}
	
	public void setEnvironmentValue(String environmentValue) {
	
		this.environmentValue = environmentValue;
	}
	
	public void setFileName(String fileName) {
	
		this.fileName = fileName;
	}
	
	public void setPieDataMapEnv(Map<String, Long> pieDataMapEnv) {
	
		this.pieDataMapEnv = pieDataMapEnv;
	}
	
	public void setPieDataMapReserv(Map<String, Long> pieDataMapReserv) {
	
		this.pieDataMapReserv = pieDataMapReserv;
	}
	
	public void setReleaseList(List releaseList) {
	
		this.releaseList = releaseList;
	}
	
	public void setServiceList(List serviceList) {
	
		this.serviceList = serviceList;
	}
}
