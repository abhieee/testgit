package com.framework.to;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class DefectsTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4140412545620174223L;
	private List<DefectsTO> defectsList = null;
	private String TestPhase;
	private String System;
	private String Status;
	private String Severity;
	private String Project;
	private String Priority;
	private String Environment;
	private String Domain;
	private Date DetectedonDate;
	private Date DetectedinRelease;
	private String DetectedBy;
	private Long DefectID;
	private String DateFound;
	private String AssignedTo;
	
	public String getAssignedTo() {
	
		return AssignedTo;
	}
	
	public String getDateFound() {
	
		return DateFound;
	}
	
	public Long getDefectID() {
	
		return DefectID;
	}
	
	public List<DefectsTO> getDefectsList() {
	
		return defectsList;
	}
	
	public String getDetectedBy() {
	
		return DetectedBy;
	}
	
	public Date getDetectedinRelease() {
	
		return DetectedinRelease;
	}
	
	public Date getDetectedonDate() {
	
		return DetectedonDate;
	}
	
	public String getDomain() {
	
		return Domain;
	}
	
	public String getEnvironment() {
	
		return Environment;
	}
	
	public String getPriority() {
	
		return Priority;
	}
	
	public String getProject() {
	
		return Project;
	}
	
	public String getSeverity() {
	
		return Severity;
	}
	
	public String getStatus() {
	
		return Status;
	}
	
	public String getSystem() {
	
		return System;
	}
	
	public String getTestPhase() {
	
		return TestPhase;
	}
	
	public void setAssignedTo(String assignedTo) {
	
		AssignedTo = assignedTo;
	}
	
	public void setDateFound(String dateFound) {
	
		DateFound = dateFound;
	}
	
	public void setDefectID(Long defectID) {
	
		DefectID = defectID;
	}
	
	public void setDefectsList(List<DefectsTO> defectsList) {
	
		this.defectsList = defectsList;
	}
	
	public void setDetectedBy(String detectedBy) {
	
		DetectedBy = detectedBy;
	}
	
	public void setDetectedinRelease(Date detectedinRelease) {
	
		DetectedinRelease = detectedinRelease;
	}
	
	public void setDetectedonDate(Date detectedonDate) {
	
		DetectedonDate = detectedonDate;
	}
	
	public void setDomain(String domain) {
	
		Domain = domain;
	}
	
	public void setEnvironment(String environment) {
	
		Environment = environment;
	}
	
	public void setPriority(String priority) {
	
		Priority = priority;
	}
	
	public void setProject(String project) {
	
		Project = project;
	}
	
	public void setSeverity(String severity) {
	
		Severity = severity;
	}
	
	public void setStatus(String status) {
	
		Status = status;
	}
	
	public void setSystem(String system) {
	
		System = system;
	}
	
	public void setTestPhase(String testPhase) {
	
		TestPhase = testPhase;
	}
}
