/**
 *
 */
package com.framework.to;

import com.framework.udeploy.to.UdeployProcess;

/**
 * @author 737070
 */
public class UdeployTaskMappingTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3155912565582010848L;
	private UdeployProcess udeployProcess;
	private long taskId;
	private TaskManagementTO taskManagementTO;
	private long processOrder;
	
	public TaskManagementTO getTaskManagementTO() {
	
		return taskManagementTO;
	}
	
	public void setTaskManagementTO(TaskManagementTO taskManagementTO) {
	
		this.taskManagementTO = taskManagementTO;
	}
	
	public long getProcessOrder() {
	
		return processOrder;
	}
	
	public void setProcessOrder(long processOrder) {
	
		this.processOrder = processOrder;
	}
	
	public UdeployProcess getUdeployProcess() {
	
		return udeployProcess;
	}
	
	public void setUdeployProcess(UdeployProcess udeployProcess) {
	
		this.udeployProcess = udeployProcess;
	}
	
	public long getTaskId() {
	
		return taskId;
	}
	
	public void setTaskId(long taskId) {
	
		this.taskId = taskId;
	}
}
