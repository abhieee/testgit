package com.framework.to;

import java.io.Serializable;
import java.util.List;

public class TestExecutionDetailsReportVO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1899252553283698505L;
	private String testcasename;
	private String status;
	private String totalTest;
	private String skipped;
	private String passed;
	private String failed;
	private List<PieChartReportVO> lPieChartVO;
	
	public String getFailed() {
	
		return failed;
	}
	
	public List<PieChartReportVO> getlPieChartVO() {
	
		return lPieChartVO;
	}
	
	public String getPassed() {
	
		return passed;
	}
	
	public String getSkipped() {
	
		return skipped;
	}
	
	public String getStatus() {
	
		return status;
	}
	
	public String getTestcasename() {
	
		return testcasename;
	}
	
	public String getTotalTest() {
	
		return totalTest;
	}
	
	public void setFailed(String failed) {
	
		this.failed = failed;
	}
	
	public void setlPieChartVO(List<PieChartReportVO> lPieChartVO) {
	
		this.lPieChartVO = lPieChartVO;
	}
	
	public void setPassed(String passed) {
	
		this.passed = passed;
	}
	
	public void setSkipped(String skipped) {
	
		this.skipped = skipped;
	}
	
	public void setStatus(String status) {
	
		this.status = status;
	}
	
	public void setTestcasename(String testcasename) {
	
		this.testcasename = testcasename;
	}
	
	public void setTotalTest(String totalTest) {
	
		this.totalTest = totalTest;
	}
}
