package com.framework.to;

import java.io.Serializable;

public class UserBusinessUnitTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private UserTO user;
	private Long clientId;
	private Long id;
	private Long userId;
	private String name;
	
	public Long getClientId() {
	
		return clientId;
	}
	
	public Long getId() {
	
		return id;
	}
	
	public String getName() {
	
		return name;
	}
	
	public UserTO getUser() {
	
		return user;
	}
	
	public Long getUserId() {
	
		return userId;
	}
	
	public void setClientId(Long clientId) {
	
		this.clientId = clientId;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setName(String name) {
	
		this.name = name;
	}
	
	public void setUser(UserTO user) {
	
		this.user = user;
	}
	
	public void setUserId(Long userId) {
	
		this.userId = userId;
	}
}
