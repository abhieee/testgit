package com.framework.to;

import java.io.Serializable;
import java.util.List;

public class NetraNolioProcessParameterMappingTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1516928856449073918L;
	private Long id;
	private long selectedNolioProcessId;
	private long parameterId;
	private long netraParameterId;
	private String parameterPathName;
	private String label;
	private List<NetraParametersTO> netraParametersTOList;
	
	public Long getId() {
	
		return id;
	}
	
	public String getLabel() {
	
		return label;
	}
	
	public long getNetraParameterId() {
	
		return netraParameterId;
	}
	
	public List<NetraParametersTO> getNetraParametersTOList() {
	
		return netraParametersTOList;
	}
	
	public long getParameterId() {
	
		return parameterId;
	}
	
	public String getParameterPathName() {
	
		return parameterPathName;
	}
	
	public long getSelectedNolioProcessId() {
	
		return selectedNolioProcessId;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setLabel(String label) {
	
		this.label = label;
	}
	
	public void setNetraParameterId(long netraParameterId) {
	
		this.netraParameterId = netraParameterId;
	}
	
	public void setNetraParametersTOList(List<NetraParametersTO> netraParametersTOList) {
	
		this.netraParametersTOList = netraParametersTOList;
	}
	
	public void setParameterId(long parameterId) {
	
		this.parameterId = parameterId;
	}
	
	public void setParameterPathName(String parameterPathName) {
	
		this.parameterPathName = parameterPathName;
	}
	
	public void setSelectedNolioProcessId(long selectedNolioProcessId) {
	
		this.selectedNolioProcessId = selectedNolioProcessId;
	}
}
