package com.framework.to;

public class TestingPhase_InvTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -372635974271458682L;
	private String testingPhase;
	
	public String getTestingPhase() {
	
		return testingPhase;
	}
	
	public void setTestingPhase(String testingPhase) {
	
		this.testingPhase = testingPhase;
	}
}
