package com.framework.to;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.apache.commons.collections.map.HashedMap;
import com.framework.nolio.to.NolioProcessParametersTO;

public class ApplicationProfileDetailsTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 9111505333229053880L;
	private String machineTyp;
	private String harwareName;
	private Long mappedSoftwareId;
	private Long hardwareId;
	private List<Long> softwareId = new ArrayList<Long>();
	private Long profileId;
	private Set<ReservationTO> reservationses = new HashSet<ReservationTO>(0);
	private String softwares;
	private List<SoftwareTO> softwareList = new ArrayList<SoftwareTO>();
	private Long platformId;
	private String platformName;
	private ApplicationProfileTO profile;
	private Long serverGroup;
	private HardwareTO hardware;
	private String activityId;
	private String activityName;
	private SoftwareconfigTO softwareConfig;
	private Long oldAppProDetId;
	private boolean flag = false;
	private Long bflag;
	private String serverName;
	private String selectedIPAddress;
	private Map<Long, List<NolioProcessParametersTO>> softwarePropertiesMapping = new HashedMap();
	private Set<ApplicationProfileSoftwareParamertsTO> applicationProfileSoftwareParamertsTOs = new HashSet<ApplicationProfileSoftwareParamertsTO>(0);
	private MachineTO machine;
	private Long machineId;
	private String machineName;
	private String serverGroupNumber;
	private Long existingMachineId;
	private Long existingPlatformId;
	private Long machineTemplateId;
	private Long platformTemplateId;
	private String existingMachineFlag;
	private String installRequired;
	private String existingMachineIP;
	private List<String> ipList = new ArrayList<String>(0);
	
	public String getActivityId() {
	
		return activityId;
	}
	
	public String getActivityName() {
	
		return activityName;
	}
	
	public Set<ApplicationProfileSoftwareParamertsTO> getApplicationProfileSoftwareParamertsTOs() {
	
		return applicationProfileSoftwareParamertsTOs;
	}
	
	public Long getBflag() {
	
		return bflag;
	}
	
	public String getExistingMachineFlag() {
	
		return existingMachineFlag;
	}
	
	public Long getExistingMachineId() {
	
		return existingMachineId;
	}
	
	public String getExistingMachineIP() {
	
		return existingMachineIP;
	}
	
	public Long getExistingPlatformId() {
	
		return existingPlatformId;
	}
	
	public HardwareTO getHardware() {
	
		return hardware;
	}
	
	public Long getHardwareId() {
	
		return hardwareId;
	}
	
	public String getHarwareName() {
	
		return harwareName;
	}
	
	public String getInstallRequired() {
	
		return installRequired;
	}
	
	public List<String> getIpList() {
	
		return ipList;
	}
	
	public MachineTO getMachine() {
	
		return machine;
	}
	
	public Long getMachineId() {
	
		return machineId;
	}
	
	public String getMachineName() {
	
		return machineName;
	}
	
	public Long getMachineTemplateId() {
	
		return machineTemplateId;
	}
	
	public String getMachineTyp() {
	
		return machineTyp;
	}
	
	public Long getMappedSoftwareId() {
	
		return mappedSoftwareId;
	}
	
	public Long getOldAppProDetId() {
	
		return oldAppProDetId;
	}
	
	public Long getPlatformId() {
	
		return platformId;
	}
	
	public String getPlatformName() {
	
		return platformName;
	}
	
	public Long getPlatformTemplateId() {
	
		return platformTemplateId;
	}
	
	public ApplicationProfileTO getProfile() {
	
		return profile;
	}
	
	public Long getProfileId() {
	
		return profileId;
	}
	
	public Set<ReservationTO> getReservationses() {
	
		return reservationses;
	}
	
	public String getSelectedIPAddress() {
	
		return selectedIPAddress;
	}
	
	public Long getServerGroup() {
	
		return serverGroup;
	}
	
	public String getServerGroupNumber() {
	
		return serverGroupNumber;
	}
	
	public String getServerName() {
	
		return serverName;
	}
	
	public SoftwareconfigTO getSoftwareConfig() {
	
		return softwareConfig;
	}
	
	public List<Long> getSoftwareId() {
	
		return softwareId;
	}
	
	public List<SoftwareTO> getSoftwareList() {
	
		return softwareList;
	}
	
	public Map<Long, List<NolioProcessParametersTO>> getSoftwarePropertiesMapping() {
	
		return softwarePropertiesMapping;
	}
	
	public String getSoftwares() {
	
		return softwares;
	}
	
	public boolean isFlag() {
	
		return flag;
	}
	
	public void setActivityId(String activityId) {
	
		this.activityId = activityId;
	}
	
	public void setActivityName(String activityName) {
	
		this.activityName = activityName;
	}
	
	public void setApplicationProfileSoftwareParamertsTOs(Set<ApplicationProfileSoftwareParamertsTO> applicationProfileSoftwareParamertsTOs) {
	
		this.applicationProfileSoftwareParamertsTOs = applicationProfileSoftwareParamertsTOs;
	}
	
	public void setBflag(Long bflag) {
	
		this.bflag = bflag;
	}
	
	public void setExistingMachineFlag(String existingMachineFlag) {
	
		this.existingMachineFlag = existingMachineFlag;
	}
	
	public void setExistingMachineId(Long existingMachineId) {
	
		this.existingMachineId = existingMachineId;
	}
	
	public void setExistingMachineIP(String existingMachineIP) {
	
		this.existingMachineIP = existingMachineIP;
	}
	
	public void setExistingPlatformId(Long existingPlatformId) {
	
		this.existingPlatformId = existingPlatformId;
	}
	
	public void setFlag(boolean flag) {
	
		this.flag = flag;
	}
	
	public void setHardware(HardwareTO hardware) {
	
		this.hardware = hardware;
	}
	
	public void setHardwareId(Long hardwareId) {
	
		this.hardwareId = hardwareId;
	}
	
	public void setHarwareName(String harwareName) {
	
		this.harwareName = harwareName;
	}
	
	public void setInstallRequired(String installRequired) {
	
		this.installRequired = installRequired;
	}
	
	public void setIpList(List<String> ipList) {
	
		this.ipList = ipList;
	}
	
	public void setMachine(MachineTO machine) {
	
		this.machine = machine;
	}
	
	public void setMachineId(Long machineId) {
	
		this.machineId = machineId;
	}
	
	public void setMachineName(String machineName) {
	
		this.machineName = machineName;
	}
	
	public void setMachineTemplateId(Long machineTemplateId) {
	
		this.machineTemplateId = machineTemplateId;
	}
	
	public void setMachineTyp(String machineTyp) {
	
		this.machineTyp = machineTyp;
	}
	
	public void setMappedSoftwareId(Long mappedSoftwareId) {
	
		this.mappedSoftwareId = mappedSoftwareId;
	}
	
	public void setOldAppProDetId(Long oldAppProDetId) {
	
		this.oldAppProDetId = oldAppProDetId;
	}
	
	public void setPlatformId(Long platformId) {
	
		this.platformId = platformId;
	}
	
	public void setPlatformName(String platformName) {
	
		this.platformName = platformName;
	}
	
	public void setPlatformTemplateId(Long platformTemplateId) {
	
		this.platformTemplateId = platformTemplateId;
	}
	
	public void setProfile(ApplicationProfileTO profile) {
	
		this.profile = profile;
	}
	
	public void setProfileId(Long profileId) {
	
		this.profileId = profileId;
	}
	
	public void setReservationses(Set<ReservationTO> reservationses) {
	
		this.reservationses = reservationses;
	}
	
	public void setSelectedIPAddress(String selectedIPAddress) {
	
		this.selectedIPAddress = selectedIPAddress;
	}
	
	public void setServerGroup(Long serverGroup) {
	
		this.serverGroup = serverGroup;
	}
	
	public void setServerGroupNumber(String serverGroupNumber) {
	
		this.serverGroupNumber = serverGroupNumber;
	}
	
	public void setServerName(String serverName) {
	
		this.serverName = serverName;
	}
	
	public void setSoftwareConfig(SoftwareconfigTO softwareConfig) {
	
		this.softwareConfig = softwareConfig;
	}
	
	public void setSoftwareId(List<Long> softwareId) {
	
		this.softwareId = softwareId;
	}
	
	public void setSoftwareList(List<SoftwareTO> softwareList) {
	
		this.softwareList = softwareList;
	}
	
	public void setSoftwarePropertiesMapping(Map<Long, List<NolioProcessParametersTO>> softwarePropertiesMapping) {
	
		this.softwarePropertiesMapping = softwarePropertiesMapping;
	}
	
	public void setSoftwares(String softwares) {
	
		this.softwares = softwares;
	}
}
