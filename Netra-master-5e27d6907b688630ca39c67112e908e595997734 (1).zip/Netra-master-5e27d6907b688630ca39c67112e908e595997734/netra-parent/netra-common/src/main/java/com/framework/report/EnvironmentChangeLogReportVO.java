package com.framework.report;

import java.io.Serializable;

public class EnvironmentChangeLogReportVO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String bu_name = null;
	private String env_name = null;
	private String vm_name = null;
	private String vm_ip = null;
	private String sw_name = null;
	private String app_name = null;
	private String proj_name = null;
	private String release_name = null;
	private String release_desc = null;
	private String release_time = null;
	private String initiated_by = null;
	
	public EnvironmentChangeLogReportVO() {
	
		/* No implementation required at the moment. Method for future use. */
	}
	
	public EnvironmentChangeLogReportVO(String bu_name, String env_name, String vm_name, String vm_ip, String sw_name, String app_name, String proj_name, String release_name, String release_desc, String release_time, String initiated_by) {
	
		this.bu_name = bu_name;
		this.env_name = env_name;
		this.vm_name = vm_name;
		this.vm_ip = vm_ip;
		this.sw_name = sw_name;
		this.app_name = app_name;
		this.proj_name = proj_name;
		this.release_name = release_name;
		this.release_desc = release_desc;
		this.release_time = release_time;
		this.initiated_by = initiated_by;
	}
	
	public String getBu_name() {
	
		return bu_name;
	}
	
	public void setBu_name(String bu_name) {
	
		this.bu_name = bu_name;
	}
	
	public String getEnv_name() {
	
		return env_name;
	}
	
	public void setEnv_name(String env_name) {
	
		this.env_name = env_name;
	}
	
	public String getVm_name() {
	
		return vm_name;
	}
	
	public void setVm_name(String vm_name) {
	
		this.vm_name = vm_name;
	}
	
	public String getVm_ip() {
	
		return vm_ip;
	}
	
	public void setVm_ip(String vm_ip) {
	
		this.vm_ip = vm_ip;
	}
	
	public String getSw_name() {
	
		return sw_name;
	}
	
	public void setSw_name(String sw_name) {
	
		this.sw_name = sw_name;
	}
	
	public String getApp_name() {
	
		return app_name;
	}
	
	public void setApp_name(String app_name) {
	
		this.app_name = app_name;
	}
	
	public String getProj_name() {
	
		return proj_name;
	}
	
	public void setProj_name(String proj_name) {
	
		this.proj_name = proj_name;
	}
	
	public String getRelease_name() {
	
		return release_name;
	}
	
	public void setRelease_name(String release_name) {
	
		this.release_name = release_name;
	}
	
	public String getRelease_desc() {
	
		return release_desc;
	}
	
	public void setRelease_desc(String release_desc) {
	
		this.release_desc = release_desc;
	}
	
	public String getRelease_time() {
	
		return release_time;
	}
	
	public void setRelease_time(String release_time) {
	
		this.release_time = release_time;
	}
	
	public String getInitiated_by() {
	
		return initiated_by;
	}
	
	public void setInitiated_by(String initiated_by) {
	
		this.initiated_by = initiated_by;
	}
}
