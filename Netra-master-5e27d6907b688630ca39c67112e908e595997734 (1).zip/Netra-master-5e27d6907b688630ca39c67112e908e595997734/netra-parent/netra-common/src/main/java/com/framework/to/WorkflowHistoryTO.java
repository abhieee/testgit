package com.framework.to;

import java.io.Serializable;
import java.util.Date;

public class WorkflowHistoryTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7340030228365080887L;
	private Long wf_history_id;
	private Long wf_id;
	private Long clientId;
	private Long projectId;
	private Long levelOrder;
	private Long statusChangedTo;
	private Long statusChangedByRole;
	private String statusChangedByRoleName;
	private String statusChangedByName;
	private Long statusChangedById;
	private Date statusChangedDate;
	private String comments;
	private Long createdBy;
	private Date createdDate;
	private Date lastUpdateDate;
	private Long lastUpdateBy;
	private String messageForUser;
	private Long serialNo;
	private Long applicationId;
	private Long environmentId;
	private Long wf_current_id;
	private UserTO userTO = new UserTO();
	private WorkFlowTO workFlowTO = new WorkFlowTO();
	private WorkflowStatusTO wfStatusTO = new WorkflowStatusTO();
	private WorkflowCurrentTO workflowCurrentTO = new WorkflowCurrentTO();
	private String statusName;
	private String action_performed_by_role_name;
	
	public String getAction_performed_by_role_name() {
	
		return action_performed_by_role_name;
	}
	
	public void setAction_performed_by_role_name(String action_performed_by_role_name) {
	
		this.action_performed_by_role_name = action_performed_by_role_name;
	}
	
	public Long getAction_performed_by() {
	
		return action_performed_by;
	}
	
	public void setAction_performed_by(Long action_performed_by) {
	
		this.action_performed_by = action_performed_by;
	}
	
	public Long getAction_performed_by_role() {
	
		return action_performed_by_role;
	}
	
	public void setAction_performed_by_role(Long action_performed_by_role) {
	
		this.action_performed_by_role = action_performed_by_role;
	}
	
	private Long action_performed_by;
	private Long action_performed_by_role;
	
	public String getAction_performed_by_name() {
	
		return action_performed_by_name;
	}
	
	public void setAction_performed_by_name(String action_performed_by_name) {
	
		this.action_performed_by_name = action_performed_by_name;
	}
	
	private String action_performed_by_name;
	
	public Long getApplicationId() {
	
		return applicationId;
	}
	
	public Long getClientId() {
	
		return clientId;
	}
	
	public String getComments() {
	
		return comments;
	}
	
	public Long getCreatedBy() {
	
		return createdBy;
	}
	
	public Date getCreatedDate() {
	
		return createdDate;
	}
	
	public Long getEnvironmentId() {
	
		return environmentId;
	}
	
	public Long getLastUpdateBy() {
	
		return lastUpdateBy;
	}
	
	public Date getLastUpdateDate() {
	
		return lastUpdateDate;
	}
	
	public Long getLevelOrder() {
	
		return levelOrder;
	}
	
	public String getMessageForUser() {
	
		return messageForUser;
	}
	
	public Long getProjectId() {
	
		return projectId;
	}
	
	public Long getSerialNo() {
	
		return serialNo;
	}
	
	public Long getStatusChangedById() {
	
		return statusChangedById;
	}
	
	public String getStatusChangedByName() {
	
		return statusChangedByName;
	}
	
	public Long getStatusChangedByRole() {
	
		return statusChangedByRole;
	}
	
	public String getStatusChangedByRoleName() {
	
		return statusChangedByRoleName;
	}
	
	public Date getStatusChangedDate() {
	
		return statusChangedDate;
	}
	
	public Long getStatusChangedTo() {
	
		return statusChangedTo;
	}
	
	public String getStatusName() {
	
		return statusName;
	}
	
	public UserTO getUserTO() {
	
		return userTO;
	}
	
	public Long getWf_current_id() {
	
		return wf_current_id;
	}
	
	public Long getWf_history_id() {
	
		return wf_history_id;
	}
	
	public Long getWf_id() {
	
		return wf_id;
	}
	
	public WorkflowStatusTO getWfStatusTO() {
	
		return wfStatusTO;
	}
	
	public WorkflowCurrentTO getWorkflowCurrentTO() {
	
		return workflowCurrentTO;
	}
	
	public WorkFlowTO getWorkFlowTO() {
	
		return workFlowTO;
	}
	
	public void setApplicationId(Long applicationId) {
	
		this.applicationId = applicationId;
	}
	
	public void setClientId(Long clientId) {
	
		this.clientId = clientId;
	}
	
	public void setComments(String comments) {
	
		this.comments = comments;
	}
	
	public void setCreatedBy(Long createdBy) {
	
		this.createdBy = createdBy;
	}
	
	public void setCreatedDate(Date createdDate) {
	
		this.createdDate = createdDate;
	}
	
	public void setEnvironmentId(Long environmentId) {
	
		this.environmentId = environmentId;
	}
	
	public void setLastUpdateBy(Long lastUpdateBy) {
	
		this.lastUpdateBy = lastUpdateBy;
	}
	
	public void setLastUpdateDate(Date lastUpdateDate) {
	
		this.lastUpdateDate = lastUpdateDate;
	}
	
	public void setLevelOrder(Long levelOrder) {
	
		this.levelOrder = levelOrder;
	}
	
	public void setMessageForUser(String messageForUser) {
	
		this.messageForUser = messageForUser;
	}
	
	public void setProjectId(Long projectId) {
	
		this.projectId = projectId;
	}
	
	public void setSerialNo(Long serialNo) {
	
		this.serialNo = serialNo;
	}
	
	public void setStatusChangedById(Long statusChangedById) {
	
		this.statusChangedById = statusChangedById;
	}
	
	public void setStatusChangedByName(String statusChangedByName) {
	
		this.statusChangedByName = statusChangedByName;
	}
	
	public void setStatusChangedByRole(Long statusChangedByRole) {
	
		this.statusChangedByRole = statusChangedByRole;
	}
	
	public void setStatusChangedByRoleName(String statusChangedByRoleName) {
	
		this.statusChangedByRoleName = statusChangedByRoleName;
	}
	
	public void setStatusChangedDate(Date statusChangedDate) {
	
		this.statusChangedDate = statusChangedDate;
	}
	
	public void setStatusChangedTo(Long statusChangedTo) {
	
		this.statusChangedTo = statusChangedTo;
	}
	
	public void setStatusName(String statusName) {
	
		this.statusName = statusName;
	}
	
	public void setUserTO(UserTO userTO) {
	
		this.userTO = userTO;
	}
	
	public void setWf_current_id(Long wf_current_id) {
	
		this.wf_current_id = wf_current_id;
	}
	
	public void setWf_history_id(Long wf_history_id) {
	
		this.wf_history_id = wf_history_id;
	}
	
	public void setWf_id(Long wf_id) {
	
		this.wf_id = wf_id;
	}
	
	public void setWfStatusTO(WorkflowStatusTO wfStatusTO) {
	
		this.wfStatusTO = wfStatusTO;
	}
	
	public void setWorkflowCurrentTO(WorkflowCurrentTO workflowCurrentTO) {
	
		this.workflowCurrentTO = workflowCurrentTO;
	}
	
	public void setWorkFlowTO(WorkFlowTO workFlowTO) {
	
		this.workFlowTO = workFlowTO;
	}
}
