package com.framework.to;

import java.io.Serializable;

public class MachineTemplateBareMetalTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3931377633555095581L;
	private Long id;
	private Long hardDiskSize;
	private String diskMode;
	private String selectedFamilyType;
	private String selectedDistribution;
	private String vmAjaxRequest;
	private String selectedVersion;
	private String selectedPack;
	private String selectedArchitecture;
	private String selectedDiskMode;
	private String name;
	private String isoPath;
	private String username;
	private String password;
	private MachineTemplateTO machineTemplateTO;
	
	/**
	 * @return the diskMode
	 */
	public String getDiskMode() {
	
		return diskMode;
	}
	
	/**
	 * @return the hardDiskSize
	 */
	public Long getHardDiskSize() {
	
		return hardDiskSize;
	}
	
	/**
	 * @return the id
	 */
	public Long getId() {
	
		return id;
	}
	
	public String getIsoPath() {
	
		return isoPath;
	}
	
	/**
	 * @return the machineTemplateTO
	 */
	public MachineTemplateTO getMachineTemplateTO() {
	
		return machineTemplateTO;
	}
	
	public String getName() {
	
		return name;
	}
	
	public String getPassword() {
	
		return password;
	}
	
	public String getSelectedArchitecture() {
	
		return selectedArchitecture;
	}
	
	public String getSelectedDiskMode() {
	
		return selectedDiskMode;
	}
	
	public String getSelectedDistribution() {
	
		return selectedDistribution;
	}
	
	public String getSelectedFamilyType() {
	
		return selectedFamilyType;
	}
	
	public String getSelectedPack() {
	
		return selectedPack;
	}
	
	public String getSelectedVersion() {
	
		return selectedVersion;
	}
	
	public String getUsername() {
	
		return username;
	}
	
	public String getVmAjaxRequest() {
	
		return vmAjaxRequest;
	}
	
	/**
	 * @param diskMode
	 *                the diskMode to set
	 */
	public void setDiskMode(String diskMode) {
	
		this.diskMode = diskMode;
	}
	
	/**
	 * @param hardDiskSize
	 *                the hardDiskSize to set
	 */
	public void setHardDiskSize(Long hardDiskSize) {
	
		this.hardDiskSize = hardDiskSize;
	}
	
	/**
	 * @param id
	 *                the id to set
	 */
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setIsoPath(String isoPath) {
	
		this.isoPath = isoPath;
	}
	
	/**
	 * @param machineTemplateTO
	 *                the machineTemplateTO to set
	 */
	public void setMachineTemplateTO(MachineTemplateTO machineTemplateTO) {
	
		this.machineTemplateTO = machineTemplateTO;
	}
	
	public void setName(String name) {
	
		this.name = name;
	}
	
	public void setPassword(String password) {
	
		this.password = password;
	}
	
	public void setSelectedArchitecture(String selectedArchitecture) {
	
		this.selectedArchitecture = selectedArchitecture;
	}
	
	public void setSelectedDiskMode(String selectedDiskMode) {
	
		this.selectedDiskMode = selectedDiskMode;
	}
	
	public void setSelectedDistribution(String selectedDistribution) {
	
		this.selectedDistribution = selectedDistribution;
	}
	
	public void setSelectedFamilyType(String selectedFamilyType) {
	
		this.selectedFamilyType = selectedFamilyType;
	}
	
	public void setSelectedPack(String selectedPack) {
	
		this.selectedPack = selectedPack;
	}
	
	public void setSelectedVersion(String selectedVersion) {
	
		this.selectedVersion = selectedVersion;
	}
	
	public void setUsername(String username) {
	
		this.username = username;
	}
	
	public void setVmAjaxRequest(String vmAjaxRequest) {
	
		this.vmAjaxRequest = vmAjaxRequest;
	}
}
