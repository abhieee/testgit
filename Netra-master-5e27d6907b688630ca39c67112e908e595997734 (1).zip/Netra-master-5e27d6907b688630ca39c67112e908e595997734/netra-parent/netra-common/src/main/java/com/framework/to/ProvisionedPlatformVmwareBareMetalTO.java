package com.framework.to;

import java.io.Serializable;

public class ProvisionedPlatformVmwareBareMetalTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3392042510380227342L;
	private Long id;
	private Long provisionedPlatformId;
	private String isoFilePath;
	
	/**
	 * @return the id
	 */
	public Long getId() {
	
		return id;
	}
	
	/**
	 * @return the isoFilePath
	 */
	public String getIsoFilePath() {
	
		return isoFilePath;
	}
	
	/**
	 * @return the provisionedPlatformId
	 */
	public Long getProvisionedPlatformId() {
	
		return provisionedPlatformId;
	}
	
	/**
	 * @param id
	 *                the id to set
	 */
	public void setId(Long id) {
	
		this.id = id;
	}
	
	/**
	 * @param isoFilePath
	 *                the isoFilePath to set
	 */
	public void setIsoFilePath(String isoFilePath) {
	
		this.isoFilePath = isoFilePath;
	}
	
	/**
	 * @param provisionedPlatformId
	 *                the provisionedPlatformId to set
	 */
	public void setProvisionedPlatformId(Long provisionedPlatformId) {
	
		this.provisionedPlatformId = provisionedPlatformId;
	}
}
