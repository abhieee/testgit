package com.framework.to;

public class TestExecutionResultsDetailsTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -905280540250669049L;
	private Long testExecutionResultId;
	private String testCaseName;
	private String status;
	private Long totalTests;
	private Long skipped;
	private Long failed;
	private Long passed;
	private TestExecutionResultsTO testExecutionResultsTO;
	
	public Long getFailed() {
	
		return failed;
	}
	
	public Long getPassed() {
	
		return passed;
	}
	
	public Long getSkipped() {
	
		return skipped;
	}
	
	public String getStatus() {
	
		return status;
	}
	
	public String getTestCaseName() {
	
		return testCaseName;
	}
	
	public Long getTestExecutionResultId() {
	
		return testExecutionResultId;
	}
	
	public TestExecutionResultsTO getTestExecutionResultsTO() {
	
		return testExecutionResultsTO;
	}
	
	public Long getTotalTests() {
	
		return totalTests;
	}
	
	public void setFailed(Long failed) {
	
		this.failed = failed;
	}
	
	public void setPassed(Long passed) {
	
		this.passed = passed;
	}
	
	public void setSkipped(Long skipped) {
	
		this.skipped = skipped;
	}
	
	public void setStatus(String status) {
	
		this.status = status;
	}
	
	public void setTestCaseName(String testCaseName) {
	
		this.testCaseName = testCaseName;
	}
	
	public void setTestExecutionResultId(Long testExecutionResultId) {
	
		this.testExecutionResultId = testExecutionResultId;
	}
	
	public void setTestExecutionResultsTO(TestExecutionResultsTO testExecutionResultsTO) {
	
		this.testExecutionResultsTO = testExecutionResultsTO;
	}
	
	public void setTotalTests(Long totalTests) {
	
		this.totalTests = totalTests;
	}
}
