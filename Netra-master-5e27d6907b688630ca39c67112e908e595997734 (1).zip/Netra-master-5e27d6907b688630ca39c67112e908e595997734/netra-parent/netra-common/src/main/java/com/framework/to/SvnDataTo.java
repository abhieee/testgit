package com.framework.to;

import java.io.Serializable;

public class SvnDataTo implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6159321423393213397L;
	private long svnId;
	private String headURL;
	private String tags;
	private String userName;
	private String password;
	
	public SvnDataTo() {
	
		/* No implementation required at the moment. Method for future use. */
	}
	
	public String getHeadURL() {
	
		return headURL;
	}
	
	public String getPassword() {
	
		return password;
	}
	
	public long getSvnId() {
	
		return svnId;
	}
	
	public String getTags() {
	
		return tags;
	}
	
	public String getUserName() {
	
		return userName;
	}
	
	public void setHeadURL(String headURL) {
	
		this.headURL = headURL;
	}
	
	public void setPassword(String password) {
	
		this.password = password;
	}
	
	public void setSvnId(long svnId) {
	
		this.svnId = svnId;
	}
	
	public void setTags(String tags) {
	
		this.tags = tags;
	}
	
	public void setUserName(String userName) {
	
		this.userName = userName;
	}
}
