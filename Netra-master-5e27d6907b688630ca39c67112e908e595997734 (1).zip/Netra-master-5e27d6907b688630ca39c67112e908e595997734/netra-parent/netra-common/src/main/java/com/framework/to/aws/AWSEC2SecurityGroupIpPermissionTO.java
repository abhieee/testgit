package com.framework.to.aws;

import java.util.ArrayList;
import java.util.List;
import com.amazonaws.services.ec2.model.IpPermission;

/**
 * @author 459704
 */
public class AWSEC2SecurityGroupIpPermissionTO {
	
	private Integer fromPort;
	private Integer toPort;
	private String ipProtocol;
	private List<String> ipRanges;
	private String ipRangesString;
	
	public AWSEC2SecurityGroupIpPermissionTO() {
	
		ipRanges = new ArrayList<String>();
	}
	
	public AWSEC2SecurityGroupIpPermissionTO(IpPermission permission) {
	
	}
	
	public Integer getFromPort() {
	
		return fromPort;
	}
	
	public String getIpProtocol() {
	
		return ipProtocol;
	}
	
	public List<String> getIpRanges() {
	
		return ipRanges;
	}
	
	public String getIpRangesString() {
	
		return ipRangesString;
	}
	
	public Integer getToPort() {
	
		return toPort;
	}
	
	public void setFromPort(Integer fromPort) {
	
		this.fromPort = fromPort;
	}
	
	public void setIpProtocol(String ipProtocol) {
	
		this.ipProtocol = ipProtocol;
	}
	
	public void setIpRanges(List<String> ipRanges) {
	
		this.ipRanges = ipRanges;
	}
	
	public void setIpRangesString(String ipRangesString) {
	
		this.ipRangesString = ipRangesString;
	}
	
	public void setToPort(Integer toPort) {
	
		this.toPort = toPort;
	}
}
