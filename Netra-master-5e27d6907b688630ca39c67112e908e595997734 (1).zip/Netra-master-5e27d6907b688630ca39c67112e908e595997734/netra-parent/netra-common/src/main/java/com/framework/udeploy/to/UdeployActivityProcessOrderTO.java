package com.framework.udeploy.to;

/**
 * @author 460650
 */
public class UdeployActivityProcessOrderTO {
	
	private long activtyProcessId;
	private UdeployActivitySoftwareMappingTO udeployActivitySoftwareMappingTO;
	private UdeployProcessSoftwareMapping udeployProcessSoftwareMapping;
	private long processOrder;
	
	public long getActivtyProcessId() {
	
		return activtyProcessId;
	}
	
	public long getProcessOrder() {
	
		return processOrder;
	}
	
	public UdeployActivitySoftwareMappingTO getUdeployActivitySoftwareMappingTO() {
	
		return udeployActivitySoftwareMappingTO;
	}
	
	public UdeployProcessSoftwareMapping getUdeployProcessSoftwareMapping() {
	
		return udeployProcessSoftwareMapping;
	}
	
	public void setActivtyProcessId(long activtyProcessId) {
	
		this.activtyProcessId = activtyProcessId;
	}
	
	public void setProcessOrder(long processOrder) {
	
		this.processOrder = processOrder;
	}
	
	public void setUdeployActivitySoftwareMappingTO(UdeployActivitySoftwareMappingTO udeployActivitySoftwareMappingTO) {
	
		this.udeployActivitySoftwareMappingTO = udeployActivitySoftwareMappingTO;
	}
	
	public void setUdeployProcessSoftwareMapping(UdeployProcessSoftwareMapping udeployProcessSoftwareMapping) {
	
		this.udeployProcessSoftwareMapping = udeployProcessSoftwareMapping;
	}
}
