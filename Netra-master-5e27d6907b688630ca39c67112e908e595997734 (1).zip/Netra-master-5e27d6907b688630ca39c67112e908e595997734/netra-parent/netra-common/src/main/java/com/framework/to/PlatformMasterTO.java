package com.framework.to;

public class PlatformMasterTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1376312103815205103L;
	private Long platformId;
	private String platformName;
	private String platformFamily;
	private String architecture;
	private String version;
	private String displayName;
	
	public String getArchitecture() {
	
		return architecture;
	}
	
	public String getDisplayName() {
	
		displayName = platformFamily + " - " + platformName + " " + version + "(" + architecture + ")";
		return displayName;
	}
	
	public String getPlatformFamily() {
	
		return platformFamily;
	}
	
	public Long getPlatformId() {
	
		return platformId;
	}
	
	public String getPlatformName() {
	
		return platformName;
	}
	
	public String getVersion() {
	
		return version;
	}
	
	public void setArchitecture(String architecture) {
	
		this.architecture = architecture;
	}
	
	public void setDisplayName(String displayName) {
	
		this.displayName = displayName;
	}
	
	public void setPlatformFamily(String platformFamily) {
	
		this.platformFamily = platformFamily;
	}
	
	public void setPlatformId(Long platformId) {
	
		this.platformId = platformId;
	}
	
	public void setPlatformName(String platformName) {
	
		this.platformName = platformName;
	}
	
	public void setVersion(String version) {
	
		this.version = version;
	}
}
