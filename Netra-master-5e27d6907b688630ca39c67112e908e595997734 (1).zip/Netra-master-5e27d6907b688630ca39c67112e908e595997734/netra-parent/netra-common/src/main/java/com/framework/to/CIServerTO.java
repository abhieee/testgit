package com.framework.to;

import java.io.Serializable;
import java.util.Date;

public class CIServerTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4065088044331066806L;
	private Long ci_id;
	private String serverName;
	private Long hardwareId;
	private String department;
	private String region;
	private String cityStateCountry;
	private String buildingAddress;
	private String room;
	private String model;
	private String patchLevel;
	private Date purchase_date;
	private Date received_date;
	private Date install_date;
	
	public String getBuildingAddress() {
	
		return buildingAddress;
	}
	
	public Long getCi_id() {
	
		return ci_id;
	}
	
	public String getCityStateCountry() {
	
		return cityStateCountry;
	}
	
	public String getDepartment() {
	
		return department;
	}
	
	public Long getHardwareId() {
	
		return hardwareId;
	}
	
	public Date getInstall_date() {
	
		return install_date;
	}
	
	public String getModel() {
	
		return model;
	}
	
	public String getPatchLevel() {
	
		return patchLevel;
	}
	
	public Date getPurchase_date() {
	
		return purchase_date;
	}
	
	public Date getReceived_date() {
	
		return received_date;
	}
	
	public String getRegion() {
	
		return region;
	}
	
	public String getRoom() {
	
		return room;
	}
	
	public String getServerName() {
	
		return serverName;
	}
	
	public void setBuildingAddress(String buildingAddress) {
	
		this.buildingAddress = buildingAddress;
	}
	
	public void setCi_id(Long ci_id) {
	
		this.ci_id = ci_id;
	}
	
	public void setCityStateCountry(String cityStateCountry) {
	
		this.cityStateCountry = cityStateCountry;
	}
	
	public void setDepartment(String department) {
	
		this.department = department;
	}
	
	public void setHardwareId(Long hardwareId) {
	
		this.hardwareId = hardwareId;
	}
	
	public void setInstall_date(Date install_date) {
	
		this.install_date = install_date;
	}
	
	public void setModel(String model) {
	
		this.model = model;
	}
	
	public void setPatchLevel(String patchLevel) {
	
		this.patchLevel = patchLevel;
	}
	
	public void setPurchase_date(Date purchase_date) {
	
		this.purchase_date = purchase_date;
	}
	
	public void setReceived_date(Date received_date) {
	
		this.received_date = received_date;
	}
	
	public void setRegion(String region) {
	
		this.region = region;
	}
	
	public void setRoom(String room) {
	
		this.room = room;
	}
	
	public void setServerName(String serverName) {
	
		this.serverName = serverName;
	}
}
