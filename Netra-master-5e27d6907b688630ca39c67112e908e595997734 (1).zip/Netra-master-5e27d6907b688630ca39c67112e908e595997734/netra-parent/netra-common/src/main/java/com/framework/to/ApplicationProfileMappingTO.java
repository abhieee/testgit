package com.framework.to;

import java.util.List;

public class ApplicationProfileMappingTO extends NamedEntityTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8434458489288723325L;
	private Long profileId;
	private Long applicationId;
	private ApplicationTO applicationTO;
	private List<Long> definedApplications;
	private ApplicationProfileTO profileTO;
	
	public Long getApplicationId() {
	
		return applicationId;
	}
	
	public ApplicationTO getApplicationTO() {
	
		return applicationTO;
	}
	
	public List<Long> getDefinedApplications() {
	
		return definedApplications;
	}
	
	public Long getProfileId() {
	
		return profileId;
	}
	
	public ApplicationProfileTO getProfileTO() {
	
		return profileTO;
	}
	
	public void setApplicationId(Long applicationId) {
	
		this.applicationId = applicationId;
	}
	
	public void setApplicationTO(ApplicationTO applicationTO) {
	
		this.applicationTO = applicationTO;
	}
	
	public void setDefinedApplications(List<Long> definedApplications) {
	
		this.definedApplications = definedApplications;
	}
	
	public void setProfileId(Long profileId) {
	
		this.profileId = profileId;
	}
	
	public void setProfileTO(ApplicationProfileTO profileTO) {
	
		this.profileTO = profileTO;
	}
}
