package com.framework.to;

import java.io.Serializable;
import java.util.List;

public class ScreenTreeTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6795477285933273360L;
	private Long id;
	private String screenName;
	private ScreenTO screensByChildScreenId;
	private ScreenTO screensByParentScreenId;
	private List<ScreenTO> screenList = null;
	
	public Long getId() {
	
		return id;
	}
	
	public List<ScreenTO> getScreenList() {
	
		return screenList;
	}
	
	public String getScreenName() {
	
		return screenName;
	}
	
	public ScreenTO getScreensByChildScreenId() {
	
		return screensByChildScreenId;
	}
	
	public ScreenTO getScreensByParentScreenId() {
	
		return screensByParentScreenId;
	}
	
	public void setId(Long id) {
	
		this.id = id;
	}
	
	public void setScreenList(List<ScreenTO> screenList) {
	
		this.screenList = screenList;
	}
	
	public void setScreenName(String screenName) {
	
		this.screenName = screenName;
	}
	
	public void setScreensByChildScreenId(ScreenTO screensByChildScreenId) {
	
		this.screensByChildScreenId = screensByChildScreenId;
	}
	
	public void setScreensByParentScreenId(ScreenTO screensByParentScreenId) {
	
		this.screensByParentScreenId = screensByParentScreenId;
	}
}
