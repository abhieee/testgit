package com.test.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@Controller
/*@RequestMapping("/service")*/
public class testJava1 {

/*	@RequestMapping(value="/abhishek/{name}")
	public   List<Object> abc(@PathVariable ("name")String name)
	{
		
		ArrayList<Object> f=new ArrayList<Object>();
		try{
		
		f.add(name);
		f.add("abhisdhek");
		f.add("abhisdhek");
		f.add("abhisdhek");
		f.add("abhisdhek");
		f.add("abhisdhek");
		f.add("abhisdhek");
		f.add("abhisdhek");
		f.add("abhisdhek");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	//	af.setResponse(f);
		return f;
	}
	*/
	@RequestMapping(value="/home")
	public ModelAndView  HomeChange()
	{
		return new ModelAndView("home");
		//return "home";
	}
	@RequestMapping(value="/about")
	public ModelAndView aboutChange()
	{
		return new ModelAndView("about");
	}
	@RequestMapping(value="/blog")
	public ModelAndView blogChange()
	{
		return new ModelAndView("blog");
	}
	
}
