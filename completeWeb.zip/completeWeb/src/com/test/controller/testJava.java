package com.test.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
/*@RequestMapping("/service")*/
public class testJava {

	@RequestMapping(value="/abhishek/{name}")
	public  List<Object> abc(@PathVariable ("name")String name)
	{
		
		ArrayList<Object> f=new ArrayList<Object>();
		try{
		
		f.add(name);
		f.add("abhisdhek");
		f.add("abhisdhek");
		f.add("abhisdhek");
		f.add("abhisdhek");
		f.add("abhisdhek");
		f.add("abhisdhek");
		f.add("abhisdhek");
		f.add("abhisdhek");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	//	af.setResponse(f);
		return f;
	}
	
	/*@RequestMapping(value="/home")
	public String HomeChange()
	{
		return "home";
	}
	@RequestMapping(value="/about")
	public String aboutChange()
	{
		return "about";
	}
	@RequestMapping(value="/blog")
	public String blogChange()
	{
		return "blog";
	}*/
	
}
